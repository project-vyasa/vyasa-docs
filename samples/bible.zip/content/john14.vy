` [source: https://www.bible.com/bible/111/JHN.14.NIV]

`set context { title="John 14 (NIV)" }
`chapter-title [ John 14 ]

`h1 [Jesus Comforts His Disciples]
`wj [
`v 1 [Do not let your hearts be troubled. You believe in God; believe also in me.]
`v 2 [My Father’s house has many rooms; if that were not so, would I have told you that I am going there to prepare a place for you?]
`v 3 [And if I go and prepare a place for you, I will come back and take you to be with me that you also may be where I am.]
`v 4 [You know the way to the place where I am going.]
]

`br
`h1 [Jesus the Way to the Father]
`v 5 [Thomas said to him, "Lord, we don’t know where you are going, so how can we know the way?"]
`br
`v 6 [Jesus answered,] `wj [
`v [I am the way and the truth and the life. No one comes to the Father except through me.]
`v 7 [If you really know me, you will know my Father as well. From now on, you do know him and have seen him.]
]
`br
`v 8 [Philip said, “Lord, show us the Father and that will be enough for us.”]
`br
`v 9 [Jesus answered,] `wj [
`v [“Don’t you know me, Philip, even after I have been among you such a long time? Anyone who has seen me has seen the Father. How can you say, ‘Show us the Father’?]
`v 10 [Don’t you believe that I am in the Father and the Father is in me? The words I say to you I do not speak on my own authority, but the Father who lives in me does his works.]
`v 11 [Believe me when I say that I am in the Father and the Father is in me; or at least believe because of the works themselves.]
`v 12 [Very truly I tell you, whoever believes in me will do the works I have been doing, and they will do even greater things than these, because I am going to the Father.]
`v 13 [And I will do whatever you ask in my name, so that the Father may be glorified in the Son.]
`v 14 [You may ask me for anything in my name, and I will do it.]
]

`br
`h1 [Jesus Promises the Holy Spirit]
`wj [
`v 15 [“If you love me, keep my commands.]
`v 16 [And I will ask the Father, and he will give you another advocate to help you and be with you forever—]
`v 17 [the Spirit of truth. The world cannot accept him, because it neither sees him nor knows him. But you know him, for he lives with you and will be in you.]
`v 18 [I will not leave you as orphans; I will come to you.] `v 19 [Before long, the world will not see me anymore, but you will see me. Because I live, you also will live.]
`v 20 [On that day you will realize that I am in my Father, and you are in me, and I am in you.]
`v 21 [Whoever has my commands and keeps them is the one who loves me. The one who loves me will be loved by my Father, and I too will love them and show myself to them.”]
]
`br
`v 22 [Then Judas (not Judas Iscariot) said, “But, Lord, why do you intend to show yourself to us and not to the world?”]
`br
`v 23 [Jesus replied,] `wj[
`v [“Anyone who loves me will obey my teaching. My Father will love them, and we will come to them and make our home with them.]
`v 24 [Anyone who does not love me will not obey my teaching. These words you hear are not my own; they belong to the Father who sent me.]
`br
`v 25 [“All this I have spoken while still with you.]
`v 26 [But the Advocate, the Holy Spirit, whom the Father will send in my name, will teach you all things and will remind you of everything I have said to you.]
`v 27 [Peace I leave with you; my peace I give you. I do not give to you as the world gives. Do not let your hearts be troubled and do not be afraid.]
`br
`v 28 [“You heard me say, ‘I am going away and I am coming back to you.’ If you loved me, you would be glad that I am going to the Father, for the Father is greater than I.]
`v 29 [I have told you now before it happens, so that when it does happen you will believe.]
`v 30 [I will not say much more to you, for the prince of this world is coming. He has no hold over me,]
`v 31 [but he comes so that the world may learn that I love the Father and do exactly what my Father has commanded me.]
`br
`v [“Come now; let us leave.]
]