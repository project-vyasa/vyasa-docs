// Domain Definitions for Bible
`command-def { name="wj" category="content" }
`alias-def { name="v" target="verse" }

// Native Templates
`template `verse `for "html" {
   `span { class="verse-num" } [
      `strong [ $.argument ]
   ]
   $.body
}

`template `wj `for "html" {
   `span { class="wj" } [ $.body ]
}

`template `break `for "html" {
   `br
}

`template `chapter-title `for "html" {
   `h1 { class="chapter-title" } [ $.body ]
}
