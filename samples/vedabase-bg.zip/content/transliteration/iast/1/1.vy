`dhritarashtra `uvacha
`v 1 [
        `iast[
        dharma-kṣetre kuru-kṣetre
        samavetā yuyutsavaḥ |
        māmakāḥ pāṇḍavāś caiva
        kim akurvata sañjaya
        ]
]
