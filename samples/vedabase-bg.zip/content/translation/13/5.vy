    `v 5 [
        `interlinear-streams { id="synonyms" pattern="term, meaning" }
        `synonyms [
            `term { iast="ṛṣibhiḥ" } `meaning [by the wise sages]
            `term { iast="bahudhā" } `meaning [in many ways]
            `term { iast="gītam" } `meaning [described]
            `term { iast="chandobhiḥ" } `meaning [by Vedic hymns]
            `term { iast="vividhaiḥ" } `meaning [various]
            `term { iast="pṛthak" } `meaning [variously]
            `term { iast="brahma-sūtra" } `meaning [of the Vedānta]
            `term { iast="padaiḥ" } `meaning [by the aphorisms]
            `term { iast="ca" } `meaning [also]
            `term { iast="eva" } `meaning [certainly]
            `term { iast="hetu-madbhiḥ" } `meaning [with cause and effect]
            `term { iast="viniścitaiḥ" } `meaning [certain.]
        ]
        `translation [
            That knowledge of the field of activities and of the knower of activities is described by various sages in various Vedic writings. It is especially presented in Vedānta-sūtra with all reasoning as to cause and effect.
        ]
        `purport [
            The Supreme Personality of Godhead, Kṛṣṇa, is the highest authority in explaining this knowledge. Still, as a matter of course, learned scholars and standard authorities always give evidence from previous authorities. Kṛṣṇa is explaining this most controversial point regarding the duality and nonduality of the soul and the Supersoul by referring to a scripture, the *Vedānta,* which is accepted as authority. First He says, “This is according to different sages.” As far as the sages are concerned, besides Himself, Vyāsadeva (the author of the *Vedānta-sūtra*) is a great sage, and in the *Vedānta-sūtra* duality is perfectly explained. And Vyāsadeva’s father, Parāśara, is also a great sage, and he writes in his books of religiosity, *aham tvaṁ ca tathānye.…* “we – you, I and the various other living entities – are all transcendental, although in material bodies. Now we are fallen into the ways of the three modes of material nature according to our different *karma.* As such, some are on higher levels, and some are in the lower nature. The higher and lower natures exist due to ignorance and are being manifested in an infinite number of living entities. But the Supersoul, which is infallible, is uncontaminated by the three qualities of nature and is transcendental.” Similarly, in the original *Vedas,* a distinction between the soul, the Supersoul and the body is made, especially in the *Kaṭha Upaniṣad.* There are many great sages who have explained this, and Parāśara is considered principal among them.
            
            The word *chandobhiḥ* refers to the various Vedic literatures. The *Taittirīya Upaniṣad,* for example, which is a branch of the *Yajur Veda,* describes nature, the living entity and the Supreme Personality of Godhead.
            
            As stated before, *kṣetra* is the field of activities, and there are two kinds of *kṣetra-jña:* the individual living entity and the supreme living entity. As stated in the *Taittirīya Upaniṣad* (2.5), *brahma pucchaṁ pratiṣṭhā.* There is a manifestation of the Supreme Lord’s energy known as *anna-maya,* dependence upon food for existence. This is a materialistic realization of the Supreme. Then, in *prāṇa-maya,* after realizing the Supreme Absolute Truth in food, one can realize the Absolute Truth in the living symptoms or life forms. In *jñāna-maya,* realization extends beyond the living symptoms to the point of thinking, feeling and willing. Then there is Brahman realization, called *vijñāna-maya,* in which the living entity’s mind and life symptoms are distinguished from the living entity himself. The next and supreme stage is *ānanda-maya,* realization of the all-blissful nature. Thus there are five stages of Brahman realization, which are called *brahma puccham.* Out of these, the first three – *anna-maya, prāṇa-maya* and *jñāna-maya* – involve the fields of activities of the living entities. Transcendental to all these fields of activities is the Supreme Lord, who is called *ānanda-maya.* The *Vedānta-sūtra* also describes the Supreme by saying, *ānanda-mayo ’bhyāsāt:* the Supreme Personality of Godhead is by nature full of joy. To enjoy His transcendental bliss, He expands into *vijñāna-maya, prāṇa-maya, jñāna-maya* and *anna-maya.* In the field of activities the living entity is considered to be the enjoyer, and different from him is the *ānanda-maya.* That means that if the living entity decides to enjoy in dovetailing himself with the *ānanda-maya,* then he becomes perfect. This is the real picture of the Supreme Lord as the supreme knower of the field, the living entity as the subordinate knower, and the nature of the field of activities. One has to search for this truth in the *Vedānta-sūtra,* or *Brahma-sūtra.*
            
            It is mentioned here that the codes of the *Brahma-sūtra* are very nicely arranged according to cause and effect. Some of the *sūtras,* or aphorisms, are *na viyad aśruteḥ* (2.3.2), *nātmā śruteḥ* (2.3.18), and *parāt tu tac-chruteḥ* (2.3.40). The first aphorism indicates the field of activities, the second indicates the living entity, and the third indicates the Supreme Lord, the *summum bonum* among all the manifestations of various entities.
        ]
    ]
