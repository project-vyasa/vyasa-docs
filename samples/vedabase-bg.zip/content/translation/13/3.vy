    `v 3 [
        `interlinear-streams { id="synonyms" pattern="term, meaning" }
        `synonyms [
            `term { iast="kṣetra-jñam" } `meaning [the knower of the field]
            `term { iast="ca" } `meaning [also]
            `term { iast="api" } `meaning [certainly]
            `term { iast="mām" } `meaning [Me]
            `term { iast="viddhi" } `meaning [know]
            `term { iast="sarva" } `meaning [all]
            `term { iast="kṣetreṣu" } `meaning [in bodily fields]
            `term { iast="bhārata" } `meaning [O son of Bharata]
            `term { iast="kṣetra" } `meaning [the field of activities (the body)]
            `term { iast="kṣetra-jñayoḥ" } `meaning [and the knower of the field]
            `term { iast="jñānam" } `meaning [knowledge of]
            `term { iast="yat" } `meaning [that which]
            `term { iast="tat" } `meaning [that]
            `term { iast="jñānam" } `meaning [knowledge]
            `term { iast="matam" } `meaning [opinion]
            `term { iast="mama" } `meaning [My.]
        ]
        `translation [
            O scion of Bharata, you should understand that I am also the knower in all bodies, and to understand this body and its knower is called knowledge. That is My opinion.
        ]
        `purport [
            While discussing the subject of the body and the knower of the body, the soul and the Supersoul, we shall find three different topics of study: the Lord, the living entity, and matter. In every field of activities, in every body, there are two souls: the individual soul and the Supersoul. Because the Supersoul is the plenary expansion of the Supreme Personality of Godhead, Kṛṣṇa, Kṛṣṇa says, “I am also the knower, but I am not the individual knower of the body. I am the superknower. I am present in every body as the Paramātmā, or Supersoul.”
            
            One who studies the subject matter of the field of activity and the knower of the field very minutely, in terms of this *Bhagavad-gītā,* can attain to knowledge.
            
            The Lord says, “I am the knower of the field of activities in every individual body.” The individual may be the knower of his own body, but he is not in knowledge of other bodies. The Supreme Personality of Godhead, who is present as the Supersoul in all bodies, knows everything about all bodies. He knows all the different bodies of all the various species of life. A citizen may know everything about his patch of land, but the king knows not only his palace but all the properties possessed by the individual citizens. Similarly, one may be the proprietor of the body individually, but the Supreme Lord is the proprietor of all bodies. The king is the original proprietor of the kingdom, and the citizen is the secondary proprietor. Similarly, the Supreme Lord is the supreme proprietor of all bodies.
            
            The body consists of the senses. The Supreme Lord is Hṛṣīkeśa, which means “the controller of the senses.” He is the original controller of the senses, just as the king is the original controller of all the activities of the state; the citizens are secondary controllers. The Lord says, “I am also the knower.” This means that He is the superknower; the individual soul knows only his particular body. In the Vedic literature, it is stated as follows:
            
            *kṣetrāṇi hi śarīrāṇi  
            bījaṁ cāpi śubhāśubhe  
            tāni vetti sa yogātmā  
            tataḥ kṣetra-jña ucyate*
            
            This body is called the *kṣetra,* and within it dwells the owner of the body and the Supreme Lord, who knows both the body and the owner of the body. Therefore He is called the knower of all fields. The distinction between the field of activities, the knower of activities, and the supreme knower of activities is described as follows. Perfect knowledge of the constitution of the body, the constitution of the individual soul, and the constitution of the Supersoul is known in terms of Vedic literature as *jñāna.* That is the opinion of Kṛṣṇa. To understand both the soul and the Supersoul as one yet distinct is knowledge. One who does not understand the field of activity and the knower of activity is not in perfect knowledge. One has to understand the position of *prakṛti* (nature), *puruṣa* (the enjoyer of nature) and *īśvara* (the knower who dominates or controls nature and the individual soul). One should not confuse the three in their different capacities. One should not confuse the painter, the painting and the easel. This material world, which is the field of activities, is nature, and the enjoyer of nature is the living entity, and above them both is the supreme controller, the Personality of Godhead. It is stated in the Vedic language (in the *Śvetāśvatara Upaniṣad* 1.12), *bhoktā bhogyaṁ preritāraṁ ca matvā/ sarvaṁ proktaṁ tri-vidhaṁ brahmam etat.* There are three Brahman conceptions: *prakṛti* is Brahman as the field of activities, and the *jīva* (individual soul) is also Brahman and is trying to control material nature, and the controller of both of them is also Brahman, but He is the factual controller.
            
            In this chapter it will also be explained that out of the two knowers, one is fallible and the other is infallible. One is superior and the other is subordinate. One who understands the two knowers of the field to be one and the same contradicts the Supreme Personality of Godhead, who states here very clearly, “I am also the knower of the field of activity.” One who misunderstands a rope to be a serpent is not in knowledge. There are different kinds of bodies, and there are different owners of the bodies. Because each individual soul has his individual capacity for lording it over material nature, there are different bodies. But the Supreme also is present in them as the controller. The word *ca* is significant, for it indicates the total number of bodies. That is the opinion of Śrīla Baladeva Vidyābhūṣaṇa. Kṛṣṇa is the Supersoul present in each and every body apart from the individual soul. And Kṛṣṇa explicitly says here that real knowledge is to know that the Supersoul is the controller of both the field of activities and the finite enjoyer.
        ]
    ]
