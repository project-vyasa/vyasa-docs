    `v 28 [
        `interlinear-streams { id="synonyms" pattern="term, meaning" }
        `synonyms [
            `term { iast="yeṣām" } `meaning [whose]
            `term { iast="tu" } `meaning [but]
            `term { iast="anta-gatam" } `meaning [completely eradicated]
            `term { iast="pāpam" } `meaning [sin]
            `term { iast="janānām" } `meaning [of the persons]
            `term { iast="puṇya" } `meaning [pious]
            `term { iast="karmaṇām" } `meaning [whose previous activities]
            `term { iast="te" } `meaning [they]
            `term { iast="dvandva" } `meaning [of duality]
            `term { iast="moha" } `meaning [delusion]
            `term { iast="nirmuktāḥ" } `meaning [free from]
            `term { iast="bhajante" } `meaning [engage in devotional service]
            `term { iast="mām" } `meaning [to Me]
            `term { iast="dṛḍha-vratāḥ" } `meaning [with determination.]
        ]
        `translation [
            Persons who have acted piously in previous lives and in this life and whose sinful actions are completely eradicated are freed from the dualities of delusion, and they engage themselves in My service with determination.
        ]
        `purport [
            Those eligible for elevation to the transcendental position are mentioned in this verse. For those who are sinful, atheistic, foolish and deceitful, it is very difficult to transcend the duality of desire and hate. Only those who have passed their lives in practicing the regulative principles of religion, who have acted piously, and who have conquered sinful reactions can accept devotional service and gradually rise to the pure knowledge of the Supreme Personality of Godhead. Then, gradually, they can meditate in trance on the Supreme Personality of Godhead. That is the process of being situated on the spiritual platform. This elevation is possible in Kṛṣṇa consciousness in the association of pure devotees, for in the association of great devotees one can be delivered from delusion.
            
            It is stated in the [*Śrīmad-Bhāgavatam* (5.5.2)](/en/library/sb/5/5/2/) that if one actually wants to be liberated he must render service to the devotees (*mahat-sevāṁ dvāram āhur vimukteḥ*); but one who associates with materialistic people is on the path leading to the darkest region of existence (*tamo-dvāraṁ yoṣitāṁ saṅgi-saṅgam*). All the devotees of the Lord traverse this earth just to recover the conditioned souls from their delusion. The impersonalists do not know that forgetting their constitutional position as subordinate to the Supreme Lord is the greatest violation of God’s law. Unless one is reinstated in his own constitutional position, it is not possible to understand the Supreme Personality or to be fully engaged in His transcendental loving service with determination.
        ]
    ]
