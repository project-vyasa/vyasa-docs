    `v 1 [
        `interlinear-streams { id="synonyms" pattern="term, meaning" }
        `synonyms [
            `term { iast="śrī-bhagavān uvāca" } `meaning [the Supreme Lord said]
            `term { iast="mayi" } `meaning [to Me]
            `term { iast="āsakta-manāḥ" } `meaning [mind attached]
            `term { iast="pārtha" } `meaning [O son of Pṛthā]
            `term { iast="yogam" } `meaning [self-realization]
            `term { iast="yuñjan" } `meaning [practicing]
            `term { iast="mat-āśrayaḥ" } `meaning [in consciousness of Me (Kṛṣṇa consciousness)]
            `term { iast="asaṁśayam" } `meaning [without doubt]
            `term { iast="samagram" } `meaning [completely]
            `term { iast="mām" } `meaning [Me]
            `term { iast="yathā" } `meaning [how]
            `term { iast="jñāsyasi" } `meaning [you can know]
            `term { iast="tat" } `meaning [that]
            `term { iast="śṛṇu" } `meaning [try to hear.]
        ]
        `translation [
            The Supreme Personality of Godhead said: Now hear, O son of Pṛthā, how by practicing yoga in full consciousness of Me, with mind attached to Me, you can know Me in full, free from doubt.
        ]
        `purport [
            In this Seventh Chapter of *Bhagavad-gītā,* the nature of Kṛṣṇa consciousness is fully described. Kṛṣṇa is full in all opulences, and how He manifests such opulences is described herein. Also, four kinds of fortunate people who become attached to Kṛṣṇa and four kinds of unfortunate people who never take to Kṛṣṇa are described in this chapter.
            
            In the first six chapters of *Bhagavad-gītā,* the living entity has been described as nonmaterial spirit soul capable of elevating himself to self-realization by different types of *yogas.* At the end of the Sixth Chapter, it has been clearly stated that the steady concentration of the mind upon Kṛṣṇa, or in other words Kṛṣṇa consciousness, is the highest form of all *yoga.* By concentrating one’s mind upon Kṛṣṇa, one is able to know the Absolute Truth completely, but not otherwise. Impersonal *brahma-jyotir* or localized Paramātmā realization is not perfect knowledge of the Absolute Truth, because it is partial. Full and scientific knowledge is Kṛṣṇa, and everything is revealed to the person in Kṛṣṇa consciousness. In complete Kṛṣṇa consciousness one knows that Kṛṣṇa is ultimate knowledge beyond any doubts. Different types of *yoga* are only steppingstones on the path of Kṛṣṇa consciousness. One who takes directly to Kṛṣṇa consciousness automatically knows about *brahma-jyotir* and Paramātmā in full. By practice of Kṛṣṇa consciousness *yoga,* one can know everything in full – namely the Absolute Truth, the living entities, the material nature, and their manifestations with paraphernalia.
            
            One should therefore begin *yoga* practice as directed in the last verse of the Sixth Chapter. Concentration of the mind upon Kṛṣṇa the Supreme is made possible by prescribed devotional service in nine different forms, of which *śravaṇam* is the first and most important. The Lord therefore says to Arjuna, *tac chṛṇu,* or “Hear from Me.” No one can be a greater authority than Kṛṣṇa, and therefore by hearing from Him one receives the greatest opportunity to become a perfectly Kṛṣṇa conscious person. One has therefore to learn from Kṛṣṇa directly or from a pure devotee of Kṛṣṇa – and not from a nondevotee upstart, puffed up with academic education.
            
            In the *Śrīmad-Bhāgavatam* this process of understanding Kṛṣṇa, the Supreme Personality of Godhead, the Absolute Truth, is described in the Second Chapter of the First Canto as follows:
            
            *śṛṇvatāṁ sva-kathāḥ kṛṣṇaḥ  
            puṇya-śravaṇa-kīrtanaḥ  
            hṛdy antaḥ-stho hy abhadrāṇi  
            vidhunoti suhṛt satām*
            
            *naṣṭa-prāyeṣv abhadreṣu  
            nityaṁ bhāgavata-sevayā  
            bhagavaty uttama-śloke  
            bhaktir bhavati naiṣṭhikī*
            
            *tadā rajas-tamo-bhāvāḥ  
            kāma-lobhādayaś ca ye  
            ceta etair anāviddhaṁ  
            sthitaṁ sattve prasīdati*
            
            *evaṁ prasanna-manaso  
            bhagavad-bhakti-yogataḥ  
            bhagavat-tattva-vijñānaṁ  
            mukta-saṅgasya jāyate*
            
            *bhidyate hṛdaya-granthiś  
            chidyante sarva-saṁśayāḥ  
            kṣīyante cāsya karmāṇi  
            dṛṣṭa evātmanīśvare*
            
            “To hear about Kṛṣṇa from Vedic literatures, or to hear from Him directly through the *Bhagavad-gītā,* is itself righteous activity. And for one who hears about Kṛṣṇa, Lord Kṛṣṇa, who is dwelling in everyone’s heart, acts as a best-wishing friend and purifies the devotee who constantly engages in hearing of Him. In this way, a devotee naturally develops his dormant transcendental knowledge. As he hears more about Kṛṣṇa from the *Bhāgavatam* and from the devotees, he becomes fixed in the devotional service of the Lord. By development of devotional service one becomes freed from the modes of passion and ignorance, and thus material lusts and avarice are diminished. When these impurities are wiped away, the candidate remains steady in his position of pure goodness, becomes enlivened by devotional service and understands the science of God perfectly. Thus *bhakti-yoga* severs the hard knot of material affection and enables one to come at once to the stage of *asaṁśayaṁ samagram,* understanding of the Supreme Absolute Truth Personality of Godhead.” (*Bhāg.* 1.2.17–21) Therefore only by hearing from Kṛṣṇa or from His devotee in Kṛṣṇa consciousness can one understand the science of Kṛṣṇa.
        ]
    ]
