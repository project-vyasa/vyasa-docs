`v 1 [
caturnavatitamaḥ sargaḥ 94
śrīvasiṣṭha uvāca |
uttamādhamamadhyānāṃ padārthānāmitastataḥ |
utpattīnāṃ vibhāgo'yaṃ śṛṇu vakṣyāmi rāghava
]

`v 2 [
idaṃprathamatotpanno yo'sminneva hi janmani |
idaṃprathamatānāmnī śubhābhyāsasamudbhavā
]

`v 3 [
śubhalokāśrayā sā ca śubhakāryānubandhinī |
sā cedvicitrasaṃsāravāsanāvyavahāriṇī
]

`v 4 [
bhavaiḥ katipayairmokṣamityuktā guṇapīvarī |
tādṛkphalapradānaikakāryākāryānumānadā
]

`v 5 [
tena rāma sasattveti procyate sā kṛtātmabhiḥ |
atha ceccitrasaṃsāravāsanāvyavahāriṇī
]

`v 6 [
atyantakaluṣā janmasahasrairjñānabhāginī |
tādṛkphalapradānaikadharmādharmānumānadā
]

`v 7 [
asāvadhamasattveti tena sādhubhirucyate |
saiva saṃkhyātigānantajanmavṛndādanantaram
]

`v 8 [
p. 352) 211
saṃdigdhamokṣā yadi tatprocyate'tyantatāmasī |
anadyatanajanmā tu jātistādṛśakāriṇī
]

`v 9 [
yotpattirmadhyamā puṃso rāma dvitribhavāntarā |
tādṛkkāryā tu sā loke rājasī rājasattama
]

`v 10 [
aviprakṛṣṭajanmāpi socyate kṛtabuddhibhiḥ |
sā hi tanmṛtimātreṇa mokṣayogyā mumukṣubhiḥ
]

`v 11 [
tādṛkkāryānumānena proktā rājasasāttvikī |
saiva ceditarairalpairjanmabhirmokṣabhāginī
]

`v 12 [
tattādṛśī hi sā tajjñaiḥ proktā rājasarājasī |
saiva janmaśatairmokṣabhāginī cecciraiṣiṇī
]

`v 13 [
tvaduktā tādṛgārambhā sadbhī rājasatāmasī |
saiva saṃdigdhamokṣā cetsahasrairapi janmanām
]

`v 14 [
taduktā tādṛśārambhā rājasātyantatāmasī |
bhuktajanmasahasrā tu yotpattirbrahmaṇo nṛṇām
]

`v 15 [
ciramokṣā hi kathitā tāmasī sā maharṣibhiḥ |
tajjanmanaiva mokṣasya bhāginī cettaducyate
]

`v 16 [
tajjñaistāmasasattveti tādṛśārambhaśālinī |
bhavaiḥ katipayairmokṣabhāginī cettaducyate
]

`v 17 [
tamorājasarūpeti tādṛśairguṇabṛṃhitaiḥ |
pūrvajanmasahasrāḍhyā purojanmaśatairapi
]

`v 18 [
mokṣāyogyā tataḥ proktā tajjñaistāmasatāmasī |
pūrvaṃ tu janmalakṣāḍhyā janmalakṣaiḥ puro'pi cet
]

`v 19 [
saṃdigdhamokṣā tadasau procyate'tyantatāmasī |
sarvā etāḥ samāyānti brahmaṇo bhūtajātayaḥ
]

`v 20 [
kiṃcitpracalitā bhogātpayorāśerivormayaḥ |
sarvā eva viniṣkrāntā brahmaṇo jīvarāśayaḥ
]

`v 21 [
svatejaḥspanditābhogāddīpādiva marīcayaḥ |
sarvā eva samutpannā brahmaṇo bhūtapaṅktayaḥ
]

`v 22 [
svamarīcivalodbhūtā jvalitāgneḥ kaṇā iva |
sarvā evotthitāstasmādbrahmaṇo jīvarāśāḥ `note[dṛśyadṛśya iti
pāṭhaḥ]
]

`v 23 [
mandāramañjarīrūpāścandrabimbādivāṃśavaḥ |
sarvā eva samutpannā brahmaṇo dṛśyadṛṣṭayaḥ
]

`v 24 [
yathā viṭapinaścitrāstadrūpā viṭapadhiyaḥ |
sarvā eva samutpannā brahmaṇo jīvapaṅktayaḥ
]

`v 25 [
kaṭakāṅgadakeyūrayuktayaḥ kanakādiva |
sarvā evotthitā rāma brahmaṇo jīvarāśayaḥ
]

`v 26 [
nirjharādamalohyotātpayasāmiva bindavaḥ |
ajasyaivākhilā rāma bhūtasaṃtatikalpanāḥ
]

`v 27 [
ākāśasya ghaṭasthālīrandhrākāśādayo yathā |
sarvā evotthitā lokakalanā brahmaṇaḥ padāt
]

`v 28 [
sīkarāvartalaharībindavaḥ payaso yathā |
sarvā evotthitā rāma brahmaṇo dṛśyadṛṣṭayaḥ
]

`v 29 [
mṛgatṛṣṇātaraṅgiṇyo yathā bhāskaratejasaḥ |
sarvā dṛśyadṛśo draṣṭurvyatiriktā na rūpataḥ
]

`v 30 [
śītaraśmerita jyotsnā svāloka iva tejasaḥ |
evametā hi bhūtānāṃ jātayo vividhāśca yāḥ
]

`v 31 [
yasmādeva samāyānti tasminneva viśanti ca |
kāścijjanmasahasrānte jātayaścirakālikāḥ |
kāścitkatipayātītajanmarūpā vyavasthitāḥ
]

`v 32 [
p. 353) 211
itthaṃ jagatsu vividheṣu vicitrarūpā-
stasyecchayā bhagavato vyavahāravatyaḥ |
āyānti yānti nipatanti tathotpatanti
rūpadhiyaḥ kaṇapaṭā iva pādakotthāḥ
]