`v 1 [
pañcanavatitamaḥ sargaḥ 95
śrīvasiṣṭha uvāca |
abhinnau karmakartārau samameva parātpadāt |
svayaṃ prakaṭatāṃ yātau puṣpāmodau taroriva
]

`v 2 [
sarvasaṃkalpanāmukte jīvā brahmaṇi nirmale |
sphuranti vitate vyomni nīlimevājñacakṣuṣaḥ
]

`v 3 [
aprabuddhajanācāro yatra rāghava dṛśyate |
tatra brahmaṇa utpannā jīvā ityuktayaḥ sthitāḥ
]

`v 4 [
saṃprabuddhajanācāre vaktumetanna śobhanam |
yadbrahmaṇa idaṃ jātaṃ na jātaṃ ceti rāghava
]

`v 5 [
kācidvā kalanā yāvanna nītā rāghava prathām |
upadeśyopadeśaśrīstāvalloke na śobhate
]

`v 6 [
tarhi paramārthopadeśake śāstre kima *? ra * * * *
*? rthāyukteḥ prayojanaṃ tatrāha - kācidveti | kalanā dvitīyakalpanā |
5 |
ato bhedadṛśā dīnāmaṅgīkṛtyopadiśyate |
brahmedamete jīvā vai veti vācāmayaṃ kramaḥ
]

`v 7 [
iti dṛṣṭo nirāsaṅgādbrahmaṇo jāyate jagat |
tajaṃ tadeva taddhetugataṃ duravabodhataḥ
]

`v 8 [
merumandarasaṃkāśā vahavo jīvarāśayaḥ |
utpattyotpattya saṃlīnāstasminneva pare pade
]

`v 9 [
athānantāḥ sphurantyete jāyamānāḥ sahasraśaḥ |
nānākakughnikubjeṣu pādapeṣviva pa *? vāḥ
]

`v 10 [
jīvaughāścodbhaviṣyanti madhāviva navāṅkurāḥ |
tatraiva layameṣyanti grīṣme madhurasā iva
]

`v 11 [
tiṣṭhantyajasraṃ kāleṣu ta evānye ca bhūriśaḥ |
jāyante ca pralīyante parasmiñjīvarāśayaḥ
]

`v 12 [
puṣpāmodādipābhinnau pumānkarma ca rāghava |
parameśātsamāyāte tatraiva viśataḥ śanaiḥ
]

`v 13 [
dṛṣṭamete jagatyasmindaityoraganarāmarāḥ |
udbhavantyabhavā bhāvaiḥ prasphuranti punaḥ punaḥ
]

`v 14 [
p. 354) 212
heturviharaṇe teṣāmātmavismaraṇādṛte |
na kaścillakṣyate sādho janmāntaraphalapradaḥ
]

`v 15 [
śrīrāma uvāca |
avisaṃvādinārthe yadyatprāmāṇikadṛṣṭibhiḥ |
vītarāgairvinirṇītaṃ tacchāstramiti kathyate
]

`v 16 [
mahāsattvaguṇopetā ye dhīrāḥ samadṛṣṭayaḥ |
anirdeśyakalopetāḥ sādhavasta udāhṛtāḥ
]

`v 17 [
dvayaṃ hi dṛṣṭirbālānāṃ siddhaye sarvakarmaṇām |
sādhuvṛttaṃ tathā śāstraṃ sarvadaivānuvartate
]

`v 18 [
sādhusaṃvyavahārārthaṃ śāstraṃyo nānuvartate |
bahiḥkurvanti taṃ sarve sa ca duḥkhe nimajjati
]

`v 19 [
iha loke ca vede ca śrutiritthaṃ sadā prabho |
yathā karma ca kartā ca paryāyeṇeha saṃgatau
]

`v 20 [
karmaṇā kriyate kartā kartrā karma praṇīyate |
bījāṅkurādivannyāyo lokavedokta eva saḥ
]

`v 21 [
karmaṇo jāyate janturbījādiva navāṅkuraḥ |
jantoḥ prajāyate karma punarbījamivāṅkurāt
]

`v 22 [
yayā vāsanayā janturnīyate bhavapañjare |
tadvāsanānurūpeṇa phalaṃ samanubhūyate
]

`v 23 [
evaṃ sthite kathaṃ nāma janmabījena karmaṇā |
vinotpattistvayā proktā bhūtānāṃ brahmaṇaḥ padāt
]

`v 24 [
pakṣeṇānena bhagavanbhavatā janmakarmaṇoḥ |
tiraskṛtā jagajjātā sā'vinābhāvitaitayoḥ
]

`v 25 [
brahmaṇyakāraṇe brahmanbrahmādiṣu phaleṣu ca |
karmaṇāṃ phalamastīti dvayaṃ loke pramārjitam
]

`v 26 [
saṃjāte saṃkare loke karmasvaphaladāyiṣu |
mātsyanyāye vilasati nāśa evāvaśiṣyate
]

`v 27 [
p. 355) 212
kiṃ tatkṛtaṃ bhavatyeva bhagavanbrūhi tattvataḥ |
enaṃ me saṃśayaṃ sphāraṃ chindhi vedyavidāṃvara
]

`v 28 [
śrīvasiṣṭha uvāca |
sādhu rāghava pṛṣṭo'smi tvayā praśnamimaṃ śubham |
śṛṇu vakṣyāmi te yena bhṛśaṃ jñānodayo bhavet
]

`v 29 [
mānaso'yaṃ samunmeṣaḥ kalākalanarūpataḥ |
etattatkarmaṇāṃ bījaṃ phalamasyaiva vidyate
]

`v 30 [
yadaiva hi manastattvamutthitaṃ brahmaṇaḥ padāt |
tadaiva karma jantūnāṃ jīvo dehatayā sthitaḥ
]

`v 31 [
kusumāśayayorbhedo na yathā bhinnayoriha |
tathaiva karmamanasorbhedo nāstyavibhinnayoḥ
]

`v 32 [
kriyāspando jagatyasminkarmeti kathito budhaiḥ |
pūrvaṃ tasya mano dehaṃ karmātaścittameva hi
]

`v 33 [
na sa śailo na tadvyoma na so'bdhiśca na viṣṭapam |
asti yatra phalaṃ nāsti kṛtānāmātmakarmaṇām
]

`v 34 [
aihikaṃ prāktanaṃ vāpi karma yadracitaṃ sphurat |
pauruṣo'sau paro yatno na kadācana niṣphalaḥ
]

`v 35 [
kṛṣṇatāsaṃkṣaye yadvatkṣīyate kajjalaṃ svayam |
spandātmakarmavigame tadvatprakṣīyate manaḥ
]

`v 36 [
karmanāśe manonāśo manonāśo hyakarmatā |
muktasyaiṣa bhavatyeva nāmuktasya kadācana
]

`v 37 [
vahnyauṣṇayoriva sadā śliṣṭayościttakarmaṇoḥ |
dvayorekatarābhāve dvayameva vilīyate
]

`v 38 [
p. 356) 213
cittaṃ sadā spandavilāsametya
spandaikarūpaṃ nanu karmaviddhi |
karmātha cittaṃ kila dharmakarma-
padaṃ gate rāma paraspareṇa
]