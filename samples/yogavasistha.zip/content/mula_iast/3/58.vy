`v 1 [
aṣṭapañcāśaḥ sargaḥ 58
śrīvasiṣṭha uvāca |
etasminnantare jñaptirjīvaṃ vaidūrathaṃ punaḥ |
saṃkalpena rurodhāśu manasaḥ spandanaṃ yathā
]

`v 2 [
līlovāca |
vada devi kiyānkālo gato'syāmiha mandire |
samādhau mayi līnāyāṃ mahīpāle śave sthite
]

`v 3 [
jñaptiruvāca |
iha māsastvatikrānta iha dāsyāvime tava |
rakṣārthaṃ vāsagṛhake svapato'vahite sthite
]

`v 4 [
śṛṇu dehasya kiṃvṛttaṃ taveha varavarṇini |
śarīraṃ tava pakṣeṇa tatklinnaṃ bāṣpatāṃ gatam
]

`v 5 [
nirjīvaṃ patitaṃ bhūmau saṃśuṣkamiva pallavam |
kāṣṭhakudyopamo jātaḥ śavastu himaśītalaḥ
]

`v 6 [
tato mantribhirāgatya mṛtaiveyamiti svayam |
kledālokādvinirṇīya bhūyo niṣkāsitaṃ gṛhāt
]

`v 7 [
bahunātra kimuktena nītvā candanadārubhiḥ |
citau saṃkṣipya saghṛtaṃ sahasā bhasmasātkṛtam
]

`v 8 [
p. 274) 170
tato rājñī mṛtetyuccaiḥ kṛtvā rodanamākulam |
parivārastavāśeṣaṃ kṛtavānaurdhvadehikam
]

`v 9 [
rājaśarīrasya vikārānudayastu jñaptisaṃkalpāttadīyādṛṣṭavaśācca bodhyaḥ |
8 |
idānīṃ tvāmihālokya saśarīrāmupāgatām |
paralokādāgateti mahaccitraṃ bhaviṣyati
]

`v 10 [
tvaṃ tu tena śarīreṇa satyasaṃkalpataḥ sute |
dṛśyase svavadātena citraṃ tatra tavopari
]

`v 11 [
yadvāsanā tvamabhavo dehaṃ prati tadeva te |
rūpamabhyuditaṃ bāle tena prāksadṛśaṃ tava
]

`v 12 [
svavāsanānusāreṇa sarvaḥ sarvaṃ hi paśyati |
dṛṣṭānto'trāvisaṃvādī bālavetāladarśanam
]

`v 13 [
ātivāhikadehāsi saṃpannā siddhasundari |
vismṛtastveva deho'sau prāktano'napavāsanaḥ
]

`v 14 [
rūḍhātivāhikadṛśaḥ praśāmyatyādhibhautikaḥ |
budhasya dṛśyamāno'pi śaranmegha ivāmbare
]

`v 15 [
rūḍhātivāhikībhāvaḥ sarvo bhavati dehakaḥ |
nirjalāmbhodasadṛśo nirgandhakusumopamaḥ
]

`v 16 [
sadvāsanasya rūḍhāyāmātivāhikasaṃvidi |
deho vismṛtimāyāti garbhasaṃstheva yauvane
]

`v 17 [
ekatriṃśe'dya divase prāptā vayamihāmbare |
prabhāte mohite dāsyau mayaite nidrayādhunā
]

`v 18 [
tadehi yāvallīlāyai līle saṃkalpalīlayā |
ātmānaṃ darśayāvo'syai vyavahāraḥ pravartatām
]

`v 19 [
śrīvasiṣṭha uvāca |
āvāṃ tāvadime līlā paśyatvityeva cintite |
jñaptyā devyā tatastatra dṛśye dīpte babhūvatuḥ
]

`v 20 [
sā vidūrathalīlātha samākulavilocanā |
gṛhamālokayāmāsa tattejaḥpuñjabhāsvaram
]

`v 21 [
candrabimbādivotkīrṇaṃ dhautaṃ hemadravairiva |
jvālāyā dravaśītāyāstatprabhādravabhittimat
]

`v 22 [
gṛhamālokya purato līlājñaptī vilokya te |
utthaya saṃbhramavatī tayoḥ pādeṣu sāpatat
]

`v 23 [
majjayāyāgate devyau jayatāṃ jīvanaprade |
iha pūrvamahaṃ prāptā bhavatyormārgaśodhinī
]

`v 24 [
ityuktavatyāṃ tasyāṃ tā māninyo mattayauvanāḥ |
upāviśanviṣṭareṣu latāmeruśiraḥsviva
]

`v 25 [
jñaptiruvāca |
sute vada kathaṃ prāptā tvamimaṃ deśamāditaḥ |
kiṃ vṛttaṃ te tvayā dṛṣṭaṃ kimivādhvani kutra vā
]

`v 26 [
vidūrathalīlovāca |
devi tasminpradeśe sā jātamūrcchā tadābhavam |
dvitīyendoḥ kalevāhaṃ kalpāntajvālayā hatā
]

`v 27 [
na cetitaṃ mayā kiṃcitsamaṃ viṣamameva ca |
tatastaralapakṣmānte vinimīlya vilocane
]

`v 28 [
tato maraṇamūrchānte paśyāmi parameśvari |
yāvadabhyuditāsmyāśu plutā ca gaganodare
]

`v 29 [
bhūtākāśe'nilarathaṃ samārūḍhāsmyahaṃ tataḥ |
ānītā gandhalekheva tenāhamimamālayam
]

`v 30 [
devi paśyāmi sadanaṃ nāyakenābhyalaṃkṛtam |
dīptadīpaṃ viviktaṃ ca mahārhaśayanānvitam
]

`v 31 [
patimālokayāmīmaṃ yāvadeṣa vidūrathaḥ |
śete kusumaguptāṅgo madhu puṣpavane yathā
]

`v 32 [
p. 275) 170
atha saṃgrāmasaṃrambhaśramārto'yaṃ svapityalam |
iti nidrā mayā seyaṃ deveśvari na vāritā
]

`v 33 [
anantaramimaṃ deśaṃ prāpte devyāvime tviti |
yathānubhūtaṃ kathitaṃ madanugrahakāriṇi
]

`v 34 [
devyau yuvāṃ imaṃ deśaṃ gṛhaṃ prāpte iti mayā yathānubhūtaṃ kathitam | 33
|
jñaptiruvāca |
he haṃsahārigāminyau līle lalitalocane |
utthāpayāmo nṛpatiṃ śavatalpatalādimam
]

`v 35 [
ityuktvā mumuce jīvamāmodamiva padminī |
sasamīralatākārastannāsānikaṭaṃ yayau
]

`v 36 [
ghrāṇakośaṃ viveśāntarvaṃśarandhramivānilaḥ |
svavāsanāśatānyantardadhadabdhirmaṇīniva
]

`v 37 [
antasthajīvaṃ vadanaṃ tasya tatkāntimāyayau |
padmasyāvagrahe padmaṃ suvṛṣṭa iva vāriṇi
]

`v 38 [
kramādaṅgāni sarvāṇi sarasāni cakāśire |
tasya puṣpākara iva latājālāni bhūbhṛtaḥ
]

`v 39 [
athābabhau kalāpūrṇaḥ sa rākāyāmivoḍurāṭ |
bhāsayanbhuvanaṃ bhūri vadanendumarīcibhiḥ
]

`v 40 [
sphurayāmāsa so'ṅgāni rasavanti mṛdūni ca |
kanakojjvalakāntīni pallavānīva mādhavaḥ
]

`v 41 [
unmīlayāmāsa dṛśau vimalālolatārake |
hāriṇyau subhagābhoge candrārkau bhuvanaṃ yathā
]

`v 42 [
uttasthau prollasatkāyo vindhyādrirvṛddhimāniva |
uvāca kaḥ sthita iti ghanagambhīraniḥsvanam
]

`v 43 [
līlādvayamathāsyāgre provācādiśyatāmiti |
sa dadarśa puro namraṃ līlādvayamavasthitam
]

`v 44 [
samācāraṃ samākāraṃ samarūpaṃ samasthiti |
samavākyaṃ samodyogaṃ samānandaṃ samodayam
]

`v 45 [
kā tvaṃ keyaṃ kutaśceyamityāha sa vilokayan |
tasmai līlāha he deva śrūyatāṃ yadvadāmyaham
]

`v 46 [
mahilā tava līlāhaṃ prāktanī sahadharmiṇī |
vāgarthasyeva saṃpṛktā sthitā saṃśleṣaśālinī
]

`v 47 [
iyaṃ līlā dvitīyā te mahilā helayā mayā |
upārjitā tvadarthena pratibimbamayī śubhā
]

`v 48 [
śirobhāgopaviṣṭeyaṃ pāhi haimamahāsane |
eṣā sarasvatī deva trailokyajananī śivā
]

`v 49 [
asmākaṃ puṇyasaṃbhārairiha sākṣādupāgatā |
anayeme parāllokādihānīte mahīpate
]

`v 50 [
ityākarṇya samutthāya rājā rājīvalocanaḥ |
lambamālyāmbaradharaḥ papāta jñaptipādayoḥ
]

`v 51 [
sarasvati namastubhyaṃ devi sarvahitaprade |
prayaccha varade medhāṃ dīrghamāyurdhanāni ca
]

`v 52 [
ityuktavantaṃ hastena pasparśa jñaptidevatā |
sarasvatyuvāca |
tvaṃ putrābhimatārthāḍhyo bhaveti bhavanānvitaḥ
]

`v 53 [
sarvāpadaḥ sakaladuṣkṛtadṛṣṭayaśca
gacchantu vaḥ śamamanantasukhāni samyak |
āyāntu nityamuditā janatā bhavantu
rāṣṭre sthirāśca vilasantu sadaiva lakṣmyaḥ
]