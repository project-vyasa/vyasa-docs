`v 1 [
tripañcāśaḥ sargaḥ 53
śrīvasiṣṭha uvāca |
atha labdhavarā dehenānenaiva mahīpatim |
patimāptuṃ prayātyeṣā nabhomārgeṇa viṣṭapam
]

`v 2 [
iti saṃcintya sānandamuddamamakaradhvajā |
pupluve pelavākārā pakṣiṇīva nabhastale
]

`v 3 [
kumārīṃ tatra sā prāpa jñaptyaiva prahitāṃ hitām |
svasaṃkalpamahādarśātpurato nirgatāmiva
]

`v 4 [
kumāryuvāca |
duhitāsmi sakhi jñapteḥ svāgataṃ te'stu sundari |
pratīkṣamāṇā tvāmeva sthitāsmīha nabhaḥpathi
]

`v 5 [
p. 257) 161
līlovāca |
devi bhartuḥ samīpaṃ māṃ naya nīrajalocane |
mahatāṃ darśanaṃ yasmānna kadācana niṣphalam
]

`v 6 [
śrīvasiṣṭha uvāca |
ehi tatraiva gacchāva ityuktvā sā kumārikā |
purastasyāḥ sthitā vyomni mārgadarśanatatparā
]

`v 7 [
tatastadanuyātā sā prāpa koṭaramambaram |
nirmalaṃ karamālāgraṃ yathā lakṣaṇalekhikā
]

`v 8 [
meghamārgamathollaṅghya vātaskandhāntare gatā |
sūryamārgādabhigatā tārāmārgamatītya ca
]

`v 9 [
vāyvindrasurasiddhānāṃ lokānullaṅghya lāghavāt |
brahmaviṣṇumaheśānāṃ prāpa brahmāṇḍakharparam
]

`v 10 [
himaśaityaṃ yathāntasthaṃ kumbhe'bhinne bahirbhavet |
tathā saṃkalpasiddhā sā brahmāṇḍānnirgatā bahiḥ
]

`v 11 [
svacittamātradehaiṣā svasaṃkalpasvabhāvajam |
antarevānubhavati kilaivaṃ nāma vibhramam
]

`v 12 [
brahmādisthānamākramya prāpya brahmāṇḍakharparam |
tato brahmāṇḍapārasthā jalādyāvaraṇāni ca
]

`v 13 [
samullaṅghya puraḥ prāpa mahācidgaganāntaram |
adṛṣṭapāraparyantamativegena dhāvatā |
sarvato garuḍenāpi kalpakoṭiśatairapi
]

`v 14 [
tatra brahmāṇḍalakṣāṇi santyasaṃkhyāni bhūriśaḥ |
tānyanyonyamadṛṣṭāni phalānīva mahāvane
]

`v 15 [
tatraikasminpuraḥsaṃsthe vitatāvaraṇānvite |
vedhayitvā viveśāntarbadaraṃ kṛmiko yathā
]

`v 16 [
punarbrahmendraviṣṇvādilokānullaṅghya bhāsvarān |
tanmahīmaṇḍalaṃ śrīmatprāpa tārāpathādadhaḥ
]

`v 17 [
tatra tanmaṇḍalaṃ prāpya tatpuraṃ tacca maṇḍapam |
praviśya puṣpaguptasya śavasya nikaṭe sthitā
]

`v 18 [
etasminnantare sā ca na dadarśa kumārikām |
māyāmiva parijñātāṃ kvāpi yātāṃ varānanā
]

`v 19 [
mukhamālokya sā tasya svabhartuḥ śavarūpiṇaḥ |
idaṃ buddhavatī satyaṃ pratibhāvaśataḥ svataḥ
]

`v 20 [
ayaṃ sa bhartā saṃgrāme nihato mama sindhunā |
vīralokānimānprāpya kṣaṇaṃ śete yathāsukham
]

`v 21 [
ahaṃ devyāḥ prasādena saśarīraivamīdṛśam |
iha prāptavatī dhanyā matsamā nāsti kācana
]

`v 22 [
iti saṃcintya sā haste gṛhītvā cāru cāmaram |
bījayāmāsa candreṇa dyaurivāvanimaṇḍalam
]

`v 23 [
prabuddhalīlovāca |
te bhṛtyāstāśca vai dāsyaḥ sa rājā ca prabuddhavān |
vakṣyanti vadatāṃ devi kiṃ kayaiva kathaṃ dhiyā
]

`v 24 [
śrīdevyuvāca |
sa rājā sā ca te bhṛtyāḥ sarva eva parasparam |
cidākāśaikatāveśādāvayośca prabhāvataḥ
]

`v 25 [
mahācitpratibhāsatvānmahāniyatiniścayāt |
anyonyameva paśyanti mithaḥ saṃpratibimbitāt
]

`v 26 [
iyaṃ me sahajā bhāryā mameyaṃ sahajā sakhī |
mameyaṃ sahajā rājñī bhṛtyo'yaṃ sahajo mama
]

`v 27 [
kevalaṃ tvamahaṃ sā ca yathāvṛttamakhaṇḍitam |
jñāsyāma idamāścaryaṃ natu kaścidapītaraḥ
]

`v 28 [
prabuddhalīlovāca |
amunaiva śarīreṇa kimarthaṃ na gatā patim |
eṣā vareṇa saṃprāptā līlā lalitavādinī
]

`v 29 [
p. 258) 162
śrīdevyuvāca |
aprabuddhadhiyaḥ siddhalokānpuṇyavaśoditān |
na samarthāḥ svadehena prāptuṃ chāyā ivātapān
]

`v 30 [
ādisarge ca niyatiḥ sthāpiteti prabodhibhiḥ |
yathā satyamalīkena na milatyeva kiṃcana
]

`v 31 [
prabodhibhiḥ satyasaṃkalpairīśvarahiraṇyagarbhādibhiriti niyatirmaryādā sthāpitā |
tatra dṛṣṭāntaḥ - yatheti | tathāca bhāṣyam - yatra hi
yadadhyāsastatkṛtena guṇena doṣeṇa vā aṇumātreṇāpi sa na saṃbadhyate iti | 30
|
yāvadvetālasaṃkalpo bālasya kila vidyate |
nirvetāladhiyastāvadudayastasya kaḥ katham
]

`v 32 [
avivekajvaroṣṇatvaṃ vidyate yāvadātmani |
tāvadvivekaśītāṃśuśaityaṃ kuta udetyalam
]

`v 33 [
ahaṃ pṛthvyādidehaḥ khe gatirnāsti mamottamā |
iti niścayavānyo'ntaḥ kathaṃ syātso'nyaniścayaḥ
]

`v 34 [
ato jñānavivekena puṇyenātha vareṇa ca |
puṇyadehena gacchanti paraṃ lokamanena tu
]

`v 35 [
śuṣkaparṇaṃ kilāṅgāre etadevāśu `note[patadevāśu iti pāṭhaḥ
kvacillabhyate] dahyate |
ayaṃ dehamahaṃdehaḥ prāpta eva viśīryate
]

`v 36 [
etāvadeva bhavati varaśāpavijṛmbhitaiḥ |
yathā saṃcintya evāhaṃ tathā smṛta iti smṛtiḥ
]

`v 37 [
yaḥ sarpapratyayo rajjvāṃ sa kathaṃ sarpakāryakṛt |
ātmanyeva hi yo nāsti tasya kā kāryakāritā
]

`v 38 [
yastvetanmṛta ityeva mithyā samanubhūyate |
prāgabhyāsasya puṣṭasya nāmaitatpravijṛmbhate
]

`v 39 [
svānubhūte jagajjāle sugamāḥ saṃsmṛtibhramāḥ |
nānyasaṃkalpito nāma sargādyabhyāsa īdṛśaḥ
]

`v 40 [
antaranubhūyamānāḥ
saṃsṛtayo bāhyabhūtajālānām |
aviditavedyadṛśāmapi
dūre puṃsāmivaindavaṃ bimbam
]