`v 1 [
p. 162)
śrīvasiṣṭha uvāca |
itthaṃ jagadahaṃtādidṛśyajātaṃ na kiṃcana |
ajātatvācca nāstyeva yaccāsti parameva tat
]

`v 2 [
paramākāśamevādau jīvatāṃ cetati svayam |
niḥspandāmbhodhikuhare salilaṃ spandatāmiva
]

`v 3 [
ākāśarūpamajahadevaṃ vettīva hṛdyatām |
svapnasaṃkalpaśalādāviva cidvṛttirāntarī
]

`v 4 [
pṛthvyādirahito deho yo virāḍātmako mahān |
ātivāhika evāsau cinmātrācchanabhomayaḥ
]

`v 5 [
akṣayaḥ svapnaśailābhaḥ sthirasvapnapuropamaḥ |
citrakṭsthiracittasthacitrasainyasamākṛtiḥ
]

`v 6 [
anikhātamahāstambhaputrikaughasamopamaḥ |
brahmākāśe'nikhātātmā sustambhe śālabhañjikā
]

`v 7 [
ādyaḥ prajāpatiḥ pūrvaṃ svayaṃbhūriti viśrutaḥ |
prākanānāṃ svakāryāṇāmabhāvādapyakāraṇaḥ
]

`v 8 [
mahāpralayaparyanteṣvādyakālapitāmahāḥ `note[ṣvādyā kila iti pāṭhaḥ]
|
mucyante sarva evātaḥ prāktanaṃ karma teṣu kim
]

`v 9 [
so'kuḍya eva kuḍyātmā dṛśyādṛśyaḥ svayaṃsthitaḥ |
na ca dṛśyaṃ na ca draṣṭā na sraṣṭā sarvameva ca
]

`v 10 [
pratiśabdapadārthānāṃ sarveṣāmeṣa eva saḥ |
tasmādudeti jīvālī dīpālī dīpakādiva
]

`v 11 [
saṃkalpa eva saṃkalpātkileti kṣmādivarjitaḥ |
ādimādiva niḥśūnyaḥ svapnātsvapnāntaraṃ yathā
]

`v 12 [
asmādekapratispandājjīvāḥ saṃprasaranti ye |
sahakārikāraṇānāmabhāvācca sa eva te
]

`v 13 [
sahakārikāraṇānāmabhāve kāryakāraṇam |
ekametadato nānyaḥ parasmātsargavibhramaḥ
]

`v 14 [
brahmavādyo virāḍātmā virāḍātmeva sargatā |
jīvākāśaḥ sa evetthaṃ sthitaḥ pṛthvyādyasadyataḥ
]

`v 15 [
śrīrāma uvāca |
kiṃ syātparimito jīvo rāśirāho anantakaḥ |
āhosvidastyanantātmā jīvapiṇḍo'calopamaḥ
]

`v 16 [
dhārāḥ payomuca iva śīkarā iva vāridheḥ |
kaṇāstaptāyasa iva kasmānniryānti jīvakāḥ
]

`v 17 [
p. 163)
iti me bhagavanbrūhi jīvajālavinirṇayam |
jñātametanmayā prāyastadeva prakaṭīkuru
]

`v 18 [
śrīvasiṣṭha uvāca |
eka eva na jīvo'sti rāśīnāṃ saṃbhavaḥ kutaḥ |
śaśaśṛṅgaṃ samuḍḍīya prayātīve hi te vacaḥ
]

`v 19 [
na jīvo'sti na jīvānāṃ rāśayaḥ santi rāghava |
na caikaḥ parvataprakhyo jīvapiṇḍo'sti kaścana
]

`v 20 [
jīvaśabdārthakalanāḥ samastakalanānvitāḥ |
neha kāścana santīti niścayo'stu tavācalaḥ
]

`v 21 [
śuddhacinmātramamalaṃ brahmāstīha hi sarvagam |
tadyathā sarvaśaktitvādvindate yāḥ svayaṃ kalāḥ
]

`v 22 [
cinmātrānukrameṇaiva saṃpraphullalatāmiva |
nanu mūrtāmamūrtāṃ vā tāmevāśu prapaśyati
]

`v 23 [
jīvo buddhiḥ kriyāspando manodvitvaikyamityapi |
svasattāṃ prakacantīṃ tāṃ niyojayati vedane
]

`v 24 [
sā'buddhaiva bhavatyevaṃ bhavedbrahmaiva bodhataḥ `note[bodhitā iti
pāṭhaḥ] |
abodhaḥ prekṣayā yāti nāśaṃ na tu prabudhyate
]

`v 25 [
yathāndhakāro dīpena prekṣyamāṇaḥ praṇaśyati |
na cāsya jñāyate tattvamabodhasyaivameva hi
]

`v 26 [
evaṃ brahmaiva jīvātmā nirvibhāgo nirantaraḥ |
sarvaśaktiranādyanto mahācitsārarūpavān
]

`v 27 [
sarvānaṇutayā tvasya na kvacidbhedakalpanā |
vidyate yā hi kalanā sā tadevānubhūtitaḥ
]

`v 28 [
śrīrāma uvāca |
evametatkathaṃ brahmannekajīvecchayākhilāḥ |
jagajjīvā na yujyante mahājīvaikatāvaśāt
]

`v 29 [
śrīvasiṣṭha uvāca |
mahājīvātma tadbrahma sarvaśaktimayātmakam |
sthitaṃ tathecchameveha nirvibhāgaṃ nirantaram
]

`v 30 [
yadevecchati tattasya bhavatyāśu mahātmanaḥ |
pūrvaṃ teneṣṭamicchādi tato dvitvamudeti yat
]

`v 31 [
paścāddvitvavibhaktānāṃ svaśaktīnāṃ prakalpitaḥ |
anenetthaṃ hi bhavatītyevaṃ tena kriyākramaḥ
]

`v 32 [
taṃ vinānudaye tvāsāṃ pradhānecchaiva rohati |
śaktyā hyajātayā brāhyā niyamo'yaṃ prakalpitaḥ
]

`v 33 [
yasyā jīvābhidhānāyāḥ śaktyapekṣā phalatyasau |
pradhānaśaktiniyamānuṣṭhānena vinā na tu
]

`v 34 [
p. 164)
pradhānaśaktiniyamaḥ supratiṣṭho na `note[bhavedbhavet iti pāṭhaḥ]
cedbhavet |
tatphalaṃ śaktyadhīnatvānnehitānāṃ kvacidbhavet
]

`v 35 [
evaṃ brahma mahājīvo vidyate'ntādivarjitaḥ |
jīvakoṭi mahākoṭi bhavatyatha na kiṃcana
]

`v 36 [
cetyasaṃvedanājjīvo bhavatyāyāti saṃsṛtim |
tadasaṃvedanādrūpaṃ samāyāti samaṃ punaḥ
]

`v 37 [
evaṃ kaniṣṭhajīvānāṃ jyeṣṭhajīvakramākramaiḥ |
samudetyātmajīvatvaṃ tāmrāṇāmiva hematā
]

`v 38 [
atrāntare mahākāśa itthameṣa gaṇo'pyasan |
svātmaiva sadivodeti ciccamatkaraṇātmakaḥ
]

`v 39 [
svayameva camatkāro yaḥ samāpadyate citaḥ |
bhaviṣyannāmadehādi tadahaṃbhāvanaṃ viduḥ
]

`v 40 [
cito yasmāccidālehastanmayatvādanantakaḥ |
sa eṣa bhuvanābhoga iti tasyāṃ prabimbati
]

`v 41 [
pariṇāmavikārādiśabdaiḥ saiva cidavyayā |
tādṛgrūpādabhedyāpi svaśaktyaiva vibudhyate
]

`v 42 [
avicchinnavilāsātma svato yatsvadanaṃ citaḥ |
cetyasya ca prakāśasya jagadityeva tatsthitam
]

`v 43 [
ākāśādapi sūkṣmaiṣā yā śaktirvitatā citaḥ |
sā svabhāvata evaitāmahaṃtāṃ paripaśyati
]

`v 44 [
ātmanyātmātmanaivāsyā yatprasphurati vārivat |
jagadantamahaṃtāṇuṃ tadaiṣā saṃprapaśyati
]

`v 45 [
camatkārakarī cāru yaccamatkurute citiḥ |
svayaṃ svātmani tasyaiva jagannāma kṛtaṃ tataḥ
]

`v 46 [
citaścetyamahaṃkāraḥ saiva rāghava kalpanā |
tanmātrādi cidevāto dvitvaikatve kva saṃsthite
]

`v 47 [
jīvahetvādisaṃtyāge tvaṃ cāhaṃ ceti saṃtyaja |
śeṣaḥ sadasatormadhye bhavatyarthātmako bhavet
]

`v 48 [
citā yathādau kalitā svasattā sā tathoditā |
abhinnā dṛśyate vyomnaḥ sattāsatte na vidmahe
]

`v 49 [
viśvaṃkhaṃ jagadīhākhyaṃ khamasti vibudhālayaḥ |
sākāraściccamatkārarūpatvānnānyadasti hi
]

`v 50 [
yo yadvilāsastasmātsa na kadācana bhidyate |
api sāvayavaṃ tasmātkaivānavayave kathā
]

`v 51 [
citernityamacetyāyā nirnāmnyā vitatākṛteḥ |
yadrūpaṃ jagato rūpaṃ tattatsphuraṇarūpiṇaḥ
]

`v 52 [
mano buddhirahaṃkāro bhūtāni girayo diśaḥ |
iti yā yāstu racanāścitastattvājjagatsthiteḥ
]

`v 53 [
citeścittvaṃ jagadviddhi nājagaccittvamasti hi |
ajagattvādaciccitsyādbhānādbhedo jagatkutaḥ
]

`v 54 [
p. 165)
citermarīcibījasya nijā yāntaścamatkṛtiḥ |
sā caiṣā jīvatanmātramātraṃ jagaditi sthitā
]

`v 55 [
cittātsvaśaktikacanaṃ `note[cittāditi mūle ṭīkāyāṃ ca pāṭhaḥ]
yadahaṃbhāvanaṃ citaḥ |
jīvaḥ spandanakarmātmā bhaviṣyadabhidho hyasau
]

`v 56 [
yacciccittvena kacanaṃ svasaṃpādyābhidhātmakam |
svavikārairvyavacchedyaṃ bhidyate no na vidyate
]

`v 57 [
citspandarūpiṇorasti na bhedaḥ kartṛkarmaṇoḥ |
spandamātraṃ bhavetkarma sa eva puruṣaḥ smṛtaḥ
]

`v 58 [
jīvaścittaparispandaḥ puṃsāṃ cittaṃ sa eva ca |
manastvindriyarūpaṃ satsattāṃ nāneva gacchati
]

`v 59 [
śāntāśeṣaviśeṣaṃ hi citprakāśacchaṭā jagat |
kāryakāraṇakāditvaṃ tasmādanyanna vidyate
]

`v 60 [
acchedyo'hamadāhyo'hamakledyo'śoṣya eva ca |
nityaḥ sarvagataḥ sthāṇuracalo'hamiti sthitam
]

`v 61 [
vavadante tathā hyatra vivadanto yathā bhramaiḥ |
bhramayanto vayaṃ tvete jātā vigatavibhramāḥ
]

`v 62 [
dṛśye mūrte jñasaṃrūḍhe vikārādi pṛthagbhavet |
nāmūrte tajjñakacite citkhe sadasadātmani
]

`v 63 [
cittarau cetyarasataḥ śaktiḥ kālādināmikām |
tanotyākāśaviśadāṃ cinmadhuśrīḥ svamañjarīm
]

`v 64 [
svayaṃ vicitraṃ sphurati cidaṇḍakamanāhatam |
svayaṃ vilakṣaṇaspandaṃ cidvāyuraṇḍajātmakaḥ `note[raṇḍajātmakam iti
pāṭhaḥ]
]

`v 65 [
svayaṃ vicitraṃ kacanaṃ cidvāri na nikhātagam |
svayaṃ vicitradhātutvaṃ śreṣṭhāṅgamapi nirmitam
]

`v 66 [
svavicitrarasollāsā cijjyotsnā satatoditā |
svayaṃ cideva prakaṭaścidāloko mahātmakaḥ
]

`v 67 [
svayamastaṃ gate bāhye svajñānāduditā citiḥ |
svayaṃ jaḍeṣu jāḍyena padaṃ sauṣuptamāgatā
]

`v 68 [
svayaṃ spanditayāspandicittvācciti mahānabhaḥ |
citprakāśaprakāśo hi jagadasti ca nāsti ca
]

`v 69 [
cidākāśaikaśūnyatvaṃ jagadasti ca nāsti ca |
cidālokamahārūpaṃ jagadasti ca nāsti ca
]

`v 70 [
p. 166)
cinmārutaparispando jagadasti ca nāsti ca |
ciddhanadhvāntakṛṣṇatvaṃ jagadasti ca nāsti ca
]

`v 71 [
cidarkālokadivaso jagadasti ca nāsti ca |
citkajjalarajastailaparamāṇurjagatkramaḥ `note[jagadbhamaḥ iti pāṭhaḥ]
]

`v 72 [
cidgnyauṣṇyaṃ jagallekhā jagaccicchaṅkhaśuklatā |
jagaccicchailajaṭharaṃ cijjaladravatā jagat
]

`v 73 [
jagaccidikṣumādhuryaṃ citkṣīrasnigdhatā jagat |
jagacciddhimaśītatvaṃ cijjvālājvalanaṃ jagat
]

`v 74 [
jagaccitsarṣapasneho vīciścitsarito jagat |
jagaccitkṣudramādhuryaṃ jagaccitkanakāṅgadam
]

`v 75 [
jagaccitpuṣpasaugandhyaṃ cillatāgraphalaṃ jagat |
citsattaiva jagatsattā jagatsattaiva cidvapuḥ
]

`v 76 [
sarvatra cidapṛthaksattvādeva jagataściddharmatvamabhipretamiti sphuṭamāha ##-
atra bhedavikārādi nakhe malamiva sthitam |
itīdaṃ danmayatvena sadasadbhuvanatrayam
]

`v 77 [
avikalpatadātmatvātsattāsattaikataiva ca |
avayavāvayavitā śabdārthau śaśaśṛṅgavat
]

`v 78 [
anubhūtyapalāpāya kalpito yairdhigastu tān |
na vidyate jagadyatra sādryabdhyuvīnadīśvaram
]

`v 79 [
cidekatvātprasaṅgaḥ syātkastatretaravibhramaḥ |
śilāhṛdayapīnāpi svākāśe viśadaiva cit
]

`v 80 [
dhatte'ntarakhilaṃ śāntaṃ saṃniveśaṃ yathā śilā |
padārthanikarākāśe tvayamākāśajo malaḥ
]

`v 81 [
sattāsattātmatātvattāmattāśleṣā na santi te |
pallavāntaralekhaughasaṃniveśavadātatam
]

`v 82 [
anyānanyātmakamidaṃ dhatte'ntaścitsvabhāvataḥ |
samastakāraṇaughānāṃ kāraṇādi pitāmahaḥ
]

`v 83 [
svabhāvato kāraṇātma cittaṃ ciddhyanubhūtitaḥ |
na cāsattvamacetyāyāścito vācāpi siddhyati
]

`v 84 [
yadasti tadudetīti dṛṣṭaṃ bījādivāṅkuraḥ
]

`v 85 [
gagana iva suśūnyabhedamasti
tribhuvanamaṅga mahācito'ntarasyāḥ |
paramapadamayaṃ samastadṛśyaṃ
tvidamiti niścayavānbhavānubhūteḥ
]

`v 86 [
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino `note[mito iti kvacit] jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]