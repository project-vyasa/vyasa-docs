`v 1 [
ṣaṇṇavatitamaḥ sargaḥ 96
śrīvasiṣṭha uvāca |
mano hi bhāvanāmātraṃ bhāvanā spandadharmiṇī |
kriyā tadbhāvitārūpaṃ phalaṃ sarvo'nudhāvati
]

`v 2 [
śrīrāma uvāca |
vistareṇa mama brahman jaḍasyāpyajaḍākṛteḥ |
rūpamārūḍhasaṃkalpaṃ manaso vaktumarhasi
]

`v 3 [
śrīvasiṣṭha uvāca |
anantasyātmatattvasya sarvaśaktermahātmanaḥ |
saṃkalpaśakti racitaṃ yadrūpaṃ tanmano viduḥ
]

`v 4 [
bhāvaḥ sadasatormadhye nṛṇāṃ calati yaścalaḥ |
kalanonmukhatāṃ yātastadrūpaṃ manaso viduḥ
]

`v 5 [
nāhaṃ vedāvabhāsātmā kurvāṇo'smīti niścayaḥ |
tasmādekāntakalanastadrūpaṃ manaso viduḥ
]

`v 6 [
kalpanātmikayā karmaśaktyā virahitaṃ manaḥ |
na saṃbhavati loke'sminguṇahīno guṇī yathā
]

`v 7 [
yathā vahnyauṣṇyayoḥ sattā na saṃbhavati bhinnayoḥ |
tathaiva karmamanasostathātmamanasorapi
]

`v 8 [
svenaiva cittarūpeṇa karmaṇā phaladharmiṇā |
saṃkalpaikaśarīreṇa nānāvistaraśālinā
]

`v 9 [
idaṃ tatamanekātma māyāmayamakāraṇam |
viśvaṃ vigatavinyāsaṃ vāsanākalpanākulam
]

`v 10 [
yā yena vāsanā yatra satevāropitā yathā |
sā tena phalasūstatra tadeva prāpyate tathā
]

`v 11 [
karma bījaṃ manaḥspandaḥ kathyate'thānubhūyate |
kriyāstu vividhāstasya śākhāścitraphalāstaroḥ
]

`v 12 [
mano yadanusaṃdhatte tatkarmendriyavṛttayaḥ |
sarvāḥ saṃpādayantyetāstasmātkarma manaḥ smṛtam
]

`v 13 [
mano buddhirahaṃkāraścittaṃ karmātha kalpanā |
saṃsṛtirvāsanā vidyā prayatnaḥ smṛtireva ca
]

`v 14 [
mana eva sarvendriyabhāvaṃ dhatta iti nāyaṃ doṣa iti darśayaṃstannāmānyāha ##-
indriyaṃ prakṛtirmāyā kriyā cetītarā api |
citrāḥ śabdoktayo brahmansaṃsārabhramahetavaḥ
]

`v 15 [
kākatālīyayogena tyaktasphāradṛgākṛteḥ |
citeścetyānupātinyāḥ kṛtāḥ paryāyavṛttayaḥ
]

`v 16 [
p. 357) 213
śrīrāma uvāca |
parāyāḥ saṃvido brahmannetāḥ paryāyavṛttayaḥ |
kalpyamānavicitrārthāḥ kathaṃ rūḍhimupāgatāḥ
]

`v 17 [
śrīvasiṣṭha uvāca |
gateva sakalaṅkatvaṃ kadācitkalpanātmakam |
unmeṣarūpiṇī nānā tadaiva hi manaḥsthitā
]

`v 18 [
bhāvanāmanusaṃdhānaṃ yadā niścitya saṃsthitā |
tadaiṣā procyate buddhiriyattāgrahaṇakṣamā
]

`v 19 [
yadā tu prathamaṃ vikalpottaraṃ vā viśeṣabhāvanāṃ prāpya
ekatarakoṭyanusaṃdhānaṃ niścitya susthirā sthitā tadaiṣā saṃvidbuddhiriti
procyate | iyattā īdṛśamevedaṃ vastviti paricchittistadgrahaṇasamarthetyarthaḥ |
18 |
yadā mithyābhimānena sattāṃ kalpayati svayam |
ahaṃkārābhimānena procyate bhavabandhanī
]

`v 20 [
idaṃ tyaktvedamāyāti bālavatpelavā yadā |
vicāraṃ saṃparityajya tadā sā cittamucyate
]

`v 21 [
yadā spandaikadharmatvātkarturyā śūnyaśaṃsinī |
ādhāvati spandaphalaṃ tadā karmetyudāhṛtā
]

`v 22 [
kākatālīyayogena tyaktvaikaghananiścayam |
yadehitaṃ kalpayati bhāvaṃ teneha kalpanā
]

`v 23 [
pūrvadṛṣṭamadṛṣṭaṃ vā prāgdṛṣṭamiti niścayaiḥ |
yadaivehāṃ vidhatte'ntastadā smṛtirudāhṛtā
]

`v 24 [
yadā padārthaśaktīnāṃ saṃbhuktānāmivāmbare |
vasatyastamitānyehā vāsaneti tadocyate
]

`v 25 [
astyātmatattvaṃ vimalaṃ dvitīyā dṛṣṭiraṅkitā |
jātā hyavidyamānaiva tadā vidyeti kathyate
]

`v 26 [
sphuratyātmavināśāya vismārayati tatpadam |
mithyāvikalpajālena tanmalaṃ parikalpyate
]

`v 27 [
śrutvā spṛṣṭvā ca dṛṣṭvā ca bhuktvā ghrātvā vimṛśya ca |
indramānandayatyeṣā `note[iṃdramāmodayatyeṣā iti pāṭhaḥ]
tenendriyamiti smṛtam
]

`v 28 [
sarvasya dṛśyajālasya paramātmanyalakṣite |
prakṛtatvena bhāvānāṃ loke prakṛtirucyate
]

`v 29 [
sadasattāṃ nayatyāśu sattāṃ vā sattvamañjasā |
sattāsattāvikalpo'yaṃ tena māyeti kathyate
]

`v 30 [
darśanaśravaṇasparśarasanaghrāṇakarmabhiḥ |
kriyeti kathyate loke kāryakāraṇatāṃ gatā
]

`v 31 [
citeścetyānupātinyā gatāyāḥ sakalaṅkatām |
prasphuradrūpadharmiṇyā etāḥ paryāyavṛttayaḥ
]

`v 32 [
cittatāmupayātāyā gatāyāḥ prakṛtaṃ padam |
svaireva saṃkalpaśatairbhṛśaṃ rūḍhimupāgatāḥ
]

`v 33 [
cetanīyakalaṅkāṅkājjāḍyajālānupātinī |
saṃkhyāvibhāgakalanā svavaikalyākuleva cit
]

`v 34 [
p. 358) 214
jīva ityucyate loke mana ityapi kathyate |
cittamityucyate saiva buddhirityucyate tathā
]

`v 35 [
nānāsaṃkalpakalilaṃ paryāyanicayaṃ budhāḥ |
vadantyasyāḥ kalaṅkinyāścyutāyāḥ paramātmanaḥ
]

`v 36 [
śrīrāma uvāca |
manaḥ kiṃ syājjaḍaṃ brahmaṃstathā vāpi ca cetanam |
ityeko mama tattvajña niścayo'ntarna jāyate
]

`v 37 [
śrīvasiṣṭha uvāca |
mano hi na ja'ṃ rāma nāpi cetanatāṃ gatam |
mlānā'jaḍā tadā dṛṣṭirmana ityeva kathyate
]

`v 38 [
cidacidubhayasaṃvalanarūpatvānnaikatararūpaṃ manaḥ paramārthatastu manvāno
mana iti tānyetāni karmanāmānyeva iti śrutāvātmana eva
karmaprayuktanāmadheyeṣu manaḥśabdaparigaṇanādajaḍā dṛṣṭiścideva tadā
saṃsāradaśāyāṃ mlānā upādhimālinyānubhāvinī mana iti kathyate ityarthaḥ | 37
|
madhye sadasato rūpaṃ pratibhūtaṃ yadāvilam |
jagataḥ kāraṇaṃ nāma tadetaccittamucyate
]

`v 39 [
śāśvatenaikarūpeṇa niścayena vinā sthitiḥ |
yena sā cittamityuktā tasmājjātamidaṃ jagat
]

`v 40 [
jaḍājaḍadṛśormadhye dolārūpaṃ svakalpanam |
yaccito mlānarūpiṇyāstadetanmana ucyate
]

`v 41 [
cinniḥspando hi malinaḥ kalaṅkavikalāntaram |
mana ityucyate rāma na jaḍaṃ na ca cinmayam
]

`v 42 [
tasyemāni vicitrāṇi nāmāni kalitānyalam |
ahaṃkāramanobuddhijīvādyānītarāṇyapi
]

`v 43 [
yathā gacchati śailūṣo rūpāṇyalaṃ tathaiva hi |
mano nāmānyanekāni dhatte karmāntaraṃ vrajat
]

`v 44 [
citrādhikāravaśato vicitrā vikṛtābhidhāḥ |
yathā yāti naraḥ karmavaśādyāti tathā manaḥ
]

`v 45 [
yā etāḥ kathitāḥ saṃjñā mayā rāghava cetasaḥ |
etā evānyathā proktā vādibhiḥ kalpanāśataiḥ
]

`v 46 [
svabhāvābhimatāṃ buddhimāropya manasā kṛtāḥ |
manobuddhindriyādīnāṃ vicitrā nāmarītayaḥ
]

`v 47 [
mano hi jaḍamanyasya bhinnamanyasya jīvataḥ |
tathāhaṃkṛtiranyasya buddhiranyasya vādinaḥ
]

`v 48 [
ahaṃkāramanobuddhidṛṣṭayaḥ sṛṣṭikalpanāḥ |
ekarūpatayā proktā yā mayā raghunandana
]

`v 49 [
naiyāyikairitarathā tādṛśaiḥ parikalpitāḥ |
anyathā kalpitāḥ sāṃkhyaiścārvākairapi cānyathā
]

`v 50 [
jaminīyaiścārhataiśca baudhāirvaiśeṣikaistathā |
anyairapi vicitraistaiḥ pāñcarātrādibhistathā
]

`v 51 [
p. 359) 214
sarvaireva ca gantavyaṃ taiḥ padaṃ pāramārthikam |
vicitraṃ deśakālotthaiḥ puramekamivādhvagaiḥ
]

`v 52 [
ajñānātparamārthasya viparītāvabodhataḥ |
kevalaṃ vivadantyete vikalpairārurukṣavaḥ
]

`v 53 [
svamārgamamiśaṃsanti vādinaścitrayā dṛśā |
vicitradeśakālotthā mārgaṃ svaṃ pathikā iva
]

`v 54 [
vicitradeśakālotthāḥ
rājasatāmasamalinārdhamalinasattvapradhānajanocitadeśakālotpannāḥ | tathāca
kālādyanusāriṇāṃ teṣāṃ svasvapakṣābhiruciriti tattatpraśaṃsā yukteti bhāvaḥ |
53 |
tairmithyā rāghava proktāḥ karmamānasacetasām |
svavikalpārpitairarthaiḥ svāḥ svā vaicitryayuktayaḥ
]

`v 55 [
yathaiva puruṣaḥ snānadānādānādikāḥ kriyāḥ |
kurvaṃstatkartṛvaicitryameti tadvadidaṃ manaḥ
]

`v 56 [
vicitrakāryavaśato nāmabhedena kartṛtā |
manaḥ saṃprocyate jīvavāsanākarmanāmabhiḥ
]

`v 57 [
cittamevedamakhilaṃ sarveṇaivānubhūyate |
acitto hi naro lokaṃ paśyannapi na paśyati
]

`v 58 [
śrutvā spṛṣṭvā ca dṛṣṭvā ca bhuktvā ghrātvā śubhāśubham |
antarharṣaṃ viṣādaṃ ca samanasko hi vindati
]

`v 59 [
āloka iva rūpāṇāmarthānāṃ kāraṇaṃ manaḥ |
badhyate baddhacitto hi muktacitto hi mucyate
]

`v 60 [
tajjaḍānāṃ paraṃ viddhi jaḍaṃ yenocyate manaḥ |
na cāvagacchati jaḍaṃ mano yasya hi cetanam
]

`v 61 [
na cetanaṃ na ca jaḍaṃ yadidaṃ protthitaṃ manaḥ |
vicitrasukhaduḥkhehaṃ jagadabhyuditaṃ tadā
]

`v 62 [
ekarūpe hi manasi saṃsāraḥ pravilīyate |
upāvilaṃ kāraṇaṃ tairbhrāntyā jagadupasthitam
]

`v 63 [
ajaḍaṃ hi mano rāma saṃsārasya na kāraṇam |
jaḍaṃ copaladharmāpi saṃsārasya na kāraṇam
]

`v 64 [
na cetanaṃ na ca jaḍaṃ tasmājjagati rāghava |
manaḥ kāraṇamarthānāṃ rūpāṇāmiva bhāsanam
]

`v 65 [
cittādṛte'nyadyadyasti tadacittasya kiṃ jagat |
sarvasya bhūtajātasya samagraṃ pravilīyate
]

`v 66 [
nānākarmavaśāveśānmano nānābhidheyatām |
ekaṃ vicitratāmeti kālo nānā yathartubhiḥ
]

`v 67 [
yadi nāmāmanaskāramahaṃkārendriyakriyāḥ |
kṣobhayanti śarīraṃ tatsantu jīvādayaḥ pare
]

`v 68 [
darśaneṣu tu ye proktā bhedā manasi tarkataḥ |
kvacitkvacidvādakarairapavādakaraiḥ kila
]

`v 69 [
te hi rāma na budhyante viśiṣyante na ca kvacit |
sarvā hi śaktayo deve vidyante sarvagā yataḥ
]

`v 70 [
yadaiva khalu śuddhāyā `note[śraddhāyā iti pāṭhaḥ] manāgapi hi
saṃvidaḥ |
jaḍeva śaktiruditā tadā vaicitryamāgatam
]

`v 71 [
ūrṇanābhādyathā tanturjāyate cetanājjaḍaḥ |
nityaprabuddhātpuruṣādbrahmaṇaḥ prakṛtistathā
]

`v 72 [
tvatprakṣe'pi tarhi tava śraddhājāḍyameva kuto na heturityāśaṅkya nāyaṃ mama
svabuddhyotprekṣitaḥ kiṃtu yathorṇanābhiḥ sṛjate gṛhṇate ca yathā
pṛthivyāmoṣadhayaḥ saṃbhavanti | yathā sataḥ puruṣātkeśalomāni
tathā'kṣarātsaṃbhavatīha viśvam ityādiśrutisiddho'yaṃ pakṣa ityāśayenāha ##-
p. 360) 215
avidyāvaśataścittabhāvanāḥ sthitimāgatāḥ |
citi paryāyaśabdā hi bhinnāste neha vādinām
]

`v 73 [
jīvo manaśca nanu buddhirahaṃkṛtiśce-
tyevaṃ prathāmupagateyamanirmalā cit |
saiṣocyate jagati cetanacittajīva-
saṃjñāgaṇena kila nāsti vivāda eṣaḥ
]