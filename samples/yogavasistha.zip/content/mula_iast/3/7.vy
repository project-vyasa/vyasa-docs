`v 1 [
saptamaḥ sargaḥ 7
śrīrāma uvāca |
ya eṣa devaḥ kathito yasmiñjñāte vimucyate |
vada kvāsau sthito brahmankathamenamahaṃ labhe | 1 |
viriñcyādijaganmūlaṃ yo devaḥ prāṅnirūpitaḥ |
nirastanikhilopādhestasya tattvamohocyate
]

`v 2 [
śrīvasiṣṭha uvāca |
ya eṣa devaḥ kathito naiṣa dūre'vatiṣṭhate |
śarīre saṃsthito nityaṃ cinmātramiti viśrutaḥ
]

`v 3 [
eṣa sarvamidaṃ viśvaṃ na viśvaṃ caiṣa sarvagaḥ |
vidyate hyeṣa evaiko na tu viśvābhidhāsti dṛk
]

`v 4 [
cinmātrameṣa śaśibhṛccinmātraṃ garuḍeśvaraḥ |
cinmātrameva tapanaścinmātraṃ kamalodbhavaḥ
]

`v 5 [
śrīrāma uvāca |
bālā api vadantyetadyadi cetanamātrakam |
jagadityeva kevātra nāma syādupadeśatā
]

`v 6 [
p. 143)
śrīvasiṣṭha uvāca |
cinmātraṃ cetanaṃ viśvamiti yajjñātavānasi |
na kiṃcideva vijñātaṃ bhavatā bhavanāśanam
]

`v 7 [
cetanaṃ rāma saṃsāro jīva eṣa paśuḥ smṛtaḥ |
etasmādeva niryānti jarāmaraṇabhītayaḥ
]

`v 8 [
paśurajño hyamūrto'pi duḥkhasyaivaiṣa bhājanam |
cetanatvāccetanīyaṃ mano'narthaḥ svayaṃ sthitaḥ
]

`v 9 [
cetyanirmuktatā yā syādacetyonmukhatāthavā |
asya sā bharitāvasthā `note[bhavitāvasthā iti pāṭhaḥ] tāṃ jñātvā
nānuśocati
]

`v 10 [
bhidyate hṛdayagranthiśchidyante sarvasaṃśayāḥ |
kṣīyante cāsya karmāṇi tasmindṛṣṭe parāvare
]

`v 11 [
tasya cetyonmukhatvaṃ tu cetyāsaṃbhavanaṃ vinā |
roddhuṃ na śakyate dṛśyaṃ cetyaṃ śāmyati vai katham
]

`v 12 [
acetyacitsvarūpaṃ yattaccāsaṃbhavanaṃ vinā |
kva svarūponmukhatvaṃ hi kevalaṃ cetyarodhataḥ
]

`v 13 [
śrīrāma uvāca |
yasmiñjīve hi vijñāte na vinaśyati saṃsṛtiḥ |
vyomarūpī paśustvajñaḥ sa brahmankutra kīdṛśaḥ
]

`v 14 [
sādhusaṃgamasacchāstraiḥ `note[bhavitāvasthā iti pāṭhaḥ]
saṃsārārṇavatārakaḥ |
dṛśyate paramātmā yaḥ sa brahmanvada kīdṛśaḥ
]

`v 15 [
śrīvasiṣṭha uvāca |
yadetaccetanaṃ jīvo `note[jīve viśīrṇe iti pāṭhaḥ] viśīrṇo janmajaṅgale
|
etamātmānamicchanti ye te'jñāḥ paṇḍitā api
]

`v 16 [
p. 144)
jīva eva hi saṃsāraścetanā duḥkhasaṃtatiḥ `note[saṃtateḥ iti pāṭhaḥ] |
asmiñjñāte na vijñātaṃ kiṃcidbhavati kutracit
]

`v 17 [
jñāyate paramātmā cedrāma duḥkhasya saṃtatiḥ |
kṣayameti viṣāveśaśāntāviva viṣūcikā
]

`v 18 [
śrīrāma uvāca |
rūpaṃ kathaya me brahmanyathāvatparamātmanaḥ |
yasmindṛṣṭe mano mohānsamagrānsaṃtariṣyati
]

`v 19 [
evaṃ samāhito rāmaḥ sargopakramapṛṣṭārthameva prāsaṅgikoktivyavahitamiti
punaḥ spaṣṭaṃ pṛcchati - rūpamiti | kāryabāhulyānmohāniti bahuvacanam |
18 |
śrīvasiṣṭha uvāca |
deśāddeśāntaraṃ dūraṃ prāptāyāḥ saṃvido vapuḥ |
nimiṣeṇaiva `note[nimeṣeṇaiva iti pāṭhaḥ] yanmadhye tadrūpaṃ
paramātmanaḥ
]

`v 20 [
atyantābhāva evāsti saṃsārasya yathāsthiteḥ `note[jagatsthiteḥ iti
pāṭhaḥ] |
yasminbodhamahāmbhodhau tadrūpaṃ paramātmanaḥ
]

`v 21 [
yathāsthiteḥ nāśādivikāramantareṇaiva svasthāne `note[svādhiṣṭhāne iti
pāṭhaḥ] mithyātvamāpannasyeti yāvat | jagatsthiteḥ `note[nimeṣeṇaiva iti
pāṭhaḥ] iti pāṭhe'pi gacchati bādhamiti jagaditi vyutpattyā ayamevārthaḥ | 20
|
draṣṭṛdṛśyakramo yatra sthito'pyastamayaṃ gataḥ |
yadanākāśamākāśaṃ tadrūpaṃ paramātmanaḥ
]

`v 22 [
aśūnyamiva yacchūnyaṃ yasminśūnyaṃ jagatsthitam |
sargaughe sati yacchūnyaṃ tadrūpaṃ paramātmanaḥ
]

`v 23 [
yanmahācinmayamapi bṛhatpāṣāṇavatsthitam |
jaḍaṃ vā jaḍamevāntastadrūpaṃ paramātmanaḥ
]

`v 24 [
sabāhyābhyantaraṃ yena sarvaṃ saṃprāpya saṃgamam |
svarūpasattāmāpnoti tadrūpaṃ paramātmanaḥ
]

`v 25 [
prakāśasya yathālokaḥ śūnyatvaṃ nabhaso yathā |
tathedaṃ saṃsthitaṃ yatra tadrūpaṃ paramātmanaḥ
]

`v 26 [
śrīrāma uvāca |
sadrūpaṃ paramātmeti kathaṃ nāma hi budhyate |
iyato'sya jagannāmno dṛśyasyāsaṃbhavaḥ katham
]

`v 27 [
śrīvasiṣṭha uvāca |
bhramasya jāgatasyāsya jātasyākāśavarṇavat |
atyantābhāvasaṃbodhe yadi rūḍhiralaṃ bhavet
]

`v 28 [
tajjñātaṃ brahmaṇo rūpaṃ bhavennānyena karmaṇā |
dṛśyātyantābhāvatastu ṛte nānyā śubhā gatiḥ
]

`v 29 [
atyantābhāvasaṃpattau dṛśyasyāsya yathā sthiteḥ |
śiṣyate paramārtho'sau budhyate jāyate tataḥ
]

`v 30 [
na vidaḥ pratibimbo'sti dṛśyābhāvādṛte kvacit |
kvacinnāpratibimbena kilādarśo'vatiṣṭhate
]

`v 31 [
p. 145)
jagannāmno'sya dṛśyasya svasattāsaṃbhavaṃ vinā |
budhyate paramaṃ tattvaṃ na kadācana kenacit
]

`v 32 [
śrīrāma uvāca |
iyato dṛśyajātasya brahmāṇḍasya jagatsthiteḥ |
mune kathamasattāsti kva meruḥ sarṣapodare
]

`v 33 [
śrīvasiṣṭha uvāca |
dināni katicidrāma yadi tiṣṭhasyakhinnadhīḥ |
sādhusaṃgamasacchāstraparamastadahaṃ kṣaṇāt
]

`v 34 [
pramārjayāmi te dṛśyaṃ bodhe mṛgajalaṃ yathā |
dṛśyābhāve draṣṭṛtā ca śāmyedbodho'vaśiṣyate
]

`v 35 [
draṣṭṛtvaṃ sati dṛśye'smindṛśyatvaṃ satyathekṣake |
ekatvaṃ sati hi dvitve dvitvaṃ caikatvayojane
]

`v 36 [
ekābhāve dvayoreva siddhirbhavati nātra hi |
dvitvaikyadraṣṭṛdṛśyatvakṣaye sadavaśiṣyate
]

`v 37 [
ahaṃtādijagaddṛśyaṃ sarvaṃ te mārjayāmyaham |
atyantābhāvasaṃvittyā manomukurato malam
]

`v 38 [
nāsato vidyate bhāvo nābhāvo vidyate sataḥ |
yattu nāsti svabhāvena kaḥ kleśastasya mārjane
]

`v 39 [
jagadādāvanutpannaṃ yaccedaṃ dṛśyate tatam |
tatsvātmanyeva vimale brahmacittvātsvabṛṃhitam
]

`v 40 [
jagannāmnā na cotpannaṃ na cāsti na ca dṛśyate |
hemnīva kaṭakāditvaṃ kimetanmārjane śramaḥ
]

`v 41 [
tathaitadvistareṇāhaṃ vakṣyāmi bahuyuktibhiḥ |
abādhitaṃ yathā tattvaṃ svayamevānubhūyate
]

`v 42 [
ādāveva hi notpannaṃ yattasyehāstitā kutaḥ |
kuto marau jalasariddvitīyendau kuto grahaḥ
]

`v 43 [
yathā vandhyāsuto nāsti yathā nāsti marau jalam |
yathā nāsti nabhoyakṣastathā `note[nabhovṛkṣaḥ iti pāṭhaḥ] nāsti
jagadbhramaḥ
]

`v 44 [
yadidaṃ dṛśyate rāma radbrahmaiva nirāmayam |
etatpurastādvakṣyāmi yuktito na giraiva ca
]

`v 45 [
yannāma yuktibhiriha pravadanti tajjñāstatrāvahelanamayuktamudārabuddhe |
yo yuktiyuktamavamatya vimūḍhabuddhiḥ
kaṣṭāgraho bhavati taṃ vidurajñameva
]