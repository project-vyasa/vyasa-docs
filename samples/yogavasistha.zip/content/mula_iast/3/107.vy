`v 1 [
p. 379) 225
saptottaraśatatamaḥ sargaḥ 107
rājovāca |
bahunātra kimuktena sotsavāvarjitāśayaḥ |
tadāprabhṛti tatrāhaṃ saṃpannaḥ puṣṭapulkasaḥ
]

`v 2 [
saptarātrotsavasyānte kramānmāsāṣṭake gate |
puṣpitā sāsya saṃpannā sthitā garbhavatī tataḥ
]

`v 3 [
prasūtā duḥkhadāṃ kanyāṃ vipadduḥkhakriyāmiva |
sā kanyā vavṛdhe śīghraṃ mūrkhacinteva pīvarī
]

`v 4 [
punaḥ prasūtā sā varṣaistribhiḥ putramaśobhanam |
anarthamiva durbuddhirāśāpāśavidhāyakam
]

`v 5 [
punaḥ sutāṃ duhitaraṃ punarapyarbhakaṃ tataḥ |
kalatravānahaṃ jāto vane jaraṭhapulkasaḥ
]

`v 6 [
tayā saha samāstatra mayā bahvyo'tivāhitāḥ |
nārake cintayā sārdhaṃ brahmaghneneva yātanāḥ
]

`v 7 [
śītavātātapakleśavivaśena vanāntare |
ciraṃ vilulitaṃ vṛddhakacchapeneva palvale
]

`v 8 [
kalatracintāhatayā dhiyā saṃdahyamānayā |
dṛṣṭāḥ kaṣṭasamārambhā diśaḥ prajvalitā iva
]

`v 9 [
kṣaumānekasamākṣīṇapaṭe ceṇḍakadhāriṇā |
kāṣṭhabhāro vane vyūḍho yo mūrtamiva duṣkṛtam
]

`v 10 [
yaukākīrṇajaratklinnagandhikaupīnavāsasā |
āśvasya dhavalīkānāṃ tale nītā ghanāḥ samāḥ
]

`v 11 [
kalatrāpūraṇotkena jarjareṇa himānilaiḥ |
hemante dardureṇeva vilīnaṃ vanakukṣiṣu
]

`v 12 [
nānākalahakallolatāpaprasaravidrutāḥ |
bāṣpavyājena nirmuktā netrābhyāṃ raktabindavaḥ
]

`v 13 [
yāminyo vipine klinne varāhāmiṣabhojanāḥ |
śilātalakuṭīkośe nītā jaladaviklavāḥ
]

`v 14 [
kāle kṣayaṃ gate rohe kālabhraghanatāṃ gate |
asauhārdena bandhūnāṃ kalahaiścāpi saṃtataiḥ
]

`v 15 [
sarvatra jātaśaṅkena kalābhimukharārbhakaiḥ |
mayā kṛpaṇacittena nītāḥ paragṛhe samāḥ
]

`v 16 [
caṇḍālīkalahodvignacaṇḍacaṇḍālatarjanaiḥ |
mukhaṃ jarjaratāṃ yātamindū rāhuradairiva
]

`v 17 [
carvitāḥ kharvitoṣṭhena dvīpīpiśitapeśayaḥ |
nārakāhṛtavikrītā nārakyo raśanā iva
]

`v 18 [
himavatkandarodgīrṇāścaṇḍā hemantavīcayaḥ |
śiśire śīkarāsāratuṣāranicayāściram
]

`v 19 [
aṅge nirambare soḍhā mṛtyumuktā iveṣavaḥ |
jarājaraṭhamūḍhena mūlāni kṣīṇabhūruhām `note[kṣīrabhūruhāṃ iti
pāṭhaḥ]
]

`v 20 [
sukṛtānāmivaikena samutkhātāni bhūriśaḥ |
śarāvakeṣ.vaṭavyāṃ ca palalaṃ pakvamādarāt
]

`v 21 [
aspṛṣṭena janairbhuktaṃ kukalatravatā mayā |
gṛhītatejaḥkṣataye bahuvaktravikāriṇā
]

`v 22 [
mārgāvikamivātmīyaṃ vikrītaṃ paṇyamanyataḥ |
prāṇyaṅgavapuṣastasya protkṛttyotkṛttya paśalaḥ
]

`v 23 [
āyasaṃpari vikrītā vindhyapakvaṇabhūmiṣu |
janmāntarasahasrotthaṃ svapāpamiva vṛddhaye
]

`v 24 [
avikīrṇamasatkīrṇaṃ caṇḍālārāmabhūmiṣu |
dṛṣṭaḥ kuddālako dṛṣṭyā saṃdhyāsnehavimuktayā
]

`v 25 [
rauravāpatiteneva tatkālasnigdhatāṃ gataḥ |
vindhyakandaragulmānāṃ bandhutvamiva gacchatā
]

`v 26 [
pulindavapuṣā yatra yuktayogaiḥ samarpitāḥ |
tarpitā laguḍāghātajitakauleyaraṃhasā `note[laguḍātkāla iti pāṭhaḥ] | 26
|
yatra yasyāṃ durdaśāyāṃ yuktayogaiḥ paramparāsaṃbandhairdaivena samarpitāḥ
putradārādayo laguḍāghātairyaṣṭitāḍanairjitakauleyaraṃhasā
nivāritaśunakopadraveṇa mayā kadannena tarpitāḥ
]

`v 27 [
p. 380) 226
putradārāḥ kadannena grāmakāndhocitena ca |
dhārāsāraraṇātpatraśuṣkatālatale niśāḥ
]

`v 28 [
nītā raṇitadantena sārdhaṃ vipinavānaraiḥ |
romabhiḥ koṭimudrodyaiḥ śītenādhyuṣitasya me
]

`v 29 [
varṣāsu muktākaṇavaddhṛtā vānalabindavaḥ |
ajājīmūtakhaṇḍārthaṃ kṣutkṣuṇṇakṣīṇakukṣiṇā
]

`v 30 [
kalatreṇa sahāṭavyāṃ kṛtaḥ kalaha ākulaḥ |
vane raṇitadantena śītakekaracakṣuṣā
]

`v 31 [
mapīmalinagātreṇa vetālasvajanāyitam |
sarittīreṣu matsyārthaṃ bhrāntaṃ vaḍiśadhāriṇā
]

`v 32 [
kalpe jagatsunāśārthaṃ kṛtānteneva pāśinā |
pītaṃ bahupavāsena sadyaḥkṛttamṛgorasaḥ
]

`v 33 [
tatkālakoṣṇaṃ rudhiraṃ mātuḥ stanapayo yathā |
śmaśānasaṃsthitānmatto raktaraktānmalāśinaḥ
]

`v 34 [
vidrutā vanavetālāścaṇḍikābhidrutā iva |
vāgurā vipine vyuptā bandhārthaṃ mṛgapakṣiṇām
]

`v 35 [
āśā iva vivṛddhyarthaṃ putradārakalatrajāḥ |
mayā māyāmayairlokāḥ sūtrajālamayaiḥ sragāḥ
]

`v 36 [
jālairjarjaratāṃ nītā diśaścāsukṛtāyuṣā |
tatrāpi dattaḥ prasaro manaso duṣkṛtodaye
]

`v 37 [
āśā prasāritā dūraṃ prāvṛṣīva taraṅgiṇī |
karabhyā iva sarpeṇa vidrutaṃ dūrato dhiyā
]

`v 38 [
dūre tyaktā dayā dehe bhujaṅgeneva kañcukam |
krauryaṃ sukhena saṃrambhaśaravarṣi ninādi ca
]

`v 39 [
aṅgīkṛtaṃ nidāghānte nabhasevāsitāmbudaḥ |
vikāsinyo kṣatāḥ kṣārā dūraṃ parihṛtā janaiḥ
]

`v 40 [
śvabhreṇeva kumañjaryaściramūḍhā mayāpadaḥ |
svakālakulakoṇāsu narakoddāmabhūmiṣu
]

`v 41 [
uptā duṣkṛtabījānāṃ muṣṭayo mohavṛṣṭayaḥ |
vāgurābhirmayā vindhyakandarasthena nirdayam
]

`v 42 [
bhūteṣviva kṛtāntena mṛgeṣu parivalgitam |
cāmarīkaṇṭhakuḍyeṣu viśrāntaśirasā mayā
]

`v 43 [
suptamastavivekena śeṣāṅgeṣviva śauriṇā |
vilolacaraṇāmbarayā sarāvollāsidhūmrayā
]

`v 44 [
mama tanvā sanīhāravindhyakacchaguhāyitam |
kṛṣṇadehena yaukāḍhyā kandhā skandhe mayā ciram
]

`v 45 [
grīṣme soḍhā caladbhūtā varāheṇa yathorvarā |
bahuśo'haṃ vanotthāgninirdagdhaprāṇimaṇḍalaḥ
]

`v 46 [
kalpāgnibhuktajagataḥ kālasyānugatiṃ gataḥ |
lobhiliṅgo yathā rogamanarthāniva durgrahaḥ |
prasūtāstatra me dārā duḥkhānyatha sukhānyapi
]

`v 47 [
nṛpālaputrakenaikatanayena tadā mayā |
nītā nīrandhradoṣeṇa ṣaṣṭiḥ kalpasamāḥ samāḥ
]

`v 48 [
upasaṃharati - nṛpāleti | ekatanayenetyatyantānaucityasūcanārthamuktam | 47
|
ākruṣṭamuddhurataraṃ ruditaṃ vipatsu
bhuktaṃ kadannamuṣitaṃ hatapakkaṇeṣu |
kālāntaraṃ bahu mayopahatena tatra
durvāsanānigaḍabandhagatena sabhyāḥ
]