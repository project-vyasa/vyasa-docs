`v 1 [
tryutaraśatatamaḥ sargaḥ 103
śrīvasiṣṭha uvāca |
parasmādutthitaṃ cetastatkallola ivārṇavāt |
sphāratāmetya bhuvanaṃ tanotīdamitastataḥ
]

`v 2 [
hrasvaṃ dīrghaṃ karotyāśu dīrghaṃ nayati kharvatām |
svatāṃ nayatyanyadalaṃ svaṃ tathaivānyatāmapi
]

`v 3 [
prādeśamātramapi yadvastubhāvanayaiva tat |
svayaṃ saṃpannayevāśu karotyadrīndrabhāsuram
]

`v 4 [
labdhapratiṣṭhaṃ paramātpadādullasitaṃ manaḥ |
nimeṣeṇaiva saṃsārānkaroti na karoti ca
]

`v 5 [
yadidaṃ dṛśyate kiṃcijjagatsthāsnu cariṣṇu ca |
sarvaṃ sarvaprakārāḍhyaṃ cittādetadupāgatam
]

`v 6 [
deśakālakriyādravyaśaktiparyākulīkṛtam |
bhāvādbhāvāntaraṃ yāti lolatvānnaṭavanmanaḥ
]

`v 7 [
sadasattāṃ nayatyāśu sattāṃ vā sannayatyalam |
tādṛśānyeva cādatte sukhaduḥkhāni bhāvitam
]

`v 8 [
p. 372) 221
yadāptaṃ svayamādatte yathaiva cañcalaṃ manaḥ |
hastapādādisaṃghātastadā prayatate tathā
]

`v 9 [
tataḥ saiva kriyā cittasamāhitaphalāphalam |
kṣaṇātprayacchati latā kālasikteva tādṛśam
]

`v 10 [
citrāṃ krīḍanakaśreṇīṃ yathā paṅkādgṛhe śiśuḥ |
karotyevaṃ mano rāma vikalpaṃ kurute jagat
]

`v 11 [
manaḥsarvajanakrīḍānṛjambālalaveṣvataḥ |
kimetaddhi padārtheṣu rūḍhaṃ jagati kalpyate
]

`v 12 [
karotyṛtukaraḥ kālo yathā rūpānyathā taroḥ |
cittamevaṃ padārthānāmeṣāmevānyatāmiva
]

`v 13 [
manorathe tathā svapne saṃkalpakalanāsu ca |
goṣpadaṃ yojanavyūhaḥ svāsu līlāsu cetasaḥ
]

`v 14 [
kalpaṃ kṣaṇīkarotyantaḥ kṣaṇaṃ nayati kalpatām |
manastadāyattamato deśakālakramaṃ viduḥ
]

`v 15 [
tīvramandatvasaṃvegādbahutvālpatvabhedataḥ |
vilambanena ca ciraṃ natu śaktimaśaktitaḥ
]

`v 16 [
nanu yadi manaḥ sarvanirmāṇasamartha tarhi kathamidānīmasmākaṃ
sarvasargāśaktistatrāha - tīvreti | rajoguṇotkarṣe tīvratā tamasa utkarṣe tu
mandateti saṃvegabhedāt āhāropacayādupacaye bahutvamapacaye'lpatvamiti
bhedastattadvastusargānukūlopasāsanādivilambanena ca prāptasargāśaktito na
manaso vāstavīṃ sarvasargaśaktimapahātuṃ śaknuma ityadhyāhṛtya yojyam | 15
|
vyāmohasaṃbhramānarthadeśakālagamāgamāḥ |
cetasaḥ prabhavantyete pādapādiva pallavāḥ
]

`v 17 [
jalameva yathāmbhodhirauṣṇyameva yathānalaḥ |
tathā vividhasaṃrambhaḥ saṃsāraścittameva vā
]

`v 18 [
sakartṛkarmakaraṇaṃ yadidaṃ cetyamāgatam |
draṣṭṛdarśanadṛśyāḍhyaṃ tatsarvaṃ cittameva ca
]

`v 19 [
cittaṃ jaganti bhuvanāni vanāntarāṇi
saṃlakṣyate svayamupāgatamātmabhedaiḥ |
keyūramaulikaṭakaiśca lasatsvarūpaṃ
tyaktvaiva kāñcanadhiyeva janena hema
]