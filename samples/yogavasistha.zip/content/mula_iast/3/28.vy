`v 1 [
aṣṭāviṃśaḥ sargaḥ  28
śrīrāma uvāca |
vajrāṅgasārādbrahmāṇḍakuḍyānnibiḍamaṇḍalāt |
koṭiyojanasaṃpuṣṭātkathaṃ te nirgate'bale
]

`v 2 [
śrīvasiṣṭha uvāca |
kva brahmāṇḍaṃ kva tadbhittiḥ kvātrāsau vajrasāratā |
kilāvaśyaṃ sthite devyāvantaḥpuravarāmbare
]

`v 3 [
tasminneva girigrāme tasminnevālayāmbare |
brāhmaṇaḥ sa vasiṣṭhākhya āsvādayati rājatām
]

`v 4 [
tameva maṇḍapākāśakoṇakaṃ śūnyamātrakam |
catuḥsamudraparyantaṃ bhūtalaṃ so'nubhūtavān
]

`v 5 [
ākāśātmani bhūpīṭhaṃ tasmiṃstadrājapattanam |
rājasadmānubhavati sa ca sā cāpyarundhatī
]

`v 6 [
līlābhidhānā sa jātā tayā ca jñaptirarcitā |
jñaptyā saha samullaṅghya khamāścaryamanoharam
]

`v 7 [
prādeśamātre `note[pradeśamātre iti pāṭhaḥ] nabhasi sā tatraiva
gṛhodare |
brahmāṇḍāntaramāsādya girigrāmakamandire
]

`v 8 [
brahmāṇḍātparinirgatya svagṛhe sthitimāyayau |
svapnātsvapnāntaraṃ prāpya yathā talpagataḥ pumān
]

`v 9 [
pratibhāmātramevaitatsarvamākāśamātrakam |
na brahmāṇḍaṃ na saṃsāro na kuḍyādi na dūratā
]

`v 10 [
svacittameva kacati tayostādṛṅmanoharam |
vāsanāmātrasollekhaṃ kva brahmāṇḍaṃ kva saṃsṛtiḥ
]

`v 11 [
nirāvaraṇamevedaṃ jñaptyākāśamanantakam |
kiṃcitsvacittenonnītaṃ spandayuktyeva mārutaḥ
]

`v 12 [
cidākāśamajaṃ śāntaṃ sarvatraiva hi sarvadā |
cittvājjagadivābhāti svayamevātmanātmani
]

`v 13 [
yena buddhaṃ tu tasyaitadākāśādapi śūnyakam |
na buddhaṃ yena tasyaitadvarjasārācalopamam
]

`v 14 [
gṛha eva yathā svapne nagaraṃ bhāti bhāsuram |
tathaitadasadevāntaściddhātau bhāti bhāsvaram
]

`v 15 [
p. 198)
yatha marau jalaṃ buddhaṃ kaṭakatvaṃ ca hemani |
asatsadiva bhātīdaṃ tathā dṛśyatvamātmani
]

`v 16 [
evamākathayantyau te lalane lalitākṛtī |
gṛhānniryayaturbāhyaṃ cārucaṃkramaṇakramaiḥ
]

`v 17 [
ādṛśye grāmalokena prekṣamāṇe purogirim |
cumbitākāśakuharaṃ saṃspṛṣṭādityamaṇḍalam
]

`v 18 [
nānāvarṇākhilotphullavicitravananirmalam |
nānānirjharanirhrādakūjadvanavihaṃgamam
]

`v 19 [
vicitramañjarīpuñjapiñjarāmbudamaṇḍalam |
svabhramacchagulucchāgraviśrāntakhagasārasam
]

`v 20 [
sāravañjulavistāraguptākhilasarittaṭam |
asamāptaśilāśvabhralatāvartanamārutam
]

`v 21 [
puṣpāgrapihitākāśakośakuḍyakavāridam |
pataddīrghasaritsrotaḥsphuranmuktākalāpakam
]

`v 22 [
puṣpāṇyagre yeṣaṃ taiḥ śikharadrumaiḥ pihitā ākāśakośasya kuḍyakāḥ
kuḍyapratikṛtibhūtā vāridā yasya | saritsrotāṃsyeva sphuranmuktāmālā yasya |
21 |
caladvṛkṣavanavyūhavātavellisarittaṭam |
nānāvanākulopāntacchāyāsatataśītalam
]

`v 23 [
atha te lalane tatra tadā dadṛśatuḥ svayam |
taṃ girigrāmakaṃ vyomnaḥ svargakhaṇḍamiva cyutam
]

`v 24 [
raṭatpraṇālīpaṭalaṃ pūrṇapuṣkariṇīgaṇam |
dvijaiḥ kucakucaiḥ kūjatsvalīlāśvabhrakacchakam
]

`v 25 [
gacchadgovṛndahuṃkārakarālākhilakuñjakam |
kuñjagulmakakhaṇḍāḍhyaṃ sacchāyaghanaśādvalam
]

`v 26 [
duṣpraveśārkakiraṇaṃ dṛśannīhāradhūsaram |
udagramañjarīpuñjajaṭālaṃ viśikhāntaram
]

`v 27 [
dṛṣadbhiḥ śilābhirnīhāraiśca dhūsaraṃ bhasmoddhūlitamiva |
unnamrāgrairmañjarīpuñjairjaṭā iva lambīni śikhāntarāṇi katipayaśikhā yasya |
26 |
śilākuharavāḥsphālaproccalanmuktanirjharaiḥ `note[ravāḥsphāra iti
pāṭhaḥ] |
smāritācalanirdhūtakṣīrodakajalaśriyam
]

`v 28 [
phalamālyamahābhārabhāsurairajiradrumaiḥ |
ānīya puṣpasaṃbhāraṃ tiṣṭhadbhiriva saṃkulam
]

`v 29 [
tarattaraṅgajhāṃkārakārimārutakampitaiḥ |
kīrṇapu.pasamāvṛṣṭaṃ drumairapi rasākulaiḥ
]

`v 30 [
aśaṅkitaśilākūṭasravadabbinduṭaṃkṛtaiḥ |
kiṃcitkṛtaravaṃ guptairaśaṅkaiḥ śaṅkitaiḥ khagaiḥ
]

`v 31 [
utphālalaharīśrāntasīkarāsvādanākualaih |
nadyāmuḍuparāvartavṛttibhirvihagairvṛtam
]

`v 32 [
uttālatālaviśrāntakākālokanaśaṅkitaiḥ |
bālaiḥ pragopitāmikṣākhaṇḍaṃ jīrṇasvabhuktakaiḥ
]

`v 33 [
puṣpaśekharasaṃbhāravasanagrāmabālakam |
kharjūranimbajambīragahanopāntaśītalam
]

`v 34 [
kṣaumāgrahastāmbarayā mañjarīpūrṇakarṇayā |
kṣutkṣīṇayākrāntarathyaṃ grāmakīṭakakāntayā
]

`v 35 [
sarittaraṅgasaṃghaṭṭasaṃrāvāśrutasaṃkatham |
karmajāḍyaghanatrāsavāñchitaikāntasaṃsthitam
]

`v 36 [
dadhiliptāsyahastāṃsaiḥ snighapuṣpalatādharaiḥ |
nagnairgomayapaṅkāṅkairbālairākulacatvaram
]

`v 37 [
p. 199)
tīraśādvalavallīnāṃ dolāndolanakāribhiḥ |
taraṅgairvāhyamānasya lekhikāṅkitasaikatam
]

`v 38 [
dadhikṣīraghanāmodamattamantharamakṣikam |
kāmabhuktārthatodbāṣpajarjarābalabālakam
]

`v 39 [
gomayāsiktavalayakaranārī kṛtakrudham |
dhammillavalanāvyagratrastastrīvihasajjanam
]

`v 40 [
gomayāsiktavalayakaratvāditaranārīṣu kṛtakrodhaṃ yathā syāttathā
muktadhammillavalanāsu vyagrāstrāstāśca striyo dṛṣṭvā vihasanto janā yatra |
39 |
dāntapuṣpacchadotsannapatatkakudavāyasam |
gṛharathyāgaṇadvārakīrṇakrūrakuraṇṭakam
]

`v 41 [
gṛhapārśvasthitaśvabhrakuñjaiḥ kusumitaprabhaiḥ |
pratyahaṃ prātarāgulpamākīrṇakusumājiram
]

`v 42 [
caraccamarasāraṅgajālajaṅgalakhaṇḍakam `note[khaṇḍakaiḥ iti
pāṭhaḥ] |
guñjānikuñjasaṃjātaśaṣpasuptamṛgārbhakam
]

`v 43 [
ekāntasuptavatsaikakarṇaspandāstamakṣikam |
gopocchiṣṭīkṛtadadhisvasṛkkispandimakṣikam
]

`v 44 [
samastasadmasaṃkṣīṇamakṣikākṣiptamākṣikam |
phullāśokadrumodyānakṛtalākṣikamandiram
]

`v 45 [
sīkarāsāramarutā nityārdravikacadrumam |
kadambamukulaprotasamastacchādanatṛṇam
]

`v 46 [
nityārdratvādeva vikacāḥ protphullāḥ | samasteti viśeṣaṇamatiśayoktyartham | 45
|
pratikṛttalatāphullaketakotkarapāṇḍuram |
vahatprāṇālapaṭalīraṇadgurugurāravam
]

`v 47 [
vātāyanaguhāniryatsaudhaviśrāntavāridam |
pūrṇapuṣkariṇīpaṅkipūrṇarājapṛthūttaram
]

`v 48 [
nīrandhraviṭapicchāyāśītalāmalaśādvalam |
sarvaśaṣpāgravārbindupratibimbitatārakam
]

`v 49 [
anāratapatatphullahimavarṣasitālayam |
vicitramañjarīpuṣpapatrasatphalapādapam
]

`v 50 [
gṛhakakṣāntarālīnameghasuptaciraṇṭikam |
saudhasthameghavidyudbhiranādeyapradīpakam
]

`v 51 [
suptāściraṇṭikāḥ suvāsinyo yatra | anādeyāḥ anyataḥ kāryasiddheranupādeyāḥ |
50 |
kandarānilabhāṃkāraghanaghuṃghumamaṇḍapam |
caraccakorahārītahariṇīhārimandiram
]

`v 52 [
ghanāḥ pratidhvanibhirnibiḍitā ghuṃghumā yeṣu tathāvidhā maṇḍapā yatra |
ghanā iva ghuṃghumāḥ garjanto vā cakorahārītau pakṣibhedau | hārīṇi sundarāṇi |
51 |
unnidrakandalodvāntamāṃsalāmodamantharaiḥ |
marudbhirmandamāyātumārabdhairlolapallavam
]

`v 53 [
lāvakālāpalīlāyāmālīnalalanāgaṇam |
kokakokilakākolakolāhalasamākulam
]

`v 54 [
śālatālatamālābjanīlatatphalamālinam |
vallīvalayavinyāsavilāsavalitadrumam
]

`v 55 [
ālolapallavalatāvalitāyanānā-
mutphullakandalaśilīndhrasugandhitānām |
tālītamāladalatāṇḍavamaṇḍapānā-
mārāmaphullakusumadrumaśītalānām
]

`v 56 [
sārāvavāricalanākulagokulānā-
mānīlasasyakusumasthalaśobhitānām |
tīradrumaprakaraguptasaridrayāṇāṃ
nīrandhrapuṣpitalatāgravitānakānām
]

`v 57 [
p. 200)
udyānakundamakarandasugandhitānāṃ
gandhāndhaṣaṭpadakulāntaritāmbujānām |
saundaryatarjitapurandaramandirāṇāṃ
rājīvarājirajasāruṇitāmbarāṇām
]

`v 58 [
raṃhovahadgirinadīravaghargharāṇāṃ
kundāvadātajaladadyutibhāsurāṇām |
saudhasthitollasitaphullalatālayānāṃ
līlāvalolakalakaṇṭhavihaṅgamānām
]

`v 59 [
ullāsikausumadalāstaraṇasthayūnā-`note[dalātaraṇastha iti pāṭhaḥ]
māpādamāvalitamālyavilāsinīnām |
sarvatra sundaranavāṅkuradanturāṇāṃ
śobhollasadvaralatākulamārgaṇānām
]

`v 60 [
saṃjātakomalalatotpalasaṃkulānāṃ
tiṣṭhatpayodapaṭasaṃvalitālayānām |
nīhārahāraharitasthalaviśrutānāṃ
saudhasthameghataḍidākulitāṅganānām
]

`v 61 [
nīlotpalollasitasaurabhasundarāṇāṃ
huṃkārahāriharitonmukhagokulānām |
viśrabdhamugdhamṛgasāragṛhājirāṇā-
munnṛtyabarhighanasīkaranirjharāṇām
]

`v 62 [
saugandhyamattapavanāhataviklavānāṃ
vaprauṣadhijvalanavismṛtadīpakānām |
kolāhalākulakulāyakulākulānāṃ
kulyākulākalakalāśrutasaṃkathānām
]

`v 63 [
muktāphalaprakarasundarabindupāta-
śītākhiladrumalatātṛṇapallavānām |
lakṣmīmanastamitapuṣpavikāsabhājāṃ
śaknoti kaḥ kalayituṃ girimandirāṇām
]