`v 1 [
p. 290) 178
ṣaṭṣaṣṭitamaḥ sargaḥ 66
śrīvasiṣṭha uvāca |
evamekaṃ paraṃ vastu rāma nānātvametyalam |
nānātvamiva saṃjātaṃ dīpāddīpaśataṃ yathā
]

`v 2 [
yathābhūtamasadrūpamātmānaṃ yadi paśyati |
vicāryate'ntastadanubhāvahīnaṃ na śocati
]

`v 3 [
cittamātraṃ narastasmingate śāntamidaṃ jagat |
upānadrūḍhapādasya nanu carmāstṛtaiva bhūḥ
]

`v 4 [
patramātrādṛte nānyatkadalyā vidyate yathā |
bhramamātrādṛte nānyajjagato vidyate tathā
]

`v 5 [
jāyate bālatāmeti yauvanaṃ vārdhakaṃ tataḥ |
mṛtiṃ svargaṃ ca narakaṃ bhramācceto hi nṛtyati
]

`v 6 [
vicitrabudbudollāse svātmano vyatirekiṇi |
yathā surāyāḥ sāmarthyaṃ tathā cittasya saṃsṛtau
]

`v 7 [
yathā dvitvaṃ śaśāṅkādau paśyatyakṣimalāvilam |
ciccetanakalākrāntā tathaiva paramātmani
]

`v 8 [
yathā madavaśādbhrāntānkṣībaḥ paśyati pādapān |
tathā cetanavikṣubdhānsaṃsārāṃścitprapaśyati
]

`v 9 [
yathā līlābhramādbālāḥ kumbhakṛccakravajjagat |
bhrāntaṃ paśyanti cittāttu viddhi dṛśyaṃ tathaiva hi
]

`v 10 [
yadā ciccetati dvitvaṃ tadā dvaitaikyavibhramaḥ |
yadā na cetati dvaitaṃ tadā dvaitaikyayoḥ kṣayaḥ
]

`v 11 [
yaccetyate taditaradvyatiriktaṃ cito'sti na |
kiṃcinnāstīti saṃśāntyā citaḥ śāmyati cetanaṃ
]

`v 12 [
cidghanenaikatāmetya yadā tiṣṭhati niścalaḥ |
śāmyanvyavaharanvāpi tadā saṃśānta ucyate
]

`v 13 [
jīvanmuktastarhi kadā bhavati tatrāha - cidghaneneti | śāmyan samādhilīnaḥ |
12 |
tanvī cetayate cetyaṃ ghanā cinnāṅga cetati |
alpakṣībaḥ kṣobhameti ghanakṣībo hi śāmyati
]

`v 14 [
cidghanaikaprapātasya rūḍhasya parame pade |
nairātmyaśūnyavedyādyaiḥ paryāyaiḥ kathanaṃ bhavet
]

`v 15 [
ciccetanena cetyatvametyevaṃ paśyati bhramam |
jāto jīvāmi paśyāmi saṃsarāmityasanmayam
]

`v 16 [
svabhāvādvyatiriktaṃ tu na cittasyāsti cetanam |
spandādṛte yathā vāyorantaḥ kiṃ nāma cetyate
]

`v 17 [
p. 291) 178
cetyatvaṃ saṃbhavatyevaṃ kiṃcidyaccetyate citā |
rajjusarpabhramābhāsaṃ tamavidyābhramaṃ viduḥ
]

`v 18 [
saṃvinmātracikitsye'sminvyādhau saṃsāranāmani |
cittamātraparispande saṃrambho na ca kiṃcana
]

`v 19 [
yadi sarvaṃ parityajya tiṣṭhasyutkrāntavāsanaḥ |
amunaiva nimeṣeṇa tanmukto'si na saṃśayaḥ
]

`v 20 [
yathā rajjvāṃ bhujaṅgābhā vinaśyatyeva vīkṣaṇāt |
saṃvinmātravivartena naśyatyeva hi saṃsṛtiḥ
]

`v 21 [
saṃvinmātrasya vivartaḥ pratyaṅmukhatayā parāvṛttya svatattvadarśanaṃ tena |
20 |
yatrābhilāṣastannūnaṃ saṃtyajya sthīyate yadi |
prāpta evāṅga tanmokṣaḥ kimetāvati duṣkaram
]

`v 22 [
api prāṇāṃstṛṇamiva jayantīha mahāśayāḥ |
yatrābhilāṣastanmātratyāge kṛpaṇatā katham
]

`v 23 [
yatrābhilāṣastattyaktvā cetasā niravagraham |
prāptaṃ karmendriyairmṛhṇaṃstyajannaṣṭaṃ ca tiṣṭha bhoḥ
]

`v 24 [
yathā karatale bilvaṃ yathā vā parvataḥ puraḥ |
pratyakṣameva tasyālamajatvaṃ paramātmanaḥ
]

`v 25 [
ātmaiva bhāti jagadityuditastaraṅgaiḥ
kalpānta eka iva vāridhiraprameyaḥ |
jñātaḥ sa eva hi dadāti vimokṣasiddhiṃ
tvajñāta eva manase cirabandhanāya
]