`v 1 [
ṣaṭsaptatitamaḥ sargaḥ 76
śrīvasiṣṭha uvāca |
athābhavadasau sūcī karkaṭīrākṣasī punaḥ |
sūkṣmaiva sthaulyamāyātā meghalekheva vārṣikī
]

`v 2 [
nijamākāśamāsādya kiṃcitpramuditā satī |
bṛhadrākṣasabhāvaṃ tadbodhātkañcukavajjahau
]

`v 3 [
p. 314) 191
tatraiva dhyāyatī tasthau baddhapadmāsanasthitiḥ |
vyālambya saṃvidaṃ śuddhāṃ saṃsthitā girikūṭavat
]

`v 4 [
atha sā māsaṣaṭkena dhyānādbodhamupāgatā |
mahājaladanādena prāvṛṣīva śikhaṇḍinī
]

`v 5 [
mahājaladanādena bodhaṃ samādhivyutthānam | śikhaṇḍinīpakṣe kāmodbodham |
4 |
prabuddhā sā bahirvṛttirbabhūva kṣutparāyaṇā |
yāvaddehaṃ svabhāvo'sya dehasya na nivartate
]

`v 6 [
asya dehasya yāvaddehaṃ yāvadavasthānaṃ tāvatkṣudhādisvabhāvo na nivartate | 5
|
atha sā kiṃ grasa iti cintayāmāsa cintayā |
bhoktavyaḥ parajīvaśca nyāyena na vinā mayā
]

`v 7 [
yadāryagarhitaṃ yadvā nyāyena na samarjitam |
tasmādgrāsādvaraṃ manye maraṇaṃ dehināmidam
]

`v 8 [
yadi dehaṃ tyajāmīdaṃ tannyāyopārjitaṃ vinā |
na kiṃcidasti nirnyāyaṃ bhukto'rtho hi garāyate
]

`v 9 [
yatra lokakramaprāptaṃ tena bhuktena kiṃ bhavet |
na jīvitena no mṛtyā kiṃcitkāraṇamasti me
]

`v 10 [
manomātramahaṃ hyāsaṃ dehādibhramabhūṣaṇam |
tacchāntaṃ svāvabodhena dehādehadṛśau kutaḥ
]

`v 11 [
śrīvasiṣṭha uvāca |
evaṃ sthitā maunavatī śuśrāva gaganādgiram |
rakṣaḥsvarūpasaṃtyāgatuṣṭenoktāṃ nabhasvatā
]

`v 12 [
gaccha karkaṭi mūḍhāṃstvaṃ jñānenāśvavabodhaya |
mūḍhottāraṇameveha svabhāvo mahatāmiti
]

`v 13 [
bodhyamāno bhavatyāpi yo na bodhamupaiṣyati |
svanāśāyaiva jāto'sau nyāyyo grāso bhavettava
]

`v 14 [
śrutvetyanugṛhītāsmi tvayetyuktavatī śanaiḥ |
uttasthau śailaśikharātkramādavaruroha ca
]

`v 15 [
adhityakāmatītyāśu gatvā copatyakātaṭān |
viveśa śailapādasthaṃ kirātajanamaṇḍalam
]

`v 16 [
vahnannapaśulokaughadravyaśaṣpauṣadhāmiṣam |
anantamūlapānānnamṛgakīṭakhagādikam `note[mūlapānānneti pāṭhe'nneti
paunaruktyam pāṭhāntare tu mūlapā vṛkṣāḥ | adantā dantarahitāḥ
prāṇiviśeṣāḥ | anantamūlapādantā iti pāṭhaḥ]
]

`v 17 [
pracalitavalitāñjanācalābhā
himagiripādaniveśitaṃ sudeśam |
tadanugatavatī niśācarī sā
niśi sughanāndhatamisramārgabhūmau
]