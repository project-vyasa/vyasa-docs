`v 1 [
pañcamaḥ sargaḥ 5
śrīrāma uvāca |
bhagavanmuniśārdūla kimiveha manobhrame |
vidyate kathamutpannaṃ mano māyāmayaṃ kutaḥ
]

`v 2 [
utpattimādāviti me samāsena vada prabho |
pravakṣyasi tataḥ śiṣṭaṃ vaktavyaṃ vadatāṃ vara
]

`v 3 [
p. 140)
śrīvasiṣṭha uvāca |
mahāpralayasaṃpattāvasatāṃ samupāgate |
aśeṣadṛśyasargādau śāntamevāvaśiṣyate
]

`v 4 [
āste'nastamito bhāsvānajo devo nirāmayaḥ |
sarvadā sarvakṛtsarvaḥ paramātmā maheśvaraḥ
]

`v 5 [
yato vāco nivartante yo muktairavagamyate |
yasya cātmādikāḥ saṃjñāḥ kalpitā na svabhāvajāḥ
]

`v 6 [
yaḥ pumānsāṃkhyadṛṣṭīnāṃ brahma vedāntavādinām |
vijñānamātraṃ vijñānavidāmekāntanirmalam
]

`v 7 [
yaḥ śūnyavādināṃ śūnyo bhāsako yo'rkatejasām |
vaktā mantā ṛtaṃ bhoktā draṣṭā kartā sadaiva saḥ
]

`v 8 [
sannapyasadyo jagati yo dehastho'pi dūragaḥ |
citprakāśo hyayaṃ yasmādāloka iva bhāsvataḥ
]

`v 9 [
yasmādviṣṇvādayo devāḥ sūryādiva marīcayaḥ |
yasmājjagantyanantāni budbudā jaladheriva
]

`v 10 [
yaṃ yānti dṛśyavṛndāni payāṃsīva mahārṇavam |
ya ātmānaṃ padārthaṃ ca prakāśayati dīpavat
]

`v 11 [
yānti pralayenāpiyanti | tasyaiva svaprakāśatvātsvaparaprathānirvāhakatvamāha ##-
ya ākāśe śarīre ca dṛṣatsvapsu latāsu ca |
pāṃsuṣvadriṣu vāteṣu pātāleṣu ca saṃsthitaḥ
]

`v 12 [
yaḥ plāvayati saṃrabdhaṃ puryaṣṭakamitastataḥ |
yena mūkīkṛtā mūḍhāḥ śilā dhyānamivāsthitāḥ
]

`v 13 [
vyoma yena kṛtaṃ śūnyaṃ śailā yena ghanīkṛtāḥ |
āpo drutāḥ kṛtā yena dīpo yasya vaśo raviḥ
]

`v 14 [
prasaranti yataścitrāḥ saṃsārāsāravṛṣṭayaḥ `note[dṛṣṭaya iti
pāṭhaḥ] |
akṣayāmṛtasaṃpūrṇādambhodādiva vṛṣṭayaḥ
]

`v 15 [
āvirbhāvatirobhāvamayāstribhuvanormayaḥ |
sphurantyatitate yasminmarāviva marīcayaḥ
]

`v 16 [
nāśarūpo vināśātmā yo'ntaḥsthaḥ sarvajantuṣu |
gupto yo'pyatirikto'pi sarvabhāveṣu saṃsthitaḥ
]

`v 17 [
prakṛtivratatirvyomni jātā brahmāṇḍasatphalā |
cittamūlendriyadalā yena nṛtyati vāyunā
]

`v 18 [
yaścinmaṇiḥ prakacati pratidehasamudgake |
yasminnindau sphurantyetā jagajjālamarīcayaḥ
]

`v 19 [
praśānte cidghane yasminphurantyamṛtavarṣiṇi |
dhārājalāni bhūtāni sṛṣṭayastaḍitaḥ sphuṭāḥ
]

`v 20 [
camatkurvanti vastūni yadālokatayā mithaḥ |
asajjātamasadyena yena satsattvamāgatam
]

`v 21 [
calatīdamanicchasya kāyo yo yasya saṃnidhau |
jaḍaṃ paramaraktasya śāntamātmani tiṣṭhataḥ
]

`v 22 [
niyatirdeśakālau ca calanaṃ spandanaṃ kriyā |
iti yena gatāḥ sattāṃ sarvasattātigāminā
]

`v 23 [
p. 141)
śuddhasaṃvinmayatvādyaḥ khaṃ bhavedvyomacintayā |
padārthacintayārthatvamiva tiṣṭhatyadhiṣṭhitaḥ
]

`v 24 [
kurvannapīha jagatāṃ mahatāmananta-
vṛndaṃ na kiṃcana karoti na kāścanāpi |
svātmanyanastamayasaṃvidi nirvikāre
tyaktodayasthitimati sthita eka eva
]