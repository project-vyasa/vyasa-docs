`v 1 [
ekonanavatitamaḥ sargaḥ 89
bhānuruvāca |
mano hi jagatāṃ kartṛ mano hi puruṣaḥ paraḥ |
manaḥkṛtaṃ kṛtaṃ loke na śarīrakṛtaṃ kṛtam
]

`v 2 [
sāmānyabrāhmaṇā bhūtvā manobhāvanayā kila |
aindavā brahmatāṃ yātā manasaḥ paśya śaktatām
]

`v 3 [
manasā bhāvyamāno hi dehatāṃ yāti dehakaḥ |
dehabhāvanayā'yukto dehadharmairna bādhyate
]

`v 4 [
bāhyadṛṣṭirhi niyataṃ sukhaduḥkhādi vindati |
nāntarmukhatayā yogī dehe vetti priyāpriye
]

`v 5 [
manaḥkāraṇakaṃ tasmājjagadvividhavibhramam |
indrasyāhalyayā sārdhaṃ vṛttānto'tra nidarśanam
]

`v 6 [
śrībrahmovāca |
kāhalyā bhagavanbhāno ko vātrendrastamonuda |
yayorudantaśravaṇe pāvanī dṛṣṭireti hi
]

`v 7 [
bhānuruvāca |
śrūyate hi purā deva māgadheṣu mahīpatiḥ |
indradyumna iti khyāta indradyumna ivāparaḥ
]

`v 8 [
tasyendubimbapratimā bhāryā kamalalocanā |
ahalyā nāma tatrāsīcchaśāṅkasyeva rohiṇī
]

`v 9 [
tasminneva pure ṣiḍgaḥ ṣiḍgaprakaraśekharaḥ |
indranāmā paraḥ kaddhiścīmānviprakumārakaḥ
]

`v 10 [
ahalyā pūrvamindrasya babhūveṣṭetyahalyayā |
śrutaṃ rājamahiṣyātha kathāprastāvataḥ kvacit
]

`v 11 [
ākarṇyaivamahalyā sā babhūvendrānurāgiṇī |
ahalyāṃ māṃ sa no kasmātsakto'bhyetītyathotsukā
]

`v 12 [
mṛṇālabhārakadalīpallavāstaraṇeṣu sā |
atapyata bhṛśaṃ bālā latā lūnā vaneṣviva
]

`v 13 [
khedamāpa samagrāsu tāsu bhūpavibhūtiṣu |
matsī nidāghataptāsu parilolā sthalīṣviva
]

`v 14 [
ayamindro'yamindraścetyevaṃ jātapralāpayā |
lajjāpi hi tayā tyaktā vaivaśyamanuyātayā
]

`v 15 [
ityārtayā ghanasnehamatha tasyā vayasyayā |
uktaṃ tayā priye'vighnamindramabhyānayāmyaham
]

`v 16 [
iṣṭaṃ tavānayāmīti śrutvā vikasitekṣaṇā |
papāta pādayoḥ sakhyā nalinyā nalinī yathā
]

`v 17 [
tataḥ prayāte divase samāyāte niśāgame |
sā vayasyā tamindrākhyaṃ yayau dvijakumārakam
]

`v 18 [
bodhayitvā yathāyuktaṃ sā tamindramathāṅganā |
ahalyānikaṭaṃ rātryāmānayāmāsa satvaram
]

`v 19 [
tataḥ sā tena ṣiḍgena sahendreṇa ratiṃ yayau |
kasmiṃścitsadane gupte bahumālyavilepanā
]

`v 20 [
hārāṅgadamanojñena taruṇī tena sā tadā |
ratenāvarjitā vallī rasena `note[ratena iti pāṭhaḥ] madhunā yathā
]

`v 21 [
tatastadanuraktā sā paśyantī tanmayaṃ jagat |
na samastaguṇākīrṇaṃ bhartāraṃ bahvamanyata
]

`v 22 [
kenacittvatha kālena tasyā indrānurāgitā |
sā jñātā rājasiṃhena tanmukhavyomacandrikā
]

`v 23 [
p. 343) 206
indraṃ dhyāyati sā yāvattāvattasyā virājate |
mukhaṃ pūrṇena candreṇa prabuddhamiva kairavam
]

`v 24 [
indro'pi ca tadāsaktasamastakaraṇākulaḥ |
na tiṣṭhati kṣaṇamaho tayā virahitaḥ kvacit
]

`v 25 [
athātisughanasnehanirāvaraṇaceṣṭayoḥ |
tayoranayavṛttānto rājñākarṇi kaṭuvyathaḥ
]

`v 26 [
evamanyonyamāsaktaṃ bhāvamālakṣya bhūpatiḥ |
cakāra bahubhirdaṇḍaiḥ sa dvayoratha śāsanam
]

`v 27 [
tāvubhāvapi saṃtyaktau hemante salilāśaye |
tuṣṭau jahasatustatra na khedaṃ samupāgatau
]

`v 28 [
apṛcchata tato rājā khinnau stho na tu durmatī |
tāvūcaturmahīpālaṃ jalāśayasamuddhṛtau
]

`v 29 [
saṃsmṛtyāvāmihānyonyamukhakāntimaninditām |
ātmānaṃ na vijānīvo rūḍhabhāvaṃ parasparam
]

`v 30 [
śāsaneṣu ca yatsaṅgo niḥśaṅkastena harṣitau |
muhyāvo na mahīpāla svāṅgairapi vikartitaiḥ
]

`v 31 [
tato bhrāṣṭre parikṣptāvakhinnāvevameva tau |
ūcaturmuditātmānāvanyonyasmṛtiharṣitau
]

`v 32 [
grathitau gajapādeṣu na khinnāveva saṃsthitau |
evamevocaturbhūpamanyonyasmṛtiharṣitau
]

`v 33 [
kaśāhatāvakhinnau tāvevameva kilocatuḥ |
anyasmācchāsanādrājñā kalpitācca punaḥ punaḥ
]

`v 34 [
uddhṛtāvūcatuḥ pṛṣṭau tamevārthaṃ punaḥ punaḥ |
uvācendro mahīpālaṃ jaganme dayitāmayam
]

`v 35 [
na śātanāni duḥkhāni bādhante kiṃcideva me |
asyāścaiva jagadrājansarvaṃ manmayameva ca
]

`v 36 [
tenānyaśāsanādduḥkhaṃ kiṃcideva na vidyate |
manomātramahaṃ rājan mano hi puruṣaḥ smṛtaḥ
]

`v 37 [
prapañcamātramevāyaṃ deho dṛśyata eva hi |
samakālaprayuktena sahasā daṇḍarāśinā
]

`v 38 [
vīraṃ mano bhedayituṃ manāgapi na śakyate |
kā nāma tā mahārāja kīdṛśyaḥ kasya śaktayaḥ
]

`v 39 [
yābhirmanāṃsi bhidyante dṛṣṭaniścayavantyapi |
vṛddhimāyātu vā deho yātu vā viśarārutām
]

`v 40 [
bhāvitārthābhipatitaṃ manastiṣṭhati pūrvavat |
iṣṭe'rthe ciramāviṣṭaṃ dadhānaṃ tatsthitaṃ `note[tadgataṃ manaḥ iti
pāṭhaḥ] manaḥ
]

`v 41 [
bhāvābhāvāḥ śarīrasthā nṛpa śaktā na bādhitum |
bhāvitaṃ tīvravegena manasā yanmahīpate
]

`v 42 [
tadeva paśyatyacalaṃ na śarīraviceṣṭitam |
na kāścana kriyā rājanvaraśāpādikā api
]

`v 43 [
tīvravegena saṃpannaṃ śaktāścālayituṃ manaḥ |
tīvravegena saṃyuktaṃ puruṣā hyabhivāñchitāt
]

`v 44 [
manaścālayituṃ śaktā na mahādriṃ mṛgā iva |
mameyamasitāpāṅgī manaḥkośe pratiṣṭhitā
]

`v 45 [
devāgāre mahotsedhe devī bhagavatī yathā |
na duḥkhamanugacchāmi priyayā jīvarakṣayā
]

`v 46 [
girirgrīṣmadaśādāhaṃ lagnayevābdamālayā |
yatra yatra yathā rājaṃstiṣṭhāmyabhipatāmi vā
]

`v 47 [
tatreṣṭasaṃgamādanyatkiṃcinnānubhavāmyaham |
ahalyādayitānāmnā manasendrābhidhaṃ manaḥ
]

`v 48 [
saṃsaktamidamāyāti na svabhāvādṛte param |
ekakāryaniviṣṭaṃ hi mano dhīrasya bhūpate
]

`v 49 [
na cālyate meruriva varaśāpabalairapi |
deho hi varaśāpābhyāmanyatvamiva gacchati |
nanu dhīraṃ mano rājanvijigīṣutayā sthitam
]

`v 50 [
p. 344) 207
etāni cātra manasāṃ na ca kāraṇāni
rājañśarīraśakalāni vṛthotthitāni |
ceto hi kāraṇamamīṣu śarīrakeṣu
vārīva sarvavanakhaṇḍalatāraseṣu
]

`v 51 [
nanu deha eva manasaḥ kāraṇaṃ dehapīḍane kuto na pīḍyate tatrāha - etānīti |
etāni paridṛśyamānāni prāṇināṃ śarīralakṣaṇāni śakalāni kalpanaikadeśā
manasāṃ na kāraṇāni kiṃtu ceto mana evāmīṣu śarīrakeṣu kāraṇamityarthaḥ | 50
|
ādyaṃ śarīramiha viddhi mano mahātma-
nsaṃkalpito jagati tena śarīrasaṅghaḥ |
ādyaṃ śarīramadhitiṣṭhati yatra yatra
tattadbhṛśaṃ phalati netaradasya puṃsaḥ
]

`v 52 [
mukhyāṅkuraṃ subhaga viddhi mano hi puṃso
dehāstataḥ pravisṛtāstarupallavābhāḥ |
naṣṭe'ṅkure punarudeti na pallavaśrī-
rnaivāṅkuraḥ kṣayamupaiti dalakṣayeṣu
]

`v 53 [
dehe kṣate vividhadehagaṇaṃ karoti
svapnāvanāviva navaṃ navamāśu cetaḥ |
citte kṣate tu na karoti hi kiṃcideva
dehastataḥ samanupālaya cittaratnam
]

`v 54 [
diśi diśi hariṇākṣīmeva paśyāmi rājan
priyayuvatimanastvānnityamānandito'smi |
tava puraprakṛtīnāṃ yatphalaṃ duḥkhadāyi
kṣaṇamatha suciraṃ tattanna paśyāmi kiṃcit
]