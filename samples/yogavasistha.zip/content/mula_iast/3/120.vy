`v 1 [
viṃśatyuttaraśatatamaḥ sargaḥ 120
śrīvasiṣṭha uvāca |
hemormikādivanmithyā kathitāyāḥ kṣayonmukham |
tvaṃ mahattvamavidyāyāḥ śṛṇu rāghava kīdṛśam
]

`v 2 [
lavaṇo'sau mahīpālastathā dṛṣṭvā tadā bhramam |
dvitīye divase gantuṃ pravṛttastāṃ mahāṭavīm
]

`v 3 [
yatra dṛṣṭaṃ mayā duḥkhamaraṇyānīṃ smarāmi tām |
cittādarśagatāṃ vindhyātkadācillabhyate hi sā
]

`v 4 [
iti niścitya sacivaiḥ prayayau dakṣiṇāpatham |
punardigvijayāyeva prāpya vindhyamahīdharam
]

`v 5 [
pūrvadakṣiṇapāścātyamahārṇavataṭasthalīm |
babhrāma kautukātsarvāṃ vyomavīthīmivoṣṇaguḥ
]

`v 6 [
athaikasminpradeśe tāṃ cintāmiva purogatām |
dadarśogrāmaraṇyānīṃ paralokamahīmiva
]

`v 7 [
sa tatra viharaṃstāṃstānvṛttāntānsakalānatha |
dṛṣṭavānpṛṣṭavāṃścaiva jñātavāṃśca visismiye
]

`v 8 [
tānparijñātavāṃścāsīdvyādhānpulkasajānpunaḥ |
vismayākulayā buddhyā bhūyo babhrāma saṃbhramī
]

`v 9 [
atha prāpya mahāṭavyāṃ paryante dhūmadhūsare |
tameva grāmakaṃ yasminso'bhavatpuṣṭapulkasaḥ
]

`v 10 [
tatrāpaśyajjanāṃstāṃstāṃstāḥ striyastāḥ kuṭīrakāḥ |
nānākārāñjanādhārāṃstāṃstāṃśca vasudhātaṭān
]

`v 11 [
tāṃścākāṇḍaparibhraṣṭāṃstānvṛkṣāṃstāṃstvanuvrajān |
tāṃstathaiva samuddeśāṃstānvyādhānekalānsutān
]

`v 12 [
anyāsu vṛddhāsu sabāṣpanetrā-
svārtārtiyuktāsu ca varṇayantī |
akālakāntāraviśīrṇabandhu-
duḥkhānyasaṃkhyāni sakhīṣu vṛddhā
]

`v 13 [
vṛddhā pravṛddhojjvalanetrabāṣpā
kaṣṭaṃ `note[kaṃthāvṛtā iti pāṭhaḥ] batāśuṣkakucā kṛśāṅgī |
avagrahogrāśanidagdhadeśe
tatrārtanādā pariroditīdam
]

`v 14 [
hā putri putrāvṛtasarvagātre
dinatrayābhojanajarjarāṅgi |
kṛtvāsinā varmaṇi jīrṇadehāḥ
kathaṃ kva muktā bhavatāsavaste
]

`v 15 [
tālīdalālambanamambudādrau
dantāntarasthāruṇasatphalasya |
smarāmi guñjāphaladāma bhartuḥ
purasthamudrāmarahāsinaste
]

`v 16 [
p. 408) 240
kadambajambīralavaṅgaguñjā-
kuñjāntaratastu carattarakṣoḥ |
paśyāmi putrasya kadā nu bhūyo
bhayaṃkarāṇyuḍyativalgitāni
]

`v 17 [
na tāni kāmasya vilāsinīha
mukhe'pi śobhālasitāni santi |
tamālanīle cibukaikadeśe
sutasya cānyāsyagatāmiṣasya
]

`v 18 [
sutāpanītā saha tena bhartrā
yamena yasyā yamunā samānā |
tamālavallīsahapuṣpagucchā
samīraṇeneva vane vareṇa
]

`v 19 [
hā putri guñjāphaladāmahāre
samunnatābhogapayodharāṅgi |
vātollasatkajjalalolavarṇe
parṇāmbare bādarajambudante
]

`v 20 [
hā rājaputrendusamānakānta
saṃtyajya śuddhāntavilāsinīstāḥ |
ratiṃ prayāto'si mamātmajāyāṃ
na sāpi te susthiratāmupetā
]

`v 21 [
saṃsāranadyāḥ sutaraṅgabhaṅgaiḥ
kriyāvilāsairvihitopahāsaiḥ |
kiṃ nāma tucchaṃ na kṛtaṃ nṛpeśo
yadyojitaḥ puṣkasakanyakāyām
]

`v 22 [
sā trastasāraṅgasamānanetrā
sa dṛptaśārdūlasamānavīryaḥ |
ubhau gatāvekapadena nāśa-
māśā sahārthena yathā mahehā
]

`v 23 [
mṛteśvarāśvastanijātmajāsmi
durdeśayātāsmi ca durgatā'smi |
durjātijātāsmi mahāpade'smi
sākṣādbhayaṃ bho'smi mahāpadasmi
]

`v 24 [
nīcāvamānaprabhavasya manyoḥ
kṣudhāprapannasya kalatrakasya |
śokasya vṛttāvanivāryavṛtte-
rnāryasmyanekāyatanaṃ vināthā
]

`v 25 [
daivopataptasya vibāndhavasya
mūḍhasya rūḍhasya mahādhibhūmau |
yatprāṇanaṃ yanmaraṇaṃ mahāpa-
dyasyātmanirjīvitamuttamaṃ tat
]

`v 26 [
idānīṃ svasadṛśaṃ janamanyamapi nindantyāha - daiveti | mahatyāṃ
ādhirmānasaduḥkhaṃ tallakṣaṇāyāṃ bhūmau rūḍhasya prādurbhūtasya
īdṛśasya yasya janasya yatprāṇanaṃ jīvanaṃ yanmaraṇaṃ yā ca mahāpat tat
tataḥ ātmanirjīvitaṃ svato jīvaśūnyaṃ pāṣāṇādi uttamaṃ śreṣṭhamityarthaḥ |
25 |
janairvihīnasya kudeśavṛtte-
rduḥkhānyanantāni samullasanti |
sahasraśākhārasasaṃkulāni
tṛṇāni varṣāsviva parvatasya
]

`v 27 [
evaṃ lapantīṃ svakalatravṛddhāṃ
dāsībhirāśvāsya nṛpaḥ striyaṃ tām |
papraccha kiṃvṛttamihaiva kā ca
kā te sutā kaśca sutastaveti
]

`v 28 [
p. 409) 240
uvāca sā bāṣpavilocanātha
grāmastvayaṃ puṣpasaghoṣanāmā |
ihābhavatpuṣkasakaḥ patirme
babhūva tasyendusamā sutaikā
]

`v 29 [
sā daivayogātpatimindratulya-
mihāgataṃ daivavaśena bhūpam |
ayaṃ viśīrṇaṃ madhukumbhamāpa
vane varākī karamī yathaikā
]

`v 30 [
sā tena sārdhaṃ suciraṃ sukhāni
bhuktvā prasūtā tanayāḥ sutāṃśca |
vṛddhiṃ gatā kānanakoṭare'smiṃ-
stumbīlatā pādapasaṃśriteva
]