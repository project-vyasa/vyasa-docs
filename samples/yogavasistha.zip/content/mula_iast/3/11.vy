`v 1 [
ekādaśaḥ sargaḥ 11
śrīrāma uvāca |
idaṃ `note[itthaṃrūpaṃ iti pāṭhaḥ] rūpamidaṃ dṛśyaṃ jagannāstīti
bhāsuram |
mahāpralayasaṃprāptau bho brahmankveva tiṣṭhati `note[gacchati iti
pāṭhaḥ]
]

`v 2 [
śrīvasiṣṭha uvāca |
kuta āyāti kīdṛgvā vandhyāputraḥ kva gacchati |
kva yāti kuta āyāti vada vā vyomakānanam
]

`v 3 [
śrīrāma uvāca |
vandhyāputro vyomavanaṃ naivāsti na bhaviṣyati |
kīdṛśī dṛśyatā tasya kīdṛśī tasya nāstitā
]

`v 4 [
śrīvasiṣṭha uvāca |
vandhyāputravyomavane yathā na staḥ kadācana |
jagadādyakhilaṃ dṛśyaṃ tathā nāsti kadācana
]

`v 5 [
p. 155)
na cotpannaṃ na ca dhvaṃsi yatkilādau na vidyate |
utpattiḥ kīdṛśī tasya nāśaśabdasya kā kathā
]

`v 6 [
śrīrāma uvāca |
vandhyāputranabhovṛkṣakalpanā tāvadasti hi |
sā yathā nāśajanmāḍhyā tathaivedaṃ na kiṃ bhavet
]

`v 7 [
śrīvasiṣṭha uvāca |
tulyasyātuladuḥsthasya bhāvakaiḥ kila tolanam |
niranvayā yathaivoktirjagatsattā tathaiva hi
]

`v 8 [
yathā sauvarṇakaṭake dṛśyamānamidaṃ sphuṭam |
kaṭakatvaṃ tu naivāsti jagattvaṃ na tathā pare
]

`v 9 [
ākāśe ca yathā nāsti śūnyatvaṃ vyatirekavat |
jagattvaṃ brahmaṇi tathā nāstyevāpyupalabdhmat
]

`v 10 [
kajjalānna yathā kārṣṇyaṃ śaityaṃ ca na yathā himāt |
pṛthagevaṃ bhavedbuddhaṃ jagannāsti pare pade
]

`v 11 [
yathā śaityaṃ na śaśino na himādvyatiricyate |
brahmaṇo na tathā sargo vidyate vyatirekavān
]

`v 12 [
marunadyāṃ yathā toyaṃ dvitīyendau yathendutā |
nāstyeveha jagannāma dṛṣṭamapyamalātmani
]

`v 13 [
ādāveva hi yannāsti kāraṇāsaṃbhavātsvayam |
vartamāne'pi tannāsti nāśaḥ syāttatra kīdṛśaḥ
]

`v 14 [
kvāsaṃbhavadbhūtajāḍyaṃ pṛthvyāderjaḍavastunaḥ |
kāraṇaṃ bhavituṃ śaktaṃ chāyāyāścātapo yathā
]

`v 15 [
kāraṇābhāvataḥ kāryaṃ nedaṃ tatkiṃcanoditam |
yattatkāraṇamevāsti tadevetthamavasthitam
]

`v 16 [
ajñānameva yadbhāti saṃvidābhāsameva tat |
yajjagaddṛśyate svapne saṃvitkacanameva tat
]

`v 17 [
saṃvitkacanamevāntaryathā svapne jagadbhramaḥ |
sargādau brahmaṇi tathā jagatkacanamātatam
]

`v 18 [
yadidaṃ dṛśyate kiṃcitsadaivātmani saṃsthitam |
nāstameti na codeti jagatkiṃcitkadācana
]

`v 19 [
yathā dravatvaṃ salilaṃ spandanaṃ pavano yathā |
yathā prakāśa ābhāso brahmaiva trijagattathā
]

`v 20 [
yathā puramivāste'ntarvideva `note['ntaścideva iti pāṭhaḥ]
svapnasaṃvidaḥ |
tathā jagadivābhāti svātmaiva paramātmani
]

`v 21 [
śrīrāma uvāca |
evaṃ cettatkathaṃ brahmansughanapratyayaṃ vada |
idaṃ dṛśyaviṣaṃ jātamasatsvapnānubhūtivat
]

`v 22 [
sati dṛśya kila draṣṭā sati draṣṭari dṛśyatā |
ekasattve dvayorbandho muktirekakṣaye dvayoḥ
]

`v 23 [
p. 156)
atyantāsaṃbhavo yāvadruddho dṛśyasya na kṣayaḥ |
tāvaddraṣṭari dṛśyatvaṃ na saṃbhavati mokṣadhīḥ
]

`v 24 [
dṛśyaṃ cetsaṃbhavatyādau paścātkṣayamupālabhet |
taddṛśyasmaraṇānartharūpo bandho na śāmyati
]

`v 25 [
yatra kvacana saṃsthasya svādarśasyeva cidgateḥ |
pratibimbo lagatyeva sarvasmṛtimayo hyalam
]

`v 26 [
ādāveva hi notpannaṃ dṛśyaṃ nāstyeva cetsvayam |
draṣṭurdṛśyasvabhāvatvāttatsaṃbhavati muktatā
]

`v 27 [
tasmādasaṃbhavanmuktermama protsārya yuktibhiḥ |
atyantāsaṃbhavo yāvatkathayātmavidāṃ vara
]

`v 28 [
śrīvasiṣṭha uvāca |
asadeva sadā bhāti jagatsarvātmakaṃ yathā |
śṛṇvahaṃ kathayā rāma dīrghayā kathayāmi te
]

`v 29 [
vyavasāyakathāvakyairyāvattatrānuvarṇitam |
na viśrāmyati te tāvaddhṛdi pāṃsuryathā hṛde
]

`v 30 [
atyantābhāvamasyāstvaṃ jagatsargabhramasthiteḥ |
yuddhaikadhyānaniṣṭhātmā vyavahāraṃ kariṣyasi
]

`v 31 [
tenaiva te dvitīyaśaṅkānirāsastattve viśrāntirlokavyavahāraśca setsyatītyāha ##-
bhāvābhāvagrahotsargasthūlasūkṣmacalācalāḥ |
dṛśastvāṃ vedhayiṣyanti na mahādrimivepavaḥ
]

`v 32 [
sa eṣo'styeka evātmā na dvitīyāsti kalpanā |
jagadatra yathotpannaṃ tatte vakṣyāmi rāghava
]

`v 33 [
tasmādimāni sakalāni vijṛmbhitāni
so'pīdamaṅga sakalāsakalaṃ mahātmā |
rūpāvalokanamanomananaprakārā
kārāspadaṃ svayamudeti vilīyate ca
]