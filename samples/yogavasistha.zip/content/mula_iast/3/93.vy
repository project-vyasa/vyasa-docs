`v 1 [
trinavatitamaḥ sargaḥ 93
śrīvasiṣṭha uvāca |
iti me bhagavatā pūrvamuktaṃ tadetadadya tubhyaṃ kathitam
]

`v 2 [
mana upakramameva sargakramaṃ prāguktaṃ
prapañcayaiṣurvidhisaṃvādamupasaṃharati - itīti | bhagavatā parameṣṭhīnā |
1 |
tasmādanākhyānādbrahmaṇaḥ sarvataḥ sarvamanākhyānamutpadyate
svayameva tadghanatāṃ prāpya manaḥ saṃpadyate
]

`v 3 [
p. 350) 210
tanmanastanmātrakalpanapūrvakasanniveśaṃ bhavati tatastaijasaḥ puruṣaḥ
saṃpadyate so'yaṃ brahmetyātmani nāma kṛtavān
]

`v 4 [
tena rāma yo'yaṃ parameṣṭhī tanmanastattvaṃ viddhi
]

`v 5 [
samanastattvākāro bhagavānbrahmā saṃkalpamayatvādyadeva saṃkalpayati
tadeva paśyati
]

`v 6 [
tatasteneyamavidyā parikalpitā anātmanyātmābhimānamayīti tena brahmaṇā
giritṛṇajaladhimayamidaṃ krameṇa jagatparikalpitam
]

`v 7 [
itthaṃ krameṇa brahmatatvādiyamāgatā sṛṣṭiranyata evāgateyamiti
lakṣyate
]

`v 8 [
tasmātsarvapadārthānāṃ trailokyodaravartinām |
utpattirbrahmaṇo rāma taraṅgāṇāmivārṇavāt
]

`v 9 [
ya evamanutpanne jagati yā brahmaṇaścinmanorūpiṇī sāhaṃkāre parikalpya
brahma brahmatāmeti
]

`v 10 [
yāstvanyāścicchaktayaḥ sarvaśakterabhinnā eva kalpyante
]

`v 11 [
jagati sphāratāṃ nīte pitāmaharūpeṇa manasā samullasanti
]

`v 12 [
ete sahasraśo'pi parivartamānajīvā ucyante
]

`v 13 [
te'bhyutthitā eva cinnabhaso nabhasi tanmātrairāvalitā
gaganapavanāntarvartinaścaturdaśavidhā ye bhūtajātamadhyatayābhyāse
tiṣṭhanti tasyā eva prāṇaśaktidvāreṇa praviśya śarīraṃ sthāvaraṃ
jaṃgamaṃ vāpi bījatāṃ gacchanti
]

`v 15 [
tadanu yonito jagati jāyante tadanu
kākatālīyayogenotpannavāsanāpravāhānurūpakarmaphalabhāgino bhavanti |
14 |
tataḥ karmarajjubhirvāsanāvalitābhirbaddhaśarīrā bhramantaḥ protpatanti
ca
]

`v 16 [
icchaivaitā bhūtajātayaḥ
]

`v 17 [
kāścijjanasahasrāntāḥ patanti vanaparṇavat |
karmavātyā paribhrāntā luṭhanti girikukṣiṣu
]

`v 18 [
aprameyabhavāḥ kāściccitsattājñānamohitāḥ |
cirajātā bhavantīha bahukalpaśatānyapi
]

`v 19 [
kāścitkatipayātītā manoramabhavāntarāḥ |
viharanti jagatyasmiñśubhakarmaparāyaṇāḥ
]

`v 20 [
p. 351) 210
kāścidvijñātavijñānāḥ parameva padaṃ gatāḥ |
vātodbhūtāḥ payomadhyaṃ sāmudrā iva bindavaḥ
]

`v 21 [
utpattiḥ sarvajīvānāmitīha brahmaṇaḥ padāt |
āvirbhāvatirobhāvabhaṅgurā bhavabhāvinī
]

`v 22 [
vāsanāviṣavaiṣamyavaidhuryajvaradhāriṇī |
anantasaṃkaṭānarthakāryasatkārakāriṇī
]

`v 23 [
nānādigdeśakālāntaśailakandaracāriṇī `note[antaśabdena maraṇottaraṃ
gantavyā lokā upalakṣyante teṣu ca] |
racitottamavaicitryavihitā'saṃbhramā'satī
]

`v 24 [
eṣā jagajjāṅgalajīrṇavallī
samyaksamālokakuṭhārakṛttā |
vallīva vikṣubdhamanaḥśarīrā
bhūyo na saṃrohati rāmabhadra
]