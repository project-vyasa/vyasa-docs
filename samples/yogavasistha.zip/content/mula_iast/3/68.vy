`v 1 [
aṣṭaṣaṣṭitamaḥ sargaḥ 68
śrīvasiṣṭha uvāca |
atraivodāharantīmamitihāsaṃ purātanam |
rākṣasyoktaṃ mahāpraśnajālamāvalitākhilam
]

`v 2 [
asti kajjalapaṅkādrerivogrā śālabhañjikā |
himādreruttare pārśve karkaṭī nāma rākṣasī
]

`v 3 [
viṣūcikābhidhānā ca nāmnāpyanyāyabādhikā |
vindhyāṭavīva dehena śuṣkā kārśyamupāgatā
]

`v 4 [
p. 297) 181
mahābalāgninayanā rodorandhrārdhapūraṇī |
nīlāmbaradharā kṛṣṇā dehabaddheva yāminī
]

`v 5 [
nīhāravasanacchannā medurābhraśiraḥpaṭā |
lambābhrabimbollasitā nityotthatimirordhvajā
]

`v 6 [
sthiravidyullatānetrā tamālatarujānukā |
vaidūryaśūrpāgranakhī bhasmanīhārahāsinī
]

`v 7 [
nirmāṃsanaradehaughapuṣpasragdāmabhūṣitā |
sarvāṅgodāttasaṃprotaśavamālāvirājitā
]

`v 8 [
vetālāveśavicalatkālakaṅkālakuṇḍalā |
arkādānotkadīrghāgrabhīmograbhujamaṇḍalā
]

`v 9 [
tasyā vipulakāyatvāddurlabhatvānnijāndhasaḥ |
atṛpto'rṇavalekhāyā ivābhūjjāṭharo'nalaḥ
]

`v 10 [
na kadācana sā tṛptimupayātā mahodarī |
vaḍavānalajihveva cintayāmāsa caikadā
]

`v 11 [
jambūdvīpagatānsarvānnigirāmi janānyadi |
anāratamanuśvāsaṃ jalarāśimivārṇavaḥ
]

`v 12 [
meghena mṛgatṛṣṇeva tanme kṣudupaśāmyati |
aviruddhaiva sā yuktiryayāpadi hi jīvyate
]

`v 13 [
mantrauṣadhatapodānadevapūjādirakṣitam |
samameva janaṃ sarvaṃ nirbādhaṃ kaḥ prabādhate
]

`v 14 [
tapaḥ karomi paramamakhinnenaiva cetasā |
tapasaiva mahogreṇa yaddurāpaṃ tadāpyate
]

`v 15 [
iti saṃcintya sā sarvajantujātajighāṃsayā |
taporthamatha sasmāra parvataṃ bhūtadurgamam
]

`v 16 [
āruroha ca tacchṛṅgaṃ sthiravidyudvilocanā |
hastapādādimaddehā śyāmalevābhramaṇḍalī
]

`v 17 [
tatra gatvātha sā snātvā tapaḥ kartuṃ kṛtasthitiḥ |
atiṣṭhadekapādena candrārkāspandalocanā
]

`v 18 [
krameṇa divasāḥ pakṣāstasyā māsartavo yayuḥ |
śītātapeṣu līnāyāḥ kṛtāyā iva śailataḥ
]

`v 19 [
sā babhūvābhramālāyāḥ samāsaṃ stambhitākṛtiḥ |
kṛṣṇordhvagordhvakeśī ca khamāhartumivodgatā
]

`v 20 [
ālokya tāṃ pavanajarjaritāṅgakatvak
cīrāṅgaṇākṛtiraṇatpavanāvadhūtaiḥ |
ūrdhvasthamūrdhajatamaḥpaṭalairdadhānāṃ
tāraughamauktikamajaḥ samupājagāma
]