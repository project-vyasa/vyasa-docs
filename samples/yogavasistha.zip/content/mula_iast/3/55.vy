`v 1 [
p. 263) 164
pañcapañcāśaḥ sargaḥ 55
prabuddhalīlovāca |
yathaiva janturmriyate jāyate ca yathā punaḥ |
tanme kathaya deveśi punarbodhavivṛddhaye
]

`v 2 [
śrīdevyuvāca |
nāḍīpravāhe vidhure yadā vātavisaṃsthitim |
jantuḥ prāpnoti hi tadā śāmyatīvāsya cetanā
]

`v 3 [
śuddhaṃ hi cetanaṃ nityaṃ nodeti na ca śāmyati |
sthāvare jaṅgame vyomni śaile'gnau pavane sthitam
]

`v 4 [
kevalaṃ vātasaṃrodhādyadā spandaḥ praśāmyati |
mṛta ityucyate dehastadāsau jaḍanāmakaḥ
]

`v 5 [
tasmindehe śavībhūte vāte cānilatāṃ gate |
cetanaṃ vāsanāmuktaṃ svātmatattve'vatiṣṭhati
]

`v 6 [
vāte śarīravāyau anilatāṃ svaprakṛtimahāvāyutām | prāṇastu sahatejasā
prājñātmanyeva līyate | upādhivilaye jīvo'pi saha vāsanābhiḥ
paramātmabhāve'vatiṣṭhata ityāha - cetanamiti | tathāca śrutiḥ athāsya prayato
vāṅmanasi saṃpadyate manaḥ prāṇe prāṇastejasi tejaḥ parasyāṃ devatāyām iti |
5 |
jīva ityucyate tasya nāmāṇorvāsanāvataḥ |
tatraivāste sa ca śavāgāre gaganake tathā
]

`v 7 [
tato'sau pretaśabdena procyate vyavahāribhiḥ |
cetanaṃ vāsanāmiśramāmodānilavatsthitam
]

`v 8 [
idaṃ dṛśyaṃ parityajya yadāste darśanāntare |
sa svapna iva saṃkalpa iva nānakṛtistadā
]

`v 9 [
tasmiṃnneva pradeśe'ntaḥ pūrvavatsmṛtimānbhavet |
tadaiva mṛtimūrcchānte paśyatyanyaśarīrakam
]

`v 10 [
ātmanyasti ghaṭāpuṣṭamanyasya vyoma kevalam |
ākāśabhūtale sākaṃ sākāśaśaśivāsaram `note[śaśicāmaram iti
pāṭhaḥ]
]

`v 11 [
bhavanti ṣaḍvidhāḥ pretāsteṣāṃ bhedamimaṃ śṛṇu |
sāmānyapāpino madhyapāpinaḥ sthūlapāpinaḥ
]

`v 12 [
sāmānyadharmā `note[chandobhaṅgo'tra ārṣaḥ] madhyamadharmā
cottamadharmavān |
eteṣāṃ kasyacidbhedo dvau trayo'pyatha kasyacit
]

`v 13 [
kaścinmahāpātakavānvatsaraṃ smṛtimūrchanam |
vimūḍho'nubhavatyantaḥ pāṣāṇahṛdayopamaḥ
]

`v 14 [
tatra prathamaṃ tṛtīyasya gatimāha - kaściditi | vatsaraṃ saṃvatsaramātram |
13 |
tataḥ kālena saṃbuddho vāsanājaṭharoditam |
anubhūya ciraṃ kālaṃ nārakaṃ duḥkhamakṣayam
]

`v 15 [
bhuktvā yoniśatānyuccairduḥkhādduḥkhāntaraṃ gataḥ |
kadācicchamamāyāti saṃsārasvapnasaṃbhrame
]

`v 16 [
p. 264) 165
athavā mṛtimohānte jaḍaduḥkhaśatākulām |
kṣaṇādvṛkṣāditāmeva hṛtsthāmanubhavanti `note[tatsthām iti
pāṭhaḥ] te
]

`v 17 [
svavāsanānurūpāṇi duḥkhāni narake punaḥ |
anubhūyātha yonīṣu jāyante bhūtale cirāt
]

`v 18 [
atha madhyamapāpo yo mṛtimohādanantaram |
saśilājaṭharaṃ jāḍyaṃ kaṃcitkālaṃ prapaśyati
]

`v 19 [
tataḥ prabuddhaḥ kālena kenacidvā tadaiva vā |
tiryagādikramairbhuktvā yonīḥ saṃsārameṣyati
]

`v 20 [
mṛta evānubhavati kaścitsāmānyapātakī |
svavāsanānusāreṇa dehaṃ saṃpannamakṣatam
]

`v 21 [
sa svapna iva saṃkalpa iva cetati tādṛśam |
tasminneva kṣaṇe tasya smṛtiritthamudeti ca
]

`v 22 [
ye tūttamamahāpuṇyā mṛtimohādanantaram |
svargavidyādharapuraṃ smṛtyā svanubhavanti te
]

`v 23 [
tato'nyakarmasadṛśaṃ bhuktvānyatra phalaṃ nijam |
jāyante mānuṣe loke saśrīke sajjanāspade
]

`v 24 [
ye ca madhyamadharmāṇo mṛtimohādanantaram |
te vyomavāyuvalitāḥ prayāntyoṣadhipallavam
]

`v 25 [
pañcamasya gatimāha - ye ceti | oṣadhipallavaṃ oṣadhipallavapradhānaṃ
nandanacaitrarathādivanaṃ kinnarakiṃpuruṣayakṣādiśarīreṇa prayāntītyarthaḥ | 24
|
tatra cāruphalaṃ bhuktvā praviśya hṛdayaṃ nṛṇām |
retasāmadhitiṣṭhanti garbhe jātikramocite
]

`v 26 [
svavāsanānusāreṇa pretā etāṃ vyavasthitim |
mūrcchānte'nubhavantyantaḥ krameṇaivākrameṇa ca
]

`v 27 [
etena caturthasyāpi gatiruktaprāyaiveti manyamāna upasaṃharati - svavāsaneti |
26 |
ādau mṛtā vayamiti budhyante tadanukramāt |
bandhupiṇḍādidānena protpannā iti vedinaḥ
]

`v 28 [
tato yamabhaṭā ete kālapāśānvitā iti |
nīyamānaḥ prayāmyebhiḥ kramādyamapuraṃ tviti
]

`v 29 [
udyānāni vimānāni śobhanāni punaḥpunaḥ |
svakarmabhirupāttāni divyānītyeva puṇyavān
]

`v 30 [
himānīkaṇṭakaśvabhraśastrapatravanāni ca |
svakarmaduṣkṛtotthāni saṃprāptānīti pāpavān
]

`v 31 [
iyaṃ me saumyasaṃpātā saraṇiḥ śītaśādvalā |
snigdhacchāyā savāpīkā puraḥsaṃstheti madhyamaḥ
]

`v 32 [
ayaṃ prāpto yamapuramahameṣa sa bhūtapaḥ |
ayaṃ karmavicāro'tra kṛta ityanubhūtimān
]

`v 33 [
iti pratyekamabhyeti pṛthuḥ saṃsārakhaṇḍakaḥ |
yathāsaṃsthitaniḥśeṣapadārthācārabhāsuraḥ
]

`v 34 [
ākāśa iva niḥśūnye śūnyātmaiva vibodhavān |
deśakālakriyādairghyabhāsuro'pi na kiṃcana
]

`v 35 [
iti'yamahamādiṣṭaḥ svakarmaphalabhojane |
gacchāmyāśu śubhaṃ svargamito narakameva ca
]

`v 36 [
yaḥ svargo'yaṃ mayā bhukto bhukto'yaṃ narako'tha vā |
imāstā yonayo bhuktā jāye'haṃ saṃsṛtau punaḥ
]

`v 37 [
ayaṃ śālirahaṃ jātaḥ kramātphalamahaṃ sthitaḥ |
ityudarkaprabodhena budhyamāno bhaviṣyati
]

`v 38 [
p. 265) 165
saṃsuptakaraṇastvevaṃ bījatāṃ yātyasau nare |
tadbījaṃ yonigalitaṃ garbho bhavati mātari
]

`v 39 [
kutastadānīmasau vrīhyādibhāvaṃ nānubhavati tatrāha - saṃsuptakaraṇa iti |
śarīrābhāvātsaṃmūrcchitabāhyāntaḥkaraṇaḥ | tuśabda etadviśeṣasūcanāya |
evamevāsau nare pitṛśarīre bhuktānnadvārā praviṣṭo bījatāṃ retobhāvaṃ yāti |
38 |
sa garbho jāyate loke pūrvakarmānusārataḥ |
bhavyo bhavatyabhavyo vā bālako lalitākṛtiḥ
]

`v 40 [
tato'nubhavatīndvābhaṃ yauvanaṃ madanonmukham |
tato jarāṃ padmamukhe himāśanimiva cyutam `note[cyutām iti pāṭhaḥ] |
40 |
indvābhaṃ candravadupacayāpacyadharmiṇaṃ calaṃ kāntaṃ ca
]

`v 41 [
tato'pi vyādhimaraṇaṃ punarmaraṇamūrcchanām |
punaḥ svapnavadāyātaṃ piṇḍairdehaparigraham
]

`v 42 [
yāmyaṃ yāti punarlokaṃ punareva bhramakramam |
bhūyo bhūyo'nubhavati nānāyonyantarodaye
]

`v 43 [
ityājavaṃ javībhāvamāmokṣamatibhāsuram |
bhūyo bhūyo'nubhavati vyomnyeva vyomarūpavān
]

`v 44 [
prabuddhalīlovāca |
ādisarge yathā devi bhrama eṣa pravartate |
tathā kathaya me bhūyaḥ prasādādbodhavṛddhaye
]

`v 45 [
śrīdevyuvāca |
paramāthaghanaṃ śailāḥ paramārthaghanaṃ drumāḥ |
paramārthaghanaṃ pṛthvī paramārthaghanaṃ nabhaḥ
]

`v 46 [
sarvātmakatvātsa yato yathodeti cidīśvaraḥ |
paramākāśaśuddhātmā tatra tatra bhavet tathā
]

`v 47 [
sargādau svapnapuruṣanyāyenādiprajāpatiḥ |
yathā sphuṭaṃ prakacitastathādyāpi sthitā sthitiḥ
]

`v 48 [
prathamo'sau pratispandaḥ padārthānāṃ hi bimbakam |
pratibimbitametasmādyattadadyāpi saṃsthitam
]

`v 49 [
yannāma suṣiraṃ sthānaṃ dehānāṃ tadgato'nilaḥ |
karotyaṅgaparispandaṃ jīvatītyucyate tataḥ
]

`v 50 [
sargādāvevamevaiṣā jaṅgameṣu sthitā sthitiḥ |
cetanā api niḥspandāstenaite pādapādayaḥ
]

`v 51 [
cidākāśo'yamevāṃśaṃ kurute cetanoditam |
sa eva saṃvidbhavati śeṣaṃ bhavati naiva tat
]

`v 52 [
naropādhipuraṃ prāptaṃ cetatyakṣipuṭaṃ nayat |
tattasyā nākṣicijjīvaṃ no jīvatyeva sargataḥ
]

`v 53 [
tathā khaṃ khaṃ tathā bhūmirbhūmitvenāptvavajjalam |
yadyathā cetati svairaṃ tadvettyeva tathā vapuḥ
]

`v 54 [
p. 266) 166
iti sarvaśarīreṇa jaṃgamatvena jaṃgamam |
sthāvaraṃ sthāvaratvena sarvātmā bhāvayan sthitaḥ
]

`v 55 [
tasmādyajjaṅgamaṃ nāma tatsvabodhanarūpavat |
tena buddhaṃ tatastadvattadevādyāpi saṃsthitam
]

`v 56 [
yathā bhāvanasiddhaṃ tadadyāpyanuvartata evetyāha - tasmāditi dvābhyām |
55 |
yadvṛkṣābhidhamābuddhaṃ sthāvaratvena vai punaḥ |
jaḍamadyāpi saṃsiddhaṃ śilātarutṛṇādi ca
]

`v 57 [
na tu jāḍyaṃ pṛthakkiṃcidasti nāpi ca cetanam |
nātra bhedo'sti sargādau sattāsāmānyakena ca
]

`v 58 [
vṛkṣāṇāmupalānāṃ yā nāmāntaḥsthāḥ svasaṃvidaḥ |
buddhyādivihitānyeva tāni teṣāmiti sthitiḥ
]

`v 59 [
vidontaḥsthāvarāderyāstasyā buddhyāstathā sthiteḥ |
anyābhidhānāsthānārthāḥ saṃketairaparaiḥ sthitāḥ
]

`v 60 [
kṛmikīṭapataṅgānāṃ yā nāmāntaḥsvasaṃvidaḥ |
tānyeva teṣāṃ buddhyādīnyabhidhārthāni kānicit
]

`v 61 [
yathottarābdhijanatā dakṣiṇābdhijanaṃ sthitam |
na kiṃcidapi jānāti nijasaṃvedanādṛte
]

`v 62 [
svasaṃjñānubhave līnāstathā sthāvarajaṅgamāḥ |
parasparaṃ yadā sarve svasaṃketaparāyaṇāḥ
]

`v 63 [
yathā śilāntaḥsaṃsthānāṃ bahiṣṭhānāṃ ca vedanam |
asajjaḍaṃ ca bhekānāṃ mitho'ntastasthuṣāṃ tathā
]

`v 64 [
sarvaṃ sarvagataṃ cittaṃ cidvyomnā yatpracetitam |
sargādau copanaṃ vāyuḥ sa ihādyāpi saṃsthitaḥ
]

`v 65 [
cetitaṃ yattu sauṣiryaṃ tannabhastatra mārutaḥ |
spandātmetyādisargehāḥ padārtheṣviva copanam
]

`v 66 [
cittaṃ tu paramārthena sthāvare jaṃgame sthitam |
copanānyanilaireva bhavanti na bhavanti ca
]

`v 67 [
evaṃ bhrāntimaye viśve padārthāḥ saṃvidaṃśavaḥ |
sargādiṣu yathaivāsaṃstathaivādyāpi saṃsthitāḥ
]

`v 68 [
yathā viśvapadārthānāṃ svabhāvasya vijṛmbhitam |
asatyameva satyābhaṃ tadetatkathitaṃ tava
]

`v 69 [
ayamastaṃ gataḥ prāyaḥ paśya rājā vidūrathaḥ |
mālāśavasya padmasya patyuste yāti hṛdgatam
]

`v 70 [
prabuddhalīlovāca |
kena mārgeṇa deveśi yātyeṣa śavamaṇḍapam |
enamevāśu paśyantyāvāvāṃ gacchāva uttame
]

`v 71 [
śrīdevyuvāca |
manuṣyavāsanāntasthaṃ mārgamāśritya gacchati |
eṣo'hamaparaṃ lokaṃ dūraṃ yāmīti cinmayaḥ
]

`v 72 [
manuṣyavāsanā padmaśarīrāhaṃvāsanā | anyathā tatprāptyayogāditi bhāvaḥ | 71
|
mārgeṇaivamanenaiva yāvasteyena (?) saṃmatam |
parasparecchāvicchittirna hi sauhārdabandhanī
]

`v 73 [
p. 267) 166
śrīvasiṣṭha uvāca |
iti vihitakathāgataklamāyāṃ
paramadṛśi prasṛte vibodhabhānau |
nṛpativarasutāmanasyudāre
vigalitacittajaḍo vidūratho'bhūt
]