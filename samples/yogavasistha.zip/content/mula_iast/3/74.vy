`v 1 [
catuḥsaptatitamaḥ sargaḥ 74
śrīvasiṣṭha uvāca |
tasya tatrordhvaśṛṅgasya tasyāṃ bhuvi mahāvanau |
dadarśa madhyamāṃ sūcīṃ protthitāṃ saśikhāmiva
]

`v 2 [
ekapādaṃ tapasyantīṃ śuṣyantīṃ śira-ūṣmaṇā |
satatānaśanāṃ śuṣkapiṇḍībhūtodaratvacam
]

`v 3 [
sakṛdvikasitāsyena gṛhītvevātapānilān |
paścāttyajantīṃ hṛdaye me na māntītyanāratam
]

`v 4 [
śuṣkāṃ caṇḍāṃśukiraṇairjarjarāṃ vanavāyubhiḥ |
acalantīṃ nijātsthānātsnāpitāminduraśmibhiḥ
]

`v 5 [
pūrvaṃ rajoṇunaikena saṃviṣṭacchannamastakām |
kṛtārthatvaṃ kathayatīṃ dadatānyasya nāspadam
]

`v 6 [
araṇyānyeva dattvārthaṃ ciraṃ jātaśikhāmiva |
mūrdhnyavasthāpitaprāṇajaṭājūṭavalīmiva
]

`v 7 [
tāṃ prekṣya pavanaḥ sūcīṃ vismayākulacetanaḥ |
praṇamyālokya suciraṃ bhītabhīta ivāgataḥ
]

`v 8 [
mahātapasvinī sūcī kimarthaṃ tapyate tapaḥ |
neti praṣṭuṃ śaśākāsau tattejorāśinirjitaḥ
]

`v 9 [
bhagavatyā mahāsūcyā aho citraṃ mahātapaḥ |
ityeva kevalaṃ dhyāyanmāruto gaganaṃ yayau
]

`v 10 [
samullaṅghyābhramārgaṃ tu vātaskandhānatītya ca |
siddhavṛndānadhaḥ kṛtvā sūryamārgamupetya ca
]

`v 11 [
ūrdhvametya vimānebhyaḥ prāpa śakrapurāntare |
sūcīdarśanapuṇyaṃ tamāliliṅga puraṃdaraḥ
]

`v 12 [
pṛṣṭaśca kathayāmāsa dṛṣṭaṃ sarvaṃ mayetyasau |
sahadevanikāyāya śakrāyāsthānavāsine
]

`v 13 [
vāyuruvāca |
jambūdvīpe'sti śailendro himavānnāma sūnnataḥ |
jāmātā yasya bhagavānsākṣācchaśikalādharaḥ
]

`v 14 [
tasyottare mahāśṛṅgapṛṣṭhe paramarūpiṇī |
sthitā tapasvinī sūcī tapaścarati dāruṇam
]

`v 15 [
bahunātra kumuktena vātādyaśanaśāntaye |
yayā svodarasauṣiryaṃ piṇḍīkṛtvā nivāritam
]

`v 16 [
śāntasaṃkocasūkṣmārthaṃ vikāsyāsyaṃ rajoṇunā |
tayādya sthagitaṃ śītavātāśananivṛttaye
]

`v 17 [
tasyāstīvreṇa tapasā tuhinākaramutsṛjan |
agnyākāramayo gṛhṇan deva duḥsevyatāṃ gataḥ
]

`v 18 [
p. 312) 190
taduttiṣṭhāśu gacchāmaḥ sarva eva pitāmaham |
tadvarārthamanarthāya viddhi tatsumahattapaḥ
]

`v 19 [
iti vāteritaḥ śakraḥ sahadevagaṇena saḥ |
jagāma brahmaṇo lokaṃ prārthayāmāsa taṃ vibhum
]

`v 20 [
sūcyā varamahaṃ dātuṃ gacchāmi himavacchiraḥ |
brahmaṇeti pratijñāte śakraḥ svargamupāyayau
]

`v 21 [
etāvatātha kālena sā babhūvātipāvanī |
sūcī nijatapastāpatāpitāmaramandirā
]

`v 22 [
mukharandhrasthitārkāṃśudṛśā svacchāyayaiva sā |
vikāsinyā vivartisthā coditāntamavekṣitā
]

`v 23 [
kauśeyarūpayā sūcyā meruḥ sthairyeṇa nirjitaḥ |
majjanaṃ naiti vṛddhvaivaṃ muktamādyantayordine
]

`v 24 [
madhyāhṇe tāpabhītyeva viśantyā mārutāntaram |
anyadā gauravāddṛṣṭvā dūrataḥ prekṣamāṇayā
]

`v 25 [
sā tamāvekṣate kṣārāttāpādaṅge nimajjati |
saṃkaṭe vismaratyeva jano gauravasatkriyām
]

`v 26 [
chayāsūcī tāpasūcī yaścātmā sa tṛtīyayā |
trikoṇaṃ tapasā pūtaṃ vārāṇasyā samaṃ kṛtam
]

`v 27 [
gatāstena trikoṇena trivarṇaparikhāvatā |
vāyavaḥ pāṃsavo ye'pi te parāṃ muktimāgatāḥ
]

`v 28 [
śuṣkatvenāmūrtā śyāmā śuklā ceti trivarṇasūcīsarillakṣaṇaparikhāvatā |
muktiṃ svasaṃsargijanamuktiprayojanatāṃ doṣamuktilakṣaṇāṃ pāvanatāṃ vā |
27 |
viditaparamakāraṇādya jātā
svayamanucetanasaṃvidaṃ vicārya |
svamananakalanānusāra eka-
stviha hi guruḥ paramo na rāghavānyaḥ
]