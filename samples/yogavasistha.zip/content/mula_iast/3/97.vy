`v 1 [
saptanavatitamaḥ sargaḥ 97
śrīrāma uvāca |
brahmanmanasa evedamantaścāḍambaraṃ sṛtam |
yatastadeva karmeti vākyārthādupalabhyate
]

`v 2 [
śrīvasiṣṭha uvāca |
dṛḍhabhāvoparaktena manasaivorarīkṛtam |
marucaṇḍātapeneva bhāsvarāvaraṇaṃ `note[varaṇaṃ vapuḥ iti pāṭhaḥ]
punaḥ
]

`v 3 [
rāmeṇa buddhaṃ tātparyaṃ tathaivetyanumodanāya svayaṃ vasiṣṭhaḥ punaḥ
saṃkṣepavistarābhyāmāha - dṛḍhetyādinā | bhāsvarasya
tejastvasyāvaraṇamaprathāheturmṛgatṛṣṇodakamiva
bhāsvarasyātmano'prathāhetvajñānajāḍyamurarīkṛtam | aṅgīkṛtamityarthaḥ |
2 |
brahmātmani jagatyasminmana ekākṛtiṃ gatam |
kvacinnaratayā rūḍhaṃ kvacitsuratayotthitam
]

`v 4 [
kvaciddaityatayollāsi kvacidyakṣatayoditam |
kvacidgandharvatāṃ prāptaṃ kvacitkinnararūpi ca
]

`v 5 [
nānācāranabhobhāgapurapattanarūpayā |
manye vitatayākṛtyā mana eva vijṛmbhate
]

`v 6 [
evaṃ sthite śarīraughastṛṇakāṣṭhalatopamaḥ |
tadvicāraṇayā ko'rtho vicāryaṃ mana eva naḥ
]

`v 7 [
tenedaṃ sarvamābhogi jagadityākulaṃ tatam |
manye tadvyatirekeṇa paramātmaiva śiṣyate
]

`v 8 [
ātmā sarvapadātītaḥ sarvagaḥ sarvasaṃśrayaḥ |
tatprasādena saṃsāre mano dhāvati valgati
]

`v 9 [
mano manye manaḥ karma taccharīreṣu kāraṇam |
jāyate mriyate taddhi nātmanīdṛgvidhā guṇāḥ
]

`v 10 [
mana eva vicāreṇa manye vilayameṣyati |
manovilayamātreṇa tataḥ śreyo bhaviṣyati
]

`v 11 [
manonāmni parikṣīṇe karmaṇyāhitasaṃbhrame |
mukta ityucyate jantuḥ punarnāma na jāyate
]

`v 12 [
śrīrāma uvāca |
bhagavanbhavatā proktā jātayastrividhā nṛṇām |
prathamaṃ kāraṇaṃ tāsāṃ manaḥ sadasadātmakam
]

`v 13 [
tatkathaṃ śuddhacinnāmnastattvādbuddhivivarjitāt |
utthitaṃ sphāratāṃ yātaṃ jagaccitrakaraṃ manaḥ
]

`v 14 [
śrīvasiṣṭha uvāca |
ākāśā hi trayo rāma vidyante vitatāntarāḥ |
cittākāśaścidākāśo bhūtākāśastṛtīyakaḥ
]

`v 15 [
p. 361) 215
ete hi sarvasāmānyāḥ sarvatraiva vyavasthitāḥ |
śuddhacittatvaśaktyā tu labdhasattātmatāṃ gatāḥ
]

`v 16 [
sarvasvakāryasādhāraṇāḥ sarvasvakārye vyavasthitā anugatā iti taddhetuḥ |
nacaivamadvaitahāniḥ sattābhedānabhyupagamādityāśayenāha - śuddheti |
15 |
sabāhyābhyantarastho yaḥ sattāsattāvabodhakaḥ |
vyāpī samastabhūtānāṃ cidākāśaḥ sa ucyate
]

`v 17 [
sarvabhūtahitaḥ śreṣṭho yaḥ kālakalanātmakaḥ |
yenedamātataṃ sarvaṃ cittākāśaḥ sa ucyate
]

`v 18 [
daśadiṅmaṇḍalābhogairavyucchinnavapurhi yaḥ |
bhūtātmāsau ya ākāśaḥ pavanābdādisaṃśrayaḥ
]

`v 19 [
bhūtākāśaṃ lakṣayati - daśeti | abdā meghāḥ saṃvatsarātmā sūryo vā | 18
|
ākāśacittākāśau dvau cidākāśabalodbhavau |
citkāraṇaṃ hi sarvasya kāryaughasya dinaṃ yathā
]

`v 20 [
jaḍo'smi na jaḍo'smīti niścayo malinaścitaḥ |
yastadeva mano viddhi tenākāśādi bhāvyate
]

`v 21 [
aprabuddhātmaviṣayamākāśatrayakalpanam |
kalpyate upadeśārthaṃ prabuddhaviṣayaṃ na tu
]

`v 22 [
ekameva paraṃ brahma sarvaṃ sarvāvapūrakam |
prabuddhaviṣayaṃ nityaṃ kalākalanavarjitam
]

`v 23 [
dviatādvaitasamudbhedairvākyasaṃdarbhagarbhitaiḥ |
upadeśyata evājño na prabuddhaḥ kathaṃcana
]

`v 24 [
yāvadrāmāprabuddhastvamākāśatrayakalpanā |
tāvadevāvabodhārthaṃ mayā tvamupadiśyase
]

`v 25 [
ākāśacittākāśādyāścidākāśakalaṅkitāt |
prasūtā dāvadahanādyathā marumarīcayaḥ
]

`v 26 [
cinoti malinaṃ rūpaṃ cittatāṃ samupāgatam |
trijagantīndrajālāni racayatyākulātmakam
]

`v 27 [
cittatvamasya malinasya cidātmakasya
tattvasya dṛśyata idaṃ nanu bodhahīnaiḥ |
śuktau yathā rajatatā natu bodhavadbhi-
rmaurkhyeṇa bandha iha bodhabalena mokṣaḥ
]