`v 1 [
trayodaśottaraśatatamaḥ sargaḥ 113
śrīvasiṣṭha uvāca |
eṣā hi vāsanā nityamasatyaiva yadutthitā |
dvicandrabhrāntivattena tyaktuṃ rāghava yujyate
]

`v 2 [
avidyā vidyamāneva naṣṭaprajñeṣu vidyate |
nāmnaivāṅgīkṛtābhāvātsamyakprajñeṣu sā kutaḥ
]

`v 3 [
naṣṭaprajñeṣu vivekavijñānaśūnyeṣu vidyamānā paramārthasatyeva
dṛḍhatarā vidyate | samyakprajñeṣu tu
abhāvādaparamārthatvānnāmnaivāṅgīkṛtā vandhyāputravat | ataḥ sā kutaḥ | 2
|
mā bhavājño bhava prājñaḥ samyagrāma vicāraya |
nāstyevendurdvitīyaḥ khe bhrāntyā saṃlakṣyate mudhā
]

`v 4 [
nātra tattvādṛte kiṃcidvidyate vastvavastu ca |
ūrmimālini vistīrṇe vāripūrādṛte yathā
]

`v 5 [
svavikalpādṛte naitānbhāvābhāvānasanmayān |
nitye'site tate śuddhe mā samāropayātmani
]

`v 6 [
nāsi kartā kimetāsu kriyāsu mamatā tava |
ekasminvidyamāne hi kiṃ kena kriyate katham
]

`v 7 [
mā vā'kartā bhava prājña kimakartṛtayehite |
sādhyaṃ sādhyamupādeyaṃ tasmātsvastho bhavānagha
]

`v 8 [
kartā saṃstvamasaktatvādbhāavābhāve raghūdvaha |
asaktatvādakartāpi kartṛvatspandanaṃ kutaḥ
]

`v 9 [
satyaṃ syāccedupādeyaṃ mithyā syāddheyameva cet |
upādeyaikasaktatvādyuktā saktirhi karmaṇi
]

`v 10 [
yatrendrajālamakhilaṃ māyāmayamavastukam |
tatra kāsthā kathaṃ nāma heyopādeyadṛṣṭayaḥ
]

`v 11 [
saṃsārabījakaṇikā yaiṣā vidyā radhūdvaha |
eṣā hyavidyamānaiva satīva sphāratāṃ gatā
]

`v 12 [
yeyamābhoginiḥsārā saṃsārārambhacakrikā |
vijñeyā vāsanaiṣā sā cetaso mohadāyinī
]

`v 13 [
cāruvaṃśalatevāntaḥśūnyā nissārakoṭarā |
sarittaraṅgamāleva na vyucchinnāpi naśvarī
]

`v 14 [
p. 391) 231
gṛhyamāṇāpi hastena grahītuṃ naiva yujyate |
mṛdvyapyatyantatīkṣṇāgrā nirjharormirivotthitā
]

`v 15 [
dṛśyate prakarābhāsā sadarthe nopayujyate |
taraṅgṇyataraṅgābhā svākārapariniṣṭhitā
]

`v 16 [
kvacidvakrāḥ kvacitspaṣṭā dīrghāḥ kharvāḥ sthirāścalāḥ |
yatprasādodbhavāstasmādvyatirekamupāgatāḥ
]

`v 17 [
antaḥśūnyāpi sarvatra dṛśyate sārasundarī |
na kvacitsaṃsthitāpīha sarvatraivopalakṣyate
]

`v 18 [
jaḍaiva cinmayīvāsāvanyaspandopajīvinī |
nimeṣamapyatiṣṭhantī sthairyāśaṅkāṃ prayacchati
]

`v 19 [
jvālāvacchuddhavarṇāpi maṣīmalinakoṭarā |
valgatyanyaprasādena dīyate tadavekṣaṇāt
]

`v 20 [
āloke vimale mlānā tamasyapi virājate |
mṛgatṛṣṇeva śuṣkābhā nānāvarṇavilāsinī
]

`v 21 [
vakrā viṣamayī tanvī mṛdvī saṃkaṭakarkaśā |
lalanācañcalā lubdhā tṛṣṇā kṛṣṇeva bhoginī
]

`v 22 [
svayaṃ dīpaśikhevāśu kṣīyate snehasaṃkṣaye |
sindūradhūlilekheva vinā rāgaṃ virājate
]

`v 23 [
kṣaṇaprakāśataralā kṛtasaṃsthā jaḍāśayā |
mugdhānāṃ trāsajananī vakrā vidyudivoditā
]

`v 24 [
yatnādgṛhītvā dahati bhūtvā bhūtvā pralīyate |
labhyate'pi hi nānviṣṭā vidyudvadatibhaṅgurā
]

`v 25 [
aprārthitaivopanatā ramaṇīyāpyanarthadā |
akālapuṣpamāleva śreyasenābhinanditā
]

`v 26 [
atyantavisṛtaivātisukhāya bhramadāyinī |
duḥsvapnakalaneveyamanarthāyaiva tarkitā
]

`v 27 [
pratibhāsavaśādeṣā trijaganti mahānti ca |
muhūrtamātreṇotpādya dhatte grāsīkaroti ca
]

`v 28 [
muhūrto vatsaraśreṇī lavaṇasyānayā kṛtā |
rātrirdvādaśavarṣāṇi hariścandrasya nirmitā
]

`v 29 [
viyogināmathānyeṣāṃ kāntāvibhavaśālinām |
rātrivatsaravaddīrghā bhavettasyāḥ prasādataḥ
]

`v 30 [
sukhitasyālpatāmeti duḥkhitasyaiti dīrghatām |
kālo yasyāḥ prasādena viparyāsaikaśīlinām
]

`v 31 [
asyāḥ svasattāmātreṇa kartṛtaitāsu vṛttiṣu |
dīpasyālokakāryāṇāṃ yathā tadvanna vastutaḥ
]

`v 32 [
sanitambastanī citre `note[tvitte iti pāṭhaḥ] na strī strīdharmiṇī yathā |
tathaivākāracinteyaṃ kartuṃ yogyā na kiṃcana
]

`v 33 [
manorājyamivākārabhāsurā satyavarjitā |
sahasraśataśāstrāpi na kiṃcitparamārthataḥ
]

`v 34 [
araṇye mṛgatṛṣṇeva mithyaivāḍambarānvitā |
viḍambayati tānmugdhamṛgāneva na mānuṣān
]

`v 35 [
phenamāleva saṃjātadhvastā vicchedavarjitā |
jaḍeva cañcalākārā gṛhyamāṇā na kiṃcana
]

`v 36 [
aṭatyuḍḍāmarākārā rajaḥprasaradhūsarā |
balātkalpāntavātyeva svākrāntabhuvanāntarā
]

`v 37 [
dhūmālīvāṅgasaṃlagnā dāhakhedapradāyinī |
garbhīkṛtarasākramya jaganti parivartate
]

`v 38 [
dhārā jaladharasyeva sudīrghā jalanirmitā |
asārasaṃsāradṛḍhā rajjustṛṇagaṇairiva
]

`v 39 [
asāraiḥ pelavaiḥ saṃsāraiḥ saṃsaraṇasaṃskārairdṛḍhā | tatra dṛṣṭāntaḥ ##-
p. 392) 232
taraṅgotpalamāleva kalpanāmātravarṇitā |
mṛṇālīva bahucchidrā paṅkaprauḍhā jalātmikā
]

`v 40 [
janena dṛśyate vṛddhitatparā naca vardhate |
viṣāsvāda ivāpātamadhurā'nte sudāruṇā
]

`v 41 [
naṣṭā dīpaśikhevaiṣā na jāne kveva gacchati |
mihikevāgradṛṣṭāpi gṛhyamāṇā na kiṃcana
]

`v 42 [
pāṃsumuṣṭirivākīrya prekṣitā pāramāṇavī |
ākāśanīlimevaiṣā nirnimittaiva dṛśyate
]

`v 43 [
dvicandramohavajjātā svapnavadvihitabhramā |
yathā nauyāyinaḥ sthāṇuspandastadvadihotthitā
]

`v 44 [
anayopahate citte dīrghakālamivākulaiḥ |
janairākalpyate dīrghasaṃsārasvapnavibhramaḥ
]

`v 45 [
anayopahate svasmiṃścitrāścetasi vibhramāḥ |
utpadyante vinaśyanti taraṅgāstoyagheriva
]

`v 46 [
manojñamapi satyaṃ ca dṛśyate sadasattayā |
amanojñamasatyaṃ ca dṛśyate sattayāpyasat
]

`v 47 [
padārtharathamārūḍhā bhāvanaiṣā balānvitā |
ākrāmati manaḥ kṣipraṃ vihagaṃ vāgurā yathā
]

`v 48 [
karuṇāsyandamānākṣī sravatkṣīralavastanī |
bhavatyullasitānandaṃ jananī gṛhiṇī yathā
]

`v 49 [
viṣīkaroti niḥsyandasaṃtarpitajagattrayam |
sudhārdrārdramapi kṣipraṃ pravṛddhaṃ bimbamaindavam
]

`v 50 [
unmattaravavetālanartanārambhasaṃbhramam |
sthāṇavaḥ saṃprayacchanti mūkā apyetayāndhayā
]

`v 51 [
saṃdhyādiṣu ca kāleṣu loṣṭapāṣāṇabhittayaḥ |
asyāḥ prasādāddṛśyante sarpājagaradṛṣṭibhiḥ
]

`v 52 [
eko'pi dvitayodeti yathā dviśaśidarśane |
dūramabhyāśatāṃ yāti svapne svamaraṇaṃ yathā
]

`v 53 [
ādīrghaṃ kṣaṇatāmeti kālasyeṣṭā yathā niśā |
kṣaṇo varṣamivābhāti kāntāvirahiṇāmiva
]

`v 54 [
na tadastīha yannāma na karotīyamuddhatā |
asyāstvakiṃcanāyāstu śaktatāṃ paśya rāghava
]

`v 55 [
saṃrodhayetprayatnena saṃvidevāśu saṃvidam |
saritsrotonirodhena śuṣyatyeṣā manonadī
]

`v 56 [
śrīrāma uvāca |
avidyamānayaivedaṃ pelavāṅgyā sutucchayā |
mithyābhāvanayā nāma citramandhīkṛtaṃ jagat
]

`v 57 [
arūpayā nirākṛtyā cārucetanahīnayā |
asatyevāpyanaśyantyā citramandhīkṛtaṃ jagat
]

`v 58 [
ālokena vinaśyantyā `note[vināśyantyā iti pāṭhaḥ] sphurantyā
tamasontare |
kauśikekṣaṇadharmiṇyā citramandhīkṛtaṃ jagat
]

`v 59 [
kukarmaikāntakāriṇyā na sahantyā vilokanam |
dehamapyavijānantyā citramandhīkṛtaṃ jagat
]

`v 60 [
sudīnācāradharmiṇyā nityaṃ prākṛtakāntayā |
anāratāstaṃgatayā citramandhīkṛtaṃ jagat
]

`v 61 [
anantaduḥkhākulayā sadaiva mṛtayānayā |
saṃbodhahīnayā yatra citramandhīkṛtaṃ jagat
]

`v 62 [
kāmakopaghāṅginyā tamaḥprasaravakrayā |
acireṇāśarīriṇyā citramandhīkṛtaṃ jagat
]

`v 63 [
svātmāndharūpāspadayā jaḍayā jāḍyajīrṇayā |
duḥkhadīrghapralāpinyā citramandhīkṛtaṃ jagat
]

`v 64 [
puruṣāsaṅgasaṅginyā rāgiṇyā kriyayānayā |
vidravantyā vivakṣāsu citramandhīkṛtaḥ pumān
]

`v 65 [
p. 393) 232
puruṣasya na yā śaktā soḍhumīkṣitumapyalam |
tayā striyāvaraṇayā citramandhīkṛtaḥ pumān
]

`v 66 [
na yasyāścetanaivāsti yāpyanaṣṭaiva naśyati |
tayā striyā paruṣayā citramandhīkṛtaḥ pumān
]

`v 67 [
anantaduṣprasaravilāsakāriṇī
kṣayodayonmukhasukhaduḥkhabhāginī |
iyaṃ prabho vigalati kena vā'samā
manoguhānilayanibaddhavāsanā
]