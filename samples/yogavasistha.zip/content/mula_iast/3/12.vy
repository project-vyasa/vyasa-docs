`v 1 [
dvādaśaḥ sargaḥ 12
śrīvasiṣṭha uvāca |
etasmātparamācchāntātpadātparamapāvanāt |
yathedamutthitaṃ viśvaṃ tacchṛṇūttamayā dhiyā
]

`v 2 [
suṣuptaṃ svapnavadbhāti bhāti brahmaiva sargavat |
sarvātmakaṃ ca tatsthānaṃ tatra tāvatkramaṃ śṛṇu
]

`v 3 [
tasyānantaprakāśātmarūpasyānantacinmaṇeḥ |
sattāmātrātmakaṃ viśvaṃ yadajasraṃ svabhāvataḥ
]

`v 4 [
p. 157)
tadātmani svayaṃ kiṃciccetyatāmiva gacchati |
agṛhītātmakaṃ saṃvidahaṃmarśanapūrvakam
]

`v 5 [
bhāvināmārthakalanaiḥ kiṃcidūhitarūpakam |
ākāśādaṇu śuddhaṃ ca sarvasminbhāti bodhanam
]

`v 6 [
tataḥ sā paramā sattā sacetaścetanonmukhī |
cinnāmayogyā bhavati kiṃcillabhyatayā tathā
]

`v 7 [
ghanasaṃvedanā paścādbhāvijīvādināmikā |
saṃbhavatyāttakalanā yadojjhati paraṃ padam
]

`v 8 [
sattaiva bhāvanāmātrasārā saṃsaraṇonmukhī |
tadā vastusvabhāvena tvanuttiṣṭhati tābhimām
]

`v 9 [
samanantaramevāsyāḥ `note[bhedasyāḥ iti pāṭhaḥ] svasattodeti śūnyatā |
śabdādiguṇabījaṃ sā bhaviṣyadabhidhārthadā
]

`v 10 [
idānīṃ mahābhūtasarga vivakṣuḥ prathamamākāśasargamāha -
samanantaramiti | asyā jīvasattāyāḥ samanantarameva svasattā
itarabhūtāvakāśadatvācchaūnyatāprāyā udeti | sūryādisargottaraṃ
bhaviṣyantīnāmākāśādyabhidhānāmāsamanprapadyate prakāśata ityādyaryadā |
9 |
ahaṃtodeti tadanu saha `note[bhūtāyathārtha(?) iti pāṭhaḥ]
vai kālasattayā |
bhaviṣyadabhidhārthena bījaṃ mukhyajagatsthiteḥ
]

`v 11 [
tasyāḥ śakteḥ parāyāstu svasaṃvedanamātrakam |
etajjālamasadrūpaṃ sadiṣodeti visphurat
]

`v 12 [
evaṃprāyātmikā saṃvidbījaṃ saṃkalpaśākhinaḥ |
bhavatyahaṃkārakaṇastataḥ spandatayā marut
]

`v 13 [
cidahaṃ tāvatī vyomaśabdatanmātrabhāvanāt |
svato ghanībhūya śanaiḥ svatanmātraṃ bhavatyalam
]

`v 14 [
bhāvināmārtharūpaṃ tadbījaṃ śabdoghaśākhinaḥ |
padavākyapramāṇākhyaṃ vedavṛndaṃ vikāsitam
]

`v 15 [
tasmādudepyatyakhilā jagacchrīḥ paramātmanaḥ |
śabdaughanirmitārthaughapariṇāmavisāriṇaḥ
]

`v 16 [
cidevaṃparivārā sā jīvaśabdena kathyate |
bhāviśabdārthajālena bījaṃ rupopaśākhinaḥ
]

`v 17 [
caturdaśavidhaṃ bhūtajālamāvalitāntaram |
jagajjaṭaragartaughaṃ prasaraṣyati vai tataḥ
]

`v 18 [
asaṃprāptāmivācārā cijjavātprasphuradvapuḥ |
sā caiva sparśatanmātraṃ bhāvanādbhavati kṣaṇāt
]

`v 19 [
p. 158)
pavanaskandhavistāraṃ bījaṃ sparśaughaśākhinaḥ |
sarvabhūtakriyāspandastasmātsaṃprasariṣyati
]

`v 20 [
tatraiva cidvilāsena prakāśo'nubhavādbhavet |
tejastanmātrakaṃ tattu bhaviṣyadabhidhārthakam
]

`v 21 [
tatsūryāgnivijṛmbhādibījamālokaśākhinaḥ |
tasmādrūpavibhedena saṃsāraḥ prasariṣyati
]

`v 22 [
bhāvayaṃstanutāmeva rasaskandha ivāmbhasaḥ |
svadanaṃ tasya saṅghasya rasatanmātramucyate
]

`v 23 [
bhāvivārivilāsātmā tadbījaṃ rasaśākhinaḥ |
anyonyasvadane tasmātsaṃsāraḥ prasariṣyati
]

`v 24 [
bhaviṣyadrūpasaṃkalpanāmāsau kalpanātmakaḥ |
saṃkalpātmaguṇairgandhatanmātratvaṃ prapaśyati
]

`v 25 [
bhāvibhūgolakatvena bījamākṛtiśākhinaḥ |
sarvādhārātmanastasmātsaṃsāraḥ prasariṣyati
]

`v 26 [
citā vibhāvyamānāni tanmātrāṇi parasparam |
svayaṃ pariṇatānyantarambunīva nirantaram
]

`v 27 [
tathaitāni vimiśrāṇi viviktāni punaryathā |
na śuddhānyupalabhyante sarvanāśāntameva hi
]

`v 28 [
saṃvittimātrarūpāṇi sthitāni gaganodare |
bhavanti vaṭajālāni yathā bījakaṇāntare
]

`v 29 [
prasavaṃ paripaśyanti śataśākhaṃ sphuranti ca |
paramāṇvantare bhānti kṣaṇātkalpībhavanti ca
]

`v 30 [
vivartameva dhāvanti nirvivartāni santi ca |
cidvedhitāni sarvāṇi kṣaṇātpiṇḍībhavanti ca
]

`v 31 [
tanmātragaṇametatsyātsā saṃkalpātmikā citiḥ |
vedanātrasareṇvābhamanākāraiva paśyati
]

`v 32 [
bījaṃ jagatsu nanu pañcakamātrameva
bījaṃ parāvyavahitasthitiśaktirādyā |
bījaṃ tadeva bhavatīti sadānubhūtaṃ
cinmātramevamajamādyamato jagacchrīḥ
]