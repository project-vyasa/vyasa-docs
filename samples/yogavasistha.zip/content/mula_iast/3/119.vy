`v 1 [
ekonaviṃśottaraśatatamaḥ sargaḥ 119
śrīvasiṣṭha uvāca |
ūrmikāsaṃvidā hema yathā vismṛtya hematām |
virauti nāhaṃ hemeti tathātmāhaṃtayānayā
]

`v 2 [
śrīrāma uvāca |
ūrmikāsaṃvidudayaḥ kathaṃ hemno yathā mune |
ahaṃtā cātmana iti yathāvadbrūhi me prabho
]

`v 3 [
śrīvasiṣṭha uvāca |
sata evāgamāpāyau praṣṭavyau nāsataḥ satā |
ahaṃtvamūrmikātvaṃ ca satī tu na kadācana
]

`v 4 [
p. 405) 238
hema `note[yadi hema grāhyaṃ tarhi hemni hemanimittamūrmikāṃ tvaṃ
gṛhāṇeti madhyasthena udito bhavatyarthātkretā tattadā
sormikeṇārthādvikretrā yaddīyate tadasti satyamityanvayaḥ | udite yadīti
saptamyantapāṭhe'rthātkretari madhyasthena iti udite sati ityādyanvayaḥ |
hemnīti nimittātkarmayoge iti saptamī] hemnyūrmikāṃ ca tvaṃ
gṛhāṇetyudito yadi |
yaddīyate sormikeṇa tattadasti na saṃśayaḥ
]

`v 5 [
śrīrāma uvāca |
evaṃ cettatprabho kiṃ syādūrmikātvaṃ tu kīdṛśam |
anayaivārthaniścityā jñāsyāmi brahmaṇo vapuḥ
]

`v 6 [
śrīvasiṣṭha uvāca |
rūpaṃ rāghava nīrūpamasataścennirūpyate |
tadbandhyātanayākāraguṇāṃstvaṃ samudāhara
]

`v 7 [
avicāritaramaṇīyaṃ tat vicārite tu na kiṃcidityāśayenottaramāha - rūpamiti | 6
|
ūrmikātvaṃ mudhā bhrāntirmāyaiṣā satsvarūpiṇī |
rūpaṃ tadetadevāsyāḥ prekṣitā yanna dṛśyate
]

`v 8 [
mṛgatṛṣṇāmbhasi dvīndāvahaṃtārūpakādiṣu |
etāvadeva rūpaṃ yatprekṣyamāṇaṃ na labhyate
]

`v 9 [
yaḥ śuktau rajatākāraṃ prekṣate rajatasya saḥ |
na saṃprāpnotyaṇumapi kaṇaṃ kṣaṇamapi kvacit
]

`v 10 [
aparyālokanenaiva sadivāsadvirājate |
yathā śuktau rajatatā jalaṃ marumarīciṣu
]

`v 11 [
yannāsti tasya nāstitvaṃ prekṣyamāṇaṃ prakāśate |
aprekṣyamāṇaṃ sphurati mṛgatṛṣṇāsvivāmbudhīḥ
]

`v 12 [
asadeva ca satkāryakaraṃ bhavati ca sthiram |
bālānāṃ maraṇāyaiva vetālabhrāntisaṃbhramaḥ
]

`v 13 [
hematāṃ varjayitvaikāṃ vidyate hemni netarat |
ūrmikākaṭakāditvaṃ tailādisikatāsviva
]

`v 14 [
nehāsti satyaṃ no mithyā yadyathā pratibhāvyate `note[bhāsata iti
pāṭhaḥ] |
tattathārthakriyākāri bālayakṣavikāravat
]

`v 15 [
sadvā bhavatvasadvāpi surūḍhaṃ hṛdaye hi yat |
tattadarthakriyākāri viṣasyevāmṛtakriyā
]

`v 16 [
paramaiṣaiva sā vidyā māyaiṣā saṃsṛtirhyasau |
asato niṣpratiṣṭhasya yadahaṃtvasya bhāvanam
]

`v 17 [
dṛṣṭāntaṃ vyutpādya dārṣṭāntike'pi tatsāmyamāha - parameṣaivetyādinā |
16 |
hemnyasti normikāditvamahantādyasti nātmani |
ahantābhāvavastvemaṃ svacche śānte site pare
]

`v 18 [
na sanātanatā kācinna ca kācidviriñcitā |
na ca brahmāṇḍatā kācinna ca kācitsutāditā
]

`v 19 [
na lokāntaratā kācinna ca svargāditā kvacit |
na merutā nāsuratā na manastvaṃ na dehatā
]

`v 20 [
na mahābhūtatā kācinna ca kāraṇatā kvacit |
na ca trikālakalanā na bhāvābhāvavastutā
]

`v 21 [
tvattāhantātmatā tattā sattā'sattā na kācana |
na kvacidbhedakalanā na bhāvo na ca rañjanā
]

`v 22 [
sarvaṃ śāntaṃ nirālambaṃ jagattvaṃ śāśvataṃ śivam |
anāmayamanābhāsamanāmakamakāraṇam
]

`v 23 [
na sannāsanna madhyāntaṃ na sarvaṃ sarvameva ca |
manovacobhiragrāhyaṃ śūnyācchūnyaṃ sukhātsukham
]

`v 24 [
p. 406) 239
śrīrāma uvāca |
avabuddhaṃ samaṃ brahma sarvameva mayādhunā |
tathāpi bhūyaḥ kathaya sargaḥ kimiva lokyate
]

`v 25 [
śrīvasiṣṭha uvāca |
pare śānte paraṃ nāma sthitamitthamidaṃtayā |
neha sargo na sargākhyā kācidasti kadācana
]

`v 26 [
mahārṇavāmbhasīvāmbu saṃsthitā parameśvare |
jalaṃ dravatvātspandīva nispandaṃ paramaṃ padam
]

`v 27 [
tatra sakṛdbhedasya tadākhyāyāśca nimittāpāyādeva asattvādityāśayena
vasiṣṭhaḥ pariharati - pare iti | paraṃ tattvaṃ pare śānte svasvabhāve eva
sthitaṃ na tāḥ pracyutam | itthaṃ ca pūrṇātmabhāvātsargastadākhyā ca idantayā
iha brahmaṇi nāsti kiṃtu tatsvabhāvenaivāstītyarthaḥ |
kadācanetyuktestādṛśasthiteḥ kādācitkatvābhāva uktaḥ | kimiva lokyate iti kiṃ
dṛṣṭāntasya praśna uta nimittasya | ādye bādhādbrahmībhūtanāmarūpasya
brahmasvarūpe sthitau dṛṣṭāntamuktvā yastato viśeṣastamāha - jalamiti | 26
|
bhāḥ svātmanīva kacati na kacatyeva tatpadam |
bhāsāṃ tattvaṃ hi kacanaṃ padaṃ tvakacanaṃ viduḥ
]

`v 28 [
adha ūrdhvaṃ varjayitvā yathābdherudare payaḥ |
sphuratyevaṃ pare cittvādidaṃ nāneva tatparam
]

`v 29 [
īṣadvidaḥ svayaṃ cittvāccetyatāmiva gacchati |
buddhyate sarga ityeva samāsthāsyati śāsvatam
]

`v 30 [
sargastu paramārthasya saṃjñetyeva viniścayaḥ |
nānāsti nāyamatyantamambarasya yathāmbaram
]

`v 31 [
cittātsargasamāpattiracittātsargasaṃkṣayaḥ |
pare paramasaṃśānte hemnīva kaṭakabhramaḥ
]

`v 32 [
sanneva sargo satyatvameti cittaśamodaye |
asatsattāmavāpnoti svataḥ saṃvedanodaye
]

`v 33 [
saṃvedanamahaṃtāvatsargasaṃbhramasaṃbhramaḥ |
asaṃvedanamāśāntaṃ paraṃ viddhi na tajjaḍam
]

`v 34 [
nāneva sargo nānāyaṃ jñasyaikātmaśivātmakaḥ |
puṃstvakarmakriyā senā mṛnmayī śilpināṃ yathā
]

`v 35 [
idaṃ pūrṇamanārambhamanantamanaghodaram |
pūrṇe pūrṇaparāpūraiḥ pūrṇamevāvatiṣṭhate
]

`v 36 [
yadayaṃ lakṣyate sargastadbrahma brahmaṇi sthitam |
nabho nabhasi viśrāntaṃ śāntaṃ śānte śive śivam
]

`v 37 [
mukurapratibimbasthe nagare navayojane |
yathā dūramadūraṃ ca tatheśe tadatatkramaḥ
]

`v 38 [
īśe brahmaṇi | tasya dūratvasya atasya sāmīpyasya vā kramaḥ paripāṭītyarthaḥ | 37
|
asadabhyuditaṃ viśvaṃ sadapyabhyuditaṃ sadā |
pratibhāsātsadābhāsamavastutvādasanmayam
]

`v 39 [
ādarśanagarākāre mṛgatṛṣṇāmbubhāsvare |
dvicandravibhramābhāse sarge'sminkaiva satyatā
]

`v 40 [
māyācūrṇaparikṣepādyathā vyomni purabhramaḥ |
tathā saṃvidi saṃsāraḥ sāro'sāraśca bhāsate
]

`v 41 [
p. 407) 239
yāvadvicāradahanena samūladāhaṃ
dagdhā na jarjaralateva balādavidyā |
śākhāpratānagahanāni bahūni tāva-
nnānāvidhāni sukhaduḥkhavanāni sūte
]