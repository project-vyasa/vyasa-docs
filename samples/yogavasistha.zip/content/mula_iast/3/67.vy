`v 1 [
saptaṣaṣṭitamaḥ sargaḥ 67
śrīrāma uvāca |
manastvayogyo jīvo'yaṃ ko bhavetparamātmanaḥ |
kathaṃ vāsminsamutpannaḥ ko vāyaṃ vada me punaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
samastaśaktikhacitaṃ brahma sarveśvaraṃ sadā |
yayaiva śaktyā sphurati prāptāṃ tāmeva paśyati
]

`v 3 [
svayaṃ yāṃ vetti sarvātmā ciraṃ cetanarūpiṇīm |
sā proktā jīvaśabdena saiva saṃkalpakāriṇī
]

`v 4 [
svabhāvātkāraṇaṃ dvitvaṃ pūrvasaṃkalpacitsvayam |
nānākāraṇatāṃ paścādyāti janmamṛtisthiteḥ
]

`v 5 [
śrīrāma uvāca |
evaṃ sthite muniśreṣṭha daivaṃ nāma kimucyate |
kimucyate tathā karma kāraṇaṃ ca kimucyate
]

`v 6 [
etāvataiva praśnaśeṣasyāpyuttaramuktaprāyamiti manyamāno rāma uktajīvasya
janmādinimittadaivakarmakāraṇāni tattvato jijñāsuḥ pṛcchati - evamiti |
evamuktavidhayā jīvasvarūpe sthite buddhau pratiṣṭhite sati pṛcchāmīti śeṣaḥ | 5
|
p. 292) 179
śrīvasiṣṭha uvāca |
spandāspandasvabhāvaṃ hi cinmātramiha vidyate |
khe vāta iva tatspandātsollāsaṃ śāntamanyathā
]

`v 7 [
cittvaṃ cittaṃ bhāvitaṃ satspanda ityucyate budhaiḥ |
dṛśyatvabhāvitaṃ caitadaspandanamiti smṛtam
]

`v 8 [
spandātsphurati citsargo niḥsapndādbrahma śāśvatam |
jīvakāraṇakarmādyā citspandasyābhidhā smṛtā
]

`v 9 [
ya evānubhavatmāyaṃ citspando'sti sa eva hi |
jīvakāraṇakarmākhyo bījametaddhi saṃsṛteḥ
]

`v 10 [
teṣāṃ cānubhavasattālambanenaiva sattā svakāryakṣamatā cetyāha - ya eveti |
9 |
kṛtadvitvacidābhāsavaśāddehamupasthitam |
saṃkalpādvividhārthatvaṃ citspando yāti sṛṣṭiṣu
]

`v 11 [
nānākāraṇatāṃ yātaścitspando mucyate cirāt |
kaścijjanmasahasreṇa kaścidekena janmanā
]

`v 12 [
svabhāvātkāraṇādvitvaṃ citsametyādhigacchati |
svargāpavarganarakabandhakāraṇatāṃ śanaiḥ
]

`v 13 [
hemnīva kaṭakāditvaṃ kāṣṭhaloṣṭasamasthitau |
dehe tiṣṭhati nānātvaṃ jaḍe bhāvavikārajam
]

`v 14 [
ajātamapyasadrūpaṃ paśyatīdaṃ manobhramaḥ |
jātaḥ sthito mṛto'smīti bhramārtaḥ pattanaṃ yathā
]

`v 15 [
ahaṃmametyasadrūpameva cetaḥ prapaśyati |
adṛṣṭaparamārthatvādāśāvivaśasaṃsthiti
]

`v 16 [
mathurādhipate rājño yathā śvapacasaṃbhramaḥ |
āsīdevaṃ hi cittasya sphuratīyaṃ jagatsthitiḥ
]

`v 17 [
sarvameva manomātrabhrāntyulāsavijṛmbhaṇam |
idaṃ jagattayā rāma prasphuratyambubhaṅgavat
]

`v 18 [
śivātprākkāraṇātpūrvaṃ ciccetyakalanonmukhī |
udeti saumyājjaladheḥ payaḥspando manāgiva
]

`v 19 [
sphuraṇājjīvacakratvameti cittormitāṃ dadhat |
cidvāribrahmajaladhau kurute sargabudbudān
]

`v 20 [
svasthaḥ saumya samasyaitadyatsiṃhasya vijṛmbhaṇam |
brahmaṇaḥ saṃvidābhāsastatsaṃcetyamiva svayam
]

`v 21 [
citsaṃvittyocyate jīvaḥ saṃkalpātsa mano bhavet |
buddhiścittamahaṃkāro māyetyādyabhidhaṃ tataḥ
]

`v 22 [
p. 293) 179
tanmātrakalpanā pūrvaṃ tanotīdaṃ jaganmanaḥ |
asatyaṃ satyasaṃkāśaṃ gandharvanagaraṃ yathā
]

`v 23 [
yathā śūnye dṛśaḥ sphārānmuktāvalyādidarśanam |
yathā svapne bhramaścaiva tathā cittasya saṃsṛtiḥ
]

`v 24 [
śuddha ātmā nityatṛpta iva śāntaḥ samasthitaḥ |
apaśyanpaśyatīvemaṃ cittākhyaṃ svapnavibhramam
]

`v 25 [
saṃsṛtirjāgradityuktaṃ svapnaṃ vidurahaṃkṛtim |
cittaṃ suṣuptabhāvaḥ syāccinmātraṃ turyamucyate
]

`v 26 [
atyantaśuddhe sanmātre pariṇāmanirāmayam |
turyātītaṃ padaṃ tatsyāttatstho bhūyo na śocati
]

`v 27 [
tasminsarvamudetīdaṃ tasminneva pralīyate |
na cedaṃ na ca tatredaṃ dṛṣṭau muktāvalī yathā
]

`v 28 [
arodhakatvātkhaṃ heturyathā vṛkṣasamunnateḥ |
akartāpi tathā kartā cetanābdhirjagatsthiteḥ
]

`v 29 [
saṃnidhānādyathā lauhaḥ pratibimbasya hetutām |
yātyādarśastathaivāyaṃ cinmayo'pyarthavedane
]

`v 30 [
bījamaṅkurapatrādiyuktyā yadvatphalaṃ bhavet |
cinmātraṃ cittajīvādiyuktyā tadvanmano bhavet
]

`v 31 [
svatobījaphalā vipruḍ yathā bījaṃ punarbhavet |
tathā ciccetyacittādi tyaktvā svasthā na tiṣṭhati
]

`v 32 [
yadyapyabodhe bodhe vā bījāntastarubījayoḥ |
iyānbhedo'sti na jagadbrahmaṇorapi cittayoḥ
]

`v 33 [
tathāpi vyajyate bodhe satyātmakamakhaṇḍitam |
rūpaśrīriva dīpena cinmātrālokarūpi yat
]

`v 34 [
yadyannikhanyate bhūmeryathā tattannabho bhavet |
yā yā vicāryate vidyā tathā sā sā paraṃ bhavet
]

`v 35 [
sphaṭikāntaḥsanniveśaḥ sthāṇutā'vedanādyathā |
śuddhe'nānāpi nāneva tathā brahmodare jagat
]

`v 36 [
brahma sarvaṃ jagadvastu piṇḍamekamakhaṇḍitam |
phalapatralatāgulmapīṭhabījamiva sthitam
]

`v 37 [
śrīrāma uvāca |
aho citraṃ jagadidamasatsadiva bhāsate |
aho bṛhadaho svasthamaho sphuṭamaho tanu
]

`v 38 [
brahmaṇi pratibhāsātmā tanmātraguṇagolakaḥ |
avaśyāyakaṇābhāso yathā sphurati tacchrutam
]

`v 39 [
yathā'sau yāti apulyaṃ yathā bhavati cātmabhūḥ |
yathā svabhāvasiddhārthāttathā kathaya me prabho
]

`v 40 [
p. 294) 180
śrīvasiṣṭha uvāca |
atyantāsaṃbhavadrūpamananyatsvasvabhāvataḥ |
atyantānanubhūtaṃ satsvānubhūtamivāgrataḥ
]

`v 41 [
ullāsaphullo phullāṅga iti bālahṛdi sphuṭam |
yathodeti tathodeti pare brahmaṇi jīvatā
]

`v 42 [
mānameyātmikā śuddhā satyaivāsatyavaststhitā |
bhinneva ca na bhinnā syādbrahmaṇo bṛṃhaṇātmikā
]

`v 43 [
yathā brahma bhavatyāśu jīvaḥ kalanajīvitaḥ |
tathā jīvo bhavatyāśu mano mananavedanāt
]

`v 44 [
cittaṃ tanmātramananaṃ paśyatyāśu svarūpavat |
eṣa sadyo'nilalavaprakhyaḥ sphurati khāntare
]

`v 45 [
astanimeṣo'nubhavatyavaśyāyakaṇopamam |
saṃvedanātmakaṃ kālakalitaṃ kāntamātmani
]

`v 46 [
ahaṃkimiti śabdārthavedanābhogasaṃvidam |
saṃvidaṃ tattvaśabdārthaṃ jīvaḥ paśyati sārthakam
]

`v 47 [
tādṛkṣavedanātso'tha rasaśabdārthavedanam |
bhāvijihvārthanāmnaikadeśe'nubhavati kṣaṇāt
]

`v 48 [
tādṛkṣavedanāttejaḥśabdārthonmukhatāṃ gataḥ |
bhaviṣyannetranāmnaikadeśe bhavati bhāsanam
]

`v 49 [
tādṛkṣavedanātso'tha ghrāṇaṃ tadvṛṣṭivedanāt |
sthito yasminbhavatīti tāvaddṛśyāditā sthitā
]

`v 50 [
evaṃprāyaḥ sa jīvātmā kākatālīyavacchanaiḥ |
viśiṣṭasaṃniveśatvaṃ bhāvitaṃ paśyati svataḥ
]

`v 51 [
tasya saṃghātābhimānamāha - viśiṣṭeti | bhāvitaṃ prāgvāsanākalpitam | 50
|
sa tasya saṃniveśasya tvasato'pi sataḥ sataḥ |
śabdabhāvaikadeśatvaṃ śravaṇārthena vindati
]

`v 52 [
sparśabhāvaikadeśatvaṃ tvakśabdārthena vindati |
rasabhāvaikadeśatvaṃ rasanātvena vindati
]

`v 53 [
rūpabhāvaikadeśatvaṃ netrārthākṛti paśyati |
gandhabhāvaikadeśatvaṃ nāsikātvena paśyati
]

`v 54 [
evaṃ bhāvamayaiḥ sattāprakaṭīkaraṇakṣamam |
bhaviṣyadindriyākhyaṃ sa radhraṃ paśyati dehake
]

`v 55 [
ityevamādi jīvasya rāghavādyatanasya ca |
udeti pratibhāsātmā deha evātivāhikaḥ
]

`v 56 [
anākhyeyaṃ parā sattāsyātivāhikatāmiva |
sā gacchatyapyagacchantī tādṛksatyātmabhāvanāt
]

`v 57 [
mātṛmeyapramāṇādi yadā brahmaiva vedanāt |
tadātivāhikoktīnāṃ kaḥ prasaṅgastadeva tat
]

`v 58 [
anyatvavedanādanyaḥ parasmādātivāhikaḥ |
brahmatvavedanādbrahma sā saṃvittirhi nānyajā
]

`v 59 [
śrīrāma uvāca |
asaṃbhavādasaṃvitterbrahmātmaikatayāthavā |
ko mokṣaḥ ko vicāraścetyalaṃ bhedavikalpanaiḥ
]

`v 60 [
p. 295) 180
śrīvasiṣṭha uvāca |
siddhānta evaiṣa praśnaste rāma rājate |
akālapuṣpamālā hi śobhanāpi na śobhate
]

`v 61 [
sārthaivānarthikā'kālamālā vilāsitā yathā |
tathaivā'kālamijjantau sarvaṃ kāle hi śobhate
]

`v 62 [
pratibandhābhyanujñānāṃ kālo dāteti dṛśyate |
nanu sarvapāarthānāṃ kālena phalayogataḥ
]

`v 63 [
evameva sa jīvātmā svapnātmā samupasthitaḥ |
pitāmahatvamucchranaṃ paśyannātmani kālataḥ
]

`v 64 [
oṃmuccāraṇasaṃvittivedanācca prapaśyati |
yatkaroti manorājyaṃ bhavatyāśu sa tanmayaḥ
]

`v 65 [
idamevamasatsarvamiva vyomni tatātmani |
parvatoccākṛtirvyoma jagadvyomni vijṛmbhate
]

`v 66 [
neha prajāyate kiṃcinneha kiṃcidvinaśyati |
jagadgandharvanagararūpeṇa brahma jṛmbhate
]

`v 67 [
yathaiva padmajādīnāṃ jīvānāṃ sadasanmayī |
sattā tathaiva sarveṣāmāsarīsṛpamāsuram
]

`v 68 [
saṃvitsaṃbhrama evāyamevamabhyutthito'pyasan |
ābrahmakīṭasaṃvitteḥ samyaksaṃvedanātkṣayaḥ
]

`v 69 [
yathā saṃpadyate brahmā kīṭaḥ saṃpadyate tathā |
kīṭastu rūḍhabhūtaughavalanāttucchakarmakaḥ
]

`v 70 [
yadeva jīvanaṃ jīve cetyonmukhacidātmakam |
tadeva pauruṣaṃ tasminsāraṃ karma tadeva ca
]

`v 71 [
brahmaṇaḥ sukṛtātpāpātkīṭakasya samutthiteḥ |
cittanmātrātmikā `note[ajñātā yā cit tanmātrātmikā pūrvaṃ
ṣaṭpañcāśaśloke anākhyeyaṃ parā sattā iti mūle atratu anākhyeyaṃ
paraṃ brahma iti vartate tatra sadasadviśairvicāraṇīyam] bhrāntiḥ
prekṣāmātraṃ bhavetkṣayaḥ
]

`v 72 [
mātṛmānaprameyāṇi na cinmātretaradyataḥ |
tato dvaitaikyavādārthaḥ śaśaśṛṅgābjnīsamaḥ
]

`v 73 [
bhāvadārḍhyātmakaṃ mithyā brahmānando vibhāvyate |
ātmaiva kośakāreṇa lālādārḍhyātmakaṃ yathā
]

`v 74 [
yadi na dvaitaṃ mānaseyaṃ tarhi kathaṃ
kuddālakoṭidurbhedabhuvanādibhāvadārḍhyātmakaṃ pratīyate tatrāha -
bhāvadārḍhyātmakamiti | brahmānandātmaka ātmaiva
bandhakabhuvanādibhāvadārḍhyātmakaṃ dvaitamiti bhrāntyānubhūyate | yathā
kośakārakīṭena svalālādārḍhyātmakaṃ bandhanamanubhūyate tadvadityarthaḥ |
73 |
p. 296) 181
manasā brahmaṇā yadyadyathā dṛṣṭaṃ vibhāvitam |
tattathā dṛśyate tajjñaiḥ svabhāvasyaiṣa niścayaḥ
]

`v 75 [
yathā yaduditaṃ vastu tattattanna vinā bhavet |
nimeṣamapi kalpaṃ vā svabhāvasyaiṣa niścayaḥ
]

`v 76 [
alīkamidamutpannamalīkaṃ ca vivardhate |
alīkameva svadate tathālīkaṃ vilīyate
]

`v 77 [
śuddhaṃ sarvagataṃ brahmānantamadvitīyaṃ `note[1]
duḥkhabodhavaśāda-
śuddhamivāsadivānekamivāsarvagamivāvabudhyate
]

`v 78 [
jalamanyattaraṅgo'nya iti bālakukalpanayā bhedaḥ kalpyata
evamavāstavastasmādyo yo'yamābhāti bhedaḥ sa kevalamatattvavidbhiḥ
parikalpito rajjvāṃ sarpa iva evaṃ bhedābhedaśaktyorarimitrayoreva
brahmaṇyeva saṃbhavet
]

`v 79 [
tenātmanā'dvitīyenaiva dvitvamivātataṃ yathā salilena taraṃgakalpanayā
suvarṇena kaṭakakalpanayaivamiti atastena svayamevātmanātmānya iva cetyate
]

`v 80 [
ataḥ kalanā jātā saiva sphāratāṃ prāpya manaḥ saṃpannaṃ
tenāhaṃbhāvaḥ kalpito nirvikalpapratyakṣarūpametatprathamaṃ
tanmanastadahaṃ bhavati kṣipramahaṃśabdārthabhāvanāt
]

`v 81 [
tato manohaṃkārābhyāṃ smṛtiranusaṃhitā
taistribhistadanubhūtatanmātrāṇi kalpitāni tanmātreṣu jīvena cittātmanā
svayaṃ kākatālīyavadbrahmopādānādiyānsaṃniveśaḥ kalpito dṛśyate |
81 |
anusaṃhitā yathānubhavamutpāditā | tayā smṛtyā anubhūtāni yathānubhavaṃ
smṛtāni | kalpitāni sṛṣṭāni | jīvena brahmalakṣaṇādupādānakāraṇādiyān
brahmāṇḍavistṛto jagatsaṃniveśaḥ kalpitaḥ | hastapādādimān iti pāṭhāntare
spaṣṭam
]

`v 82 [
evaṃ yadeva manaḥ kalpayati tadeva paśyati |
sadvā bhavatvasadvā cittaṃ yatkalpayatyabhiniviṣṭam |
tattatpaśyati yāsyati sadiva pratibhāsamupagataṃ sadyaḥ
]