`v 1 [
caturviṃśaḥ sargaḥ 24
śrīvasiṣṭha uvāca |
dūrāddūramabhiplutya śanairuccaiḥ padaṃ gate |
hastaṃ haste samālambya yāntyau dadṛśaturnabhaḥ
]

`v 2 [
ekārṇavamivocchūnaṃ gambhīraṃ nirmalāntaram |
komalaṃ komalamarudāsaṅgasukhabhogadam
]

`v 3 [
āhlādakamalaṃ saumyaṃ śūnyatāmbhonimajjanāt |
atyantaśuddhaṃ gambhīraṃ prasannamapi sajjanāt
]

`v 4 [
śṛṅgasthanirmalāmbhodapīnodarasudhālaye |
viśaśramaturāśāsu pūrṇacandrodarāmale
]

`v 5 [
siddhagandharvamandāramālāmodamanohare |
candramaṇḍalaniṣkrānte remāte madhurānile
]

`v 6 [
sasnaturbhūrigharmānte taḍidraktābjasaṃkule |
sarasīva jalāpūramanthare meghamaṇḍale
]

`v 7 [
p. 187)
bhūtalaughamahāśailamṛṇālāṅkurakoṭiṣu |
dikṣu babhramatuḥ svairaṃ bhramaryau sarasīṣviva
]

`v 8 [
dhārāgṛhadhiyā dhīragaṅgānirjharaghāriṇi |
bhrematurvātavikṣubdhameghamaṇḍalamaṇḍape
]

`v 9 [
tato madhuragāminyau viśrāmyantyau svaśaktitaḥ |
śūnye dadṛśaturvyoma mahārambhātimantharam
]

`v 10 [
adṛṣṭapūrvamanyonyaṃ sarvasaṃkaṭakoṭaram |
apūryamāṇamāśūnyaṃ jagatkoṭiśatairapi
]

`v 11 [
uparyuparyuparyuccairanyairanyairvṛtaṃ pṛthak |
vicitrābharaṇākārairbhūtalaiḥ suvimānakaiḥ
]

`v 12 [
paritaḥ pūritavyomnāṃ mervādikulabhūbhṛtām |
padmarāgataṭoddyotaiḥ kalpajvālopamodaram
]

`v 13 [
muktāśikharabhāpūrairhimavatsānusundaram |
kāñcanādristhalārcirbhiḥ kāñcanasthalabhāsuram
]

`v 14 [
mahāmarakatābhābhiḥ śādvalasthalanīlimam |
draṣṭṛdṛśyakṣayāsaktajātadhvāntotthakālimam
]

`v 15 [
pārijātalatālolavimānagaṇaketanam |
ato mañjarikākāramiva vaidūryabhūtalam
]

`v 16 [
manovegamahāsiddhajitavātagamāgamam |
vimānagṛhadevastrīgeyavādyasaghuṃghumam
]

`v 17 [
trailokyavarabhūtaughasaṃcārāviralāntaram `note[saṃcāraviralāṃ iti
pāṭhaḥ] |
anyonyādṛṣṭasaṃcārasurāsurakulākulam
]

`v 18 [
paryantasthitakūṣmāṇḍarakṣaḥpaiśācamaṇḍalam |
vātaskandhamahāvegavahadvaimānikavrajam
]

`v 19 [
vahadvimānasītkāramuṣṭigrāhyaghanadhvani |
graharkṣaghanasaṃcārātpracaladvātayantrakam
]

`v 20 [
nikaṭātapadagdhālpasiddhasiddhojjhitāspadam |
arkāśvamukhavātāstadagdhamugdhavimānakam
]

`v 21 [
lokapālāpsarovṛndasaṃcārācāracañcalam |
devyantaḥpurikādagdhadhūpadhūmāmbudāmbaram
]

`v 22 [
svasvargāhūtadevastrīsvāṅgavibhraṣṭabhūṣaṇam |
sāmānyasiddhasaṅghogratejaḥpuñjatamobalam
]

`v 23 [
balavatsiddhasaṃghaṭṭagamāgamavighaṭṭitaiḥ |
ghanaiḥ sāṃśukapārśvasthahimavanmerumandaram
]

`v 24 [
kākolūkairgṛdhrabhāsai rāśibhūtaiścalairvṛtam |
nṛtyadbhirḍākinīsaṅghaistaraṅgairiva vāridhim
]

`v 25 [
pravṛttairyoginīsaṅghaiḥ śvakākoṣṭrasvarānanaiḥ |
nirarthaṃ yojanaśataṃ gatvāgacchadbhirāvṛtam
]

`v 26 [
p. 188)
lokapālapurodhvāntadhūmadhūmre'bhramandire `note[dhūgrābhramandiraṃ
iti pāṭhaḥ] |
siddhagandharvamithunaprārabdhasuratotsavam
]

`v 27 [
svargagītastavonmattamadanākrāntamārgagam |
anāratavahaddhiṣṇyacakralakṣitapakṣakam
]

`v 28 [
vātaskandhanikhātāntarvahattripathagājalam |
āścaryālokanavyagrasaṃcarattridaśārbhakam
]

`v 29 [
sadehasaṃcaradvajracakraśūlāsiśaktimat |
kvacinnirbhitti bhavanaṃ gāyannāradatumburu
]

`v 30 [
meghamārgamahāmeghamahārambhākulaṃ kvacit |
citranyastasamākāramūkakalpāntavāridam
]

`v 31 [
utpatatkajjalādrīndrasundarāmbhodharaṃ kvacit |
kvacitkanakaniṣpandakāntatāpāntavāridam
]

`v 32 [
kvaciddigdāhatāpāḍhyamṛṣyamūkāmbudāṃśukam |
kvacinniṣpavanāmbhodhisaṃrambhaṃ śūnyatājalam
]

`v 33 [
kvacidvātanadīprauḍhavimānatṛṇapallavam |
kvaciccaladalivrātapṛṣṭhatvakkāntinirmalam
]

`v 34 [
kvacinmerunadīkalpavātadhūlividhūsaram |
kvacidvimānagīrvāṇaprabhācitrablāṅgakam
]

`v 35 [
kvacinnirambaronnṛttamātṛmaṇḍalamālitam `note[nirantaronnṛtta iti
pāṭhaḥ] |
kvacinnityaṃ navakṣībakṣubdhayogīśvarīgaṇam
]

`v 36 [
kvacicchāntasamādhisthaviśrāntamunimālitam |
samaṃ dūrāstasaṃrambhasādhucittamanoharam
]

`v 37 [
gāyatkinnaragandharvasurastrīmaṇḍalaṃ kvacit |
kvacitstabdhapurākīrṇaṃ vahatpuravaraṃ kvacit
]

`v 38 [
stabdhairniścalaiḥ purairākīrṇam | vahanti bhramanti tripurādipuravarāṇi yasmin |
37 |
kvacidrudrapurāpūrṇaṃ kvacidbrahmamahāpuram |
kvacinmāyākṛtapuraṃ kvacidāgāmipattanam
]

`v 39 [
kvacidbhramaccandrasaraḥ kvacitstabdhamayaṃsaraḥ |
kvacitsaratsiddhagaṇaṃ kvacidindukṛtodayam
]

`v 40 [
kvacitsūryodayamayaṃ kvacidrātritamomayam |
kvacitsaṃdhyāṃśukapilaṃ kvacinnīhāradhūsaram
]

`v 41 [
kvaciddhimābhradhavalaṃ kvacidvarṣatpayodharam |
kvacitsthala ivākāśa eva viśrāntalokapam
]

`v 42 [
ūrdhvādhogamanavyagrasurāsuragaṇaṃ kvacit |
pūrvāparottarāyāmyadiksaṃcārākulaṃ kvacit
]

`v 43 [
aparāśabdaḥ pratīcīparaḥ pariśeṣāt | uttarā yāmyeti sarvanāmno
vṛttāvapuṃvadbhāvaśchāndasaḥ | diśaḥ saṃcarantīti diksaṃcārāstairākulam |
42 |
api yojanalakṣāṇi kvacidduṣprāpabhūdharam |
avināśitamaḥpūrṇaṃ dṛṣadgarghopamaṃ kvacit
]

`v 44 [
avināśibṛhattejaḥ kvacidarkānalopamam |
himānījaṭharāśītaṃ kvaciccandrādisamasu
]

`v 45 [
kvacidvahatpurovṛttakalpavṛkṣalatāvanam |
kvaciddaityahatottuṅgaprapataddevapattanam
]

`v 46 [
vaimānikanipātena vahnilekhāṅkitaṃ kvacit |
kvacitketuśatotpātamithaḥsaṃghaṭṭapaṭṭitam
]

`v 47 [
kvacicchubhagrahagaṇapragṛhītāgryamaṇḍalam |
kvacidrātritamovyāptaṃ kvaciddivasabhāsvaram
]

`v 48 [
kvacidudgarjadambhodaṃ kvacinmūkāmalāmbudam |
vātāvakīrṇaśuklābhrakhaṇḍapuṣpottaraṃ kvacit
]

`v 49 [
p. 189)
kvacidatyantaniḥśūnyamavadātamanantaram |
ānandamṛduśāntācchaṃ jñasyeva hṛdayaṃ tatam
]

`v 50 [
śukravāhanabhekaughaiḥ kvacidgalakṛtāravam |
śūnyatāvārivalitaṃ kṣetramākāśavāsinām
]

`v 51 [
mayūrahemacūḍādipakṣibhiḥ kvacidāvṛtam |
vidyādharīṇāṃ devīnāṃ vāhanairvihitāspadaiḥ
]

`v 52 [
kvacidabhrāntaronnṛtyadguhamāyūramaṇḍalam |
kvacidagniśukaiḥ śyāmaṃ śādvalānāmiva sthalam
]

`v 53 [
kvacitpreteśamahiṣamahimnā vāmanāmbudam |
kvacidaśvaistṛṇagrāmaśaṅkāgrastāsitāmbudam
`note[grastāmitāmbudaṃ iti pāṭhaḥ]
]

`v 54 [
kvaciddevapuravyāptaṃ kvaciddaityapurānvitam |
anyonyāprāpyanagaraṃ nagarandhrakarānilam
]

`v 55 [
kvacitkulācalākāranṛtyadbhairavabhāsuram |
kvacitsapakṣaśailendrasamanṛtyadvināyakam
]

`v 56 [
kvaciddhargharavātaughapakṣaproḍḍīnaparvatam |
kvacidgandharvanagarasurastrīvṛndabandhuram
]

`v 57 [
kvacidvahadgiridhvastavṛkṣalakṣocchritāmbudam |
kvacinmāyākṛtākāśanalinījalaśītalam
]

`v 58 [
kvacidindukarākṛṣṭiśītalāhlādamārutam |
kvacittaptānilādagdhadrumaparvatavāridam
]

`v 59 [
kvacidatyantasaṃśāntavātādekāntanirdhvani |
kvacitparvatatulyābhraśikhākūṭaśatodayam
]

`v 60 [
kvacitprāvṛḍbhavonmattaghanābhraravaghargharam |
kvacitsurāsuragaṇapravṛttaraṇadurgamam
]

`v 61 [
kvacidvyomābjinīhaṃsīsvanāhūtābjavāhanam |
kvacinmandākinītīranalinīluṇṭhakānilam
]

`v 62 [
svaśarīreṇa gaṅgādisaritāṃ sannidhānataḥ |
proḍḍīnamatsyamakarakulīrāmbujakūrmakam
]

`v 63 [
pātālagārkajanitabhūcchāyākākacopanaiḥ |
kvacitkvacinmaṇḍaleṣu grastacandrārkamaṇḍalam
]

`v 64 [
kvacitsargānilādhūtamāyākusumakānanam |
patatpuṣpahimāsāratrasadvaimānikāṅganam
]

`v 65 [
udumbarodaramaśakakramabhrama-
jjagattrayāntaragatabhūtasaṃcayam |
vilaṅghya tadvaralalane khamuccakai-
rmahītalaṃ punarapi gantumudyate
]