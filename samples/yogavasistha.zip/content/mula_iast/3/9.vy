`v 1 [
navamaḥ sargaḥ 9
śrīvasiṣṭha uvāca |
taccittāstadgataprāṇā bodhayantaḥ parasparam |
kathayantaśca tannityaṃ tuṣyanti ca ramanti ca
]

`v 2 [
teṣāṃ jñānaikaniṣṭhānāmātmajñānavicāriṇām |
sā jīvanmuktatodeti videhānmuktataiva yā
]

`v 3 [
p. 147)
śrīrāma uvāca |
brahmanvidehamuktasya jīvanmuktasya lakṣaṇam |
brūhi yena tathaivāhaṃ yate śāstradṛśā dhiyā
]

`v 4 [
śrīvasiṣṭha uvāca |
yathāsthitamidaṃ yasya vyavahāravato'pi ca |
astaṃ gataṃ sthitaṃ vyoma jīvanmuktaḥ sa ucyate
]

`v 5 [
bodhaikaniṣṭhatāṃ yāto jāgratyeva suṣuptavat |
yā āste vyavahartaiva jīvanmuktaḥ sa ucyate
]

`v 6 [
nodeti nāstamāyāti sukhe duḥkhe mukhaprabhā |
yathāprāptasthiteryasya jīvanmuktaḥ sa ucyate
]

`v 7 [
yo jāgarti suṣuptastho yasya jāgranna vidyate |
yasya nirvāsano bodhaḥ sa jīvanmukta ucyate
]

`v 8 [
rāgadveṣabhayādīnāmanurūpaṃ carannapi |
yo'ntarvyomavadacchasthaḥ sa jīvanmukta ucyate
]

`v 9 [
yasya nāhaṃkṛto bhāvo yasya buddhirna lipyate |
kurvato'kurvato vāpi sa jīvanmukta ucyate
]

`v 10 [
yasyonmeṣanimeṣārdhādvidaḥ pralyasaṃbhavau |
paśyettrilokyāḥ svasamaḥ sa jīvanmukta ucyate
]

`v 11 [
yasmānnodvijate loko lokānnodvijate ca yaḥ |
harṣāmarṣabhayonmuktaḥ sa jīvanmukta ucyate
]

`v 12 [
śāntasaṃsārakalanaḥ kalāvānapi niṣkalaḥ |
yaḥ sacitto'pi niścittaḥ sa jīvanmukta ucyate
]

`v 13 [
yaḥ samastārthajāteṣu vyavahāryapi śītalaḥ |
padārtheṣvapi pūrṇātmā sa jīvanmukta ucyate
]

`v 14 [
jīvanmuktapadaṃ tyaktvā dehe kālavaśīkṛte |
viśatyadehamuktatvaṃ pavano'spandatāmiva
]

`v 15 [
videhamukto nodeti nāstameti na śāmyati |
na sannāsanna dūrastho na cāhaṃ na ca netaraḥ
]

`v 16 [
sūryo bhūtvā pratapati viṣṇuḥ pāti jagattrayam |
rudraḥ sarvānsaṃharati sargānsṛjati padmajaḥ
]

`v 17 [
khaṃ bhūtvā pavanaskandhaṃ dhatte sarpisurāsuram |
kulācalagato bhūtvā lokapālapurāspadaḥ
]

`v 18 [
bhūmirbhūtvā bibhartīmāṃ lokasthitimakhaṇḍitām |
tṛṇagulmalatā bhūtvā dadāti phalasaṃtatim
]

`v 19 [
bibhrajjalānalākāraṃ jvalati dravati drutam |
candro'mṛtaṃ prasavati mṛtaṃ hālāhalaṃ viṣam
]

`v 20 [
tejaḥ prakaṭayatyāśāstanotyāndhyaṃ tamo bhavat |
śūnyaṃ sadvyomatāmeti giriḥ san rodhayatyalam
]

`v 21 [
karoti jaṃgamaṃ cittaḥ sthāvaraṃ sthāvarākṛtiḥ |
bhūtvārṇavo balayati bhūstriyaṃ valayo yathā
]

`v 22 [
paramārkavapurbhūtvā prakāśāntaṃ viasārayan |
trijagattrasareṇvoghaṃ `note[trijagattrasareṇvantaṃ iti pāṭhaḥ]
śāntamevāvatiṣṭhate
]

`v 23 [
p. 148)
yatkiṃcididamābhāti bhātaṃ bhānamupaiṣyati |
kālatrayagataṃ dṛśyaṃ tadasau sarvameva ca
]

`v 24 [
śrīrāma uvāca |
kathamevaṃ vada brahmanbhūyate viṣamā hi me |
dṛṣṭireṣātha duṣprāpyā durākramyeti niścayaḥ
]

`v 25 [
śrīvasiṣṭha uvāca |
muktireṣocyate rāma brahmaitatsamudāhṛtam |
nirvāṇametatkathitaṃ śṛṇu tatprāpyate katham
]

`v 26 [
evaṃ sotkaṇṭhaṃ rāmaṃ tatprāptyupāyopadeśenāśvāsayan vasiṣṭha uvāca ##-
yadidaṃ dṛśyate dṛśyamahantvantādisaṃyutam `note[tvantvādi iti
kvacit] |
sato'pyasyātyanutpattyā buddhayaitadavāpyate
]

`v 27 [
śrīrāma uvāca |
videhamuktāstrailokyaṃ saṃpadyante yadā tadā |
manyete sargatāmeva gatā vedyavidāṃvara
]

`v 28 [
śrīvasiṭha uvāca |
vidyate cettribhuvanaṃ tattattāṃ saṃprayāntu te |
yatra trailokyaśabdārtho na saṃbhavati kaścana
]

`v 29 [
etattrilokatāṃ yātaṃ brahmetyuktārthadhīḥ kutaḥ |
tasmānno saṃbhavatyeṣā jagacchabdārthakalpanā
]

`v 30 [
ananyacchāntamābhāsamātramākāśanirmalam |
brahmaiva jagadityetatsarvaṃ sattvāvabodhataḥ
]

`v 31 [
ahaṃ hi hemakaṭake vicāryāpi na dṛṣṭavān |
kaṭakatvaṃ kvacinnāma ṛte nirmalahāṭakāt
]

`v 32 [
pratyagdṛṣṭyā paryālocane tadadhyastasyāsattvaṃ dṛṣṭāntairanubhāvayati ##-
jalādṛte payovīcau nāhaṃ paśyāmi kiṃcana |
vīcitvaṃ tādṛśaṃ dṛṣṭaṃ yatra nāstyeva tatra hi
]

`v 33 [
spandatvaṃ pavanādanyanna kadācana kutracit |
spanda eva sadā vāyurjagattasmānna bhidyate
]

`v 34 [
yathā śūnyatvamākāśe tāpa eva marau jalam |
teja eva sadā loke brahmaiva trijagattathā
]

`v 35 [
śrīrāma uvāca |
atyantābhāvasaṃpattyā jagaddṛśyasya muktatā |
yayodeti mune yuktyā tāṃ mamopadiśottamam
]

`v 36 [
mithaḥsaṃpannayordraṣṭṛdṛśyayorekasaṃkhyayoḥ |
dvayābhāve sthitiṃ yāte `note[yāti iti pāṭhaḥ] nirvāṇamavaśiṣyate
]

`v 37 [
dṛśyasya jagatastasmādatyantāsaṃbhavo yathā |
brahmaivetthaṃ svabhāvasthaṃ budhyate vada me tathā
]

`v 38 [
kayaitajjñāyate yuktyā kathametatprasiddhyati |
etasmiṃstu mune siddhe na sādhyamavaśiṣyate
]

`v 39 [
śrīvasiṣṭha uvāca |
bahukālamiyaṃ rūḍhā mithyājñānaviṣūcikā |
nūnaṃ vicāramantreṇa nirmūlamupaśāmyati
]

`v 40 [
na śakyate jhaṭityeṣā samutsādayituṃ kṣaṇāt |
samaprapatane hyadrau samarohāvarohaṇe
]

`v 41 [
tasmādabhyāsayogena yuktyā nyāyopapattibhiḥ |
jagadbhrāntiryathā śāmyettavedaṃ kathyate śṛṇu
]

`v 42 [
vakṣyāmyākhyāyikāṃ rāma yāmimāṃ bodhasiddhaye |
tāṃ cecchṛṇoṣi tatsādho mukta evāsi bodhavān
]

`v 43 [
athotpattiprakaraṇaṃ mayedaṃ tava kathyate |
yatkilotpadyate rāma tena muktena bhūyate
]

`v 44 [
iyamitthaṃ jagadbhrāntirbhātyajātaiva khātmikā |
ityutpattiprakaraṇe kathyate'sminmayādhunā
]

`v 45 [
p. 149)
yadidaṃ dṛśyate kiṃcijjagatsthāvarajaṅgamam |
sarvaṃ sarvaprakārāḍhyaṃ sasurāsurakinnaram
]

`v 46 [
tanmahāpralaye prāpte rudrādipariṇāmini |
bhavatyasadadṛśyātma kvāpi yāti vinaśyati
]

`v 47 [
tataḥ stimitagambhīraṃ na tejo na tamastatatam |
anākhyamanabhivyaktaṃ satkiṃcidavaśiṣyate
]

`v 48 [
na śūnyaṃ nāpi cākāraṃ na dṛśyaṃ na ca darśanam |
na ca bhūtapadārthaugho yadanantatayā sthitam
]

`v 49 [
kimapyavyapadeśātma pūrṇātpūrṇatarākṛti |
na sannāsanna sadasanna bhāvo bhavanaṃ na ca
]

`v 50 [
cinmātraṃ cetyarahitamanantamajaraṃ śivam |
anādimadhyaparyantaṃ yadanādi nirāmayam
]

`v 51 [
yasmiñjagatprasphurati dṛṣṭamauktikahaṃsavat |
yaścedaṃ yaśca naivedaṃ devaḥ sadasadātmakaḥ
]

`v 52 [
akarṇajihvānāsātvagnetraḥ sarvatra sarvadā |
śṛṇotyāsvādayati yo jighretspṛśati paśyati
]

`v 53 [
sa eva sadasadrūpaṃ yenālokena lakṣyate |
sargacitramanādyantaṃ svarūpaṃ cāpya rañjanam
]

`v 54 [
ardhonmīlitadṛśyabhrūmadhye tārakavajjagat |
vyomātmaiva sadābhāsaṃ svarūpaṃ yo'bhipaśyati
]

`v 55 [
yasyānyadasti na vibhoḥ kāraṇaṃ śaśaśṛṅgavat |
yasyedaṃ ca jagatkāryaṃ taraṅgaugha ivāmbhasaḥ
]

`v 56 [
jvalataḥ sarvato'jasraṃ cittasthāneṣu tiṣṭhataḥ |
yasya cinmātradīpasya bhāsā bhāti jagattrayam
]

`v 57 [
yaṃ vinā'rkādayo'pyete prakāśāstimiropamāḥ |
sati yasminpravartante trijaganmṛgatṛṣṇikāḥ
]

`v 58 [
saspande samudetīva niḥspandāntargate na ca |
iyaṃ yasmiñjagallakṣmīralāta iva cakratā
]

`v 59 [
jagannirmāṇavilayavilāso vyāpako mahān |
spandāspandātmako yasya svabhāvo nirmalo'kṣayaḥ
]

`v 60 [
spandāspandamayī yasya pavanasyeva sarvagā |
sattā nāmnaiva bhinneva vyavahārānna vastutaḥ
]

`v 61 [
sarvadaiva prabuddho yaḥ supto yaḥ sarvadaiva ca |
na supto na prabuddhaśca yaḥ sarvatraiva sarvadā
]

`v 62 [
yadaspandaṃ śivaṃ śāntaṃ yatspandaṃ trijagatsthitiḥ |
spandāspandavilāsātmā ya eko bharitākṛtiḥ `note[bharatāvaniḥ iti
pāṭhaḥ]
]

`v 63 [
p. 150)
āmoda iva puṣpeṣu na naśyati vināśiṣu |
pratyakṣastho'pyathāgrāhyaḥ śauklyaṃ śuklapaṭe yathā
]

`v 64 [
mūkopamo'pi yo'mūko mantā yo'pyupalopamaḥ |
yo bhoktā nityatṛpto'pi kartā yaścāpyakiṃcanaḥ
]

`v 65 [
yo'naṅgo'pi samastāṅgaḥ sahasrakaralocanaḥ |
na kiṃcitsaṃsthitenāpi yena vyāptamidaṃ jagat
]

`v 66 [
nirindriyabalasyāpi yasyāśeṣendriyakriyāḥ |
yasya nirmananasyaitā manonirmāṇarītayaḥ
]

`v 67 [
yadanālokanādbhrāntisaṃsāroragabhītayaḥ |
yasmindṛṣṭe palāyante sarvāśāḥ sarvabhītayaḥ
]

`v 68 [
sākṣiṇi sphāra ābhāse dhruve dīpa iva kriyāḥ |
sati yasminpravartante cittehāḥ spandapūrvikāḥ
]

`v 69 [
yasmādghaṭapaṭākārapadārthaśatapaṅktayaḥ |
taraṅgagaṇakallolavīcayo vāridheriva
]

`v 70 [
sa evānyatayodeti yatpadārthaśatabhramaiḥ |
kaṭakāṅgadakeyūranūpurairiva kāñcanam
]

`v 71 [
yastvameko'vabhāsātmā yo'hamete janāśca ye |
yaśca na tvamabuddhātmā nāhaṃ naite janāśca `note[janāśca ye iti
pāṭhaḥ] yaḥ
]

`v 72 [
anyevāpyatirikteva saivāseva ca bhaṅgurā |
payasīva taraṅgālī yasmātphurati dṛśyabhūḥ
]

`v 73 [
yataḥ kālasya kalanā yato dṛśyasya dṛśyatā |
mānasī kalanā yena yasya bhāsā vibhāsanam
]

`v 74 [
kriyāṃ rūpaṃ rasaṃ gandhaṃ śabdaṃ sparśaṃ ca cetanam |
yadvetsi tadasau devo yena vetsi tadapyasau
]

`v 75 [
draṣṭṛdarśanadṛśyānāṃ madhye yaddarśanaṃ sthitam |
sādho tadavadhānena svātmānamavabudhyase
]

`v 76 [
ajamajaramanādyaṃ śāśvataṃ brahma nityaṃ
śivamamalamamoghaṃ vandyamuccairanindyam |
sakalakalanaśūnyaṃ kāraṇaṃ kāraṇānā-
manubhavanamavedyaṃ vedanaṃ viśvamantaḥ
]