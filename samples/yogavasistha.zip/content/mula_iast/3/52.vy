`v 1 [
p. 254) 152
dvipañcāśaḥ sargaḥ 52
śrīvasiṣṭha uvāca |
etasminnantare rāma līlovāca sarasvatīm |
śvāsāvaśeṣamālokya mūḍhaṃ bhartāramagragam
]

`v 2 [
pravṛtto dehamutsraṣṭuṃ madbhartāyamihāmbike |
jñaptiruvāca |
evaṃrūpamahārambhe saṃgrāme rāṣṭrasaṃbhrame
]

`v 3 [
saṃpanne'pi sthite'pyuccairvicitrārambhamanthare |
na kiṃcidapi saṃpannaṃ rāṣṭraṃ na ca mahītalam
]

`v 4 [
na sthitaṃ kvacanāpyevaṃ svapnātmakamidaṃ jagat |
tasya tanmaṇḍapasyāntaḥ śavasya nikaṭāmbare
]

`v 5 [
idaṃ bhūrāṣṭramābhāti bhartṛjīvasya te'naghe |
antaḥpuragṛhānte tadidaṃ rāṣṭrānvitodaram
]

`v 6 [
vasiṣṭhavipragehe'ntarvindhyādrigrāmake sthitam |
vasiṣṭhavipragehentaḥ śavagehajagatsthitam
]

`v 7 [
śavagehajagatkukṣāvidaṃ gehajagatsthitam |
evameṣa mahārambho jagattrayamayo bhramaḥ
]

`v 8 [
tvayā mayā'nayā'nena saṃyuktaḥ sārṇavāvaniḥ |
girigrāmakadehāntarmadhye gaganakośake
]

`v 9 [
svātmaiva kacati vyartho na kacatyeva vā kvacit |
tatpadaṃ paramaṃ viddhi nāśotpādavivarjitam
]

`v 10 [
svayaṃ kacitamābhātaṃ śāntaṃ paramanāmayam |
kila maṇḍapagehentaḥ svasvabhāvoditātmani
]

`v 11 [
evamārambhaghanayorapi maṇḍapayostayoḥ |
udare śūnyamākāśamevāsti na jagadbhramaḥ
]

`v 12 [
bhramadraṣṭurabhāve hi kīdṛśī bhramatā bhrame |
nāstyeva bhramasattāto yadasti tadajaṃ padam
]

`v 13 [
bhramo dṛśyamasattasya draṣṭṛdṛśyadaśā kutaḥ |
draṣṭṛdṛśyakramābhāvādadvayaṃ sahajaṃ hi tat
]

`v 14 [
tatpadaṃ paramaṃ viddhi nāśotpādavivarjitam |
svayaṃ kacitamābhātaṃ śāntamādyamanāmayam
]

`v 15 [
kila maṇḍapagehāntaḥ svasvabhāvoditātmani |
viharanti janāstatra svagehe svavyavasthayā
]

`v 16 [
na jagattatra no sargaḥ kaścidapyanubhūyate `note[kvacit iti pāṭhaḥ] |
tenāhamajamākāśaṃ jagadityeva vartate
]

`v 17 [
sarvaṃ śūnyātmavijñānaṃ mervādigirijālakam |
nedaṃ kuḍyamayaṃ kiṃcidyathā svapne mahāpuram
]

`v 18 [
deśe prādeśamātre'pi girijālamayānyapi |
vajrasārāṇi svānyeva lakṣāṇi jagato viduḥ
]

`v 19 [
p. 255) 152
jaganti subahūnyeva saṃbhavantyaṇuke'pi ca |
kadalīpallavānīva saṃniveśena bhūriśaḥ
]

`v 20 [
trijagaccidaṇāvantarasti svapnapuraṃ yathā |
tasyāpyantaścidaṇavasteṣvapyekaikaśo jagat
]

`v 21 [
teṣāṃ yasmiñjagatyeṣa padmo rājā śavaḥ sthitaḥ |
līlā tava sapatnīyaṃ prāptā pūrvatarā śubhe
]

`v 22 [
yadaiva mūrcchāmāyātā līleyaṃ puratastava |
tadaiva bhartuḥ padmasya śavasya nikaṭe sthitā
]

`v 23 [
līlovāca |
kathameṣā purā devi saṃpannā tatra dehinī |
kathaṃ ca tatsapatnīkabhāvamāptavatī sthitā
]

`v 24 [
te cāsyā vada kiṃ rūpaṃ paśyantyatha vadanti kim |
tadgehavaravāstavyāḥ samāseneti me vada
]

`v 25 [
śrīdevyuvāca |
śṛṇu sarvaṃ samāsena yathāpṛṣṭaṃ vadāmi te |
līle līlāsvavṛttāntamantadaṃ dṛśyadurdaśam
]

`v 26 [
līlāntarabhūtāyāḥ svasyā eva vṛttāntam | antaṃ nirṇayaṃ dadātītyantadam |
dṛśyāḥ samyag draṣṭuṃ śakyā maraṇaparalokagamanādidurdaśā yena tam |
25 |
padmastava sa bhartaiṣa bhrāntiṃ tāvattatāmimām |
iyaṃ jaganmayī tasminneva sadmani paśyati
]

`v 27 [
bhrāntiyuddhamidaṃ yuddhameṣā bhrāntirjano'janaḥ |
bhrāntyaivāstīha maraṇameṣa caivaṃ bhramātmakaḥ
]

`v 28 [
bhramakrameṇānenaiva līlāsya dayitā sthitā |
tvaṃ caiṣā ca varārohe svapnamātraṃ varāṅgane
]

`v 29 [
yathā bhavatyāvetasya svapnamātraṃ varāṅgane |
tathā bhavatyorbhartaiṣa tathaivāhamapi svayam
]

`v 30 [
jagacchobhaivedṛśīyaṃ dṛśyametadihocyate |
etadeva parijñātaṃ dṛśyaśabdārthamujjhati
]

`v 31 [
evameṣā tvameṣā ca saṃpannaivamasau nṛpaḥ |
ahaṃ cātmani satyatvaṃ gatā sarvatayātmanaḥ
]

`v 32 [
ime vayamihānyonyaṃ sapannāścoditā iti |
itthaṃ sarvātmakatayā mahāciddhanasaṃsthiteḥ
]

`v 33 [
evameṣā sthitā rājñī hārihāsavilāsinī |
līlā vilolavadanā navayauvanaśālinī
]

`v 34 [
peśalācāramadhurā madhurodārabhāṣiṇī |
kokilāsvarasaṃkāśā madamanmathamantharā
]

`v 35 [
asitotpalapatrākṣī vṛttapīnapayodharā |
kāntā kāñcanagaurāṅgī pakvabimbaphalādharā
]

`v 36 [
tvatsaṃkalpātmakasyaiṣā yadā bharturmanaḥkalā |
tadā tvatsadṛśākārā sthitaiṣā ciccamatkṛtau
]

`v 37 [
tvadbharturmaraṇe kṣipraṃ samanantarameva hi |
tvadbhartraiṣā puro dṛṣṭā tvatsaṃkalpātmanāmunā
]

`v 38 [
yadādhibhautikaṃ bhāvaṃ ceto'nubhavati svayam |
cetyaṃ sanmayamevāta ātivāhikakalpanam
]

`v 39 [
yadādhibhautikaṃ bhāvaṃ ceto vetti na sanmayam |
ātivāhikasaṃkalpastadā satyopajāyate
]

`v 40 [
atho maraṇasaṃvittyā punarjanmamaye bhrame |
tvaṃ hi saṃviditānena tvayā ca gata eva saḥ
]

`v 41 [
itthaṃ tvāṃ dṛṣṭavāneṣa dṛṣṭaścaiṣa tvayeti ca |
tvamapyātmani saṃpannā sarvagatvāccidātmanaḥ
]

`v 42 [
brahma sarvagataṃ yasmādyathā yatra yadoditam |
bhavatyāśu tathā tatra svapnaśaktyaiva paśyati
]

`v 43 [
p. 256) 153
sarvatra sarvaśaktitvādyatra yā śaktirunnayet |
āste tatra tathā bhāti tīvrasaṃvegahetutaḥ
]

`v 44 [
mṛtimohakṣaṇenaiva yadaitau daṃpatī sthitau |
tadaivābhyāmidaṃ buddhaṃ pratibhāsavaśāddhṛdi
]

`v 45 [
āvayoḥ pitarāvetāvime vai cāpi mātarau |
deśa eṣa dhanaṃ cedaṃ karmedaṃ pūrvamīdṛśam
]

`v 46 [
āvāṃ vivāhitāvevamevaṃ nāmaikatāṃ gatau |
etayoḥ sāpi janatā yātā tatraiva satyatām
]

`v 47 [
tathaivātrāsti dṛṣṭāntaḥ pratyakṣaṃ svapnavedanam |
ityevaṃbhāvayā līle līlayāhamathārcitā
]

`v 48 [
nāhaṃ syāṃ vidhavetyevaṃ varo datto mayāpyasau |
ityarthena mṛtā pūrvameveha khalu bālikā
]

`v 49 [
bhavatāṃ cetanāṃśānāmahaṃ cetanadharmiṇī |
kuladevī sadā pūjyā svata eva karomyaham
]

`v 50 [
athāsyā jīvako dehātprāṇamārutarūpadhṛk |
manasā calatāṃ prāpto mukhāgratyaktadehakaḥ
]

`v 51 [
tato maraṇamūrcchānte gṛhe'sminneva caitayā |
buddhau bhāvita ākāśe dṛṣṭo jīvātmanā tataḥ
]

`v 52 [
saṃpannaiṣā hariṇanayanā candrabimbānanaśrī-
rmānonnaddhā dayitalalitā kāntamābhoktukāmā |
pūrvasmṛtyā sarabhasamukhī saṃyutā maṇḍalāntaḥ
svapnānte vā'prakṛtivibhavā padminī coditeva
]