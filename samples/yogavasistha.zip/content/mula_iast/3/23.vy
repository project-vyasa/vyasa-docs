`v 1 [
caturtho divasaḥ |
trayoviṃśaḥ sargaḥ 23
śrīvasiṣṭha uvāca |
iti saṃkathanaṃ kṛtvā tasyāṃ niśi varāṅgane |
supte parijane nūnamathāntaḥpuramaṇḍape
]

`v 2 [
dṛḍhākhilārgaladvāragavākṣe dakṣacetasi |
puṣpaprakaraniṣṭhyūtamāṃsalāmodamanthare `note[puṣpaprākāra iti
pāṭhaḥ]
]

`v 3 [
amlānamālāvasanaśavapārśvāsanasthite |
sakalāmalapūrṇenduvadanadyotitāspade
]

`v 4 [
samādhisthānakaṃ gatvā tasthaturniścalāṅgike |
ratnastambhādivotkīrṇe citre bhittāvivārpite
]

`v 5 [
sarvāstatyajatuścintāḥ saṃkocaṃ samupāgate |
divasānta ivābjinyau prasṛtāmodalekhike
]

`v 6 [
babhūvaturbhṛśaṃ śānte śuddhe spandavivarjite |
girau śaradi nirvāta iva bhraṣṭābhramālike
]

`v 7 [
p. 186)
nirvikalpasamādhānājjahaturbāhyasaṃvidam |
yathā kalpalate kānte pūrvamṛtvantare rasam
]

`v 8 [
ahaṃ jagaditi bhrāntidṛśyasyādāvanudbhavaḥ |
yadā tābhyāmavagatastvatyantābhāvanātmakaḥ
]

`v 9 [
tadā dṛśyapiśāco'yamalamastaṃ gato dvayoḥ |
asattvādeva cāsmākaṃ śaśaśṛṅgamivānagha
]

`v 10 [
ādāveva hi yannāsti vartamāne'pi tattathā |
bhātaṃ vā'bhātamevāto mṛgatṛṣṇāmbuvajjagat
]

`v 11 [
svabhāvakevalaṃ śāntaṃ strīdvayaṃ tadvabhūva ha |
candrārkāpadārthaughairdūramuktamivāmbaram
]

`v 12 [
tenaiva jñānadehena cacāra jñaptidevatā |
mānuṣī tvitareṇāśu dhyānajñānānurūpiṇā
`note[jñānājñānānurūpiṇī]
]

`v 13 [
gehāntareva prādeśamātramāruhya saṃvidā |
babhūvatuścidākāśarūpiṇyau vyomagākṛtī
]

`v 14 [
atha te lalane līlālole lalitalocane |
svabhāvāccetyasaṃvitternabho dūramito gate
]

`v 15 [
tatrasthe vātha cidvṛttyā pupluvāte nabhasthalam |
koṭiyojanavistīrṇaṃ dūrāddūratarāntaram
]

`v 16 [
dṛśyānusandhānanijasvabhāvā-
dākāśadehe api te mitho'tra |
parasparākāravilokanena
babhūvatuḥ snehapare vayasye
]