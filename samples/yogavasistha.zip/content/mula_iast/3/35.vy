`v 1 [
pañcatriṃśaḥ sargaḥ 35
śrīvasiṣṭha uvāca |
atha proḍḍayanodyuktaturaṅgamataraṅgakaḥ |
uttāṇḍava ivonmatto babhūva sa raṇārṇavaḥ
]

`v 2 [
chatraḍiṇḍīraviśrāntasiteṣuśapharotkaraḥ |
aśvasainyollasallolakallolākulakoṭaraḥ
]

`v 3 [
nānāyudhanadīnītasainyāvartavivṛttimān |
mattahastighaṭāpīṭhacalācalakulācalaḥ
]

`v 4 [
kacaccakraśatāvartavṛttibhrāntaśirastṛṇaḥ |
dhūlījaladharāpītabhramatkhaḍgaprabhājalaḥ
]

`v 5 [
makaravyūhavistārabhagnābhagnabhaṭaughanau |
mahāguḍuguḍāvartapratiśruddhanakandaraḥ
]

`v 6 [
mīnavyūhaviniṣkrāntaśarabījaughasarṣapaḥ |
hetivīcīvarālūnapatākāvīcimaṇḍalaḥ
]

`v 7 [
śastravārikṛtāmbhodasadṛśāvartakuṇḍalaḥ |
saṃrambhaghanasaṃcārasenātimitimiṅgilaḥ
]

`v 8 [
kṛṣṇāyasaparidhānavalatsenāmbubhīṣaṇaḥ |
kabandhāvartalekhāntarbaddhasainyādibhūṣaṇaḥ
]

`v 9 [
p. 215)
śarasīkaranīhārasāndhakārakakubgaṇaḥ |
nirghoṣāśoṣitāśeṣaśabdaikaghanabhuṃghumaḥ
]

`v 10 [
patanotpatanavyagraśiraḥśakalasīkaraḥ |
āvartacakravyūheṣu prabhramadbhaṭakāṣṭhakaḥ
]

`v 11 [
kaṣṭaṭāṅkārakodaṇḍakuṇḍalonmathanodbhaṭaḥ |
aśaṅkameva pātālādivodyatsainikormimān
]

`v 12 [
gamāgamaparānantapatākācchatraphenilaḥ |
vahadraktanadīraṃhaḥprohyamānarathadrumaḥ
]

`v 13 [
gajapratimasaṃpannamahārudhirabudbudaḥ |
sainyapravāhavicaladdhayahastijalecaraḥ
]

`v 14 [
sasaṃgrāmo'mbaragrāma ivāścaryakaro nṛṇām |
abhūtpralayabhūkampakampitācalacañcalaḥ
]

`v 15 [
tarattaraṅgavihagaḥ patatkarighaṭātaṭaḥ |
trastabhīrumṛgānīkasphūrjadghurughurāravaḥ
]

`v 16 [
saraccharālīśalabhaśatabhaṅgurasainikaḥ |
taratturaṅgaśarabhaḥ śarabhāravanāvaniḥ
]

`v 17 [
caladdvirephanirhrādo `note[jaladvirepha iti pāṭhaḥ] rasattūryaguhāguruḥ
|
cirātsa sainyajalado luṭhadbhaṭamṛgādhipaḥ
]

`v 18 [
cirādityasyottaratrābhūdityanenānvayaḥ
`note[viṃśatitamaślokagatenetyarthaḥ] | sasainyā gajādayo jaladā iva yatra | 17
|
prasaraddhūlijalado vigalatsainyasānumān |
patadrathavarāḍhyāṅgaḥ pratapatkhaḍgamaṇḍalaḥ
]

`v 19 [
protpatatpadapuṣpaughaḥ patākācchatravāridaḥ |
vahadraktanadīpūrapatatsārāvavāraṇaḥ
]

`v 20 [
so'bhūtsamarakalpānto jagatkavalanākulaḥ |
paryastasadhvajacchatrapatākārathapattanaḥ
]

`v 21 [
patadvimalahetyaughabhūribhāsvarabhāskaraḥ |
kaṭhinaprāṇasaṃtāpatāpitākhilamānasaḥ
]

`v 22 [
kodaṇḍapuṣkarāvartaśaradhārānirantaraḥ |
vahatkhaḍgaśilālekhāvidyudvalayitāmbaraḥ
]

`v 23 [
ucchinnaraktajaladhipatitebhakulācalaḥ |
nabhovikīrṇanipatadyuttārakaṇatārakaḥ
]

`v 24 [
cakrakulyāmbudāvartapūrṇavyomaśirāmbudaḥ |
astrakalpāgninirdagdhasainyalokāntarakramaḥ
]

`v 25 [
hetivarṣāśanicchannabhūtalāmalabhūdharaḥ |
gajarājagirivrātapātapiṣṭajanavrajaḥ
]

`v 26 [
śaradhārāghanānīkameghacchannamahīnabhāḥ |
mahānīkārṇavakṣobhasaṃghaṭṭaghaṭitādravaḥ
]

`v 27 [
vyāpta ugrāniloddhūtairjalavyālairivācalaḥ |
anyonyadalanavyagraiḥ śastrotpāta ivotthitaiḥ
]

`v 28 [
jalavyālairlaḍuṇḍubhaiḥ | acalaḥ arthātsamudrāntargata iti labhyate | anyonyadalane
vyagraiḥ śastrairiti śeṣaḥ | śastravarṣiṇi saṃvartotpāte utthitairivetyutprekṣā | 27
|
śūlāsicakraśaraśaktigadābhuśuṇḍī-
prāsādayo vidalanena mitho dhvanantaḥ |
dīptā adhurdaśadiśaḥ śataśo bhramantaḥ
kalpāntavātaparivṛttapadārthalīlām
]