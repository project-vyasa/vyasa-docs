`v 1 [
daśottaraśatatamaḥ sargaḥ 110
śrīvasiṣṭha uvāca |
paramātkāraṇādādau ciccetyapadapātinī |
kalanāpadamāsādya kalā kalilatāṃ gatā
]

`v 2 [
asatsveva vimoheṣu rāmaivaṃprāyavṛttiṣu |
ghaneṣu tucchatāmetya cirāya parimūrcchati
]

`v 3 [
asadeva manovṛttirmlānā vistārayatyalam |
duḥkhaṃ doṣasahasreṇa vetālāniva bālikā
]

`v 4 [
p. 384) 228
sadeva hi mahāduḥkhamasattāṃ nayati kṣaṇāt |
niṣkalaṅkā manovṛttirandhakāramivārkaruk
]

`v 5 [
nayatyabhyāśatāṃ dūraṃ dūramabhyāśatāṃ nayet |
mano valgati bhūteṣu bālo bālakhageṣviva
]

`v 6 [
abhayaṃ bhayamajñasya cetaso vāsanāvataḥ |
dūrato mugdhapānthasya sthāṇuryāti piśācatām
]

`v 7 [
śatrutvaṃ śaṅkate mitre kalaṅkamalinaṃ manaḥ |
madāviṣṭamatirjanturbhramatpaśyati bhūtalam
]

`v 8 [
paryākule hi manasi śaśino jāyate'śaniḥ |
amṛtaṃ viṣabhāvena bhuktaṃ yāti viṣakriyām
]

`v 9 [
surapattananirmāṇamasatsadiva paśyati |
vāsanāvalitaṃ cetaḥ svapnavajjāgradeva hi
]

`v 10 [
mohaikakāraṇaṃ jantormanaso vāsanolbaṇā |
utkhātavyā prayatnena mūlocchedena saiva ca
]

`v 11 [
vāsanāvāgurākṛṣṭo manohariṇako nṛṇām |
parāṃ vivaśatāmeti saṃsāravanagulmake
]

`v 12 [
yena cchinnā vicāreṇa jīvasya jñeyavāsanā |
nirabhrasyeva sūryasya tasyāloko virājate
]

`v 13 [
atastvaṃ man evedaṃ naraṃ viddhi na dehakam |
jaḍo deho manaścātra na jaḍaṃ nājaḍaṃ viduḥ
]

`v 14 [
tatra prathamaṃ mana eva me deho nānya iti sadā bhāvanābhyāsaḥ kārya ityāha ##-
yatkṛtaṃ manasā tāta tatkṛtaṃ viddhi rāghava |
yattyaktaṃ manasā tāvattattyaktaṃ viddhi cānagha
]

`v 15 [
manomātraṃ jagatkṛtsnaṃ manaḥ paryantamaṇḍalam |
mano vyoma mano bhūmirmano vāyurmano mahān
]

`v 16 [
mano yadi padārthe tu tadbhāvena na yojayet |
tataḥ sūryodaye'pyete `note[sūryādayo'pyete iti pāṭhaḥ] na prakāśāḥ
kadācana
]

`v 17 [
mano mohamupādatte yasyāsau mūḍha ucyate |
śarīre mohamāpanne na śavo mūḍha ucyate
]

`v 18 [
manaḥ paśya bhavatyakṣi śṛṇvacchravaṇatāṃ gatam |
tvagbhāvaṃ sparśanādeti ghrāṇatāmeti jighraṇāt
]

`v 19 [
rasanādrasatāmeti vicitrāstatra `note[vicitrāsvatra vṛttiṣu iti pāṭhaḥ
sādhuḥ] vṛttiṣu |
nāṭake naṭavaddehe mana evānuvartate
]

`v 20 [
laghu dīrghaṃ karotyeva satye'sattāṃ prayacchati |
kaṭutāṃ nayati svādu ripuṃ nayati mitratām
]

`v 21 [
ya eva pratibhāso'sya cetaso vṛttivartinaḥ |
tatastadeva pratyakṣaṃ tathātrānubhavādiha
]

`v 22 [
pratibhāsavaśādeva svapnākulitacetasaḥ |
hariścandrasya saṃpannā rātrirdvādaśavārṣikī
]

`v 23 [
cittānubhāvavaśato muhūrtatve gataṃ yugam |
indradyumnasya vairiñcyapurābhyantaravartinaḥ
]

`v 24 [
manojñayā manovṛttyā sukhatāṃ yāti rauravam |
prātaḥprāptavyarājyasya subaddhasyeva bandhanam
]

`v 25 [
jite manasi sarvaiva vijitā cendriyāvaliḥ |
śīryate ca yathā tantau dagdhe mauktikamālikā
]

`v 26 [
sarvatra sthitayā svaccharūpayā nirvikārayā |
samayā sūkṣmayā nityaṃ cicchaktyā sākṣibhūtayā
]

`v 27 [
sarvabhāvānugatayā na cetyārthavibhinnayā |
rāmātmasattayā mūkamapi dehasamaṃ jaḍam
]

`v 28 [
mano'ntaścalati vyarthaṃ mananaiṣaṇamuhyayā |
bahirgirisaridvyomasamudrapuralīlayā
]

`v 29 [
jāgraccābhimataṃ vastu nayatyamṛtamṛṣṭatām |
anīhitaṃ ca viṣatāṃ nayatyamṛtamapyalam
]

`v 30 [
amṛṣṭasarvabhāvānāmalamātmacamatkṛtim |
tarhi tattvajñānapi tatkuto na bhramayettatrāha - amṛṣṭeti | na mṛṣṭaḥ
sākṣātkṛtaḥ sarvabhāvaḥ pūrṇatā yaisteṣāmeva manaḥ
svābhimatākāramātmacamatkārabhūtaṃ rūpaṃ sṛjati natu tattvavidām | teṣāṃ
mithyābuddhibādhitamanovilāseṣu camatkāradṛṣṭyabhāvādityāśayaḥ
]

`v 31 [
p. 385) 228
spandeṣu vāyutāmeti prakāśeṣu prakāśatām |
draveṣu dravatāmeti cicchaktisphuritaṃ manaḥ
]

`v 32 [
pṛthvyāṃ kaṭhinatāmeti śūnyatāṃ śūnyadṛṣṭiṣu |
sarvatrecchāsthitiṃ yāti cicchaktisphuritaṃ manaḥ
]

`v 33 [
śuklaṃ kṛṣṇīkarotyeva kṛṣṇaṃ nayati śuklatām |
vinaiva deśakālābhyāṃ śaktiṃ paśyāsya cetasaḥ
]

`v 34 [
manasyanyatra saṃsakte carvitasyāpi jihvayā |
bhojanasyāpi mṛṣṭasya na svādo'syānubhūyate
]

`v 35 [
yaccittadṛṣṭaṃ taddṛṣṭaṃ na dṛṣṭaṃ tadalokitam |
andhakāre yathā rūpamindriyaṃ nirmitaṃ tathā
]

`v 36 [
indriyeṇa mano dehi manasendriyamunmanaḥ |
indriyāṇi prasūtāni manaso nendriyānmanaḥ
]

`v 37 [
atyantabhinnayoraikyaṃ yeṣāṃ cittaśarīrayoḥ |
jñātajñeyā mahātmāno manasyāste supaṇḍitāḥ
]

`v 38 [
kusumollāsidhammillā helācalitalocanā |
kāṣṭhakuḍyopamāṅgeṣu lagnāpyamanaso'ṅganā
]

`v 39 [
manasyanyatra saṃsakte vītarāgeṇa kānane |
kravyādacarvito'ṅkasthaḥ svakaro'pi na lakṣitaḥ
]

`v 40 [
sukhīkartuṃ suduḥkhāni duḥkhīkartuṃ sukhāni ca |
sukhenaivāśu yujyante manaso'tiśayā muneḥ
]

`v 41 [
manasyanyatra saṃsakte kathyamānāpi yatnataḥ |
latā paraśukṛtteva kathā vicchidyate bata
]

`v 42 [
manasyadritaṭārūḍhe gṛhasthenāpi jantunā |
śubhrābhrakandarabhrāntiduḥkhaṃ samanubhūyate
]

`v 43 [
manasyullasite svapne hṛdyeva puraparvatāḥ |
ākāśa iva vistīrṇe dṛśyante nirmitāḥ kṣamāḥ
]

`v 44 [
mano vilulite svapne hṛdyevādripurāvalim |
tanoti calitāmbhodhirvīcīcayamivātmani
]

`v 45 [
antarabdhijalādyadvattaraṅgāpīḍavīcayaḥ |
dehāntarmanasastadvatsvapnādripurarājayaḥ
]

`v 46 [
aṅkurasya yathā patralatāpuṣpaphalaśriyaḥ |
manaso'sya tathā jāgratsvapnavibhramabhūmayaḥ
]

`v 47 [
vyatiriktā yathā hemno na hemavanitā tathā |
jāgratsvapnakriyālakṣmīrvyatiriktā na cetasaḥ
]

`v 48 [
dhārākaṇormiphenaśrīryathā saṃlakṣyate'mbhasaḥ |
tathā vicitravibhavā nānāteyaṃ hi cetasaḥ
]

`v 49 [
svacittavṛttireveha jāgratsvapnadṛśoditam |
rasāveśādupādatte śailūṣa iva bhūmikām
]

`v 50 [
caṇḍālatvaṃ hi lavaṇe pratibhāsavaśādyathā |
tathedaṃ jagadābhogi mano mananamātrakam
]

`v 51 [
yadyatsaṃvedyate kiṃcittena tenāśu bhūyate |
mano manananirmāṇaṃ yathecchasi tathā kuru
]

`v 52 [
nānāpurasaricchailarūpatāmetya dehinām |
tanotyantaḥsthamevedaṃ jāgratsvapnamayaṃ manaḥ
]

`v 53 [
suratvāddaityatāmetya nāgatvānnagatāmapi |
pratibhāsavaśāccittamāpannaṃ lavaṇo yathā
]

`v 54 [
naratvādeti nārītvaṃ pitṛtvātputratāṃ gataḥ |
yathā kṣipraṃ prati naraḥ svasaṃkalpāttathā manaḥ
]

`v 55 [
saṃkalpataḥ pramriyate saṃkalpājjāyate punaḥ |
manaścirantanābhyastājjīvatāmetyanākṛti
]

`v 56 [
p. 386) 229
mano mananasaṃmūḍhamūḍhavāsanamātatam |
saṃkalpādyonimāyāti sukhaduḥkhe bhayābhaye
]

`v 57 [
sukhaṃ duḥkhaṃ ca manasi tile tailamiva sthitam |
taddeśakālavaśato ghanaṃ vā tanu vā bhavet
]

`v 58 [
tailaṃ tilasya cākrāntyā sphuṭatāmeti śāśvatīm |
cetaso mananāsaṅgādghanībhūte sukhāsukhe
]

`v 59 [
deśakālābhidhānena rāma saṃkalpa eva hi |
kathyate tadvaśādyasmāddeśakālau sthitiṃ gatau
]

`v 60 [
praśāmyatyullasatyeti yāti nandati valgati |
manaḥśarīrasaṃkalpe phalite na śarīrakam
]

`v 61 [
nānāsphārasamullāsaiḥ svasaṃkalpopakalpitaiḥ |
mano valgati dehe'sminsādhvīvāntaḥpurājire
]

`v 62 [
cāpale prasarastasmādantaryena nadīyate |
manovilayamādatte tasyālāna iva dvipaḥ
]

`v 63 [
na spandate mano yasya śastrastambha ivottamaḥ |
sadvastuto'sau puruṣaḥ śiṣṭāḥ kardamakīṭakāḥ
]

`v 64 [
yasyācapalatāṃ yātaṃ mana ekatra saṃsthitam |
anuttamapadenāsau dhyānenānugato'nagha
]

`v 65 [
saṃyamānmanasaḥ śāntimeti saṃsāravibhramaḥ |
mandare'spandatāṃ yāte yathā kṣīramahārṇavaḥ
]

`v 66 [
mānasyo vṛttayo yā yā bhogasaṃkalpavibhramaiḥ |
saṃsāraviṣavṛkṣasya tā evāṅkurayonayaḥ
]

`v 67 [
cittaṃ calatkuvalayaṃ valayanta ete
mūḍhā mahājaḍajave madamohamandāḥ |
āvartavartini vilūnaviśīrṇacintā-
cakrabhrame puruṣadurbhramarāḥ patanti
]