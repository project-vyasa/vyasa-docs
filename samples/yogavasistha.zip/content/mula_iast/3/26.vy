`v 1 [
ṣaḍviṃśaḥ sargaḥ 26
śrīvasiṣṭha uvāca |
iti te varavarṇinyau tato brahmāṇḍamaṇḍalāt |
nirgatyānyadanuprāpte yatra tadbrāhmaṇāspadam
]

`v 2 [
tato dadṛśatuḥ sadma svamevaṃ siddhayoṣitau |
adṛśye eva lokasya maṇḍapaṃ brāhmaṇāspadam
]

`v 3 [
cintāvidhuradāsīkaṃ bāṣpaklinnāṅganāmukham |
vidhvastaprāyavadanaṃ śīrṇaparṇāmbujopamam
]

`v 4 [
naṣṭotsavapuraprāyamagastyāttamivārṇavam |
grīṣmadagdhamivodyānaṃ vidyuddagdhamiva drumam
]

`v 5 [
vātacchinnamivāmbhodaṃ himadagdhamivāmbujam |
alpasnehadaśaṃ dīpamivālokanabhedanam
]

`v 6 [
āsannamṛtyukaruṇākulavaktrakānti-
saṃśīrṇajīrṇataruparṇavanopamānam |
vṛṣṭivyapāyaparidhūsaradeśarūkṣaṃ
jātaṃ gṛheśvaraviyogahataṃ gṛhaṃ tat
]

`v 7 [
p. 192)
śrīvasiṣṭha uvāca |
atha sā nirmalajñānacirābhyāsena sundarī |
saṃpannā satyasaṃkalpā satyakāmā ca devavat
]

`v 8 [
cintayāmāsa māmete devīṃ cemāṃ svabandhavaḥ |
paśyantu tāvatsāmānyalalanārūpadhāraṇīm
]

`v 9 [
tato gṛhajanastatra sa dadarśāṅganādvayam |
lakṣmīgauryoryugamiva samudbhāsitamandiram
]

`v 10 [
āpādavividhāmlānamālāvasanasundaram |
vasantalakṣmyoryugalamivāmoditakānanam
]

`v 11 [
sarvauṣadhivanagrāmaṃ pūrayantyau rasāyanaiḥ |
śītalāhlādasukhadaṃ candradvayamivoditam
]

`v 12 [
lambālakalatālolalocanālivilokanaiḥ |
kiratkuvalayonmiśramālatīkusumotkarān
]

`v 13 [
drutahemarasāpūrasaritsaraṇahāriṇā |
dehaprabhāpravāheṇa `note[prabhavina iti pāṭhaḥ] kanakīkṛtakānanam
]

`v 14 [
sahajāyā vapurlakṣmyā līlādolāvilāsinaḥ |
ta ete ca taraṅgāḍhyā nijalāvaṇyavāridheḥ
]

`v 15 [
vilolabāhulatikāyugenāruṇapāṇinā |
kirannavanavaṃ haimaṃ kalpavṛkṣalatāvanam
]

`v 16 [
pādairamṛditāmlānapuṣpakomalapallavaiḥ `note[puṣpapallavakomalaiḥ iti
pāṭhaḥ] |
sthalābjadalamālābhairaspṛśadbhūtalaṃ punaḥ
]

`v 17 [
tālītamālakhaṇḍānāṃ śuṣkāṇāṃ śuciśociṣām |
ālokanāmṛtāsekairjanayadbālapallavān
]

`v 18 [
namo'stu vanadevībhyāmityuktvā kusumāñjalim |
tatyāja jyeṣṭhaśarmātha sārdhaṃ gṛhajanena saḥ
]

`v 19 [
papāta pādayorgehe tayorvai kusumāñjaliḥ |
prāleyasīkarāsāraḥ padminyā iva padmayoḥ
]

`v 20 [
jayatamiti loṇmadhyamapuruṣadvivacanam
]

`v 21 [
iti tadvacanānte te devyāvūcaturādarāt |
ākhyāta duḥkhaṃ yenāyaṃ lakṣyate duḥkhito janaḥ
]

`v 22 [
jyeṣṭhaśarmādayaste te devyau prati yathākramam |
nijaṃ tadduḥkhamācakhyurdampativyasanātmakam
]

`v 23 [
jyeṣṭhaśarmādaya ūcuḥ |
devyāvabhavatāṃ snigdhāviha brāhmaṇadampatī |
sarvātithī kulakarau stambhābhūtau dvijasthiteḥ
]

`v 24 [
tāvadya gṛhamutsṛjya saputrapaśubāndhavam |
svargaṃ gatau naḥ pitarau tena śūnyaṃ jagattrayam
]

`v 25 [
pakṣiṇo gṛhamāruhya vikṣipantaḥ pratikṣaṇam |
dehaṃ śūnye mṛtaṃ bhaktyā śocanti madhauraiḥ svaraiḥ
]

`v 26 [
guhāgurugurārāvapralāpalapanākulaḥ |
saritsthūlāśrudhārābhiḥ pariroditi parvataḥ
]

`v 27 [
nirjarākrandakāriṇyo muktāmbarapayodharāḥ |
taptaniḥśvāsavidhvastāḥ paraṃ kārśyamitā diśaḥ
]

`v 28 [
kṣatavikṣatasarvāṅgaḥ karuṇākrandakarkaśaḥ |
upavāsarato grāmo dīno mṛtiparaḥ sthitaḥ
]

`v 29 [
p. 193)
divasaṃ prati vṛkṣāṇāmavaśyāyāśrubindavaḥ |
gucchalocanakośebhyastāpoṣṇāni patantyadhaḥ
]

`v 30 [
praśāntajanasaṃcārā rathyā kṣāravidhūsarā |
vidhavāvigatānandā saṃśūnyahṛdayā sthitā
]

`v 31 [
kokilālipralāpinyo vṛṣṭibāṣpahṛtā latāḥ |
uṣṇoṣṇaśvasanā dehaṃ ghanti pallavapāṇibhiḥ
]

`v 32 [
ātmānaṃ śatadhā kartuṃ bṛhacchvabhraśilātale |
nirjharāḥ prapatantyete tāpataptaśarīrakāḥ
]

`v 33 [
niḥśaṅkayā gataśrīkā mūkā vilulitāśayāḥ |
andhena tamasā pūrṇā gṛhā gahanatāṃ gatāḥ
]

`v 34 [
udyānapuṣpakhaṇḍebhyo rudadbhyo bhramarāravaiḥ |
pūtigandho viniryāti svāmodāparanāmakaḥ
]

`v 35 [
caitradrumavilāsinyo virasāḥ prativāsaram |
latāḥ kṛśā vilīyante saṃkucadgucchalocanāḥ
]

`v 36 [
caitradrumānvilāsayanti tacchīlāḥ | caitya iti pāṭhe spaṣṭam | vilīyante viśīryante |
35 |
prakṣeptumambudhau dehaṃ pravṛttā gantumākulāḥ |
kulyāḥ kalakalālolaṃ dolayantyastanuṃ bhuvi
]

`v 37 [
aśaṅkamaśakāpātaspandamapyaticāpalam |
kalayantyaḥ sthitā vāpyo nispandānandamātmani
]

`v 38 [
gāyatkinnaragandharvavidyādharasurāṅganam |
nūnamadya nabho jātamasmattātābhyalaṃkṛtam
]

`v 39 [
taddevyau kriyatāṃ tāvadasmākaṃ śokanāśanam |
mahatāṃ darśanaṃ nāma na kadācana niṣphalam
]

`v 40 [
ityuktavantaṃ sā putraṃ mūrdhni pasparśa pāṇinā |
pallavenānatā namraṃ mūlagranthimivābjinī
]

`v 41 [
tasyāḥ sparśena tenāsau duḥkhadaurbhāgyasaṃkaṭam |
jahau prāvṛḍghanāsaṅgādgrīṣmatāpamivācalaḥ
]

`v 42 [
sarvo gṛhajanaḥ so'tha tayordevyorvilokanāt |
lakṣmīvānduḥkhanirmukto babhūvāmṛtapo yathā
]

`v 43 [
śrīrāma uvāca |
tayāsya līlayā mātrā putrasya jyeṣṭhaśarmaṇaḥ |
kasmānna darśanaṃ dattaṃ mohaṃ tāvannirākuru
]

`v 44 [
śrīvasiṣṭha uvāca |
buddhaḥ pṛthvyādibodhena yena pṛthvyādisaṅghakaḥ |
tasya piṇḍātmatāṃ dhatte vyomaivānyasya kevalam
]

`v 45 [
asadevāṅga sadiva bhāti pṛthvyādivedanāt |
yathā bālasya vetālo nābhāti tadavedanāt
]

`v 46 [
yathā pṛthvyādinā bhātamapṛthvyādi bhavetkṣaṇāt |
svapne svapnaparijñānāttathā jāgratyapi sphuṭam
]

`v 47 [
pṛthvyādi khatayā buddhaṃ khamityevānubhūyate |
tathāhi kṣubdhadhātūnāṃ kuḍyeṣu kha ivodyamaḥ
]

`v 48 [
svapne nagaramurvīṃ `note[ūrvī ityubhayatra pāṭhaḥ] vā śūnyaṃ
khātaṃ ca budhyate |
svapnāṅganā ca kurute śūnyāpyarthakriyāṃ nṛṇām
]

`v 49 [
khaṃ pṛthvyāditayā buddhaṃ pṛthvyādi bhavati kṣaṇāt |
mūrcchāyāṃ paraloko'pi pratyakṣamanubhūyate
]

`v 50 [
bālo vyomaiva vetālaṃ mriyamāṇo'mbare vanam |
keśoṇḍrakaṃ khamanyastu khamanyo vetti mauktikam
]

`v 51 [
trastakṣībārdhanidrāśca nauyānāśca sadaiva khe |
vetālavanavṛkṣādi paśyantyanubhavanti ca
]

`v 52 [
p. 194)
yathābhāvitameteṣāṃ padārthānāmato vapuḥ |
abhyāsajanitaṃ bhāti nāstyekaṃ paramārthataḥ
]

`v 53 [
līlayā tu yathāvastu buddhā pṛthvyādināstitā |
ākāśameva saṃvittyā bhāti bhrāntitayoditam
]

`v 54 [
kathaṃ buddhā tadāha - ākāśameveti | bhrāntitayā mithyāprapañcatayā | 53
|
brahmātmaikacidākāśamātrabodhavato muneḥ |
putramitrakalatrāṇi kathaṃ kāni kadā kutaḥ
]

`v 55 [
dṛśyamādāvanutpannaṃ yacca bhātyajameva tat |
samyagjñānavatāmevaṃ rāgadveṣadṛśo kutaḥ
]

`v 56 [
hastaḥ śirasi yaddatto līlayā jyeṣṭhaśarmaṇaḥ |
tatprabhāvasthitārambhasaṃbodhāyāściteḥ phalam
]

`v 57 [
bodho hi cetati yathaiva tathā śubhāni
sūkṣmastu khādapi tathātitarāṃ viśuddhaḥ |
sarvatra rāghava sa eva padārthajālaṃ
svapneṣu kalpitapureṣvanubhūtametat
]