`v 1 [
navottaraśatatamaḥ sargaḥ 109
rājovāca |
tasmiṃstadā vartamāne kaṣṭe vidhiviparyaye |
akālolbaṇakalpānte nitāntaṃ tāpadāyini
]

`v 2 [
janāḥ kecana niṣkramya sakalatrasuhṛjjanāḥ |
gatā deśāntaraṃ vyomnaḥ śaradīva payodharāḥ
]

`v 3 [
dehāvayavasaṃlīnaputradārāgryabandhavaḥ |
śīrṇāḥ kecana tatraiva cchinnā iva vane drumāḥ
]

`v 4 [
bhaktāḥ kecana ca vyāghrairnirgatāstu svamandirāt |
ajātapakṣakāḥ śyenaiḥ khagā nīḍodgatā iva
]

`v 5 [
praviṣṭāḥ kecidanalaṃ jvalitaṃ śalabhā iva |
kecicchvabhreṣu patitāḥ śilā śailacyutā iva
]

`v 6 [
ahaṃ tu tānparityajya śvaśurādīnsvakaṃ kṣamam |
kalatramātramādāya kṛcchrāddeśādvinirgataḥ
]

`v 7 [
analānanilāṃścaiva bhakṣakāṃstakṣakānapi |
vañcayitvā bhayānmṛtyoḥ sadāro'haṃ vinirgataḥ
]

`v 8 [
prāpya taddeśaparyantaṃ tatra tālatarostale |
avaropya sutānskandhānnānānarthānivolbaṇān
]

`v 9 [
viśrānto'smi ciraṃ śrānto rauravādiva nirgataḥ |
dīrghadāvanidāghārto grīṣme padma ivājalaḥ
]

`v 10 [
atha cāṇḍālakanyāyāṃ viśrāntāyāṃ tarostale |
suptāyāṃ śītalacchāye dvau samāliṅgya dārakau
]

`v 11 [
pṛcchako nāma tanayo mamaikaḥ purataḥ sthitaḥ |
atyantavallabho'smākaṃ kanīyānmaugdhyavāniti
]

`v 12 [
sa māmuvāca dīnātmā bāṣpapūrṇavilocanaḥ |
tāta dehyāśu me māṃsaṃ pātuṃ ca rudhiraṃ kṣaṇāt
]

`v 13 [
punaḥpunarvadannevaṃ sa bālastanayo mama |
prāṇāntikīṃ daśāṃ prāptaḥ sākrando hi punaḥ kṣudhā
]

`v 14 [
tasyoktaṃ tu mayā putra māṃsaṃ nāstīti bhūriśaḥ |
tathāpi māṃsaṃ dehīti vadatyeva sa `note[sudurmatiḥ iti pāṭhaḥ]
durmatiḥ
]

`v 15 [
atha vātsalyamūḍhena `note[yuktena iti pāṭhaḥ] mayā duḥkhātibhāriṇā |
tasyoktaṃ putra manmāṃsaṃ pakvaṃ saṃbhujyatāmiti
]

`v 16 [
tadapyaṅgīkṛtaṃ tena dehīti vadatā punaḥ |
manmāṃsabhakṣaṇaṃ kṣīṇavṛttinā'śleṣavṛttinā
]

`v 17 [
sarvaduḥkhāpanodāya snehakāruṇyamohinā |
tasya tāmārtimālokya mayā duḥkhātibhāriṇā
]

`v 18 [
soḍhuṃ tāmāpadaṃ tīvrāmaśaktena hatātmanā |
maraṇāyātimitrāya kṛto'ntarniścayo mayā
]

`v 19 [
p. 383) 227
tatra kāṣṭhāni saṃcitya citāṃ racitavānaham |
citā caṭacaṭāsphoṭaiḥ sthitā madabhikāṅkṣiṇī
]

`v 20 [
tasyāṃ tu yāvadātmānaṃ citāyāṃ nikṣipāmyaham |
calito'smi javāttāvadasmātsiṃhāsanānnṛpaḥ
]

`v 21 [
tatastūryaninādena jayaśabdena bodhitaḥ |
iti śāmbarikeṇāyaṃ moha utpādito mama
]

`v 22 [
ajñāneneva jīvasya daśāśatasamanvitaḥ |
ityuktavati rājendre lavaṇe bhūritejasi
]

`v 23 [
antardhānaṃ jagāmāśu tatra śāmbarikaḥ kṣaṇāt |
athedamūcuste sabhyā vismayotphullalocanāḥ
]

`v 24 [
nāyaṃ śāmbariko deva yasya nāsti dhanaiṣaṇā |
daivī kācana māyeyaṃ saṃsārasthitibodhinī
]

`v 25 [
daivī tvadanugrahāya devaiḥ prayuktā ata eva saṃsārasyedṛśī sthitiriti bodhinī |
24 |
manovilāsaḥ saṃsāra iti yasyāṃ pratīyate |
sarvaśakteranantasya vilāso hi manojagat
]

`v 26 [
sarvaśaktervicitrā hi śaktayaḥ śataśo vidheḥ |
yadviveki mano'pyeṣa vimohayati māyayā
]

`v 27 [
vijñātalokavṛttāntaḥ kva nāmāyaṃ mahīpatiḥ |
kva sāmānyamanovṛttiyogyo vipulasaṃbhramaḥ
]

`v 28 [
na ca śāmbarikeccheyaṃ māyā manasi mohinī |
arthasya siddhyai cehante nityaṃ śāmbarikāḥ kila
]

`v 29 [
yatnena prārthayante'rthaṃ nāntardhānaṃ vrajanti bho |
iti saṃdehavelāyāṃ saṃsthitā lulitā vayam
]

`v 30 [
śrīvasiṣṭha uvāca |
sabhāyāmavasaṃ tasyāmahaṃ rāma tadā kila |
tena pratyakṣato dṛṣṭaṃ mayaitannānyataḥ śrutam
]

`v 31 [
iti bahukalanāvivardhitāṅgaṃ
jayati ciraṃ vitataṃ mano mahātman |
śamamupagamite parasvabhāve
paramamupaiṣyasi pāvanaṃ padaṃ yat
]