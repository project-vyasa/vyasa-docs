`v 1 [
pañcasaptatitamaḥ sargaḥ 75
śrīvasiṣṭha uvāca |
atha varṣasahasreṇa tāṃ pitāmaha āyayau |
varaṃ putri gṛhāṇeti vyājahāra nabhastalāt
]

`v 2 [
sūcī karmendriyābhāvājjīvamātrakalāvatī |
na kiṃcidvyājahārāsmai cintayāmāsa kevalam
]

`v 3 [
pūrṇāsmi gatasaṃdehā kiṃ vareṇa karomyaham |
śāmyāmi parinirvāmi sukhamāse ca kevalam
]

`v 4 [
jñātaṃ jñātavyamakhilaṃ śāntā saṃdehajālikā |
svaviveko vikasitaḥ kimanyena prayojanam
]

`v 5 [
yathā sthiteyamasmīha saṃtiṣṭheyaṃ tathaiva hi |
satyāsatyakalāmeva tyaktvā kimitareṇa me
]

`v 6 [
p. 313) 190
etāvantamahaṃ kālamavivekena yojitā |
svasaṃkalpasamutthena vetāleneva bālikā
]

`v 7 [
idānīmupaśānto'sau svavicāraṇayā svayam |
īpsitānīpsitairarthaḥ ko bhavetkalitairmama
]

`v 8 [
iti niścayayuktāṃ tāṃ sūcīṃ karmendriyojjhitām |
tūṣṇīsthitāṃ saniyatiḥ sa paśyanbhagavānsthitaḥ
]

`v 9 [
brahmā punaruvācedaṃ vītarāgāṃ prasannadhīḥ |
varaṃ putri gṛhāṇa tvaṃ kiṃcitkālaṃ ca bhūtale
]

`v 10 [
bhogānbhuktvā tataḥ paścādgamiṣyasi paraṃ padam |
avyāvṛttisvarūpāyā niyatereṣa niścayaḥ
]

`v 11 [
tapasānena saṃkalpaḥ saphalo'stu tavottame |
pīnā bhava punaḥ śaile himakānanarākṣasī
]

`v 12 [
yayā pūrvaṃ viyuktāsi tanvā jaladarūpayā |
bījāntarvṛkṣatā putri bṛhadvṛkṣatayā yathā
]

`v 13 [
yogameṣyasi bhūyaśca tanvāntarbījarūpiṇī |
tayaiva rasasekena latayevāṅkurasthitiḥ
]

`v 14 [
bādhāṃ viditavedyatvānna ca loke kariṣyasi |
antaḥśuddhā spandavatī śāradīvābhramaṇḍalī
]

`v 15 [
aśrāntadhyānaniratā kadācillīlayā yadi |
bhaviṣyasi bahīrūpā sarvātmadhyānarūpiṇī
]

`v 16 [
vyavahārātmakadhyānadhāraṇādhārarūpiṇī |
vātasvabhāvavaddehaparispandādvilāsinī
]

`v 17 [
tadā virodhinī putri svakarmaspandarodhinī |
nyāyena kṣunnivṛttyarthaṃ bhūtabādhāṃ kariṣyasi
]

`v 18 [
bhaviṣyasi nyāyavṛttirloke tvanyāyabādhikā |
jīvanmuktatayā dehe svavivekaikapālikā
]

`v 19 [
ityuktvā gaganatalājjagāma devaḥ
sūcī sā bhavatu mameti kiṃ virodhaḥ |
rāgo vābjajavacanārthavāraṇe'smi-
nnityantaḥ svatanumayī manāgbabhūva
]

`v 20 [
prādeśaḥ prathamamabhūttato'pi hasto
vyāmaścāpyatha viṭapastato'bhramālā |
sodyatsvāvayavalatā babhau nimeṣā-
tsaṃkalpadrumakaṇikāṅkurakrameṇa
]

`v 21 [
tadgātrāṇyavikalaśaktimanti dehā-
dudbhūtānyatha karaṇendriyāṇi samyak |
saṃkalpadrumavanapuṣpavatsamantā-
dbījaughānyalamabhavaṃstirohitāni
]