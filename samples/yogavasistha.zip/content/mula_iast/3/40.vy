`v 1 [
catvāriṃśaḥ sargaḥ 40
śrīvasiṣṭha uvāca |
evaṃ niśācarācāraciraghore raṇāṅgaṇe |
ahanīva janācāre sthite yāmāvarehite
]

`v 2 [
hastahāryatamaḥpiṇḍasphuṭakuḍye niśāgṛhe |
lābhocchadoccalacate bhūtasaṅghe pravalgati
]

`v 3 [
niḥśabde dhvāntasaṃcāre nidrāruddhakakubgaṇe |
līlāpatirudārātmā kiṃcitkhinnamanā iva
]

`v 4 [
prātaḥkāryaṃ vicāryāśu mantribhirmantrakovidaiḥ |
dīrghacandrasamākāre śayane himaśītale
]

`v 5 [
candrodaranibhe cārugṛhe śiśirakoṭare |
nidrāṃ muhūrtamagamanmudritekṣaṇapuṣkaraḥ
]

`v 6 [
atha te lalane vyoma tatparityajya tadgṛham |
randhrairviviśaturvātalekhe'bjamukulaṃ yathā
]

`v 7 [
śrīrāma uvāca |
kiyanmātramidaṃ sthūlaṃ śarīraṃ vāgvidāṃvara |
randhreṇa tantutanunā kathamāśvāviśatprabho
]

`v 8 [
p. 226)
śrīvasiṣṭha uvāca |
ādhibhautikadeho'hamiti yasya matibhramaḥ |
tasyāsāvaṇurandhreṇa gantuṃ śaknoti nānagha
]

`v 9 [
rodhito'hamaneneti na māmyatreti yasya dhīḥ |
anubhūtānubhavati bhavatītyanubhūyate
]

`v 10 [
yenānubhūtaṃ pūrvārdhaṃ gacchāmīti sa tatkriyaḥ |
kathaṃ bhavati paścārdhaṃ gamanonmukhacetanaḥ
]

`v 11 [
nahi vāryūrdhvamāyāti nādho gacchati pāvakaḥ |
yā yathaiva pravṛttā citsā tathaiva pratiṣṭhitā
]

`v 12 [
chāyāyāmupaviṣṭasya kutastāpānubhūtayaḥ |
yasya saṃvedane'nyo'rthaḥ kenacinnānubhūyate
]

`v 13 [
yathā saṃvittathā cittaṃ sā tathāvasthitiṃ gatā |
parameṇa prayatnena nīyate'nyadaśāṃ punaḥ
]

`v 14 [
sarpaikapratyayo rajjvāmasarpapratyaye balāt |
nivartate'nyathā tveṣa tiṣṭhatyeva yathāsthitaḥ
]

`v 15 [
yathā saṃvittathā cittaṃ yathā cittaṃ tathehitam |
bālaṃ pratyapi saṃsiddhametatko nānubhūtavān
]

`v 16 [
yaḥ punaḥ svapnasaṃkalpapuruṣaḥ pratimākṛtiḥ |
ākāśamātrakākāraḥ sa kathaṃ kena rodhyate
]

`v 17 [
nanu sthūladehavadātivāhikaṃ cittaśarīramapi kuto na rodhyate tatrāha - ya iti |
16 |
cittamātraṃ śarīraṃ tu sarvasyaiva hi sarvataḥ |
vidyate vedanāccaitatkvacidetīva hṛdgatāt
]

`v 18 [
yathābhimatamevāsya bhavatyastamayodayam |
ādisarge svabhāvotthaṃ paścāddvaitaikyakāraṇam
]

`v 19 [
cittākāśaṃ cidākāśamākāśaṃ ca tṛtīyakam |
viddhyetantrayamekaṃ tvamavinābhāvanāvaśāt
]

`v 20 [
etaccittaśarīratvaṃ viddhi sarvagatodayam |
yathāsaṃvedanecchatvādyathāsaṃvedanodayam
]

`v 21 [
vasati trasareṇvantardhriyate gaganodare |
līyate'ṅkurakośeṣu rasībhavati pallave
]

`v 22 [
ullasatyambuvīcitve pranṛtyati śilodare |
pravarṣatyambudo bhūtvā śilībhūyāvatiṣṭhate
]

`v 23 [
yathecchamambare yāti jaṭhare'pi ca bhūbhṛtām |
anantarākāśavapurdhatte'tha paramāṇutām
]

`v 24 [
bhavatyadrirdharādhāro baddhapīṭho nabhaḥ śirāḥ |
dehasyāntarbahirapi dadhadvanatanūruham
]

`v 25 [
p. 227)
bhavatyākāśamādhatte koṭīḥ padmajasadmanām |
ananyāḥ svātmano'mbhodhirāvartaracanā iva
]

`v 26 [
anudvignaprabodho'sau sargādau cittadehakaḥ |
ākāśātmā mahānbhūtvā vetti prakṛtatāṃ tataḥ
]

`v 27 [
asatyameva vāritvaṃ buddhyodetīva tattathā |
vandhyāputro'yamastīti yathā svapne bhramo naraḥ
]

`v 28 [
śrīrāma uvāca |
kiṃ cittametadbhavati kiṃvā bhavati no katham |
kathameva na sadrūpaṃ nānyadbhavati vīkṣaṇāt
]

`v 29 [
śrīvasiṣṭha uvāca |
pratyekameva yaccittaṃ tadevaṃrūpaśaktikam |
pṛthakpratyekamuditaḥ praticittaṃ jagadbhramaḥ
]

`v 30 [
kṣaṇakalpajagatsaṅghāḥ samudyanti galanti ca |
nimeṣātkasyacitkalpātkasyacicca kramaṃ śṛṇu
]

`v 31 [
maraṇādimayī mūrcchā pratyekenānubhūyate |
yaiṣā tāṃ viddhi sumate mahāpralayayāminīm
]

`v 32 [
tadante tanute sargaṃ sarva eva pṛthakpṛthak |
sahajasvapnasaṃkalpānsaṃbhramācalanṛtyavat
]

`v 33 [
mahāpralayarātryante cirādātmamanovapuḥ |
yathedaṃ tanute tadvatpratyekaṃ mṛtyanantaram
]

`v 34 [
śrīrāma uvāca |
mṛteranantaraṃ sargo yathā smṛtyānubhūyate |
cirāttathānubhavati nāto viśvamakāraṇam
]

`v 35 [
śrīvasiṣṭha uvāca |
mahati pralaye rāma sarve hariharādayaḥ |
videhamuktatāṃ yānti smṛteḥ ka iva saṃbhavaḥ
]

`v 36 [
bhavedevaṃ yadyādisarge yathārthānubhavajanyā sargahetuḥ smṛtistasya
saṃbhavet | nahi sā prathamaṃ hiraṇyagarbhapadaprāptasyopāsakasya saṃbhavati
tasya hi smṛtirupāsanopanītasaṃskārajanyā na yathārthānubhavajanyā | upāsanā
ca prāktanī vyaṣṭereva samaṣṭibhāvacintanaṃ na yathārthānubhava
ityayathārthopāsanāsaṃskārajasmṛtijanyatvānnādisargasya satyatāprasaktiḥ |
nahi prāktanāḥ kecidanye sarvajñāstadānīṃ santi | sarveṣāṃ prāgeva muktatvāt |
dvitīyakalpādisargahetusmṛtestu pūrvasargānubhūtamithyārthaviṣayataiveti na
kvāpi sargasatyatāprasaktirityāśayena vasiṣṭhaḥ samādhatte - mahatītyādinā |
35 |
asmadādiḥ prabuddhātmā kilāvaśyaṃ vimucyate |
kathaṃ bhavantu no muktā videhāḥ padmajādayaḥ
]

`v 37 [
anye tvamiva `note[tvapi ca iti pāṭhaḥ] ye jīvāsteṣāṃ maraṇajanmasu |
smṛtiḥ kāraṇatāmeti mokṣābhāvavaśādiha
]

`v 38 [
p. 228)
jīvo hi mṛtimūrcchānte yadantaḥ pronmiṣanniva |
anunmiṣita evāste tatpradhānamudāhṛtam
]

`v 39 [
tadvyomaprakṛtiḥ proktā tadavyaktaṃ jaḍājaḍam |
saṃsmṛterasmṛteścaiva krama eṣa bhavodaye
]

`v 40 [
bodhonmukhatve hi mahattatprabuddhaṃ yadā bhavet |
tadā tanmātradikkālakriyā bhūtādyudeti khāt
]

`v 41 [
tadevocchūnamābuddhaṃ bhavatīndriyapañcakam |
tadeva budhyate dehaḥ sa eṣo'syātivāhikaḥ
]

`v 42 [
ā ucchūnamīṣaducchūnaṃ sūkṣmāvasthamityarthaḥ | budhyate svapnajāgarayoḥ |
41 |
cirakālapratyayataḥ kalpanāparipīvaraḥ |
ādhibhautikatābodhamādhatte caiṣa bālavat
]

`v 43 [
tato dikkālakalanāstadādhāratayā sthitāḥ |
udyantyanuditā eva vāyoḥ spandakriyā iva
]

`v 44 [
vṛddhimitthamayaṃ yāto mudhaiva bhuvanabhramaḥ |
svapnāṅganāsaṅgasamastvanubhūto'pyasanmayaḥ
]

`v 45 [
yatraiva mriyate jantuḥ paśyatyāśu tadeva saḥ |
tatraiva bhuvanābhogamimamitthamiva sthitam
]

`v 46 [
vyomaivānubhavatyacchamahaṃ jagaditi bhramam |
vyomarūpaṃ vyomarūpī jīvo jāta ivātmavān
]

`v 47 [
`note[pūrvatra vyomaivānubhavatīti ṣaṭcatvāriṃśattamaśloke iti bhāvaḥ]
surapattanaśailārkatārānikarasundaram |
jarāmaraṇavaiklavyavyādhisaṃkaṭakoṭaram
]

`v 48 [
svabhāvābhāvasaṃrambhasthūlasūkṣmacarācaram |
sābdhyadryurvīnadīśāhorātrikalpakṣaṇakṣayam
]

`v 49 [
ahaṃ jāto'munā pitrā kilātretyāptaniścayam |
iyaṃ mātā dhanamidaṃ mametyuditavāsanam
]

`v 50 [
sukṛtaṃ duṣkṛtaṃ cedaṃ mameti kṛtakalpanam |
bālo'bhūvamahaṃ tvadya yuveti vilasaddhṛdi
]

`v 51 [
pratyekamevamuditaḥ saṃsāravanakhaṇḍakaḥ |
tārākusumito nīlameghacañcalapallavaḥ
]

`v 52 [
carannaramṛgānīkaḥ surāsuravihaṃgamaḥ |
ālokakausumarajāḥ śyāmāgahanakuñjakaḥ
]

`v 53 [
abdhipuṣkariṇīpūrṇo mevādyacalaloṣṭakaḥ |
cittapuṣkarabījāntarnilīnānubhavāṅkuraḥ
]

`v 54 [
yatraiṣa mriyate jīvastatraivaṃ paśyati kṣaṇāt |
pratyekamuditeṣvevaṃ jagatkhaṇḍeṣu bhūriśaḥ
]

`v 55 [
koṭayo brahmarudrendramarudviṣṇuvivasvatām |
giryabdhimaṇḍaladvīpalokāntaradṛśāṃ gatāḥ
]

`v 56 [
yātā yāsyanti yāntyetā dṛṣṭayo naṣṭarūpiṇīḥ |
yā brahmaṇyupabṛṃhāḍhyāstāḥ ke gaṇayituṃ kṣamāḥ
]

`v 57 [
evaṃ kuḍyamayaṃ viśvaṃ nāstyeva mananādṛte |
manane calamevāntastadidānīṃ vicāraya
]

`v 58 [
p. 229)
yadeva taccidākāśaṃ tadeva mananaṃ smṛtam |
yadeva ca cidākāśaṃ tadeva paramaṃ padam
]

`v 59 [
yadevāmbu sa āvarto natvasyāvarta vastu san |
draṣṭaivāste dṛśyamiva dṛśyaṃ natvasti vastu sat
]

`v 60 [
cidvyomno bhūtanabhasi kacanaṃ yanmaṇeriva |
tajjagadbhāvinānāsattattvaṃ śvabhramivāmbare
]

`v 61 [
madbuddhārtho jagacchabdo vidyate paramāmṛtam |
tvadbuddhārthastu nāstyeva tvamahaṃśabdakādapi `note[tvamahaṃśabdau
kāyatīti vicāraṇīyoṃ'śaḥ]
]

`v 62 [
madbuddhārtho'dhiṣṭhānasanmātram | tvadbuddhārtha āropitasattā | evaṃ
tvamahaṃśabdau kāyati abhilapati yaḥ sa tvamahaṃśabdakāt jagatpramātā so'pi
madbuddhaḥ sākṣicinmātrasvabhāva evāsti na tvadbuddhajīvasvabhāva ityarthaḥ |
61 |
tasmāllīlāsarasvatyāvākāśavapuṣau sthite |
sarvage paramātmācche sarvatrāpratighe'naghe
]

`v 63 [
yatra yatra sadā `note[mahāvyomni iti pāṭhaḥ] vyomni yathākāmaṃ
yathepsitam |
udayaṃ kurutastena tadgehe'sti gatistayoḥ
]

`v 64 [
sarvatra saṃbhavati cidgaganaṃ tadatra
sadvedanaṃ kalanamāmananaṃ `note[valanaṃ iti katipayapustakeṣu
paṭhyate] visāri |
taccātivāhikamihāhurakuḍyameva
dehaṃ kathaṃ ka iva taṃ vada kiṃ ruṇaddhi
]