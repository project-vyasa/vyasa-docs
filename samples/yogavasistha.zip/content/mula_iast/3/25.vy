`v 1 [
pañcaviṃśaḥ sargaḥ 25
śrīvasiṣṭha uvāca |
nabhaḥsthalādgirigrāmaṃ gacchantyau kaṃcideva te |
jñapticittasthitaṃ bhūmitalaṃ dadṛśatuḥ striyau
]

`v 2 [
p. 190)
brahmāṇḍanarahṛtpadmaṃ digaṣṭakadalaṃ bṛhat |
girikesarasaṃbādhaṃ svāmodabharasundaram
]

`v 3 [
saritkesarikānālamadhye'vaśyāyabindukam |
śarvaribhramarībhrāntaṃ bhūtaughamaśakākulam
]

`v 4 [
antarguṇagaṇākīrṇaṃ surandhraiḥ suṣirairvṛtam |
uhyamānapayaḥpūrairdivasālokakāntimat
]

`v 5 [
rasārdraṃ khe bhramaddhaṃsaṃ rātrisaṃkocabhājanam |
pātālapaṅkanirmagnanāganāthamṛṇālakam `note[nāgarāja iti
pāṭhaḥ]
]

`v 6 [
kadācidāspadāmbhodhikampakampitadigadalam |
adhonālagatānantadaityadānavakaṇṭakam
]

`v 7 [
asurastraiṇavallaryā saṃbhogasukumārayā |
prāpya bhūbhṛnmahābījahṛdayaṃ bhūtabījayā
]

`v 8 [
jambudvīpa iti khyātāṃ vipulāṃ tatra karṇikām |
saritkesarikānālāṃ nagaragrāmakesarām
]

`v 9 [
kulaśaileśvarottuṅgabījasaptakasundarīm |
madhyasthoccamahāmerubījākrāntanabhasthalīm
]

`v 10 [
saraḥprāleyakaṇikāṃ vanajaṅgaladhūlikām |
sthaleṣvāmaṇḍalāntasthajanajālālimaṇḍalām `note[sthaleṣu maṇḍalāṃ iti
pāṭhaḥ]
]

`v 11 [
tāṃ yojanaśatākāraiḥ pratirākaṃ prabodhibhiḥ |
sāgarairbhramarairvyāptāṃ dikcatuṣṭayaśālibhiḥ
]

`v 12 [
digdalāṣṭakaviśrāntasasurāmbhodhiṣaṭpadām |
bhrātṛbhirnavabhirbhūpairnavadhā parikalpitām
]

`v 13 [
lakṣayojanavistīrṇāmākīrṇāṃ ca rajolavaiḥ |
nānājanapadavyūhasthirāvaśyāyasīkarām
]

`v 14 [
dvīpāttu dviguṇaṃ mānaṃ lavaṇārṇavalekhayā |
dadhatyā valitāṃ bāhye prakoṣṭhamiva kambunā
]

`v 15 [
tato'pi dviguṇaṃ dehaṃ dadhatyā valayākṛtim |
jagadbhūtalatāvyāptāṃ śākākhyadvīpalekhayā
]

`v 16 [
tato'pi dvigu'nākāraṃ dhārayantyā ca veṣṭitām |
pratyagrakṣīrapūrṇābdhilekhayā svāduśītayā
]

`v 17 [
tato'pi dviguṇākāraṃ dhārayantyopaveṣṭitām |
nānājanālaṃkṛtayā kuśākhyadvīpalekhayā
]

`v 18 [
tato'pi dviguṇākāraṃ dhārayantyā ca veṣṭitām |
dadhyabdhilekhayā nityasaṃtarpitasuraughayā
]

`v 19 [
tataḥ krauñcābhidhadvīpalekhayaivaṃpramāṇayā |
veṣṭitāṃ khātaracayā navāṃ nṛpapurīmiva
]

`v 20 [
tato'pi ca ghṛtāmbhodhilekhayivaṃpramāṇayā |
tato'pi śālmalīdvīpalekhayā malapūrṇayā
]

`v 21 [
tataḥ surāmahāmbhodhilekhayā puṣpaśubhrayā |
śeṣasya dehalatayā harimūrtimivāvṛtām
]

`v 22 [
tato gomedakadvīpalekhayaivaṃpramāṇayā |
ikṣvabdhilekhayāpyevaṃ himavatsānuśuddhayā
]

`v 23 [
tato'pi puṣkaradvīpalekhayā dviguṇasthayā |
ante svādūdakāmbhodhilekhayaivaṃpramāṇayā
]

`v 24 [
tato daśaguṇenātha pātālatalagāminā |
nikhātavalayenoccaiḥ śvabhrasaṃbhārarūpiṇā
]

`v 25 [
p. 191)
pātālagāmimārgeṇa valitāṃ bhayadātmanā |
etasmātkhalu sarvasmāttato daśaguṇoccayā
]

`v 26 [
āvyomasucaturdikṣu śvabhrasaṃbhārabhīṣayā |
ardhonmlānatamorūpalagnanīlotpalasrajā
]

`v 27 [
nānāmāṇikyaśikharakahlārakumudābjayā |
lokālokācalottālavipuloddāmamālayā
]

`v 28 [
valitāṃ trijagallakṣmīdhammillavalanāmiva |
etasmādeva sarvasmāttato daśaguṇātmanā
]

`v 29 [
ajñātabhūtasaṃcāranāmnāraṇyena mālitām |
etasmādeva sarvasmāttato daśaguṇātmanā
]

`v 30 [
nabhaseva caturdikkaṃ vyāptāmatulavāriṇā `note[mamalavāriṇā iti
pāṭhaḥ] |
etasmādeva sarvasmāttato daśaguṇātmanā
]

`v 31 [
mervādidrāvaṇotkena jvālājālena mālitām |
etasmādatha sarvasmāttato daśaguṇātmanā
]

`v 32 [
mervādyacalasaṅghātaṃ nayatā tṛṇapāṃsuvat |
vahatādrīndravisphoṭakāriṇā javahāriṇā
]

`v 33 [
niḥśūnyatvādaśabdena marutā parito vṛtam |
etasmādatha sarvasmāttato daśaguṇātmanā
]

`v 34 [
parito valitaṃ vyomnā niḥśūnyenaikarūpiṇā |
atha yojanakoṭīnāṃ śatena ghanarūpiṇā |
vyāptaṃ brahmāṇḍakuḍyena haimenāpi dviparvaṇā
]

`v 35 [
iti jaladhimahādrilokapāla-
tridaśapurāmbarabhūtalaiḥ parītam |
jagadudaramavekṣya mānuṣī drāgbhuvi nijamandirakoṭaraṃ dadarśa
]