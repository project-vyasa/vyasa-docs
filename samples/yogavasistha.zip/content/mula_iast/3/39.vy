`v 1 [
ekonacatvāriṃśaḥ sargaḥ 39
śrīvasiṣṭha uvāca |
atha vīra ivāraktaḥ kālenāstamito raviḥ |
astratejaḥparimlānapratāpo'bdhau samujjhitaḥ
]

`v 2 [
raṇaraktarucirvyomadarpaṇapratibimbitā |
jahau sūryaśiraśchede saṃdhyālekhodabhūtkṣaṇam
]

`v 3 [
bhūpātālanabhodigbhyaḥ pralayābdhijalaughavat |
samājagmustanattālā vetālā valayā iva
]

`v 4 [
mṛṣṭadhvāntāsivalite dinanāgendramastake |
saṃdhyārāgāruṇaṃ kīrṇaṃ tārānikaramauktikam
]

`v 5 [
niḥsattveṣu tamondheṣu rasanārasaśāliṣu |
saṃkocamāyayuḥ padmāmṛtānāṃ hṛdayeṣviva
]

`v 6 [
mīlatpakṣāḥ kṣaṇātsuptāḥ kṛcchraprocchritakandharāḥ |
kulāyeṣu khagā āsañchavāṅgeṣviva hetayaḥ
]

`v 7 [
āsannacandrasubhagā lokāḥ kusumapaṅktayaḥ |
ullasaddhṛdayā jātā vīrapakṣeṣviva śriyaḥ
]

`v 8 [
raktavārimayī sāyamaṅgaguptaśilīmukhā |
saṃkucadvakrapadmābhūdraṇabhūmirivābjinī
]

`v 9 [
uparyabhūdvyomasarastārākumudamaṇḍitam |
adhastvabhūdvārisaraḥ sphuratkumudatārakam
]

`v 10 [
tamasyapetabhītāni bhūtāni militānyalam |
payāṃsīva visetūni prasṛtāni diśaṃ prati
]

`v 11 [
āsīdraṇāṅgaṇaṃ gāyadvetālakulasaṃkulam |
kvaṇatkaṅkālakāṅkasthakaṅkakākolakelimat
]

`v 12 [
atha kāṣṭhacitājvālasatārāmbarabhāsvaram |
pacatpacapacāśabdimedomāṃsamayānalam
]

`v 13 [
sarvāṅgāsthisphuṭāsphoṭasphuṭacciticayonmukham |
vetālalalanārabdhajalalīlātirohitam
]

`v 14 [
śvakākayakṣavetālatālakolāhalolbaṇam |
gamāgamena bhūtānāṃ samuḍḍīnavanopamam
]

`v 15 [
raktamāṃsavasāmedoharaṇavygraḍākini |
carvitāsṛgvasāmāṃsasravatsṛkkipiśācakam
]

`v 16 [
madhyamadhyacitālokaprakaṭāsṛkśavavrajam |
virūpikānīyamānasvāṃsanyastamahāśavam
]

`v 17 [
uttāṇḍavograkumbhāṇḍamaṇḍaloḍḍāmarodaram |
chamicchamitpralāpāntaṃ medosṛgbāṣpasāmbudam
]

`v 18 [
vahadraktanadīraṃhorūḍhabhūcararūpikam |
vetālakulakaṅkālakarṣaṇākulakākalam
]

`v 19 [
mṛtebhodaramañjūṣāsuptavetālabālakam |
viviktaikaraṇoddeśapānakrīḍāstharākṣasam
]

`v 20 [
mattavetālakalahacitālātaraṇojjvalam |
vahadraktavasāmiśragandhabandhuramārutam
]

`v 21 [
p. 225)
rūpikāpeṭikāvāntāraṇadraṭaraṭāravam |
ardhapakvaśavāsvādalubdhayakṣollasatkali
]

`v 22 [
tuṅgavaṅgakaliṅgāṅgataṅgaṇāṅgalagatkhagam |
tārāpātopamahasatsaṃmukhajvālarūpikam
]

`v 23 [
patadvetālasollāsamadhyasthāsṛgvirūpikam |
piśācākarṇitābhyarṇayoginīgaṇanāyakam
]

`v 24 [
prasṛtāntramahātantrīprāyasaṃpannavādanam |
piśācavāsanotkrāntapiśācībhūtamānavam
]

`v 25 [
rūpikālokanāpūrvatrāsārdhamṛtasadbhaṭam |
kvacidvetālarakṣobhiraparīpūrṇamadrakam
]

`v 26 [
svarūpikāskandhapatacchavatrastaniśācaram |
nabhaḥsaṃghaṭṭitāpūrvabhūtapeṭakasaṃkaṭam
]

`v 27 [
atiprayatnāpahṛtamriyamāṇanarāmiṣam |
svabhaksyāpekṣapakṣeṣu vikṣiptaśavarāśivat
]

`v 28 [
śivāmukhānalaśikhākhaṇḍotthamitiraktagaiḥ |
samuḍḍīnanavāśokapuṣpagucchamivābhitaḥ
]

`v 29 [
kabandhakandharābandhavygravetālabālakam |
yakṣarakṣaḥpiśācādikacadākāśagolmukam
]

`v 30 [
ākāśabhūdharanikuñjaguhāntarāla-
piṇḍopamaṇḍitatamombudapīṭhapūram |
vyālolabhūtarabhasākulakalpavāta-
vyādhūtalokakarakāṇḍakapeṭakalpam
]