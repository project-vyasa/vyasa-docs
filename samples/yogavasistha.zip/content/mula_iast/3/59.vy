`v 1 [
p. 276) 171
ekonaṣaṣṭitamaḥ sargaḥ 59
śrīvasiṣṭha uvāca |
sarasvatī tathetyuktvā tatraivāntardhimāyayau |
prabhāte paṅkajaiḥ sārdhaṃ bubudhe sakalo janaḥ
]

`v 2 [
āliliṅga ca tāṃ līlāṃ līlā ca dayitaṃ kramāt |
punaḥpunarmahānandānmṛtaṃ projjīvitaṃ punaḥ
]

`v 3 [
tadāsīdrājasadanaṃ madamanmathamantharam |
ānandamattajanataṃ vādyageyaravākualam
]

`v 4 [
tadā rājasadanamānandena mattā paravaśacittā janatā yasmiṃstathāvidhamāsīt | 3
|
jayamaṅgalapuṇyāhaghoṣaghuṃghumaghargharam |
tuṣṭapuṣṭajanāpūrṇaṃ rājalokavṛtāṅgaṇam
]

`v 5 [
siddhavidyādharonmuktapuṣpavarṣasahasrabhṛt |
dhvananmṛdaṅgamurajakāhalāśaṅkhadundubhi
]

`v 6 [
ūrdhvīkṛtabṛhaddhastahāstikastanitotkaṭam |
uttālatāṇḍavastraiṇapūrṇāṅgaṇalasaddhavani
]

`v 7 [
mithaḥsaṃghaṭṭanipatajjanopāyanadanturam |
puṣpaśekharasaṃbhāramayasaṃsārasundaram
]

`v 8 [
vikīrṇāpāditakṣaumaṃ mantrisāmantanāgaraiḥ |
sthūlapadmamayaṃ vyoma raktaistāṇḍavinīkaraiḥ
]

`v 9 [
mattastrikandharāvṛttalīlāndolitakuṇḍalam |
pravṛttapādasaṃpātaprollasatpuṣpakardamam
]

`v 10 [
paṭṭavāsaḥśaranmeghavitānakavitānakam |
varāṅganāmukhairnṛtyaccandralakṣagṛhājira
]

`v 11 [
paralokādupānītā rājñī sā patireva ca |
iti nirvṛttagāthābhirjagurdeśāntare janāḥ
]

`v 12 [
padmo bhūmipatiḥ śrutvā vṛttāntaṃ kathitaṃ manāk |
cakre snānaṃ samānītaiścatuḥsāgaravāribhiḥ
]

`v 13 [
tato'bhiṣiṣicurviprā mantriṇo bhūbhujaśca tam |
labdhodayamanantehamamarendramivāmarāḥ
]

`v 14 [
līlā līlā ca rājā ca jīvanmuktamahādhiyaḥ |
remire pūrvavṛttāntakathanaiḥ suratairiva
]

`v 15 [
sarasvatyāḥ prasādena svapauruṣakṛtena tat |
prāptaṃ lokatrayaśreyaḥ padmeneti mahībhujā
]

`v 16 [
sa jñaptijñānasaṃbuddho rājā līlādvayānvitaḥ |
cakre varṣāyutānyaṣṭau tatra rājyamaninditaḥ
]

`v 17 [
jīvanmuktāsta ityevaṃ rājyaṃ varṣāyutāṣṭakam |
kṛtvā videhamuktatvamāseduḥ siddhasaṃvidaḥ
]

`v 18 [
p. 277) 171
yadudayaviśadaṃ vidagdhamugdhaṃ
samucitamātmahitaṃ ca peśalaṃ ca |
tadakhilajanatoṣadaṃ svarājyaṃ
ciramanupālya sudaṃpatī vimuktau
]