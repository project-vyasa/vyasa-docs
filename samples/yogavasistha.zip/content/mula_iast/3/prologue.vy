`v 1 [
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
Vasudeva ḻaxmana ṣharma Pansikar
1918
utpattiprakaraṇaṃ tṛtīyam |
prathamaḥ sargaḥ 1
vāgbhābhirbrahmavidbrahma bhāti svapna ivātmani |
yadidaṃtatsvaśabdotthairyo yadvetti sa vetti tat
]

`v 2 [
nyāyenānena loke'sminsarge brahmāmbare sati |
kimidaṃ kasya kutreti codyamūce nirākṛtam
]

`v 3 [
ahaṃ tāvadyathājñānaṃ yathāvastu yathākramam |
yathāsvabhāvaṃ tatsarvaṃ vacmīdaṃ śrūyatāṃ budha
]

`v 4 [
svapnavatpaśyati jagaccinnabhodehavitsvayam (cinmayaṃ iti pāṭhaḥ) |
svapnasaṃsāradṛṣṭānta evāhaṃtvaṃsamanvitam
]

`v 5 [
p. 128)
mumukṣuvyavahāroktimayātprakaraṇātprakaraṇātparam |
athotpattiprakaraṇaṃ mayedaṃ parikathyate
]

`v 6 [
bandho'yaṃ dṛśyasadbhāvāddṛśyābhāvena bandhanam (sadbhāvo
dṛśyābhāvena iti pāṭhaḥ) |
na saṃbhavati dṛśyaṃ tu yathedaṃ tacchṛṇu kramāt
]

`v 7 [
utpadyate yo jagati sa eva kila vardhate |
sa eva mokṣamāpnoti svargaṃ vā narakaṃ ca vā
]

`v 8 [
ataste svāvabodhārthaṃ tattāvatkathayāmyaham |
utpattiḥ saṃsṛtāveti pūrvameva hi yo yathā
]

`v 9 [
idaṃ prakaraṇārthaṃ tvaṃ saṃkṣepācchṛṇu rāghava |
tataḥ saṃkathayiṣyāmi vistaraṃ te yathepsitam
]

`v 10 [
yadidaṃ dṛśyate sarvaṃ jagatsthāvarajaṃgamam |
tatsuṣuptāviva svapnaḥ kalpānte pravinaśyati
]

`v 11 [
tataḥ stimitagambhīraṃ na tejo na tamastatam |
anākhyamanabhivyaktaṃ satkiṃcidavaśiṣyate
]

`v 12 [
ṛtamātmā paraṃ brahma satyamityādikā budhaiḥ |
kalpitā vyavahārārthaṃ tasya saṃjñā mahātmanaḥ
]

`v 13 [
sa tathābhūta evātmā svayamanya ivollasan |
jīvatāmupayātīva bhāvināmnā (bhāvināma iti pāṭhaḥ) kadarthitām
]

`v 14 [
tataḥ sa jīvaśabdārthakalanākulatāṃ gataḥ |
mano bhavati bhūtātmā mananānmantharībhavan
]

`v 15 [
manaḥ saṃpadyate tena mahataḥ paramātmanaḥ |
susthirādasthirākārastaraṅga iva vāridheḥ
]

`v 16 [
tatsvayaṃ svairamevāśu saṃkalpayati nityaśaḥ |
tenetthamindrajālaśrīrvitateyaṃ vitanyate
]

`v 17 [
yathā kaṭakaśabdārthaḥ pṛthaktvārho na kāñcanāt |
na hema kaṭakāttadvajjagacchabdārthatā pare
]

`v 18 [
itthamadhyāropasahasreṇāpi nādhiṣṭhānasya pāramārthikasthitibhaṅga iti
darśayituṃ dṛṣṭāntamāha - yatheti |
hemakaṭakarūpātkāñcanātkaṭakaśabdārtho yathā pṛthaktvārho netyanvayaḥ |
pare brahmaṇi pratibhātā jagacchabdārthatāpi tataḥ pṛthaktvārhā netyarthaḥ || 17
||
brahmaṇyevāstyanantātma yathāsthitamidaṃ jagat |
na jagacchabdakārthe'sti hemnīva kaṭakātmatā
]

`v 19 [
p. 129)
satī vāpyasatī tāpanadyeva laharī calā |
manasehendrajālaśrīrjāgatī pravitanyate
]

`v 20 [
avidyā saṃsṛtirbandho māyā moho mahattamaḥ |
kalpitānīti nāmāni yasyāḥ sakalavedibhiḥ
]

`v 21 [
bandhasya tāvadrūpaṃ tvaṃ kathyamānamidaṃ śṛṇu |
tataḥ svarūpaṃ mokṣasya jñāsyasīndunibhānana
]

`v 22 [
draṣṭurdṛśyasya sattāṅga bandha ityabhidhīyate |
draṣṭā dṛśyabalādvaddho (vaśādvaddha iti pāṭhaḥ)
dṛśyābhāve vimucyate
]

`v 23 [
jagattvamahamityādirmithyātmā dṛśyamucyate |
yāvadetatsaṃbhavati tāvanmokṣo na vidyate
]

`v 24 [
nedaṃ nedamiti vyarthapralāpairnopaśāmyati |
saṃkalpajanakairdṛśyavyādhiḥ pratyuta vardhate
]

`v 25 [
na ca tarkabharakṣodairna tīrthaniyamādibhiḥ |
sato dṛśyasya jagato yasmādeti vicārakāḥ (vicāraka iti pāṭhaḥ) ||
25 ||
he vicārakāḥ dṛśyasya sataḥ dṛśye sati tarkātiśayādinā dṛśyavyādhirna
śāmyatītyetāvadeva na kiṃtvanyo'pyeti āgacchatītyarthaḥ | ṣaṣṭhī cānādare iti
bhāvalakṣaṇe ṣaṣṭhī | dṛśyasattā nānādarādupekṣyā kiṃtu vicāreṇa
bādhyetyarthaḥ
]

`v 26 [
jagaddṛśyaṃ tu yadyasti na śāmyatyeva kasyacit |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ
]

`v 27 [
acetyacitsvarūpātmā yatra yatraiva tiṣṭhati |
draṣṭā tatrāsya dṛśyaśrīḥ samudetyapyaṇūdare
]

`v 28 [
tasmādasti jagaddṛśyaṃ tatprasṛṣṭamidaṃ mayā |
tyaktaṃ tapodhyānajapairiti kāñjikatṛptivat
]

`v 29 [
yadi rāma jagaddṛśyamasti tatpratibimbati |
paramāṇūdare'pyasmiṃścidādarśe tathaiva hi
]

`v 30 [
yatra tatra sthite yadvaddarpaṇe pratibimbati |
adnyabdhyurvīnadīvāri cidādarśe tathaiva hi
]

`v 31 [
tatastatra punarduḥkhaṃ jarā maraṇajanmanī |
bhāvābhāvagrahotsargaḥ sthūlasūkṣmacalācalaḥ
]

`v 32 [
idaṃ pramārjitaṃ dṛśyaṃ mayā cātrāhamāsthitaḥ |
etadevākṣayaṃ bījaṃ samādhau saṃsṛtismṛteḥ
]

`v 33 [
sati tvasminkuto (jgaddṛśye iti pāṭhaḥ) dṛśye
nirvikalpasamādhitā |
samādhau cetanatvaṃ tu turyaṃ cāpyupapadyate
]

`v 34 [
vyutthāne hi samādhānātsuṣuptānta ivākhilam |
jagadduḥkhamidaṃ bhāti yathāsthitamakhaṇḍitam
]

`v 35 [
prāptaṃ bhavati he rāma tatkiṃ nāma samādhibhiḥ |
bhūyo'narthanipāte hi kṣaṇasāmye hi kiṃ sukham
]

`v 36 [
yadi vāpi samādhāne nirvikalpe sthitiṃ vrajet |
tadakṣayasuṣuptābhaṃ tanmanyetāmalaṃ padam
]

`v 37 [
p. 130)
prāpyate sati dṛśye'sminna ca kiṃnāma kenacit |
yatra yatra kilāyāti cittatāsya jagadbhramaḥ
]

`v 38 [
draṣṭātha yadi pāṣāṇarūpatāṃ bhāvayanbalāt |
kilāste tattadante'pi bhūyo'syodeti dṛśyatā
]

`v 39 [
na ca pāṣāṇatātulyā nirvikalpasamādhayaḥ |
keṣāṃcitsthitimāyānti sarvairityanubhūyate
]

`v 40 [
na ca pāṣāṇatātulyā rūḍhiṃ (vṛddhiṃ yātāḥ iti pāṭhaḥ) yātāḥ
samādhayaḥ |
bhavantyagrapadaṃ śāntaṃ cidrūpamajamakṣayam
]

`v 41 [
tasmādyadīdaṃ saddṛśyaṃ tanna śāmyetkadācana |
śāmyettapojapadhyānairdṛśyamityajñakalpanā
]

`v 42 [
ālīnavallarīrūpaṃ yathā padmākṣakoṭare |
āste kamalinībījaṃ tathā draṣṭari dṛśyadhīḥ
]

`v 43 [
yathā rasaḥ padārtheṣu yathā tailaṃ tilādiṣu |
kusumeṣu yathā'modastathā draṣṭari dṛśyadhīḥ
]

`v 44 [
yatra yatra sthitasyāpi karpūrādeḥ sugandhitā |
yathodeti tathā dṛśyaṃ ciddhātorudare jagat
]

`v 45 [
yathā cātra tava svapnaḥ saṃkalpaścittarājyadhīḥ |
svānubhūtyaiva dṛṣtāntastathā hṛdyasti dṛśyabhūḥ
]

`v 46 [
tasmāccittavikalpasthapiśāco bālakaṃ yathā |
vinihantyevamapyetaṃ draṣṭāraṃ dṛśyarūpikā
]

`v 47 [
yathāṅkuro'ntarbījasya saṃsthito deśakālataḥ |
karoti bhāsuraṃ dehaṃ tanotyevaṃ hi dṛśyadhīḥ
]

`v 48 [
yadi sarvaṃ dṛśyaṃ hṛdyasti tarhyadhunaiva sarvaiḥ kuto nānubhūyate tatrāha
- yatheti | deśakālakarmaparipākā api tadāvirbhāvasahakāriṇa iti bhāvaḥ || 47
||
dravyasya hṛdyeva camatkṛtiryathā
sadoditāstyastamitojjhitodare |
dravyasya cinmātraśarīriṇastathā
svabhāvabhūtāstyudare jagatsthitiḥ
]