`v 1 [
aṣṭamaḥ sargaḥ 8
śrīrāma uvāca |
kayaitajjñāyate yuktyā kathametatprasidhyati |
nyāyānubhūta etasminna jñeyamavaśiṣyate
]

`v 2 [
p. 146)
śrīvasiṣṭha uvāca |
bahukālamiyaṃ rūḍhā mithyājñānaviṣūcikā |
jagannāmnyavicārākhyā vinā jñānaṃ na śāmyati
]

`v 3 [
vadāmyākhyāyikā rāma yā imā bodhasiddhaye |
tāścecchṛṇoṣi tatsādho mukta evāsi buddhimān
]

`v 4 [
no cedudvegaśīlatvādardhādutthāya gacchasi |
tattiryagdharmiṇaste'dya na kiṃcidapi setsyati
]

`v 5 [
yo'yamarthaṃ prārthayate tadarthaṃ yatate tathā |
so'vaśyaṃ tadavāpnoti na cecchrānto nivartate
]

`v 6 [
sādhusaṃgamasacchāstraparo bhavasi rāma cet |
taddinaireva no māsaiḥ prāpnoṣi paramaṃ padam
]

`v 7 [
śrīrāma uvāca |
ātmajñānaprabodhāya śāstraṃ śāstravidāṃ vara |
kiṃ nāma tatpradhānaṃ syādyasmiñjñāte na śocyate
]

`v 8 [
śrīvasiṣṭha uvāca |
ātmajñānapradhānānāmidameva mahāmate |
śāstrāṇāṃ paramaṃ śāstraṃ mahārāmāyaṇaṃ śubham
]

`v 9 [
itihāsottamādasmācchrutādbodhaḥ pravartate |
sarveṣāmitihāsānāmayaṃ sāra udāhṛtaḥ
]

`v 10 [
śrute'sminvāṅmaye yasmājjivanmuktatvamakṣayam |
udeti svayamevāta idamevātipāvanam
]

`v 11 [
sthitamevāstamāyāti jagaddṛśyaṃ vicāraṇāt |
yathā svapne parijñāte svapnādāveva bhāvanā
]

`v 12 [
yadihāsti tadanyatra yannehāsti na tatkvacit |
imaṃ samastavijñānaśāstrakośaṃ vidurbudhāḥ
]

`v 13 [
ya idaṃ śṛṇuyānnityaṃ tasyodāracamatkṛteḥ |
bodhasyāpi paraṃ bodhaṃ buddhireti na saṃśayaḥ
]

`v 14 [
yasmai nedaṃ tvarucaye rocate duṣkṛtodayāt |
vicārayatu yatkiṃcitsacchāstraṃ jñānavāṅmayam
]

`v 15 [
jīvanmuktatvamasmiṃstu śrute samanubhūyate |
svayameva yathā pīte nīrogatvaṃ varauṣadhe
]

`v 16 [
śrūyamāṇe hi śāstre'smiñchrotā vettyetadātmanā |
yadhāvadidamasmābhirnanūktaṃ varaśāpavat
]

`v 17 [
naśyati saṃsṛtiduḥkhamidaṃ te
svātmavicāraṇayā kathayaiva |
no dhanadānatapaḥśrutavedai-
statkathanoditayatnaśatena
]