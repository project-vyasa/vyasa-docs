`v 1 [
pañcottaraśatatamaḥ sargaḥ 105
śrīvasiṣṭha uvāca |
muhūrtadvitayenātha bodhamāpa mahīpatiḥ |
prāvṛṣeṇyāmbunirmuktamamboruhamivottamam
]

`v 2 [
āsanātsāṅgadottaṃsaḥ prabuddho'sāvakampayat |
savanābhogaśṛṅgāgryo bhūkampa iva parvataḥ
]

`v 3 [
babhūvātha prabuddho'sāvāsanopari kampitaḥ |
vikṣubdha iva pātālavāraṇe śaṅkarācalaḥ
]

`v 4 [
patantaṃ dhārayāmāsustaṃ purogā nṛpaṃ bhujaiḥ |
meruṃ pralayavikṣubdhaṃ kulaśailāstaṭairiva
]

`v 5 [
purogairdhāryamāṇo'sau paryākulamatirnṛpaḥ |
vīcivikṣobhitasyendorbabhāra vanamāḥ śriyaḥ
]

`v 6 [
p. 375) 222
ko'yaṃ pradeśaḥ kasyeyaṃ sabheti sa nṛpaḥ śanaiḥ |
dadhvāna majjadambhojakośastha iva ṣaṭpadaḥ
]

`v 7 [
athovāca sabhā deva kimetaditi sādaram |
raṇanmadhukarī bhānuṃ dṛṣṭarāhumivābjinī
]

`v 8 [
athainaṃparipapracchuḥ purogā mantriṇastathā |
pralayollāsasaṃtrastaṃ mārkaṇḍeyamivāmarāḥ
]

`v 9 [
tvayītthaṃ saṃsthite deva vayamatyantamākulāḥ |
abhedyamapi bhindanti nirnimittaṃ bhramā manaḥ
]

`v 10 [
āpātaramaṇīyeṣu paryantaviraseṣu ca |
bhogeṣviva vikalpeṣu keṣu te lulitaṃ manaḥ
]

`v 11 [
satatodāravṛttāsu kathāsu pariśītalam |
manaste nirmalaṃ kasmātsaṃbhrameṣu nimajjati
]

`v 12 [
tucchālambanamālūnaviśīrṇaṃ lokavṛttiṣu |
mano mohamupādatte na mahattvavijṛmbhitam
]

`v 13 [
sātatyena hi yaivāsya manaso vṛttirutthitā |
śarīramadamattāsu tāmevaitadvidhāvati
]

`v 14 [
atucchālambanaṃ dhīraṃ prabuddhaṃ guṇahāri ca |
tavāpi hi manaścitramālūnamiva lakṣyate
]

`v 15 [
anabhyastavivekaṃ hi deśakālavaśānugam |
mantrauṣadhivaśaṃ yāti mano nodāravṛttimat
]

`v 16 [
nityamāttavivekasya kathamālūnaśīrṇatā |
dhunoti vitataṃ ceto vātyeva vibudhācalam
]

`v 17 [
iti jātānugīrṇasya bhūpateḥ kāntirānanam |
bhūṣayāmāsa śītāṃśuṃ māsānta iva pūrṇatā
]

`v 18 [
rarāja rājā saumyāsyamunmīlitavilocanaḥ |
gate himartāvullāsipuṣpaugha iva mādhavaḥ
]

`v 19 [
athātisaṃbhramāścaryakhinnāsmṛtimukho babhau |
āsannamṛtyurālokya rāhumindurivāmbare
]

`v 20 [
aindrajālikamālokya provācātha hasanniva |
babhuṃ hiṃsātmakaṃ dṛṣṭvā sarparūpīva takṣakaḥ
]

`v 21 [
jālma jālajaṭālena kimetadbhavatāṃ kṛtam |
yenāspandaprasanno'bdhiḥ kṣaṇādetya prasannatām
]

`v 22 [
citraṃ citrā hi devasya padārthaśataśaktayaḥ |
suśaktamapi me cittaṃ yābhirmohe niveśitam
]

`v 23 [
kva vayaṃ lokaparyāyakṛtāntapadavedinaḥ |
kva manomohadāyinyo vitatāḥ prakṛtāpadaḥ
]

`v 24 [
apyabhyastamahājñānaṃ manastiṣṭhati dehake |
kadācinmohamādatte kṣaṇaṃ matimatāmapi
]

`v 25 [
idamāścaryamākhyānaṃ śrūyatāṃ re sabhāsadaḥ |
mama śāmbarikeṇeha yanmuhūrtaṃ pradarśitam
]

`v 26 [
dṛṣṭavānahametasminbahvīḥ kāryadaśāścalāḥ |
muhūrtaṃ prārthito'dhvastaśakrasṛṣṭirivābjajaḥ
]

`v 27 [
ityuktvonmukhanetreṣu sabhyeṣu sa hasanniva |
rājā varṇayituṃ citraṃ vṛttāntamupacakrame
]

`v 28 [
p. 376) 223
rājovāca |
iha vividhapadārthasaṃkulāyāṃ
hradanadapattanaparvatākulāyām |
kulaśikharisamudrasaṃkarāyāṃ
bhuvi vibhavāvalito'styayaṃ pradeśaḥ
]