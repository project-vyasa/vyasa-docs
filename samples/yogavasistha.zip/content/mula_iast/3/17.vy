`v 1 [
saptadaśaḥ sargaḥ 17
śrīsarasvatyuvāca |
śavībhūtamimaṃ vatse bhartāraṃ puṣpapuñjake |
ācchādya sthāpayainaṃ tvaṃ punarbhartārameṣyasi
]

`v 2 [
puṣpāṇi mlānimeṣyanti no nacaiṣa vinaṅkṣyati |
bhūyaśca tava bhartṛtvamacireṇa kariṣyati
]

`v 3 [
etadīyaśca jīvo'sāvākāśaviśadastava |
na nirgamiṣyati kṣipramito'ntaḥpuramaṇḍapāt
]

`v 4 [
ṣaṭpadaśreṇinayanā samākarṇyeti bandhubhiḥ |
sā samāśvāsitāgatya payobhiriva padminī
]

`v 5 [
patiṃ saṃsthāpya tatraiva puṣpapūrapragopitam |
kiṃcidāśvāsitā'tiṣṭhaddaridreva nidhāninī
]

`v 6 [
p. 171)
tasminneva dine saiṣā tasmiñchuddhāntamaṇḍape |
ardharātre parijane sarvasminnidrayā hṛte
]

`v 7 [
jñaptiṃ bhagavatīṃ devīṃ śuddhadhyānamahādhiyā |
duḥkhādāhvāyayāmāsa sovāca samupetya tām
]

`v 8 [
kiṃ smṛtāsmi tvayā vatse dhatse kimiti śokitām |
saṃsārabhrāntayo bhānti mṛgatṛṣṇāmbuvanmudhā
]

`v 9 [
līlovāca |
kva mamāvasthito bhartā kiṃ karotyatha kīdṛśaḥ |
samīpaṃ naya māṃ tasya naikā śaknopi jīvitum
]

`v 10 [
śrīdevyuvāca |
cittākāśaṃ cidākāśamākāśaṃ ca tṛtīyakam |
dvābhyāṃ śūnyataraṃ viddhi cidākāśaṃ varānane
]

`v 11 [
taccidākāśakośātma cidākāśaikabhāvanāt |
avidyamānamapyāśu dṛśyate'thānubhūyate
]

`v 12 [
deśāddeśāntaraprāptau saṃvido madhyameva yat |
nimiṣeṇa cidākāśaṃ tadviddhi varavarṇini
]

`v 13 [
tasminnirastaniḥśeṣasaṃkalpā sthitimeṣi cet |
sarvātmakaṃ padaṃ tattvaṃ tvaṃ tadāpnoṣyasaṃśayam
]

`v 14 [
atyantābhāvasaṃpattyā jagataścaitadāpyate |
nānyathā madvareṇāśu tvaṃ tu prāpsyasi sundari
]

`v 15 [
śrīvasiṣṭha uvāca |
ityuktvā sā yayau devī divyamātmīyamāspadam |
līlā tu līlayaivāsīnnirvikalpasamādhibhāk
]

`v 16 [
tattatyāja nimeṣeṇa sāntaḥkaraṇapañjaram |
svadehaṃ khamivoḍḍīnā muktanīḍā vihaṃgamī
]

`v 17 [
dadarśa khasthā bhartāraṃ tasminnevālayāmbare |
saṃsthitaṃ pṛthvīpālamāsthāne bahurājani
]

`v 18 [
siṃhāsane samārūḍhaṃ jayajīveti saṃstutam |
prastutaṃ maṇḍalānīkakāryamāhartumādṛtam
]

`v 19 [
patākāmañjarīkīrṇarājadhānīgṛhasthitam |
pūrvadvārasthitāsaṃkhyamuniviprarṣimaṇḍalam
]

`v 20 [
dakṣiṇadvāragāsaṃkhyarājarājeśamaṇḍalam |
paścimadvāragāsaṃkhyalalanālokamaṇḍalam
]

`v 21 [
uttaradvāragāsaṃkhyarathahastyaśvasaṃkulam |
ekabhṛtyavinirṇītadakṣiṇāpathavigrahma
]

`v 22 [
karṇāṭanātharacitapūrvadeśakriyākramam |
surāṣṭrādhipanirṇītasarvamlecchottarāpatham
]

`v 23 [
māladeśasamākrāntasarvapāścātyataṅgaṇam |
dakṣiṇābdhitaṭāyātalaṅkādūtavinoditam
]

`v 24 [
pūrvābdhitaṭamāhendrasiddhoktagaganāpagam |
uttarābdhitaṭāyātadūtavarṇitaguhyakam
]

`v 25 [
paścimābdhitaṭālokavarṇitāstamayakramam |
asaṃkhyabaddhabhūpālakalākīrṇākhilājiram
]

`v 26 [
yajñavāṭapaṭhadviprajitatūryāgraniḥsvanam |
bandikolāhalollāsapratiśrudvanakuñjaram
]

`v 27 [
p. 172)
geyavādyotadhvānapradhvanadgānāntaram |
hayahastirathārājirajomeghaghanāmbaram
]

`v 28 [
puṣpakarpūradhūpāḍhyaṃ gandhāmoditaparvatam |
sarvamaṇḍalasaṃbhāraracitānekaśāsanam
]

`v 29 [
yaśaḥkarpūrajaladasuśubhrāmbaraparvatam |
rodasīstambhabhūtaikasvapratāpajitārkakam
]

`v 30 [
ārambhamantharodārakāryasaṃvyagrabhūmipam |
nānānagaranirmāṇasodyogasthapatīśvaram
]

`v 31 [
papātātha mahārambhā sā tāṃ narapateḥ sabhām |
vyomātmikā vyomamayīṃ mihikevāmbarāṭavīm
]

`v 32 [
bhramantīṃ tatra tāmagre dadṛśuste na kecana |
saṃkalpamātraracitāṃ puruṣāḥ kāminīmiva
]

`v 33 [
tathā te tāṃ na dadṛśuḥ saṃcarantīṃ purogatām |
anyasaṃkalparacitāmanyena nagarīṃ yathā
]

`v 34 [
prāktanāneva tānsarvānsvāndadarśa sabhāgatān |
bhūbhṛteva susaṃprāptānnagarānnagarāntaram
]

`v 35 [
taddeśāṃstatsamācārāṃstathā tāneva bālakān |
tā eva bālavanitāstāṃstāneva ca mantriṇaḥ
]

`v 36 [
tāneva bhūmipālāṃśca tāṃstāneva ca paṇḍitān |
tāneva narmasacivānbhṛtyāṃstāneva tādṛśān
]

`v 37 [
athānyānapyapūrvāṃśca paṇḍitānsuhṛdastathā |
vyavahārāṃstathānyāṃśca paurānanyāṃstathaiva ca
]

`v 38 [
madhyāhnakāle divase ghanadāvākulā diśaḥ |
antarikṣaṃ sacandrārkaṃ sāmbhodapavanadhvani
]

`v 39 [
mahīruhanadīśailapurapattanamaṇḍitam |
nānānagaravinyāsajaṅgalagrāmasaṃkulam
]

`v 40 [
dviraṣṭavarṣaṃ bhūpālaṃ prāktanyā jarasojjhitam |
prāktanīṃ janatāṃ sarvāṃ samasstāngrāmavāsinaḥ
]

`v 41 [
sā tānālokya lalanā cintāparavaśābhavat |
tasminnagaravāstavyāḥ kiṃ te sarve mṛtā `note[mṛtā api iti pāṭhaḥ]
iti
]

`v 42 [
punaḥ prajñaptibodhena prāktanāntaḥpuraṃ gatā |
kṣaṇena ca dadarśātra sārdharātre tathaiva tān
]

`v 43 [
atha sotthāpayāmāsa nidrākrāntaṃ sakhījanam |
āha cātīva me duḥkhamāsthānaṃ dīyatāmiti
]

`v 44 [
bhartuḥ siṃhāsanasyāsya pārśve tiṣṭhāmyahaṃ yadi |
paśyāmi `note[paśyantī iti pāṭhaḥ] svabhyasaṃghātaṃ tatprajīvāmi
nānyathā
]

`v 45 [
sa rājaparivāro'tha tayetyukte `note[tayetyukto iti pāṭhaḥ] yathākramam |
āsīdvinidraḥ saṃvyagraḥ `note[saṃvignaḥ iti pāṭhaḥ] sarvaḥ
sarvasvakarmaṇi
]

`v 46 [
paurānsabhyānsamānetuṃ `note[sarvānsabhyān iti pāṭhaḥ]
yayuryāṣṭikapaṅktayaḥ |
vyavahāraṃ kalayitumurvyāmarkakarā iva
]

`v 47 [
āsthānabhūmiṃ bhṛtyāśca mārjayāmāsurādṛtāḥ |
prāvṛṭayodamalinaṃ khaṃ śaradvāsarā iva
]

`v 48 [
aṅgaṇaṃ prati dīpaughāstasthuḥ pītatamombhasaḥ |
āścaryadarśanāyeva saṃprāptā ṛkṣapaṅktayaḥ
]

`v 49 [
janatāḥ pūrayāmāsuḥ pūrairajirabhūmikāḥ |
abdhīnpralayasaṃśuṣkānpurāsarga ivāmbhasā
]

`v 50 [
ājagmurmantrisāmantāḥ svasvaṃ sthānamaninditāḥ |
trailokye punarutpanne lokapālā yathā diśaḥ
]

`v 51 [
vavurākīrṇakarpūrasāndrāvaśyāyaśītalāḥ |
utphullakusumodvāntamāṃsalāmoditānilāḥ
]

`v 52 [
paryanteṣu pratīhārāstasthurdhavalavāsasaḥ |
ṛṣyamūkārkatāpārtameghamālā ivādriṣu
]

`v 53 [
paryanteṣvāsthānaprānteṣu | ṛṣyamūkaḥ sugrīvālayastatra
sugrīvānugrahāyārkasya viśeṣasaṃnidhānāttattāpārtāḥ | adriṣu himavadādiṣu |
52 |
prabhāpītatamaḥpuñjāḥ petuḥ puṣpotkarā bhuvi |
caṇḍamārutavidhvastāstārakānikarā iva
]

`v 54 [
p. 173)
āsthānaṃ pūrayāmāsurmahīpālānuyāyinaḥ |
utphullakamalotkīrṇaṃ haṃsā iva sarovaram
]

`v 55 [
soṃhāsanasamīpasthe haimacitrāsane nave |
upāviśadasau līlā līlaiva smaracetasi
]

`v 56 [
dadarśa tānnṛpānsarvānpūrvāneva yathāsthitān |
gurūnāryānsakhīnsabhyānsuhṛtsaṃbandhibāndhavān
]

`v 57 [
sakalameva hi pūrvavadeva sā
samavalokya mudaṃ paramāṃ yayau |
nṛpatirāṣṭrajanaṃ khalu jīvanā-
bhyuditayā ca babhau śaśivacchriyā
]