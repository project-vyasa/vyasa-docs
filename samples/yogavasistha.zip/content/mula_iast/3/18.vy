`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīvasiṣṭha uvāca |
itthaṃ vinodayāmīdaṃ duḥkhadaṃ cittamityalam |
bodhayitveṅgitairbhūpānāsthānādutthitātha sā
]

`v 2 [
itthamāsthānadarśanādinā
vinodayāmyāśvāsayāmītiṅgitairabhiprāyasūcakaceṣṭābhirbhūpānbodha##-
praviśyāntaḥpuraṃ bhartuḥ pārśve'ntaḥpuramaṇḍape |
viveśa puṣpaguptasya cintayāmāsa cetasā
]

`v 3 [
aho vicitrā māyeyamete'smatpuramānavāḥ |
bahirantaravaddeśe tatra ceha ca saṃsthitāḥ
]

`v 4 [
tālītamālarhitālamālitā girayo'pyamī |
yathā tatra tathehāpi vata māyeyamātatā
]

`v 5 [
ādarśe'ntarbahiścaiva yathā śailo'nubhūyate |
bahirantaścidādarśe tathā sargo'nubhūyate
]

`v 6 [
tatra bhrāntimayaḥ sargaḥ kaḥ syātkaḥ pāramārthikaḥ |
iti pṛcchāmi vāgīśāmabhyarcyoktamasaṃśayam
]

`v 7 [
iti niścitya tāṃ devīṃ pūjayāmāsa sā tadā |
dadarśa ca puraḥ prāptāṃ kumārīrūpadhāriṇīm
]

`v 8 [
bhadrāsanagatāṃ devīmupaviśya purogatā |
paramārthamahāśaktiṃ līlā'pṛcchadbhuvi sthitā
]

`v 9 [
līlovāca |
anukampyasya no devi bhajantyudvegamuttamāḥ |
tvayaivaṃ kila sargādau sthāpitā sthitiruttamā
]

`v 10 [
tadidaṃ yatpuraḥ prahvā pṛcchāmi parameśvari |
tadbrūhi tvatkṛto nūnaṃ saphalo me'stvanugrahaḥ
]

`v 11 [
asyādarśo jagannāmnaḥ khādapyadhikanirmalaḥ |
yasya yojanakoṭīnāṃ koṭayo'vayavo manāk
]

`v 12 [
niḥsaṃdhitavacojyotirghano mṛdusuśītalaḥ |
acetyaciditi khyāto nāmnā nirbhittiragrataḥ
]

`v 13 [
dikkālakalanākāśaprakāśaniyatikramāḥ |
yatreme pratibimbanti parāṃ pariṇatiṃ gatāḥ
]

`v 14 [
trijagatpratibimbaśrīrbahirantaśca saṃsthitā |
tatra vai kṛtrimā kā syātkāsau vā syādakṛtrimā
]

`v 15 [
śrīdevyuvāca |
akṛtrimatvaṃ sargasya kīdṛśaṃ vada sundari |
kīdṛśaṃ kṛtrimatvaṃ syādyathāvatkathayeti me
]

`v 16 [
p. 174)
līlovāca |
yathāhamiha tiṣṭhāmi tvaṃ ca devi sthitāmbike |
asāvakṛtrimaḥ sarga iti deveśi vedmyaham
]

`v 17 [
vipulatvena pramitasya tadaparyāptadeśakālaparicchedo mithyātvavyāpyo
giripratibimbādau dṛṣṭaḥ saca bhartṛprapañca eva dṛśyate nāsminniti
vaidharmyadarśinī līlovāca - yathetyādi dvābhyām vedmi saṃbhāvayāmi | 16
|
yatrādhunā sa bhartā me sthitaḥ sargaḥ sa kṛtrimaḥ |
ahaṃ manye yataḥ śūnyo deśakālādyapūrakaḥ
]

`v 18 [
śrīdevyuvāca |
kṛtrimo'kṛtrimātsargānna kadācana jāyate |
nahi kāraṇataḥ kāryamudetyasadṛśaṃ kvacti
]

`v 19 [
līlovāca |
dṛśyate kāraṇātkāryaṃ suvilakṣaṇamambike |
ambvādātumaśaktā mṛdghaṭastajjastadāspadam
]

`v 20 [
śrīdevyuvāca |
saṃpadyate hi yatkāryaṃ kāraṇaiḥ sahakāribhiḥ |
mukhyakāraṇavaicitryaṃ kiṃcittatrāvalokyate
]

`v 21 [
vada tadbhartṛsargasya kiṃ pṛthvyādiṣu kāraṇam |
tadbhūmaṇḍalato bhhutirjātā tatra varānane
]

`v 22 [
gataṃ `note[smṛtestat iti pāṭhaḥ] cedita uḍḍīya kutaḥ syādiha bhūtalam
|
sahakārīṇi kānīva kāraṇānyatra kāraṇe
]

`v 23 [
kāraṇānāmabhāve'pi yodeti sahakāritā |
tatpūrvakāraṇānnānyatsarveṇetyanubhūyate
]

`v 24 [
līlovāca |
smṛtiḥ sā devi madbhartustathā sphāratvamāgatā |
smṛtistatkāraṇaṃ vedmi sargo'yamiti niścayaḥ
]

`v 25 [
satyaitatsargānubhavajanyasaṃskārajaḥ pramuṣṭasattākasmṛtitulyaḥ svapna iva
madbhartuḥ sargo'stviti vidhāntareṇa vaidharmyaṃ līlā śaṅkate - smṛtiriti |
24 |
śrīdevyuvāca |
smṛtirākāśarūpā ca yathā tajjastathaiva te |
bhartuḥ sargo'nubhūto'pi sa vyomaiva tathābale
]

`v 26 [
līlovāca |
smṛtyākāśamayaḥ sargo yathā bharturmamoditaḥ |
tathaivemamahaṃ manye sa sargo'tra nidarśanam
]

`v 27 [
śrīdevyuvāca |
evametadasatsargo bhartustairbhāti bhāsuraḥ |
tathaivāyamihābhāti paśyāmyetadahaṃ sute
]

`v 28 [
līlovāca |
yathā patyuramūrto'smātsargātsargo bhramātmakaḥ |
jātastathā kathaya me jagadbhramanivṛttaye
]

`v 29 [
śrīdevyuvāca |
prāksmṛterbhrāntimātrātmā sargo'yamudito yathā |
svapnabhramātmako bhāti tathedaṃ kathyate śṛṇu
]

`v 30 [
p. 175)
asti kvaciccidākāśe kvacitsaṃsāramaṇḍapaḥ |
ākāśakācadalavatsaṃsthānācchāditākṛtiḥ
]

`v 31 [
merustambhasthalokeśapurandhrīśālabhañjikaḥ |
caturdaśāpavarakastrigarto bhānudīpakaḥ
]

`v 32 [
koṇasthabhūtavalmīkavyāptaparvataloṣṭakaḥ |
anekaputrajaraṭhaprajeśabrāhmaṇāspadam
]

`v 33 [
jīvaughakośakārāḍhyo vyomordhvatalakālimā |
nabhonivāsasiddhaughamaśakāhitaghuṃgumaḥ
]

`v 34 [
payodagṛhadhūmograjālāvalitakoṇakaḥ |
vātamārgamahāvaṃśasthitavaimānakīṭakaḥ
]

`v 35 [
surāsurādidurbālalīlākalakalākulaḥ |
lokāntarapuragrāmabhāṇḍopaskaranirbharaḥ
]

`v 36 [
saraḥsrotobdhisarasījalokṣitamahītalaḥ |
pātālabhūtalasvargabhāgabhāsurakoṭaraḥ
]

`v 37 [
tatra kasmiṃścidekasminkoṇeṣvambarakoṭare |
śailaloṣṭataleṣveko girigrāmakagartakaḥ
]

`v 38 [
tasminnadīśailavanopagūḍhe
sāgniḥ sadāraḥ sutavānarogaḥ |
gokṣīravān rājabhayādvimuktaḥ
sarvātithirdharmaparo dvijo'bhūt
]