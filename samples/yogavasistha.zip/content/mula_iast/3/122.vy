`v 1 [
dvāviṃśatyuttaraśatatamaḥ sargaḥ 122
śrīvasiṣṭha uvāca |
prathamaṃ jātamātreṇa puṃsā kiṃcidvikasitabuddhinaivaṃ
satsaṃgamapareṇa bhavitavyam
]

`v 2 [
anavaratapravāhapatito'yamavidyānadīnivahaḥ śāstrasajjanasaṃparkādṛte
na tarituṃ śakyate
]

`v 3 [
tena vivekataḥ puruṣasya heyopādeyavicāra upajāyate
]

`v 4 [
tadāsau śubhecchābhidhāṃ vivekabhuvamāpatito `note[mavatīrṇo bhavatīti
pāṭhaḥ] bhavati
]

`v 5 [
tato vivekavaśato vicāraṇāyām
]

`v 6 [
samyagjñānenāsamyagvāsanāṃ tyajataḥ saṃsārabhāvanātomanastanutāmeti
]

`v 7 [
tena tanumānasāṃ nāma vivekabhūmimavatīrṇo bhavati
]

`v 8 [
p. 413) 242
yadaiva yoginaḥ samyagjñānodayastadaiva sattvāpattiḥ
]

`v 9 [
tadvaśādvāsanā tanutāṃ gatā yadā tadaivāsāvasaṃsakta ityucyate
karmaphalena na badhyata iti
]

`v 10 [
atha tānavavaśādasatye bhāvanātānavamabhyasyati
]

`v 11 [
yāvanna kurvannapi vyavaharannapyasatyeṣu saṃsāravastuṣu sthito'pi
svātmanyeva `note[svātmanyavakṣīṇa iti pāṭhaḥ]
kṣīṇamanastvādabhyāsavaśādbāhyaṃ vastu kurvannapi na paśyati
nālambanena sevate nābhidhyāyati tanuvāsanatvācca kevalaṃ mūḍhaḥ
suptaprabuddha iva kartavyaṃ karoti
]

`v 12 [
tanubhāvitamanaskastena yogabhūmikāṃ bhāvanāmadhirūḍhaḥ
]

`v 13 [
tanubhāvitamanaskaḥ sūkṣmatamabrahmaikarasīkṛtacittastenoktalakṣaṇena
yogabhūmikāṃ bhāvanāṃ padārthābhāvanākhyāṃadhirūḍho bhavatīti śeṣaḥ |
12 |
ityantarlīnacittaḥ katicitsaṃvatsarānabhyasya sarvathaiva kurvannapi
bāhyapadārthānbhāvanāṃ tyajati turyātmā bhavati tato jīvanmukta ityucyate
]

`v 14 [
nābhinandati saṃprāptaṃ nāprāptamabhiśocati |
kevalaṃ vigatāśaṅkaṃ saṃprāptamanuvartate
]

`v 15 [
tvayāpi rāghava jñātaṃ jñātavyamakhilāntaram |
nanu te sarvakāryebhyo vāsanā tanutāṃ gatā
]

`v 16 [
śarīrātītavṛttistvaṃ śarīrastho'thavā bhava |
māgāḥ śokaṃ ca harṣaṃ tvaṃ tvamātmā vigatāmayaḥ
]

`v 17 [
tvayyātmani site svacche sarvage sarvadodite |
kuto duḥkhasukhe rāma kuto maraṇajanmanī
]

`v 18 [
abandhurapi kasmāttvaṃ bandhuduḥkhāni śocasi |
advitīye sthite hyasminbāndhavāḥ ka ivātmani
]

`v 19 [
dṛśyate kevale dehe paramāṇucayaḥ param `note[para iti pāṭhaḥ] |
deśakālānyatāpatternātmodeti na līyate
]

`v 20 [
avināśo'pi kasmāttvaṃ vinaśyāmīti śocasi |
amṛtyuvasatau svacche vināśaḥ ka ivātmani
]

`v 21 [
ghaṭe kapālatāṃ yāte ghaṭākāśo na naśyati |
yathā tathā śarīre'sminnaṣṭe'pi na vinaśyati
]

`v 22 [
mṛgatṛṣṇātaraṅgiṇyāṃ kṣīṇāyāmātapo yathā |
na naśyati tathā dehe naṣṭe nātmā vinaśyati
]

`v 23 [
vāñchaivodeti te kasmādbhrāntirantarnirarthikā |
advitīyo dvitīyaṃ kiṃyadvastvātmābhivāñchatu
]

`v 24 [
śravyaṃ spṛśyaṃ tathā dṛśyaṃ rasyaṃ ghreyaṃ ca rāghava |
na kiṃcidasti jagati vyatiriktaṃ yadātmanaḥ
]

`v 25 [
sarvaśaktāvimāstasminnātmanyevākhilāḥ sthitāḥ |
śaktayo vitate vyakte ākāśa iva śūnyatā
]

`v 26 [
cittādrāghava rūḍheyaṃ trilokīlalanoditā |
trividhenakrameṇeha janmanā janitabhramā
]

`v 27 [
tarhyatyantāsato jagataḥ prarohe kiṃ bījamiti ceccittameveti prāguktamevetyāha ##-
manaḥpraśamane siddhe vāsanākṣayanāmani |
karmakṣayāmidhānaiva māyeyaṃ pravinaśyati
]

`v 28 [
p. 414) 243
saṃsārogrāraghaṭṭe'sminnārūḍhā yantravāhinī |
rajjustāṃ vāsanāmetāṃ chindhi rāghava yatnataḥ
]

`v 29 [
aparijñānamānaiṣā mahāmohapradāyinī |
parijñātā tvanantākhyā sukhadā brahmadāyinī
]

`v 30 [
āgatā brahmaṇo bhuktvā saṃsāramiha līlayā |
punarbrahmaiva saṃsmṛtya brahmaṇyeva vilīyate
]

`v 31 [
śivādrāghava nīrūpādaprameyānnirāmayāt |
sarvabhūtāni jātāni prakāśā iva tejasaḥ
]

`v 32 [
rekhāvṛndaṃ yathā parṇe vīcijālaṃ yathā jale |
kaṭakādi yathā hemni tathoṣṇādi yathā'nale
]

`v 33 [
tadetadbhāvanārūpe tathedaṃ bhuvanatrayam |
tasminneva sthitaṃ jātaṃ tasmādeva tadeva ca
]

`v 34 [
sa eva sarvabhūtānāmātmā brahmeti kathyate |
tasmiñjñāte jagajjñātaṃ sa jñātā bhuvanatraye
]

`v 35 [
śāstrasaṃvyavahārārthaṃ tasyāsya vitatākṛteḥ |
cidbrahmātmeti nāmāni kalpitāni kṛtātmabhiḥ
]

`v 36 [
viṣayendriyasaṃyoge harṣāmarṣavivarjitā |
saiṣā śuddhānubhūtirhi so'yamātmā cidavyayaḥ
]

`v 37 [
ākāśātitarācchāccha idaṃ tasmiṃścidātmani |
svābhoga eva hi jagatpṛthagvatpratibimbati
]

`v 38 [
buddhistadvyatirekeṇa lobhamohādayo hi tān |
pātyasadvyatirekeṇa te ca tasmiṃstadeva te
]

`v 39 [
te ca jagattadbuddhitatprayuktalobhamohādayaḥ asataiva vyatirekeṇa parasparabhedena
tasmiṃścidātmani pratibimbitā iti paramārthatastadātmarūpameva | tena hi
darpaṇavyatirekeṇa tadantardṛśyamānāḥ parvatavananadyādayaḥ santītyarthaḥ |
38 |
adehasyaiva te rāma nirvikalpacidākṛteḥ |
lajjābhayaviṣādebhyaḥ kuto mohaḥ samutthitaḥ
]

`v 40 [
adeho dehajairebhirlajjādibhirasanmayaiḥ |
kiṃ mūrkha iva durbuddhirvikalpairabhibhūyase
]

`v 41 [
akhaṇḍacitirūpasya dehe khaṇḍanamāgate |
asamyagdarśino'pyasti na nāśaḥ kimu sanmateḥ
]

`v 42 [
āpatedarkamārge'pi na niruddhagamāgamam |
cittaṃ nāma sa vijñeyaḥ puruṣo na śarīrakam
]

`v 43 [
śarīre satyasati vā pumāneva jagattraye |
jño'pyajño'pi sthito rāma naṣṭe dehe na naśyati
]

`v 44 [
yānīmāni vicitrāṇi duḥkhāni paripaśyasi |
tāni dehasya sarvāṇi nāgrāhyasya cidātmanaḥ
]

`v 45 [
manomārgādatītatvādyāsau śūnyamiva sthitā |
citkathaṃ nāma duḥkhairvā sukhairvā parigṛhyate
]

`v 46 [
svāspadātmānamevāsau vinaṣṭādehapañjarāt |
abhyastāṃ vāsanāṃ yātaḥ ṣaṭpadaḥ khamivāmbujāt
]

`v 47 [
asaccedātmatattvaṃ tadasmiṃste dehapañjare |
naṣṭe kiṃ nāma naṣṭaṃ syādrāma kenānuśocasi
]

`v 48 [
p. 415) 243
satyaṃ bhāvaya tena tvaṃ mā mohamanubhāvaya |
niricchasyātmano necchā kācidapyanaghākṛteḥ
]

`v 49 [
sākṣibhūte same svacche nirvikalpe cidātmani |
niricchaṃ pratibimbanti jaganti mukure yathā
]

`v 50 [
sākṣibhūte same svacche nirvikalpe cidātmani |
svayaṃ jaganti dṛśyante sanmaṇāviva raśmayaḥ
]

`v 51 [
anicchamapi saṃbandho yathā darpaṇabimbayoḥ |
tathaivehātmajagatorbhedābhedau vyavasthitau
]

`v 52 [
sūryasaṃnidhimātreṇa yathodeti jagatkriyā |
citsattāmātrakeṇedaṃ jaganniṣpadyate tathā
]

`v 53 [
piṇḍagraho nivṛtto'syā evaṃ rāma jagatsthiteḥ |
ākāśameṣā saṃpannā bhavatāmapi cetasi
]

`v 54 [
sattāmātreṇa dīpasya yathālokaḥ svabhāvataḥ |
cittattvasya svabhāvāttu tatheyaṃ jāgatī sthitiḥ
]

`v 55 [
pūrvaṃ manaḥ samuditaṃ paramātmatattvā-
ttenātataṃ jagadidaṃ svavikalpajālaiḥ |
śūnyena śūnyamapi tena yathāmbareṇa
nīlatvamullasitacārutarābhidhānam
]

`v 56 [
saṃkalpasaṃkṣayavaśādgalite tu citte
saṃsāramohamihikā galitā bhavanti |
svacchaṃ vibhāti śaradīva khamāgatāyāṃ
cinmātramekamajamādyamanantamantaḥ
]

`v 57 [
karmātmakaṃ prathamameva mano'bhyudeti
saṃkalpataḥ kamalajaprakṛtīstadetya |
nānābhidaṃ jagadidaṃ hi mudhā tanoti
vetāladehakalanāmiva mugdhabālaḥ
]

`v 58 [
asanmayaṃ sadiva puro vilakṣyate
punarbhavatyatha parilīyate punaḥ |
svayaṃ manaściti citasaṃsphuradvapu-
rmahārṇave jalavalayāvalī yathā
]