`v 1 [
p. 348) 209
dvinavatitamaḥ sargaḥ 92
śrīvasiṣṭha uvāca |
ityuktavānsa bhagavānmayā kamalasaṃbhavaḥ |
raghūdvaha punaḥ pṛṣṭo vākyamākṣipya bhūtapaḥ
]

`v 2 [
tvayaiva bhagavanproktāḥ śāpamantrādiśaktayaḥ |
amoghā iti tā eva kathaṃ moghāḥ kṛtāḥ punaḥ
]

`v 3 [
śāpena mantravīryeṇa manobuddhīndriyāṇyapi |
sarvāṇyeva vimūḍhāni dṛṣṭāni kila jantuṣu
]

`v 4 [
yathaitau pavanaspandau yathā snehatilau yathā |
abhinnau tadvadevaitau manodehau sa eva tat
]

`v 5 [
atha nāstīha vā dehaḥ kevalaṃ cetasaiva saḥ |
mudhānubhūyate svapnamṛgatṛṣṇādvicandravat
]

`v 6 [
ekanāśe dvayoreva nāśo'trābhyupapadyate |
avaśyaṃ bhavituṃ manonāśe dehaparikṣayaḥ
]

`v 7 [
manaḥ śāpādibhirdoṣaiḥ kathaṃ nākramyate prabho |
kathamākramyate vāpi brūhi me parameśvara
]

`v 8 [
brahmovāca |
na tadastijagatkośe śubhakarmānupātinā |
yatpauruṣeṇa śuddhena na saptāsādyate janaiḥ
]

`v 9 [
ābrahma sthāvarāntaṃ ca sarvadā sarvajātayaḥ |
sarva eva jagatyasmindviśarīrāḥ śarīriṇaḥ
]

`v 10 [
ekaṃ manaḥśarīraṃ tu kṣiprakāri sadā calam |
akiṃcitkaramanyattu śarīraṃ māṃsanirmitam
]

`v 11 [
tatra māṃsamayaḥ kāyaḥ sarvasyaiva ca saṃgataḥ |
sarvairākramyate śāpaistathā vidyādisaṃcayaiḥ
]

`v 12 [
mūkaprāyo hyaśakto'sau dīnaḥ kṣaṇavinaśvaraḥ |
padmapatrāmbucapalo daivādivivaśasthitiḥ
]

`v 13 [
manonāma dvitīyo'yaṃ kāyaḥ kāyavatāmiha |
sa āyatto'pi nāyatto bhūtānāṃ bhuvanatraye
]

`v 14 [
pauruṣaṃ svamavaṣṭabhya dhairyamālambya śāśvatam |
yadi tiṣṭhatyagamyo'sau duḥkhānāṃ tadaninditaḥ
]

`v 15 [
yathā yathāsau yatate manodeho hi dehinām |
tathā tathāsau bhavati svaniścayaphalaikabhāk
]

`v 16 [
saphalo māṃsadehasya na kaścitpauruṣakramaḥ |
manodehasya saphalaṃ sarvameva svaceṣṭitam
]

`v 17 [
pavitramanusaṃdhānaṃ cetaḥ smarati sarvadā |
niṣphalāstatra śāpādyāḥ śilāyāmiva sāyakāḥ
]

`v 18 [
patatvambhasi vahnau vā kardame vā śarīrakam |
mano yadanusaṃdhatte tadevāpnoti tatkṣaṇāt
]

`v 19 [
puruṣātiśayaḥ sarvaḥ sarvabhāvopamardane |
dadātyavighnena phalaṃ mano hi manaso mune
]

`v 20 [
pauruṣeṇa balenāntaścittaṃ kṛtvā priyāmayam |
kṛtrimendreṇa duḥkhārtirna dṛṣṭā sā manāgapi
]

`v 21 [
p. 349) 209
pauruṣeṇa manaḥ kṛtvā nīrāgaṃ vigatajvaram |
māṇḍavyena jitāḥ kleśāḥśūlaprānte'pi tiṣṭhatā
]

`v 22 [
andhakūpasthitenāpi mānasairyajñasaṃcayaiḥ |
ṛṣiṇā dīrghatapasā saṃprāptaṃ vaibudhaṃ padam
]

`v 23 [
induputrairnaraireva puruṣādhyavasāyataḥ |
dhyānena brahmatā prāptā sā mayāpi na khaṇḍyate
]

`v 24 [
anye'pi sāvadhānā ye dhīrāḥ suramaharṣayaḥ |
cittātsvamanusaṃdhānaṃ na tyajanti manāgapi
]

`v 25 [
ādhayo vyādhayaścaiva śāpāḥ pāpadṛśastathā |
na khaṇḍayanti taccittaṃ padmaghātāḥ śilāmiva
]

`v 26 [
ye cāpi khaṇḍitāḥ kecicchāpādyairādhisāyakaiḥ |
svavivekākṣamaṃ teṣāṃ mano manye vipauruṣam
]

`v 27 [
na kadācana saṃsāre sāvadhānamanā manāk |
svapne'pi kaściddṛśye vā doṣajālaiḥ khilīkṛtaḥ
]

`v 28 [
manasaiva manastasmātpauruṣeṇa pumāniha |
svakameva svakenaiva yojayetpāvane pathi
]

`v 29 [
pratibhātaṃ yadevāsya yathābhūtaṃ bhavatyalam |
kṣaṇādeva manaḥ pīnaṃ bālavetālavanmune
]

`v 30 [
pratibhāsasyānupadaṃ prāktanīṃ sthitimujjhati |
kulālakarmānupadaṃ ghaṭo mṛtpiṇḍatāmiva
]

`v 31 [
pratibhāsārthatāmeti kṣaṇādeva mano mune |
spandamātrātmakaṃ vāri yathā tuṅgataraṅgatām
]

`v 32 [
anusaṃdhānamātreṇa sūryabimbe'pi yāminīm |
manaḥ paśyatyaśuddhākṣaścandrabimbe dvitāmiva
]

`v 33 [
yatpaśyati tadevāśu phalībhūtamidaṃ manaḥ |
saha harṣaviṣādābhyāṃ bhuṅkte tasmāttadeva tat
]

`v 34 [
pratibhānupadaṃ cetaścandre'pyagniśikhāśatam |
dṛṣṭvā dāhamavāpnoti dagdhaṃ ca paritapyate
]

`v 35 [
pratibhānupadaṃ cetaḥ kṣāre'pi hi rasāyanam |
dṛṣṭvā pītvā parāṃ tṛptiṃ yāti valgati nṛtyati
]

`v 36 [
pratibhānupadaṃ ceto vyomanyapi mahāvanam |
dṛṣṭvā lunāti ca punarāropayatyalam
]

`v 37 [
itthaṃ yadeva parikalpayatīndrajālaṃ
kṣipraṃ tadeva paripaśyati tāta cetaḥ |
nāsajjaganna ca sadityavagamya nūnaṃ
lūnāṃ dṛśaṃ vividhamedavatīṃ jahīhi
]