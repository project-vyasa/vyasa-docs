`v 1 [
p. 289) 177
pañcaṣaṣṭitamaḥ sargaḥ 65
śrīvasiṣṭha uvāca |
parasmātkāraṇādeva manaḥ prathamamutthitam |
mananātmakamābhogi tatsthameva sthitiṃ gatam
]

`v 2 [
bhāvābhāvalasaddolaṃ tenāyamavalokyate |
sargaḥ sadasadābhāsaḥ pūrvagandha ivecchayā
]

`v 3 [
na kaścidvidyate bhedo dvaitaikyakalanātmakaḥ |
brahmajīvamanomāyākartṛkarmajagaddṛśām
]

`v 4 [
apārāvāravistārasaṃvitsalilavalganaiḥ |
cidekārṇava evāyaṃ svayamātmā vijṛmbhate
]

`v 5 [
asatyamasthairyavaśātsatyaṃ saṃpratibhāsataḥ |
yathā svapnastathā cittaṃ jagatsadasadātmakam
]

`v 6 [
na sannāsanna saṃjātaścetaso jagato bhramaḥ |
atha dhīsamavāyānāmindrajālamivotthitaḥ
]

`v 7 [
dīrghaḥ svapnaḥ sthitiṃ yātaḥ saṃsārākhyo manobalāt |
samyagdarśanātsthāṇāviva puṃspratyayo mudhā
]

`v 8 [
anātmālokanāccittaṃ cittatvaṃ nānuśocati |
vetālakalpanādbāla iva saṃkalpite bhaye
]

`v 9 [
anākhyasya svarūpasya sarvāśātigatātmanaḥ |
cetyonmukhatayā cittaṃ cittājjīvatvakalpanam
]

`v 10 [
jīvatvādapyahaṃbhāvastvahaṃbhāvācca cittatā |
cittatvādindriyāditvaṃ tato dehādivibhramāḥ
]

`v 11 [
dehādimohataḥ svarganarakau mokṣabandhane |
bījāṅkuravadārambhasaṃrūḍhe dehakarmaṇoḥ
]

`v 12 [
dvaitaṃ yathā nāsti cidātmajīvayo-
stathaiva bhedo'sti na jīvacittayoḥ |
yathaiva bhedo'sti na jīvacittayo-
stathaiva bhedo'sti na dehakarmaṇoḥ
]

`v 13 [
karmaiva deho nanu deha eva
cittaṃ tadevāhamitīha jīvaḥ |
sa jīva eveśvaracitsa ātmā
sarvaḥ śivastvekapadoktametat
]