`v 1 [
aṣṭatriṃśaḥ sargaḥ 38
śrīvasiṣṭha uvāca |
evamatyākule yuddhe sāsphoṭabhayasaṃkule |
āditye tamasā vṛddhe caṭatkaṭhinakaṅkaṭe
]

`v 2 [
vahatyambūtpatantīṣu patantīṣvaśmavṛṣṭiṣu |
nadīṣu kṣepaṇācchāsu varakeṣvabjapaṅktiṣu
]

`v 3 [
mithaḥ phalāgrakāṭotthavahvisīkariṇīṣu ca |
āyāntīṣu prayāntīṣu dūraṃ śaranadīṣu ca
]

`v 4 [
vahallūnaśiraḥpadmacakrāvartaistaraṅgitaiḥ |
khārṇave pūrite hetivṛndamandākinīgaṇaiḥ
]

`v 5 [
samīraṇaraṇatkvāṇaśastrapūrṇaghanairghanaiḥ |
saṃdehānteṣu siddheṣu kapikacchavyathāpradaiḥ
]

`v 6 [
aṣṭabhāgadaśāśeṣapratāpamadhurākṛti |
śastraghātaujasā vīra ivāhastanutāṃ yayau
]

`v 7 [
śrāntāśvebhāḥ prabhagnāśca hetisaṃghātadīptayaḥ |
divasena samaṃ senā yayurmandapratāpatām
]

`v 8 [
athasenādhināthābhyāṃ vicārya sahamantribhiḥ |
dūtāḥ parasparaṃ vṛttā yuddhaṃ saṃhriyatāmiti
]

`v 9 [
tatra śramavaśānmandayantraśastraparākramaiḥ |
raṇasaṃharaṇaṃ kāle sarvairevorarīkṛtam
]

`v 10 [
tato mahārathottuṅgaketuprāntakṛtāspadam |
balayorāruhohaika eko yodho dhruvo yathā
]

`v 11 [
soṃ'śukaṃ bhrāmayāmāsa sarvadiṅmaṇḍale sitam |
śyāmeva dīrghaśuddhāṃśuṃ yuddhaṃ saṃhriyatāmiti
]

`v 12 [
tato dundubhayo neduḥ pratidhvanitadiṅmukhāḥ |
mahāpralayasaṃśāntau puṣkarāvartakā iva
]

`v 13 [
śarādihetisarito vistīrṇe gagane sthite |
pravṛttaḥ sukhamāgantuṃ sarasaḥ sarito yathā
]

`v 14 [
p. 222)
yodhadordrumasaṃcārastanutāmāyayau śanaiḥ |
bhūkampānte vanaspanda ivābhrānta ivārṇavaḥ
]

`v 15 [
vāripūra iti | arthātpralayānte iti gamyate
]

`v 16 [
utkṣiptamandarakṣīrasamudravadanākulam |
sainyaṃ praśāmyadāvartaṃ śanaiḥ sāmyamupāyayau
]

`v 17 [
krameṇāsīnmuhūrtena vikaṭodarabhīṣaṇam |
agastyapītārṇavavacchūnyameva raṇāṅgaṇam
]

`v 18 [
śavasantatisaṃpūrṇaṃ vahadraktanadākulam |
parikūjanajhaṅkārapūrṇajhillivanopamam `note[jhillī iti pāṭhaḥ]
]

`v 19 [
bahadraktasaritsrotastaraṅgāravaghargharam |
sākrandārdhamṛtāhūtasaprāṇavyagramānavam
]

`v 20 [
mṛtārdhamṛtadehaughasṛtāsṛkplutanirjharam |
sajīvanarapṛṣṭhasthaśavaspandanabhrāntidam
]

`v 21 [
karīndraśavarāśyagraviśrāntāmbudakhaṇḍakam |
viśīrṇarathasaṃghātaṃ vātacchinnamahāvanam
]

`v 22 [
vahadraktanadīraṃhaḥprohyamānahayadvipam |
śaraśaktyṛṣṭimusalagadāprāsāsisaṃkulam
]

`v 23 [
paryāṇāvanasaṃnāhakavacāvṛtabhūtalam |
ketucāmarapaṭṭaughaguptaṃ śavaśarīrakam
]

`v 24 [
phaṇāsphuṭakatūṇīrakuñjakūjatsamīraṇam |
śavarāśipalālaughatalpasuptapiśācakam
]

`v 25 [
maulihārāṅgadadyotaśakracāpavanāvṛtam |
śvaśṛgālakarākṛṣṭasāndrāntrādīrgharajjuakam
]

`v 26 [
raktakṣetrakvaṇatkiṃciccheṣajīvanṛdanturam |
raktakardamanirmagnasajīvanaradarduram
]

`v 27 [
varāṅgakavacaprakhyanirgatākṣiśatoccayam |
vahadbhujorukāṣṭhaughaghoraraktasaricchatam
]

`v 28 [
sākrandabandhuvalitaṃ mṛtārdhamṛtamānavam |
śarāyudharathāśvebhaparyāṇāsaṃvarāntaram
]

`v 29 [
nṛtyatkabandhadordaṇḍamaṇḍalānamitāmbaram |
madamedovasāgandhapīḍārdraghrāṇakoṭaram
]

`v 30 [
uttālvardhamṛtebhāśvavāryamāṇālpajīvitam `note[mārthamāṇa iti
pāṭhaḥ] |
vahadraktanadīvīciprahārahatadundubhi
]

`v 31 [
uhyamānamṛtebhāśvamakarāsṛksaricchatam |
mriyamāṇanarānīkaphūtkṛtāsṛkpraṇālikam
]

`v 32 [
svalpajīvaśarāpūrṇamukhadṛkkāntitasvanam |
piṇḍabhāryāvasāgandhavātāntotpīṭhalohitam
]

`v 33 [
unnāsārdhamṛtebhendrakarākrāntakabandhakam |
niradhiṣṭhitahastyaśvapātitoccakabandhakam
]

`v 34 [
rudatkrandatparibhraṣṭaśvakṣubdhāsṛguddhati |
mṛtabhartṛgale śastratyaktaprāṇakulāṅganam
]

`v 35 [
senotkrāntatatak.iprabahupānthaparīkṣaṇam |
śavahārakarākṛṣṭasaprāṇānucarākulam
]

`v 36 [
keśaśaivālavakrābjacakrāvartanadīśatam |
tarattuṅgataraṅgāḍhyavahadraktamahānadam
]

`v 37 [
aṅgalagnāyudhoddhāravyagrārdhamṛtamānavam |
videśamṛtasākrandahutāṅgagajavājinam
]

`v 38 [
p. 223)
prāṇāntasmṛtaputreṣṭamātṛdevaparābhidham |
hāhāhīhītikathitamarmacchedanavedanam
]

`v 39 [
mriyamāṇamathaujiṣṭhadviṣṭaprārabdhasaṃcayam |
dantiyuddhāsamarthāgramṛtadeheṣṭadaivatam
]

`v 40 [
mriyamāṇamahāvajñāśūrāśritapalāyanam |
aśaṅkitāsṛgāvartabhīmāspadagamotsukam
]

`v 41 [
marmacchedaśarāghātavyathāviditaduṣkṛti |
kabandhabandhaprārabdhavetālavadanākramam
]

`v 42 [
uhyamānadhvajacchatracārucāmarapaṅkajam |
kiratsaṃdhyāruṇaṃ dikṣu tejaskaṃ raktapaṅkajam
]

`v 43 [
rathacakradharāvartaṃ raktārṇavamivāṣṭamam |
patākāphenapuñjāḍhyaṃ cārucāmarabudbudam
]

`v 44 [
viparyastarathaṃ bhūmipaṅkamagnapuropamam |
utpātavātanirdhūtadrumaṃ vanamivātatam
]

`v 45 [
kalpadagdhajagatprakhyaṃ munipītārṇavopamam |
ativṛṣṭihataṃ deśamiva projjhitamānavam
]

`v 46 [
kalāpakuntavalitaṃ bhuśuṇḍīmaṇḍalākulam |
mattanāgaśatākāraśavatomaramudgaram
]

`v 47 [
śilāśikharasaṃjātatālajālamivātatam |
taradraktanadītīrajātakuntonnatadrumam
]

`v 48 [
nāgāṃsasyūtahetyoghavṛkṣāṃśukusumākulam |
kaṅkakṛṣṭāntrarasanāvṛndajālakitāmbaram
]

`v 49 [
asṛksarittīrajātakuntonnatavanadrumam |
asṛksarovarordhvasthapatākānalinīgaṇam
]

`v 50 [
raktakardamanirmagnanarāhūtasuhṛjjanam |
karīndrakuṇapāpātaniryadbhagnajanekṣitam `note[tirthagbhagna iti
pāṭhaḥ]
]

`v 51 [
hetilūnalatairvṛkṣaiḥ saṃdigdhārdhakabandhakam |
asṛṅnadīvahaddhastikaṭakarpaṭanaugaṇam
]

`v 52 [
raktasrotaḥsphuracchuklavastraṇḍiṇḍīrapiṇḍakam |
saṃcāraniyatakṣiprabhṛtyavicchinnamānavam
]

`v 53 [
itaścetaśca nipatatkabandharavadānavam `note[navadānavaṃ iti pāṭhaḥ]
|
ūrdhvasthūlākṣacakraughacchinnasainyadravajjanam
]

`v 54 [
raktaniḥsvanabhāṅkāraphetkārārdhamṛtāravam |
śilāmukhalaladraktadhārādhūtarajaḥkhagam
]

`v 55 [
sutālottālavetālatālatāṇḍavasaṃkaṭam |
paryastarathadārvantarardhāntaritasadbhaṭam
]

`v 56 [
antasthasajjīvabhaṭaspandispandanabhītidam |
raktakardamapūrṇāsyakiṃcijjīvakṛpācchavam
]

`v 57 [
kiṃcijjivanarodgrīvaduḥkhadṛṣṭaśvavāyasam |
ekāmiṣotkakravyādayuddhakolāhalākulam |
ekāmiṣārthayuddhehāmṛtakravyādasaṃkulam
]

`v 58 [
vivṛttāsaṃkhyāśvadviradapuruṣādhīśvararatha-
prakṛttoṣṭragrīvāprasṛtarudhirodgārasusarit |
raṇodyānaṃ mṛtyostadabhavadaśuṣkāyudhalataṃ
saśailaṃ kalpānte jagadiva viparyastamakhilam
]