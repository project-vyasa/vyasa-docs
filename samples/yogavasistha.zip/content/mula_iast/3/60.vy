`v 1 [
ṣaṣṭitamaḥ sargaḥ 60
śrīvasiṣṭha uvāca |
etatte kathitaṃ rāma dṛśyadoṣanivṛttaye |
līlopākhyānamanaghaṃ ghanatāṃ jagatastyaja
]

`v 2 [
śāntaiva dṛśyasattasyāḥ śamanaṃ nopayujyate |
sato hi mārjanakleśo nāsatastu kadācana
]

`v 3 [
jñānenākāśarūpeṇa dṛśyaṃ jñeyasvarūpakam |
ityekībhūtamālokya jñastiṣṭhatyambaropamaḥ
]

`v 4 [
pṛthvyādirahitenedaṃ cidbhāsaiva svayaṃbhuvā |
sādhitaṃ yadi siddhena tataḥ svātmani sādhitam
]

`v 5 [
saṃidyathā yā yatate tathā saiva vyavasthitā |
visṛṣṭā sṛṣṭivinnadyāṃ yāvadyatnānna rodhitā
]

`v 6 [
cidākāśāvabhāso'yaṃ jagadityavabudhyate |
cidvyomnyevātmani svacche paramāṇukaṇaṃ prati
]

`v 7 [
evamasyā mudhābhrānteḥ kā sattā keva vāsanā |
kā vāsthā kā ca niyatiḥ kāvaśyaṃbhāvitocyatām
]

`v 8 [
evaṃca sati sattaniyativāsanādibhirapi na dṛśyatrāṇaprasaktirityāśayenāha ##-
sarvaṃ caitadyathādṛṣṭaṃ sthitamitthamakhaṇḍitam |
māyaiveyamananteyaṃ na ca māyāsti kācana
]

`v 9 [
śrīrāma uvāca |
aho nu paramā dṛṣṭirdarśitā bhagavaṃstvayā |
dāvāgnidagdhakakṣāṇāṃ dāhaśāntau kalaindavī
]

`v 10 [
aho nu sucireṇādya jñātaṃ jñātavyamakṣatam |
mayā yathedaṃ yaccedaṃ yādṛg jñeyaṃ yato yadā
]

`v 11 [
śāmyāmīva dvijaśreṣṭha nirvāmīva vikalpayan |
etadākhyānamāścaryaṃ vyākhyānaṃ śāstradṛṣṭiṣu
]

`v 12 [
p. 278) 172
imaṃ me bhagavanbrūhi saṃśayaṃ sarvakovida |
tava pātuṃ na tṛpto'smi śrotrapātrairvacomṛtam
]

`v 13 [
sa sargatritaye kālo līlābharturhi yogataḥ |
sa kvacitkimahorātraḥ kvacitkiṃ māsamātrakaḥ
]

`v 14 [
kvacitkiṃ bahuvarṣāṇi kasyacitkimu pelavaḥ |
kasyacitkiṃ mahādīrghaḥ kasyacitkiṃ kṣaṇaḥ sthitaḥ
]

`v 15 [
ekasminnapi brahmāṇḍe manuṣyāṇāṃ saṃvatsaro devānāṃ dinamiti pelavaḥ |
kasyacitkṣudrajantoḥ sa eva mahādīrghaḥ | kasyacitsvayaṃbhuvaḥ kṣaṇa iti eka eva
kālo deśalokādibhedena viruddharūpaḥ kiṃ sthitaḥ | arthasattaikarūpye
pratītivaiṣamyaṃ kathamityāśayaḥ | iti imaṃ saṃśayaṃ me brūhīti saṃbandhaḥ |
14 |
iti me bhagavanbrūhi tvaṃ yathāvadanugrahāt |
sakṛcchrutaṃ na viśrāntimeti loṣṭe yathā jalam
]

`v 16 [
śrīvasiṣṭha uvāca |
yena yena yathā yadyadyadā saṃvedyate'nagha |
tena tena tathā tattattadā samanubhūyate
]

`v 17 [
amṛtatvaṃ viṣaṃ yāti sadaivāmṛtavedanāt |
śatrurmitratvamāyāti mitrasaṃvittivedanāt
]

`v 18 [
yathā bhāvitameteṣāṃ padārthānāṃ nijaṃ vapuḥ |
tadeva hi cirābhyāsānniyatervaśamāyatam
]

`v 19 [
kacanaikātmikaiṣā cidyathā kacati yādṛśam |
tathā tathāśu bhavati tatsvabhāvaikakāraṇāt
]

`v 20 [
nimeṣe yadi kalpaughasaṃvidaṃ parivindati |
nimeṣa eva tatkalpo bhavatyatra na saṃśayaḥ
]

`v 21 [
kalpe yadi nimeṣatvaṃ vetti kalpo'pyasau tataḥ |
nimeṣībhavati kṣipraṃ tādṛgūrpātmikā hi cit
]

`v 22 [
duḥkhitasya niśā kalpaḥ sukhitasyaiva ca kṣaṇaḥ |
kṣaṇaḥ svapne bhavetkalpaḥ kalpaśca bhavati kṣaṇaḥ
]

`v 23 [
yathā ca mṛtvā jāto'haṃ taruṇo yauvanasthitaḥ |
yāto'smi yojanaśataṃ svapna ityanubhūyate
]

`v 24 [
rātriṃ dvādaśavarṣāṇi hariścandro'nubhūtavān |
lavaṇo bhuktavānāyurekarātryā samāḥ śatam
]

`v 25 [
yanmuhūrtaḥ prajeśasya sa manorjīvitaṃ muneḥ |
jīvitaṃ yadviriñcasya taddinaṃ kila cakriṇaḥ
]

`v 26 [
viṣṇoryajjīvitaṃ rāma radvṛṣāṅkasya vāsaraḥ |
dhyānaprakṣīṇacittasya na dināni na rātrayaḥ
]

`v 27 [
na padārthā na ca jagatsatyamātmani yoginaḥ |
madhuraṃ kaṭutāmeti kaṭubhāvena cintitam
]

`v 28 [
kaṭu cāyāti mādhuryaṃ madhuratvena cintitam |
mitrabuddhyā dviṣanmitraṃ ripubuddhyā ripuḥ suhṛt
]

`v 29 [
bhātīti mahābāho yathāsaṃvedanaṃ jagat |
anabhyastāḥ padārthā ye śāstrapāṭhajapādayaḥ
]

`v 30 [
teṣāṃ saṃvedanābhyāsānnūnamabhyeti sāmyatā |
nauyāyināṃ bhramārtānāṃ vedanādbhūrvivartate
]

`v 31 [
avedanābhramārtānāmapi naiṣāṃ vivartate |
śūnyamākīrṇatāmeti vedanātsvapnadṛkṣviva `note[svapnadṛṣṭivat iti
pāṭhaḥ]
]

`v 32 [
p. 279) 172
vedanātpītamānīlaṃ śuklaṃ vāpyanubhūyate |
āpadvadutsavaḥ khedaṃ karoti parimohataḥ
]

`v 33 [
kuḍye'pi kha ivācāro dṛṣṭo nanvavicāriṇaḥ |
asadyakṣo vimūḍhānāṃ prāṇānapyapakarṣati
]

`v 34 [
vedanātsvapnavanitā jāgratīva ratipradā |
yadyathābhāsamāyātaṃ tattathā sthiratāṃ gatam
]

`v 35 [
asadeva nabhaścaiva nabha eva cidātmani |
śatahastāmbudacchāyānaṭanṛttamivātatam
]

`v 36 [
gagane `note[mūle gamane iti pāṭhaḥ ṭīkāyāṃ ca gagane iti bhūlānanuguṇaḥ
pratīko mudritapustake labhyate] mānasaṃ spandaṃ jagadviddhi na vastu
tat |
mithyājñānapiśācasya spandadarśanamākṛti
]

`v 37 [
māyāmātrakamevedamarodhakamabhittimat |
idaṃ bhāsvaramābhātaṃ svapnasaṃdarśanaṃ sthitam
]

`v 38 [
apūrvamevāsuptasya narasyevoditaṃ viduḥ |
acetā cetati stambho yādṛśaṃ śālabhañjikām
]

`v 39 [
paramārthamahāstambhaḥ sṛṣṭiṃ cetati tādṛśam |
yādṛśo me naraḥ pārśve svapne kṣubdho mahābhaṭaiḥ
]

`v 40 [
tādṛśo brahmaṇaḥ svargo buddha eva suṣuptavat |
tṛṇagulmalatāyuktaḥ śiśirānte yathā rasaḥ
]

`v 41 [
vāsantaḥ saṃsthito bhūmau tathā sargaḥ pare pade |
yathā dravatvaṃ kanake sthitamantaranunmiṣat
]

`v 42 [
tathā sthitaḥ pare sarga ātmavargādaṇāvaṇau |
saṃniveśo yathāṅgānāmaṅgino'nanya ātmanaḥ
]

`v 43 [
jagadevamanaṅgasya svātmano brahmaṇastathā |
yādṛgekanaraḥ svapne yuddhamanyaṃ naraṃ prati
]

`v 44 [
tādṛśaṃ sadasadrūpaṃ svātmedaṃ vyomagaṃ jagat |
mahākalpāntasargādau citsvabhāvamidaṃ jagat `note[vapuḥ iti pāṭhaḥ] |
44 |
ādyantakālayoḥ sadbrahmamātrābhāvena pariśeṣādapi tanmātrasvabhāvatetyāha
- mahākalpānteti
]

`v 45 [
kāraṇatvaṃ mithaḥ paścādasadeti na vāstavam |
mukte'sminbrahmaṇi yadi brahmānyaḥ smṛtijo bhavet |
tatsmṛtijñaptije sarge sthitaiva jñaptimātratā
]

`v 46 [
śrīrāma uvāca |
paurāṇāṃ mantrimukhyānāṃ vidūrathakulakramaḥ |
samameva kathaṃ tatra sarveṣāṃ pratibhāsitaḥ
]

`v 47 [
śrīvasiṣṭha uvāca |
citaḥ samanuvartante mukhyāyāḥ sarvasaṃvidaḥ |
yathā vipulavātyāyāḥ sāmānyā vātalekhikāḥ
]

`v 48 [
p. 280) 173
parasparānusāreṇa tathārūpeṇa saṃvidaḥ |
kacitāstāḥ prajāpālaprajāvāstavyamantriṇaḥ
]

`v 49 [
evaṃrūpātkulājjāto rājāsmākamayaṃ tvasau |
kacitā ieva vāstavyavido vaidūrathe pure
]

`v 50 [
kacane citsvabhāvasya na ca kāraṇamārgaṇam |
yuktaṃ mahāmaṇerbhāsāmivānyatra svabhāvataḥ
]

`v 51 [
nanūdāsīnāyāḥ saṃvido'dhyastaviṣayaprathālakṣaṇe kacane ko heturiticennātra
hetucintā yuktā kacanasyāgantukatvādato'nyatra āgantukaviṣayeṣveva sā yuktā |
yathā udāsīnasya cintāmaṇerbhāsāṃ prasare na hetvantarāpekṣā kiṃtu
vicitrārthajanane cintakajanamanorathavaicitryāpekṣā tadvadityāha - kacane iti |
50 |
ahamevaṃ kulācāre rājā syāmevamityapi |
vidūrathavido ratnāduditā pratibhā yathā
]

`v 52 [
yāvanto jantavo yasminye ye sarge yadā yadā |
te sarvagatvācciddhātoranyonyādarśatāṃ `note[sargagatvāt iti pāṭhaḥ]
gatāḥ
]

`v 53 [
tīvravegavatī yā syāttatra saṃvidakampitā |
saivāyāti paraṃ sthairyamāmokṣaṃ tvekarūpiṇī
]

`v 54 [
balavaccidvilāsānāmanuvṛttyā parasparam |
svabhāvāḥ pratibimbanti cidādarśe svabhāvataḥ
]

`v 55 [
tatrātiyatnājjayati satyāḥ saṃvidaḥ ātmasāt |
kurvanti saridambhodhigāminī sarito yathā
]

`v 56 [
ye samāstatra te tāvadyatante citsvabhāvataḥ |
yāvadeko jayatyatra dvitīyaḥ sa nimajjati
]

`v 57 [
jāyamāneṣu naśyatsu vartamāneṣu bhūriśaḥ |
evaṃ sargasahasreṣu paramāṇukaṇaṃ prati
]

`v 58 [
na kiṃcitkenaciddhyāptaṃ `note[kenacidvyāptaṃ iti kvācitkaḥ pāṭhaḥ] na
kiṃcitkenacitsthitam |
cidākāśamidaṃ śāntamataḥ sarvamabhittimat
]

`v 59 [
ayamābhāsate svapno nirnidro dṛṣṭivarjitaḥ |
avaśyaṃbhāvibodhastu svanubhūto'pyasanmayaḥ
]

`v 60 [
patrapuṣpaphalāṃśātmā yathaikaḥ svāsthito drumaḥ |
anantasarvaśaktyātmā hyeka eva tathā vibhuḥ
]

`v 61 [
mātṛmeyapramāṇādimāyātmakamajaṃ padam |
buddhaṃ vismṛtimāyāti na kadācana kasyacit
]

`v 62 [
śūnyodayāstamayavastu tamaḥprakāśaṃ
dikkālarūpyapi sadaikamanādiśuddham |
ādyantamadhyarahitaṃ sthitamacchamambu
saumyatvavīcivalanāḍhyamivaikameva
]

`v 63 [
p. 281) 173
ahaṃtvamityādijagatsvarūpā
viśuddhabodhaikavibhā vibhāti
ākāśakośe nijaśūnyateva
dvaitaikyasaṃkalpavikalpanācca
]