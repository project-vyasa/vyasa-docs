`v 1 [
ekādhikaśatatamaḥ sargaḥ 101
śrīrāma uvāca |
kimucyate muniśreṣṭha bālakākhyāyikākramaḥ |
krameṇa kathayaitanme manovarṇanakāraṇam
]

`v 2 [
śrīvasiṣṭha uvāca |
ko'pi mugdhamatirbālo dhātrīṃ pṛcchati rāghava |
kāṃcidvinodinīṃ dhātri varṇayākhyāyikāmiti
]

`v 3 [
sā bālasya vinodāya dhātrī tasya mahāmate |
ākhyāyikāṃ kathayati prasannamadhurākṣasam
]

`v 4 [
kvacitsanti mahātmāno rājaputrāstrayaḥ śubhāḥ |
dhārmikāḥ śauryamuditā atyantāsati pattane
]

`v 5 [
vistīrṇe śūnyanagare vyomnīva jalatārakāḥ |
dvau na jātau tathaikastu garbha eva na saṃsthitaḥ
]

`v 6 [
p. 368) 219
athātyuttamalābhārthaṃ kadācitsamavāyataḥ |
vibandhavaḥ khinnamukhāḥ śokopahatacetasaḥ
]

`v 7 [
te tasmācchūnyanagarānnirgatā vitatānanāḥ |
gaganādiva saṃśliṣṭā budhaśukraśanaiścarāḥ
]

`v 8 [
śirīṣasukumārāṅgāḥ pṛṣṭhato'rkeṇa tāpitāḥ |
mārge'hani gatā grīṣmatāpārtāḥ pallavā iva
]

`v 9 [
saṃtaptamārgasikatādagdhapādasaroruhāḥ |
hā tāta ceti śocanto mṛgā yūthacyutā iva
]

`v 10 [
darbhāgrabhinnacaraṇāstāpakhinnāṅgasaṃdhayaḥ |
ullaṅghya dūramadhvānaṃ dhūlidhūsaramūrtayaḥ
]

`v 11 [
mañjarījālajaṭilaṃ phalapallavamālitam |
mṛgapakṣigaṇādhāraṃ prāpurmārge tarutrayam
]

`v 12 [
yasminvṛkṣatraye vṛkṣau dvau na jātau manāgapi |
bījameva tṛtīyasya svārohasya na vidyate
]

`v 13 [
viśrāntāste pariśrāntāstatraikasya taroradhaḥ |
pārijātatale svarge śakrānilayamā iva
]

`v 14 [
phalānyamṛtakalpāni bhuktvā pītvā ca tadrasam |
kṛtvā gulucchakairmālāṃ ciraṃ viśramya te yayuḥ
]

`v 15 [
punardūrataraṃ gatvā madhyāhne samupasthite |
sarittritayamāsedustaraṅgataralāravam
]

`v 16 [
tatraikā pariśuṣkaiva manāgapyambu na dvayoḥ |
vidyate saritordṛṣṭirandhalocanayoriva
]

`v 17 [
pariśuṣkā bhṛśaṃ yāsau tasyāṃ te sasnurādṛtāḥ |
gharmārtā iva gaṅgāyāṃ brahmaviṣṇuharā iva
]

`v 18 [
gharmārtā janā iva brahmaviṣṇuharā gaṅgāyāmiva ceti pṛthakkṛtya yojyam |
17 |
ciraṃ kṛtvā jalakrīḍāṃ pītvā kṣīropamaṃ payaḥ |
jagmuste rājatanayāḥ prahṛṣṭamanasaḥ svayam
]

`v 19 [
athāsedurdinasyānte lambamāne divākare |
bhaviṣyannavanirmāṇaṃ nagaraṃ nagasannibham
]

`v 20 [
patākāpadminīvyāptaṃ nīlākāśajalāśayam |
dūraśrutasamullāpagāyannāgaramaṇḍalam
]

`v 21 [
dadṛśustatra ramyāṇi trīṇi sadbhavanāni te |
maṇikāñcanagehāni śṛṅgāṇīva mahāgireḥ
]

`v 22 [
anirmite dve sadane ekaṃ nirbhitti tatra vai |
abhittimandiraṃ cāru praviṣṭāste narāstrayaḥ
]

`v 23 [
saṃpraviśyopaviśyāśu viharanto varānanāḥ |
prāpuḥ sthālītrayaṃ tatra taptakāñcanakalpitam
]

`v 24 [
tatra karparatāṃ yāte dve ekā cūrṇatāṃ gatā |
jagṛhuścūrṇarūpāṃ tāṃ sthālīṃ te dīrghabuddhayaḥ
]

`v 25 [
droṇairnavanavatyā taistasyāṃ droṇena cāndhasaḥ |
tatra droṇaśataṃ hīnaṃ randhitaṃ bahubhojibhiḥ
]

`v 26 [
nimantritāstrayastaistu brāhmaṇā rājasūnubhiḥ |
dvau nirdehāvathaikasya mukhameva na vidyate
]

`v 27 [
nirmukhenāndhasastatra bhuktaṃ droṇaśataṃ suta |
viprabhuktāvaśeṣaṃ tu bhuktamandho nṛpātmajaiḥ
]

`v 28 [
tribhiste rājaputrāśca parāṃ nirvṛtimāgatāḥ |
bhaviṣyannagare tasmin rājaputrāstrayo hi te |
sukhamadya sthitāḥ putra mṛgayāvyavahāriṇaḥ
]

`v 29 [
ākhyāyikaiṣā kathitā mayā ramyā tavānagha |
etāṃ hṛdi kuru prājña vidagdhastvaṃ bhaviṣyasi
]

`v 30 [
dhātryeti kathitā rāma bālakākhyāyikā śubhā |
tuṣṭiṃ jagāma bālaśca śubhākhyāyikayānayā
]

`v 31 [
eṣā hi kathitā rāma cittākhyānakathāṃ prati |
bālakākhyāyikā tubhyaṃ mayā kamalalocana
]

`v 32 [
iyaṃ saṃsāraracanā sthitimevamupāgatā |
bālakākhyāyikevograiḥ saṃkalpairdṛḍhakalpitaiḥ
]

`v 33 [
vikalpajālakaiveyaṃ pratibhāsātmikānagha |
bandhamokṣādikalanārūpeṇa parijṛmbhate
]

`v 34 [
p. 369) 219
saṃkalpamātrāditaradvidyate neha kiṃcana |
saṃkalpavaśataḥ kiṃcinna kiṃcitkiṃcideva vā
]

`v 35 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
saṃkalpakacitaṃ sarvamevaṃ svapnavadātmanaḥ
]

`v 36 [
rājaputrāstrayo nadyo bhaviṣyannagare yathā |
yathā saṃkalparacanā tatheyaṃ hi jagatsthitiḥ
]

`v 37 [
saṃkalpamātramabhitaḥ parisphurati cañcalaḥ |
payomātrātmako'bhodhirambhasīvātmanātmani
]

`v 38 [
saṃkalpamātraṃ prathamamutthitaṃ paramātmanaḥ |
tadidaṃ sphāratāṃ yātaṃ vyāpārairdivasaṃ yathā
]

`v 39 [
saṃkalpajālakalanaiva jagatsamagraṃ
saṃkalpameva nanu viddhi vilāsacetyam |
saṃkalpamātramalamutsṛja nirvikalpa-
māśritya niścayamavāpnuhi rāma śāntim
]