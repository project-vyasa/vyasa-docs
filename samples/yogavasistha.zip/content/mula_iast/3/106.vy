`v 1 [
ṣaḍuttaraśatatamaḥ sargaḥ 106
rājovāca |
asti tāvadayaṃ deśo nānāvananadīyutaḥ |
vasudhāmaṇḍalasyāsya sahodara ivānujaḥ
]

`v 2 [
asmiṃścāyamahaṃ rājā paurābhimatavṛttimān |
indraḥ svarga ivāsyāṃ tu sabhāyāṃ madhyasaṃsthitaḥ
]

`v 3 [
yāvadabhyāgato dūrātkaścicchāmbarikastvayam |
rasātalādabhyudito māyī maya iva svayam
]

`v 4 [
anena bhramitādyeha picchikā tejasorjitā |
kalpāntapavanābhreṇa śakracāpalatā yathā
]

`v 5 [
ālokyaitāmahaṃ lolāmasyāśvasya puraḥ sthitaḥ |
pṛṣṭhamārūḍhavāneka ātmanā bhrāntamānasaḥ
]

`v 6 [
tato'rdriṃ pralayakṣubdhaṃ puṣkarāvartako yathā |
tathā calantaṃ calitaḥ svaśvamārūḍhavānaham
]

`v 7 [
gantuṃ pravṛtto mṛgayāmeko'hamatiraṃhasā |
urvarāmiva nirbhartuḥ kallolaḥ pralayāmbudheḥ
]

`v 8 [
tenānilavilolena dūraṃ nīto'smi vājinā |
yogābhyāsajaḍenājño mugdhasya manasā yathā
]

`v 9 [
akiṃcanamanaḥśūnyaṃ strīcittamiva nirbharam |
tataḥ pralayanirdagdhajagadāspadabhīṣaṇam
]

`v 10 [
niṣpakṣikṣāranīhāraṃ nirvṛkṣamajalaṃ mahat |
saṃprāpto'hamaparyantamaraṇyaṃ śrāntavāhanaḥ
]

`v 11 [
taddvitīyamivākāśaṃ tathāṣṭamamivāmbudhim |
pañcamaṃ sāgaramiva saṃśuṣkaṃ śūnyakoṭaram
]

`v 12 [
svādūdakārṇavātparato'ṣṭamamambudhiṃ prāgvarṇitabhūparikhāgartamiva |
jambūdvīpāntaścaturdiśaṃ catuḥsāgaraprasiddhestatra pañcamaṃ sāgaramiva |
11 |
jñasyeva vitataṃ ceto mūrkhasyeva ruṣā'javam |
adṛṣṭajanasaṃsargamajātatṛṇapallavam
]

`v 13 [
araṇyamidamāsādya matirme khedamāgatā |
lalanevaitya dāridryaṃ nirannaphalabāndhavam
]

`v 14 [
kacanmarumarīcyambupuraḥplutakakummukham |
āsūryāstaṃ dinaṃ tatra prakrāntaṃ sīdatā mayā
]

`v 15 [
tadaraṇyaṃ mayātītamatikṛcchreṇa khedinā |
vivekineva saṃsāro madhyaśūnyatatākṛti
]

`v 16 [
yadetenātivāhyāhaṃ prāptavāñjaṅgalaṃ kramāt |
astādrisānuṃ khinnāśvaḥ śūnyabhrāntyeva bhāskaraḥ
]

`v 17 [
jambūkadambaprāyeṣu kalālāpāḥ patatriṇaḥ |
yatra sphuranti khaṇḍeṣu pānthānāmiva bāndhavāḥ
]

`v 18 [
yatra śaṣpaśikhāśreṇyo dṛśyante viralāḥ sthale |
kadarthalakṣmyā jihmasya hṛdīvānandavṛttayaḥ
]

`v 19 [
pūrvādaraṇyādarasāttaddhi kiṃcitsukhāvaham |
atyantaduḥkhānmaraṇādvaraṃ vyādhirhi jantuṣu
]

`v 20 [
p. 377) 223
tatra jambīrakhaṇḍasya talaṃ saṃprāptavānaham |
mārkaṇḍeya ivāgendramekārṇavavihārataḥ
]

`v 21 [
ālambitā mayā tatra skandhasaṃsargiṇī latā |
nīlā jaladamāleva tāpataptena bhūbhṛtā
]

`v 22 [
mayi pralambamāne'syāṃ prayātaḥ sa turaṅgamaḥ |
gaṅgāvalambini nare yathā duṣkṛtasaṃcayaḥ
]

`v 23 [
ciraṃ dīrghādhvagaḥ khinnastatra viśrāntavānaham |
bhānurastācalaotsaṅge tale kalpataroriva
]

`v 24 [
yāvatsamastasaṃsāravyavahārabharaiḥ samam |
ravirviśramaṇāyeva niviṣṭo'stācalāṅgaṇe
]

`v 25 [
yāvatsamastasaṃsāravyavahāraiḥ saha ravirastācalopalakṣite udayādryante
gaganāṅgaṇe niviṣṭastāvadahaṃ tasmiṃstarugaṇe nilīna iti vyavahitenānvayaḥ |
24 |
śanaiḥ śyāmikayā graste samaste bhuvanodare |
rātrisaṃvyavahāreṣu saṃpravṛtteṣu jaṅgale
]

`v 26 [
ahaṃ tarutṛṇe tasminpelave khaṇḍakoṭare |
nilīnaściralīnāsyaḥ svanīḍe vihago yathā
]

`v 27 [
viṣadaṣṭavivekasya kīnāśasya galatsmṛteḥ |
vikrītasyeva dīnasya magnasyevāndhakūpake
]

`v 28 [
tatra kalpasamā rātrirmohamagnasya me gatā |
ekārṇavohyamānasya mārkaṇḍeyamaneriva
]

`v 29 [
na snātavānnārcitavānna tadā bhuktavānaham |
kevalaṃ me gatā rātriḥ sāpadāṃ dhuri tiṣṭhataḥ
]

`v 30 [
vinidrasya vidhairyasya sphurataḥ saha pallavaiḥ |
samaṃ duṣṭātidairghyeṇa sā vyatīyāya śarvarī
]

`v 31 [
tatastimiralekhāsu saha tārendukairavaiḥ |
mayīvāpādyamānāsu mlānatāmalamānane
]

`v 32 [
śāmyantīṣu ca vetālakṣveḍāsu javajaṅgale |
sahaśītārtimaddantapaṅktiṭāṅkārasītkṛtaiḥ
]

`v 33 [
kṣveḍāsu siṃhanādeṣu | javajaṅgale dīrghāraṇye | jaṅgale'saheti praśleṣaḥ |
asahā duḥsahā yā śītārtistadvatāṃ prāṇināṃ
dantapaṅktighaṭṭanaṭāṅkārasītkārairmāmeva hasantīmiveti deśo viśeṣaṇam |
32 |
māmevārtivinirmagnaṃ hasantīmiva dṛṣṭavān |
ahaṃ pūrvāṃ diśaṃ prāptamadhupānāruṇāmiva
]

`v 34 [
kṣaṇādajña iva jñānaṃ daridra iva kāñcanam |
dṛṣṭavānahamarkaṃ khe vāraṇārohaṇonmukham
]

`v 35 [
utthāyāstaraṇaṃ vastraṃ tattadāsphoṭitaṃ mayā |
hasticarmahareṇeva saṃdhyānṛtyānurāgiṇā
]

`v 36 [
pravṛttastāmahaṃ sphārāṃ vihartuṃ jaṅgalasthalīm |
kālo jagatkuṭīṃ kalpadagdhabhūtagaṇāmiva
]

`v 37 [
na kiṃciddṛśyate tatra bhūtaṃ jaraṭhajaṅgale |
abhijāto guṇalavo yathā mūrkhaśarīrake
]

`v 38 [
kevalaṃ vigatāśaṅkaṃ khaṇḍabhramaṇacañcalam |
cīcīkūcītivacanā viharanti vigaṅgamāḥ
]

`v 39 [
athāṣṭabhāgamāpanne vyomno divasanāyake |
śuṣkāvaśyāyaleśāsu snātāsviva latāsu ca
]

`v 40 [
dṛṣṭā mayā prabhramatā dārikaudanadhāriṇī |
gṛhītāmṛtasatkumbhā dānaveneva mādhavī
]

`v 41 [
tarattārakanetrāṃ tāṃ śyāmāmadhavalāmbarām |
ahamabhyāgatastatra śarvarīmiva candramāḥ
]

`v 42 [
mahyamodanamāśvetadvāle balavadāpadi |
dehidīnārtiharaṇātsphāratāṃ yānti saṃpadaḥ
]

`v 43 [
balavatyāṃ prāṇātyayaparyantāyām | tathāca smṛtiḥ - jīvitātyayamāpanno
yo'nnamatti yatastataḥ | lipyate na sa pāpena padmapatramivāmbhasā | iti |
sarvānnānumatiḥ prāṇātyaye taddarśanāt iti bādarāyaṇasūtraṃ ceti bhāvaḥ | 42
|
kṣudantarmahatīyaṃ me bāle vṛddhimupeyuṣī |
kṛṣṇasarpā prasūteva koṭarasthā jaraddrume
]

`v 44 [
yācñayāpi tayā mahyamitthaṃ dattaṃ na kiṃcana |
yatnaprārthanayā lakṣmyā yathā duṣkṛtine dhanam
]

`v 45 [
kevalaṃ cirakālena mayātyantānugāminā |
khaṇḍātkhaṇḍaṃ nipatati cchāyābhūte puraḥsthite
]

`v 46 [
p. 378) 225
tayoktaṃ hārakeyūriṃścaṇḍālīṃ viddhi māmiti |
rākṣasīmiva sukrūrāṃ puruṣāśvagajāśanām
]

`v 47 [
rājanyārcanamātreṇa matto nāpnoṣi bhojanam |
grāmyādanabhijātehātsaujanyamiva sundaram
]

`v 48 [
ityuktavatyā gacchantyā khelayā ca pade pade |
kuñjakeṣu nimajjantyā līlāvanatayoditam
]

`v 49 [
dadāmi bhojanamidaṃ bhartā bhavasi cenmama |
loko nopakarotyarthaiḥ sāmānyaḥ snigdhatāṃ vinā
]

`v 50 [
vāhayatyatra me dāntānkedāre pulkasaḥ pitā |
śmaśāna iva vetālaḥ kṣudhito dhūlidhūsaraḥ
]

`v 51 [
tasyedamannaṃ bhavati bhartṛtve dīyate sthite |
prāṇairapi hi saṃpūjyā vallabhāḥ puruṣā yataḥ
]

`v 52 [
athoktā sā mayā bhartā bhavāmi tava suvrate |
kenāpadi vicāryante varṇadharmakulakramāḥ
]

`v 53 [
tatastayaudanādardhaṃ mahyamekaṃ samarpitam |
māghavyevāmṛtādardhamindrāyārtimahatpurā
]

`v 54 [
jambūphalarasaḥ pītaḥ sa bhuktaḥ pakvaṇaudanaḥ |
viśrāntaṃ ca mayā tatra mohāpahatacetasā
]

`v 55 [
māṃ tatrārkamivāpūrya sā prāvṛṭ śyāmalā gatā |
hastena samupādāya prāṇaṃ bahiriva sthitam
]

`v 56 [
durākṛtiṃ durārambhamāsasāda bhayapradam |
pitaraṃ pīvarākāramavīcimiva yātanā
]

`v 57 [
tayā madanuṣaṅgiṇyā svārthastasmai niveditaḥ |
mātaṅgāya bhramaryeva niḥsvanenālilagnayā
]

`v 58 [
ayaṃ mama bhavedbhartā tāta he tava rocatām |
sa tasyā bāḍhamityuktvā dinānte samupasthite
]

`v 59 [
mumoca dāntāvābaddhau kṛtāntaḥ kiṅkarāviva |
nīhārābhrakaḍārāsu dikṣu proddhūlitāsu ca |
vetālabandhanāttasmāddinānte calitā vayam
]

`v 60 [
kṣaṇena pakkaṇaṃ prāptāḥ saṃdhyāyāṃ dīrghajaṅgalāt |
śmaśānādiva vetālāḥ śmaśānamitaranmahat
]

`v 61 [
vikartitavibhāgasthakapikukkuṭavāyasam |
raktasiktorvarābhāgaprabhramanmakṣikāgaṇam
]

`v 62 [
śoṣārthaṃ prasṛtārdrāntratantrījālapatatkhagam |
niṣkuṭasthitajambīrakhaṇḍalagnakhagadhvani
]

`v 63 [
śuṣyadguruvasāpiṇḍapūrṇālindalasatkhagam |
dṛṣṭiprasṛtaraktāktacarmasravadasṛgalavam
]

`v 64 [
bālahastasthitakravyapiṇḍakkaṇitamakṣikam |
jarjarādhiṣṭhacaṇḍālatarjitāraṭitārbhakam
]

`v 65 [
tatpraviṣṭā vayaṃ kīrṇaśirāntraṃ bhīmapakkaṇam |
mṛtabhūtaṃ jagatkalpe kṛtāntānucarā iva
]

`v 66 [
saṃbhramopahitānalpakadalīdalapīṭhake |
ahamāsthitavāṃstatra nave śvaśuramandire
]

`v 67 [
śvaśvā me kekarākṣyā tu tenāsṛglavacakṣuṣā |
jāmātāyamiti proktaṃ tayā tadabhinanditam `note[sadabhinanditam iti
pāṭhaḥ]
]

`v 68 [
atha viśramya caṇḍālabhojanānyajināsane |
saṃcitānyupabhuktāni duṣkṛtānīva bhūriśaḥ
]

`v 69 [
anantaduḥkhabījāni na manojñatarāṇyapi |
tāni praṇayavākyāni śrutānyasubhagānyalam
]

`v 70 [
nirabhrāmbaranakṣatre kasmiṃściddivase tataḥ |
taistairāmbhasaṃrambhaistairvastravibhavārpaṇaiḥ
]

`v 71 [
dattāpyanena sā mahyaṃ kumārī bhayadāyinī |
sukṛṣṇā kṛṣṇavarṇena duṣkṛteneva yātanā
]

`v 72 [
sarabhasamabhito vineduratra
prasṛtamahāmadirāsavāḥ śvapākāḥ |
hatapaṭupaṭahā vilāsavantaḥ
svayamiva duṣkṛtarāśayo mahāntaḥ
]