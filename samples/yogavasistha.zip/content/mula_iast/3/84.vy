`v 1 [
caturaśītitamaḥ sargaḥ 84
śrīvasiṣṭha uvāca |
etatte kathitaṃ sarvaṃ mayākhyānamaninditam |
karkaṭyā himarākṣasyā yathāvadanupūrvaśaḥ
]

`v 2 [
śrīrāma uvāca |
himavadgahvare protthā sā kathaṃ kṛṣṇarākṣasī |
babhūva karkaṭīnāmnā yathāvadvada me prabho
]

`v 3 [
śrīvasiṣṭha uvāca |
kulāni santyanekāni rākṣasānāṃ svabhāvataḥ |
tāni śuklāni kṛṣṇāni haritānyujjvalāni ca
]

`v 4 [
karkaṭaprāṇisādṛśyātkarkaṭo nāma rākṣasaḥ |
babhūva tajjā sā kṛṣṇā karkaṭī karkaṭākṛtiḥ
]

`v 5 [
karkaṭīpraśnasaṃsmṛtyā mayaiṣā kathitā tava |
adhyātmoktiprasaṅgena viśvarūpanirūpaṇe
]

`v 6 [
saṃpannameva me kasmādasaṃpannamiva sphuṭam |
idaṃ jagadanādyantātpadātparamakāraṇāt
]

`v 7 [
plāvinyo vīcayo vāriṇyanyānanyāḥ sthitā yathā |
vartamānā api pare sṛṣṭayaḥ saṃsthitāstathā
]

`v 8 [
ajvalanneva kāṣṭheṣu vahnirarthakriyāṃ yathā |
karoti markaṭādīnāṃ śītāpaharaṇādikam
]

`v 9 [
samaṃ saumyatvamajahadeva nityodayasthiti |
tathā brahma karotīdaṃ nānā karteva sajjagat
]

`v 10 [
apyanāgata evāyamevaṃ sarga upāgataḥ |
bhoḥ śālabhañjikāsaṃviddāruṇyeva mudhoditā
]

`v 11 [
bīje yathā'nanyadapi phalādyanyadivoditam |
citau tathā'nanyadapi cetyamanyadivoditam
]

`v 12 [
acchedādekasattāyā na bhedaḥ phalabījayoḥ |
ciccetyayośca vāryūrmyoriva vastuni kaścana
]

`v 13 [
avicārātkuto bhedo naitayorupapadyate |
yataḥkutaściduditaḥ sa vicāreṇa naśyati
]

`v 14 [
bhrāntireṣā yathā'yātā tathā yātu raghūdvaha |
jñāsyase tatprabuddhastvamenāṃ kevalamutsṛja
]

`v 15 [
p. 334) 202
bhrāntigranthau vitruṭite maduktiśravaṇāttataḥ |
jñānaśabdārthabhedānāṃ vastu jñāsyasyalaṃ svayam
]

`v 16 [
cittādiyamanarthaśrīstacca sā cetarā ca te |
maduktiśravaṇādeva śāntimeṣyatyasaṃśayam
]

`v 17 [
brahmaṇaḥ sarvamutpannaṃ sarvaṃ brahmaivameti ca |
madgīrbhiḥ saṃprabuddhaḥ san jñāsyasyalamaninditam
]

`v 18 [
śrīrāma uvāca |
tasmādiyamiti brahmanvyatirekārthapañcamī |
nanu kiṃ viddhi deveśādabhinnaṃ sarvamityapi
]

`v 19 [
śrīvasiṣṭha uvāca |
upadeśāya śāstreṣu jātaḥ śabdo'thavārthajaḥ |
pratiyogivyavacchedasaṃkhyālakṣaṇapakṣavān
]

`v 20 [
bhedo dṛśyata evāyaṃ vyavahārānna vāstavaḥ |
vetālo bālakasyeva kāryārthaṃ parikalpitaḥ
]

`v 21 [
dvaitaikyamapi no yasyāṃ tathā bhūtārthasaṃsthitau |
asti tasyāmīdṛśaḥ syātkutaḥ saṃkalpaviplavaḥ
]

`v 22 [
kāryakāraṇabhāvo hi tathā svasvāmilakṣaṇam |
hetuśca hetumāṃścaivāvayavāvayavikramaḥ
]

`v 23 [
vyatirekāvyatirekau pariṇāmādivibhramaḥ |
tathā bhāvavilāsādi vidyāvidye sukhāsukhe
]

`v 24 [
evamādimayī mithyāsaṃkalpakalanā mitā |
ajñānāmavabodhārthaṃ natu bhedo'sti vastuni
]

`v 25 [
avibodhādayaṃ vādo jñāte dvaitaṃ na vidyate |
jñāte saṃśāntakalanaṃ maunamevāvaśiṣyate
]

`v 26 [
sarvamekamanādyantamavibhāgamakhaṇḍitam |
iti jñāsyasi siddhāntaṃ kāle bodhamupāgataḥ
]

`v 27 [
vivadante hyasaṃbuddhāḥ svavikalpavijṛmbhitaiḥ |
upadeśādayaṃ vādo jñāte dvaitaṃ na vidyate
]

`v 28 [
asaṃbuddhā ajñātatattvāḥ puruṣāḥ svavikalpavijṛmbhitaistairkaiḥ | ayaṃ vādaḥ
sarvo'pi vedāntatatvvopadeśātprāgeva yato jñāte dvaitaṃ na vidyate ityarthaḥ | 27
|
vācyavācakasaṃbodho vinā dvaitaṃ na siddhyati |
naca dvaitaṃ saṃbhavati maunaṃ vāpādayatyalam
]

`v 29 [
mahāvākyārthaniṣṭhāntāṃ buddhiṃ kṛtvā raghūdvaha |
vacobhedamanādṛtya yadidaṃ vacmi te śṛṇu
]

`v 30 [
yataḥkutaściducchrāyaṃ gandharvapuravanmanaḥ |
bhrāntimātraṃ tanotīdaṃ jagadākhyaṃ svajṛmbhaṇam
]

`v 31 [
yathā cetastanotīmāṃ jaganmāyāṃ tathānagha |
śṛṇu tvaṃ kathayāmīdaṃ dṛṣṭāntaṃ dṛṣṭivedanam
]

`v 32 [
yaṃ śrutvā sarvamevedaṃ bhrāntimātramiti svayam |
rāma niścayavānbhūtvā dūre tyakṣyasi vāsanām
]

`v 33 [
manomanananirmāṇamātrameva jagattrayam |
sarvamutsṛjya śāntātmā svātmanyeva nivatsyasi
]

`v 34 [
madvākyārthāvadhānastho manovyādhicikitsane |
vivekauṣadhaleśena prayatnaṃ ca kariṣyasi
]

`v 35 [
evaṃ sthite jagadrūpaṃ cittameveha jṛmbhate |
na vidyate śarīrādi sikatāntaratailavat
]

`v 36 [
cittameva hi saṃsāro rāgādikleśadūṣitam |
tadaiva tairvinirmuktaṃ bhavānta iti kathyate
]

`v 37 [
p. 335) 202
cittaṃ sādhyaṃ pālanīyaṃ vicāryaṃ kāryamāryavat |
āhāryaṃ vyavahāryaṃ ca saṃcāryaṃ dhāryamādarāt
]

`v 38 [
sarvamabhyantare cittaṃ bibharti trijagannabhaḥ |
ahamāpūramiva tadyathākālaṃ vijṛmbhate
]

`v 39 [
yo'yaṃ cittasya cidbhāgaḥ saiṣā sarvārthabījatā |
yaścāsya jaḍabhāgaśca tajjagatso'ṅga saṃbhramaḥ
]

`v 40 [
avidyamānamevedamādisarge dharādikam |
nirākṛtirajaḥ svapnaṃ paśyatīva na paśyati
]

`v 41 [
sargādidīrghasaṃvittyā śailādijaḍasaṃvidā |
sūkṣmaṃ sūkṣmavidā ceti dehaṃ śūnyaṃ na vāstavam
]

`v 42 [
sarvagenātmanā vyāptaṃ svacetyātmavapurmanaḥ |
ātataṃ saumya vimalaṃ vārīva ravitejasā
]

`v 43 [
cittabālo jagadyakṣaṃ mithyā paśyatyabodhataḥ |
bodhito'sau paraṃ rūpaṃ svaṃ paśyati nirāmayam
]

`v 44 [
yathātmā dṛśyatāmeti dvitvaikyabhramadāyinīm |
śṛṇu tatte pravakṣyāmi vakṣyāmāṇakathāgamaiḥ
]

`v 45 [
yatkathyate hi hṛdayaṃgamayopamāna-
yuktyā girā madhurayuktapadārthayā ca |
śrotustadaṅga hṛdayaṃ parito visāri
vyāpnoti tailamiva vāriṇī vārya śaṅkām
]

`v 46 [
tyaktopamānamamanojñapadaṃ durāpaṃ
kṣubdhaṃ dharāvidhuritaṃ vinigīrṇavarṇam |
śroturna yāti hṛdayaṃ pravināśameti
vākyaṃ kilājyamiva bhasmani hūyamānam
]

`v 47 [
ākhyānakāni bhuvi yāni kathāśca yā yā
yadyatprameyamucitaṃ paripelavaṃ vā |
dṛṣṭāntadṛṣṭikathanena tadeti sādho
prākāśyamāśu bhuvanaṃ sitaraśmineva
]