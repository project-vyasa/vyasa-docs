`v 1 [
saptatitamaḥ sargaḥ 70
śrīvasiṣṭha uvāca |
atha bhūdharaśṛṅgābhā sā mahākṛṣṇarākṣasī |
kajjalāmbudalesveva tānavaṃ gantumudyatā
]

`v 2 [
babhūvābhropamākārā tato viṭaparūpiṇī |
puṃspramāṇā tato'pyāsīdathābhūddhastamātrikā
]

`v 3 [
tataḥ prādeśamātrā sā tato'pyaṅgulirūpiṇī |
tato māṣaśamītulyā tataḥ sūcī babhūva ha
]

`v 4 [
tataḥ kauśeyasūcitvaṃ padmakesarasundarī |
prāpa sā śikharākārā saṃkalpādririvāṇutām
]

`v 5 [
rarāja sūcikā kṛṣṇā sūkṣmāyasamanāyasī |
puryaṣṭakena calitā vyomagā vyomavāsinī
]

`v 6 [
sūcī dṛśyata evāsau natvayo nāma vidyate |
saṃvidbhramakule caiṣā svalpasūcīva lakṣyate
]

`v 7 [
ratnasūcīva masṛṇā manomananasaṃyutā |
vaidūryaraśmilekheva bhānusaṃtānasundarī
]

`v 8 [
kajjalāmbhodasaṃkalkalateva pavanāhṛtā |
sūkṣmarandhrekṣaṇasvacchadṛṣṭajyotiḥkanīnikā
]

`v 9 [
sumukhagrāhyarūpeṇa ślakṣṇapucchaśikhāṇunā |
tadā vaipulyaśāntyarthaṃ paraṃ maunavrataṃ gatā
]

`v 10 [
sudūrāddīpavaddṛṣṭaṃ khatanmātratvamāgatā |
dūrādeva manojñena prodgirantī mukhena kham
]

`v 11 [
kuñcitekṣaṇasaṃdṛśyā dīrghadīpāṃśukomalā |
sadyaḥsnātasamutsannabālavālavilāsinī
]

`v 12 [
tanturbisādivoḍḍīnā bāhyasaṃcārakautukāt |
brahmanāḍirivodyuktā bahīrandhraṃ susundarī
]

`v 13 [
niyatendriyaśaktiḥ sā jīvenaiva bahiḥsthitā |
baudhatārkikavijñānasaṃtānavadalakṣitā
]

`v 14 [
p. 300) 183
śūnyasiddhārthasavikā randhrānīlamayā'ravā |
adṛśyayā jīvasūcyā saṃtatānusṛtā sthitā
]

`v 15 [
kalākalanadharmiṇyā vāsanāmātrasārayā |
kṣīṇadīpāṃśusūcīvattīkṣṇayānupalabhyayā
]

`v 16 [
grāsārthaṃ sūcitāṃ yātā saivāsthā nopayujyate |
vicāritaṃ tayā naitadaho maurkhyavijṛmbhitam
]

`v 17 [
sāgrā saṃcintayāmāsa na sūcīrūpatucchatām |
cittamīhitamevaikaṃ paśyantyāste nirarthakam
]

`v 18 [
avicāryaiva sūcitvaṃ tayā mūḍhadhiyāṣthitam |
nānarthabuddheḥ sphurati pūrvāparavicāraṇā
]

`v 19 [
svārthakriyograsāmarthyādyāti bhāvanayānyatām |
padārtho'bhimatāṃśāḍhyo niḥśvāseneva darpaṇaḥ
]

`v 20 [
sūcībhāvaṃ prapannāyāstyajantyāḥ pīvaraṃ vapuḥ |
mahāmaraṇamapyasyā rākṣasyāḥ susukhaṃ sthitam
]

`v 21 [
ekavastvatirāgāṇāmaho nu viṣamā gatiḥ |
deho'pi tṛṇavattyakto rākṣasyā nijayecchayā
]

`v 22 [
ekavastvatigandhena bhraśyantyanyā hi saṃvidaḥ |
rākṣasyā grāsagandhena dehanāśo'pi nekṣitaḥ
]

`v 23 [
nāśo'pi sukhayatyajñamekavastvatirāgiṇam |
sūcībhūtā videhāpi parituṣṭaiva rākṣasī
]

`v 24 [
anyā babhūva lagnā `note[āyasasūcyā saṃlagnā | lagnāśā iti pāṭhaḥ tatra
lagnā āśā prāṇigrasanecchā yasyā ityarthaḥ] sā tathā jīvaviṣūcikā |
vyomātmikā nirākārā vyomavṛttiśarīrakā
]

`v 25 [
tejastanupravāhābhā prāṇatantumayātmikā |
mūlasaṃvedanākārā candrārkāṃśukasundarī
]

`v 26 [
pṛthagevāsidhārābhā paramāṇvavalīya sā |
kausumī gandhalekheva kalā kalanarūpiṇī
]

`v 27 [
pāpātmikā manovṛttiḥ sā hi tasyāstathā sthitā |
paraprāṇavaśādeva paramārthaparāyaṇā
]

`v 28 [
evamasyāstanurjātā sūcīdvayamayī hi sā |
nīhārāṃśukavattanvī kārpāsāṃśusupelavā
]

`v 29 [
tanudvayena tenāsau praviśya hṛdayaṃ nṛṇām |
vedhayantī tataḥ krūrā prababhrāma diśo daśa
]

`v 30 [
sarvaḥ svasaṃkalpavaśāllāghurbhavati vā guruḥ |
karkaṭyograṃ vapustyaktvā sūcītvamurarīkṛtam
]

`v 31 [
saṃkalpasyāghaṭitaghaṭanāsāmarthye idameva nidarśanamityāha - sarva iti |
30 |
tuccho'pyartho'lpasattvānāṃ gacchati prārthanīyatām |
sūcīvṛttapiśācītvaṃ rākṣasyā tapasā sthitam
]

`v 32 [
api puṇyaśarīrāṇāṃ jātibandho na śāmyati |
tanusūcīpiśācītvaṃ rākṣasyā tapasārjitam
]

`v 33 [
tasyāṃ digantabhramaṇe pravṛttāyāṃ mahānilaiḥ |
tatraiva sā tanuḥ sthūlā galitā śaradabhravat
]

`v 34 [
p. 301) 183
kasyacidvivaśāṅgasya kṣīṇasya vipulasya ca |
praviśyāntarvātasūcirbhavatyativiṣūcikā
]

`v 35 [
kasyacittanudehasya svasthasya sudhiyo'pi vā |
praviśya jīvasūcitve bhavatyantarviṣūcikā
]

`v 36 [
evaṃ kvacittṛpyati sā durbuddhihṛdayāsthitā |
kvaciducchedyate puṇyairmantrauṣadhitapaḥkramaiḥ
]

`v 37 [
āsīdbahūni varṣāṇi bhramaṇaikaparāyaṇā |
dehadvayena gacchantī vyomni bhūmitale tathā
]

`v 38 [
rajastirohitā bhūmau haste'ṅgulitirohitā |
prabhātirohitā vyomni vastre sūtratirohitā
]

`v 39 [
antaḥsthasnāyusariti durbhage pāṃśupāṇḍure |
śuṣkarekhāsaritkhāte sūkṣmarekhājarattṛṇe
]

`v 40 [
arthahīne gatacchāye śūnyā ucchvāsakāriṇī |
makṣikāvātaharite śrīvṛkṣaparivarjite
]

`v 41 [
sthūlāsthigranthivalite nityakampasphurattame |
anātmīyācchanīhāre'śuddhaṃśukakṛtabhrame
]

`v 42 [
kiṇasthāṇvaṅgaviśrāntamakṣikāpikavāyase |
raukṣarūḍharasadvāte vilolāṅguliśākhini
]

`v 43 [
kiṇeṣu koṭareṣu sthāṇvaṅgeṣu cchinnāgravṛkṣeṣu ca kramādviśrāntā
madhumakṣikāḥ pikavāyasāśca yatra | śītātiśayena rūkṣa eva raukṣo rūḍhaḥ
prādurbhūto rasan śabdāyamāno vāto yatra | ata eva kampavilolāṅguliśākhini |
42 |
mālābhralekhāsaṃsāre svāṅgulivraṇagartake |
spandāvaśyāyapṛṣati padavalmīkaparvate
]

`v 44 [
kacatyāśu jalabhrāntau nakhājagarakarkaśe |
kvacitkavisaradbhītabhītayūkakupānthake
]

`v 45 [
virūpāśuṣkasaṃdaṣṭavīṭikāpūtipalvale |
madhyasthalekhamārgaughaśītaśvasanagocare
]

`v 46 [
grastayūkānaraughāsṛkpūrṇasṛkkinakhāsyatām |
dadhatāṅguṣṭhapakṣeṇa krānte sarvatra yāyinī
]

`v 47 [
nānāviracanācitrapaṭapattanagāminī |
gamāgamapariśrāntā tatrātyantacirādhvagā
]

`v 48 [
nagarānagare vyastasūtrabhāṇḍaikabhāriṇī |
tapte kalevarāraṇye balīvardāpavartinī
]

`v 49 [
guptā viśramaṇāyaiva manākkaraparicyutā |
tantuprotā mukhākṛṣṭiḥ khinnā kvāpi vilīyate
]

`v 50 [
kenacitsīvanāya gṛhītā ciraṃ sīvane tantuprotamukhākṛṣṭiḥ khinnā śrāntā
satī manāk tatkaraparicyutā satī viśramaṇāyaiva kvāpi guptā pracchannā līyate |
49 |
p. 302) 185
vedhanaṃ karmasaṃśliṣṭā kaṭhināpi na sākarot |
na hi tīkṣṇo vahiḥ kāryo nijatvaṃ vijahāti cet
]

`v 51 [
sāyaḥsūcī manaḥsūcyā valitā vijahāra ha |
dikṣvāśeva śilāgurvī nāvāṅgapalitā satī
]

`v 52 [
visasāra diganteṣu sāntaḥkaraṇasattayā |
tuṣalekheva pavanaśaktyā saṃsṛtirūpayā
]

`v 53 [
mukhena sūkṣmasūtrāntaṃ carantīva parombhitam |
parapūrodyamenāśu jāteva hṛdayānvitā
]

`v 54 [
parairumbhitaṃ gumphitaṃ sūkṣmaṃ sūtrāntaṃ carantī bhakṣayantīva ata eva hi
paraprayuktenaivodarapūraṇodyamena hṛdayānvitā svasthacittā jātevetyutprekṣā |
53 |
parapūrarasenaiva sūcyā hṛtsuvikāsitam |
anāratapatatsūkṣmasūtrānta iva stambhitā
]

`v 55 [
tīkṣṇairapi cirakṣīṇaṃ pūryate nirvicāraṇā |
dṛṣṭānto'tra kṣaṇātsūcyā pūrito jarjaraḥ paṭaḥ
]

`v 56 [
sūtrāṃśunirgame yogyaṃ sūcyā hṛdayamarjitam |
parapūraṇayaivāśu tejaśca kavitārkaruk
]

`v 57 [
akasmāttena rūḍhena kṣīṇapūreṇa rūpiṇī |
hṛdaye rākṣaī sūciḥ karmaṇā tapyate ca sā
]

`v 58 [
vedhaṃ pūrarayeṇeva karoti svaṃ pracāritā |
prakṛtena nijenāpi vedhāya vyavahāritā
]

`v 59 [
saṃcārayati vastreṣu sūtraṃ caturavedhanāt |
ādīrghavāsanātantuḥ śarīreṣviva cetanām
]

`v 60 [
saṃcāryamāṇavedhena dhāvantīvākṣipātane |
adarśitamukhā eva durjanā marmavedhinaḥ
]

`v 61 [
kaṇṭhavastradalaprotā vedhākṣṇā mukhamīkṣate |
kathametā bhinadmīti tīkṣṇānāmetadīpsitam
]

`v 62 [
samameva ca kauśeye kṣaume ca vasane sṛtā |
jaḍaḥ ka iva vā nāma guṇāguṇamapekṣate
]

`v 63 [
sā dadhānā tataṃ sūtramaṅguṣṭhāṅgulipīḍitā |
āntratantumivāmāntamudgirantī nirīkṣate
]

`v 64 [
tīkṣṇāpyahṛdayatvena saraseṣvaraseṣvavit |
sūtritāpi padārtheṣu viśatyarasagāminī
]

`v 65 [
p. 303) 185
agardatī mukhaprotā sutīkṣṇāpi ca tāpidhīḥ |
suvedhitāpyahṛdayā rājaputryāpi durbhagā
]

`v 66 [
vinā parāpakāreṇa tīkṣṇā maraṇamīhate |
vedanādrodhitā sūcī karmapāśe pralambate
]

`v 67 [
śete kiṃśyāmamaitryeva dūre karaparicyutā |
svarūpasadṛśaṃ mitraṃ kasmai nāma na rocate
]

`v 68 [
miśritā mūḍhacittānāṃ vṛttibhiḥ prākṛte jane |
tiṣṭhatyātmasamāṃ ko hi saṃgatiṃ tyaktumicchati
]

`v 69 [
bhavatyayaskāravittau saṃtyajyāntardhigāminī |
bhastrāvātairvicalitā gaganādutpatonmukhī
]

`v 70 [
prāṇāpānapravāhasthahṛtpadmāntaracāriṇī |
duḥkhaśaktirmahāghorā jīvaśaktirivoditā
]

`v 71 [
samānavaiparītyena samānasamagāminī |
udānaviparītatvādudānasamagāminī
]

`v 72 [
vyānasthā vyādhijananī sarvāṅgarasacāriṇī |
hṛtkaṇṭhe śūlapavane vaivarṇyonmādakāriṇī
]

`v 73 [
prāyaśo'vikahastasthā suptorṇāgandhakoṭare |
bālahastāṅgulītalpavedhanaikavilāsinī
]

`v 74 [
pādapraviṣṭā rudhirapānopārjanavismitā |
tuṣyatyatitarāṃ gucchabhojanā tucchabhojanaiḥ
]

`v 75 [
śete kardamakośasthā cirakālamadhomukhī |
icchānurūpamāsādya ka ivāspadamujjhati
]

`v 76 [
krauryeṇāpahatātmānaṃ darśayatyupavedhanaiḥ |
utsavādapi nīcānāṃ kalaho'pi sukhāyate
]

`v 77 [
apahataṃ dūṣitamātmānaṃ svām | upavedhanaiḥ
paraprāṇāpahāraparyantairvedhanaiḥ | svārthābhāve kathaṃ paramāraṇe tasyāḥ
pravṛttistatrāha - utsavādapīti | yeṣāṃ parapīḍā'sāmarthye'pi paraiḥ saha
kalaho'pi sukhāyate teṣāṃ paramāraṇaṃ sukhāyate iti kiṃ vaktavyamiti bhāvaḥ |
76 |
kapardakārdhalābhena kṛpaṇo bahu manyate |
durucchedā hi bhūtānāmahaṃkāracamatkṛtiḥ
]

`v 78 [
sūcikāyugmalabhyena mohitenātmanā nṛṇām |
mṛtimāśaṅkate citrā svārthe nodeti mūḍhatā
]

`v 79 [
vastratantuvibhedena paramāraṇamāśu me |
idaṃ saṃpadyata iti bhavatyantarhi nirmalā
]

`v 80 [
sthāpitā malamādatte yathā mṛdgharṣaṇaṃ vinā |
parāparādhavirahādvyādhistasyāḥ pravartate
]

`v 81 [
sūkṣmā'dṛśyā caiva dātrī kṣaṇādvismṛtimeti sā |
tīkṣṇabhedakarī krūrā sūcī ceṣṭeva daivikī
]

`v 82 [
p. 304) 186
tantuvedhanamātreṇa hato'nya iti toṣitā |
durjano yena tenaiva nāśitenaiti hṛṣṭatām
]

`v 83 [
paṅke majjati yāti khaṃ viharati vyomānilairdiktaṭe
śete pāṃsuṣu bhūtaleṣviva vane paṭṭe gṛhe'ntaḥpure |
haste śrotrasaroruhe'tha mṛduni svecchorṇikākhaṇḍake
randhre kāṣṭhamṛdāṃ ca māti hṛdaye dravyātmaśaktyaiva sā
]

`v 84 [
śrīvālmīkiruvāca |
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagām
śyāmakṣaye ravikaraiśca sahājagāma
]