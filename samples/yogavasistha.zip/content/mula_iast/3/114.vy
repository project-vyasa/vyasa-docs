`v 1 [
caturdaśottaraśatamaḥ sargaḥ 114
śrīrāma uvāca |
avidyāvibhavaprotthaṃ nibiḍaṃ puruṣasya hi |
mahadāndhyamidaṃ brahmankathaṃ nāma vinaśyati
]

`v 2 [
śrīvasiṣṭha uvāca |
yathā tuṣārakaṇikā bhāskarālokanātkṣaṇāt |
naśyatyevamavidyeyaṃ rāghavātmāvalokanāt
]

`v 3 [
evaṃ pṛṣṭo vasiṣṭhaḥ prathamamavidyākṣayopāyamāha - yathetyādinā | 2
|
tāvatsaṃsārabhṛguṣu svātmanā saha dehinam |
āndolayati nīrandhraduḥkhakaṇṭakaśāliṣu
]

`v 4 [
avidyā yāvadasyāstu notpannā kṣayakāriṇī |
svayamātmāvalokecchā mohasaṃkṣayadāyinī
]

`v 5 [
asyāḥ paraṃ prapaśyantyāḥ svātmanāśaḥ prajāyate |
ātapānubhavārthinyāśchāyāyā iva rāghava
]

`v 6 [
dṛṣṭe sarvagate bodhe svayameva vilīyate |
sarvāśābhyuditecchāyā dvādaśārkagaṇe yathā
]

`v 7 [
icchāmātramavidyeha tannāśo mokṣa ucyate |
sa cāsaṃkalpamātreṇa siddho bhavati rāghava
]

`v 8 [
manāgapi manovyomni vāsanārajanīkṣaye |
kālimā tanutāmeti cidādityamahodayāt
]

`v 9 [
yathodite dinakare kvāpi yāti tamasvinī |
tathā viveke'bhyudite kvāpyavidyā vilīyate
]

`v 10 [
dṛḍhavāsanayā bandho ghanatāmeti cetasaḥ |
balādvetālasaṃkalpaḥ saṃdhyākāle yathā śiśoḥ
]

`v 11 [
śrīrāma uvāca |
yāvatkiṃcididaṃ dṛśyaṃ sāvidyā kṣīyate ca sā |
ātmabhāvanayā brahmannātmāsau kīdṛśaḥ smṛtaḥ
]

`v 12 [
śrīvasiṣṭha uvāca |
cetyānupātarahitaṃ sāmānyena ca sarvagam |
yaccittattvamanākhyeyaṃ sa ātmā parameśvaraḥ
]

`v 13 [
ābrahma stambaparyantaṃ tṛṇādi yadidaṃ jagat |
tatsarvaṃ sarvadātmaiva nāvidyā vidyate'nagha
]

`v 14 [
sarvaṃ ca khalvidaṃ brahma nityaṃ cidghanamakṣatam |
kalpanānyā manonāmnī vidyate nahi kācana
]

`v 15 [
na jāyate na mriyate kiṃcidatra jagattraye |
na ca bhāvavikārāṇāṃ sattā kvacana vidyate
]

`v 16 [
kevalaṃ kevalābhāsaṃ sarvasāmānyamakṣatam |
cetyānupātarahitaṃ cinmātramiha vidyate
]

`v 17 [
p. 394) 233
tasminnitye tate śuddhe cinmātre nirupadrave |
śānte samasamābhoge nirvikāroditātmani
]

`v 18 [
yaiṣā svabhāvātigataṃ svayaṃ saṃkalpya dhāvati |
ciccaityaṃ svayamāmlānā sā mlānā tanmanaḥ smṛtam
]

`v 19 [
etasmātsarvagāddevātsarvaśaktermahātmanaḥ |
vibhāgakalanāśaktirlaharīvotthitāmbhasaḥ
]

`v 20 [
ekasminvitate śānte yā na kiṃcana vidyate |
saṃkalpamātreṇa gatā sā siddhiṃ paramātmani
]

`v 21 [
ataḥ saṃkalpasiddheyaṃ saṃkalpenaiva naśyati |
yenaiva jātā `note[jāyate tena iti pāṭhaḥ] tenaiva vahnijvāleva vāyunā | 21
|
vāyuneti | vāyoragniḥ iti śruteriti bhāvaḥ
]

`v 22 [
pauruṣodyogasiddhena bhogāśā rūpatāṃ gatā |
asaṃkalpanamātreṇa sāvidyā pravilīyate
]

`v 23 [
nāhaṃ brahmeti saṃkalpātsudṛḍhādbadhyate manaḥ |
sarvaṃ brahmeti saṃkalpātsudṛḍhānmucyate manaḥ
]

`v 24 [
tathāca bandhamokṣāvapi manodharmāveva nātmadharmāvityāha - nāhamiti |
23 |
saṃkalpaḥ paramo bandhastvasaṃkalpo vimuktatā |
saṃkalpaṃ saṃvijityāntaryathecchasi tathā kuru
]

`v 25 [
dṛḍhā na yāmbare'trāsti nalinī hemapaṅkajā |
lolavaidūryamadhupā sugandhitadigantarā
]

`v 26 [
uddaṇḍaiḥ prakaṭābhogairmṛṇālabhujamaṇḍalaiḥ |
vihasantī prakāśasya śaśino raśmimaṇḍalam
]

`v 27 [
vikalpajālikevetthamasatyevāpi satsamā |
manaḥsvārthavilāsārthaṃ yathā bālena kalpyate
]

`v 28 [
tathaiveyamavidyeha bhavabandhanabandhanī |
capalā na sukhāyaiva bālena kalitā dṛḍhā
]

`v 29 [
kṛśo'ti duḥkhī baddho'haṃ hastapādādimānaham |
iti bhāvānurūpeṇa vyavahāreṇa badhyate
]

`v 30 [
nāhaṃ duḥkhī na me deho bandhaḥ kasyātmanaḥ sthitaḥ |
iti bhāvānurūpeṇa vyavahāreṇa mucyate
]

`v 31 [
nāhaṃ māṃsaṃ na cāsthīni dehādanyaḥ paro hyaham |
iti niścayavānantaḥ kṣīṇāvidya ihocyate
]

`v 32 [
prottuṅgasuraśailāgravaidūryaśikharaprabhā |
athavārkāṃśudurbhedā timiraśrīḥ sthitopari
]

`v 33 [
kalpyate hi yathā vyomnaḥ kālimeti svabhāvataḥ |
puṃsā dharaṇisaṃsthena svasaṃkalpanayeddhayā
]

`v 34 [
kalpitaivamavidyeyamanātmanyātmabhāvanā |
puruṣeṇāprabuddhena na prabuddhena rāghava
]

`v 35 [
śrīrāma uvāca |
merunīlamaṇicchāyā neyaṃ nāpi tamaḥprabhā |
tadetatkiṃkṛtaṃ brahmannīlatvaṃ nabhaso vada
]

`v 36 [
śrīvasiṣṭha uvāca |
na nāma nīlatā vyomnaḥ śūnyasya guṇavatsthitā |
anyaratnaprabhābhāvānna vāpyeṣā ca mairavī
]

`v 37 [
tejomayatvādaṇḍasya sphāratvādiva tejasaḥ |
prākāśyādaṇḍapārasya tamaso nātra saṃbhavaḥ
]

`v 38 [
p. 395) 233
kevalaṃ śūnyataivaiṣāṃ vahni subhaga lakṣyate |
vayasyevānurūpā yā avidyāyā asanmayī
]

`v 39 [
svadṛṣṭikṣayasaṃpattāvakṣṇorevoditaṃ tamaḥ |
vastusvabhāvāttadvyomnaḥ kārṣṇyamityavalokyate
]

`v 40 [
etadbuddhvā yathā vyomni dṛśyamāno'pi kālimā |
na kālimeti buddhiḥ syādavidyātimiraṃ tathā
]

`v 41 [
asaṃkalpo hyavidyāyā nigrahaḥ kathito budhaiḥ |
yathā gaganapadminyāḥ sa bhāti sukaraḥ svayam
]

`v 42 [
bhramasya jāgatasyāsya jātasyākāśavarṇavat |
apunaḥsmaraṇaṃ manye sādho vismaraṇaṃ varam
]

`v 43 [
naṣṭo'hamiti saṃkalpādyathā duḥkhena naśyati |
prabuddho'smīti saṃkalpājjano hyeti yathā sukham
]

`v 44 [
tathā saṃmūḍhasaṃkalpānmūḍhatāmeti vai manaḥ |
prabodhodārasaṃkalpātprabodhāyānudhāvati
]

`v 45 [
kṣaṇātsaṃsmaraṇādeṣā hyavidyodeti śāśvatī |
yasmādvismaraṇādantaḥ pariṇaśyati naśvarī
]

`v 46 [
bhāvanī sarvabhāvānāṃ sarvabhūtavimohinī |
bhāriṇī svātmano nāśe svātmavṛddhau vināśinī
]

`v 47 [
mano yadanusaṃdhatte tatsarvendriyavṛttayaḥ |
kṣaṇātsaṃpādayantyetā rājājñāmiva mantriṇaḥ
]

`v 48 [
tasmānmanonusaṃdhānaṃ bhāveṣu na karoti yaḥ |
antaścetanayatnena sa śāntimadhigacchati
]

`v 49 [
yadādāveva nāstīdaṃ tadadyāpi na vidyate |
yadidaṃ bhāti tadbrahma śāntamekamaninditam
]

`v 50 [
mananīyamato nānyatkadā kasya kathaṃ kutaḥ |
nirvikāramanādyantamāsyatāmapayantraṇam
]

`v 51 [
paraṃ pauruṣamāśritya yatnātparamayā dhiyā |
bhogāśābhāvanāṃ cittātsamūlāmalamuddharet
]

`v 52 [
yadudeti paro moho jarāmaraṇakāraṇam |
āśāpāśaśatollāsivāsanā tadvijṛmbhate
]

`v 53 [
mama putrā mama dhanamayaṃ so'hamidaṃ mama |
itīyamindrajālena vāsanaiva vivalgati
]

`v 54 [
śūnye eva śarīre'sminvilolo jalavātavat |
ananyayā vāsanayā tvahaṃbhāvāhirarpitaḥ
]

`v 55 [
paramārthena tattvajña mamāhamidamityalam |
ātmatattvādṛte satyaṃ na kadācana kiṃcana
]

`v 56 [
khādridyūrvīnadiśreṇyo dṛṣṭisṛṣṭyā punaḥ punaḥ |
saivānyeva vicitreyamavidyā parivartate
]

`v 57 [
udetyajñānamātreṇa naśyati jñānamātrataḥ |
sanmātre parivicchedyā rajjvāmiva bhujaṃgadhīḥ
]

`v 58 [
khādyabdhyurvīnadī seyaṃ yā'vidyā'jñasya rāghava |
nāvidyā jñasya tadbrahma svamahimnā vyavasthitam
]

`v 59 [
rajjusarpavikalpau dvāvajñenaivopakalpitau |
jñena tvekaiva nirṇītā brahmadṛṣṭirakṛtrimā
]

`v 60 [
mā bhavājño bhava prājño jahi saṃsāravāsanām |
anātmanyātmabhāvena kimajña iva rodiṣi
]

`v 61 [
kastavāyaṃ jaḍo mūko deho bhavati rāghava |
yadarthaṃ sukhaduḥkhābhyāmavaśaḥ paribhūyase
]

`v 62 [
p. 396) 234
yathā hi kāṣṭhajatunoryathā badarakuṇḍayoḥ |
śliṣṭayorapi naikatvaṃ dehadehavatostathā
]

`v 63 [
bhastrādāhe yathā dāho na bhastrāntaravartinaḥ |
pavanasya tathā dehanāśe nātmā na naśyati
]

`v 64 [
duḥkhito'haṃ sukhāḍhyo'hamiti bhrāntiṃ raghūdvaha |
mṛgatṛṣṇopamāṃ buddhvā tyaja satyaṃ samāśraya
]

`v 65 [
aho nu citraṃ yatsatyaṃ brahma tadvismṛtaṃ nṛṇām |
yadasatyamavidyākhyaṃ tannūnaṃ smṛtimāgatam
]

`v 66 [
prasaraṃ tvamavidyāyā mā prayaccha radhūdvaha |
anayopahite citte duṣpāreha kadarthanā
]

`v 67 [
mathyaivānarthakāriṇyā manomananapīnayā |
anayā duḥkhadāyinyā mahāmohaphalāntayā
]

`v 68 [
avidyāyā asaṃbhāvitānarthasahasrakāritāṃ prapañcayati - mithyaivetyādinā |
anayā candrabimbe'pi dāhasaṃśoṣaduḥkhaṃ samanubhūyate iti pareṇānvayaḥ | 67
|
candrabimbe sudhārdre'pi kṛtvā rauravakalpanam |
nārakaṃ dāhasaṃśoṣaduḥkhaṃ samanubhūyate
]

`v 69 [
jalakallolakahlārapuṣpasīkaravīciṣu |
sarassu mṛgatṛṣṇāḍhyaṃ maruttvaṃ paridṛśyate
]

`v 70 [
nabhonagaranirmāṇapātotpātanasaṃbhramāḥ |
svapnādiṣvanubhūyante vicitrāḥ sukhaduḥkhadāḥ
]

`v 71 [
saṃsāravāsanāśceto yadi nāma na pūrayet |
tajjāgratsvapnasaṃrambhāḥ kiṃ nayeyurihāpadam
]

`v 72 [
dṛśyate rauravā vīcinarakānarthaśāsanā |
mithyājñāne gate vṛddhiṃ svapnopavanabhūmiṣu
]

`v 73 [
anayā vedhitaṃ ceto bisatantāvapi kṣaṇāt |
paśyatyakhilasaṃsārasāgarānarthavibhramam
]

`v 74 [
anayopahate citte rājya eva hi saṃsthitāḥ |
tāstādṛśyo janā yānti yā na yogyāḥ śvapākinaḥ
]

`v 75 [
tasmādrāma parityajya vāsanāṃ bhavabandhanīm |
sarvarāgamayīṃ tiṣṭha nīrāgaḥ sphaṭiko yathā
]

`v 76 [
tiṣṭhatastava kāryeṣu māstu rāgeṣu rañjanā |
sphaṭikasyeva citrāṇi pratibimbāni gṛhṇataḥ
]

`v 77 [
viditakautukasaṅghasamiddhayā `note[1]
yadi karoṣi sadaiva suśīlayā |
varadhiyā gataprākṛtikakriya-
stadasi kena sahānupamīyase
]