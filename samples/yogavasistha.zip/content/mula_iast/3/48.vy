`v 1 [
p. 245) 147
aṣṭacatvāriṃśaḥ sargaḥ 48
śrīvasiṣṭha uvāca |
prāpya rājā puraḥ prāptaṃ sindhumuddhurakandharam |
madhyāhnatapanāntena kopena vitato'bhavat
]

`v 2 [
dhanurāsphālayāmāsa cirārāvitadiṅmukham |
kalpāntapavanāsphoṭaiva merugirestaṭam
]

`v 3 [
visasarjorjito rājā pralayārkaḥ karāniva |
tūṇīrarajanībaddhāḥ śilīmukhaparamparāḥ
]

`v 4 [
eka eva viniryāti guṇāttasya śilīmukhaḥ |
sahasraṃ bhavati vyomni gacchanpatati lakṣaśaḥ
]

`v 5 [
sindhorapi tathaivāsīcchaktirlāghavameva ca |
vareṇa varadasyaivaṃ viṣṇordhānuṣkatā tayoḥ
]

`v 6 [
musalā nāma te bāṇā musalākṛtayo'mbaram |
chādayāmāsurunnādāḥ kalpāntāśanayo yathā
]

`v 7 [
rejuḥ kanakanārācarājayo vyomni sasvanāḥ |
rasantyaḥ kalpavātārtāḥ patantya iva tārakāḥ
]

`v 8 [
vidūrathāccharāsārā ajasramabhiniryayuḥ |
abdheriva payaḥpūrāḥ sūryādiva marīcayaḥ
]

`v 9 [
pracaṇḍapavanoddhūtātpuṣpāṇīva mahātaroḥ |
ayaḥpiṇḍādivottaptāttāḍitātkaṇapaṅktayaḥ
]

`v 10 [
dhārā varṣamuca iva sīkarā iva nirjharāt |
tatpurāgnimahādāhātsphuliṅgā iva bhāsurāḥ
]

`v 11 [
tayoścaṭacaṭāsphoṭaṃ śṛṇvatkodaṇḍayordvayoḥ |
baladvayamabhūtprekṣāmūkaṃ śānta ivāmbudhiḥ
]

`v 12 [
vahanti sma śarāpūrā gaṅgāpūrā ivāmbare |
sindhorabhimukhaṃ yuddhe ghargharārāvaraṃhasaḥ
]

`v 13 [
kacatkanakanārācaśaravarṣā anāratam |
vahacchavaśavāśabdaṃ niryayurdhanurambudāt
]

`v 14 [
bāṇamandākinīpūraṃ vrajantaṃ sindhupūraṇe |
vātāyanāttamālokya līlā tatpuravāsinī
]

`v 15 [
tena bāṇasamūhena jayamāśaṅkya bhartari |
uvāca vākyamānandavikasanmukhapaṅkajā
]

`v 16 [
jaya devi jayatyeṣa nātho'smākaṃ vilokaya |
kiṃcānena śaraugheṇa merurapyeti cūrṇatām
]

`v 17 [
tasyāmevaṃ vadantyāṃ tu ghanasneharavākulam |
prekṣaṇavyagrayordevyorhasantyormānuṣīṃ hṛdā
]

`v 18 [
taccharārṇavamāmattamapibatsindhuvāḍavaḥ |
śaroṣmaṇā hyagastyena jahnurmandākinīmiva
]

`v 19 [
agastyenāgastyībhūtena śaroṣmaṇā karaṇenāpivat | upasaṃhṛtavāniti yāvat | 18
|
bāṇavarṣeṇa kaṇaśastaṃ sāyakamahāghanam |
chittvā tanurajaḥ kṛtvā cikṣepa gaganārṇave
]

`v 20 [
yathā dīpasya śāntasya na parijñāyate gatiḥ |
tasya sāyakasaṅghasya na vijñātā tathā gatiḥ
]

`v 21 [
taṃ chittvā sāyakāsāraṃ śarīrāmbudharaṃ ghanam |
vyomni prasārayāmāsa rasācchavaśatānvitam `note[rasāt yuddhaviṣaye
rāgāt]
]

`v 22 [
vidūrathastamapyāśu vyadhamatsāyakottamaiḥ |
sāmānyajaladaṃ mattaṃ kalpāntapavano yathā
]

`v 23 [
kṛtapratikṛtairevaṃ bāṇavarṣairmahīpatī |
vyarthīkṛtairanayatāṃ prahāramavicāraṇaiḥ
]

`v 24 [
athādadhe mohanāstraṃ sindhurgandharvasauhṛdāt |
prāptaṃ tena yayurlokā vinā mohaṃ vidūrathāt
]

`v 25 [
vyastaśastrāmbarā mūkā viṣaṇṇavadanekṣaṇāḥ |
mṛtā ivābhavanyodhāścitranyastā ivāthavā
]

`v 26 [
yāvadvidūrathādanyaṃ moho nayati mandatām |
tāvadvidūratho rājā prabodhāstramathādade
]

`v 27 [
p. 246) 148
tataḥ prabodhamāpannāḥ prajāḥ prātarivābjinī |
vidūrathe bhavatsindhuḥ kruddho'rka iva rākṣase
]

`v 28 [
nāgāstramādade bhīmaṃ pāśabandhanakhedadam |
tenābhavannabho vyāptaṃ bhogibhiḥ parvatopamaiḥ
]

`v 29 [
sarpairvilasitā bhūmirmṛṇālaiḥ sarasī yathā |
saṃpannā girayaḥ sarve kṛṣṇapannagakambalāḥ
]

`v 30 [
padārthāḥ sarva eveme viṣoṣmakhinnatāṃ yayuḥ |
saparvatavanābhogā yayau vivaśatāṃ mahī
]

`v 31 [
pūtāṅgārasamākīrṇaṃ viṣavaiṣamyaśaṃsinaḥ |
vavū rūkṣoṣṇanīhāravātā jvalanareṇavaḥ
]

`v 32 [
vidūratho'tha sauparṇamādade'straṃ mahāstravit |
udagurgaruḍāstreṇa sauparṇāḥ parvatā iva
]

`v 33 [
kāñcanīkṛtasarvāśāḥ sarvāśāparipūrakāḥ |
pakṣaparvatasaṃrambhajanitapralayānilāḥ
]

`v 34 [
ghoṇānilajavākṛṣṭaśvasadbhujagamaṇḍalāḥ |
mahāghuraghurārāvapūritāmbhodhikhaṇḍakāḥ
]

`v 35 [
sa suparṇaghano'pāttaṃ sarpaughaṃ bhūprapūrakam |
kaṣṭaṃ śalaśalāyantamagastya iva vāridhim
]

`v 36 [
sarpakambalanirmuktaṃ bhūmaṇḍalamarājata |
cirāttamavanīrandhramiva nirvārirāśi ca
]

`v 37 [
tatastadgaruḍānīkaṃ kvāpyagacchadadṛśyatām |
dīpaugha iva vātena śaradevābdamaṇḍalam
]

`v 38 [
vajrabhītyeva pakṣaughaparvataprakaraḥ puraḥ |
svapnadṛṣṭaṃ jagadiva saṃkalpapurapūravat
]

`v 39 [
tatastamo'stramasṛjatsindhurandhāndhakāradam |
tenāndhakāro `note[tenāndhakāraḥ kṛṣṇo'bhūdbhubile jaṭharopamaḥ iti
pāṭha tatra bhūbile pātāle yajjaṭharaṃ madhyaṃ tadupama ityarthaḥ]
vavṛdhe kṛṣṇo bhūjaṭharopamaḥ
]

`v 40 [
rodorandhre pravisṛta ekārṇava ivābhavat |
matsyā ivābhavansenāstārāśca maṇayo'bhavan
]

`v 41 [
andhakārapravṛttena maṣīpaṅkārṇavopamam |
kajjalācalasaṃbhārodbhūtakalpānilairiva
]

`v 42 [
andhakūpe nipatitā ivāsansakalāḥ prajāḥ |
kalpānta iva saṃśemurvyavahārā diśaṃ prati
]

`v 43 [
vidūratho'tha mārtaṇḍaṃ dīpaṃ brahmāṇḍamaṇḍape |
astraṃ mantravidāṃ śreṣṭhaḥ sṛṣṭvā mantro vyaceṣṭayat
]

`v 44 [
athoditatamombhodhimarkāgastyo gabhastibhiḥ |
apibatkṛṣṇamambhodaṃ śaratkāla ivāmalaḥ
]

`v 45 [
andhakārāmbaronmuktā virejuramalā diśaḥ |
bhūpateḥ purataḥ kāntā iva ramyapayodharāḥ
]

`v 46 [
yayuḥ prakaṭatāmantarakhilā vanarājayaḥ |
lobhakajjalajālena muktā iva satāṃ dhiyaḥ
]

`v 47 [
atha kopākulaḥ sindhu rākṣasāstraṃ mahābhayam |
kṣaṇādudīrayāmāsa mantrodīrṇaśarātmakam
]

`v 48 [
udagurbhīṣaṇā digbhyaḥ paruṣā vanarākṣasāḥ |
pātālagajaphutkārakṣubdhā iva mahārṇavāḥ
]

`v 49 [
kapilordhvajaṭādhūmrāḥ sphuṭaccaṭacaṭāravāḥ |
agnayo lelihānograjihvā ārdrendhanā iva
]

`v 50 [
sāvartavṛttayo vyomni bhīmacītkāraṭāṃkṛtāḥ |
agnidāhā mahādhūmavilolā iva solmukāḥ
]

`v 51 [
daṃṣṭrābisāṅkurākrāntamukhapaṅkākṣadehakāḥ |
uditā lomajambālā duṣpalvalataṭā iva
]

`v 52 [
p. 247) 148
nigirantaḥ pradhāvanto garjantaḥ sarjitā iva |
jaṭājālataḍitpuñjā jaladāḥ sajalā iva
]

`v 53 [
etasminnantare tasmiṁllīlānātho vidūrathaḥ |
nārāyaṇāstraṃ pradade duṣṭabhūtanivāraṇam
]

`v 54 [
udīryamāṇa evāsminmantrarāje'strarājayaḥ |
rākṣasānāṃ praśemustā andhakāra ivodaye
]

`v 55 [
pramuṣṭarākṣasānīkamabhavadbhuvanatrayam |
śaradīva gatāmbhodaṃ vyoma nirmalamābabhau
]

`v 56 [
atha sindhurmumocāstramāgneyaṃ jvalitāmbaram |
jajvaluḥ kakubhastena kalpāgnijvalitā iva
]

`v 57 [
dhūmāmbudabharācchannā babhūvuḥ sakalā diśaḥ |
gagane protapātālatimirākulitā iva
]

`v 58 [
babhūvurjvalitākārā girayaḥ kāñcanā iva |
praphullavananīrandhracampakaughavanā iva
]

`v 59 [
yayurvyomādridikkuñjā jvālājālajaṭālatām |
kuṅkumenotsave mṛtyoḥ samālabdhā iva srajaḥ
]

`v 60 [
jvalitā janatā caikaśaṅkinī sā nabhaḥspṛśā |
sahasrākṛtinauvegacaliteneva sāgarāt
]

`v 61 [
jitvā ripuṃ punarasau yathā praharate tathā |
vāruṇaṃ visasarjāstraṃ pūjayitvā vidūrathaḥ
]

`v 62 [
āyayuḥ salilāpūrāstamaḥpūrā ivābhitaḥ |
adhastādūrdhvato digbhyo dravarūpā ivādrayaḥ
]

`v 63 [
bhāgā iva śaravyomni dhṛtayānā ivāmbudāḥ |
mahārṇavā ivoccasthāḥ kulaśailaśilā iva
]

`v 64 [
tamālaughā ivoḍḍīnāh saṃdhitā iva rātrayaḥ |
kajjalaughā ivodbhūtā lokālokataṭādiva
]

`v 65 [
rasatalaguhābhogā iva vyomadidṛkṣavaḥ |
mahāghuraghurārāvaraṃhobṛṃhitamūrtayaḥ
]

`v 66 [
tāmagnisaṃtatiṃ mattāmācacāmāmbusaṃtatiḥ |
bhuvanavyāpinī saṃdhyāmāśu kṛṣṇeva yāminī
]

`v 67 [
tāmagnisaṃtatiṃ pītvā pūrayāmāsa bhūtalam |
jalaśrīrjaṭitaṃ dehaṃ nidreva vyaktimeyuṣī
]

`v 68 [
evaṃvidhānastramohānvidadhurdhāvanetare |
mithomāyāmayānagre paśyantyanubhavanti ca
]

`v 69 [
hetibhāravarāḥ sindhoścakrarakṣāstato'mbhasā |
tṛṇānīva gatāḥ prohya rathaścāsyābhavatplutaḥ
]

`v 70 [
etasminnantare sindhurastraṃ sasmāra śoṣaṇam |
āpattrāṇakaraṃ daivaṃ dadau ca śararūpiṇam
]

`v 71 [
śaśāmāmbumayī māyā tena yāmeva bhāsvatā |
ye mṛtāste mṛtā eva babhūvuḥ śoṣitā bhuvaḥ
]

`v 72 [
atha mūrkharuṣā tulyastāpaḥ saṃtāpayanprajāḥ |
jajṛmbhe jharjharākīrṇavanavistārakarkaśaḥ
]

`v 73 [
kacatkanakaniḥsyandasundarāṅgacchavirdiśām |
āsīdrājavarastrīṇāmivālepo'ṅgasaṃgataḥ
]

`v 74 [
tena gharmamayīṃ mūrcchāmājagmustadvirodhinaḥ |
grīṣmadāvānalottaptā mṛdavaḥ pallavā iva
]

`v 75 [
vidūratho raṇodreke tāvatkreṃkāramātatam |
kodaṇḍaṃ kuṇḍalīkṛtya parjanyāstramathādade
]

`v 76 [
udaguḥ paṅktayo'bdānāṃ yāminya iva saṃcitāḥ |
tamālavipinoḍḍīnasaṃrambhādambumantharāḥ
]

`v 77 [
vāmanā vāripūreṇa garjanoddāmasaṃcarāḥ |
mahimnāmantharāśeṣakakummaṇḍalakuṇḍalāḥ
]

`v 78 [
p. 248) 149
vavurāvalitāsārā meghaḍambarabhedinaḥ |
kīrṇasīkaranīhārabhārodārāḥ samīraṇāḥ
]

`v 79 [
prapusphuruḥ susauvarṇasarpāpatsaraṇopamāḥ |
vidyuto divi daivyastrīkaṭākṣavalanā iva
]

`v 80 [
jughūrṇurgarjanocchūnapratiśuddhanakandarāḥ |
diśaścalitamātaṅgasiṃharkṣaravaghargharāḥ
]

`v 81 [
mahāmusaladhārābhiḥ peturāsāravṛṣṭayaḥ |
kaṣṭaṭaṃkārakaṭhināḥ kṛtāntasyeva dṛṣṭayaḥ
]

`v 82 [
udabhūtprathamaṃ vāṣpa uṣṇo'nalanibho bhuvaḥ |
pātālādabhravṛndānāṃ yuddhāyevāttavibhramaḥ
]

`v 83 [
tato nimeṣamātreṇa praśemurmṛgatṛṣṇikāḥ |
parabodharasāpūrairyathā saṃsāravāsanāḥ
]

`v 84 [
āsītpaṅkāṅkamakhilaṃ bhūmaṇḍalamasaṃcaram |
pūritaḥ pūrṇadhārābhiḥ sindhuḥ sindhurivāmbunā
]

`v 85 [
vāyavyamastramasṛjatpūritākāśakoṭaram |
kalpāntanṛttasaṃmattaraṭadbhairavabhīṣaṇam
]

`v 86 [
vavuraśaninipātapīḍitāṅgā
dalitaśilāśakalāḥ kakummukheṣu |
pralayasamayasūcakā bhaṭānāṃ
kṛtapaṭutāṃkṛtaṭaṅkinaḥ samīrāḥ
]