`v 1 [
ṣaṭpañcāśaḥ sargaḥ 56
śrīvasiṣṭha uvāca |
etasminnantare rājā parivṛttākṣitārakaḥ |
babhūvaikatanuprāṇaśeṣaḥ śuṣkasitādharaḥ
]

`v 2 [
jīrṇaparṇasavarṇābhaḥ kṣīṇapāṇḍumukhacchaviḥ |
bhṛṅgadhvanitasacchāyaśvāsakūjāvikūṇitaḥ
]

`v 3 [
bhṛṅgasya dhvanitaṃ dhvanistatsacchāyayā śvāsakūjayā vikūṇito dhvanitaḥ |
2 |
mahāmaraṇamūrcchāndhakūpe nipatitāśayaḥ |
antarnilīnaniḥśeṣanetrādīndriyavṛttimān
]

`v 4 [
mahati maraṇamūrcchālakṣaṇe andhakūpe nipatita iva nimagna āśayo mano yasya |
3 |
citranyasta ivākāramātradṛśyo vicetanaḥ |
niḥspandasarvāvayavaḥ samutkīrṇa ivopale
]

`v 5 [
bahunātra kimuktena tanudeśena taṃ jahau |
prāṇaḥ pipatiṣuṃ vṛkṣaṃ svṃ pakṣīvāntarikṣagaḥ
]

`v 6 [
te taṃ dadṛśaturbāle divyadṛṣṭī nabhogatam |
jīvaṃ prāṇamayī saṃvidgandhaleśamivānile
]

`v 7 [
sā jivasaṃvidgagane vātena militā satī |
khe dūraṃ gantumārebhe vāsanānuvidhāyinī
]

`v 8 [
tāmevānusasārātha strīdvayaṃ jīvasaṃvidam |
bhramarīyugalaṃ vātalagnāṃ gandhakalāmiva
]

`v 9 [
tato muhūrtamātreṇa śānte maraṇamūrcchane |
ambare bubudhe saṃvidgandhalekhena vāyunā
]

`v 10 [
apaśyatpuruṣānyāmyānnīyamānaṃ ca tairvapuḥ |
bandhpiṇḍapradānena śarīraṃ jātamātmanaḥ
]

`v 11 [
mārge karmaphalollāsamatidūratare sthitam |
vaivasvatapuraṃ prāpa jantubhiḥ pariveṣṭitam
]

`v 12 [
prāptaṃ vaivasvatapuramādideśa tato yamaḥ |
asya karmāṇyaśubhrāṇi naiva santi kadācana
]

`v 13 [
nityamevāvadātānāṃ kartāyaṃ śubhakarmaṇām |
bhāvatyāḥ sarasvatyā vareṇāyaṃ vivardhitaḥ
]

`v 14 [
prāktano'sya śavībhūto deho'sti kusumāmbare |
praviśatveṣa taṃ gatvā tyajyatāmiti cetasā
]

`v 15 [
tatastyakto nabhomārge yantropala iva cyutaḥ |
atha jīvakalā līlā jñaptiśceti trayaṃ nabhaḥ
]

`v 16 [
pupluve jīvalekhā tu rūpiṇyau te na paśyati |
tāmevānusarantyau te samullaṅghya nabhastalam
]

`v 17 [
loakāntarāṇyatītyāśu vinirgatya jagadgṛhāt |
dvitīyaṃ jagadāsādya bhūmaṇḍalamupetya ca
]

`v 18 [
jagadgṛhaṃ brahmāṇḍaṃ tasmādvinirgatya dvitīyaṃ jagadbrahmāṇḍamāsādya |
17 |
te dve saṃkalparūpiṇyau saṃgate jīvalekhayā |
padmarājapuraṃ prāpya līlāntaḥpuramaṇḍapam
]

`v 19 [
p. 268) 167
kṣaṇādviviśatuḥ svairaṃ vātalekhā yathāmbujam |
sūryabhāso yathāmbhojaṃ surabhiḥ pavanaṃ yathā
]

`v 20 [
śrīrāma uvāca |
brahmanprāptaḥ kathamasau śavasya nikaṭaṃ gṛham |
kathaṃ tena parijñāto mārgo mṛtaśarīriṇā
]

`v 21 [
śrīvasiṣṭha uvāca |
tasya svavāsanāntaḥsthaśavasya kila rāghava |
tatsarvaṃ hṛdgataṃ kasmānnāsau prāpnoti tadgṛham
]

`v 22 [
bhrāntimātrasaṃkhyeyaṃ jagajjīvakaṇodare |
vaṭadhānātarumiva sthitaṃ ko vā na paśyati
]

`v 23 [
yathā jīvadvapurbījamaṅkuraṃ hṛdi paśyati |
svabhāvabhūtaṃ cidaṇustrailokyanicayaṃ tathā
]

`v 24 [
naro yathaikadeśastho dūradeśāntarasthitam |
saṃpaśyati nidhānaṃ svaṃ manasānārataṃ sadā
]

`v 25 [
tathā svavāsanāntasthamabhīṣṭaṃ paripaśyati |
jīvo jātiśatāḍhyo'pi bhrame parigato'pi san
]

`v 26 [
śrīrāma uvāca |
bhagavanpiṇḍadānādivāsanārahitākṛtiḥ |
kīdṛksaṃpadyate jīvaḥ piṇḍo yasmai na dīyate
]

`v 27 [
śrīvasiṣṭha uvāca |
piṇḍo'tha dīyate māvā piṇḍo datto mayeti cit |
vāsanā hṛdi saṃrūḍhā tatpiṇḍaphalabhāṅgaraḥ
]

`v 28 [
yaccittaṃ tanmayo janturbhavatītyanubhūtayaḥ |
sadeheṣu videheṣu na bhavatyanyathā kvacit
]

`v 29 [
sapiṇḍosmīti saṃvittyā niṣpiṇḍopi sapiṇḍavān |
niṣpiṇḍosmīti saṃvittyā sapiṇḍopi napiṇḍavān
]

`v 30 [
yathābhāvanameteṣāṃ padārthānāṃ hi satyatā |
bhāvanā ca padārthebhyaḥ kāraṇebhya udeti hi
]

`v 31 [
yathā vāsanayā jantorviṣamapyamṛtāyate |
asatyaḥ satyatāmeti padārtho bhāvanāttathā
]

`v 32 [
kāraṇena vinodeti na kadācana kasyacit |
bhāvanā kācidapi no iti niścayavānbhava
]

`v 33 [
kāraṇasatyatve hi kāryasatyatā syāt | bhāvanā tu na vastusatīti satyakāraṇena vinā
jātaṃ kārya nāstyeveti śuddhaṃ brahmaiva vastuto'stīti niścayavānbhavetyarthaḥ |
32 |
kāraṇena vinā kāryamā mahāpralayaṃ kvacit |
na dṛṣṭaṃ na śrutaṃ kiṃcitsvayaṃ tvekodayādṛte
]

`v 34 [
cideva vāsanā saiva dhatte svapna ivārthatām |
kāryakāraṇatāṃ yāti saivāgatyeva tiṣṭhati
]

`v 35 [
śrīrāma uvāca |
dharmo nāsti mametyeva yaḥ preto vāsanānvitaḥ |
tasya cetsuhṛdā bhūridharmaḥ kṛtvā samarpitaḥ
]

`v 36 [
p. 269) 167
tattadātra sa kiṃ dharmo naṣṭaḥ syāduta vā na vā |
satyārthā vāpyasatyārthā bhāvanā kiṃ balādhikā
]

`v 37 [
śrīvasiṣṭha uvāca |
deśakālakriyādravyasaṃpattyodeti bhāvanā |
yatraivābhyuditā sā syātsa dvayoradhiko jayī
]

`v 38 [
dharmadātuḥ pravṛttā cedvāsanā tattayā kramāt |
āpūryate pretamatirna cetpretadhiyāśubhā
]

`v 39 [
evaṃ parasparajayājjayatyatrātivīryavān |
tasmācchubhena yatnena śubhābhyāsamudāharet
]

`v 40 [
śrīrāma uvāca |
deśakālādinā brahmanvāsanā samudeti cet |
tanmahākalpasargādau deaśakālādayaḥ kutaḥ
]

`v 41 [
kāraṇe samudetīdaṃ taistadā sahakāribhiḥ |
sahakārikāraṇānāmabhāve vāsanā kutaḥ
]

`v 42 [
śrīvasiṣṭha uvāca |
evametanmahābāho satyātmanna kadācana |
mahāpralayasargādau deśakālau na kaucana
]

`v 43 [
sahakārikāraṇānāmabhāve sati dṛśyadhīḥ |
neyamasti na cotpannā na ca sphurati kācana
]

`v 44 [
dṛśyasyāsaṃbhavādeva kiṃcidyaddṛśyate tvidam |
tadbrahmaiva svacidrūpaṃ sthitamitthamanāmayam
]

`v 45 [
etaccāgre yuktiśataiḥ kathayiṣyāma eva te |
etadarthaṃ prayatno'yaṃ vartamānakathāṃ śṛṇu
]

`v 46 [
evaṃ dadṛśatuḥ prāpte mandiraṃ sundarodaram |
kīrṇaṃ puṣpopahāreṇa vasantamiva śītalam
]

`v 47 [
praśāntācārasaṃrambharājadhānyā samanvitam |
mandārakundamālyādiśavaṃ tatra samaṃ sthitam
]

`v 48 [
praśāntarājakāryācaraṇasaṃrambhayā rājadhānyā lakṣaṇayā
rājadhānīsthajanena tatra gṛhe tairjanaiḥ samaṃ sākaṃ sthitaṃ
mandārakundamālyādipihitaṃ śavaṃ ca dadṛśaturityatrottaratra cānukṛṣyate |
47 |
mandārakundasragdāmavṛtāmbarabṛhacchavam |
śavaśayyāśiraḥsthāgryapūrṇakumbhādimaṅgalam
]

`v 49 [
anivṛttagṛhadvāragavākṣakaṭhinārgalam |
praśāmyaddīpakālokaśyāmalāmalabhittikam |
gṛhaikadeśasaṃsuptamukhaśvāsasamīkṛtam
]

`v 50 [
saṃpūrṇacandrasakalodayakāntikāntaṃ
saundaryanirjitapurandaramandirarddhi |
vairiñcapadmamukulāntaracāruśobhaṃ
niḥśabdamandamiva nirmalamindukāntam
]