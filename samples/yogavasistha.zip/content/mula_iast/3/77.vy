`v 1 [
saptasaptatitamaḥ sargaḥ 77
śrīvasiṣṭha uvāca |
etasminnantare tatra kirātajanamaṇḍale |
hastahāryatamaḥpiṇḍā babhūvāsitayāminī
]

`v 2 [
nīlameghapaṭacchannā nirindugaganāntarā |
tamālavanasaṃpiṇḍā māṃsaloḍḍīnakajjalā
]

`v 3 [
latāghanatayā grāmakoṭaraikāndhyamantharā |
gṛhacatvarasaṃbādhe nagare navayauvanā
]

`v 4 [
p. 315) 191
catvareṣu tamaḥpiṇḍī prajihmīkṛtadīpikā |
kuñcitacchidraniṣkrāntā'dīpikārocirājitā
]

`v 5 [
suvayasyeva karkaṭyāḥ parinṛtyatpiśācikā |
mattavetālakaṅkālakāṣṭhamaunamivāsthitā
]

`v 6 [
suṣuptamṛgabhūtaughaghananīhārahāriṇī |
mandamandamarutsparśalasatprāleyasīkarā
]

`v 7 [
saraḥsu vivaṭadvāri kākabhekataraṅgitā |
antaḥpureṣu ramaṇaraṇannārīnarānanā
]

`v 8 [
jaṅgaleṣu jagajjvālā jaṭālajvalanojjvalā |
kedāreṣvambusaṃsekapṛṣṭhapākamilacchalā
]

`v 9 [
nabhasthalekṣitaspandapraviviktarkṣacakrikā |
vaneṣu visaradvātapatatpuṣpaphaladrumā
]

`v 10 [
śvabhreṣu kauśikasyāntarvāyasavyāhatāravā |
taskarākrāntaparyantagrāmyākrandanakarkaśā
]

`v 11 [
vipine vipināmaunā nagare suptanāgarā |
vaneṣu visaradvātā nīḍeṣvaspandapakṣikā
]

`v 12 [
guhāsu suptasiṃhāḍhyā kuñjeṣusvapadeṇakā |
khe sāvaśyāyanikarā vipine maunacāriṇī
]

`v 13 [
kajjalāmbhodamadhyābhā kācaśailodaropamā |
paṅkapiṇḍāntaraghanā khaḍgacchedyāndhyamāṃsalā
]

`v 14 [
pralayānilavikṣubdhakajjalācalacañcalā |
ekārṇavamahāpaṅkaparvatodaramedurā
]

`v 15 [
aṅgārakoṭaraghanā sauṣuptapadasundarī |
ajñānanidrānibiḍā bhṛṅgapṛṣṭhacchadacchaviḥ
]

`v 16 [
tasyāṃ rajanyāṃ bhīmāyāṃ kirātajanamaṇḍale |
mantriṇā saha bhūpālastasminnavasare tadā
]

`v 17 [
nirjagāma sudhīrātmā nagarātsuptanāgarāt |
aṭavīṃ vikramo nāma viṣamāṃ vīracaryayā
]

`v 18 [
aṭavyāṃ karkaṭī sā tau carantau rājamantriṇau |
apaśyaddhṛtadhairyāstrau vetālālokanonmukhau
]

`v 19 [
atha sā cintayāmāsa labdho bhakṣo hyaho mayā |
mūḍhāvetāvanātmajñau bhāro dehaḥ kilānayoḥ
]

`v 20 [
ihāmutra ca nāśāya mūḍho duḥkhāya jīvati |
yatnādvināśanīyo'sau nānarthaḥ paripālyate
]

`v 21 [
apaśyataḥ svamātmānaṃ mṛtirmūḍhasya jīvitam |
maraṇenodayo'syāsti pāpāsaṃpattihetutaḥ
]

`v 22 [
ādisarge ca niyamaḥ kṛtaḥ paṅkajajanmanā |
hiṃsrāṇāṃ bhojanāyāstu mūḍhātmānātmavāniti
]

`v 23 [
tasmādimau mayaivādya bhoktavyau bhojyatāṃ gatau |
abhavya eva nirdoṣaṃ prāptamarthamupekṣate
]

`v 24 [
kadācittāvimau syātāṃ guṇayuktau mahāśayau |
tādṛṅna ravināśo hi svabhāvānme rocate
]

`v 25 [
tadetau saṃparīkṣe'haṃ yadi tādṛgguṇānvitau |
tadbhakṣaṃ na karomyetau na hiṃsyāṃ guṇinaḥ kvacit
]

`v 26 [
akṛtrimaṃ sukhaṃ kīrtimāyuścaivābhivāñchatā |
sarvābhimatadānena pūjanīyā guṇānvitāḥ
]

`v 27 [
api naṅkṣyāmi dehena naiva bhokṣye guṇānvitam |
sukhayanti hi cetāṃsi jīvitādapi sādhavaḥ
]

`v 28 [
p. 316) 192
api jīvitadānena guṇinaṃ paripālayet |
guṇavatsaṃgamauṣadhyā mṛtyurapyeti mitratām
]

`v 29 [
yatrāhamapi rakṣāmi rākṣasī guṇaśālinam |
tatrānyaḥ ko na kuryāttaṃ hṛdi hāramivāmalam
]

`v 30 [
udāraguṇayuktā ye viharantīha dehinaḥ |
dharātalendavaḥ saṅgādbhṛśaṃ śītalayanti te
]

`v 31 [
mṛtirguṇitiraskāro jīvitaṃ guṇisaṃśrayaḥ |
phalaṃ svargāpavargādi jīvitādguṇisaṃśritāt
]

`v 32 [
tasmādimau parīkṣe'haṃ kayācitpraśnalīlayā |
kiṃmātrajñānakāvetāviti tāmarasekṣaṇau
]

`v 33 [
ādau vicārya saguṇāguṇaleśayuktiṃ
paścātsvato'dhikataraṃ ca guṇairyadi syāt |
kuryāttataḥ samupapattivaśena daṇḍaṃ
daḍyasya yuktisadṛśaṃ ghanasaṃbhavena
]