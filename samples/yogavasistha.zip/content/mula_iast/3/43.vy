`v 1 [
tricatvāriṃśaḥ sargaḥ 43
śrīsarasvatyuvāca |
asmin raṇavare rājanmartavyaṃ bhavatādhunā |
prāptavyaṃ prāktanaṃ rājyaṃ sarvaṃ pratyakṣameva te
]

`v 2 [
kumāryā mantriṇā caiva tvayā ca prāktanaṃ puram |
āgantavyaṃ śavībhūtaṃ prāptavyaṃ taccharīrakam
]

`v 3 [
āvāṃ yāvo yathāyātaṃ vātarūpeṇa ca tvayā |
āgantavyaḥ sa deśastu kumāryā mantriṇāpi ca
]

`v 4 [
mṛtvā vāyurūpiṇā ātivāhikadeśarūpeṇa tvayā sa prāktano deśa āgantavyaḥ |
3 |
anyaiva gatiraśvasya gatiranyā kharoṣṭrayoḥ |
madasvinnakapolasya gatiranyaiva dantinaḥ
]

`v 5 [
prastuteti kathā yāvanmitho madhurabhāṣiṇoḥ |
tāvatpraviśya saṃbhrānta uvācordhvasthito naraḥ
]

`v 6 [
p. 235)
deva sāyakacakrāsigadāparighavṛṣṭimat |
mahatparabalaṃ prāptamekārṇava ivoddhataḥ
]

`v 7 [
kalpakālāniloddhūtakulācalaśilopamam |
gadāśaktibhuśuṇḍīnāṃ vṛṣṭiṃ muñcati tuṣṭimat
]

`v 8 [
nagare nagasaṃkāśe lagno'gnirvyāptadiktaṭaḥ |
dahaṃścaṭacaṭāsphoṭaiḥ pātayatyuttamāṃ purīm
]

`v 9 [
kalpāmbudaghaṭātulyā vyomni dhūmamahādrayaḥ |
balātproḍḍayanaṃ kartuṃ pravṛttā garuḍā iva
]

`v 10 [
śrīvasiṣṭha uvāca |
sasaṃbhramaṃ vadatyevaṃ puruṣe paruṣāravaḥ |
udabhūtpūrayannāśā bahiḥ kolāhalo mahān
]

`v 11 [
balādākarṇakṛṣṭānāṃ dhanuṣāṃ śaravarṣiṇām |
bṛṃhatāmatimattānāṃ kuñjarāṇāṃ tarasvinām
]

`v 12 [
pure caṭacaṭāsphoṭairdahatāṃ jātavedasām |
paurāṇāṃ dagdhadārāṇāṃ mahāhalahalāravaiḥ
]

`v 13 [
taratāmagnikhaṇḍānāṃ ṭāṃkāraḥ kathito ravaiḥ |
jvalitānāṃ parispandāddhagaddhagiti cārciṣām
]

`v 14 [
atha vātāyanāddevyau mantrī rājā vidūrathaḥ |
dadṛśuḥ prollasannādaṃ mahāniśi mahāpuram
]

`v 15 [
pralayānalasaṃkṣubdhapūrṇaikārṇavaraṃhasā |
pūrṇaṃ parabalenograhetimeghataraṅgiṇā
]

`v 16 [
kalpāntavahnivigalanmerubhūdharabhāsuraiḥ |
dahyamānaṃ mahājvālājvālairambarapūrakaiḥ
]

`v 17 [
muṣṭigrāhyamahāmeghagarjāsaṃtarjitorjitaiḥ |
ghoraṃ kalakalārāvairmāṃsalairdasyujalpitaiḥ
]

`v 18 [
puṣkarāvartasaṃkāśadhūmrābhrapihitāmbaram |
proḍḍīnahemāgranibhairjvālāpuñjairnirantaram
]

`v 19 [
taradulmukakhaṇḍogratārātaralitāmbaram |
anyonyadeśasadmaughaprajvalajjvalanācalam
]

`v 20 [
hatasainyapurāpātaṃ drutāṅgārābhrakoṭaraiḥ |
karkaśākrandanirdagdhalokapūgogragarjitam
]

`v 21 [
kṛśānukaṇanārācanirantaratarāmbaram |
bahuhetiśilājālaluṭaddagdhapurotkaram
]

`v 22 [
raṇaddviradasaṃghaṭṭakuṭṭitodbhaṭasadbhaṭam |
vidravattaskaracchedamārgakīrṇamahādhanam
]

`v 23 [
aṅgārarāśinipatannaranāryugrarodanam |
sphuṭaccaṭacaṭāśabdapraluṭhatsphuṭakāṣṭhakam
]

`v 24 [
vipulālātacakraughaśatasūryanabhastalam |
aṅgāraśikhirākīrṇasamastavasudhātalam
]

`v 25 [
dagdhāgnikāṣṭhakreṃkāraraṇajjvalanavaiṇavam |
dagdhajantughanākrandarudatsakalasainikam
]

`v 26 [
pāṃsuśeṣāttarājaśrīvṛddhatṛptahutāśanam |
sakalagrasanārambhasodyogāgnimahāśanam
]

`v 27 [
pāṃsava eva śiṣyante yathā tathā āttāyāṃ dagdhāyāṃ rājaśriyi vṛddhaḥ
pravṛddhastṛptaśca hutāśano yatra | agnilakṣaṇo mahāśano ghasmaro yatra |
26 |
yadṛcchātkāraḍātkārakaṭhināgniraṭadgṛham |
anantajantubhojyānnavahnibhuktendhanaspṛham
]

`v 28 [
yadṛcchayā akasmādeva daivopapāditābhyāṃ sarvasvādānamātkāro niśi
supteṣu dasyubhiḥ praharaṇaṃ ḍātkārastābhyāṃ kaṭhinena kurvāreṇāgninā ca
raṭanto gṛhā yatra | anantānāṃ jantūnāṃ bhojyeṣu bhojanārheṣvanneṣu
dhānyarāśiṣu vahninā bhukteṣu avaśiṣṭendhanamātre keṣāṃcitspṛhā yatra |
27 |
atha śuśrāva tatrāsau giro rājā vidūrathaḥ |
yodhānāṃ dagdhadārāṇāṃ paśyatāmbhidhāvatām
]

`v 29 [
p. 236)
hā mattamarudūrdhvasthānaṅgāra gṛhapādapān |
raṇatkharakharaṃ nīrajālāmātapapanthinaḥ
]

`v 30 [
hā dagdhadārāḥ prāleyaśītā deheṣu dantinām |
magnā manassu mahatāmiva vijñānasūktayaḥ
]

`v 31 [
hā tāta hetayo lagnāstaruṇīkabarītṛṇe |
jvalanti śuṣkaparṇaughā iva vīrānileritāḥ
]

`v 32 [
āvartananadīdīrghā vahatyūrdhvataraṅgiṇī |
paśyeyaṃ dhūmayamunā vyomagaṅgāṃ pradhāvati
]

`v 33 [
vahadulmukakāṣṭhordhvagāminī dhūmanimnagā |
vaimānikānandhayati paśyāgnikaṇabudbudā
]

`v 34 [
vahanti pravahanti ulmukakāṣṭhāni yasyāṃ sā | agnikaṇā eva budbudā yasyām |
33 |
asyā mātā pitā bhrātā jāmātā stanapāḥ sute |
asminsadmani nirdagdhā dagdhaivāsatsamindhane
]

`v 35 [
hā hā hāgaccha te śīghrametadaṅgāramandiram |
itaḥ pravṛttaṃ patituṃ sumeruḥ pralaye yathā
]

`v 36 [
aho śaraśilāśaktikuntaprāsāsihetayaḥ |
jālasaṃdhyābhrapaṭalaṃ viśanti śalabhā iva
]

`v 37 [
hetipravāhā jvalanaṃ nabhasyantyāṃ viśantyaho |
vaḍavānalamujjvālamarṇaḥ `note[katipayādarśāntarairapyatra raṇādityeva
paṭhyate parantvetatpāṭho mūlānugatvātsuvaca iti sa eva
saṅgṛhīto'smābhiḥ] pūrā ivārṇavāt
]

`v 38 [
dhūmāyanti mahābhrāṇi jvālāḥ śikharikoṭiṣu |
sarasānyapi śuṣyanti hṛdayānīva rāgiṇām
]

`v 39 [
ālānatvaruṣevaitā dantibhirvṛkṣapaṅktayaḥ |
sphuratkaṭakaṭārāvaṃ pātyante kṛtacītkṛtaiḥ
]

`v 40 [
puṣṭapuṣpaphalaskandhā gataśrīkā gṛhadrumāḥ |
gatā nirdagdhasarvasvā gṛhasthā iva dīnatām
]

`v 41 [
mātāpitṛvinirmuktā bālakāstimirāvalīm |
magnanto'ṅgeṣurathyāsu kuḍyapātena hā hatāḥ
]

`v 42 [
vātavidrāvitāttrasyankariṇyo raṇamūrdhani |
patadaṅgārakāgārabhāriṇaḥ kaṭukūjitam
]

`v 43 [
hā kaṣṭamasinirbhinne skandhe sannadṛḍholmuke |
patito yantrapāṣāṇaḥ puruṣasyāśaniryathā
]

`v 44 [
gavāśvamahiṣebhoṣṭraśvaśṛgālaiḍakairaho |
ghorai raṇamivārabdhaṃ mārgarodhakamākulaiḥ
]

`v 45 [
paṭaiḥ paṭapaṭāśabdajalajālālimālitaiḥ |
ākrandantyaḥ striyo yānti sthalapadmācitā iva
]

`v 46 [
strīṇāṃ jvālālavāḥ paśya lihantyalakavallarīḥ |
kurvanto'śokapuṣpābhāṃ karabhā iva pannagīḥ
]

`v 47 [
hā hā hariṇaśāvākṣyāḥ pakṣalakṣaṇapakṣmasu |
kumārgeṣviva viśrāntimeti kārśānavi śikhā
]

`v 48 [
dahyamāno viniryāti na kalatraṃ vinā naraḥ |
aho bata durucchedāḥ prāṇināṃ snehavāgurāḥ
]

`v 49 [
karī rabhasanirlūnajvaladaṅgārapādapaḥ |
pluṣṭapuṣkarakaḥ kopānmagnaḥ puṣkaradaṃ saraḥ
]

`v 50 [
p. 237)
dhūmo'mbudapadaṃ prāpya vilolāntastaḍillataḥ |
jvaladaṅgāranārācanikaraṃ parivarṣati
]

`v 51 [
deva dhūmasphuradvahnikaṇa āvartavṛttimān |
sthita āpīḍavānvyomni ratnapūrṇa ivārṇavaḥ
]

`v 52 [
gauramambaramābhāti jvālāśikharatejasā |
mṛtyunevotsave dattaḥ kuṅkumāktakaraṇḍakaḥ
]

`v 53 [
aho nu viṣamaṃ cedaṃ vartate vṛttavarjitam |
dhriyante rājanāryo'pi vairivīrairudāyudhaiḥ
]

`v 54 [
lolasragadāmakusumairmārgaprākārakārakaiḥ |
ardhanirdagdhakabarīkīrṇavakṣasthalastanāḥ
]

`v 55 [
ālolāmbarasaṃlakṣyanitambajaghanasthalāḥ |
patanmāṇikyavalayavalitāvanimaṇḍalāḥ
]

`v 56 [
chinnahāralatājālavikīrṇāmalamauktikāḥ |
dṛṣṭādṛṣṭastanaśreṇīpārśvodyatkanakaprabhāḥ
]

`v 57 [
kurarīkarkaśākrandamandīkṛtaraṇāravāḥ |
dhārāvāhāsrutārāvabhinnapārśvavicetanāḥ
]

`v 58 [
raktakardamabāṣpāmbuklinnagranthitavāsasaḥ |
bhujamūlārpitabhujairnīyamānā balānnṛbhiḥ
]

`v 59 [
ka ivāsminparitrātā syādityādīnavīkṣitaiḥ |
utpalālīva varṣadbhiḥ pariroditasainikāḥ
]

`v 60 [
mṛṇālakomalācchorumūlajālaiḥ sunirmalaiḥ |
svacchāmbaratalālakṣyairākāśanalinīnibhāḥ
]

`v 61 [
ālolamālyavasanābharaṇāṅgarāgā
bāṣpākulātatacalālakavallarīkāḥ |
ānandamandaranirantaramathyamānā-
tkāmārṇavātsamuditā iva rājalakṣmyaḥ
]