`v 1 [
ekaṣaṣṭitamaḥ sargaḥ 61
śrīrāma uvāca |
ahaṃ jagaditi bhrāntiḥ parasmātkāraṇaṃ vinā |
yathodeti tathā brahmanbhūyaḥ kathaya sādhu me
]

`v 2 [
śrīvasiṣṭha uvāca |
samastāḥ samataivāntāḥ saṃvido budhyate yataḥ |
sarvathā sarvadā sarvaṃ sarvātmakamajastataḥ
]

`v 3 [
sarvā hi śabdārthadṛśo brahmaivaitāḥ pṛthaṅga tat |
sarvārthaśabdārthakalārūpamāsāṃ na vidyate
]

`v 4 [
kaṭakatvaṃ pṛthagghemnastaraṅgatvaṃ pṛthagjalāt |
yathā na saṃbhavatyevaṃ na jagatpṛthagīśvarāt
]

`v 5 [
eṣa eva jagadrūpaṃ jagadrūpaṃ tu neśvare |
hemaiva kaṭakāditvaṃ kaṭakatvaṃ na hemani
]

`v 6 [
yathāvayavino rūpamanekāvayavātmakam |
tathā'navayavāyāstu citaḥ sarvātmakaṃ ca yat | 6 |
nanvekasyānekātmatāvirodha ityāśaṅkya yatra
samasattākairapyanekairavayavairekasyāvayavinaḥ samasattākaṃ tādātmyaṃ loke
na viruddhaṃ tatra kiṃ vācyaṃ kalpitairanekairvāstavaṃ
brahmaikyamaviruddhamitītyāśayenāha - yatheti | kiṃcaikātmye sarvasya
sarvātmatālābhādanekatvāpagamādapyavirodha ityāśayenāha - sarvātmakaṃ
ceti
]

`v 7 [
yattulyakālamakhilaṃ tanmātrāvedanaṃ pare |
antasthaṃ tadidaṃ bhāti jagadityahamityapi
]

`v 8 [
p. 282) 174
lekhaughānāṃ yathā bhedasaṃniveśaḥ śilodare |
tathānanyajjagadahaṃ cetyantaścidghane ghanam
]

`v 9 [
sthitāstaraṅgāḥ salile yathāntarataraṅgite |
sṛṣṭiśabdārtharahitāstathāntaḥ sṛṣṭayaḥ pare
]

`v 10 [
na sarge tiṣṭhati paraṃ sargastiṣṭhati no pare |
avayavāvayavivatsattānavayavaistayoḥ
]

`v 11 [
cidrūpeṇa svasaṃvittyā svacinmātraṃ vibhāvyate |
svameva rūpahṛdayaṃ vātena spandanaṃ yathā
]

`v 12 [
tatkālameṣa śabdāṇuściccamatkārarūpadhṛk |
cetate svamivaivāntaḥ saṃkalpa iva cetasā
]

`v 13 [
tadevānilatāṃ vetti nijasattātmikāṃ svayam |
antargatasparśarasāṃ pavanaspandatāmiva
]

`v 14 [
tadevābhāsatāmeti nijasattātmikāṃ svayam |
kośasthitālokalavāṃ tejaḥ pragaṭatāmiva
]

`v 15 [
tadevaṃ jalatāṃ yāti nijasattātmikāṃ svayam |
antaḥsthitāsvādalavāṃ salilaṃ dravatāmiva
]

`v 16 [
tadedāvanitāṃ vetti svacittaikātmatāmayīm |
antaḥsthagandhatanmātrāmurvī sthairyakalāmiva
]

`v 17 [
tulyakālanimeṣāṃśalakṣabhāgapratīti yat |
nijaṃ vidaḥ prakacanaṃ tatsargaughaparamparā
]

`v 18 [
śuddhaṃ sakṛtprabhātāntardṛśyamadhyamanāmayam |
udayāstamayonmuktaṃ brahma tiṣṭhatyaniṣṭhitam
]

`v 19 [
buddhaṃ sadapavargaṃ tatsasargamapi satsamam |
abuddhaṃ sargarūpātma visargamapi tatsadā
]

`v 20 [
cidbrahma yadyathā yena budhyate svātmanātmani |
tattattathā nu bhavati sarvaṃ sarvāṅgaśaktimat
]

`v 21 [
tatsatyaṃ cidvilāsatvānnityānubhavarūpataḥ |
tadasatyaṃ manaḥ ṣaṣṭhātsarvākhyā nigataṃ yataḥ
]

`v 22 [
yathaitatsaraṇaṃ vāyau tathā sargaḥ sthitaḥ pare |
asatkalpe'pi saṃkalpaḥ satye'satya ivāpi ca
]

`v 23 [
p. 283) 174
anyarūpā yathānanyā tejasyālokatodare |
tathā brahmaṇi viśvaśrīḥ satyāsatyātmikā citi
]

`v 24 [
anutkīrṇā yathā paṅke putrikā cātha dāruṇi |
yathā varṇā maṣīkalke tathā sargāḥ sthitāḥ pare
]

`v 25 [
ananyānyeva kacati brahmatattvamarusthale |
asatyātmani satyeva trijaganmṛgatṛṣṇikā
]

`v 26 [
brahmaṇā cinmayenātmā sargātmaiva vibhāvyate |
na bhāvyate cānanyatvādbījenāntariva drumaḥ
]

`v 27 [
yathā kṣīrasya mādhuryaṃ tīkṣṇatvaṃ maricasya ca |
dravatvaṃ payasaścaiva spandanaṃ pavanasya ca
]

`v 28 [
sthito'nanyo yathānyaḥ sannāsti tatra tathātmani |
sargo nirgalacidrūpaḥ paramātmātmarūpabhṛt
]

`v 29 [
ananyaḥ san sthitaḥ | anyaḥ sannāsti asannityarthaḥ | nirgalīti nirgalaḥ
pravilīnamātraścidrūpaḥ san paramātmamātrapariśiṣṭasvarūpabhṛdityarthaḥ |
28 |
kacanaṃ brahmaratnasya jagadityeva yatsthitam |
tadakāraṇakaṃ yasmāttena na vyatiricyate
]

`v 30 [
vāsanā cittajīvādivedanaṃ vedanoditam |
nodetyavedanādeva yatanādeva pauruṣāt
]

`v 31 [
nāstameti na codeti kvacitkiṃcitkadācana |
sarvaṃ śāntamajaṃ brahma ciddhanaṃ suśilāghanam
]

`v 32 [
parāṇuṃ prati sargaughāścitādbhrāntisahasraśaḥ |
teṣvapyaṇāvaṇāvantaḥ kaivātrāvāsanā katham
]

`v 33 [
yathā jalānta ūrmyādyā guptāguptāśca śaktayaḥ |
jāgratsvapnasuṣuptādyāstathā jīve'ntarāsthitāḥ
]

`v 34 [
jātā cedaratirjantorbhogānprati manāgapi |
tadasau tāvataivoccaiḥ padaṃ prāpta iti śrutiḥ
]

`v 35 [
yato yato virajyate tatastato vimucyate |
ato'hamityasaṃvidanka eti janmasaṃvidam
]

`v 36 [
citiṃ parāparāmajāmarūpikāmanāmikām |
carācarā'dharāmayīṃ vidanti ye jayanti te
]

`v 37 [
pare citiḥ svaprakaṭādvitīyā-
svāvartalekheva jale dravāntaḥ |
sāhaṃ tayemāni jaganti dhatte
na santi nāsanti parātmakāni
]

`v 38 [
ahaṃmayī padmajabhāvanā cit
saṃkalpabhedādvitanoti viśvam |
antarmukhaivānubhavatyananta-
nimeṣakoṭyaṃśavidhau yugāntam
]