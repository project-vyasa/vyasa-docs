`v 1 [
ṣaṣṭho divasaḥ |
ekasaptatitamaḥ sargaḥ 71
śrīvasiṣṭha uvāca |
atha sā bahukālena karkaṭī nāma rākṣasī |
sarveṣāṃ naramāṃsānāṃ natu tṛptimupāyayau
]

`v 2 [
pūrveṇaiva kilāhnā sā tṛptā rudhirabindunā |
sūcyāḥ kimiva mātyantastṛṣṇāsūcī sudurbharā
]

`v 3 [
cintayāmāsa hā kaṣṭaṃ kimahaṃ sūcitāṃ gatā |
sūkṣmāsmi hataśaktiśca api grāso na māti ca
]

`v 4 [
kva me tāni viśālāni gatānyaṅgāni durdhiyaḥ |
kālameghaviśālāni vane śīrṇāni parṇavat
]

`v 5 [
mayyasyāṃ mandabhāgyāyāṃ manāgapi na māti hi |
svādumāṃsarasagrāso vasāvāsita āsayan
]

`v 6 [
paṅkāntarvinimajjāmi patāmi dharaṇītale |
hastāsmi janapādaughaiḥ śukreṇa malināsmi ca
]

`v 7 [
hā hatāhamanāthāhamanāśvāsā nirāspadā |
duḥkhādduḥkhe nimajjāmi saṃkaṭātsaṃkaṭe'pi ca
]

`v 8 [
na sakhī na ca me dāsī na me mātā na me pitā |
na me bandhurna me bhṛtyā na me bhrātā na me sutaḥ
]

`v 9 [
na me deho na me sthānaṃ na me kaścitsamāśrayaḥ |
naikasthāne samāvāso bhrāmyāmi vanaparṇavat
]

`v 10 [
āpadāṃ dhuri tiṣṭhāmi niviṣṭāsmi sudāruṇe |
abhāvamapi vāñchāmi so'pi saṃpadyate na me
]

`v 11 [
svako dehaḥ parityakto mūḍhacetanayā mayā |
kācabuddhyā vimūḍhena hastāccintāmaṇiryathā
]

`v 12 [
āpataddhi mano mohaṃ pūrvamāpatprayacchati |
paścādanarthavistārarūpeṇa parijṛmbhate
]

`v 13 [
dhūmeṣu paritiṣṭhāmi mārge vilulitāsmi ca |
tṛṇeṣu preṣitāsmyantarhā me duḥkhaparamparā
]

`v 14 [
parapraiṣakarī nityaṃ parasaṃcāracāriṇī |
paraṃ kārpaṇyamāyātā jātā paravaśāsmyalam
]

`v 15 [
bhrāntiṃ karomi tucche ca sāpi vedhanarūpiṇī |
aho mamālpabhāgyāyā daurbhāgyamapi durbhagam
]

`v 16 [
tuccheṣvāntararaktādyāsvādaviṣayeṣu bhrāntimabhilāṣam | sā bhrāntirapi
vedhanarūpiṇī vedhanamātraphalā nāsvādanaphalā | nirudarajihvatvādityarthaḥ | 15
|
p. 305) 186
utthitaḥ sphāravetālaḥ kurvatyāḥ śāntimadya me |
sarvanāśo'vadātena pravṛttāyā mamoditā
]

`v 17 [
kiṃ mandayā mayā tādṛksaṃtyaktaṃ tanmahāvapuḥ |
yathā nāśena vā bhāvyaṃ tathodetyaśubhā matiḥ
]

`v 18 [
māmavāntaranirmagnāṃ sūkṣmāṃ kīṭatanorapi |
uddhariṣyati ko nāma pāṃsurāśibhirāvṛtām `note[hāritāṃ
pāṃsurāśibhiḥ iti pāṭhaṣṭīkānuguṇaḥ]
]

`v 19 [
nāpūjayadgaṇeśānaṃ sūcīsṛṣṭau sa viśvasṛṭ | nāpasūtrāṃ tataḥ sūcīṃ
naṣṭāṃ vindati mānavaḥ | ityābhāṇakamanusṛtyāha-māmiti | avāntare
pathi daivātpāṃsunirmagnāṃ ko vā uddhariṣyati | durlakṣyatvānna
kaściduddhariṣyatītyarthaḥ | hāritāṃ hāpitām | āvṛtām iti pāṭhe tu spaṣṭam |
18 |
viviktamanasāṃbuddhau kva sphuranti hatāśayāḥ |
grāmamārgatṛṇānīva gireruparivāsinām
]

`v 20 [
sthitāyā ajñatāmbhodhau kva mamābhyudayo bhavet |
andhasyodeti prākāśyaṃ nakhadyotānusevinaḥ
]

`v 21 [
ataḥ kiyantaṃ no jāne kālamāvalitāpadam |
mayāpacchvabhragarteṣu luṭhitavyaṃ hatehayā
]

`v 22 [
kadā syāmañjanamahāśailaputrakarūpiṇī |
dyāvāpṛthivyorvaidhurye stambhatāmanutiṣṭhatī
]

`v 23 [
meghamālāsamabhujā ciraṃ vidyutpadekṣaṇā |
nīhārajālavasanā proccakeśamitāmbarā
]

`v 24 [
lambodarābhrasaṃdarśapranartitaśikhaṇḍinī |
lambalolastanī śyāmā dehavātadravatstanī
]

`v 25 [
hāsabhasmacchaṭācchannasūryamaṇḍalarodhinī |
kṛtāntagrasanodyuktakṛtyaikākṛtidhāriṇī
]

`v 26 [
kṛśānūlūkhaladṛśā sūryasragdāmahāriṇī |
parvatātparvate śṛṅge nyasya pādau vihāriṇī
]

`v 27 [
kadā me syādguruśvabhrabhāsuraṃ tanmahodaram |
kadā me syāccharanmeghamedurā nakharāvalī
]

`v 28 [
kadā me syānmahārakṣovidrāvaṇakaraṃ smitam |
svasphigvādyairaraṇyānyāṃ kadā nṛtyeyamunmadā
]

`v 29 [
vasāsavamahākumbhairmṛtamāṃsāsthisaṃcayaiḥ |
kadā kariṣye'virataṃ medurodarapūraṇam
]

`v 30 [
kadā pītamahālokarudhirā kṣībatāṃ gatā |
bhaveyaṃ muditā dṛptā mudritā nidrayā tataḥ
]

`v 31 [
mayaiva kutapovahnau tadagryaṃ bhāsuraṃ vapuḥ |
bhasmatvaṃ kanakeneva sūcitvamurarīkṛtam
]

`v 32 [
kva kliāñjanaśailābhaṃ vapurbharitadiktaṭam |
kva prācikākhurasamaṃ sūcitvaṃ tṛṇapelavam
]

`v 33 [
tyajatyāśu mṛdityajñaḥ prāpyāpi kanakāṅgadam |
mayā sūcitvalobhena saṃtyaktaṃ bhāsuraṃ vapuḥ
]

`v 34 [
hā mahodara vindhyādrisanīhāraguhopama |
adya nāntaṃ karoṣi tvaṃ kathaṃ siṃhena hastinām
]

`v 35 [
hā bhujau bharanirbhagnaśikharau śaśabhṛnnakhaiḥ |
puroḍāśadhiyā candraṃ kathamadya na bādhataḥ
]

`v 36 [
p. 306) 187
hā vakṣaḥ kācavaidhuryagirīndrataṭasundara |
nādya siṃhādi yaukaṃ taddhṛtaṃ romavanaṃ tathā
]

`v 37 [
hā netre kṛṣṇarajanīrajaḥśuṣkendhanaijane |
kasmānna me bhūṣayato dṛgjvālāmālayā diśaḥ
]

`v 38 [
hā skandha bandho naṣṭo'si niṣiddho'si mahītale |
kālena vinipiṣṭo'si nipṛṣṭo'si śilātale
]

`v 39 [
hā mukhendo tapasi kiṃ nādya tvaṃ mama raśmibhiḥ |
kalpāntadāvasaṃśāntacandrabimbamanohara
]

`v 40 [
hā hā hastau mahākārau tāvadya kva gatau mama |
saṃpannāsmi mahāsūcirmakṣikākhuradolitā
]

`v 41 [
hā `note[tvāṃ śocāmītyarthaḥ]
bhagograkarañjāḍhyasatkandaśvabhraśobhana |
vindhyādvareṇyavipulanitambāmalabimbaka
]

`v 42 [
kvākāro'mbarapūrakaḥ kva ca navaṃ tucchātmasūcīvapū
rodorandhrasamaṃ kva vāsya kuharaṃ kvedaṃ ca sūcīmukham |
kva grāso bahumāṃsabhārabahulaḥ kvābbindunā bhojanaṃ
sūkṣmāsmyetadaho mayaiva racitaṃ svātmakṣaye nāṭakam
]