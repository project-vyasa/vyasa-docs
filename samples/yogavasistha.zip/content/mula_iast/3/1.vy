`v 1 [
(ātivāhikadehasya `note[kvācitkamidaṃ dhanuśihnāntargataṃ
padyam] kālenābhyudito bhramaḥ |
ādhibhautikadeho'hamiti rajjubhujaṃgavat | 1 |)
]

`v 15 [
ātivāhikadehena dṛśyaṃ yadavalokitam |
bhūmyādi nāma tasyaiva kṛtaṃ taccādhibhautikam
]

`v 16 [
vāstavena tu rūpeṇa bhūmyādyātmādhibhautikaḥ |
na śabdena na cārthena satyātmā śaśaśṛṅgavat
]

`v 17 [
puṃso hariṇako'smīti svapne yasyoditā matiḥ |
sa kimanviṣyati mṛgaṃ svamṛgatvaparikṣaye
]

`v 18 [
udetyasatyamevāśu tathā satyaṃ vilīyate |
bhrāntirbhramavato rajjvāmapi sarpabhrame gate
]

`v 19 [
samastasyāprabuddhasya manojātasya kasyacit |
bījaṃ vinā mṛṣaiveyaṃ mithyārūḍhimupāgatā
]

`v 20 [
p. 271) 168
svapnopalambhaṃ sargākhyaṃ sa sarvo'nubhavansthitaḥ |
ciramāvṛttadehātmā bhūcakrabhramaṇaṃ yathā
]

`v 21 [
śrīrāma uvāca |
brahmaṁllokaiḥ purasthasya gacchato yogino nijam |
ātivāhikatāṃ dehaḥ kīdṛśo'yaṃ vilokyate
]

`v 22 [
śrīvasiṣṭha uvāca |
dehāddehāntaraprāptiḥ pūrvadehaṃ vinā sadā |
ātivāhikadehe'sminsvapneṣviva vinaśvarī
]

`v 23 [
yathātape himakaṇaḥ śaradvyomni sito'mbudaḥ |
dṛśyamāno'pyadṛśyatvamityevaṃ yogidehakaḥ
]

`v 24 [
drāgityevāthavā kaścidyogideho na lakṣyate |
yogibhiśca puro vegātproḍḍīna iva khe khagaḥ
]

`v 25 [
svavāsanābhrameṇaiva kvacitkecitkadācana |
mṛto'yamiti paśyanti kecidyoginamagragāḥ
]

`v 26 [
bhrāntimātraṃ tu dehātmā teṣāṃ tadupaśāmyati |
satyabodhena rajjūnāṃ sarpabuddhirivātmani
]

`v 27 [
ko dehaḥ kasya vā sattā kasya nāśaḥ kathaṃ kutaḥ |
sthitaṃ tadeva yadabhūdabodhaḥ kevalaṃ gataḥ
]

`v 28 [
śrīrāma uvāca |
ātivāhikatāmeti ādhibhautika eva kim |
utānya iti me brūhi yenohya iva bhoḥ prabho
]

`v 29 [
śrīvasiṣṭha uvāca |
bahuśo hyuktametatte na gṛhṇāsi kimuttama |
ātivāhika evāsti nāstyevehādhibhautikaḥ
]

`v 30 [
tasyaivābhyasato'pyeti `note[vābhyāsato iti pāṭhaḥ] sādhibhautikatāmatiḥ
|
yadā śāmyati saivāsya tadā pūrvā pravartate
]

`v 31 [
tadā gurutvaṃ kāṭhinyamiti yaśca mudhā grahaḥ |
śāmyetsvapnanarasyeva boddhurbodhānnirāmayāt
]

`v 32 [
laghutūlasamāpattistataḥ samupajāyate |
svapne svapnaparijñānādiva dehasya yoginaḥ
]

`v 33 [
svapne svapnaparijñānādyathā deho laghurbhavet |
tathā bodhādayaṃ dehaḥ sthūlavatplutimānbhavet
]

`v 34 [
anekadinasaṃkalpadehe pariṇatātmanām |
asmindehe śave dagdhe tatraivāsthitimīyuṣām
]

`v 35 [
p. 272) 169
laghudehānubhavanamavaśyaṃ bhāvi vai tathā |
prabodhātiśayādeti jīvatāmapi yoginām
]

`v 36 [
uditāyāṃ smṛtau tatra saṃkalpātmāhamityalam |
yādṛśaḥ sa bhaveddehastādṛśo'yaṃ prabodhataḥ
]

`v 37 [
bhrāntirevamiyaṃ bhāti rajjvāmiva bhujaṅgatā |
kiṃ naṣṭamasyāṃ naṣṭāyāṃ jātāyāṃ kiṃ prajāyate
]

`v 38 [
śrīrāma uvāca |
anantaraṃ ye vāstavyā līlāṃ paśyanti te yadi |
tatsatyasaṃkalpatayā budhyante kimataḥ prabho
]

`v 39 [
śrīvasiṣṭha uvāca |
evaṃ jñāsyanti te rājñī sthiteyamiha duḥkhitā |
vayasyā kācidanyeyaṃ kuto'pyasyā upāgatā
]

`v 40 [
saṃdehaḥ ka ivātraiṣāṃ paśavo hyavivekinaḥ |
yathādṛṣṭaṃ viceṣṭante kuta eṣāṃ vicāraṇā
]

`v 41 [
yathā loṣṭo luṭhadvṛkṣaṃ vañcayitvāśu gacchati |
ajñānatve'japaśavastathā hyasti purādikam
]

`v 42 [
yathā svapnavapurbodhānna jāne kveva gacchati |
asatyameva tadyasmāttathaivehādhibhautikam
]

`v 43 [
śrīrāma uvāca |
bhagavansvapnaśikharī prabodhe kveva gacchati |
iti me saṃśayaṃ chindhi śaradabhramivānilaḥ
]

`v 44 [
śrīvasiṣṭha uvāca |
svapnabhrame'tha saṃkalpe padārthāḥ parvatādayaḥ |
saṃvido'ntarmilantyete spandanānyanile yathā
]

`v 45 [
aspandasya yathā vāyoḥ saspando'ntarviśatyalam |
ananyātmā tathaivāyāṃ svapnārthaḥ saṃvido malam
]

`v 46 [
svapnādyarthāvabhāsena saṃvideva sphuratyalam |
asphurantī tu tenaiva yātyekatvaṃ tadātmikā
]

`v 47 [
saṃvitsvapnārthayordvitvaṃ na kadācana labhyate |
yathā dravatvapayasoryathā vā spandavātayoḥ
]

`v 48 [
yastatra syādivābodhastadajñānamanuttamam |
saiṣā saṃsṛtirityuktā mithyājñānātmikoditā
]

`v 49 [
tatrānyadiva bhāsamānaṃ tu kevalamavidyaiva saiva saṃsāra ityāha - ya iti | 48
|
sahakārikāraṇānāmabhāve kila kīdṛśī |
saṃvitsvapnapadārthānāṃ dvitā svapne nirarthikā
]

`v 50 [
p. 273) 169
yathā svapnastathā jāgradidaṃ nāstyatra saṃśayaḥ |
svapne puramasadbhāti sargādau bhātyasajjagat
]

`v 51 [
nanu tarhi sahakārikāraṇavato jāgratprapañcasya satyatvaṃ prāptaṃ netyāha -
yatheti | sargādāviti | yadyapīdānīṃ sahakāryādayaḥ santi tathāpyādisarge
ajñānopahitahairaṇyagarbhasaṃvidatiriktaṃ nāstīti svapnasāmyamevetyarthaḥ | 50
|
na cārtho bhavituṃ śakyaḥ satyatve svapnatoditaḥ |
saṃvido nityasatyatvaṃ svapnārthānāmasatyatā
]

`v 52 [
jhaṭityeva yathākāśaṃ bhavati svapnaparvataḥ |
krameṇa vā tathā bodhe khaṃ bhavatyādhibhautikam
]

`v 53 [
uḍḍīno'yaṃ mṛto veti paśyanti nikaṭasthitāḥ |
jñamātivāhikībhūtaṃ svasvabhāvahatā yataḥ
]

`v 54 [
mithyādṛṣṭaya evemāḥ sṛṣṭayo mohadṛṣṭayaḥ |
māyāmātradṛśo bhrāntiḥ śūnyāḥ svapnānubhūtayaḥ
]

`v 55 [
svapnānubhūtaya imā maraṇāntabodhe
bhrāntyetarabhramadṛśaḥsphuṭasargabhāsaḥ |
bhāntyātivāhikaśarīragatāḥ samastā
mithyoditā mṛganadīsaraṇakrameṇa
]