`v 1 [
p. 151)
daśamaḥ sargaḥ 10
śrīrāma uvāca |
mahāpralayasaṃpattau yadetadavaśiṣyate |
bhavatyetadanākāraṃ nāma nāstyatra saṃśayaḥ
]

`v 2 [
na śūnyaṃ kathametatsyānna prakāśaḥ kathaṃ bhavet |
kathaṃ vā na tamorūpaṃ kathaṃ vā naiva bhāsvaram
]

`v 3 [
kathaṃ vā naiva cidrūpaṃ jīvo vā na kathaṃ bhavet |
kathaṃ na buddhitattvaṃ syātkathaṃ vā na mano bhavet
]

`v 4 [
kathaṃ vā naiva kiṃcitsyātkathaṃ vā sarvamityapi |
anayaiva vacobhaṅgyā mama moha ivoditaḥ
]

`v 5 [
śrīvasiṣṭha uvāca |
viṣamo'yamatipraśno bhavatā samudāhṛtaḥ |
bhettāsmyahaṃ tvayatnena naiśaṃ tama ivāṃśumān
]

`v 6 [
mahākalpāntasaṃpattau yattatsadavaśiṣyate |
tadrāma na yathā śūnyaṃ tadidaṃ śṛṇu kathyate
]

`v 7 [
anutkīrṇā yathā stambhe saṃsthitā śālabhañjikā |
tathā viśvaṃ sthitaṃ tatra tena śūnyaṃ na tatpadam
]

`v 8 [
ayamitthaṃ mahābhogo jagadākhyo'vabhāsate |
satyo bhavatvasatyo vā yatra tatra tvaśūnyatā
]

`v 9 [
yathā na putrikāśūnyaḥ stambho'nutkīrṇaputrikaḥ |
tathā bhātaṃ `note[māsaṃ iti pāṭhaḥ] jagadbrahma tena śūnyaṃ na
tatpadam
]

`v 10 [
saumyāmbhasi yathā vīcirna cāsti naca nāsti ca |
tathā jagadbrahmaṇīdaṃ śūnyāśūnyapadaṃ gatam
]

`v 11 [
deśakālādi śāntatvātputrikāracanaṃ drume |
saṃbhavatyayathā'to vai tenānante vimuhyate
]

`v 12 [
tatstambhaputrikādyetatparamārthe jagatsthiteḥ |
ekadeśena sadṛśamupamānaṃ na sarvathā `note[sarvataḥ iti pāṭhaḥ] |
12 |
yadyuktarītyā vaiṣamyaṃ kathaṃ tarhi stambhaputrikādṛṣṭāntastatrāha -
taditi | tadetatprāguktaṃ stambhaputrikādi paramārthe brahmaṇi ekadeśena
tatsattānucchedāṃśena `note[tatsata ādhārasattānucchedāṃśena iti pāṭhaḥ]
]

`v 13 [
na kadācidudetīdaṃ parasmānna ca śāmyati |
itthaṃ sthitaṃ kevalaṃ sadbrahma svātmani saṃsthitam
]

`v 14 [
aśūnyāpekṣayā śūnyaśabdārthaparikalpanā |
aśūnyatvātsaṃbhavataḥ śūnyatāśūnyate kutaḥ
]

`v 15 [
p. 152)
brahmaṇyayaṃ prakāśo hi na saṃbhavati bhūtajaḥ |
sūryānalendutārādiḥ kutastatra kilāvyaye
]

`v 16 [
mahābhūtaprakāśānāmabhāvastama ucyate |
mahābhūtābhāvajaṃ tu tenātra na tamaḥ kvacit
]

`v 17 [
svānubhūtiḥ prakāśo'sya `note[prakāśo'yaṃ iti pāṭhaḥ] kevalaṃ
vyomarūpiṇaḥ |
yo'ntarasti sa tenaiva natvanyenānubhūyate
]

`v 18 [
muktaṃ tamaḥprakāśābhyāmityetadajaraṃ padam |
ākāśakośamevedaṃ viddhi kośaṃ jagatsthiteḥ
]

`v 19 [
bilvasya bilvamadhyasya yathā bhedo na kaścana |
tathāsti brahmajagatorna manāgapi bhinnatā
]

`v 20 [
salilāntaryathā vīcirmṛdantarghaṭako `note[rmṛdontaḥ iti mudritapustake
pāṭhaḥ] yathā |
tathā yatra jagatsattā tatkathaṃ khātmakaṃ bhavet
]

`v 21 [
bhūrjalādyupamānaśrīḥ sākārāntā samānasā |
brahma tvākāśaviśadaṃ tasyāntasthaṃ tathaiva tat
]

`v 22 [
tasmādyādṛkcidākāśamākāśādapi nirmalam |
tadantasthaṃ tādṛgeva jagacchabdārthabhāgapi
]

`v 23 [
marīce'ntaryathā taikṣṇyamṛte bhokturna lakṣyate |
cinmātratvaṃ cidākāśe tathā cetyakalāṃ vinā
]

`v 24 [
tasmāccidapyacidrūpaṃ cetyariktaṃ tadātmani |
jagattā tādṛgeveyaṃ tāvanmātrātmatāvaśāt `note[tādṛṅmātra iti
pāṭhaḥ]
]

`v 25 [
rūpālokamanaskārāstanmayā eva netarat |
yathāsthitamato viśvaṃ suṣuptaṃ turyameva vā
]

`v 26 [
vakṣyamāṇāsu saptasu pañcamyantabhūmikāgatānāṃ suṣuptamuttarayosturyam |
25 |
tena yogī suṣuptātmā vyavahāryapi śāntadhīḥ |
āste brahma nirābhāsaṃ sarvābhāsasamudgakaḥ
]

`v 27 [
ākāriṇi yathā saumye sthitāstoye mahormayaḥ |
anākṛtau tathā viśvaṃ sthitaṃ tatsadṛśaṃ pare
]

`v 28 [
pūrṇātpūrṇaṃ prasarati yattatpūrṇaṃ nirākṛti |
brahmaṇo viśvamābhātaṃ `note[viśvabhānaṃ tattaddhi svārthaṃ iti
pāṭhaḥ] taddhi svārthaṃ vicakṣitam
]

`v 29 [
pūrṇātpūrnaṃ prasarati saṃsthitaṃ pūrṇameva tat |
ato viśvamanutpannaṃ yaccotpannaṃ tadeva tat
]

`v 30 [
cetyāsaṃbhavatastasminyadekā jagadarthatā |
āsvādakā saṃbhavato marīce kaiva tīkṣṇatā
]

`v 31 [
p. 153)
satyeveyamasatyaiṣa cittacetyāditā pare |
tadbhāvātpratibimbasya pratibimbārhatā kutaḥ
]

`v 32 [
paramāṇorapi paraṃ tadaṇīyo hyaṇīyasaḥ |
śuddhaṃ sūkṣmaṃ paraṃ śāntaṃ tadākāśodarādapi
]

`v 33 [
dikkālādyanavacchinnarūpatvādativistṛtam |
tadanādyantamābhāsaṃ bhāsanīyavivarjitam
]

`v 34 [
cidrūpameva no yatra labhyate tatra jīvatā |
kathaṃ syāccittatākārā vāsanā nityarūpiṇī `note['nilarūpiṇī iti pāṭhaḥ]
]

`v 35 [
cidrūpānudayādeva tatra nāstyeva jīvatā |
na buddhitā cittatā vā nendriyatvaṃ na vāsanā
]

`v 36 [
evamitthaṃ mahārambhapūrṇamapyajaraṃ padam |
asmaddṛṣṭyā sthitaṃ śāntaṃ śūnyamākāśato'dhikam
]

`v 37 [
śrīrāma uvāca |
paramārthasya kiṃ rūpaṃ tasyānantacidākṛteḥ |
punaretanmamācakṣva nipuṇaṃ bodhavṛddhaye
]

`v 38 [
evaṃ samāhite cetasi yena rūpeṇa tadaparokṣamanubhavituṃ śakyaṃ
tadasādhāraṇaṃ rūpaṃ paricetukāmaḥ punaḥ pṛcchati - paramārthasyeti |
37 |
śrīvasiṣṭha uvāca |
mahāpralayasaṃpattau sarvakāraṇakāraṇam |
śiṣyate paramaṃ brahma tadidaṃ varṇyate śṛṇu
]

`v 39 [
nāśayitvā svamātmānaṃ manaso vṛttisaṃkṣaye |
sadrūpaṃ yadanākhyeyaṃ tadrūpaṃ tasya vastunaḥ
]

`v 40 [
nāsti dṛśyaṃ jagaddraṣṭā dṛśyābhāvādvilīnavat |
bhātīti bhāsanaṃ yatsyāttadrūpaṃ tasya vastunaḥ
]

`v 41 [
citerjīvasvabhāvāyā yadacetyonmukhaṃ vapuḥ |
cinmātraṃ vimalaṃ śāntaṃ tadrūpaṃ paramātmanaḥ
]

`v 42 [
aṅgalagne'pi vātādau sparśādyanubhavaṃ vinā |
jīvataścetaso rūpaṃ yattadvai paramātmanaḥ
]

`v 43 [
asvapnāyā anantāyā ajaḍāyā manaḥsthiteḥ |
yadrūpaṃ ciranidrāyāstattadānagha śiṣyate
]

`v 44 [
yadvyomno hṛdayaṃ yadvā śilāyāḥ pavanasya ca |
tasyācetyasya cidvyomnastadrūpaṃ paramātmanaḥ
]

`v 45 [
vyomno hṛdayaṃ rahasyaṃ śūnyatvaṃ pavanasya
hṛdayamantarbahiḥpūrṇatvaṃ śilāyāstu ghanatvaṃ tasyaivācetyasya
cetyabhinnasya cetyarahitasya ca cidvyomnaḥ sato yadrūpaṃ bhavettattadityarthaḥ | 44
|
acetyasyāmanaskasya jīvato yā svabhāvataḥ |
syātsthitiḥ sā parā śāntā sattā tasyādyavastunaḥ
]

`v 46 [
citprakāśasya yanmadhyaṃ prakāśasyāpi khasya vā |
darśanasya ca yanmadhyaṃ tadrūpaṃ brahmaṇo viduḥ
]

`v 47 [
p. 154)
vedanasya prakāśasya dṛśyasya tamasastathā |
vedanaṃ yadanādyantaṃ tadrūpaṃ paramātmanaḥ
]

`v 48 [
yato jagadudetīva nityānuditarūpyapi |
vibhinnavadivābhinnaṃ tadrūpaṃ paramārthakam
]

`v 49 [
vyavahāraparasyāpi yatpāṣāṇavadāsanam |
avyomna eva vyomatvaṃ tadrūpaṃ paramātmanaḥ
]

`v 50 [
vedyavedanaveṭtṛtvarūpatrayamidaṃ puraḥ |
yatrodetyastamāyāti tattatparamadurlabham
]

`v 51 [
vedyavedanavettṛtvaṃ yatredaṃ pratibimbati |
abuddhyādau mahādarśe tadrūpaṃ paramaṃ smṛtam
]

`v 52 [
manaḥ svapnendriyairmuktaṃ yadrūpaṃ syānmahāciteḥ |
jaṅgame sthāvare vāpi tatsarvānte'vaśiṣyate
]

`v 53 [
sthāvarāṇāṃ hi yadrūpaṃ taccedbodhamayaṃ bhavet |
manobuddhyādinirmuktaṃ tatpareṇopamīyate
]

`v 54 [
brahmārkaviṣṇuharaśakrasadāśivādi
śāntau śivaṃ paramametadihaikamāste |
sarvopadhivyayavaśādavikalparūpaṃ
caitanyamātramayamujjhitaviśvasaṅgam
]