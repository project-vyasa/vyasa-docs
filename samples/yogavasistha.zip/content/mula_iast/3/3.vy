`v 1 [
tṛtīyaḥ sargaḥ 3
śrīrāma uvāca |
evameva manaḥ śuddhaṃ pṛthvyādirahitaṃ tvayā |
mano brahmeti kathitaṃ satyaṃ pṛthvyādivarjitam
]

`v 2 [
tadatra prāktanī brahmansmṛtiḥ kasmānna kāraṇam |
yathā mama tavānyasya bhūtānāṃ ceti me vada
]

`v 3 [
śrīvasiṣṭha uvāca |
pūrvadeho'sti yasyādya pūrvakarmasamanvitaḥ |
tasya smṛtiḥ saṃbhavati kāraṇaṃ saṃsṛtisthiteḥ
]

`v 4 [
p. 134)
brahmaṇaḥ prāktanaṃ karma yadā kiṃcinna vidyate |
prāktanī saṃsmṛtistasya tadodeti kutaḥ katham
]

`v 5 [
tasmādakāraṇa bhāti vā svacittaikakāraṇam |
svakāraṇādananyātmā svayaṃbhūḥ svayamātmavān
]

`v 6 [
ātivāhika evāsau deho'styasya svayaṃbhuvaḥ |
na tvādhibhautiko rāma deho'jasyopapadyate
]

`v 7 [
śrīrāma uvāca |
ātivāhika eko'sti deho'nyastvādhibhautikaḥ |
sarvāsāṃ bhūtajātīnāṃ brahmaṇo'styeka eva kim
]

`v 8 [
śrīvasiṣṭha uvāca |
sarveṣāmeva dehau dvau bhūtānāṃ kāraṇātmanām |
ajasya kāraṇābhāvādeka evātivāhikaḥ
]

`v 9 [
sarvāsāṃ bhūtajātīnāmeko'jaḥ kāraṇaṃ param |
ajasya kāraṇaṃ nāsti tenāsāvekadehavān
]

`v 10 [
nāstyeva bhautiko dehaḥ prathamasya prajāpateḥ |
ākāśātmā ca bhātyeṣa ātivāhikadehavān
]

`v 11 [
ākāśātmā cidākāśamātrarūpaḥ | āropitasyādhiṣṭhānātiriktasvarūpābhāvāt |
10 |
cittamātraśarīro'sau na pṛthvyādikramātmakaḥ |
ādyaḥ prajāpatirvyomavapuḥ pratanute prajāḥ
]

`v 12 [
tāśca vidvyomarūpiṇyo vinānyaiḥ kāraṇāntaraiḥ |
yadyatastattadevati sarvairevānubhūyate
]

`v 13 [
nirvāṇamātraṃ puruṣaḥ paro bodhaḥ sa eva ca |
cittamātraṃ tadevāste nāyāti vasudhāditām
]

`v 14 [
sarveṣāṃ bhūtajātānāṃ saṃsāravyavahāriṇām |
prathamo'sau pratispandaścittadehaḥ svatodayaḥ
]

`v 15 [
asmātpūrvātpratispandādananyaitatsvarūpiṇī |
iyaṃ pravisṛtā sṛṣṭiḥ spandasṛṣṭirivānilāt
]

`v 16 [
pratibhānākṛterasmātpratibhāmātrarūpadhṛk |
vibhātyevamayaṃ sargaḥ satyānubhavavānsthitaḥ
]

`v 17 [
dṛṣṭānto'tra bhavatsvapnapurastrīsurataṃ `note[svapnasvapnastrī iti
mudritapustake pāṭhaḥ] yathā |
asadapyarthasaṃpattyā satyānubhavabhāsuram
]

`v 18 [
apṛthvyādimayo bhāti vyomākṛtiradehakaḥ |
sadeha iva bhūteśaḥ svātmabhūḥ puruṣākṛtiḥ
]

`v 19 [
saṃvitsaṃkalparūpatvānnodeti samudeti ca |
svāyattatvātsvabhāvasya nodeti na ca śāmyati
]

`v 20 [
nodeti paramārthataḥ samudeti bhrāntyā tatrādyamupapādayati - svāyattatvāditi
| jagadbhāvavadavidyādyadhīnatvābhāvāditi bhāvaḥ | svabhāvasya svarūpasthiteḥ |
19 |
brahmā saṃkalpapuruṣaḥ pṛthvyādirahitākṛtiḥ |
kevalaṃ cittamātrātmā kāraṇaṃ trijagatsthiteḥ
]

`v 21 [
saṃkalpa eṣa kacati yathā nāma svayaṃbhuvaḥ |
vyomātmaiṣa tathā bhāti bhavatsaṃkalpaśailavat
]

`v 22 [
ātivāhikamevāntarvismṛtyā dṛḍharūpayā |
ādhibhautikabodhena mudhā bhāti piśācavat
]

`v 23 [
tarhi kathaṃ sarveṣāṃ
saṃkalpaśailavilakṣaṇādhibhautikatvārthakriyāsāmarthyādyanubhavastatrāha ##-
p. 135)
idaṃ prathamatodyogasaṃprabuddhaṃ mahāciteḥ |
nodeti śuddhasaṃvittvādātivāhikavismṛtiḥ
]

`v 24 [
ādhibhautikajātena nāsyodeti paśācikā |
asatyā mṛgatṛṣṇeva mithyā jāḍyabhramapradā
]

`v 25 [
manomātraṃ yadā `note[yathā brahmā iti pāṭhaḥ] brahmā na
pṛthvyādimayātmakaḥ |
manomātramato viśvaṃ yadyajjātaṃ tadeva hi
]

`v 26 [
ajasya sahakārīṇi kāraṇāni na santi yat |
tajjasyāpi na santyeva tāni tasmāttu kānicit
]

`v 27 [
kāraṇātkāryavaicitryaṃ tena nātrāsti kiṃcana |
yādṛśaṃ kāraṇaṃ śuddhaṃ kāryaṃ tādṛgiti sthitam
]

`v 28 [
kāryakāraṇatā hyatra na kiṃcidupapadyate |
yādṛgeva paraṃ brahma tādṛgeva jagattrayam
]

`v 29 [
manastāmiva yātena brahmaṇā tanyate jagat |
ananyādātmanaḥ `note[ananyat iti pāṭhaḥ] śuddhāddravatvamiva
vāriṇaḥ
]

`v 30 [
manasā tanyate sarvamasadevedamātatam |
yathā saṃkalpanagaraṃ yathā gandharvapattanam
]

`v 31 [
ādhibhautikatā nāsti rajjvāmiva bhujaṅgatā |
brahmādayaḥ prabuddhāstu kathaṃ tiṣṭhanti tatra te
]

`v 32 [
ātivāhika evāsti na prabuddhamateḥ kila |
ādhibhautikadehasya vāco `note[caracaivātra iti pāṭhaḥ] vātra kutaḥ
katham
]

`v 33 [
manonāmno manuṣyasya viriñcayākāradhāriṇaḥ |
manorājyaṃ jagaditi satyarūpamiva sthitam
]

`v 34 [
mana eva viriñcitvaṃ taddhi saṃkalpanātmakam |
svavapuḥ sphāratāṃ nītvā manasedaṃ vitanyate
]

`v 35 [
viriñco manaso rūpaṃ viriñcasya mano vapuḥ |
pṛthvyādi vidyate nātra tena pṛthvyādi kalpitam
]

`v 36 [
padmākṣe padminīvāntarmano hṛdyasti dṛśyatā |
manodṛśyadṛśau bhinne na kadācana kenacit
]

`v 37 [
yathā cātra tava svapnaḥ saṃkalpaścittarājyadhīḥ |
svānubhūtyaiva dṛṣṭāntastasmāddhṛdyasti dṛśyabhūḥ
]

`v 38 [
tasmāccittavikalpasthapiśāco bālakaṃ yathā |
vinihantyevameṣāntardraṣṭāraṃ dṛśyarūpikā
]

`v 39 [
yathāṅkuro'ntarbījasya saṃsthito deśakālataḥ |
karoti bhāsuraṃ dehaṃ tanotyevaṃ hi dṛśyadhīḥ
]

`v 40 [
saccenna śāmyati kadācana dṛśyaduḥkhaṃ
dṛśye tvaśāmyati na boddhari kevalatvam |
dṛśye tvasaṃbhavati boddhari boddhṛbhāvaḥ
śāmyetsthito'pi hi tadasya vimokṣamāhuḥ
]