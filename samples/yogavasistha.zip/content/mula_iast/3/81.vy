`v 1 [
p. 324) 196
ekāśītitamaḥ sargaḥ 81
rākṣasyuvāca |
aho nu paramārthoktiḥ pāvanī tava mantriṇaḥ |
rājā rājīvapatrākṣa idānīmeṣa bhāṣatām
]

`v 2 [
rājovāca |
jāgatapratyayābhāvo yasyāhuḥ pratyayaṃ param |
sarvasaṃkalpasaṃnyāsaścetasā yatparigrahaḥ
]

`v 3 [
yatsaṃkocavikāsābhyāṃ jagatpralayasṛṣṭayaḥ |
niṣṭhā vedāntavākyānāmatha vācāmagocaraḥ
]

`v 4 [
koṭidvayāntarālasthaṃ madhye koṭidvayīmayam |
yasya cittamayī līlā jagadetaccarācaram
]

`v 5 [
yasya viśvātmakatve'pi khaṇḍyate naikapiṇḍatā |
sanmātraṃ tattvayā bhadre kathyate brahma śāśvatam
]

`v 6 [
eṣo'ṇurvedanādvāyuḥ svabhrāntirdṛgadṛśyata
`note[bhrāntidṛgadṛśyata iti pāṭhaḥ sādhuḥ] |
ato na kiṃcidvāyvādi kevalaṃ śuddhacetanam
]

`v 7 [
śabdasaṃvedanācchabdaḥ śabdasya bhrāntidarśanam |
tato'tra śabdaśabdārthadṛṣṭerdūrataraṃ gataḥ
]

`v 8 [
so'ṇuḥ sarvaṃ na kiṃcicca so'haṃ nāhaṃ sa eva ca |
sarvaśakyātmano'syaiva pratibhaikātra kāraṇam
]

`v 9 [
ātmā yatnaśataprāpyo labdhe'sminna ca kiṃcana |
labdhaṃ bhavati taccaitatparamaṃ vā na kiṃcana
]

`v 10 [
tāvajjanma vasanteṣu saṃsṛtivratatiściram |
vikasatyudito yāvanna bodho mūlakāṣakṛt
]

`v 11 [
aṇunānena rūpatvaṃ dṛśyatāmiva gacchatā |
tāpenāmbudhiyevedaṃ svasthenaivāpahāritam
]

`v 12 [
anena saṃvidaṇunā merustribhuvanaṃ tṛṇam |
vamitvā bahirantasthaṃ māyātmakamavekṣyate
]

`v 13 [
cidaṇorantare yadyadasti taddṛśyate bahiḥ |
saṃkalpeṣṭāliṅganadidṛṣṭānto'tra `note[saṃkalpeṣvāliṅganādi iti
pāṭhaḥ] hi rāgiṇaḥ
]

`v 14 [
p. 325) 196
ādisarge sarvaśaktiścidyathaivoditātmanā |
tathāśu paśyatyakhilaṃ saṃkalpe parvataḥ svataḥ
]

`v 15 [
abhijātasya yasyāntaryadyathā pratibhāsate |
tattathā paśyatīvāsau dṛṣṭānto'tra śośormanaḥ
]

`v 16 [
abhijātasya āvirbhūtacittasya ca
]

`v 17 [
aṇureva na mātyeṣa yojanānāṃ śateṣvapi |
sarvagatvādanāditvādarūpatvādanākṛtiḥ
]

`v 18 [
yathā dūrtena khḍgena `note[khiṅgena iti pāṭhaḥ] puṃsā bālaḥ
pratāryate |
subhrūvikāranayananirīkṣaṇaviceṣṭitaiḥ
]

`v 19 [
cidālokena śuddhena saparvatatṛṇaṃ jagat |
nāṭyate'virataṃ tadvadvivṛttyābhinayaṃ sadā
]

`v 20 [
tenaivānantarūpatvādaṇunā vāsasā yathā |
saṃvidā `note[saṃvidantarbhavadbāhye iti pāṭhaḥ sādhuḥ]
tadbhavadbāhye kṛtvā mervādiveṣṭitam
]

`v 21 [
kasyāṇorudare santi kilāvanibhṛtāṃ ghaṭāḥ ityetatpratyāha - teneti | yathā
vāsasā svāntarbhavanmervādicitraṃ bāhya iva kṛtvā veṣṭitaṃ tadvadityarthaḥ |
20 |
dikkālādyanavacchinnarūpatvānmeruto bṛhat |
vālāgraśatabhāgātmāpyeṣa sūkṣmaḥ paro'nukaḥ
]

`v 22 [
śuddhasaṃvedanākāśarūpasya paramāṇunā |
śobhate nahi sāmyoktirmerusarṣapayoriva
]

`v 23 [
māyākalāpināṇutvaṃ nirmāya paramātmani |
hemnīva kaṭakatvena nānātra samatā bhavet
]

`v 24 [
prakaṭo'nena dīpena prakāśo'nubhavātmanā |
svasattānāśapūrvo hi vinānena bhavettataḥ
]

`v 25 [
yadi sūryādikaṃ sarvaṃ jagadekaṃ jaḍaṃ bhavet |
tataḥ kimātmakaṃ rūpaṃ prakāśaḥ syātkva vātha kim
]

`v 26 [
śuddhasanmātracittvaṃ yatsvataḥ svātmani saṃsthitam |
tadetadaṇunā tejo dṛṣṭaṃ bahiravasthitam
]

`v 27 [
tejāṃsyarkenduvahnīnāṃ na bhinnāni tamoghanāt |
etāvāneva bhedo'sti yadvarṇe śauklyakṛṣṇate
]

`v 28 [
nanu arkendvādibhireva prakāśasiddheḥ kiṃ cidaṇunā tatrāha - tejāṃsīti |
tamoghanāt svakāraṇājñānāt | etāvāniti | jāḍhyāṃśe tu na bheda ityāśayaḥ |
27 |
yādṛkkajjalanīhāre meghanīhārayorbhavet |
tādṛkprakāśatamasorbhedo neti tayoḥ sthitiḥ
]

`v 29 [
jaḍayorupalambhāya cidādityaḥ kilaitayoḥ |
yadā tapati tenaite labdhasattaikatāṃ gate
]

`v 30 [
tapatyekaścidādityo rātriṃdivamatandritaḥ |
antarbahiḥ śilādyantarapyanastamayodayaḥ
]

`v 31 [
trilokī bhāti teneyaṃ jīvasya prathitātmanaḥ |
nānopalambhabhāṇḍāḍhyā kuṭī kaṭhinakoṭarā
]

`v 32 [
p. 326) 197
tamastvaṃ tamaso dehamavināśayatāmunā |
tapyate'bhāsayā bhāsā sarvamābhāsyate tamaḥ
]

`v 33 [
padmotpale yathārkeṇa tapatā prakaṭīkṛte |
prakāśatamaso satte citaivaṃ prakaṭīkṛte
]

`v 34 [
arkaḥ kurvannahorātre darśayatyākṛtiṃ yathā |
citiḥ sadasatī kṛtvā darśayatyākṛtiṃ tathā
]

`v 35 [
cidaṇorantare santi samagrānubhavāṇavaḥ |
yathā madhurasasyāntaḥ puṣpapatraphalaśriyaḥ
]

`v 36 [
udyanti cidaṇorete samagrānubhavāṇavaḥ |
madhumāsarasāccitrā iva khaṇḍaparamparāḥ
]

`v 37 [
paramātmāṇuratyantaniḥsvāduḥ sūkṣmatāvaśāt |
samagrasvādusattaikajanakaḥ svadate svayam
]

`v 38 [
ko'ṇuratyantanisvādurapi saṃsvadate'niśam ityasyottaramāha - paramātmeti | 37
|
yo yo nāma rasaḥ kaścitsamasto'pyapsvavasthitaḥ |
pratibimbamivādarśe taṃ vinā nāstyasau svataḥ
]

`v 39 [
tyajatā saṃsthitaṃ sarvaṃ cinmātraparamāṇunā |
tyaktaṃ jagadasaṃvittyā saṃvittyā sarvamāśritam
]

`v 40 [
aśaktayā svātmaguptau sarvamācchāditaṃ jagat |
cittāṇutāmeva `note[citāṇutāṃ iti pāṭhaḥ] parāṃ saṃprasārya vitānavat
]

`v 41 [
ātmaguptau na śaknoti paramātmāmbarākṛtiḥ |
manāgapi kṣaṇamapi gajo dūrvāvane yathā
]

`v 42 [
tathāpyākrāntavānviśvaṃ jñāto gopāyati kṣaṇāt |
jagaddhānākaṇaṃ bāla ivāho ghanamāyitā
]

`v 43 [
jagat jagadantaḥpātijīvajātaṃ jñātaḥ san svātmalābhena gopāyati rakṣati yathā
bālo jñātaḥ prabuddhaḥ san dhānākaṇaṃ gopāyati na suptastadvat |
nanvīdṛśasvaprakāśapūrṇātmanaḥ kathaṃ bālavat svātmavismṛtistatrāha ##-
cinmātrānunayenedaṃ jagatsannapi jīvati |
vasantarasabodhena vicitreva vanāvalī
]

`v 44 [
cittasattaivamakhilaṃ svato jagadivoditam |
madhumāsarasollāsāccitro hi vanakhaṇḍakaḥ
]

`v 45 [
satyaṃ cinmayamevedaṃ jagadityeva viddhyalam |
vasantarasameva tvaṃ viddhi pallavagulmakam
]

`v 46 [
sarvāvayavisāratvātsahasrakaralocanaḥ |
paramāṇurasāveva nityānavayavodayaḥ
]

`v 47 [
nimeṣāṃśāvabodho hi cidaṇoḥ pratibhāsate |
yataḥ kalpasahasraughaḥ svapne vārdhakabālyavat
]

`v 48 [
tataḥ so'pi nimeṣoṇuḥ kalpakoṭiśatānyalam |
sarvasattāvilāsena pratibhaikā vijṛmbhate
]

`v 49 [
abhuktavatyeva yathā bhuktavānahamityalam |
jāyate pratyayastadvannimeṣe kalpaniścayaḥ
]

`v 50 [
abhuktvā bhuktavānasmītyevaṃ pratyayaśālinaḥ |
dṛśyante vāsanāviṣṭāḥ `note[vāsanāniṣṭhā iti pāṭhaḥ] svapne
svamaraṇaṃ yathā
]

`v 51 [
jaganti paritiṣṭhanti paramāṇau cidātmani |
pratibhāsāḥ pravartante tata eva hi jāgatāḥ
]

`v 52 [
yadasti yatra tattasmātsamudeti tadeva tat |
ākāriṇi vikārādi dṛṣṭaṃ na gagane'male
]

`v 53 [
p. 327) 197
citi bhūtāni bhūtāni vartamānāni saṃprati |
bhaviṣyanti ca bhūtāni santi bīje drumā iva
]

`v 54 [
nimeṣakalpāvetena tuṣeṇānnakaṇāviva |
valitā veṣacetyābhyāmaṇuḥ svātmāṅgakaṃ śritaḥ
]

`v 55 [
udāsīnavadāsīno na saṃspṛṣṭo manāgapi |
eṣa bhoktṛtvakartṛtvaiḥ svātmā sarvajagatyapi
]

`v 56 [
jagatsattodite yaṃ hi śuddhacitparamāṇutaḥ |
paramāṇośca bhoktṛtvakartṛtve kevalaṃ sthite
]

`v 57 [
jaganna kiṃcitkriyate sarvadaiva na kenacit |
vilīyate ca no kiṃcinmānuṣyāddṛśyakhaṇḍanam
]

`v 58 [
sarvaṃ samasamābhāsamidamākāśakośakam |
jagattayopaśabdaṃ ca viddhyanādyaṃ niśācari
]

`v 59 [
cidaṇurdṛśyasiddhyarthamāntarīṃ ciccamatkṛtim |
bahīrūpatayā dhatte svātmani parisaṃsthitām
]

`v 60 [
etadbahiṣṭhamantasthamasti śabde na vastuni |
upadeśāya sattvānāṃ cidrūpatvājjagattraye
]

`v 61 [
draṣṭā'dṛṣṭapadaṃ gacchannātmanāṃ saṃprapaśyati |
netradṛśyābhipātīva sadevāsadiva sthitam
]

`v 62 [
naca gacchati dṛśyatvaṃ draṣṭā hyasadavāstavam |
āmtanyeva na yatkiṃcittattāmeti kathaṃ paraḥ
]

`v 63 [
dṛgeva locane sā ca vāsanāntaṃ nijaṃ vapuḥ |
bahīrūpatayā dṛśyaṃ kṛtvā draṣṭṛtayoditā
]

`v 64 [
na vinā draṣṭṛtāmasti dṛśyasattā kathaṃcana |
pitṛteva vinā putraṃ dvitevaikyapadaṃ vinā
]

`v 65 [
draṣṭaiva dṛśyatāmeti na draṣṭṛtvaṃ vināsti tat |
vinā pitreva tanayo vinā bhokreva bhogyatā
]

`v 66 [
draṣṭurdṛśyavinirmāṇe cittvādastyeva śaktatā |
kanakasyāvadātasya kaṭakādikṛtāviva
]

`v 67 [
dṛśyasya draṣṭṛnirmāṇe jaḍatvānnāsti śaktatā |
kaṭakasya tu haimasya yathā kanakanirmitau
]

`v 68 [
cetanādṛśyanirmāṇaṃ citkarotyasadeva sat |
akāraṇaṃ mohahetuṃ hemeva kaṭakabhramam
]

`v 69 [
kaṭakatvāvabhāse hi yathā hemno na hematā |
satyeva prakacatyevaṃ draṣṭṛdṛśyasthitau vapuḥ
]

`v 70 [
draṣṭā dṛśyatayā tiṣṭhandraṣṭṛtāmupajīvati |
satyāṃ kaṭakasaṃvittau hema kāñcanatāmiva
]

`v 71 [
p. 328) 198
ekasminpratibhāse hi na sattā draṣṭṛdṛśyayoḥ |
puṃpratyayaprakacane kva paśupratyayodayaḥ
]

`v 72 [
dṛśyaṃ paśyansvamātmānaṃ na draṣṭā saṃprapaśyati |
draṣṭurhi dṛśyatāpattau sattā'satteva tiṣṭhati
]

`v 73 [
bodhādgalitadṛśyasya draṣṭuḥ satteva bhāsate |
abuddhe kaṭake svasya hemno'kaṭakatā yathā
]

`v 74 [
dṛśye satyasti vai draṣṭā dṛśyaṃ draṣṭari bhāsate |
dvayena ca vinā naikaṃ naikamapyasti cānayoḥ
]

`v 75 [
sarvaṃ yathāvadvijñāya śuddhasaṃvinmayātmanā |
vācāmaviṣayaṃ svacchaṃ kiṃcidevāvaśiṣyate
]

`v 76 [
ātmānaṃ darśanaṃ dṛśyaṃ dīpenevāvabhāsitam |
kṛtaṃ ca sarvametena cinmātraparamāṇunā
]

`v 77 [
mātṛmānaprameyākhyaṃ budho nigirati trayam |
hemeva kaṭakāditvamasanmayamupasthitam
]

`v 78 [
yathā na jalabhūmyādeḥ pṛthakkiṃcinmanāgapi |
tathaitasmātsvabhāvāṇorna kiṃcitpṛthagasti hi
]

`v 79 [
sarvagānubhavātmatvātsarvānubhavarūpataḥ |
ekatvānubhavanyāye rūḍhe sarvaikatāsya hi
]

`v 80 [
asyecchayā pṛthaṅgāsti vīciteva mahāmbhasaḥ |
icchānurūpasaṃpatterbhāvitārthaikatā kila
]

`v 81 [
dikkālādyanavacchinnaḥ paramātmāsti kevalaḥ |
sarvātmatvātsa sarvātmā sarvānubhavataḥ svataḥ
]

`v 82 [
sanneṣa cetanātmatvāddarśanānavabodhataḥ |
dvaitaikye nātra vidyete sarvarūpe mahātmani
]

`v 83 [
yadi kaściddvitīyaḥ syāttadaikasyaikatā bhavet |
dvaitaikyayormithaḥ siddhirātapacchāyayoriva
]

`v 84 [
yatra nāsti dvitīyo hi tatraikasyaikatā katham |
ekatāyāmasiddhāyāṃ dvayameva na vidyate
]

`v 85 [
evaṃ sthite tu yastiṣṭhaṃstattādṛktadivāsti hi |
tasmānna vyatiriktaṃ tadrūpaṃ drava ivāmbhasaḥ
]

`v 86 [
nānārambhavibhāsaṃ `note[vināśaṃ ca iti pāṭhaḥ] ca
sāmyenākṣubdharūpiṇaḥ |
bījasyāntastaruriva brahmaṇo'ntaḥ sthitaṃ jagat
]

`v 87 [
dvaitamapyapṛthaktasmāddhemnaḥ kaṭakatā yathā |
samyagbuddhāvabodho hi dvaitaṃ tacca na sanmayam
]

`v 88 [
yathā dravatvaṃ payasaḥ spandanaṃ mātariśvanaḥ |
vyomnaḥ śūnyatvamevaṃ hi na pṛthagdvaitamīśvarāt
]

`v 89 [
p. 329) 198
dvaitādvaitopalambho hi duḥkhāyaiva kriyātmane |
nipuṇo'nupalambho yastvetayostatparaṃ viduḥ
]

`v 90 [
mātṛmānaprameyādidraṣṭṛdarśanadṛśyatā |
etāvajjagadetacca paramāṇau citi sthitam
]

`v 91 [
ayaṃ jagadaṇurnityametenāṇusumeruṇā |
spandanaṃ pavaneneva svāṅga eva kṛtākṛtaḥ
]

`v 92 [
aho nu bhīmā māyeyamathavā māyināṃ parā |
paramāṇvantarevāsti yattrailokyaparamparā
]

`v 93 [
athāsaṃbhavamāyitvamevaitatsarvadā sthitam |
cinmātraparamāṇutvamātrameva jagatsthitiḥ
]

`v 94 [
antargatajagajjālo'pyeṣo'ṇuḥ sāmyamatyajan |
sthito'ntasthabṛhadvṛkṣaṃ bījaṃ bhāṇḍodare yathā
]

`v 95 [
bīje'ntarvṛkṣavistāraḥ sthitaḥ saphalapallavaḥ |
parayā dṛśyate dṛṣṭyā jagacca cidaṇūdare
]

`v 96 [
sa śākhāphalapuṣpaṃ svamajahadbījakoṭare |
yathā taruḥ sthitastadvadvikāsi cidaṇorjagat
]

`v 97 [
saṃsthitaṃ dvaitamadvaitaṃ bījakośa iva drumaḥ |
jagaccitparamāṇvantaryaḥ paśyati sa paśyati
]

`v 98 [
na dvaitaṃ naiva cādvaitaṃ na ca bījaṃ na cāṅkuraḥ |
na sthūlaṃ na ca vā sūkṣmaṃ nājātaṃ jātameva ca
]

`v 99 [
na cāsti na ca nāstīdaṃ na saumyaṃ kṣubhitaṃ na ca |
trijagaccidaṇorantaḥ khavāyvapi na kiṃcana
]

`v 100 [
na jagannājagaccāsti vidyate citparā śubhā |
sarvātmikā yadā yatra sā yathodeti tattathā
]

`v 101 [
udetyanudito'pyeṣa svayaṃvedanajṛmbhitaḥ |
paramātmāṇurekātmā samagrātmatayaiva khe
]

`v 102 [
drumo bhūmau svabījatvamivodetyanudetyapi |
paraṃ tattvaṃ jagadbhaṅgyā jagattāṃ svodayena ca
]

`v 103 [
drumo bījatayaivāśu na saṃtyaktasamasthitiḥ |
tiṣṭhatyapagataspandastyāgātyāgaparo'ṇukaḥ
]

`v 104 [
bisatanturmahāmeruḥ paramāṇorapekṣayā |
dṛśyaṃ kila viśettanturadṛśyākṣṇā parāṇutā
]

`v 105 [
bisatanturmahāmeruḥ paramāṇoḥ kilātmanaḥ |
tasyaiva tadghanāḥ svāntaḥ sthitā mervādikoṭayaḥ
]

`v 106 [
dṛṣṭāntoktaṃ dārṣṭāntike'pyupapādayan tasya kasyodare santi
merumandarakoṭayaḥ ityasyottaramāha - bisatanturiti |
paramāṇorapyāntarasyātmano brahmaṇo'pekṣayā bisatanturapi merustasyaiva
svāntastadghanāścidghanāḥ paramārthasvabhāvā merumandarakoṭayaḥ sthitāḥ |
105 |
ekena tena mahatā paramāṇunā ca
vyāptaṃ tataṃ viracitaṃ janitaṃ kṛtaṃ ca |
dṛśyaṃ prapañcaracitaṃ nabhaseva viśvaṃ
śūnyatvamacchamabhitaḥ parilabdhameva
]

`v 107 [
p. 330) 200
dvaitena sundarataraṃ svamanujjhitena
rūpaṃ suṣuptasadṛśena yathāvabodhāt
aikyaṃ gataṃ sthitigamāgamamuktameva-
mitthaṃ sthitaṃ tanu jagatparamārthapiṇḍaḥ
]