`v 1 [
śatatamaḥ sargaḥ 100
śrīvasiṣṭha uvāca |
cittametadupāyātaṃ brahmaṇaḥ paramātpadāt |
atanmayaṃ tanmayaṃ ca taraṅgaḥ sāgarādiva
]

`v 2 [
prabuddhānāṃ mano rāma brahmaiveha hi netarat |
jalasāmānyabuddhīnāmabdhernānyastaraṅgakaḥ
]

`v 3 [
mano rāmāprabuddhānāṃ saṃsārabhramakāraṇam |
apaśyato'mbusāmānyamanyatāmbutaraṅgayoḥ
]

`v 4 [
aprabuddhadṛśāṃ pakṣe tatprabodhāya kevalam |
vācyavācakasaṃbandhakṛto bhedaḥ prakalpyate
]

`v 5 [
ata eva hi upadeśyopadeśakaśabdārthādiśāstrīyavyavahārakalpanāpi
ajñapakṣamavalambyaiva na tattvadṛśeti prāguktamityāha - aprabuddheti | 4
|
sarvaśakti paraṃ brahma nityamāpūrṇamavyayam |
na tadasti na tasminyadvidyate vitatātmani
]

`v 6 [
sarvaśaktirhi bhagavānyaiva tasmai hi rocate |
śaktiṃ tāmeva vitatāṃ prakāśayati sarvagaḥ
]

`v 7 [
cicchaktirbrahmaṇo rāma śarīreṣvabhidṛśyate |
spandaśaktiśca vāteṣu jaḍaśaktistathopale
]

`v 8 [
dravaśaktistathāmbhaḥsu tejaḥśaktistathā'nale |
śūnyaśaktistathākāśe bhāvaśaktirbhavasthitau
]

`v 9 [
brahmaṇaḥ sarvaśaktirhi dṛśyate daśadiggatā |
nāśaśaktirvināśeṣu śokaśaktiśca śokiṣu
]

`v 10 [
ānandaśaktirmudite vīryaśaktistathā bhaṭe |
sargeṣu sargaśaktiśca kalpānte sarvaśaktitā
]

`v 11 [
p. 366) 218
phalapuṣpalatāpatraśākhāviṭapamūlavān |
vṛkṣabīje yathā vṛkṣastathedaṃ brahmaṇi sthitam
]

`v 12 [
pratibhāsavaśādeva madhyasthaṃ cittajāḍyayoḥ |
jīvetarābhidhaṃ cittamantarbrahmaṇi dṛśyate
]

`v 13 [
nānātarulatāgulmajālapallavaśālayaḥ |
nirvikalpakacinmātraṃ nānā'nirjñātakalpanā
]

`v 14 [
brahmaivedamahaṃtattvaṃ jagatpaśyādya rāghava |
sa ātmā sarvago nāma nityoditamahāvapuḥ
]

`v 15 [
yanmanāḍyananīṃ śaktiṃ dhatte tanmana ucyate |
picchabhrāntiryathā vyomni payasyāvartadhīryathā
]

`v 16 [
pratibhāsakalāmātraṃ mano jīvastathātmani |
yadetanmanaso rūpamuditaṃ mananātmakam
]

`v 17 [
brāhmī śaktirasau tasmādbrahmaiva tadariṃdama |
idaṃ tadahamityeva vibhāgaḥ pratibhāsajaḥ
]

`v 18 [
manaso brahmaṇo'nyacca mohe paramakāraṇam |
yadyaccaitanmanasyeva kiṃcitsadasadātmakam
]

`v 19 [
vyāśabditaṃ sarvaśaktestāṃ śaktiṃ brahmatāṃ viduḥ |
manaḥ sattātmakaṃ nāma yathaitanmanasi sthitam
]

`v 20 [
yathartoḥ śaktayastadvajjīvehā brahmaṇi sthitāḥ |
vyāptasarvartukusumā kṣmādeśavidhibhedataḥ
]

`v 21 [
yathā dadhāti puṣpāṇi tathā cittāni lokakṛt |
kvacitkvacitkadāciddhi tasmādāyānti śaktayaḥ
]

`v 22 [
āyānti vyavasthitaphalātmanā āvirbhavanti | kṣmātalācchāliśaktaya ivetyarthaḥ |
21 |
deśakālādivaicitryātkṣmātalādiva `note[diha śālayaḥ iti pāṭhaḥ]
śālayaḥ |
na jātaṃ pratibhāsena tenaivānyena paśyati
]

`v 23 [
pratiyogivyavacchedasaṃkhyārūpādayaśca ye |
manaḥśabdaiḥ prakalpyante brahmajānbrahma viddhi tān
]

`v 24 [
yathā yathāsya manasaḥ pratibhāsaḥ pravartate |
tathā tathaiva bhavati dṛṣṭānto'tra kilaindavāḥ
]

`v 25 [
svayamakṣubdhavimale yathā spando mahāmbhasi |
saṃsārakāraṇaṃ jīvastathāyaṃ paramātmani
]

`v 26 [
jñasya sarvaṃ citaṃ rāma brahmaivāvartate sadā |
kallolormitaraṅgaughairabdherjalamivātmani
]

`v 27 [
dvitīyā nāsti sattaikā nāmarūpakriyātmikā |
pare nānātaraṅge'bdhau kalpaneva jaletarā
]

`v 28 [
jāyate naśyati tathā yadidaṃ yāti tiṣṭhati |
tadidaṃ brahmaṇi brahma brahmaṇā ca vivartate
]

`v 29 [
svātmanyevātapastīvro mṛgatṛṣṇikayā yathā |
vicitreṇa vicitro'pi prasphuratyātmanā tathā
]

`v 30 [
karaṇaṃ karma kartā ca jananaṃ maraṇaṃ sthitiḥ |
sarvaṃ brahmaiva nahyasti tadvinā kalpanetarā
]

`v 31 [
na lobho'sti na moho'sti na tṛṣṇāsti na rañjanā |
ka ātmanyātmano lobhastṛṣṇā moho'thavā kutaḥ
]

`v 32 [
ātmaivedaṃ jagatsarvamātmaiva kalanākramaḥ |
hemāṅgadatayevāyamātmodeti manastayā
]

`v 33 [
p. 367) 218
abuddhaṃ yatparaṃ dhāma taccittaṃ jīva ucyate |
aparijñāta evāśu bandhurāyātyabandhutām
]

`v 34 [
cinmayenātmanā'jñena svasaṃkalpanayā svayam |
śūnyatā gaganeneva jīvatā prakaṭīkṛtā
]

`v 35 [
ātmaivānātmavadiha jīvo jagati rājate |
dvīndutvamiva durdṛṣṭeḥ saccāsacca samutthitam
]

`v 36 [
mohārthaśabdārthadṛśoretayoratyasaṃbhavāt |
satyatvādātmanaścaiva kvātmā baddhaḥ kva mucyate
]

`v 37 [
nityāsaṃbhavabandhasya baddho'smīti kukalpanā |
yasya kālpanikastasya mokṣo mithyā na tattvataḥ
]

`v 38 [
śrīrāma uvāca |
mano yaṃ niścayaṃ yāti tattadbhavati nānyathā |
tena kālpaniko nāsti bandhaḥ kathamiha prabho
]

`v 39 [
śrīvasiṣṭha uvāca |
mithyā kālpanikīveyaṃ mūrkhāṇāṃ bandhakalpanā |
mithyaivābhyuditā teṣāmitarā mokṣakalpanā
]

`v 40 [
evamajñānakādeva bandhamokṣadṛśo'smṛteḥ |
vastutastu na bandho'sti na mokṣo'sti mahāmate
]

`v 41 [
kalpanāyā avastutvaṃ saṃprabuddhamatiṃ prati |
rajjvaheriva he prājña tattvabuddhamatiṃ prati
]

`v 42 [
bandhamokṣādisaṃmoho na prājñasyāsti kaścana |
saṃmohabandhamokṣādi hyajñasyaivāsti rāghava
]

`v 43 [
ādau manastadanu bandhavimokṣadṛṣṭī
paścātprapañcaracanā bhuvanābhidhānā |
ityādikā sthitiriyaṃ hi gatā pratiṣṭhā-
mākhyāyikā subhaga bālajanoditeva
]