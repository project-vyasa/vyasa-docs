`v 1 [
ekapañcāśaḥ sargaḥ 51
śrīvasiṣṭha uvāca |
hato rājā hato rājā pratirājena saṃyuge |
itiśabde samudbhūte rāṣṭramāsīdbhayākulam
]

`v 2 [
bhāṇḍopaskarabhārāḍhyaṃ vidravacchakaṭavrajam |
sākrandrārtakalatrāḍhyaṃ dravannāgaradurgamam
]

`v 3 [
palāyamānasākrandaṃ mārgāhṛtavadhūgaṇam |
anyonyaluṇṭhanavyagralokalagnamahābhayam
]

`v 4 [
pararāṣṭrajanānīkatāṇḍavollāsasāravam |
niradhiṣṭhitamātaṅgahayavīrapatajjanam
]

`v 5 [
p. 253) 151
kapāṭapāṭanoḍḍīnakośāntaravaghargharam |
luṇṭhitāsaṃkhyakauśeyaprāvṛtābhibhaṭodbhaṭam
]

`v 6 [
kṣurikotpāṭitārdrāntramṛtarājagṛhāṅganam |
rājāntaḥpuraviśrāntacaṇḍālaśvapacotkaram
]

`v 7 [
gṛhāpahṛtabhojyānnabhojanonmukhapāmaram |
sahemahāravīraughapādāhatarudacchiśu
]

`v 8 [
apūrvataruṇākrāntakeśāntaḥpurikāṅganam |
corahastacyutānarghyaratnadanturamārgagam
]

`v 9 [
hayebharathasaṃghaṭṭavyagrasāmantamaṇḍalam |
abhiṣekodyamādeśaparamantripuraḥsaram `note[dyamādeśaṃ paraṃ ityapi
ādarśāntare pāṭho labhyate tathāpyetatpāṭhasya
susaṅgatatvāṭṭīkākārasaṃmatatvāccaiṣa evāsmābhirādṛtaḥ]
]

`v 10 [
saṃghaṭṭanaṃ saṃghaṭṭaḥ apahṛtya melanaṃ tatra vyagraṃ sāmantamaṇḍalaṃ
yatra | sindhusutapaṭṭābhiṣekodyamasya ādeśe ājñāpane parāstatparāḥ | 9 |
rājadhānīvinirmāṇasārambhasthapatīśvaram |
kṛtavātāyanaśvabhranipatadrājavallabham
]

`v 11 [
jayaśabdaśatodghoṣasindhurājanyanirbharam |
asaṃkhyanijarājaughadhṛtasindhukṛtāsthiti
]

`v 12 [
grāmāntarasamākrāntavidravadrājavallabham |
maṇḍalāntarasaṃjātanagaragrāmaluṇṭhanam
]

`v 13 [
anantacoramoṣārtharuddhamārgagamāgamam |
mahānubhāvavaidhuryasanīhāradinātapam
]

`v 14 [
mṛtabandhujanākrandairmṛtatūryaravairapi |
hayebharathaśabdaiśca piṇḍagrāhyaghanadhvani
]

`v 15 [
sindhudevo jayatyekacchatrabhūmaṇḍalādhiapaḥ |
ityanantaramārebhe bheryaḥ pratipuraṃ tadā
]

`v 16 [
rājadhānīṃ viveśātha sindhuruddhurakandharaḥ |
prajāḥ sraṣṭuṃ yugasyānte manurjagadivāparaḥ
]

`v 17 [
pravṛttā daśadigbhyo'tha praveṣṭuṃ saindhavaṃ puram |
karāḥ karihayākārai ratnapūrā ivāmbudhim
]

`v 18 [
nibandhanāni cihnāni śāsanāni diśaṃ prati |
kṣaṇānniveśayāmāsurmaṇḍalaṃ prati mantriṇaḥ
]

`v 19 [
udabhūdacireṇaiva deśe deśe pure pure |
jīvite maraṇe māne niyamo'yamato yathā
]

`v 20 [
atha śemurnimeṣeṇa deśopaplavavibhramāḥ |
praśāntotpātapavanāḥ padārthāvṛttayo yathā
]

`v 21 [
saumyatāmājagāmāśu deśo daśadiganvitaḥ |
kṣīrodaḥ kṣubhitāvarto drāgivoddhṛtamandaraḥ
]

`v 22 [
vavuralakacayānvilolayanto
mukhakamalālikulāni saindhavīnām |
jalalavavalanākulāḥ samīrā
aśivaguṇāniva sarvataḥ kṣaṇena
]