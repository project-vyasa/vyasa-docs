`v 1 [
ekonaviṃśaḥ sargaḥ 19
śrīdevyuvāca |
vittaveṣavayaḥkarmavidyāvibhavaceṣṭitaiḥ |
vasiṣṭhasyaiva sadṛśo natu vāsiṣṭhaceṣṭitaḥ
]

`v 2 [
vasiṣṭha iti nāmnāsau tasyābhūdindusundarī |
nāmnā tvarundhatī bhāryā bhūmivyomanyarundhatī
]

`v 3 [
vittaveṣavayaḥkarmavidyāvibhavaceṣṭitaiḥ |
samaiva sāpyarundhatyā natu cetanasattayā
]

`v 4 [
akṛtrimapremarasā vilāsālasagāminī |
sāsya saṃsārasarvasvamāsītkumudahāsinī
]

`v 5 [
sa viprastasya śailasya sānau saralaśādvale |
kadācidupaviṣṭaḥ sandadarśādo mahīpatim
]

`v 6 [
samagraparivāreṇa yāntamākheṭakecchayā |
mahatā sainyaghoṣeṇa meroriva bibhitsayā
]

`v 7 [
cāmaraiḥ kīrṇacandrāṃśupatākābhirlatāvanam |
kurvāṇaṃ khaṃ sitacchatramaṇḍalai rūpyakuṭṭimam
]

`v 8 [
latāvanaṃ cāmaraiḥ patākābhiśca kīrṇacandrāṃśu kurvāṇaṃ tathā khaṃ
sitacchatramaṇḍalai rūpyasaudhaṃ kurvāṇam | ubhayatra tatsadṛśamityarthaḥ | 7
|
aśvapādūsvanatkṣmājareṇupūrāvṛtāmbaram |
hāstikottambhitakaravātāṭṭālakagopitam
]

`v 9 [
p. 176)
mahākalakalāvartadravaddigbhūtamaṇḍalam |
kacatkāñcanamāṇikyahārakeyūramaṇḍalam
]

`v 10 [
tamālokya mahīpālamidaṃ cintitavānasau |
aho nu ramyā nṛpatā sarvasaubhāgyabhāsitā
]

`v 11 [
padātirathahastyaśvapatākācchatracāmaraiḥ |
kadā syāṃ daśadikkuñjapūrako'haṃ mahīpatiḥ
]

`v 12 [
kadā me vāyavaḥ kundamakarandasugandhayaḥ |
pāsyantyantaḥpurastrīṇāṃ surataśramasīkarān
]

`v 13 [
karpūreṇa purandhrīṇāṃ pūrṇena yaśasā diśām |
indūdayāvadātāni kadā kuryāṃ mukhānyaham
]

`v 14 [
itthaṃ tataḥprabhṛtyeṣa vipraḥ saṃkalpavānabhūt |
svadharmanirato nityaṃ yāvajjīvamatandritaḥ
]

`v 15 [
himāśanirivāmbhojaṃ jarjarīkartumādṛtā |
jale jarjaritevātha jarā dvijamupāyayau
]

`v 16 [
āsannamaraṇasyātha bhāryā mlānimupāyayau |
tasya śāmyati puṣpartau lateva grīṣmabhītitaḥ
]

`v 17 [
māmathārādhitavatī sā tatastvamivāṅganā |
amaratvaṃ suduṣprāpaṃ buddhvemaṃ sāvṛṇodvaram
]

`v 18 [
devi svamaṇḍapādeva jīvo bharturmṛtasya me |
māyāsīdityatastasyāḥ sa evāṅgīkṛto mayā
]

`v 19 [
atha kālavaśādvipraḥ sa pañcatvamupāyayau |
tasminneva gṛhākāśe jīvākāśatayā sthitaḥ
]

`v 20 [
saṃpannaḥ prāktanānalpasaṃkalpavaśataḥ svayam |
ākāśavapurevaiṣa patiḥ paramaśaktimān
]

`v 21 [
prabhāvajitabhūpīṭhaḥ pratāpākrāntaviṣṭapaḥ |
kṛpāpālitapātālastrilokavijayī nṛpaḥ
]

`v 22 [
kalpāgnirarivṛkṣāṇāṃ strīṇāṃ makaraketanaḥ |
merurviṣayavāyūnāṃ sādhvabjānāṃ divākaraḥ
]

`v 23 [
ādarśaḥ sarvaśāstrāṇāmarthināṃ kalpapādapaḥ |
pādapīṭhaṃ dvijāgryāṇāṃ rākādharmāmṛtatviṣaḥ
]

`v 24 [
svagṛhābhyantarākāśe cittākāśamayātmani |
tasmindvije śavībhūte bhūtākāśaśarīriṇi
]

`v 25 [
sā tasya brāhmaṇī bhāryā śokenātyantakarśitā |
śuṣkeva māṣaśimbīkā hṛdayena dvidhābhavat
]

`v 26 [
bhartrā saha śavībhūtā dehamutsṛjya dūrataḥ |
ātivāhikadehena bhartāraṃ samupāyayau
]

`v 27 [
nadīnikhātamiva taṃ bhartāramanusṛtya sā |
ājagāma viśokatvaṃ sā vāsantīva mañjarī
]

`v 28 [
tatrāsya viprasya gṛhāṇi santi
bhūsthāvarādīni dhanāni santi |
adyāṣṭamaṃ vāsaramāptamṛtyo-
rjīvo girigrāmakakandarasthaḥ
]