`v 1 [
ekonapañcāśaḥ sargaḥ 49
śrīvasiṣṭha uvāca |
vavurvalitanīhārā vikīrṇavanapallavāḥ |
vāyavo dhūtavṛkṣaughāḥ sallīlāpīḍapāṃsavaḥ
]

`v 2 [
pakṣivadbhrāntavṛkṣaughāḥ patanotpātanodbhaṭāḥ |
vikuṭṭitāṭṭālakhaṇḍāścābhrabhittivibhedinaḥ
]

`v 3 [
tenātibhīmavātena vidūratharatho'pyatha |
uhyamāno'bhavannadyā yathā jarjarapallavaḥ
]

`v 4 [
vidūratho'tha tatyāja pārvatāstraṃ mahāstravit |
vyomāpi ghanatoyena samādātumvodyatam
]

`v 5 [
tena śailāstraghātena virāṭ prāṇasamīraṇaḥ |
śamaṃ caitanyaśāntyeva prayayau vāyurātataḥ
]

`v 6 [
antarikṣagatā vṛkṣapaṅktayaḥ patitā bhuvi |
nānājanaśavavyūhe kākānāmiva koṭayaḥ
]

`v 7 [
śemuḥ sūtkāraḍātkārabhāṃkārotkārakā diśām |
pralāpā iva vidhvastāḥ pūrgrāmavanavīrudhām
]

`v 8 [
girīnapaśyannabhasaḥ patataḥ patravarṇavat |
sindhuḥ sindhurivotpakṣānmainākādīnitastataḥ
]

`v 9 [
vajrāstramasṛjaddīptaṃ cerurvajragaṇāstataḥ |
pibanto'drīndratimiramagnidāhamivāgnayaḥ
]

`v 10 [
te girīṇāṃ tathā kṣiptāḥ koṭituṇḍāvakhaṇḍanaiḥ |
śirāṃsi pātayāmāsuḥ phalānīvolbaṇānilāh
]

`v 11 [
vidūratho'tha vajrāstraśantyai brahmāstramatyagāt |
tato brahmāstravajrāstre samaṃ praśamamāgate
]

`v 12 [
p. 249)
śyāmāśyāmaṃ piśācāstramatha sindhuracodayat |
tenodaguḥ piśācānāṃ paṅktayo'tyantabhītidāḥ
]

`v 13 [
saṃdhyāyāmatha bhītyeva divasaḥ śyāmatāṃ yayau |
piśācā bhuvanaṃ jagmurandhakārabharā iva
]

`v 14 [
bhasmanaḥstambhasadṛśāstālottālavilāsinaḥ |
dṛśyamānamahākārā muṣṭigrāhyā na kiṃcana
]

`v 15 [
ūrdhvakeśāḥ kṛśāṅgāścakecicca śmaśrulā api |
kṛṣṇāṅgā malināṅgāśca grāmyā iva nabhaścarāḥ
]

`v 16 [
sabhayā mūḍhadṛṣṭāśca yatkiṃcanakarāścalāḥ |
dīnā vajrāsinaḥ krūrā dīnā grāmyajanā iva
]

`v 17 [
tarukardamarathyāntaḥśūnyagehagṛhāścalāḥ |
lelihānāḥ pretarūpāḥ kṛṣṇāṅgāścapalā iva
]

`v 18 [
jagṛhuste tadā mattā hataśiṣṭamarerbalam |
āsaṃstatsainikāstatra bhinnāstrakṣubdhacetanāḥ
]

`v 19 [
tyaktāyudhatanutrāṇāstrastaprāṇāḥ skhaladgamāḥ |
netrairaṅgairmukhaiḥ pādairvikārabharakāriṇaḥ
]

`v 20 [
tyaktakaupīnavasanā nimagnāvasanottarāḥ |
viṣṭhāṃ mūtraṃ ca kurvantaḥ sthiramārabdhanartanāḥ
]

`v 21 [
piśācarājī rājānaṃ tasya yāvadvidūratham |
samākrāmati tāvattāṃ māyāṃ sa bubudhe budhaḥ
]

`v 22 [
piśācasaṃgrāmakarīṃ māyāṃ vetti sa bhūmipaḥ |
tayā piśācasainyaṃ tatparasainye nyayojayat
]

`v 23 [
tataḥ svasainikāḥ svasthāḥ parayodhāḥ piśācinaḥ |
tasyāśu rūpikāstraṃ ca dadāvanyadasau ruṣā
]

`v 24 [
tasya piśācasainyasya sahāyabhūtam | rūpikāḥ pūtanābhedāḥ | asau vidūrathaḥ |
23 |
udagurbhūtalādvyomno rūpikā ūrdhvamūrdhajāḥ |
nirmagnavikarālākṣyaścalacchroṇipayodharāḥ
]

`v 25 [
udbhinnayauvanā vṛddhāḥ pīvarāṅgyo'tha jarjarāḥ |
svarūpārūpajaghanā `note[svarūpeṇa svarūpataḥ arūpāṇi nirākārāṇi
jaghanāni yāsāṃ tathāvidhāḥ durlakṣyajaghanā ityarthaḥ] durnābhyo
vikasadbhagāḥ
]

`v 26 [
nararaktaśirohastāḥ saṃdhyābhrāruṇagātrikāḥ |
ardhacarvitamāṃsāsṛksravatsṛkkyākulānanāḥ
]

`v 27 [
nānāṅgavalanā nānānamannamanasattamāḥ |
śilābhujagavakrorukaṭipārśvakarāṅgikāḥ
]

`v 28 [
nārīkṛtārbhakaśavā hastākṛṣṭāntrarajjavaḥ |
śvakākolūkavadanā nimnavakrahanūdarāḥ
]

`v 29 [
jagṛhustānpiśācāṃstā durbalānduḥśiśūniva |
piśācarūpikāsainyaṃ tadāsīdekatāṃ gatam
]

`v 30 [
nirmagnanartanottānavadanāṅgavilocanam |
parasparākrāntikaraṃ pradhāvacca parasparam
]

`v 31 [
niskāsitamahājihvaṃ nānāmukhavikāradam |
śarabhārāḍhyamanyonyaṃ `note[nyonyahriyamāṇa iti pāṭhaḥ]
hriyamāṇaśavāṅgakam
]

`v 32 [
rudhirāmbhasi majjaṃ tadunmajjaddhṛllasattanu |
lambodaraṃ lambabhujaṃ lambakarṇoṣṭhanāsikam
]

`v 33 [
raktamāṃsamahāpaṅkeṣvanyonyaṃ vellanābhyasat |
mandaroddhūtadugdhābdhilasatkalakalākulam
]

`v 34 [
yathaiva māyāsaṃcārastena tasya kṛtaḥ purā |
tenāpi tasyāśu tathā kṛto buddhvā sa lāghavāt
]

`v 35 [
vetālāstraṃ tato datte tenottasthuḥ śavavrajāḥ |
amūrdhānaḥ samūrdhāno vetālā veśavallitāḥ
]

`v 36 [
p. 250) 150
tataḥ piśācavetālarūpikograkabandhavat |
tadvabhūva balaṃ bhīmamurvīnigaraṇakṣamam
]

`v 37 [
athetaro'pi bhūpālo māyāṃ saṃcārya tāṃ gurau |
rākṣasāstraṃ sasarjātha trailokyagrahaṇonmukham
]

`v 38 [
udaguḥ parvatākārāḥ sarvataḥ sthūlarākṣasāḥ |
dehamāśritya niṣkrāntāḥ pātālānnarakā iva
]

`v 39 [
athodabhūdbalaṃ bhīmaṃ sasurāsurabhītidam |
garjadrakṣomahānādavādyanṛtyatkabandhakam
]

`v 40 [
medomāṃsopadaṃśāḍhyaṃ rudhirāsavasundaram |
kṣībakūśmāṇḍavetālayakṣatāṇḍavasundaram
]

`v 41 [
kūśmāṇḍakottāṇḍavadaṇḍapāda-
kṣubdhāsṛgutkṣiptataraṅgasiktaiḥ |
saṃdhyābhrarāgotkarakoṭikānti
bhūtairasṛksrotasi dattasetu
]