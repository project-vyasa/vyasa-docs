`v 1 [
dvyaśītitamaḥ sargaḥ 82
śrīvasiṣṭha uvāca |
iti rājamukhācchrutvā karkaṭī vanamarkaṭī |
avabuddhapadāntaṃ svaṃ jahau matsaracāpalam
]

`v 2 [
antaḥśītalatāmetya viśrāntimapatāpatām |
prāptā prāvṛṇmayūrīva sajyotsneva kumudvatī
]

`v 3 [
tathā rājagirā tasyā ānanda udabhūdbhṛśam |
garbhe'ntaḥ khe balākāyā raveṇeva payomucaḥ
]

`v 4 [
rākṣasyuvāca |
aho bata pavitreyaṃ bhavatorbhāti śemuṣī |
anastamitasāreṇa prabodhārkeṇa bhāsitā
]

`v 5 [
śītā samarasā śuddhā jyotsneva śaśimaṇḍalāt |
vivekakaṇikāṃ śrutvā bhavato hṛdayādiyam
]

`v 6 [
vivekino jagatpūjyāḥ sevyā manye bhavādṛśāḥ |
satsaṅgātsavikāsāsmi candreṇeva kumudvatī
]

`v 7 [
saurabhaṃ kusumāsaṅgādeva satsaṅgamācchubham |
vartate hyarkasaṃparkādvikāso'mburuhāmiva
]

`v 8 [
mahatāmeva saṃparkātpunarduḥkhaṃ na bādhate |
ko hi dīpaśikhāhastastamasā paribhūyate
]

`v 9 [
mayemau jaṅgalaprāptau bhavantau bhūmibhāskarau |
pūjanīyāvataḥ śīghramīhitaṃ kathyatāṃ śubham
]

`v 10 [
rājovāca |
asmin janapade rakṣaḥkulakānanamañjari `note[rakṣaḥkulakānanamañjari iti
rākṣasyāḥ saṃbodhanam] |
janasya bādhate'tyantaṃ sadā hṛdayaśūlanam
]

`v 11 [
yataḥ sarvaiva janatā taptā dṛḍhaviṣūcikā |
maṇḍale nanu tenāhaṃ nirgato rātricaryayā
]

`v 12 [
śūlādi hṛdaye nṝṇāṃ na śāmyati yadauṣadhaiḥ |
tato'haṃ tvadvidhaproktamantrārthena vinirgataḥ
]

`v 13 [
tvādṛśasya ca lokasya mugdhalokābhighātinaḥ |
nigrahārthaṃ pravṛttirme sā ca saṃpattimetyalam
]

`v 14 [
etāvadeva ca śubhe tvayāṅgīkriyatāṃ vacaḥ |
bhūyo bhavatyā prāṇā hi hiṃsanīyā na kasyacit
]

`v 15 [
rākṣasyuvāca |
bāḍhamevaṃ karomyadyaprabhṛtyavitathaṃ prabho |
satyameva na kiṃciddhi hiṃsanīyaṃ mayādhunā
]

`v 16 [
rājovāca |
yadyevaṃ phullapadmākṣi paradehaikabhojane |
kiṃ syāccharīravṛttyai `note[bhṛtyai iti pāṭhaḥ] te sthitāyā
matsamīhite
]

`v 17 [
p. 331) 200
ṣaḍbhirmāsairgirau rājanprabuddhāyāḥ samādhitaḥ |
jātā bhojanasaṃkalpādbhojaneccheyamadya me
]

`v 18 [
idānīṃ śikharaṃ gatvā tadeva dhyānaniścalā |
yāvadicchaṃ sukhenāse sajīvā śālabhañjikā
]

`v 19 [
āmṛtīṃ dhāraṇāṃ baddhvā dhārayāmi śarīrakam |
yathecchamatha kālena tyakṣyāmīti matirmama
]

`v 20 [
āśarīraparityāgamidānīṃ na mayā nṛpa |
hiṃsanīyāḥ paraprāṇāstenedaṃ madvacaḥ śṛṇu
]

`v 21 [
himavānnāma śailo'sti śaraccandrāṃśunirmalaḥ |
ya uttarāśāhṛdaye spṛṣṭapūrvāparārṇavaḥ
]

`v 22 [
tatrāhaṃ nivasāmyagre hemaśṛṅgadarīgṛhe |
āyasī meghalekheva karkaṭīnāma rākṣasī
]

`v 23 [
tapasopārjito brahmā janatāmāraṇecchayā |
viṣūcikā prāṇaharā syāṃ sūcyātmeti bho mayā
]

`v 24 [
tasmātsaṃprāptavarayā bahūnvarṣagaṇānmayā |
bhuktā viṣūcikātvena janatā jīvabādhanaiḥ
]

`v 25 [
tvayā na guṇino hiṃsyā iti me brahmaṇā tataḥ |
niyamārthaṃ mahāmantrastadāyattāsmi saṃsthitā
]

`v 26 [
so'yaṃ pragṛhyatāṃ tena sarvaṃ hṛdayaśūlanam |
śamameṣyati loke'smātkā kathā matkṛte bhrame
]

`v 27 [
vitataivāsmi hiṃsāyāṃ yatpurā hiṃsitaṃ mayā |
janasya hṛdayaṃ tena nāḍyo vaidhuryamāgatāḥ
]

`v 28 [
hiṃsitvā raktamāṃsāni saṃtyaktā ye mahājanāḥ |
tebhyo vidhuranāḍībhyo ye jātāste'pi tādṛśāḥ
]

`v 29 [
rājanviṣūcikāmantraḥ so'yaṃ saṃpanna eva te |
nahi sattvavatāmasti duḥsādhyamiha kiṃcana
]

`v 30 [
ato durnāḍikośeṣu śūlānāṃ pariśāntaye |
mantro yo brahmaṇā prokto rājañśīghraṃ gṛhāṇa tam
]

`v 31 [
āgaccha nikaṭaṃ nadyā gacchāmastatra bhūmipa |
svācāntābhyāṃ saṃyatābhyāṃ bhavadbhyāṃ sumatā dade
]

`v 32 [
śrīvasiṣṭha uvāca |
iti tasyāṃ tadā rātryāṃ rākṣasīmantribhūbhṛtaḥ |
jagmuste saritastīraṃ mithaḥ saṃjātasauhṛdāḥ
]

`v 33 [
anvayavyatirekeṇa rākṣasyāḥ sauhṛdaṃ tadā |
jñātvā sthitau tau svācāntāvubhāvantenivāsinau
]

`v 34 [
tayā brahmopadiṣṭo'su tatastābhyāṃ yathākramam |
snehādviṣūcikāmantraḥ pradatto japasiddhidaḥ
]

`v 35 [
tataḥ saṃjātasauhārdau tau visṛjya niśācarī |
yadā gantuṃ pravṛttāsau tadā rājābravīdvacaḥ
]

`v 36 [
rājovāca |
gurustvaṃ nau mahādehe vayasyā ca sunirvṛtā |
nimantrayāvahe yatnādgrāsāya tava sundari
]

`v 37 [
nacāsmatpraṇayaṃ prītā vitathīkartumarhasi |
sauhārdaṃ sujanānāṃ hi darśanādeva vardhate
]

`v 38 [
laghusaubhāgyasaṃyuktaṃ kṛtvākāraṃ manoramam |
āgacchāsmadgṛhaṃ bhadre tatra tiṣṭha yathāsukham
]

`v 39 [
rākṣasyuvāca |
mugdhastrīrūpadhāriṇyai dātuṃ śakto'si bhojanam |
saṃtarpayasi māṃ kena rākṣasākāraghāriṇīm
]

`v 40 [
rakṣonnameva saṃtuṣṭyai na sāmānyajanāśanam |
pūrvasiddhasvabhāvo'yamādehaṃ na nivartate
]

`v 41 [
rājovāca |
hemasragdāmavalitā dināni katicidgṛhe |
mama strīrūpiṇī tiṣṭha yāvadicchamanindite
]

`v 42 [
tato duṣkṛtinaścaurānvadhyāñchatasahasraśaḥ |
maṇḍalebhyaḥ samānīya dade tubhyaṃ subhojanam
]

`v 43 [
kāntārūpaṃ parityajya gṛhītvā rākṣasaṃ vapuḥ |
ādāya vadhyāñchataśaḥ puruṣāṃstānsusaṃcitān
]

`v 44 [
nayasva himavacchṛṅgaṃ tatra bhuṅkṣva yathāsukham |
mahāśanānāmekānte bhojanaṃ hi sukhāyate
]

`v 45 [
tṛptā nidrāṃ manākkṛtvā bhava bhūyaḥ samādhibhāk |
samādhiviratā bhūyo'pyāgatya punaranyadā
]

`v 46 [
p. 332) 201
neṣyasyanyānvadhyajanān hiṃsā naiṣāṃ ca dharmataḥ |
svadharmeṇa ca hiṃsaiva mahākaruṇayā samā
]

`v 47 [
tvaṃ sameṣyasi cāvaśyaṃ māṃ samādhivirāgiṇī |
asatāmapi saṃrūḍhaṃ sauhārdaṃ na nivartate
]

`v 48 [
rākṣasyuvāca |
yuktamuktaṃ tvayā rājankaromyevamahaṃ sakhe |
sauhārdena pravṛttasya ko vākyaṃ nābhinandati
]

`v 49 [
śrīvasiṣṭha uvāca |
ityuktvā rākṣasī tatra saṃpannā suvilāsinī |
hārakeyūrakaṭakapaṭṭasragdāmadhāriṇī
]

`v 50 [
rājannāgaccha gacchāma ityuktvā bhūpamantriṇau |
agre gantuṃ pravṛttau tau rātrāvanusasāra sā
]

`v 51 [
atha te pārthivagṛhaṃ prāpya tāṃ rajanīṃ mithaḥ |
kathayaikagṛhe ramye kṣapayāmāsurādṛtāḥ
]

`v 52 [
prabhāte'ntaḥpure tasthau purandhrījanalīlayā |
rākṣasī mantrirājānau svavyāpārau babhūvatuḥ
]

`v 53 [
tato divasaṣaṭkena saṃcitāni mahībhṛtā |
nṛptaḥ parapurebhyo'pi svamaṇḍalagaṇāttathā
]

`v 54 [
trīṇi vadhyasahasrāṇi tāni tasyai tadā dadau |
sā babhūva niśā kāle saivogrā kṛṣṇarākṣasī
]

`v 55 [
tāni vadhyasahasrāṇi jagrāha bhujamaṇḍale |
dhārānikarajālāni meghamāleva koṭare
]

`v 56 [
yayau rājānamāpṛcchya tadeva himavacchiraḥ |
daridrā labdhahemeva graheṣūgraśarīriṇī
]

`v 57 [
tatra tṛptā bhṛśaṃ bhuktvā sukhaṃ suptvā dinatrayam |
āsītprabodhasusvasthā sā samādhimatiḥ punaḥ
]

`v 58 [
pañcabhirvā caturbhirvā varṣaiḥ sā saṃprabudhyate |
tattato maṇḍalaṃ yāti tena rājasabhājane
]

`v 59 [
tatra viśrambhagarbhābhiḥ kathābhiḥ kaṃcideva sā |
sthitvā kālaṃ gṛhītvā tānvadhyānsvāspadametyatha
]

`v 60 [
jīvanmuktatayaivameva vipine sādyāpi rakṣoṅganā
tasminneva girau sthitā vicalitadhyānaikatānāśayā |
tasminrājani śāntimāgatavati tyaktaiṣaṇenātmanā
tadrāṣṭrādhipasauhṛdaiḥ svakavalānāsvādayantī ciraṃ
]