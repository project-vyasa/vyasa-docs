`v 1 [
p. 206)
ekatriṃśaḥ sargaḥ 31
śrīvasiṣṭha uvāca
evamākalayantyau te nirgatya jagato nijāt |
antaḥpuraṃ dadṛśaturjhaṭityeva vinirgate
]

`v 2 [
sthitapuṣpabharāpūrṇamahārājamahāśavam |
śavapārśvopaviṣṭāntaścittalīlāśarīrakam
]

`v 3 [
ghanarātritayālpālpamahānidrājanākulam |
dhūpacandanakarpūrakuṅkumāmodamantharam
]

`v 4 [
tamālokyāparaṃ bhartuḥ saṃsāraṃ gantumādṛtā |
papāta līlā saṃkalpadehenātraiva tannabhaḥ
]

`v 5 [
viveśa bhartuḥ saṃkalpasaṃsāraṃ kiṃcidātatam |
saṃsārāvaraṇaṃ bhittvā bhittvā brahmāṇḍakarparam
]

`v 6 [
prāpa sārdhaṃ tayā devyā punarāvaraṇānvitam |
brahmāṇḍamaṇḍapaṃ sphāraṃ taṃ praviśya tathā javāt
]

`v 7 [
dadarśa bhartuḥ saṃkalpajagajjambālapalvalam |
siṃhīva śailakuharaṃ tamo jaladapaṅkilam
]

`v 8 [
devyo viviśatustatte vyoma vyomātmike jagat |
brahmāṇḍe'ntaryathā pakvaṃ mṛdubilvaṃ pipīlike
]

`v 9 [
tatra lokāntarāṇyadrīnantarikṣamatītya te |
prāpaturbhūtalaṃ śailamaṇḍalāmbhodhisaṃkulam
]

`v 10 [
meruṇālaṃkṛtaṃ jambūdvīpaṃ navadalodaram |
gavātha bhārate varṣe līlānāthasya maṇḍalam
]

`v 11 [
navadalāni navakhaṇḍāḥ | līlānāthasya maṇḍalaṃ rājyaṃ dadarśetyanvayaḥ | 10
|
etasminnantare tasminmaṇḍale maṇḍitāvanau |
cakre'vaskandanaṃ kaścitsāmantodriktabhūmipaḥ
]

`v 12 [
tena saṃgrāmasaṃrambhe prekṣārthaṃ samupāgataiḥ |
trailokyabhūtaistadvyoma babhūvātyantasaṃkaṭam
]

`v 13 [
aśaṅkitāgate tatte devyau dadṛśaturnabhaḥ |
nabhaścaragaṇākrāntamambudairiva mālitam
]

`v 14 [
mithyātva niścayādantardhānādikuśalatvāccāśaṅkitaṃ bhayaśaṅkārahitaṃ
yathā syāttathā āgate | nabhaścaretyādīnyārāmapraśnānnabhaso viśeṣaṇāni |
13 |
siddhacāraṇagandharvagaṇavidyādharānvitam |
śūragrahaṇasaṃrabdhasvargalokāpsarovṛtam
]

`v 15 [
raktamāṃsonmukhonmattabhūtarakṣaḥpiśācakam |
puṣpavṛṣṭibhirāpūrṇahastavidyādharāṅganam
]

`v 16 [
vetālayakṣakuśmāṇḍairdvandvālokanasādaraiḥ |
āyudhāpātarakṣārthaṃ gṛhītādritaṭairvṛtam
]

`v 17 [
astramārganabhobhāgavidravadbhūtamaṇḍalam |
āhopuruṣikākṣubdhaprekṣakāmodanodbhaṭam
]

`v 18 [
āsannabhīmasaṃgrāmakiṃvadantīparasparam |
līlāhāsavilāsotkasundarīdhṛtacāmaram
]

`v 19 [
dharmāprekṣyaprayuktāgryamunisvastyayanastavam |
saṃpannānekalokeśavanitāvasarastavam
]

`v 20 [
svargārhaśūrānayanavyagrendrabhaṭabhāsuram |
śūrārthālaṃkṛtottuṅgalokapālākhyavāraṇam
]

`v 21 [
āgacchacchūrasanmānonmukhagandharvacāraṇam |
śūronmukhāmarastraiṇakaṭākṣekṣitasadbhaṭam
]

`v 22 [
vīradordaṇḍakāśleṣalampaṭastrīgaṇākaram |
śuklena śūrayaśasā candrīkṛtadivākaram
]

`v 23 [
p. 207)
śrīrāma uvāca |
bhagavañchūraśabdena kīdṛśaḥ procyate bhaṭaḥ |
svargālaṃkaraṇaṃ kaḥ syātko vā ḍimbhāhavo bhavet
]

`v 24 [
śrīvasiṣṭha uvāca |
śāstroktācārayuktasya prabhorarthena yo raṇe |
mṛto vātha jayī vā syātsa śūraḥ śūralokabhāk
]

`v 25 [
anyathā prāṇikṛttāṅgo raṇe yo mṛtimāpnuyāt |
ḍimbhāhavahataḥ proktaḥ sa naro narakāspadam
]

`v 26 [
ayathāśāstrasaṃcāravṛtterarthena yudhyate |
yo narastasya saṃgrāme mṛtasya nirayo'kṣayaḥ
]

`v 27 [
yathāsaṃbhavaśāstrārthalokācārānuvṛttimān |
yudhyate tādṛśaścaiva bhaktaḥ śūraḥ sa ucyate
]

`v 28 [
gorarthe brāhmaṇasyārthe mitrasyārthe ca sanmate |
śaraṇāgatayatnena sa mṛtaḥ svargabhūṣaṇam
]

`v 29 [
paripālyasvadeśaikapālane yaḥ sthitaḥ sadā |
rājā mṛtāstadarthaṃ ye te vīrā vīralokinaḥ
]

`v 30 [
prajopadravaniṣṭhasya rājño'rājño'tha vā prabhoḥ |
arthena ye mṛtā yuddhe te vai nirayagāminaḥ
]

`v 31 [
ye hi rājñāmarājñāṃ vāpyayathāśāstrakāriṇām |
raṇe mriyante chinnāṅgāste vai nirayagāminaḥ
]

`v 32 [
dharmyaṃ yathā tathā yuddhaṃ yadi syāttarhi saṃsthitiḥ |
nāśayeyuralaṃ mattaḥ paralokabhayojjhitāḥ
]

`v 33 [
yatra yatra hataḥ śūraḥ svarga ityavaśoktayaḥ |
dharme yoddhā bhavecchūra ityevaṃ śāstraniścayaḥ
]

`v 34 [
sadācāravatāmarthe khaḍgadhārāṃ sahanti ye |
te śūrā iti kathyante śeṣā ḍimbhāhavāhatāḥ
]

`v 35 [
teṣāmarthe raṇe vyomni tiṣṭhantyutkaṇṭhitāśayāḥ |
śūrībhūtamahāsattvadayitoktisurāṅganāḥ
]

`v 36 [
vidyādharīmadhuramantharagītigarbhaṃ
mandāramālyavalanākulakāminīkam |
viśrāntakāntasurasiddhavimānapaṅkti
vyomotsavoccaritaśobhamivollalāsa
]