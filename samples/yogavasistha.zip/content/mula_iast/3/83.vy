`v 1 [
tryaśītitamaḥ sargaḥ 83
śrīvasiṣṭha uvāca |
kirātamaṇḍale tasminye bhavanti mahībhṛtaḥ |
taistaiḥ saha parā maitrī tasyāḥ samabhijāyate
]

`v 2 [
tadrāṣṭrādhipasauhṛdaiḥ svakavalānāsvādayantīti yaduktaṃ tatprapañcayati ##-
sarvāṃstatra mahotpātānpiśācādibhayānyapi |
rogāṃśca yogasaṃsiddhā nivārayati rākṣasī
]

`v 3 [
bahuvarṣagaṇenaiṣā dhyānādviratimāgatā |
tatrāgatya samastāṃstānvadhyāñjantūnsusaṃcitān
]

`v 4 [
adyāpi tatra ye vadhyāste tadarthaṃ mahībhujā |
nīyante mitrasanmāne ke hi nādhyavasāyinaḥ
]

`v 5 [
tasyāṃ dhyānaniṣaṇṇāyāṃ kirātajanamaṇḍale |
anāyāntyāṃ ciraṃ kālaṃ janairdoṣapraśāntaye
]

`v 6 [
sā devī kandarānāmnī maṅgaletaranāmikā |
saṃpratiṣṭhāpitā mūrtyā pure gaganakoṭare
]

`v 7 [
p. 333) 201
tataḥprabhṛti tatratyo `note[tatrānya iti pāṭhaḥ] yo yo bhavati bhūmipaḥ
|
sa kandarāṃ bhagavatīṃ pratiṣṭhāpayati svayam
]

`v 8 [
yaḥ kandarāpratiṣṭhāṃ `note[kandarāṃ pratiṣṭhāṃ ca iti pāṭhaḥ] ca na
karoti nṛpādhamaḥ |
tasyopatāpanicayāḥ prajā nighnanti yatnataḥ
]

`v 9 [
tatpūjanādavāpnoti janastannikhilaṃ phalam |
svavāsanāvaśocchūnamanarthaṃ yātyapūjanāt
]

`v 10 [
vadhyalokopahāreṇa sā devī paripūjyate |
pratimā sā sthitādyāpi citrasthā phaladāyinī
]

`v 11 [
sakalakomalamaṅgalakāriṇī
kavalitākhilavadhyamahājanā |
jayati sātra kirātajanāspade
paramabodhavatī ciradevatā
]