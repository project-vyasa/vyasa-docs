`v 1 [
aśītitamaḥ sargaḥ 80
śrīvasiṣṭha uvāca |
mahāniśi mahāraṇye mahārākṣasakanyayā |
iti prokte mahāpraśne mahāmantrī giraṃ dadau
]

`v 2 [
mantryuvāca |
śṛṇu toyadasaṃkāśe praśnametaṃ bhinadmi te |
anukramātmakaṃ mattaṃ gajendramiva kesarī
]

`v 3 [
bhavatyā paramātmaiṣa kathitaḥ kamalekṣaṇe |
anayaiva vacobhaṅgyā praśnavidbodhayogyayā
]

`v 4 [
sarvānpraśnān śithilīkartu sarvapraśnahṛdayaṃ tāvatprathamaṃ darśayati ##-
anākhyatvādagamyatvānmanaḥṣaṣṭhendriyasthiteḥ |
cinmātramevamātmāṇurākāśādapi sūkṣmakaḥ
]

`v 5 [
cidaṇoḥ paramasyāntaḥ sadivāsadivāpi vā |
bīje'ntardrumasatteva sphuratīdaṃ jagatsthitam
]

`v 6 [
satkiṃcidanubhūtitvātsarvātmakatayā svataḥ |
tadātmakatayā pūrvaṃ bhāvāḥ sattāṃ kilāgatāḥ
]

`v 7 [
ākāśaṃ bāhyaśūnyatvādanākāśaṃ tu cittvataḥ |
atīndriyatvānno kiṃcitsa evāṇuranantakaḥ
]

`v 8 [
sarvātmakatvādbhukte ca tena kiṃcinna kiṃcana |
cidaṇoḥ pratibhā sā syādekasyānekatoditā |
asatyeva `note[asatyevāpi satyeva hemnaḥ kaṭakatā yathā iti kvācitkaḥ
pāṭhaḥ] yathā hemnaḥ kaṭakādi tathā pare
]

`v 9 [
yadi tu kiṃcidapi na kiṃcidyadātmabhāve taditi praśnārthastadāpyāha -
sarvātmakatvāditi | svasyaiva sarvātmakatvātsvātmanaiva sākṣātkṛtena
sarvasminbhukte nigīrṇe sati tadeva kiṃcit | na kiṃcanātmanā pariśiṣyata ityāśaya
ityarthaḥ | ekasyānekasaṃkhyasyeti praśnopakramābhiprāyamāha - cidaṇoriti |
ekasyaiva cidaṇostvaduditānekatāpratibhāmātra prātītikī na vāstavītyarthaḥ | etena
kaṭakādīni hemneveti praśno'pyuktaprāya evetyāśayenāha - yathā hemna iti |
8 |
eṣo'ṇuḥ paramākāśaḥ sūkṣmatvādapyalakṣitaḥ |
manaḥṣaṣṭhendriyātītaḥ sthitaḥ sarvātmako'pi san
]

`v 10 [
sarvātmakatvānnaivāsau śūnyo bhavati karhicit |
yadasti na tadastīti vaktā mantā iti smṛtaḥ
]

`v 11 [
kayācidapi yuktyeha sato'sattvaṃ na yujyate |
sarvātmā svātmaguptena karpūreṇeva dṛśyate
]

`v 12 [
cinmātrāṇu sa eveha sarvaṃ kiṃcinmanaḥsthitam |
na kiṃcidindriyātītarūpatvādamalaḥ sthitaḥ
]

`v 13 [
p. 321) 194
sa eva caiko'nekaśca sarvasattvātmavedanāt |
sa evedaṃ jagaddhatte jagatkośastathaiva hi
]

`v 14 [
imāścittamahāmbhodhau trijagallavavīcayaḥ |
prajñāstasminkacantyapsu dravatvāccakratā iva
]

`v 15 [
cittendriyādyalabhyatvātso'ṇu śūnyasvarūpavat |
svasaṃvedanalabhyatvādaśūnyaṃ vyomarūpyapi
]

`v 16 [
so'haṃ bhavāneva bhavānsaṃpanno'dvaitavedanāt |
sa bhavānna bhavennāhaṃ jāto bodhabṛhadvapuḥ
]

`v 17 [
tvaṃtāhaṃtātmakaṃ sarvaṃ vinigīryāvabodhataḥ |
na tvaṃ nāhaṃ na sarvaṃ ca sarvaṃ vā bhavati svayam
]

`v 18 [
gacchanna gacchatyeṣo'ṇuryojanaughagato'pi san |
saṃvittyā yojanaughatvaṃ tasyāṇorantare sthitam
]

`v 19 [
na gacchatyeṣa yāto'pi saṃprāpto'pi ca nāgataḥ |
svasattākāśakośāntarvāsitvāddeśakālayoḥ
]

`v 20 [
gamyaṃ yasya śarīrasthaṃ kva kilāsau prayāti hi |
kucakoṭaragaḥ putraḥ kiṃ mātrānyatra vīkṣyate
]

`v 21 [
gamyo yasya mahādeśo yāvatsaṃbhavamakṣayaḥ |
antasthaḥ sarvakarturhi sa kathaṃ kveva gacchati
]

`v 22 [
yathā deśāntaraprāpte kumbhe vakrasamudrite |
tadākāśasya gamanāgamane na tathātmanaḥ
]

`v 23 [
cittatā sthāṇutā svāntaryadā sto'nubhavātmike |
cetanasya jaḍasyaiva tadāsau dvayameva ca
]

`v 24 [
yadā cetanapāṣāṇasattaikātmaikacidvapuḥ |
tadā cetana evāsau pāṣāṇa iva rākṣasi
]

`v 25 [
paramavyomnyanādyante cinmātraparamātmanā |
vicitraṃ trijagaccitraṃ tenedamakṛtaṃ kṛtam
]

`v 26 [
tatsaṃvittyā vahnisattā tenātyaktānalākṛtiḥ |
sarvago'pyadahatyeva sa jagaddravyapāvakaḥ `note[sa sarvadravyapāvakaḥ iti
pāṭhaḥ sādhuḥ]
]

`v 27 [
prajvaladbhāsvarākārānnirmalādgaganādapi |
prajvalaccetanaikātmā tasmādagniḥ sa jāyate
]

`v 28 [
saṃvedanādyadarkādiprakāśasya prakāśakaḥ |
na naśyatyātmabhārūpo mahākalpāmbudairapi
]

`v 29 [
anetralabhyo'nubhavarūpo hṛdgṛhadīpakaḥ |
sarvasattāprado'nantaḥ prakāśaḥ paramaḥ smṛtaḥ
]

`v 30 [
pravartate'smadāloko manaḥṣaṣṭhendriyātigāt |
yenāntarāpi vastūnāṃ dṛṣṭā dṛśyacamatkṛtiḥ
]

`v 31 [
p. 322) 195
latāgulmāṅkurādīnāmanakṣāṇāṃ ca poṣakaḥ |
utsedhavedanākāraḥ prakāśo'nubhavātmakaḥ
]

`v 32 [
latāgulma ityādipraśnasyottaramāha - lateti | poṣakaḥ svasaṃnidhānena
vṛddhinimittam | utsedhasya ca tatphalasya vedanameva ākāro yasya tatsākṣiṇaḥ |
31 |
kālākāśakriyāsattā jagattatrāsti vedane |
svāmī kartā pitā bhoktā ātmatvācca na kiṃcana
]

`v 33 [
aṇutvamajahatso'ṇurjagadratnasamudgakaḥ |
mātṛmānaprameyātma jaganāstīti kevale
]

`v 34 [
ko jagadratnakośaḥ syāt ityasyottaraṃ punarāha - aṇutvamiti | samudgakaḥ
saṃpuṭakaḥ | kasya kośī maṇerjagat ityasyottaramāha - mātrityādisārdhena |
33 |
sa eva sarvajagati sarvatra kacati sphuṭam |
yadā jagatsamudre'smiṃstadāsau `note[jagatsamudre iti pāṭhaḥ] paramo
maṇiḥ
]

`v 35 [
durbodhatvāttamaḥ so'ṇuścinmātratvātprakāśadṛk |
so'sti saṃvittirūpatvādakṣātītastathā na san
]

`v 36 [
dūre so'nakṣalabhyatvāccidrūpatvānna dūragaḥ |
sarvasaṃvedanācchailo hyasāvevāṇureva san
]

`v 37 [
tatsaṃvedanamātraṃ yattadidaṃ bhāsate jagat |
na satyamasti śailādi tenāṇāveva merutā
]

`v 38 [
nimeṣapratibhāso `note[nimeṣakṛtibhāsaḥ iti pāṭhaḥ] hi nimeṣa iti
kathyate |
kalpeti pratibhāso hi kalpaśabdena kathyate
]

`v 39 [
kalpakriyāvilāso hi nimeṣaḥ pratibhāsate |
bahuyojanakoṭisthaṃ manasyeva mahāpuram
]

`v 40 [
nimeṣajaṭhare kalpasaṃbhavaḥ samudeti hi |
mahānagaranirmāṇaṃ mukure'ntarivāmale
]

`v 41 [
nimeṣakalpaśailādipūrayojanakoṭayaḥ |
yatrā'ṇāveva vidyante tatra dvaitaikyate kutaḥ
]

`v 42 [
kṛtavānprāgidamahamiti buddhāvudeti hi |
kṣaṇātsatyamasatyaṃ ca dṛṣṭāntaḥ svapnavibhramaḥ
]

`v 43 [
duḥkhe kālaḥ sudīrgho hi sukhe laghutaraḥ sadā |
rātrirdvādaśavarṣāṇi hariścandrasya coditā
]

`v 44 [
ukte'rthe lokānubhavamākhyāyikāṃ codāharati - duḥkha iti | uditā āvirbhūtā |
43 |
niścayo ya udetyantaḥ satyātmā satya eva ca |
hemnīva kaṭakāditvaṃ sa eva citi rājate
]

`v 45 [
na nimeṣo'sti no kalpo nādūraṃ na ca dūratā |
cidaṇupratibhaivaivaṃ sthitānyānyānyavastuvat `note[nānyānyavastuvat iti
pāṭhaḥ]
]

`v 46 [
prakāśatamasordūrādūrayoḥ kṣaṇakalpayoḥ |
ekaciddehayoreva na bhedo'sti manāgapi
]

`v 47 [
pratyakṣamakṣasāratvādapratyakṣaṃ tato'tigam |
dṛśyatvenaiṣa vodeti cetā draṣṭaiva sadvapuḥ
]

`v 48 [
yāvatkaṭakasaṃvittistāvanāstīva hematā |
yāvacca dṛśyatāpattistāvannāstīva sā kalā
]

`v 49 [
kaṭakatve'kṛte'dṛṣṭe suvarṇatvamivātatam |
kevalaṃ nirmalaṃ śuddhaṃ brahmaiva paridṛśyate
]

`v 50 [
sarvatvādeva sadrūpo durlakṣyatvādasadvapuḥ |
cetanaścetanātmatvāccetyāsaṃbhavatastvacit
]

`v 51 [
p. 323) 195
ciccamatkāramātrātmanyasmiṃścitpratibhātmani |
jagatyanilavṛkṣābhe ciccetyakalane kutaḥ
]

`v 52 [
yathā tāpasya pīnasya bhāsanaṃ mṛgatṛṣṇikā |
evaṃ pīvaramadvaitaṃ tathā cidbhāsanaṃ jagat
]

`v 53 [
arkāṃśubhiḥ sūkṣmataranirmāṇaṃ yadanāmayam |
astitānāstite tatra kalpāderiva kaiva dhīḥ
]

`v 54 [
māyayāṃśukaṇāṅke khe yathā kacati kāñcanam |
tathā jagadidaṃ bhāti ciccetyakalane kutaḥ
]

`v 55 [
svapnagandharvasaṃkalpanagare kuḍyavedanam |
na sannāsadyathā tadvadviddhi dīrghabhramaṃ jagat
]

`v 56 [
tathā caivaṃvidhanyāyabhāvanābhyāsanirmalāt |
cidākāśena niryāti yathā bhūtārthadarśinaḥ
]

`v 57 [
na kuḍyākāśayorbhedo dṛśyasaṃvedanādṛte |
ābrahmajīvakalanādyadrūḍhaṃ rūḍhameva ca
]

`v 58 [
pratibhāsāccidākāśe sattvaśūnyaṃ bhavanti tāḥ |
prakacanti hyanirbhāvyāḥ prabhāpiṇḍa iva prabhāḥ
]

`v 59 [
pṛthaktāmatibhāsasya svacamatkārayogataḥ |
sarvātmikā hi pratibhā parā vṛkṣātmabījavat
]

`v 60 [
evaṃ sopapatti prāsaṅgikaṃ kiṃ cetanamacetanam iti praśnottaramuktvā
śiṣṭānāṃ praśnānāmuttaraṃ rājārthe
pariśeṣayaṃstadajñānaśaṅkānivṛttaye teṣvavayutya dvitrāṇāmuttaraṃ
vivakṣurdvaitamithyātvopavarṇanaprasañjitaṃ dvaitamapyapṛthakkasmāt
ityasyottaramāha - pṛthakteti | pṛthaktāsaṃskārasaṃskṛtāyā
materbuddhivṛtteryo bhāso'ntargata ātmaprakāśastasya yaḥ svacamatkāraḥ
pṛthaktāprakaṭanaśaktilakṣaṇastadyogato dvaitaṃ pratibhātamapi
apṛthagevetyarthaḥ | tatra hetumāha - sarvātmiketi | pratibhā ātmaprakāśaḥ |
59 |
bījamantasthavṛkṣatvaṃ nānā'nānā yathaikadṛk |
tathā'saṃkhyajagadbrahma śāntamākāśakośavat
]

`v 61 [
vṛkṣātmabījavaditi dṛṣṭāntaṃ vivṛṇvan ko'ntarbījamivāntasthaṃ sthitaḥ
kṛtvā trikālagaḥ ityasyottaramāha - bījamiti | ekadṛk ekarūpaṃ bījaṃ nānā
pṛthagbhūtaṃ anānā apṛthagbhūtaṃ ca antasthavṛkṣatvaṃ
antargatavṛkṣākāraṃ kṛtvā sthitaṃ tathā brahmāpyasaṃkhyajagadityarthaḥ |
60 |
bījasyāntasthavṛkṣasya vyomādvaitā sthitiryathā |
brahmaṇo'ntasthajagataḥ sākṣitvāccitsthitistathā
]

`v 62 [
śāntaṃ samastamajamekamanādimadhyaṃ
nehāsti kācana kalākalanā kathaṃcit |
nirdvandvaśāntamatirekamanekamaccha-
mābhāsarūpamajamekavikāsamāste
]