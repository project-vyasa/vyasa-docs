`v 1 [
navatitamaḥ sargaḥ 90
bhānuruvāca |
athendreṇaivamukto'sau rājā rājīvalocanaḥ |
muniṃ bharatanāmānaṃ pārśvasaṃsthamuvāca ha
]

`v 2 [
rājovāca |
bhagavansarvadharmajña paśyāmi sudurātmanaḥ |
bhṛśamasya mukhe sphāraṃ dhārṣṭyaṃ maddārahāriṇaḥ
]

`v 3 [
pāpānurūpamasyāśu śāpaṃ dehi mahāmune |
yadavadhyavadhātpāpaṃ vadhyatyāgāttadeva hi
]

`v 4 [
ityukto rājasoṃhena bharato munisattamaḥ |
yathāvatpravicāryāśu pāpaṃ tasya durātmanaḥ
]

`v 5 [
sahānayā duṣkṛtinyā bhartṛdrohābhibhūtayā |
vināśaṃ vraja durbuddhe iti śāpaṃ visṛṣṭavān
]

`v 6 [
tatastau rājabharatau pratyūcaturidaṃ vacaḥ |
sudurmatī yuvāṃ yābhyāṃ kṣapitaṃ duścaraṃ tapaḥ
]

`v 7 [
anena śāpadānena kiṃcidbhavati nāvayoḥ |
dehe naṣṭe na nau kiṃcinnaśyati svāntarūpayoḥ
]

`v 8 [
svāntaṃ hi nahi kenāpi śakyate nāśituṃ kvacit |
sūkṣmatvāccinmayatvācca durlakṣyatvācca viddhi nau
]

`v 9 [
śrībhānuruvāca |
sughanasnehasaṃbaddhamanaskāveva śāpataḥ |
patitau bhūtale vṛkṣavicyutāviva pallavau
]

`v 10 [
atha vyasanasaṃsaktau mṛgayonimupāgatau |
tato dvāvapi saṃsaktau bhūyo jātau vihaṃgamau
]

`v 11 [
athāsmākaṃ vibho sarge mithaḥsaṃbandhabhāvanau |
tapaḥparau mahāpuṇyau jātau brāhmaṇadampatī
]

`v 12 [
bhārato'pi tayoḥ śāpaḥ sa samartho babhūva ha |
śarīramātrākramaṇe na manonigrahe prabho
]

`v 13 [
p. 345) 207
tāvadyāpi hi tenaiva mohasaṃskārahetunā |
yatra yatra prajāyete bhavatastatra dampatī
]

`v 14 [
akṛtrimapremarasānuviddhaṃ
snehaṃ tayostaṃ prativīkṣya kāntam |
vṛkṣā api premarasānuviddhāḥ
śṛṅgāraceṣṭākulitā bhavanti
]