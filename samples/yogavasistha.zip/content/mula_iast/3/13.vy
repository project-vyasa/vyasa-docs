`v 1 [
p. 159)
trayodaśaḥ sargaḥ
śrīvasiṣṭha uvāca |
parame brahmaṇi sphāre same rāma samasthite |
anutpannanabhastejastamaḥsattā cidātmani
]

`v 2 [
pūrvaṃ cetyatvakalanaṃ sataścetyāṃśacetanāt |
udeti cittakalanaṃ citiśaktitvacetanāt
]

`v 3 [
tato jīvatvakalanaṃ cetyasaṃyogacetanāt |
tato'sya `note[tato'haṃbhāvakalanaṃ iti pāṭhaḥ] māyākalanaṃ
cetyaikaparatāvaśāt
]

`v 4 [
tato buddhitvakalanamahantāpariṇāmataḥ |
etadeva manastādiśabdatanmātrakādimat
]

`v 5 [
ucchūnādanyatanmātrabhāvanādbhūtarūpiṇaḥ `note[bhāvanodbhūta iti
pāṭhaḥ] |
ayamitthaṃ mahāgulmo jagadādirvilokyate
]

`v 6 [
jhaṭityevaṃ krameṇeti svapne puramivākṛtam |
mahākāśamahāṭavyāmudbhūyodbhūya naśyati
]

`v 7 [
jagatkarañjakuñjānāṃ bījametadvāpajam |
nāpekṣate kiṃcidapi kṣitivāryanalādikam
]

`v 8 [
etaccidātmakaṃ paścātkilorvyādi kariṣyati |
svaṃ svapnavitpuramiva cinmātrāmakameva yat
]

`v 9 [
jagadādyaṅkuraṃ yatra tatrasthamapi muñcati |
jagataḥ pañcakaṃ bījaṃ pañcakasya cidavyayā
]

`v 10 [
yadbījaṃ tatphalaṃ viddhi tasmādbrahmamayaṃ jagat |
evameṣa mahākāśe sargādau pañcako gaṇaḥ
]

`v 11 [
cicchaktyā svāṅgabhūtātmā kalpitosti na vāstavaḥ |
anenocchūnatāmetya yadapīdaṃ vitanyate
]

`v 12 [
tadapyākāśarūpātmakalpanātmani sanmayam |
kvacinna nāma tatsiddhaṃ yadasiddhena sādhyate
]

`v 13 [
svarūpaṃ yadvikalpātma kathaṃ tatsatyatāmiyāt |
atha cetpañcakaṃ brahma brahmātmakatayā dhiyā
]

`v 14 [
tatpañcakaṃ viddhi prauḍho brahmaiva trijagatkramaḥ |
yathā sphurati sargādāveṣa pañcakasaṃbhavaḥ
]

`v 15 [
tathaivādyeha bhūtatve yāti kāraṇatāṃ svayam |
evaṃ na jāyate kiṃcijjagajjātaṃ `note[jātaṃ tu iti pāṭhaḥ] na lakṣyate |
15 |
bhūtatve paurvakālikatve | svayaṃ auttarakālikaṃ svaṃ pratyeveti śeṣaḥ |
upasaṃharati - evamiti
]

`v 16 [
svapnasaṃkalpapuravadasatsadanubhūyate |
brahmākāśaparākāśe jīvākāśatvamātmani
]

`v 17 [
iti cityavadātātmā pṛthvyādīnāmasaṃbhavāt |
ityeṣa jīvaḥ kathito vyomni khātmā ivoditaḥ
]

`v 18 [
p. 160)
jīvākāśastvimaṃ dehaṃ yathā vindati tacchṛṇu |
jīvākāśaḥ svamevāsau tasmiṃstu parameśvare
]

`v 19 [
aṇutejaḥkaṇo'smīti svayaṃ cetati cintayā |
yattadevocchūnamiva `note[ucchūnyabhāvaṃ iti pāṭhaḥ]
bhāvayatyātmanāmbare
]

`v 20 [
asadeva sadākāraṃ saṃkalpenduryathā na san |
tameva bhāvayan draṣṭṛdṛśyarūpatayā sthitaḥ
]

`v 21 [
eka eva dvitāmeti svapne svamṛtibodhavat |
kiṃcitsthaulyamivādatte tatastārakatāṃ vian
]

`v 22 [
yathābhāvitamātrārthabhāvitādviśvarūpataḥ `note[bhāvitvādyatsvarūpataḥ
iti pāṭhaḥ] |
sa eva svātmā satato'pyayaṃ sohamiti svayam
]

`v 23 [
cittātpratyayamādhatte svapne svāmiva pānthatām |
tārakākāramākāraṃ bhāvidehābhidhaṃ tathā
]

`v 24 [
bhāvayatyeti `note[bhāvayanyāti iti pāṭhaḥ] tadbhāvaṃ cittaṃ
cetyārthatāmiva |
parityajyaiva tadbāhyaṃ tatastārakakoṭare
]

`v 25 [
antarbhāti bahiṣṭho'pi parvato mukure yathā |
kūpasaṃstho yathā dehaḥ samudgakagataṃ vacaḥ
]

`v 26 [
svapnasaṃkalpayoḥ saṃvidvettyetajjivako'ṇuke `note[vettyevaṃ jīvaka iti
pāṭhaḥ] |
svarūpatārakāntastho jīvo'yaṃ cetati svayam
]

`v 27 [
tadetadbuddhicittādijñānasattādirūpakam |
jīvākāśaḥ `note[jīvākāśastatastatreti pāṭhaḥ] svatastatra
tārakākāśakośagam
]

`v 28 [
prekṣe'hamiti bhāvena draṣṭuṃ prasaratīva khe |
tato randhradvayenaiva bhāvibāhyābhidhaṃ punaḥ
]

`v 29 [
yena paśyati tannetrayugaṃ nāmnā bhaviṣyati |
yena spṛśati sā vai tvagyacchṛṇoti śrutistu sā
]

`v 30 [
yena jighrati tadghrāṇaṃ sa svamātmani paśyati |
tattasya svadanaṃ paścādrasanā collasiṣyati
]

`v 31 [
spandate yatsa tadbāyuśceṣṭā karmendriyavrajam |
rūpālokamanaskārajātamityapi bhāvayat
]

`v 32 [
ātivāhikadehātmā tiṣṭhatyambaramambare |
evamucchūnatāṃ tasminbhāvayaṃstejasaḥ `note[bhāvavattejasaḥ iti
pāṭhaḥ] kaṇe
]

`v 33 [
asatyāṃ satyasaṃkāśāṃ brahmāste jīvaśabdavat |
itthaṃ sa jīvaśabdārthaḥ kalanākulatāṃ gataḥ
]

`v 34 [
ātivāhikadehātmā cittadehāmbarākṛtiḥ |
svakalpanānta ākāramaṇḍaṃ saṃsthaṃ prapaśyati
]

`v 35 [
kaścijjalagataṃ vetti kaścitsamrāṭsvarūpiṇam |
bhāvibrahmāṇḍakalanāṃ paśyatyanubhavatyapi
]

`v 36 [
tasyaiva jalāntargatabrahmāṇḍaśarīrāhaṃbhāvavedanaṃ
tadantaścaturmukhaśarīrāhaṃbhāvavedanaṃ ceti dvaividhyamāha - kaściditi |
35 |
p. 161)
ātmagarbhagṛhaṃ cittādyathāsaṃkalpamātmanaḥ |
deśakālakriyādravyakalpanāvedanaṃ sa tat
]

`v 37 [
bhāvayañchabdanirmātā śabdairbadhnāti kalpitaiḥ |
ātivāhikadeho'sāvityasatyajagadbhrame
]

`v 38 [
asatya eva kacati svapne khoḍḍayanaṃ yathā |
ityanutpanna evāsau svayaṃbhuḥ svayamutthitaḥ
]

`v 39 [
upapāditāyā utpattyākhyāyikāyāḥ prastutopayogamāha - ityanutpanna iti | 38
|
ātivāhikadehātmā prabhurādyaḥ prajāpatiḥ |
etasminnapi saṃpanne brahmāṇḍākāriṇi bhrame
]

`v 40 [
na kiṃcidapi saṃpannaṃ na ca jātaṃ na dṛśyate |
tadbrahmākāśamākāśameva sthitamanantakam
]

`v 41 [
saṃkalpanagarākārametatsadapi naiva sat |
anirmitamarāgaṃ ca etadvai `note[etat khe citraṃ iti pāṭhaḥ]
citramutthitam
]

`v 42 [
akṛtaṃ cānubhūtaṃ ca na satyaṃ satyavatsthitam |
mahākalpe vimuktatvādbrahmādīnāmasaṃśayam
]

`v 43 [
smṛtirna prāktanī kācitkāraṇaṃ vā svayaṃbhuvaḥ |
tena yādṛksvayaṃbhūḥ syāttādṛktajjamidaṃ smṛtam
]

`v 44 [
anādyanubhavastvitthaṃ yo'trāsti `note[yo'vāstyavanikādike iti pāṭhaḥ]
vanikādike |
svapnānubhūtaṃ pṛthvyādi prabodhe yādṛśaṃ bhavet
]

`v 45 [
smṛtaḥ sa vyomamātrātmā sarvadaiva smṛtaṃ jagat |
yatra yatra yathā toye dravatvaṃ nāma bhidyate
]

`v 46 [
tatra tatra tathā nānyaḥ sargo'sti paramātmani |
sṛṣṭirevamiyaṃ prauḍhā sama eva tvayaṃ sthitaḥ
]

`v 47 [
bhātyevaṃ nāma brahmāṇḍaṃ vyomātmevātinirmalam |
dṛśyamevamidaṃ śāntaṃ svātmanirmitavibhramam
]

`v 48 [
nirādhāraṃ nirādheyamadvaitaṃ caikyavarjitam |
jagatsaṃvidi jātāyāmapi jātaṃ na kiṃcana
]

`v 49 [
paramākāśamāśūnyamacchameva vyavasthitam |
sarvasaṃsāratā nāsti yadeva tadavasthitam
]

`v 50 [
nādheyaṃ tatra nādhāro na dṛśyaṃ na ca draṣṭṛtā |
brahmāṇḍaṃ nāsti na brahmā na ca vaitaṇḍikā kvacit
]

`v 51 [
na jagannāpi jagatī śāntamevākhilaṃ sthitam |
brahmaiva kacati svacchamitthamātmātmanātmani
]

`v 52 [
cittvāddravatvātsalilamivāvartatayātmani |
asadevedamābhāti sadivehānubhūyate
]

`v 53 [
vinaśyatyasadevānte svapne svamaraṇaṃ yathā |
athavā svasvarūpatvātsadevedamanāmayam |
akhaṇḍitamanādyantaṃ jñānamātrāmbarodaram
]

`v 54 [
ākāśa eva parame prathamaḥ prajeśo
nityaṃ svayaṃ kacati śūnyatayā samo yaḥ |
sa hyātivāhikavapurnatu bhūtarūpī
pṛthvyādi tena na sadasti yathā `note[tathā na iti pāṭhaḥ] na jātam
]