`v 1 [
ṣaṣṭhaḥ sargaḥ 6
śrīvasiṣṭha uvāca |
asya devādhidevasya parasya paramātmanaḥ |
jñānādeva parā siddhirna tvanuṣṭhānaduḥkhataḥ
]

`v 2 [
atra jñānamanuṣṭhānaṃ natvanyadupayujyate |
mṛgatṛṣṇājalabhrāntiśāntau cedaṃ nirūpitam
]

`v 3 [
nahyeṣa dūre nābhyāśe nālabhyo viṣame na ca |
svānandābhāsarūpo'sau svadehādeva labhyate
]

`v 4 [
nātidūre nātisaṃnihite kriyāmantareṇālabhye viṣamādisthe ca phale kriyā saphalā
syādātmā tu na tatheti tasya na kriyālabhyatetyāha - nahīti |
vismṛtakaṇṭhacāmīkaravajjñānalabhyatā tvasya sulabhetyāha - svānandeti |
3 |
kiṃcinnopakarotyatra tapodānavratādikam |
svabhāvamātre viśrāntimṛte nātrāsti sādhanam
]

`v 5 [
sādhusaṃgamasacchāstraparataivātra kāraṇam |
sādhanaṃ bādhanaṃ mohajālasya yadakṛtrimam
]

`v 6 [
ayaṃ sadeva ityeva saṃparijñānamātrataḥ |
jantorna jāyate duḥkhaṃ jīvanmuktatvameti ca
]

`v 7 [
duḥkhanivṛttau jīvanmuktau vā tarhi sādhanāntaraṃ syāttatrāha - ayamiti | 6
|
śrīrāma uvāca |
saṃparijñātamātreṇa kilānenātmanātmanā `note[mātmanaḥ iti pāṭhaḥ]
|
punardoṣā na bādhante maraṇādyāḥ kadācana `note[kathaṃcana iti
pāṭhaḥ]
]

`v 8 [
devadevo mahāneṣa kuto dūrādavāpyate |
tapasā kena tīvreṇa kleśena kiyatāthavā
]

`v 9 [
śrīvasiṣṭha uvāca |
svapauruṣaprayatnena vivekena vikāsinā |
sa devo jñāyate rāma na tapaḥsnānakarmabhiḥ
]

`v 10 [
rāgadveṣatamaḥkrodhamadamātsaryavarjanam |
vinā rāma tapodānaṃ kleśa eva na vāstavam
]

`v 11 [
rāgādyupahṛte `note[dyupagate iti pāṭhaḥ] citte vañcayitvā paraṃ
dhanam |
yadarjyate tasya dānādyasyārthāstasya tatphalam
]

`v 12 [
p. 142)
rāgādyupahate citte vratādi kriyate ca yat |
taddambhaḥ procyate tasya phalamasti manāṅga ca
]

`v 13 [
tasmātpuruṣayatnena mukhyamauṣadhamāharet |
sacchāstrasajjanāsaṅgau saṃsṛtivyādhināśanau
]

`v 14 [
atraikaṃ pauruṣaṃ yatnaṃ varjayitvetarā gatiḥ |
sarvaduḥkhakṣayaprāptau na kācidupapadyate
]

`v 15 [
śṛṇu tatpauruṣaṃ kīdṛgātmajñānasya labdhaye |
yena śāmyatyaśeṣeṇa rāgadveṣaviṣūcikā
]

`v 16 [
yathāsaṃbhavayā vṛttyā lokaśāstrāviruddhayā |
saṃtoṣasaṃtuṣṭamanā bhogagandhaṃ parityajet
]

`v 17 [
yathāsaṃbhavamudyogādanudvignatayā svayā |
sādhusaṃgamasacchāstraparatāṃ prathamaṃ śrayet
]

`v 18 [
yathāprāptārthasaṃtuṣṭo yo garhitamupekṣate |
sādhusaṃgamasacchāstraparaḥ śīghraṃ sa mucyate
]

`v 19 [
vicāreṇa parijñātasvabhāvasya mahāmateḥ |
anukampyā bhavantyete brahmaviṣṇvindraśaṃkarāḥ
]

`v 20 [
deśe yaṃ sujanaprāyā lokāḥ sādhuṃ pracakṣate |
sa viśiṣṭaḥ sa sādhuḥ syāttaṃ prayatnena saṃśrayet
]

`v 21 [
sādhuṃ lakṣayati - deśa iti | sujanāḥ
śrutismṛtyācāraniṣṭhāstatprāyāstatpracurā lokā janāṃ yaṃ pracakṣate sa
cedviśiṣṭairjñānavairāgyādiguṇaiḥ sahitaḥ syāttarhi sa sādhuḥ syādityarthaḥ |
20 |
adhyātmavidyā vidyānāṃ pradhānaṃ tatkathāśrayam |
śāstraṃ sacchāstramityāhurmucyate tadvicāraṇāt
]

`v 22 [
sacchāstrasatsaṃgamajairvivekai-
stathā vinaśyanti balādavidyāḥ |
yathā jalānāṃ katakānuṣaṅgā-
dyathā janānāṃ matayo'pi `note[matayaśca iti pāṭhaḥ] yogāt
]