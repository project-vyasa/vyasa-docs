`v 1 [
saptāśītitamaḥ sargaḥ 87
bhānuruvāca |
pitāmahakrame tasmiṃstataste bahubhāvanāt |
karmabhistaiḥ samākrāntamanaskāstasthurādṛtāḥ
]

`v 2 [
yāvatte dehakāsteṣāṃ tāpena pavanaistathā |
kālena śoṣamabhyetya galitāḥ śīrṇaparṇavat
]

`v 3 [
jakṣustāndehakāṃstatra kravyādā vanavāsinaḥ |
itaścetaśca luṭhitānsuphalānīva markaṭāḥ
]

`v 4 [
atha te śāntabāhyārthā brahmatve kṛtabhāvanāḥ |
tasthuścaturyugasyānte yāvatkalpaḥ kṣayaṃ gataḥ
]

`v 5 [
kṣīyamāṇe tataḥ kalpe tapatyādityasaṃcaye |
puṣkarāvartakeṣūccairvarṣatsu kaṭhināravam
]

`v 6 [
vahatsu kalpavāteṣu sthita ekamahārṇave |
kṣīṇeṣu bhūtavṛndeṣu te tathaiva vyavasthitāḥ
]

`v 7 [
tato rātrikramapare sarvāṃ saṃhṛtya tāṃ sthitim |
sthite tvayyātmani vibho te tathaiva vyavasthitāḥ
]

`v 8 [
adya prabuddhe bhavati sraṣṭumicchati saṃsṛtim |
sukhenaiva krameṇoccaiste tathaiva vyavasthitāḥ
]

`v 9 [
tathaite bhagavanbrahmanbrahmaṇo brāhmaṇā daśa |
ta ete daśa saṃsārā manovyomani saṃsthitāḥ
]

`v 10 [
teṣāmekatamasyāhamayamākāśamandire |
bhānurbhuvi vibho kālakalākarmaṇi yojitaḥ
]

`v 11 [
eṣa te kathitaḥ sargo diśānāmabjasaṃbhava |
brahmaṇāṃ saṃbhavo vyomni yathecchasi tathā kuru
]

`v 12 [
eṣu sargeṣu satsvapi na tava sarge ko'pi virodha ityāśayenāha - yathecchasīti |
11 |
vividhakalpanayā valitāmbaraṃ
yadidamuttama jāgatamutthitam |
karaṇajālakamāhitamohanaṃ
tadakhilaṃ nijacetasi vibhramaḥ
]