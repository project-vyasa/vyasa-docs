`v 1 [
saptacatvāriṃśaḥ sargaḥ 47
śrīvasiṣṭha uvāca |
etasminvartamāne tu ghore samarasaṃgame |
līlādvayamuvācedaṃ jñaptiṃ bhagavatīṃ punaḥ
]

`v 2 [
līlādvayamuvāca |
devi kasmādakasmānnau bhartā jayati no raṇe |
vada tvayyapi tuṣṭāyāmasminvidrutavāraṇe
]

`v 3 [
śrīsarasvatyuvāca |
ciramārādhitānena vidūrathanṛpāriṇā |
ahaṃ putri jayārthena na vidūrathabhūbhṛtā
]

`v 4 [
tenāsāveva jayati jīyate ca vidūrathaḥ |
jñaptirantargatā saṃvidetāṃ māṃ yo yadā yathā
]

`v 5 [
prerayatyāśu tattasya tadā saṃpādayāmyaham |
yo yathā prerayati māṃ tasya tiṣṭhāmi tatphalā
]

`v 6 [
na svabhāvo'nyatāṃ dhatte vahnerauṣṇyamivaiṣa me |
anena mukta eva syāmahamityasmi bhāvitā
]

`v 7 [
pratibhārūpiṇī tena bāle mukto bhaviṣyati |
etadīyaḥ svayaṃ śatruḥ sindhurnāma mahīpatiḥ
]

`v 8 [
jayāmyahaṃ syāṃ saṃgrāma ityanenāsmi pūjitā |
tasmādvidūratho dehaṃ tatprāpya saha bhāryayā
]

`v 9 [
tvayānayā ca kālena vāle mukto bhaviṣyati |
etadīyaḥ svayaṃ śatruḥ sindhurnāma mahīpatiḥ
]

`v 10 [
hatvainaṃ vasudhāpīṭhe jayī rājyaṃ kariṣyati `note[bhaviṣyati iti pāṭhaḥ]
|
śrīvasiṣṭha uvāca |
evaṃ devyāṃ vadantyāṃ tu balayoryudhyamānayoḥ
]

`v 11 [
ravirdraṣṭumivāścaryamājagāmodayācalam |
celustimirasaṃghātā balānīvārirūpiṇaḥ
]

`v 12 [
asṛjanjīvasaṅghānye saṃdhyāyāṃ tārakā iva |
śanaiḥ prakaṭatāṃ jagmurnīlākāśādribhūmayaḥ `note[bilākāśādri iti
mudritapustake pāṭhaḥ]
]

`v 13 [
bhuvanaṃ kajjalāmbhodherivotkṣiptamarājata |
petuḥ kanakaniḥsyandasundarā raviraśmayaḥ
]

`v 14 [
śaileṣu varavīreṣu raṇe raktacchaṭā iva |
adṛśyata tato vyoma tathā raṇamahītalam
]

`v 15 [
bāhubhirbhrāntabhujagaṃ prabhābhiḥ kīrṇakāñcanam |
kuṇḍalaiḥ kīrṇaratnaughaṃ śirobhirdṛṣṭapaṅkajam
]

`v 16 [
āyudhaiḥ khaḍganīrandhraṃ śaraiḥ śalabhanirbharam |
raktābhāsthirasaṃdhyāḍhyaṃ sasiddhapuruṣaṃ śavaiḥ
]

`v 17 [
p. 244) 147
hāraiḥ sasarpanirmokaṃ kaṭairiddhaṃ susaṃkulam |
lasallataṃ patākābhirurubhiḥ kṛtatoraṇam
]

`v 18 [
hastaiḥ pādaiḥ pallavitaṃ śaraiḥ śaravaṇopamam |
śastrāṃśuśādvalaśyāmaṃ śastrapūraiḥ sakaitakam
]

`v 19 [
kīrṇamāyudhamālābhirunmattamiva bhairavam |
phullāśokavanākāraṃ śastrasaṃghaṭṭavahnibhiḥ
]

`v 20 [
udaghuṃghumahāśabdairvidravatsiddhanāyakaiḥ |
sauvarṇanagarākāraṃ bālārkakacitāyudhaiḥ
]

`v 21 [
prāsāsiśakticakrarṣṭimudgarāraṇitāmbaram |
vahadraktanadīraṃhaḥprohyamānaśavotkaram
]

`v 22 [
bhuśuṇḍīśaktikuntāsiśūlapāṣāṇasaṃkulam |
śūlaśastrāhaticchannakabandhapatanānvitam
]

`v 23 [
kālatāṇḍavavetālakulārabdhahalāravam |
śūnye raṇāṅgaṇe dīptau padmasindhvo rathau calau
]

`v 24 [
adṛśyetāṃ nabhaścihnau candrasūryau divīva tau |
cakraśūlabhuśuṇḍyṛṣṭiprāsāyudhasamākulau
]

`v 25 [
sahasreṇa sahasreṇa vīrāṇāṃ parivāritau |
vicarantau yathākāmaṃ maṇḍalairvitatāravaiḥ
]

`v 26 [
sacītkāramahācakrapiṣṭānekamṛtāmṛtau |
tarantau raktasaritau mattavāraṇalīlayā
]

`v 27 [
keśaśaivalasaṃpanne cakracakrajalenduke |
vahaccakrāhatikṣobhapātitākulavāraṇau
]

`v 28 [
maṇimuktājhaṇatkāraraṇatkūbarakāravau |
vātāhatapatākāgrapaṭatpaṭapaṭāravau
]

`v 29 [
anuyātau mahāvīrairbhūribhirbhīrusainikaiḥ |
dhārā vamadbhiḥ kuntānāṃ śarāṇāṃ dhanuṣāmapi
]

`v 30 [
śaktīnāṃ prāsaśaṅkūnāṃ cakrāṇāṃ kacatāṃ raṇe |
tatra tau kṣaṇamāvṛtya maṇḍale bhūmikuṇḍale
]

`v 31 [
ubhau vyatibabhūvāte saṃmukhāvāyudhāvubhau |
nārācadhārānikaravikṣepakarakadhvanau
]

`v 32 [
anyonyamapi garjantau mattabdhijaladāviva |
tayoḥ praharatorbāṇā vasudhānarasiṃhayoḥ
]

`v 33 [
pāṣāṇamusalākārā vyomavistāriṇo'bhavan |
karavālamukhāḥ kecinmudgarānanakāḥ pare
]

`v 34 [
śitacakramukhāḥ kecitkecitparaśuvakrakāḥ |
kecicchaktimukhāḥ kecitkecicchūlaśilāmukhāḥ |
triśūlavadanāḥ kecitsthūlā iva mahāśilāḥ
]

`v 35 [
pralayapavanapātitāḥ śilaughā
iva nipatanti śilīmukhāstadā sma |
pramilitamabhavattayostadānīṃ
pralayavijṛmbhitasindhusaṃbhrameṇa
]