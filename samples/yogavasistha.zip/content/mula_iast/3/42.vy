`v 1 [
pañcamadinam |
dvicatvāriṃśaḥ sargaḥ 42
śrīvasiṣṭha uvāca |
yastvabuddhamatirmūḍho rūḍho na vitate pade |
vajrasāramidaṃ tasya jagadastyasadeva sat
]

`v 2 [
yathā bālasya vetālo mṛtiparyantaduḥkhadaḥ |
asadeva sadākāraṃ tathā mūḍhamaterjagat
]

`v 3 [
tāpa eva yathā vāri mṛgāṇāṃ bhramakāraṇam |
asatyameva satyābhaṃ tathā mūḍhamaterjagat
]

`v 4 [
yathā svapnamṛtirjantorasatyā satyarūpiṇī |
arthakriyākarī bhāti tathā mūḍhadhiyāṃ jagat
]

`v 5 [
avyutpannasya kanake kānake kaṭake yathā |
kaṭakajñaptirevāsti na manāgapi hemadhīḥ
]

`v 6 [
tathā'jñasya purāgāranaganāgendrabhāsurā `note[bhāsvarā iti pāṭhaḥ] |
iyaṃ dṛśyadṛgevāsti natvanyā paramārthadṛk
]

`v 7 [
yathā nabhasi muktālīpicchakeśoṇḍrakādayaḥ |
asatyāḥ satyatāṃ yātā bhātyevaṃ durdṛśāṃ jagat
]

`v 8 [
p. 233)
dīrghasvanamidaṃ viśvaṃ viddhyahantādisaṃyutam |
atrānye svapnapuruṣā yathā satyāstathā śṛṇu
]

`v 9 [
asti sarvagataṃ śāntaṃ paramārthaghanaṃ śuci |
acetyacinmātravapuḥ paramākāśamātatam
]

`v 10 [
tatsarvagaṃ sarvaśakti sarvaṃ sarvātmakaṃ svayam |
yatra yatra yathodeti tathāste tatra tatra vai
]

`v 11 [
tena svapnapure draṣṭā yānvetti puravāsinaḥ |
narāniti narā eva kṣaṇāttasya bhavanti te
]

`v 12 [
yaddraṣṭuścitsvarūpaṃ tatsvapnākāśāntarasthitam |
svapnākāśacittābhaṃ hi narānāmeti bhāvitam
]

`v 13 [
veditṛtvaikyavaśato naratevāvabudhyate |
ātmanyataścidbalena dvayorapyeti satyatā
]

`v 14 [
śrīrāma uvāca |
svapne'pi svapnapuruṣā na satyāḥ syurmune yadi |
vada tatko bhaveddoṣo māyāmātraśarīriṇi
]

`v 15 [
śrīvasiṣṭha uvāca |
svapne na puravāstavyā vastutaḥ satyarūpiṇaḥ |
pramāṇamatra śṛṇu me pratyakṣaṃ nāma netarat
]

`v 16 [
sargādāvātmabhūrbhāti svapnābhānubhavātmakaḥ |
tatsaṃkalpakalaṃ `note[kalāviśvaṃ iti pāṭhaḥ] viśvamevaṃ
svapnābhameva tat
]

`v 17 [
evaṃ viśvamidaṃ svapnastatra satyaṃ bhavānmama |
yathaiva tvaṃ tathaivānye svapne svapnavarā nṛṇām
]

`v 18 [
svapne nagaravāstavyāḥ satyā na syurime yadi |
tadihāpi tadākāre na satyaṃ me manāgapi
]

`v 19 [
yathāhaṃ tava satyātmā satyaṃ sarvaṃ bhavenmama |
svapnopalambhe saṃsāre mithaḥ siddhyai pramedṛśī
]

`v 20 [
saṃsāre vipule svapne yathā satyamahaṃ tava |
yathā tvamapi me satyaṃ sarvaṃ svapneṣviti kramaḥ
]

`v 21 [
śrīrāma uvāca |
svapnadraṣṭari nirnidre taddraṣṭuḥ svapnapattanam |
sadrūpatvāttathaivāste mameti bhagavanmatiḥ
]

`v 22 [
śrīvasiṣṭha uvāca |
evametattathaivāste satyatvātsvapnapattanam |
svapnadraṣṭari nirnidre'pyākāśaviśadākṛti
]

`v 23 [
etadāstāmidaṃ tāvadyajjāgradiva manyase |
viddhi tatsvapnamevāntardeśakālādyapūrakam
]

`v 24 [
p. 234)
evaṃ sarvamidaṃ bhāti na satyaṃ satyavasthitam |
rañjayatyapi mithyaiva svapnastrīsuratopamam
]

`v 25 [
evamadhiṣṭhānasattayā satyatve'pi sarvadeśakālādyapūrakatvānna svatastatheti
mithyātvamubhayoḥ samamityāha - evamiti | rañjayati svāsaktyā mohayati | 24
|
sarvatra vidyate sarvaṃ dehasyāntarbahistathā |
yattu vetti yathā saṃvittattathā svaiva paśyati
]

`v 26 [
yatkośe vidyate dravyaṃ taddraṣṭrā labhyate yathā |
tathāsti sarvaṃ cidvyomni cetyate tattvanena vai
]

`v 27 [
anantaramuvācedaṃ devī jñaptirvidūratham |
kṛtvā bodhāmṛtāsekairvivekāṅkurasundaram
]

`v 28 [
evamutkathaṃ rāmaṃ samādhāya prastutakathāmālambyāha - anantaramiti | 27
|
etadeva mayā rājaṁllīlārthamupavarṇitam |
svasti te'stu gamiṣyāvo dṛṣṭā dṛṣṭāntadṛṣṭayaḥ
]

`v 29 [
śrīvasiṣṭha uvāca |
iti prokte sarasvatyā girā madhuravarṇayā |
uvāca vacanaṃ dhīmānbhūmipālo vidūrathaḥ
]

`v 30 [
vidūratha uvāca |
mamāpi darśanaṃ devi moghaṃ bhavati nārthini |
mahāphalapradāyāstu kathaṃ tava bhaviṣyati
]

`v 31 [
ahaṃ dehaṃ samutsṛjya lokāntaramito'param |
nijamāyāmi he devi svapnātsvapnāntaraṃ yathā
]

`v 32 [
paśyādiśāśu māṃ mātaḥ prapannaṃ śaraṇāgatam |
bhakte'vahelā varade mahatāṃ na virājate
]

`v 33 [
paśya kṛpādṛṣṭyā | ādiśa prayaccha matprārthitamupadeśottarakāryaṃ ca |
32 |
yaṃ pradeśamahaṃ yāmi tamevāyātvayaṃ mama |
mantrī kumārī caiveyaṃ bāleti kuru me dayām
]

`v 34 [
śrīsarasvatyuvāca |
āgaccha rājyamucitārthavilāsacāru
prāgjanmamaṇḍalapate kuru nirviśaṅkam |
asmābhirarthijanakāmanirākṛtirhi
dṛṣṭā na kācana kadācidapīti viddhi
]