`v 1 [
caturuttaraśatatamaḥ sargaḥ 104
śrīvasiṣṭha uvāca |
atra te śṛṇu vakṣyāmi vṛttāntamimamuttamam |
jāgatīhendrajālaśrīścittāyattā yathā sthitā
]

`v 2 [
astyasminvasudhāpīṭhe nānāvanasamākulaḥ |
uttarāpāṇḍavo nāma sphīto janapado mahān
]

`v 3 [
nīrandhraghanagambhīravanaviśrāntatāpasaḥ |
vidyādharīkṛtalatādolopavanapattanaḥ
]

`v 4 [
vātodbhūtābjakiñjalkapuñjapiñjaraparvataḥ `note[vātodbhūta iti kvacit]
|
lasatkusumasaṃbhāravanamālāvataṃsakaḥ
]

`v 5 [
karañjamañjarīkuñjagucchaparyantajaṅgalaḥ |
kharjūrāntaritagrāmo ghuṃghumadhvanitāmbaraḥ
]

`v 6 [
p. 373) 221
ekapiṅgaśilāśreṇīśālikedārapiṅgalaḥ |
nīlakaṇṭhāravoddāmavanajaṅgalamaṇḍitaḥ
]

`v 7 [
sārasāravasaṃrambharaṇatkanakakānanaḥ |
tamālapāṭalīnīlagirigrāmakakuṇḍalaḥ
]

`v 8 [
vicitravihagavyūhavirāvakṛtakākaliḥ |
nadīparisaronnidrapāribhadradrumāruṇaḥ
]

`v 9 [
gāyatkalamakedāradārikāhṛtamanmathaḥ |
puṣpaphalacaladvātavyādhūtakusumāmbudaḥ
]

`v 10 [
darīgṛhaviniṣkrāntasiddhacāraṇabandikam |
svargādiva samānīya lāvaṇyamabhinirmitaḥ
]

`v 11 [
gāyatkinnaragandharvakadalīkhaṇḍamaṇḍapaḥ |
mandānilaravodbhūtaḥ puṣpopavanapāṇḍuraḥ
]

`v 12 [
tatrāsti lavaṇo nāma rājā paramadhārmikaḥ |
hariścandrakulodbhūto bhūmāviva divākaraḥ
]

`v 13 [
yadyaśaḥkusumottaṃsapāṇḍuraskandhamaṇḍalāḥ |
tatra śailā virājante hārāḥ proddhūlitā iva
]

`v 14 [
kṛpāṇaśakalotkṛttaniḥśeṣārātimaṇḍalaḥ |
arātilokaḥ prāpnoti yadanusmaraṇājjvaram
]

`v 15 [
yasyodārasamārambhamāryalokānupālanam |
caritaṃ saṃsmariṣyantihareriva ciraṃ janāḥ
]

`v 16 [
yasyāpsarobhiradrīndramūrdhasvamarasadmasu |
vikāsipulakollāsaṃ gīyante guṇagītayaḥ
]

`v 17 [
yasya svaḥsundarīgītā lokapālaciraśrutāḥ |
viriñcihaṃsairdhvanyante svabhyāsādguṇagītayaḥ
]

`v 18 [
svapneṣvapi na sāmānyā yasyodāracamatkṛtiḥ |
rāma dṛṣṭā śrutā vāpi dainyadoṣamayī kriyā
]

`v 19 [
jihmatāṃ yo na jānāti na dṛṣṭā yena ghṛṣṇutā |
udāratā yena dhṛtā brahmaṇevākṣamālikā
]

`v 20 [
dināṣṭabhāgamākāśamāgate divasādhipe |
sa kadācitsabhāsthāne siṃhāsanagato'bhavat
]

`v 21 [
sukhopaviṣṭe tatrāsminrājanīndāvivāmbare |
praviśantīṣu sāmantasenāsu ca sasaṃbhramam
]

`v 22 [
gāyantīṣvatha kāntāsu sūpaviṣṭeṣu rājasu |
mano harati sāhlāde vīṇāvaṃśakalārave
]

`v 23 [
cārucāmarahastāsu savilāsāsu rājani |
devāsuraguruprakhye viśrānte mantrimaṇḍale
]

`v 24 [
prastuteṣu praviṣṭeṣu rājakāryeṣu mantribhiḥ |
proktāsu deśavārtāsu nipuṇaiścārumantribhiḥ
]

`v 25 [
itihāsamaye puṇye vācyamāne ca pustake |
paṭhatsu ca stutīḥ puṇyāḥ puraḥ prahveṣu bandiṣu
]

`v 26 [
sabhāṃ viveśa sāṭopaḥ kaścittāmaindrajālikaḥ |
varṣeṇāhitasaṃrambho vasudhāmiva vāridaḥ
]

`v 27 [
sa nanāma mahīpālaṃ śikharodārakandharam |
pādopāntagataḥ kāntaṃ śailaṃ phalataruryathā
]

`v 28 [
sacchāyasyonnatāṃsasya phalinaḥ puṣpabhāsinaḥ |
sa viveśa puro rājñastaroragre kapiryathā
]

`v 29 [
capalo lampaṭo'rthānāmāmodasukhamārutam |
uvācotkandharaṃ bhūpaṃ sapadmamiva ṣaṭpadaḥ
]

`v 30 [
vilokaya vibho tāvadekāmiha kharolikām |
pīṭhastha eva sāścaryāṃ vyomni candra ivāvanim
]

`v 31 [
ityuktvā picchikā tena bhrāmitā bhramadāyinī |
nānāviracanābījā māyeva paramātmanaḥ
]

`v 32 [
tāṃ dadarśa mahīpālastejoreṇuvirājitām |
śakraḥ suravimānasthaḥ svakārmukalatāmiva
]

`v 33 [
p. 374) 222
sabhāṃ saindhavasāmanto viveśāsminkṣaṇe tadā |
tārāparikarāpūrṇāṃ vyomavīthīmivāmbudaḥ
]

`v 34 [
taṃ caivānujagāmāśvaḥ saumyaḥ paramavegavān |
devalokonmukhaṃ tuṣṭaṃ śakramuccaiḥśravā iva
]

`v 35 [
sa tamaśvamupādāya pārthivaṃ samuvāca ha |
soccaiḥśravā iva kṣīrasāgaro marutāṃ patim
]

`v 36 [
idamuccaiḥśravaḥprakhyaṃ hayaratnaṃ mahīpate |
javoḍḍayanaśīlena mūrtimāniva mārutaḥ
]

`v 37 [
aśvo'yamasmatprabhuṇā prabho saṃprahitastvayi |
rājate hi padārthaśrīrmahatāmarpaṇācchubhā
]

`v 38 [
ityuktavati tasmiṃstu pratyuvācaindrajālikaḥ |
jaladastanite śānte cātako'mbudharaṃ yathā
]

`v 39 [
sadaśvamenamāruhya bhuvanaṃ vihara prabho |
svapratāpāhitānalpaśobhāmurvīṃ raviryathā
]

`v 40 [
aśvamālokayāmāsa tenokta iti pārthivaḥ |
nirghātastanitaṃ meghaṃ mayūra iva sūtkaraḥ
]

`v 41 [
athānimeṣayā dṛṣṭyā rājā citropamākṛtiḥ |
babhūvālokayannaśvaṃ lipikarmārpitopamaḥ
]

`v 42 [
lipikarmārpitaścitranyastastadupamo niścalaḥ | etadādiḥ
sabhājanapratītisiddhārthānuvādaḥ | rājapratītidṛṣṭaṃ tu agre rājaiva vakṣyati |
41 |
kṣaṇamālokya pīṭhasthastasthau saṃsthagitekṣaṇaḥ |
dṛṣṭyā'kṣubdhaḥ samudro'drimīnakaiḥ karavo yathā
]

`v 43 [
tasthau muhūrtayugmaṃ sa dhyānāsakta ivātmani |
vītarāgo muniḥ kṣubdhaḥ parānanda iva sthitaḥ
]

`v 44 [
bodhitaḥ kenacinnāsau svapratāpajitorjitaḥ |
dhiyā kāmapyayaṃ bhūyaścintāṃ cintayatīti ca
]

`v 45 [
babhūvuḥ kevalaṃ tatra niḥspandasitacāmarāḥ |
cāmariṇyo hi śarvaryaḥ stambhitendukarā iva
]

`v 46 [
virejurvismayāpūrṇā niḥspandāste sabhāsadaḥ |
niḥspandakiñjalkadalāḥ padmāḥ paṅkakṛtā iva
]

`v 47 [
praśaśāma sabhāsthāne janakolāhalaḥ śanaiḥ |
praśāntaprāvṛṣi vyomanyāmbhodamiva garjitam
]

`v 48 [
saṃdehasāgare magnā jagmuścintāṃ sumantriṇaḥ |
viṣīdati gadāpāṇāvasurājāvivāmarāḥ
]

`v 49 [
vitatavismitajihmitayā tayā
janatayā bhayamohaviṣaṇṇayā |
stimitacakṣuṣi bhūmipatau sthite
mukulitābjavanasya dhṛtā dyutiḥ
]