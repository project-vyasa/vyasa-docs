`v 1 [
trayastriṃśaḥ sargaḥ 33
śrīrāma uvāca |
bhagavanyuddhametanme samāsena manāgvada |
śrutirāhlādyate śroturyasmādetābhiruktibhiḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
atha tatraiva te devyau saṃgrāmaṃ tamavekṣitum |
vimāne kalpite kānte ruddhe ruruhatuḥ sthire
]

`v 3 [
etasminnantare tatra līleśaḥ pratipakṣataḥ |
tamutsoḍhumaśaktaḥ sanmukhavyatikare raṇe
]

`v 4 [
pralayārṇavakallola ivotpattyodbhaye bhaṭe |
jahau sānāviva śilāṃ bhaṭasyorasi mudgaram
]

`v 5 [
atha pravṛttaḥ prasabhaṃ pralayārṇavaraṃhasā |
senayoḥ śastrasaṃpātaḥ kirannanalavidyutaḥ
]

`v 6 [
tarattaraladhārāgrarekhāṅkitanabhastalaḥ |
dhvanatkaṇakaṇāśabdamadhyalakṣitaṭāṃkṛtiḥ
]

`v 7 [
dhīrahuṃkāramiśriṣmaghargharāravaghasmaraḥ |
pravṛttaśaradhārāgrabhāskarārcirvitānakaḥ
]

`v 8 [
nadatkaṅkaṭaṭaṅkāraproḍḍīnakaṇapāvakaḥ |
parasparāhaticchinnahetikhaṇḍakhagāmbaraḥ
]

`v 9 [
vīradordrumasaṃcāravahadvananabhasthalaḥ |
kodaṇḍacakrakreṅkāradravadvaimānikāṅganaḥ
]

`v 10 [
mahāhalahalārāvabhṛṅgīkṛtaghanadhvaniḥ |
nirvikalpasamādhistha ivaikaghanatāvaśāt
]

`v 11 [
nārācāsāradhārāgralūnaśūraśiraskaraḥ |
parasparāṃsasaṃghaṭṭaraṇatkaṅkaṭasaṃkaṭaḥ
]

`v 12 [
huṃkārahatahetyugrasaṃghaṭṭakaṭuṭāṃkṛtaḥ |
taraddhārātaraṅgābhradanturāśeṣadiṅmukhaḥ
]

`v 13 [
hetisaṃghaṭṭavikṣobhamuṣṭigrāhyajhaṇajjhaṇaḥ |
ciramāsphoṭakāsphoṭaluṭhaccaṭacaṭāravaḥ
]

`v 14 [
p. 210)
pravahatkhaḍgasītkārajvalatkaṇasaṇadhvaniḥ |
saraccharabharādhvāntaśaratkhakharāravaḥ
]

`v 15 [
dhagaddhagitivicchinnakaṇṭhotthaprāṇalohitaḥ |
chinnabāhuśiraḥkhaḍgakhaṇḍanirvivarāmbaraḥ
]

`v 16 [
kaṅkaṭotthasphuradvahnisaṭāspṛṣṭaśiroruhaḥ |
raṇatpatadasivrātamattapīnajhaṇajjhaṇaḥ
]

`v 17 [
kuntakuṇṭhitamātaṅgataraṅgottuṅgalohitaḥ |
dantidantaviniṣpeṣatāracītkārakarkaśaḥ
]

`v 18 [
mahāmusalasaṃpātapiṣṭakaṣṭoddhurasvaraḥ |
taracchūraśiraḥpadmaprakarācchāditāmbaraḥ
]

`v 19 [
vyomanyastabhujāhīndraḥ pūrṇadhūlimayāmbudaḥ |
chinnahetinarārabdhakeśākeśipratikriyaḥ
]

`v 20 [
nakhānakhinikṛttākṣikarṇanāsoṣṭhakandharaḥ |
chinnāyudhamahāmallahelollālanalabdhabhūḥ
]

`v 21 [
patatsamadamātaṅgakampitorvīluṭhadrayaḥ |
raṇadratharayotpannakṣaradraktasaritpathaḥ
]

`v 22 [
mātaṅgena kampitānāṃ ata eva dhāvitumaśaktyā urvyā luṭhatāṃ rayo yatra | 21
|
rajoracitanīhāraḥ kacatpravahadāyudhaḥ |
ekīkṛtaghanakṣobhasainyasāgaragarjitaḥ
]

`v 23 [
mattahāsavilāsena mṛtyunā paricarvitaḥ |
garvitādrīndranāgendrakharvitāmbhodagarjitaḥ
]

`v 24 [
vṛkṣaśvabhrataṭīcchannacakraśaktyṛṣṭimudgaraḥ |
śarorṇātantunīrandhraghṛṣṭiyodhādrimekhalaḥ
]

`v 25 [
vṛkṣaśvabhrādyāśrayeṇa praharatāṃ vadhāya kṣiptāstatra
cchannāścakrādayo yatra | śaralakṣaṇorṇātantubhirnīrandhradhṛṣṭayo
nirantarānusyūtā nānāvarṇā yodhalakṣaṇā adrimekhalāḥ parvatanitambā yatra |
24 |
meghaviśrāntavicchinnapatākāpaṭacāmaraḥ |
yantrapāṣāṇacakraughadūravidrutakhecaraḥ
]

`v 26 [
maraṇavyagrakṛttāṅgayodhākrandātighargharaḥ |
kuṭhārāghātasaṃghātavidalanmastakavrajaḥ
]

`v 27 [
dūroḍḍīnakacatkhaḍgakhaṇḍatārakitāmbaraḥ |
śaktinirmuktaśaktyaughavibhinnebhāvṛtāvaniḥ
]

`v 28 [
sainyavyākulavetālalalanonmuktamudgaraḥ `note[ddhūtamudgaraḥ iti
pāṭhaḥ] |
gaganottambhitottuṅgaśūratomaratoraṇaḥ
]

`v 29 [
bhuśuṇḍībhagnakhaḍgaughakhaṇḍālīvyomakuntalaḥ |
kuntaveṇuvananyastatāpāmbarakacacchaviḥ
]

`v 30 [
khaḍgakhaṇḍālireva vyomnaḥ kuntalāḥ keśā yatra | kuntasamūhalakṣaṇe
veṇuvane nyastaḥ kṣiptastāpo dāvāgnirivāmbare kacantī chaviḥ kuntakāntiryatra |
29 |
khaḍgarṣṭivṛṣṭisaṃpuṣṭarājapūjitasainikaḥ |
śūlottambhitasacchūragrahaṇodyamitāpsarāḥ
]

`v 31 [
gadātuṣāravigalatsphuritāṅgadadiṅmukhaḥ |
prāsaprasabhasaṃpiṣṭakaṣṭaceṣṭatayotkaṭaḥ
]

`v 32 [
cakrakrakacasaṃcāracchinnāśvanaravāraṇaḥ |
paraśuvrātasaṃpātapatatsamadavāraṇaḥ
]

`v 33 [
lakuṭolloḍanoḍḍīnaproḍḍāmaracaṭadbhaṭaḥ |
yantrapāṣāṇasaṃpātapiṣṭaketurathadrumaḥ
]

`v 34 [
karavālavilūnāgracchatrapaṅkajapāṇḍuraḥ |
kṣepaṇakṣobhasaṃkṣīṇasainyakṣobho'pyalakṣaṇaḥ
]

`v 35 [
kabandhabandhasaṃnetṛpātasaṃpiṣṭapārśvagaḥ |
sāṅkuśāṅktasaṃkhyasthavīravāritavāraṇaḥ
]

`v 36 [
p. 211)
paraśuvrātasaṃpātapatatsamadavāraṇaḥ |
pāśāpāśiviśeṣajñavīrātiparidevanaḥ
]

`v 37 [
kṣurikākukṣinirbhedagalatpadmapatajjanaḥ |
triśūlavalanonmattaśūrasaṃkaranartataḥ
]

`v 38 [
dhāvaddhānuṣkasaṃpūrṇakulakūjitakākaliḥ `note[kṛtakūjita iti
pāṭhaḥ] |
bhindipālasaṭāṭopahuṃkārārabhaṭīnaṭaḥ
]

`v 39 [
vajramuṣṭiviniṣpiṣṭapiṣṭasadbhaṭasaṃkaṭaḥ |
śyenavadvyomapadavīprotpatatpaṭupaṭṭiśaḥ
]

`v 40 [
aṅkuśākṛṣṭaśūreśarathebhahayaketanaḥ |
halāhalihatālūnahelākulakulācalaḥ
]

`v 41 [
sutālottālakuddālanikhātavanabhūtalaḥ |
dhanurdviguṇamātrāstalūnalokaśilāvaliḥ
]

`v 42 [
krakacobhayapārśvebhacchinnamattamataṅgajaḥ |
saṃgrāmolūkhalakṣuṇṇalokataṇḍulamausalī
]

`v 43 [
astrābhāśṛṅkhalājālabaddhasenāvihaṅgamaḥ |
lolāsivīranistriṃśanītavādigṛhāṅgaṇaḥ
]

`v 44 [
gaṇaśo nīyamānāgryaśvāpadārāvanirbharaḥ |
nakhāṅguṣṭhakhanatpuṅkhapreṅkāraṇaraṇāravaiḥ
]

`v 45 [
maricairvyañjanānīva rañjayansakalāravān |
sainyanikṣiptakumbhāgnidagdhayodheritāyudhaḥ `note[sainikakṣipta iti
pāṭhaḥ] |
sainyanikṣiptakumbhāgnidagdhayodhojjhitāyudhaḥ `note[gnimṛtayodho
jitāyudhaḥ mṛtayādheritāyudhaḥ iti pāṭhau]
]

`v 46 [
sainyanikṣiptakumbhastataptāṅgārahatekṣaṇaḥ |
sainyanikṣiptakumbhasthaviṣavāridalajjanaḥ
]

`v 47 [
nārācavarṣavaravāridavīrapūra-
mattābhrasaṃbhramasanṛttakabandhavarhī |
kalpāntakāla iva vegavivartamāna-
mātaṅgaśailavalito raṇasaṃbhramo'bhūt
]