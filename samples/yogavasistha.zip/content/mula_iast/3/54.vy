`v 1 [
catuḥpañcāśaḥ sargaḥ 54
śridevyuvāca |
tasmādye vedyavettāro ye vā dharmaṃ paraṃ śritāḥ |
ātivāhikalokāṃste prāpnuvantīha netare
]

`v 2 [
ādhibhautikadehatvaṃ mithyābhramamayātmakam |
kathaṃ satye sthitiṃ yāti cchāyāste kathamātape
]

`v 3 [
līlā viditavedyā no paramaṃ dharmamāśritā |
kevalaṃ tena sā bhartuḥ kalpitaṃ nagaraṃ gatā
]

`v 4 [
p. 259)
prabuddhalīlovāca |
evameṣā prayātā'stu bhartā paśya mamāmbike |
pravṛttaḥ prāṇasaṃtyāge kartavyaṃ kimihādhunā
]

`v 5 [
bhāvābhāveṣu bhāvānāṃ kathaṃ niyatirāgatā |
kathaṃ bhūyo'pyaniyatirmṛtijanmādisūcitā
]

`v 6 [
kathaṃ svabhāvasaṃsiddhiḥ kathaṃ sattā padārthagā |
kathamagnyādiṣūṣṇatvaṃ pṛthvyādau sthiratā katham
]

`v 7 [
nanu māstu niyatiraniyama evāstu tatrāha - kathamiti | svabhāvo jalasya
śaityamagnerauṣṇyamevetyādiḥ | ghaṭādipadārthagā sattā bhāvarūpatāniyamaḥ |
6 |
himādiṣu kathaṃ śaityaṃ kā sattā kālakhādiṣu |
bhāvābhāvagrahotsargasthūlasūkṣmadṛśaḥ katham
]

`v 8 [
kathamatyantamucchrāyaṃ tṛṇagulmanarādikam |
vastu nāyātyaniṣṭe'pi sthite svocchrāyakāraṇe
]

`v 9 [
śālatālādivadatyantamucchrāyamūrdhvadairghyam | svocchrāyakāraṇe sthite'pi
iṣṭe aniṣṭe'pi sarvatrāniyamātsarvavastuṣvanāśvāsa eva kiṃ na syāditi bhāvaḥ | 8
|
śrīdevyuvāca |
mahāpralayasaṃpattau sarvārthāstamaye sati |
anantākāśamāśāntaṃ sadbrahmaivāvatiṣṭhate
]

`v 10 [
taccidrūpatayā tejaḥkaṇo'hamiti cetati |
svapne saṃvidyathā hi tvamākāśagamanādi ca
]

`v 11 [
tejaḥkaṇo'sau sthūlatvamātmanātmani vindati |
asatyameva satyābhaṃ brahmāṇḍaṃ tadidaṃ smṛtam
]

`v 12 [
tatrāntarbrahma tadvetti brahmāyamahamityatha |
manorājyaṃ sa kurute svātmaivaṃ tadidaṃ jagat
]

`v 13 [
tasminprathamataḥ sarge yā yathā yatra saṃvidaḥ |
kacitāstāstathā tatra sthitā adyāpi niścalāḥ
]

`v 14 [
yadyathā sphuritaṃ cittaṃ tattathā hyātmacidbhavet |
svayamevāniyamatastattatsyānneha kiṃcana
]

`v 15 [
na ca nāma nakiṃcittvaṃ yujyate viśvarūpiṇaḥ |
tyaktvā samastasaṃsthānaṃ hema tiṣṭhati vai katham
]

`v 16 [
sargādau svayamevāntaścidyathā kacitātmani |
himāgnyāditayādyāpi sā tathāste svasattayā
]

`v 17 [
tasmātsvasattāsaṃtyāgaḥ sataḥ kartuṃ na yujyate |
yadā cidāste teneyaṃ niyatirna vinaśyati
]

`v 18 [
yadyathā kacitaṃ yatra vyomarūpyapi pārthivam |
sargādau tasya calitumadyayāvanna yujyate
]

`v 19 [
yā yathā citprakacitā pratipakṣavidaṃ `note[pratipakṣacitaṃ ityubhayatra]
vinā |
na sā tataḥ pracalati vedanābhyāsataḥ svayam
]

`v 20 [
p. 260)
jagadādāvanutpannaṃ yaccedamanubhūyate |
tatsaṃvidvyomakacanaṃ svapnastrīsurataṃ yathā
]

`v 21 [
asatyameva satyābhaṃ pratibhānamidaṃ sthitam |
iti svabhāvasaṃpattiriti bhūtānubhūtayaḥ
]

`v 22 [
itiniścayā eva svabhāvasaṃpattiḥ svarūpāvāptiḥ | bhūtānubhūtayo
yathāsthitabodhā ityarthaḥ | athavā iti prāgvarṇitarītyā niyatiḥ
svabhāvasaṃpattirbhūtānubhūtayo jīvanamaraṇādipadārthānubhavāścetyarthaḥ |
21 |
sargādau yā yathā rūḍhā saṃvitkacanasaṃtatiḥ |
sādyāpyacalitānyena sthitā niyatirucyate
]

`v 23 [
gṛhītavyomasaṃvitticidvyoma vyomatāṃ gatam |
gṛhītakālatāsaṃviccinnabhaḥ kālatāṃ gatam
]

`v 24 [
uktamarthamudāhṛtya darśayati - gṛhīteti | gṛhītā sargādau svīkṛtā
vyomasaṃvittirvyomākāreṇa kacanaṃ yena cidvyomnā tattathoktam | evamagre'pi |
23 |
gṛhītajalasaṃvitticidvyoma vārivatsthitam |
svapne yathā hi puruṣaḥ paśyatyātmani vāritām
]

`v 25 [
svapnacitsaṃvidābhāti bhavatyeṣā yathāsthitā |
ciccamatkāracāturyādasadetatsamūhate
]

`v 26 [
khatvaṃ jalatvamurvītvamagnivāyutvamapyasat |
vettyantaḥ svapnasaṃkalpadhyāneṣviva citiḥ svayam
]

`v 27 [
maraṇānantaraṃ karmaphalānubhavanakramam |
sarvasaṃdehaśāntyarthaṃ mṛtiśreyaskaraṃ śṛṇu
]

`v 28 [
rūḍhādisarge niyatiryaikadvitricatuḥśatā |
pūrvādiṣvāyuṣaḥ puṃsāṃ tasyā me niyatiṃ śṛṇu
]

`v 29 [
deśakālakriyādravyaśuddhyaśuddhī svakarmaṇām |
nyūnatve cādhikatve ca nṛṇāṃ kāraṇamāyuṣaḥ
]

`v 30 [
svakarmadharme hrasati hrasatyāyurnṛṇāmiha |
vṛddhe vṛddhimupāyāti samameva bhavetsame
]

`v 31 [
bālamṛtyupradairbālo yuvā yauvanamṛtyudaiḥ |
vṛddhamṛtyupradairvṛddhaḥ karmabhirmṛtimṛcchati
]

`v 32 [
yo yathāśāstramārabdhaṃ svadharmanumatiṣṭhati |
bhājanaṃ bhavati śrīmānsa yathāśāstramāyuṣaḥ
]

`v 33 [
evaṃ karmānusāreṇa janturantyāṃ daśāmitaḥ |
bhavantyantaṃ gatavato dṛṅmarmacchedavedanāḥ
]

`v 34 [
antamāyuḥsamāptiṃ gatavataḥ prāptavataḥ puruṣasya dṛśyante
pratyakṣamanubhūyanta iti dṛśastathāvidhā marmacchedavedanā bhavanti |
sarvaśarīranāḍībhyaḥ prāṇānāṃ hṛdyupasaṃhārakāle
sahasravṛścikadaṃśavedanāsamaṃ duḥkhaṃ bhavatīti purāṇeṣu prasiddham |
33 |
prabuddhalīlovāca |
maraṇaṃ me samāsena kathayendusamānane |
kiṃ sukhaṃ maraṇaṃ kiṃ vā duḥkhaṃ mṛtvā ca kiṃ bhavet
]

`v 35 [
varṇitaṃ maraṇaduḥkhaṃ kiṃ sarveṣāṃ samamuta keṣāṃcitsukhamapyasti
maraṇottaraṃ ca kiṃ sarveṣāṃ tulyā gatiruta yogināṃ viśiṣṭeti praśnāśayaḥ |
34 |
śrīdevyuvāca |
trividhāḥ puruṣāḥ santi dehasyānte mumūrṣavaḥ |
mūkho'tha dhāraṇābhyāsī yuktimānpuruṣastathā
]

`v 36 [
abhyasya dhāraṇāniṣṭho dehaṃ tyaktvā yathāsukham |
prayāti dhāraṇābhyāsī yuktiyuktastathaiva ca
]

`v 37 [
p. 261)
dhāraṇā yasya nābhyāsaṃ prāptā naiva ca yuktimān |
mūrkhaḥ svamṛtikāle'sau duḥkhametyavaśāśayaḥ
]

`v 38 [
vāsanāveśavaivaśyaṃ bhāvayanviṣayāśayaḥ |
dīnatāṃ paramāmeti parilūnamivāmbujam
]

`v 39 [
aśāstrasaṃskṛtamatirasajjanaparāyaṇaḥ |
mṛtāvanubhavatyantardāhamagnāviva cyutaḥ
]

`v 40 [
yadā ghargharakaṇṭhatvaṃ vairūpyaṃ dṛṣṭivarṇajam |
gacchatyeṣo'vivekātmā tadā bhavati dīnadhīḥ
]

`v 41 [
paramāndhyamanāloko divāpyuditatārakaḥ |
sābhradigmaṇḍalābhogo ghanamecakitāmbaraḥ
]

`v 42 [
marmavyathāvicchuritaḥ prabhramaddṛṣṭimaṇḍalaḥ |
ākāśībhūtavasudho vasudhābhūtakhāntaraḥ
]

`v 43 [
parivṛttakakupcakra uhyamāna ivārṇave |
nīyamāna ivākāśe ghananidronmukhāśayaḥ
]

`v 44 [
andhakūpa ivāpannaḥ śilāntariva yojitaḥ |
svayaṃ jaḍībhavadvarṇo vinikṛtta ivāśaye
]

`v 45 [
patatīva nabhomārgāttṛṇāvarta ivārpitaḥ |
rathe druta ivārūḍho himavadgalanonmukhaḥ
]

`v 46 [
vyākurvanniva saṃsāraṃ vāndhavānaspṛśanniva |
bhramitakṣepaṇeneva vātayantra ivāsthitaḥ
]

`v 47 [
bhramito vā bhrama iva kṛṣṭo rasanayeva vā |
bhramanniva jalāvarte śastrayantra ivārpitaḥ
]

`v 48 [
prohyamānastṛṇamiva vahatparjanyamārute |
āruhya vāripūreṇa nipatanniva cārṇave
]

`v 49 [
anantagagane śvabhre cakrāvarte patanniva |
abdhrurvīviparyāsadaśāmanubhavansthitaḥ
]

`v 50 [
urvīviparyāsadṛśāmanubhavannabdhirivānavarataṃ patannityautprekṣikopamā |
49 |
patannivānavarataṃ protpatanniva cābhitaḥ |
sūtkārākarṇanodbhrāntapūrṇasarvendriyavraṇaḥ
]

`v 51 [
kramācchyāmalatāṃ yānti tasya sarvākṣasaṃvidaḥ |
yathāstaṃ `note[yathā hyastaṃgataravau iti pāṭhaḥ] gacchati ravau
mandālokatayā diśaḥ
]

`v 52 [
pūrvāparaṃ na jānāti smṛtistānavamāgatā |
yathā pāścātyasaṃdhyānte naṣṭā dṛṣṭirdigaṣṭake
]

`v 53 [
manaḥ kalpanasāmarthyaṃ tyajatyasya vimohataḥ |
avivekena tenāsau mahāmohe nimajjati
]

`v 54 [
yadaivāmohamādatte nādatte pavanastadā |
natvādatte yadā prāṇānmohamayātyalaṃ tadā
]

`v 55 [
anyonyapuṣṭatāṃ yātairmohasaṃvedanabhramaiḥ |
jantuḥ pāṣāṇatāmeti sthitamityādisargataḥ
]

`v 56 [
prabuddhalīlovāca |
vyathāṃ vimohaṃ mūrcchāntaṃ bhramaṃ vyādhimacetanam |
kimarthamayamāyāti deho hyaṣṭāṅgavānapi
]

`v 57 [
śrīdevyuvāca |
evaṃ saṃvihitaṃ karma sargādau spandasaṃvidā |
yadyasminsamaye duḥkhaṃ kālenaitāvatedṛśam
]

`v 58 [
syānme ityeva saṃviśya gulmavattatsvabhāvajam |
vetti cittavijṛmbhotthaṃ nānyadatrāsti kāraṇam
]

`v 59 [
yadā vyathāvaśānnāḍyaḥ svasaṃkocavikāsanaiḥ |
gṛhṇanti māruto dehe tadojjhati nijāṃ sthitim
]

`v 60 [
pṛṣṭaṃ samādhāya pratutamevāha - yadetyādinā | nāḍyaḥ
prataptapittādirasapūritatvādyathāsaṃcalanaṃ
tadvaśātsvasaṃkocavikāsanairbhuktānnapānarasaṃ vaiṣamyeṇa gṛhṇanti tadā
mārutaḥ samānavāyurnijāṃ bhuktānnapānādisamīkaraṇasthitimujjhatyutsṛjati |
59 |
p. 262)
praviṣṭā na viniryānti gatāḥ saṃpraviśanti no |
yadā vātā vināḍītvāttadā spandātsmṛtirbhavet
]

`v 61 [
na viśatyeva vāto na niryāti pavano yadā |
śarīranāḍīvaidhuryānmṛta ityucyate tadā
]

`v 62 [
āgantavyo mayā nāśaḥ kālenaitāvateti yā |
pūrvasaṃviditā saṃvidyāti taccoditā mṛtim
]

`v 63 [
īdṛśena mayehetthaṃ bhāvyamityādi sargajā |
saṃvidbījakalā nāśaṃ na kadācana gacchanti
]

`v 64 [
saṃvido vedanaṃ nāma svabhāvo'vyatirekavān |
tasmātsvabhāvasaṃvitternānye maraṇajanmanī
]

`v 65 [
kvacidāvṛtimatsaumyaṃ kvacinnadyāṃ jalaṃ yathā |
kvacitsaumyaṃ kvacijjīvadharmedaṃ cetanaṃ tathā
]

`v 66 [
yathā latāyāḥ parvāṇi dīrghāyā madhyamadhyataḥ |
tathā cetanasattāyā janmāni maraṇāni ca
]

`v 67 [
na jāyate na mriyate cetanaḥ `note[cetanaṃ puruṣe kvacit iti pāṭhaḥ]
puruṣaḥ kvacit |
svapnasaṃbhramavadbhrāntametatpaśyati kevalam
]

`v 68 [
puruṣaścetanāmātraṃ sa `note[sa kadācinna naśyati ityapi pāṭhaḥ] kadā
kveva naśyati |
cetanavyatiriktatve vadānyatkiṃ pumānbhavet
]

`v 69 [
ko'dyayāvanmṛtaṃ brūhi cetanaṃ kasya kiṃ katham |
mriyante dehalakṣāṇi cetanaṃ sthitamakṣayam
]

`v 70 [
amariṣyanna vai cittamekasminneva tanmṛte |
abhaviṣyatsarvabhāvamṛtirekamṛtāviha
]

`v 71 [
vāsanāmātravaicitryaṃ yajjīvo'nubhavetsvayam |
tasyaiva jīvamaraṇe nāmanī parikalpite
]

`v 72 [
evaṃ na kaścinmriyate jāyate na ca kaścana |
vāsanāvartagarteṣu jīva luṭhati kevalam
]

`v 73 [
atyantāsaṃbhavādeva dṛśyasyāsau ca vāsanā |
nāstyeveti vicāreṇa dṛḍhajñātaiva naśyati
]

`v 74 [
anuditamuditaṃ jagatprabandhaṃ
bhavabhayato'bhyasanairvilokya samyak |
alamanuditavāsano hi jīvo
bhavati vimukta itīha satyavastu
]