`v 1 [
dvātriṃśaḥ sargaḥ 32
śrīvasiṣṭha uvāca |
atha vīravarotkaṇṭhanṛtyadapsarasi `note[varātkaṇṭhā iti pāṭhaḥ]
sthitā |
līlāvalokayāmāsa vyomni vidyānvitāvanau
]

`v 2 [
vidyā sarasvatī tadanvitā līlā avanau senādvitayamavalokayāmāseti saṃbandhaḥ | 1
|
svarāṣṭramaṇḍale bhartṛpālite balamālite |
kasmiṃścidvitatāraṇye dvitīyākāśabhīṣaṇe
]

`v 3 [
senādvitayamākṣubdhaṃ saumyābdhidvitayopamam |
maharambhaghanaṃ mattaṃ sthitaṃ rājadvayānvitam
]

`v 4 [
yuddhasajjaṃ susaṃnaddhamiddhamagnimivādbhutam |
pūrvaprahārasaṃpātaprekṣākṣubdhākṣilakṣitam
]

`v 5 [
udyatāmalanistriṃśadhārāsāravahajjanam |
kacatparaśvadhaprāsabhindipālarṣṭimudgaram
]

`v 6 [
p. 208)
garutmatpakṣavikṣubdhavanasaṃpātakampitam |
udyaddinakarālokacañcatkanakakaṅkaṭam
]

`v 7 [
parasparamukhālokakopaproddāmitāyudham |
anyonyabaddhadṛṣṭitvāccitraṃ bhittāvivārpitam
]

`v 8 [
lekhāmaryādayā dīrghabaddhayā sthāpitasthiti |
anivāryamahāsainyajhāṃkārāśrutasaṃkatham
]

`v 9 [
pūrvaprahārasmayataściraṃ saṃśāntadundubhi |
nibaddhayodhasaṃsthānanikhilānīkamantharam
]

`v 10 [
dhanurdvitayamātrātmaśūnyamadhyaikasetunā |
vibhaktaṃ kalpavātena mattamekārṇavaṃ yathā
]

`v 11 [
dhanurdvitayapramāṇaṃ janaśūnyātmakaṃ yanmadhyaṃ tallakṣaṇenaikasetunā |
10 |
kāye `note[kāryasaṃkara iti pāṭhaḥ]
saṃkaṭasaṃrambhacintāparavaśeśvaram |
viraṭaḍbhekakaṇṭhatvagbhaṅgurāturahṛdguham
]

`v 12 [
prāṇasarvasvasaṃtyāgasodyogāsaṃkhyasainikam |
karṇākṛṣṭaśaraughaughatyāgonmukhadhanurdharam
]

`v 13 [
prahārapātasaṃprekṣāniṣpandāsaṃkhyasainikam |
anyonyotkaṇṭhakāṭhinyabharabhrukuṭisaṃkaṭam
]

`v 14 [
parasparasusaṃghaṭṭakaṭuṭaṅkārakaṅkaṭam |
vīrayodhamukhādagdhabhīruprepsitakoṭaram
]

`v 15 [
mithaḥsaṃsthānakālokamātrāsaṃdigdhajīvitam |
samastāṅgaruhāsaktaprāṃśuvṛddhebhamānavam
]

`v 16 [
pūrvaprahārasaṃprekṣāvyagraprāṇatayā tayā |
saṃśāntakallolaravaṃ nidrāmudrapuropamam
]

`v 17 [
saṃśāntaśaṅkhasaṃghātatūryanirhrādadundubhi |
bhūtalākāśasaṃlīnasarvapāṃsupayodharam
]

`v 18 [
palāyanaparaiḥ paścāttyaktamaṅgulamaṇḍalam `note[maṅgalamaṇḍalaṃ
iti pāṭhaḥ] |
visārimakaravyūhamatsyasaṃkhyābdhibhāsuram
]

`v 19 [
patākāmañjarīpuñjavijitākāśatārakam |
hāstikottambhitakarakānanīkṛtakhāntaram
]

`v 20 [
tarattaralabhāpūrasapakṣasakalāyudham |
dhamaddhamitiśabdaiśca śvāsotthairghmātakhāntaram
]

`v 21 [
cakravyūhakarākrāntadurvṛttasurabhāsuram |
garuḍavyūhasaṃrambhavidravannāgasaṃcayam
]

`v 22 [
śyenavyūhavibhinnāgrasaṃniveśottamadhvani |
anyonyāsphoṭaniḥśeṣaprapatadbhūrivṛndakam
]

`v 23 [
kvacittu śyenavyūhena vibhinno vibhakto yaḥ pratisainyasaṃniveśastena hetunā
uttamastāratamo dhvaniryasmin | kvacittu anyonyaṃ pratibhujāsphoṭena
saṃrambhānniḥśeṣaṃ kṛtsnaśaḥ prapatanto bhūrivṛndakāḥ samūhā yasmin |
22 |
vividhavyūhavinyāsavāntavīravarāravam |
karapratolanollāsamattamudgaramaṇḍalam
]

`v 24 [
kṛṣṇāyudhāṃśujaladaśyāmīkṛtadivākaram |
anilādhūtapalyūlasūtkṛtābhaśaradhvani
]

`v 25 [
anekakalpakalpāgrasavṛndamiva saṃsthitam |
pralayānilasaṃkṣubdhamekārṇavamivotthitam
]

`v 26 [
sadyaśchinnaṃ mahāmeroḥ pakṣadvayamiva sphurat |
kṣubdhamārutanirdhūtamiva kajjalaparvatam
]

`v 27 [
p. 209)
pātālakuharātkṣubdhamandhakāramivotthitam |
lokālokamivonmattanṛtyalolalasattaṭam |
mahānarakasaṃghātaṃ bhittvāvanimivotthitam
]

`v 28 [
ālolakuntamusalāsiparaśvaghāṃśu-
śyāmāyamānadivasātapavāripūraiḥ |
ekārṇavaṃ bhuvanakośamivācireṇa
kartuṃ samudyatamagādhamanantapūraiḥ
]