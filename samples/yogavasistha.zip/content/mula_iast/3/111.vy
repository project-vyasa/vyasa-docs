`v 1 [
ekādaśottaraśatatamaḥ sargaḥ 111
śrīvasiṣṭha uvāca |
asya cittamahāvyādheścikitsāyā mahauṣadham |
svāyattaṃ śṛṇu vakṣyāmi sādhu susvādu niścitam
]

`v 2 [
svenaiva pauruṣeṇāśu svasaṃvedanarūpiṇā |
yatnena cittavetālastyaktveṣṭaṃ vastu jīyate
]

`v 3 [
tyajannabhimataṃ vastu yastiṣṭhati nirāmayaḥ |
jitameva manastena kudanta iva dantinā
]

`v 4 [
svasaṃvedanayatnena pālyate cittabālakaḥ |
avastuto vastuni ca yojyate bodhyate'pi ca
]

`v 5 [
śāstrasatsaṅgadhīreṇa cintātaptamatāpinā |
chindhi tvamāyasenāyo manasaiva mano mune
]

`v 6 [
ayatnena yathā bāla itaścetaśca yojyate |
bhāvaistathaiva cetontaḥ kimivātrāsti duṣkaram
]

`v 7 [
satkarmaṇi samākrāntamudarkodayadāyini |
svapauruṣeṇaiva manaścetanena niyojayet
]

`v 8 [
p. 387) 229
svāyattamekāntahitaṃ svepsitatyāgavedanam |
yasya duṣkaratāṃ yātaṃ dhiktaṃ puruṣakīṭakam
]

`v 9 [
aramyaṃ ramyarūpeṇa bhāvayitvā svasaṃvidā |
malleneva śiśuścittamayatnenaiva jīyate
]

`v 10 [
pauruṣeṇa prayatnena cittamāśveva jīyate |
acittenāprayatnena padaṃ brahmaṇi dīyate
]

`v 11 [
svāyattaṃ ca susādhyaṃ ca svacittākrāntimātrakam |
śaknuvanti na ye kartuṃ dhiktānpuruṣajambukān
]

`v 12 [
svapauruṣaikasādhyena svepsitatyāgarūpiṇā |
manaḥpraśamamātreṇa vinā nāsti śubhā gatiḥ
]

`v 13 [
manomāraṇamātreṇa sādhyena svātmasaṃvidā |
niḥsapatnamanādyantamaniṅganamihocyatām
]

`v 14 [
īpsitāvedanākhyāttu manaḥpraśamanādṛte |
gurūpadeśaśāstrārthamantrādyā yuktayastṛṇam
]

`v 15 [
sarvaṃ sarvagataṃ śāntaṃ brahma saṃpadyate tadā |
asaṃkalpanaśastreṇa cchinnaṃ cittaṃ gataṃ yadā
]

`v 16 [
svasaṃvedanasādhye'sminsaṃkalpānarthaśāsane |
śāntāyāmatra vapuṣi puṃsaḥ kaiva kadarthanā
]

`v 17 [
nūnaṃ daivamanādṛtya mūḍhasaṃkalpakalpitam |
puruṣārthena saṃvittyā naya cittamacittatām
]

`v 18 [
tāṃ mahāpadavīmekāṃ `note[etāṃ iti pāṭhaḥ] kāmapyadhigataṃ ciram |
cittaṃ cidbhakṣitaṃ kṛtvā cittādapi paro bhava
]

`v 19 [
bhava bhāvanayā yukto yuktaḥ paramayā dhiyā |
dhārayātmānamavyagro grastacittaṃ tataḥ param
]

`v 20 [
paraṃ pauruṣamāśrtiya nītvā cittamacittatām |
tāṃ mahāpadavīmehi yatra nāśo na vidyate
]

`v 21 [
saṃvedanaviparyāsarūpiṇī dhīrivācalā |
jetumāśu mano rāma pauruṣeṇaiva śakyate
]

`v 22 [
anudvegaḥ śriyo mūlamanudvegātpravartate |
jantormanojayo yena trilokīvijayastṛṇam
]

`v 23 [
na śastradalanotpātapātā yasyāṃ manāgapi |
svabhāvamātravyāvṛttau tasyāṃ kaiva kadarthanā
]

`v 24 [
api svavedanākrāntau na śaktā ye narādhamāḥ |
kathaṃ vyavahariṣyanti vyavahāradaśāsu te
]

`v 25 [
pumānmṛto'smi jāto'smi jīvāmīti kudṛṣṭayaḥ |
cetaso vṛttayo bhānti capalasyāsadutthitāḥ
]

`v 26 [
na kaścaneha mriyate jāyate na ca kaścana |
svayaṃ vetti mṛtaṃ svasya lokamanyaṃ svakaṃ manaḥ
]

`v 27 [
ito yāti paraṃ lokaṃ sphuratyanyatayā manaḥ |
tattasyaityetadāmokṣamato mṛtibhayaṃ kutaḥ
]

`v 28 [
ihalokena vicaratvihaloke paratra ca |
cittamāmokṣamāste'sya rūpamanyanna vidyate
]

`v 29 [
mṛte bhrātari bhṛtyādau kleśa ākriyate'nṛtaḥ |
tatsvacittaṃ svacaitanyavyāvṛttātmeti me matiḥ
]

`v 30 [
p. 388) 230
sati pathye tate śubhre cittopaśamanādṛte |
tiryagūrdhvamadhastācca bhūyobhūyo vicāritam
]

`v 31 [
yāvannāsti kilopāyaścittopaśamanādṛte |
ṛte tathye tate śubhre bodhe hṛdyudite sati
]

`v 32 [
manovilayamātreṇa viśrāntirupajāyate |
vyāyate hṛdayākāśe citi ciccakradhārayā
]

`v 33 [
mano māraya niḥśaṅkaṃ tvāṃ prabadhnanti nādhayaḥ |
yadi ramyamaramyatve tvayā saṃviditaṃ vidā
]

`v 34 [
chinnānyeva tadāṅgāni `note[tadaṅgāni iti pāṭhaḥ kvacit] cittasyeti
matirmama |
ayaṃ so'hamidaṃ tanma etāvanmātrakaṃ manaḥ
]

`v 35 [
tadabhāvanamātreṇa dātreṇeva vilūyate |
chinnābhramaṇḍalaṃ vyomni `note[vyoma iti pāṭhaḥ] yathā śaradi
dhūyate
]

`v 36 [
vātenākalpanenaivaṃ tathā taddhūyate manaḥ |
bhavanti yatra śastrāgnipavanāstatra bhīrbhavet
]

`v 37 [
svāyate mṛduni svacche kimasaṃkalpane bhayam |
idaṃ śreya idaṃ neti siddhamābālamakṣatam
]

`v 38 [
bālaṃ putramivodāre manaḥ śreyasi yojayet |
akṣayaṃ cānavaṃ cetaḥsiṃhaṃ saṃsṛtibṛṃhaṇam |
ghnanti ye te jayantīha nirvāṇapadadāyinaḥ
]

`v 39 [
bhīmāḥ saṃbhramadāyinyaḥ saṃkalpakadanādimāḥ |
vipadaḥ saṃprasūyante mṛgatṛṣṇā marāviva
]

`v 40 [
kalpāntapavanā vāntu yāntu caikatvamarṇavāḥ |
tapantu dvādaśādityā nāsti nirmanasaḥ kṣatiḥ
]

`v 41 [
manobījātsamudyanti sukhaduḥkhe śubhāśubhe |
saṃsārakhaṇḍakā ete lokasaptakapallavāḥ
]

`v 42 [
asaṃkalpanamātraikasādhye sakalasiddhide |
asaṃkalpanasāmrājye tiṣṭhāvaṣṭabdhatatpadaḥ
]

`v 43 [
prayacchatyuttamānandaṃ kṣīyamāṇaṃ manaḥ kramāt |
kāṣṭhakṣīṇāṅgakāṅgāro yathāṅgārakṣayārthinaḥ
]

`v 44 [
api brahmakuṭīlakṣaṃ manasaścetsamīhitam |
tadaṇorantare vyaktaṃ vibhaktaṃ paridṛśyate
]

`v 45 [
saṃkalpamātravibhavena kṛtātyanarthaṃ
saṃkalpamātravibhavena susādhitārtham |
saṃtoṣamātravibhavena mano vijitya
nityoditena jayamehi nirīpsitena
]

`v 46 [
paramapāvanayā vimanastayā
samatayā matayātmavidāmapi |
śamitayā mitayāntarahaṃtayā
yadavaśiṣṭamajaṃ padamastu tat
]