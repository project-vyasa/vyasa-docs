`v 1 [
p. 389) 230
dvādaśottaraśatatamaḥ sargaḥ 112
śrīvasiṣṭha uvāca |
yasmiṃstasminpadārthe hi yena tena yathā tathā |
tīvrasaṃvegasaṃpannaṃ manaḥ paśyati vāñchitam
]

`v 2 [
jāyate mriyate caiṣā manasastīvravegitā |
saumyāmbubudbudālīva nirnimittā svabhāvataḥ
]

`v 3 [
śītatā tuhinasyeva kajjalasyeva kṛṣṇatā |
lolatā manaso rūpaṃ tīvrātīvraikarūpiṇī
]

`v 4 [
śrīrāma uvāca |
kathamasyātilolasya vego vegaikakāraṇam |
calatā manaso brahmanbalato vinivāryate
]

`v 5 [
śrīvasiṣṭha uvāca |
neha cañcalatāhīnaṃ manaḥ kvacana dṛśyate |
cañcalatvaṃ manodharmo vahnerdharmo yathoṣṇatā
]

`v 6 [
yaiṣā hi cañcalā spandaśaktiścittatvasaṃsthitā |
tāṃ viddhi mānasīṃ śaktiṃ jagadāḍambarātmikā
]

`v 7 [
spandāspandādṛte vāyoryathā sattaiva nohyate |
tathā `note[tathāca iti pāṭhaḥ] na cittasattāsti cañcalaspandanādṛte | 7
|
sattā astitā | nohyate na virarkyate
]

`v 8 [
yattu cañcalatāhīnaṃ tanmano mṛtamucyate |
tadeva ca tapaḥśāstrasiddhānto mokṣa ucyate
]

`v 9 [
manovilayamātreṇa duḥkhaśāntiravāpyate |
manomananamātreṇa duḥkhaṃ paramavāpyate
]

`v 10 [
duḥkhamutpādayatyuccairutthitaścittarākṣasaḥ |
sukhāyānantabhogāya taṃ prayatnena pātaya
]

`v 11 [
tasya cañcalatā yaiṣā tvavidyā rāma socyate |
vāsanāpadanāmnīṃ tāṃ vicāreṇa vināśaya
]

`v 12 [
avidyayā vāsanayā tayāntaścittasattayā |
vilīnayā tyāgavaśātparaṃ śreyo'dhigamyate
]

`v 13 [
yattatsadasatormadhyaṃ yanmadhyaṃ cittvajāḍyayoḥ |
tanmanaḥ procyate rāma dvayordolāyitākṛti
]

`v 14 [
jāḍyānusaṃdhānahataṃ jāḍyātmakatayeddhayā |
ceto jaḍatvamāyāti dṛḍhābhyāsavaśena hi
]

`v 15 [
vivekaikānusaṃdhānāccidaṃśātmatayā manaḥ |
cidekatāmupāyāti dṛḍhābhyāsavaśādiha
]

`v 16 [
pauruṣeṇa prayatnena yasminneva pade manaḥ |
pātyate tatpadaṃ prāpya bhavatyabhyāsato hi tat
]

`v 17 [
punaḥ pauruṣamāśritya cittamākramya cetasā |
viśokaṃ padamāśritya nirāśaṅkaḥ sthiro bhava
]

`v 18 [
bhavabhāvanayā magnaṃ manasaiva na cenmanaḥ |
balāduttāryate rāma tadupāyo'sti netaraḥ
]

`v 19 [
mana eva samarthaṃ vo manaso dṛḍhanigrahe |
arājā kaḥ samarthaḥ syādrājño rāghava nigrahe
]

`v 20 [
tṛṣṇāgrāhagṛhītānāṃ saṃsārārṇavaraṃhasi |
āvartairuhyamānānāṃ dūre svaṃ mana eva nauḥ
]

`v 21 [
manasaiva manaśchittvā pāśaṃ paramabandhanam |
unmocito na yenātmā nāsāvanyena mokṣyate
]

`v 22 [
yā yodeti manonāmnī vāsanā vāsitāntarā |
tāṃ tāṃ pariharetprājñastato'vidyākṣayo bhavet
]

`v 23 [
p. 390) 231
bhogaughavāsanāṃ tyaktvā tyaja tvaṃ bhedavāsanām |
bhāvābhāvau tatastyaktvā nirvikalpaḥ sukhī bhava
]

`v 24 [
abhāvanaṃ bhāvanāyāstvetāvānvāsanākṣayaḥ |
eṣa eva manonāśastvavidyānāśa ucyate
]

`v 25 [
yadyatsaṃvedyate kiṃcittatrāsaṃvedanaṃ param |
asaṃvittistu nirvāṇaṃ duḥkhaṃ saṃvedanādbhavet
]

`v 26 [
svenaiva tatprayatnena puṃsaḥ saṃvedyate kṣaṇāt |
bhāvasyābhāvanaṃ bhūtyai tattasmānnityamāharet
]

`v 27 [
tacca vedyāvedanaṃ puruṣaprayatnādbhavatītyāha - sveneti |
bhāvasyābhāvanaṃ vedyasyāvedanam | tatsvaprayatnaṃ nityamāharedabhyaset | 26
|
rāgādayo ye manasīpsitāste
buddhveha tāṃstāṃstvamavastubhūtān |
tyaktvā tadāsyāṅkuramastabījaṃ
mā harṣaśokaṃ samupaihi tṛptaḥ
]