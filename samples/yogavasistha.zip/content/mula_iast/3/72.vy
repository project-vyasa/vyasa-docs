`v 1 [
dvisaptatitamaḥ sargaḥ 72
śrīvasiṣṭha uvāca |
sūcī sā saṃbhavadvāṇī cintayitvetyakampanam |
punastaddehalābhāya bhavāmyāśu tapasvinī
]

`v 2 [
iti saṃcintya cittasthaṃ saṃhṛtya janamāraṇam |
tadeva himavacchṛṅgaṃ jagāma tapase sthitam
]

`v 3 [
apaśyadeva sūcitvaṃ sā tanmānasamātmani |
prāṇavātātmikā prāṇaiḥ praviśya hatamānasam
]

`v 4 [
athātmanyeva sūcitvaṃ paśyatyeva manomayam |
prāṇavātaśarīrāsau jagāma himavacchiraḥ
]

`v 5 [
dṛḍhadāvānale tatra sarvabhūtavivarjite |
mahāmahāśilābhābhārūkṣe pāṃsuvidhūsare
]

`v 6 [
tasthāvabhyuditevāsau nistṛṇe vipule sthale |
marāvakasmātsaṃjātaśuṣkā tṛṇaśikhā yathā
]

`v 7 [
susūkṣmasyaikapādasya sārdhenaivāśritorvarā |
svasaṃvidekapādātma tapaḥ kartuṃ pracakrame
]

`v 8 [
sūkṣmapādatalenaiṣā vasudhāreṇusaṃkaṭī |
nivārya tripadīṃ kṛtsnādyatnenordhvamukhī sthitā
]

`v 9 [
p. 307) 187
kṛṣṇatvahiṃsratātaikṣṇyavyāptyāsyapavanāśanaiḥ |
yatnātpadaṃ nibadhnantī reṇvaṇūpalasaṃkaṭe
]

`v 10 [
araṇye kṣubhitāṃ saṃpaddūrālokārthamutthitām |
pucchākoṭisthitāṃ vātālolāmanucakāra sā
]

`v 11 [
mukharandhraviniṣkrāntā tasyā bhāskaradīdhitiḥ |
sakhī babhūva sūcyābhā paścādbhāgaikarakṣiṇī
]

`v 12 [
kṣudre'pi svajane bhūte'pyeti vatsalatāṃ janaḥ |
dīdhītyāpi sakhīvṛttaṃ sūcyāṃ śucitayā bhṛtam
]

`v 13 [
babhūva tasyāḥ svacchāyā dvitīyā tāpasī sakhī |
evaṃ sūcīva malinā tayā paścātkṛteva sā
]

`v 14 [
sūcyā tayā sunirgatya supātākṣyaḥ sma kūṇitaiḥ |
paścātsakhyābhayā sādhuranyonyācārakevalam
]

`v 15 [
sūcyābhiprekṣite yātā matiṃ drumalatādayaḥ |
mahātapasvinīṃ sūcīṃ dṛṣṭvā notkaṇṭhayanti ke
]

`v 16 [
sthirabaddhapadāmenāṃ svamanovṛttimutthitām |
anilaṃ bhojayāṃcakrurmukhanirgatabhāṃkṛtaiḥ
]

`v 17 [
prasūtāni bhaviṣyāṇi gīrvāṇānyāni vā ciram |
kausumāni rajāṃsyasyā ityāsyaṃ paryapūrayan
]

`v 18 [
tato mahendraprahitaṃ vātanunnāmiṣaṃ rajaḥ |
tayā tvabhratvavyājena na nigīrṇaṃ mukhe viśat
]

`v 19 [
na nigīrṇavatī tāni rajāṃsi dṛḍhaniścayāt |
antaḥsāratayā kāryaṃ laghavo'pyāpnuvanti hi
]

`v 20 [
na pibatyāsyasaṃsthāni tathā puṣparajāṃsyapi |
vismayaṃ pavanaḥ prāpa sumerūnmūlanādhikam
]

`v 21 [
āśiraḥ pihitā paṅkaiḥ pūritāpi mahājalaiḥ |
vidhūtāpi bṛhadvātairdagdhāpi vanavahnibhiḥ
]

`v 22 [
bhinnāpi karakāpātairbhrāmitāpi taḍidbhramaiḥ |
udvejitāpi jaladaiḥ kṣobhitāpyatigarjitaiḥ
]

`v 23 [
api varṣasahasraiḥ sā cittasthadṛḍhaniścayā |
pādāgraṃ tu kusupteva nākampata tapasvinī
]

`v 24 [
nivṛttāyā bahiḥspandāddeśakāle vahau gate |
vicārayantyāstasyāḥ svamātmā satyaṃ sucetanam
]

`v 25 [
jñānālokaḥ samudabhūtsā parāvaradarśinī |
babhūva nirmalā succirviṣūcī pāvanaṃ param
]

`v 26 [
jātā viditavedyā sā svayameva tayā dhiyā |
tapasā duṣkṛte kṣīṇe sūcī svasukhasūcinī
]

`v 27 [
iti varṣasahasrāṇi sākaroddāruṇaṃ tapaḥ |
saptasaptamahālokasaṃtāpakaramunmukhī
]

`v 28 [
tasyāḥ kalpāgnibhīmena tapasā hi mahāgiriḥ |
babhūva tena jvalito jajvāleva tato jagat
]

`v 29 [
p. 308) 188
kasyedaṃ tapasākrāntaṃ jagadityatha vāsavaḥ |
nāradaṃ paripapraccha sa tasyākathayacca tat
]

`v 30 [
saptavarṣasahasrāṇi sūcī dīrghatapasvinī |
mahāvijñānadehāsau tenedaṃ jvalitaṃ jagat
]

`v 31 [
nāgāḥ śvasanti vicalanti nagāḥ patanti
vaimānikā jaladhivāridharāḥ prayānti |
śoṣaṃ diśo'rkasahitā malinībhavanti
sūcyāḥ surendra tapasā kṣayamāyayeva
]