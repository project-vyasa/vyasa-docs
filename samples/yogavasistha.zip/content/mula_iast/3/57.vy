`v 1 [
p. 270) 168
saptapañcāśaḥ sargaḥ 57
śrīvasiṣṭha uvāca |
tato dadṛśatustatra śavaśayyaikapārśvagām |
līlāṃ vidūrathasyāgre mṛtāṃ te prathamāgatām
]

`v 2 [
prāgveṣāṃ prāksamācārāṃ prāgdehāṃ prākasavāsanām |
prāktanākārasadṛśīṃ sarvarūpāṅgasundarīm
]

`v 3 [
prāgrūpāvayavaspandāṃ prāgambaraparīvṛtām |
prāgabhūṣaṇabharacchannāṃ kevalaṃ tatra saṃsthitām
]

`v 4 [
gṛhītacāmarāṃ cāru vījayantīṃ mahīpatim |
udyaccandrāmiva divaṃ bhūṣayantīṃ mahītalam
]

`v 5 [
maunasthāṃ vāmahastasthavadanendutayā natām |
bhūṣaṇāṃśulatāpuṣpaiḥ phullāmiva vanasthalīm
]

`v 6 [
kurvāṇāṃ vīkṣitairdikṣu mālatyutpalavarṣaṇam |
sṛjantīmātmalāvaṇyādinduminduṃ nabhoditam
]

`v 7 [
narapālātmano viṣṇorlakṣmīmiva samāgatām |
uditāṃ puṣpasaṃbhārādiva puṣpākaraśriyam
]

`v 8 [
bharturvadanake nyastadṛṣṭimiṣṭaviceṣṭitām |
kiṃcitpramlānavadanāṃ mlānacandrāṃ niśāmiva
]

`v 9 [
tābhyāṃ sā lalanā dṛṣṭā tayā te tu na lakṣite |
yasmātte satyasaṃkalpe sā na tāvattathoditā
]

`v 10 [
śrīrāma uvāca |
tasminpradeśe sā pūrvalīlā saṃsthāpya dehakam |
dhyānena jñaptisahitā gatābhūditi varṇitam
]

`v 11 [
kimidānīṃ sa līlāyā dehastatra na varṇitaḥ |
kiṃsaṃpannaḥ kva vā yāta iti me kathaya prabho
]

`v 12 [
śrīvasiṣṭha uvāca |
kvāsīllīlāśarīraṃ tatkutastasyāsti satyatā |
kevalā bhrāntirevābhūjjalabuddhirmarāviva
]

`v 13 [
ātmaivedaṃ jagatsarvaṃ kuto dehādikalpanā |
brahmaivānandarūpaṃ sadyatpaśyasi tadeva cit
]

`v 14 [
yathaiva bodhe līlāsau pariṇāmamitā `note[pariṇāmamupāgatā iti
pāṭhaṣṭīkānuguṇaḥ syāt] kramāt |
pare tathaiva tasmāttaddhimavadgalitaṃ vapuḥ
]