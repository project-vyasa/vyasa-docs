`v 1 [
ekaviṃśaḥ sargaḥ 21
śrīdevyuvāca |
pratibhānti jagantyāśu mṛtimohādanantaram |
jīvasyonmīlanādakṣṇo rūpāṇīvākhilānyalam
]

`v 2 [
dikkālakalanākāśadharmakarmamayāni ca |
parisphurantyanantāni kalpāntasthairyavanti ca
]

`v 3 [
nānubhūtaṃ na yaddṛṣṭaṃ tanmayā kṛtamityapi |
tatkṣaṇātsmṛtitāmeti svapne svamaraṇaṃ yathā
]

`v 4 [
māyikasmṛtyanubhavābhāsayoḥ prasiddhasmṛtyanubhavavaidharmyamāha ##-
bhrāntirevamananteyaṃ cidvyomavyomni bhāsurā |
apakuḍyā jagannāmnī nagarī kalpanātmikā
]

`v 5 [
idaṃ jagadayaṃ sargaḥ smṛtireveti jṛmbhate |
dūrakalpakṣaṇābhyāsaviparyāsaikarūpiṇī
]

`v 6 [
nānubhūtānubhūtā ca jñaptiritthaṃ dvirūpiṇī |
pūrvakāraṇariktaiva cidrūpaiva pravartate
]

`v 7 [
nānubhūte'nubhūtatvasaṃvidantarudetyapi |
svapnabhramādāvantyasminpitarīva pituḥ smṛtiḥ
]

`v 8 [
kadācitsmṛtitāṃ tyaktvā pratibhāmātrameva sat |
bhāti prathamasargeṣu rūpeṇa tadanukramāt
]

`v 9 [
dṛśyaṃ tribhuvanādīdamanubhūtaṃ smṛtau sthitam |
keṣāṃcittanvi keṣāṃcinnānubhūtaṃ smṛtau sthitam
]

`v 10 [
pratibhāsata evedaṃ keṣāṃcitsmaraṇaṃ vinā |
cidaṇūnāṃ prajeśatvaṃ kākatālīyavadyataḥ
]

`v 11 [
atyantavismṛtaṃ viśvaṃ mokṣa ityabhidhīyate |
īpsitānīpsite tatra na staḥkācana kasyacit
]

`v 12 [
atyantābhāvasaṃpattiṃ vināhantājagatsthiteḥ |
anutpādamayī hyeṣā nodetyeva vimuktatā
]

`v 13 [
rajjvāṃ sarpabhramaḥ sarpaśabdārthāsaṃbhavaṃ sthitam |
anutpādamayaṃ tyaktvā śānto'pi hi na śāmyati
]

`v 14 [
p. 180)
ardhaśānto na śānto'sau sametyarthatayā punaḥ |
udetyekapiśācānte piśāco'nyo hyadhīmataḥ
]

`v 15 [
saṃsāraścāyamābhogī parameveti niścayaḥ |
kāraṇābhāvato bhāti yadihābhātameva tat
]

`v 16 [
līlovāca |
brāhmaṇabrāhmaṇīrūpe sarge kāraṇasaṃsmṛtiḥ |
kathamabhyutthitā sāsya smaraṇīyamidaṃ vinā
]

`v 17 [
śrīdevyuvāca |
pitāmahasmṛtistatra kāraṇaṃ tasya na smṛtiḥ |
pūrvaṃ na saṃbhavatyeva muktatvātpūrvajanmanaḥ `note[padmajanmana iti
pāṭhaḥ]
]

`v 18 [
pūrvaṃ na saṃbhavatyeva smaraṇīyamiti svayam |
padmajāditvamāyāti caitanyasya tathāsthiteḥ
]

`v 19 [
abhūvamahamityanyaḥ prajānāthaḥ prajāpateḥ |
kākatālīyavatkaścidbhavati pratibhāmayaḥ
]

`v 20 [
evamabhyudite loke na kiṃcinna kadācana |
kvacidabhyuditaṃ nāma kevalaṃ cinnabhaḥ sthitam
]

`v 21 [
dvividhāyāḥ smṛterasyāḥ kāraṇaṃ paramaṃ padam |
kāryakāraṇabhāvo'sāveka eva cidambare
]

`v 22 [
kāryaṃ ca kāraṇaṃ caiva kāraṇaiḥ sahakāribhiḥ |
kāryakāraṇayoraikyāttadabhāvānna śāmyati
]

`v 23 [
avimarśātmakamāyākṛtaḥ kāryakāraṇavikalpo vimarśe bādhyata iti
darśayituṃ vimṛśati - kāryamiti | paṭaḥ kāryaṃ tantavaḥ kāraṇamiti
turīvemādisahakāribhiḥ kāraṇaiḥ syāttatropakāramakurvāṇānāṃ
sahakāritvāyogādupakārarūpamapi kāryaṃ tathāvidhaireva
vācyamityanavasthāpattestasyopakārasyābhāvātkāryakāraṇabhāvabhādhe
tatkalpanādhiṣṭhānatantādyaikyaṃ na śāmyati bhedakāraṇābhāvādityarthaḥ | 22
|
mahācidrūpameva tvaṃ smaraṇaṃ viddhi vedanam |
kāryakāraṇatā tena sa śabdo na ca vāstavaḥ
]

`v 24 [
evaṃ na kiṃcidutpannaṃ dṛśyaṃ cijjagadādyapi |
cidākāśe cidākāśaṃ kevalaṃ svātmani sthitam
]

`v 25 [
līlovāca |
aho nu paramā dṛṣṭirdarśitā devi me tvayā |
rūpaśrīrjagatī prātaḥ prabhayevekṣaṇadyutiḥ
]

`v 26 [
idānīmahametasyāṃ yāvatpariṇatā dṛśi |
nābhyāsena vinā tāvadbhindhīdaṃ devi kautukam
]

`v 27 [
p. 181)
yatrāsau brāhmaṇo gehe brāhmaṇyā sahito'bhavat |
taṃ sargaṃ taṃ girigrāmaṃ naya māṃ taṃ vilokaye
]

`v 28 [
śrīdevyuvāca |
acetyacidrūpamayī paramāṃ pāvanīṃ dṛśam |
avalambyemamākāramavamucya bhavāmalā
]

`v 29 [
tataḥ prāpsyasyasaṃdehaṃ vyomātmānaṃ nabhaḥsthitam |
bhūmiṣṭhanarasaṃkalpo gaganāntaḥ puraṃ yathā
]

`v 30 [
evaṃ sthite taṃ paśyāvaḥ saha sargamanargalam |
ayaṃ taddarśanadvāre deho hi paramārgalam
]

`v 31 [
līlovāca |
amunā devi dehena jagadanyadavāpyate |
na kasmādatra me yuktiṃ kathayānugrahāgrahāt
]

`v 32 [
śrīdevyuvāca |
jagantīmānyamūrtāni mūrtimanti mudhāgrahāt |
bhavadbhiravabuddhāni hemānīvormikādhiyā
]

`v 33 [
māyāmātratvādamūrtāni | mudhāgrahānmithyājñānāt | ūrmikāṅgulimudrikā |
32 |
hemnyūrmikārūpadhare'pyūrmikātvaṃ na vidyate |
yathā tathā jagadrūpe jagannāsti ca brahmaṇi
]

`v 34 [
jagadākāśamevedaṃ brahmaiveha tu dṛśyate |
dṛśyate kācidapyatra dhūlirambunidhāviva
]

`v 35 [
ayaṃ prapañco mithyaiva satyaṃ brahmāhamadvayam |
atra pramāṇaṃ vedāntā guravo'nubhavastathā
]

`v 36 [
brahmaiva paśyati brahma nābrahma brahma paśyati |
sargādināmnā prathitaḥ svabhāvo'syaiva cedṛśaḥ
]

`v 37 [
na brahmajagatāmasti kāryakāraṇatodayaḥ |
kāraṇānāmabhāvena sarveṣāṃ sahakāriṇām
]

`v 38 [
yāvadabhyāsayogena na śāntā bhedadhīstava |
nūnaṃ tāvadatadrūpā na brahma paripaśyasi
]

`v 39 [
tatra rūḍhimupāyātā ya ime tvasmadādayaḥ |
abhyāsādbrahmasaṃpatteḥ paśyāmaste hi tatparam
]

`v 40 [
saṃkalpanagarasyaiva mamākāśamayaṃ vapuḥ |
brahmaiva cāntaḥ paśyāmi dehenānena tatpadam
]

`v 41 [
viśuddhājñānadehārhāstathaite padmajādayaḥ |
brahmātmajagadādīnāmaṃśe saṃsthānamaṅgane
]

`v 42 [
tavābhyāsaṃ vinā bāle nākāro brahmatāṃ gataḥ |
sthitaḥ kalanarūpātmā tena tannānupaśyasi
]

`v 43 [
yatra svasaṃkalpapuraṃ svadehena na labhyate |
tatrānyasaṃkalpapuraṃ deho'nyo labhate katham
]

`v 44 [
tasmādenaṃ parityajya dehaṃ cidvyomarūpiṇī |
yatpaśyasi `note[tapaśyasi iti pāṭhaḥ] tadevāśu kuru kāryavidāṃvare |
44 |
paśyasi drakṣyasi | vartamānasāmīpyādvartamānavannirdeśaḥ
]

`v 45 [
saṃkalpanagaraṃ satyaṃ yathāsaṃkalpitaṃ prati |
saṃdehaṃ vā videhaṃ vā netaraṃ prati kiṃcana
]

`v 46 [
ādisarge jagadbhrāntiryatheyaṃ sthitimāgatā |
tathā tadāprabhṛtyevaṃ niyatiḥ prauḍhimāgatā
]

`v 47 [
līlovāca |
tvayoktaṃ devi gacchāvo brāhmaṇabrāhmaṇī jagat |
sahetīdamidaṃ vacmi kathaṃ gantavyamamba he
]

`v 48 [
imaṃ dehamihāsthāpya śuddhasatvānupātinā |
cetasā taṃ paraṃ yāmi lokaṃ tvaṃ kathameṣi tat
]

`v 49 [
śrīdevyuvāca |
saṃkalpavyomavṛkṣaste yathā sannapi svātmakaḥ |
na kuḍyātmā na kuḍyena rodhyate nāpi kuḍyahā
]

`v 50 [
p. 182)
śuddhaikasattvanirmāṇaṃ cidrūpasyaiva tatkila |
pratibhānamatastasmātparasmādbhidyate manāk
]

`v 51 [
so'yametādṛśo deho nainaṃ `note[naivaṃ iti pāṭhaḥ] saṃtyajya
yāmyaham |
anenaiva tamāpnomi deśaṃ gandhamivānilaḥ
]

`v 52 [
yathā jalaṃ jalenāgniragninā vāyunānilaḥ |
milatyevamato deho dehairanyairmanomayaiḥ
]

`v 53 [
nahi pārthivatāsaṃvidetya pārthivasaṃvidā |
ekatvaṃ kalpanāśailaśailayoḥ kvāhatirmithaḥ
]

`v 54 [
ātivāhika evāyaṃ tvādṛśaiścittadehakaḥ |
ādhibhautikatābuddhyā gṛhītaścirabhāvanāt
]

`v 55 [
yathā svapne yathā dīrghakāladhyāne yathā bhrame |
yathāca sati saṃkalpe yatha gandharvapattane
]

`v 56 [
vāsanātānavaṃ nūnaṃ yadā te sthitimeṣyati |
tadātivāhiko bhāvaḥ punareṣyati dehake
]

`v 57 [
līlovāca |
ātivāhikadehatvapratyaye ghanatāṃ gate |
tāmavāpnotyayaṃ deho daśāmāho vinaśyati
]

`v 58 [
śrīdevyuvāca |
yadasti nāma tatraiva nāśānāśakramo bhavet |
vastuto yacca nāstyeva nāśaḥ syāttasya kīdṛśaḥ
]

`v 59 [
rajjvāṃ sarpabhrame naṣṭe satyabodhavaśātsute `note[sute iti līlāyāḥ
saṃbodhanam] |
sarpo na naṣṭa unnaṣṭo vetyevaṃ kaiva sā kathā
]

`v 60 [
yathā satyaparijñānādrajjvāṃ sarpo na dṛśyate |
tathātivāhikajñānāddṛśyate nādhibhautikaḥ
]

`v 61 [
kalpanāpi nivarteta kalpitā yadi kenacit |
sā śilā samapāstaiva yā nehāsti kadācana
]

`v 62 [
paraṃ pare parāpūrṇamidaṃ dehādikaṃ sthitam |
iti satyaṃ vayaṃ bhadre paśyāmo nābhipaśyasi
]

`v 63 [
ādisarge bhaveccittvaṃ kalpanākalpitaṃ yadā |
tadā tataḥ prabhṛtyekasattvaṃ dṛśyamavekṣate
]

`v 64 [
līlovāca |
ekasminneva saṃśānte dikkālādyavibhāgini |
vidyamāne pare tattve kalanāvasaraḥ kutaḥ
]

`v 65 [
śrīdevyuvāca |
kaṭakatvaṃ yathā hemni taraṅgatvaṃ yathāmbhasi |
satyatvaṃ ca yathā svapnasaṃkalpanagarādiṣu
]

`v 66 [
satye hi vikāre'bhyupagate tvaduktadoṣaḥ syānna mithyābhūta iti devī pariharati ##-
nāstyeva satyanubhave tathā nāstyeva brahmaṇi |
kalpanāvyatiriktātmatatsvabhāvādanāmayāt
]

`v 67 [
yathā nāstyambare pāṃsuḥ pare nāsti tathā kalā |
akalākalanaṃ śāntamidamekamajaṃ tatam
]

`v 68 [
p. 183)
yadidaṃ bhāsate kiṃcittattasyeva nirāmayam |
kacanaṃ kācakasyeva kāntasyā'timaṇeriva
]

`v 69 [
līlovāca |
etāvantaṃ ciraṃ kālamete devi vayaṃ vada |
bhrāmitāḥ kena nāmāpi dvaitādvaitavikalpanaiḥ
]

`v 70 [
śrīdevyuvāca |
avicāreṇa tarale bhrāntāsi ciramākulā |
avicāraḥ svabhāvotthaḥ sa vicārādvinaśyati
]

`v 71 [
vicārabādhyatvādavicāraśabdito moha eva taddheturiti devyāha - avicāreṇeti |
70 |
avicāro vicāreṇa nimeṣādeva naśyati |
eṣā sattaiva tenāntaravidyaiṣā na vidyate
]

`v 72 [
eṣā avicāralakṣaṇā avidyā vicārabādhitā brahmasattaiva saṃpadyata iti śeṣaḥ |
71 |
tasmānnaivāvicāro'sti nāvidyāsti na bandhanam |
na mokṣo'sti nirābādhaṃ śuddhabodhamidaṃ jagat
]

`v 73 [
tadbādhasya traikālikatvamāha - tasmāditi | bandhābhāvānmokṣo'pi nāsti | 72
|
etāvantaṃ yadākālaṃ tvayaitanna vicāritam |
tadā na saṃprabuddhā tvaṃ bhrāntaivābhava `note[bhrāntevārṇava ākulā iti
pāṭhaḥ] ākulā
]

`v 74 [
adyaprabhṛti buddhāsi vimuktāsi vivekinī |
vāsanātānavaṃ bījaṃ patitaṃ tava cetasi
]

`v 75 [
ādāveva hi notpannaṃ dṛśyaṃ saṃsāranāmakam |
yadā tadā kathaṃ tena vāsyante vāsanāpi kā
]

`v 76 [
atyantābhāvasaṃpattau draṣṭṛdṛśyadṛśāṃ manaḥ |
ekadhyāne pare rūḍhe nirvikalpasamādhini
]

`v 77 [
vāsanākṣayabīje'sminkiṃcidaṅkurite hṛdi |
kramānnodayameṣyanti rāgadveṣādikā dṛśaḥ
]

`v 78 [
saṃsārasaṃbhavaścāyaṃ nirmūlatvamupaiṣyati |
nirvikalpasamādhānaṃ pratiṣṭhāmalameṣyati
]

`v 79 [
vigatakalanakālimākalaṅkā
gaganakalāntaranirmalāmbanena |
sakalakalanakāryakāraṇāntaḥ
katipayakālavaśādbhaviṣyasīti
]