`v 1 [
triṣaṣṭitamaḥ sargaḥ 63
śrīvasiṣṭha uvāva |
yadetadbrahmatattvaṃ sarvathā sarvadaiva sarvata eva sarvaśakti sarvākāraṃ
sarveśvaraṃ sarvagaṃ sarvameveti
]

`v 2 [
eṣa tvātmā sarvaśaktitvācca kvaciccicchaktiṃ prakaṭayati kvacicchāntiṃ
kvacijjaḍaśaktiṃ kvacidullāsaṃ kvacitkiṃcinna kiṃcitprakaṭayati
]

`v 3 [
yatra yadā yadevāsau yathā bhāvayati tatra tadā tadevāsau prapaśyati
]

`v 4 [
sarvaśakterhi yā yaiva yathodeti tathaiva sā
]

`v 5 [
tadāsti śaktirnānārūpiṇī sā svabhāvata imāḥ śaktayo'yamātmeti
]

`v 6 [
evaṃ vikalpajālaṃ vyavahārārthaṃ dhīmadbhiḥ parikalpitaṃ loke navātmani
vidyate bhedaḥ
]

`v 7 [
yathormitaraṅgapayasāṃ sāgare kaṭakāṅgadakayūrairvā hemnaḥ |
avayavāvayavinoḥ saṃvitkālpanikī dvitā na vāstavī
]

`v 8 [
natvātmani vidyate bheda ityatrārthe dṛṣṭāntatrayapradarśanaparo yathetyādirna
vāstavītyanto granthaḥ | saṃvitkālpanikī vyutpādakabuddhiparikalpitā dvitā bhidā |
7 |
yathā yaccetyate hi tathaiva tanna bāhyato nāntarataścaitatsamudeti hi
]

`v 9 [
sarvātmatvātsamābhāsaṃ kvacitkiṃcitprapaśyati
]

`v 10 [
sarvākāramayaṃ brahmaivedaṃ tataṃ mithyājñānavadbhiḥ
śaktiśaktimattve avayavāvayavirūpe kalpite na pāramārthike
]

`v 11 [
sadvā bhavatvasadvā cidyatsaṃkalpayatyabhiniviśati tattatpaśyati sakalā
tatsadbrahmaiva cidbhāti
]