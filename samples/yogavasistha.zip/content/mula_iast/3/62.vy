`v 1 [
p. 284) 175
dviṣaṣṭitamaḥ sargaḥ 62
śrīvasiṣṭha uvāca |
paramāṇunimeṣāṇāṃ lakṣāṃśakalanāsvapi |
jagatkalpasahasrāṇi satyānīva vibhāntyalam
]

`v 2 [
teṣvapyantastathaivāntaḥ paramāṇukaṇaṃ prati |
bhrāntirevamanantāho iyamityavabhāsate
]

`v 3 [
vahantīmāḥ parāḥ sattaḥ śāntāḥ sargaparamaparāḥ |
saliladravatevāntaḥsphuṭāvartavivartikā
]

`v 4 [
mithyātmikaiva sargaśrīrbhavatīha mahāmarau |
tīradrumalatonmuktapuṣpālīva taraṅgiṇī
]

`v 5 [
svapnendrajālapuravatsaṃkathehāpurādrivat |
saṃkalpavadasatyaiva bhāti sargānubhūtibhūḥ
]

`v 6 [
śrīrāma uvāca |
ekātmaikatayaivaṃ hi jāte samyagvicāraṇāt |
nirvikalpātmavijñāne pare jñānavatāṃ vara
]

`v 7 [
kimarthamiha tiṣṭhanti dehāstattvavidāmapi |
daivenaiva samākrāntā daivamatra ca kiṃ bhavet
]

`v 8 [
śrīvasiṣṭha uvāca |
astīha niyatirbrāhmī cicchaktiḥ spandarūpiṇī |
avaśyabhavitavyaikasattā sakalakalpagā
]

`v 9 [
ādisarge hi niyatirbhāvavaicitryamakṣayam |
anenetthaṃ sadā bhāvyamiti saṃpadyate param
]

`v 10 [
mahāsatteti kathitā mahācitiriti smṛtā |
mahāśaktiriti khyātā mahādṛṣṭiriti sthitā
]

`v 11 [
mahākriyeti gaditā mahodbhava iti smṛtā |
mahāspanda iti prauḍhā mahātmaikatayoditā
]

`v 12 [
tṛṇānīva jagantyevamiti daityāḥ surā iti |
iti nāgā iti nagā ityākalpaṃ kṛtāsthitiḥ
]

`v 13 [
kadācidbrahmasattāyā vyabhicāro'numīyate |
citramākāśakośe ca nānyathā niyateḥ sthitiḥ
]

`v 14 [
viriñcayādyātmabhirbuddhairbodhāyāviditātmanām |
brahmātmaiva sā niyatiḥ sargo'yamiti kathyate
]

`v 15 [
acalaṃ calavaddṛṣṭaṃ brahmāpūrya vyavasthitaḥ |
anādimadhyaparyantaṃ sargo vṛkṣa ivāmbare
]

`v 16 [
nanvalaṃ brahma calaḥ sargaḥ kathamanayoraikyaṃ tatrāha - acalamiti |
anādimadhyaparyantaṃ brahma āpūrya ajñadṛśā āpūryeva sargo vyavasthitaḥ |
15 |
pāṣāṇodaralekhaughanyāyenātmani tiṣṭhatā |
brahmaṇā niyatiḥ sargo buddho'bodhavateva kham
]

`v 17 [
p. 285) 175
dehe yathāṅgino'ṅgādi dṛśyate citsvabhāvataḥ |
brahmaṇā padmajatvena niyatyādyaṅgakaṃ tathā
]

`v 18 [
eṣā daivamiti proktā sarvaṃ sakalakālagam |
padārthamalamākramya śuddhā ciditi saṃsthitā
]

`v 19 [
śuddhā mohānāskanditā cit īśvarasaṃkalpacaitanyam | iti jagadvyavasthārūpeṇa |
18 |
spanditavyaṃ padārthena bhāvyaṃ vā bhokṛtāpadam |
anenetthamanenetthamavaśyamiti daivadhīḥ
]

`v 20 [
eṣaiva puruṣaspandastṛṇagulmādi cākhilam |
eṣaiva sarvabhūtādi jagatkālakriyādi vā
]

`v 21 [
anayā pauruṣī sattā sattāsyāḥ pauruṣeṇa ca |
lakṣyate bhuvanaṃ yāvaddve ekātmatayaiva hi
]

`v 22 [
nareṇa pauruṣeṇaiva kārye sattātmake ubhe |
īdṛśyetena niyatirevaṃ niyatipauruṣe
]

`v 23 [
praṣṭavyo'haṃ tvayā rāma daivapauruṣanirṇayaḥ |
maduktaṃ pauruṣaṃ pālyaṃ tvayeti niyatiḥ sthitā
]

`v 24 [
bhojayiṣyati māṃ daivamiti daivaparāyaṇaḥ |
yattiṣṭhatyakriyo maunaṃ niyatereṣa niścayaḥ
]

`v 25 [
yadapi kaściddaivamevāvalambya pauruṣaprayatnamakurvannājagaraṃ
vratamāsthāya tiṣṭhati tadapi
tadanuguṇaprāktanakarmopdbodhitaniyatiniścayādevetyāha - bhojayiṣyatīti | 24
|
na syādbuddhirna karmāṇi na vikārādi nākṛtiḥ |
kevalaṃ tvitthamākalpaṃ sthityā bhāvyamiti sthitāḥ
]

`v 26 [
avaśyaṃbhavitavyaiṣā tvidamitthamiti sthitiḥ |
na śakyate laṅghayitumapi rudrādibuddhibhiḥ
]

`v 27 [
pauruṣaṃ na parityājyametāmāśritya dhīmatā |
pauruṣeṇaiva rūpeṇa niyatirhi niyāmikā
]

`v 28 [
apauruṣaṃ hi niyatiḥ pauruṣaṃ saiva sargagā |
niṣphalā'pauruṣākārā saphalā pauruṣātmikā
]

`v 29 [
niyatyā mūkatāmetya niṣpauruṣatayā'kriyam |
yastiṣṭhati prāṇamarutspandastasya kva gacchati
]

`v 30 [
atha prāṇakriyārodhamapi kṛtvā virāmadam |
yadi tiṣṭhati tatsādhurmukta eva kimucyate
]

`v 31 [
pauruṣaikātmatā śreyo mokṣo'tyantamakartṛtā |
ābhyāṃ tu sabalaḥ pakṣo nirduḥkhaiva mahātmanām
]

`v 32 [
niyatirbrahmasattābhā tasyāṃ cetpariṇamyate |
nūnaṃ paramaśuddhākhyaṃ tatprāptaiva parāgatiḥ
]

`v 33 [
p. 286) 176
etairniyatyādimahāvilāsai-
rbrahmaiva visphūrjati sarvagātmā |
tṛṇādivallītarugulmajālaiḥ
satteva toyasya dharāntarasthā
]