`v 1 [
ekonasaptatitamaḥ sargaḥ 69
śrīvasiṣṭha uvāca |
atha varṣasahasreṇa tāṃ pitāmaha āyayau |
dāruṇaṃ hi tapaḥ siddhyai viṣāgnirapi śītalaḥ
]

`v 2 [
manasaiva praṇamyainaṃ sā tathaiva sthitā satī |
ko varaḥ kṣucchamāyālamiti cintānvitābhavat
]

`v 3 [
p. 298) 182
ā smṛtaṃ prārthayiṣye'haṃ varamekamimaṃ vibhum |
anāyasī cāyasī ca syāmahaṃ jīvasūcikā
]

`v 4 [
asyoktyā dvividhā sūcirbhūtvā lakṣyā viśāmyaham |
prāṇināṃ saha sarveṣāṃ hṛdayaṃ surabhiryathā
]

`v 5 [
yathābhimatametena graseyaṃ sakalaṃ jagat |
krameṇa kṣudvināśāya kṣudvināśaḥ paraṃ sukham
]

`v 6 [
iti saṃcintayantīṃ tāmuvāca kamalālayaḥ |
anyādṛśyāstathā dṛṣṭvā stanitābhrāravopamam
]

`v 7 [
śāntidāntidayāditapasvidharmaviruddhalokahiṃsābhilāṣiṇītvādanyā##-
brahmovāca |
putri karkaṭike rakṣaḥkulaśailābhramālike |
uttiṣṭha tvaṃ tu tuṣṭo'smi gṛhāṇābhimataṃ varam
]

`v 8 [
karkaṭyuvāca |
bhagavanbhūtabhavyeśa syāmahaṃ jīvasūcikā |
anāyasī cāyasī ca vidhe'rpayasi cedvaram
]

`v 9 [
śrīvasiṣṭha uvāca |
evamastviti tāmuktvā punarāha pitāmahaḥ |
sūcikā sopasargā tvaṃ bhaviṣyasi viṣūcikā
]

`v 10 [
sūkṣmayā māyayā sarvalokahiṃsāṃ kariṣyasi |
durbhojanā durārambhā mūrkhā duḥsthitayaśca ye
]

`v 11 [
durdeśavāsino duṣṭāsteṣāṃ hiṃsāṃ kariṣyasi |
praviśyā'hṛdayaṃ prāṇaiḥ padmaplīhādibādhanāt
]

`v 12 [
vātalekhātmikā vyādhirbhaviṣyasi viṣūcikā |
saguṇaṃ viguṇaṃ caiva janamāsādayiṣyasi
]

`v 13 [
guṇānvitacikitsārthaṃ mantro'yaṃ tu mayocyate |
brahmovāca |
himādreruttare pārśve karkaṭī nāma rākṣasī
]

`v 14 [
viṣūcikābhidhānā sā nāmnāpyanyāyabādhikā |
tasyā mantraḥ |
oṃ hrīṃ hrāṃ rīṃ rāṃ viṣṇuśaktaye namaḥ | oṃ namo bhagavati
viṣṇuśaktimenāṃ oṃ harahara nayanaya pacapaca mathamatha utsādaya dūre
kuru svāhā himavantaṃ gaccha jīva saḥ saḥ saḥ candramaṇḍalagato'si svāhā |
iti mantrī mahāmantraṃ nyasya vāmakarodare |
mārjayedāturākāraṃ tena hastena saṃyutaḥ
]

`v 15 [
himaśailābhimukhyena vidrutāṃ tāṃ vicintayet |
karkaṭīṃ karkaśākrandāṃ mantramudgaramarditām
]

`v 16 [
āturaṃ cintayeccandre rasāyanahṛdi sthitam |
ajarāmaraṇaṃ yuktaṃ muktaṃ sarvādhivibhramaiḥ
]

`v 17 [
sādhako hi śucirbhūtvā svācāntaḥ susamāhitaḥ |
krameṇānena sakalāṃ procchinatti viṣūcikām
]

`v 18 [
p. 299) 182
iti gaganagatastrilokanātho
gaganagasiddhagṛhītasiddhamantraḥ |
gata upagataśakravandyamāno
nijapuramakṣayamāyamujjvalaśrīḥ
]