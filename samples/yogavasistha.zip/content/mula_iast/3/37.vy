`v 1 [
saptatriṃśaḥ sargaḥ 37
śrīvasiṣṭha uvāca |
raṇe rabhasanirlūnanaravāraṇadāruṇe |
ahaṃpūrvamahaṃpūrvamiti vṛndānupātini
]

`v 2 [
ete cānye ca bahavastatra bhasmatvamāgatāḥ |
praviśantaḥ prayatnena śalabhā iva pāvake
]

`v 3 [
atrānye madhyadeśīyā janā nodāhṛtā mayā |
tānimāñchṛṇu vakṣyāmi pakṣāṁllīlāmahībhṛtaḥ
]

`v 4 [
taddehikāḥ śūrasenā guḍā aśvaghanāyakāḥ |
uttamajyotibhadrāṇi madamadhyamikādayaḥ
]

`v 5 [
sālūkākodyamālāsyā `note[sālūsākedya iti pāṭhaḥ] daurjñeyāḥ
pippalāyanāḥ |
māṇḍavyāḥ pāṇḍunagarāḥ saugrīvādyā gurugrahāḥ
]

`v 6 [
pāriyātrāḥ kurāṣṭrāśca yāmunodumbarā api |
rājyāhvā ujjihānāśca kālakoṭikamāthurāḥ
]

`v 7 [
pāñcālā dharmāraṇyāśca tathaivottaradakṣiṇāḥ |
pāñcālakāḥ kurukṣetrāstathā sārasvatā janāḥ
]

`v 8 [
avantīsyandanaśreṇīkuntipāñcanaderitaiḥ |
spandamānā vidravantī nipapāta mahābhṛgau
]

`v 9 [
kośabrahmāvasānāśca cchinnā `note[chinnāḥ śastra iti pāṭhaḥ]
vastravatījanaiḥ |
bhūmau nipatitāḥ santo militā mattavāraṇaiḥ
]

`v 10 [
śūrā dāśapurāḥ śastranikṛttodarakandharāḥ |
bāṇakṣitibhirākramya yojitā yojane hrade
]

`v 11 [
p. 219)
dīrṇodaraviniryātasvāntratantrīniyantritāḥ |
śāntikāḥ śāntasaṃcārāḥ piśāccaiścarvitā niśi
]

`v 12 [
udravairbhadragiribhiḥ saṃgrāmādhvaradīkṣitaiḥ |
kṣoṇigarteṣu nikṣiptā maragāḥ kamaṭhā iva
]

`v 13 [
ut utkṛṣṭo dravo vego ravo dhvanirvā yeṣāṃ taiḥ | kṣoṇigarteṣu palvalādiṣu | 12
|
pradrutā vidravadraktā vidrāvitamahārayaḥ |
daṇḍikāsthāniloddhūtā haihayairhariṇā iva
]

`v 14 [
dantidantavinirbhinnā dadā dalitārayaḥ |
nītā raktamahānadyā drumāṇāṃ pallavā iva
]

`v 15 [
nārācaiścarvitāścīnā jīrṇā jarjarajīvitāḥ |
jahurjalanidhau dehānbhārabhūtāniva sthitān
]

`v 16 [
karṇāṭasubhaṭoḍḍīnakuntākalitakandharāḥ |
bhagnā naladaśūrāśca tārakānikarā iva
]

`v 17 [
karīndramakaravyūharaṃhaḥsaṃhatahetayaḥ |
keśākeśikṛtārambhā vinedurdāśakāḥ śakāḥ
]

`v 18 [
daśārṇāḥ pāśanirmuktaśṛṅkhalā jālabhīravaḥ |
nilīnā raktajambāle vaitasāstimayo yathā
]

`v 19 [
gurjarānīkanāśena gurjarīkeśaluñcanam |
vihitaṃ taṅgaṇottuṅganāsiśaṅkuśatai raṇe
]

`v 20 [
siṣicuḥ śastrakarṇaughādbindubhyo nigaḍā guhān |
śaradhārāvanānīva vīrahetiprabhāmbudāḥ
]

`v 21 [
śastrakarṇānāṃ karṇavadūrdhvīkṛtaśastratvāttathā
prasiddhānāmoghātsaṃghānnirgatā vīrahetiprabhāvidyudbhirambudāyamānā
nigaḍā jānapadā guhān jānapadānprati śaradhārāḥ siṣucurakṣaran | yathā
vīrahetisadṛśaprabhā ambudāḥ svabindubhyo hetubhyo vanāni siṃcanti tadvat | 20
|
bhuśuṇḍīmaṇḍaloddyotaśyāmārkotpātabhīruṣu |
ābhīreṣvarayaḥ peturgogaṇā hariteṣviva
]

`v 22 [
kāntakāñcanakāntāsīttāmrasaṃgrāmavāhinī |
bhutā gauḍabhaṭenāṅga nakhakeśanikarṣaṇaiḥ
]

`v 23 [
raṇe naganayāsaṃkhyakavaccakranikṛntanaiḥ |
taṅgaṇāḥ kaṇaśaḥ kīrṇāḥ kaṅkagṛdhreṣubhāsakaiḥ
]

`v 24 [
laguḍāloḍanoḍḍīnaṃ gauḍaṃ guḍuguḍāravam |
śrutvā gāndhāragāvo'gre dudruvurdraviḍā iva
]

`v 25 [
ākāśagārṇavaprakhyo vahacchakakadambakaḥ |
akarotpārasīkānāṃ ghananaiśatamobhramam
]

`v 26 [
mandarāhananoḍḍīnasvacchakṣīrārṇavodare |
vanānīvāyudhānyāsañchatruprāleyasānuni
]

`v 27 [
yadambudairivoḍḍīnaṃ śastravṛndairnabhoṅgaṇe |
taddṛṣṭaṃ vīcivalanairlolaiḥ plutamivārṇave
]

`v 28 [
śatacandraṃ sitacchatraiḥ śaraiḥ śalabhanirbharam |
śaktibhiḥ kila nīrandhraṃ dṛṣṭamākāśakānanam
]

`v 29 [
śalabhaiḥ pataṅgairnirbharaṃ bhṛśaṃ vyāptam | nīrandhraṃ niravakāśam | 28
|
vīrāsavasamākrandakāriṇaḥ kekayaiḥ kṛtāḥ |
kaṅkaiḥ kaṅkakulākrāntavyomoddhūlitamastakāḥ
]

`v 30 [
kirātasainyakanyānāṃ kāmaṃ kalakalāravaiḥ |
aṅgairanaṅgatāṃ nītvā bhairavairiva garjitam `note[garjitaiḥ iti
pāṭhaḥ]
]

`v 31 [
kāśaistaddehakāḥ krāṃtā adṛśyairmāyayā khagaiḥ |
nirdhūtapakṣaiḥ kṣubhitaiḥ pavanairiva pāṃsavaḥ
]

`v 32 [
unmattāḥ suvinirdhūtāstyaktahetiraṇāmbarāḥ |
nārmadā narmanirmātṛ nanṛturjahasurjaguḥ
]

`v 33 [
p. 220)
prakkaṇatkiṃkiṇījālaṃ śaktivarṣamupāgatam |
sālvabāṇānilodbhūtamagamatpṛṣadākṛti
]

`v 34 [
śaibyāstu khaṇḍitāḥ kauntairbhramatkuntairvighaṭṭitāḥ |
śavībhūtā divaṃ nītā dṛṣṭā vidyādharā iva
]

`v 35 [
dharādharaṇadharmiṇyā dhīrayā hīnasenayā |
luṇṭhitāḥ pāṇdunagarāścalanollāsamātrataḥ
]

`v 36 [
taṃ dehakāḥ pāñcanadairdalitā mattakāśibhiḥ |
kuntadantadrumoddāmā nagā iva mataṅgajaiḥ
]

`v 37 [
kuntairgajadantairdrumaiśca praharaṇairuddāmā yuddhadakṣāḥ | nagā vṛkṣāḥ |
36 |
brahmāvatsanakā nīpaiścakraiḥ kṛttā gatā mahīm |
sahayāḥ krakacotkṛttā vṛkṣāḥ kusumitā iva
]

`v 38 [
śvetakākānanaṃ lūnaṃ kuṭhārairjaṭhareritaiḥ |
etaddadāha pārśvastho bhadreśaḥ śaravahninā
]

`v 39 [
kāṣṭhayodhe nirālānaṃ magnā jīrṇā mataṅgajāḥ |
layamājagmurāyuddhamiddhegnāvindhanaṃ yathā
]

`v 40 [
mitragartāstrigartāttā bhramitvordhvaṃ tṛṇopamam |
viviśurvyastamūrdhānaḥ pātālāntaṃ palāyitum
]

`v 41 [
mandānilacalāmbhodhibhāsure māgadhe bale |
nirmagnā vanilā mandāḥ paṅke jīrṇagajā iva
]

`v 42 [
cedayaścetanāṃ jahnustaṅgaṇānāṃ raṇāṅgaṇe |
puṣpāṇāṃ pathi śīrṇānāṃ saukumāryamivātapāḥ
]

`v 43 [
kausalāḥ pauravārāvamasahanto'ntakā iva |
tairunmuktagadāprāsaśaraśaktyativṛṣṭayaḥ
]

`v 44 [
babhūvurbhallakṛttāṅgā'vismayā vidrumadrumāḥ |
ivādrau vidravantyārdrasāndrāsṛksūryamūrtayaḥ
]

`v 45 [
nārācaughamahāhetimārutādhūtamūrtayaḥ |
babhramurbhramarānīkabhāsurā jaladā iva
]

`v 46 [
śaradhārādharā meghāḥ śarorṇāpūrṇameṣakāḥ |
śarapatrāvṛtā vṛkṣā bhremustadgarjanāgajāḥ
]

`v 47 [
vanarājyajarājīrṇāḥ kandākasthalajantavaḥ `note[kaṇṭakasthala iti
pāṭhaḥ] |
atruṭanparamākṛṣṭāḥ pelavā iva tantavaḥ
]

`v 48 [
ratheṣu dhvastacakreṣu nikhāte'mutra mūrdhasu |
nipeturjanasaṃghātā meghā iva vanādriṣu
]

`v 49 [
śālatālavanaṃ prāpya janatāvalanaṃ vanam |
bhujāvakartanaṃ cāsīduttālaṃ sthāṇukānanam
]

`v 50 [
nanardurnandanodyānasundaryo mattayauvanāḥ |
vanopavanadeśeṣu merorvīravarāśritāḥ
]

`v 51 [
tāvattārāravaṃ reje sainyakānanamuttamam |
yāvanna parapakṣeṇa prāptaṃ kalpānalārciṣā
]

`v 52 [
chinnāḥ piśācasaṃyuktā bhūtāpahṛtahetayaḥ |
pātayitvā yayuḥ karṇāndaśārṇāstarṇakā iva
]

`v 53 [
jahurbhagneśvarāḥ kāntiṃ tāṃ jigīṣavanaujasā |
kāsayaḥ `note[kāśayaḥ iti pāṭhaḥ] kamalānīva śuṣkasrotasvinaujasā |
53 |
bhagneśvarā hatasvāmikāḥ | tāṃ jigīṣavanānāṃ jānapadānām | śuṣkāḥ
srotasvinaḥ saraḥpūrakanirjharā yena tathāvidhena grīṣmaujasā
]

`v 54 [
tuṣākā mesalaiḥ `note[mekhalaiḥ iti pāṭhaḥ] kīrṇāḥ
śaraśaktyasimudgaraiḥ |
vidrutā narakaiḥ kṣiptāḥ kaṭakacchalanā api
]

`v 55 [
p. 221)
kauntakṣetrāḥ prasthavāsaiḥ sthitvā yodhibhirāvṛtāḥ |
guṇā iva khalākrāntā gatā vyaktamaśaktatām
]

`v 56 [
dvipayo bāhudhānānāṃ kṣaṇenādāya mastakam |
bhallaiḥ palāyyāśu gatā vilūnakamalā iva
]

`v 57 [
mithaḥ sārasvatā nītvā ādināntaṃ kṛtājayaḥ |
paṇḍitā iva vādeṣu nodvignā na parājitāḥ
]

`v 58 [
kharvagāḥ khaditāḥ kṣudrā yātudhānaiḥ parāvṛtāḥ |
tejaḥ paramamājagmuḥ śāntāgnaya ivendhanaiḥ
]

`v 59 [
kiyadākhyāyata eta-
jjihvānicayaiḥ kilālamākulitaḥ |
vāsukirapi varṇayituṃ
na samartho raṇavaraṃ rāma
]