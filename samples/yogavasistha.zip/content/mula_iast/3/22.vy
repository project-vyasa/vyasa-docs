`v 1 [
dvāviṃśaḥ sargaḥ 22
śrīdevyuvāca |
yathā svapnaparijñānātsvapnadeho na vāstavaḥ |
anubhūto'pyayaṃ tadvadvāsanātānavādasan
]

`v 2 [
yathā svapnaparijñānātsvapnadehaḥ praśāmyati |
vāsanātānavāttadvajjāgraddeho'pi śāmyati
]

`v 3 [
svapnasaṃkalpladehānte deho'yaṃ cetyate yathā |
tathā jāgradbhāvanānte udetyevātivāhikaḥ
]

`v 4 [
svapne nirvāsanābīje yathodeti suṣuptatā |
jāgratyavāsanābīje tathodeti vimuktatā
]

`v 5 [
yeyaṃ tu jīvanmuktānāṃ vāsanā sā na vāsanā |
śuddhasattvābhidhānaṃ tatsattāsāmānyamucyate
]

`v 6 [
p. 184)
yā suptavāsanā nidrā sā suṣuptiriti smṛtā |
yatsuptavāsanaṃ jāgraddhano'sau moha ucyate
]

`v 7 [
prakṣīṇavāsanā nidrā turyaśabdena kathyate |
jāgratyapi bhavatyeva vidite `note[vihite parame iti pāṭhaḥ] parame pade | 7
|
nidretyavivakṣitaṃ yato jāgratyapi jñānātsamūlavāsanākṣaye turyaṃ
bhavatyevetyarthaḥ
]

`v 8 [
prakṣīṇavāsanā yeha jīvatāṃ jīvanasthitiḥ |
amuktairaparijñātā sā jīvanmuktatocyate
]

`v 9 [
śuddhasatvānupatitaṃ cetaḥ pratanuvāsanam |
ātivāhikatāmeti himaṃ tāpādivāmbutām
]

`v 10 [
ātivāhikatāṃ yātaṃ buddhaṃ cittāntarairmanaḥ |
sargajanmāntaragataiḥ siddhairmilati netarat
]

`v 11 [
yadā te'yamahaṃbhāvaḥ svabhyāsācchāntimeṣyati `note[svābhyāsāt
pāṭhaḥ] |
tadodeṣyati te sphārā dṛśyāntā `note[dṛśyānte bodhatā iti pāṭhaḥ]
bodhatā svayam
]

`v 12 [
ātivāhikatājñānaṃ sthitimeṣyati śāśvatīm |
yadā tadā hyasaṃkalpāṁllokāndrakṣyasi pāvanān
]

`v 13 [
vāsanātānave tasmātkuru yatnamanindite |
tasminprauḍhimupāyāte jīvanmuktā bhaviṣyasi
]

`v 14 [
yāvanna pūritastveṣa śītalo bodhacandramāḥ |
tāvaddehamavasthāpya lokāntaramavekṣyatām
]

`v 15 [
māṃsadeho māṃsadehenaiva saṃśleṣameṣyati |
natu cittaśarīreṇa vyavahāreṣu karmasu
]

`v 16 [
yathānubhavamevaitadyathāsthitamudāhṛtam |
ābālasiddhasaṃsiddhaṃ na nāma varaśāpavat
]

`v 17 [
avabodhaghanābhyāsāddehasyāsyaiva jāyate |
saṃsāravāsanākārśye nūnaṃ cittaśarīratā
]

`v 18 [
udeṣyantī ca saivātra kenacinnopalakṣyate |
kevalaṃ tu janairdeho mriyamāṇo'valokyate
]

`v 19 [
dehastvayaṃ na mriyate na ca jīvati kiṃca te |
ke kila `note[kokilasvapna pāṭhaḥ] svapnasaṃkalpabhrāntau maraṇajīvite |
19 |
kiṃcāvāstavo'yaṃ deho na mriyate na ca jīvati te jīvanamaraṇe ca kiṃ na
kiṃcidvastviti nātra virodhaśaṅkā yuktetyarthaḥ
]

`v 20 [
jīvitaṃ maraṇaṃ caiva saṃkalpapuruṣe yathā |
asatyameva bhātyevaṃ tasminputri śarīrake
]

`v 21 [
līlovāca |
tadetadupadiṣṭaṃ me jñānaṃ devi tvayā'malam |
yasmiñśrutigate śāntimeti dṛśyaviṣūcikā
]

`v 22 [
atropakuru me brūhi ko'bhyāsaḥ kīdṛśo'thavā |
sa kathaṃ poṣamāyāti puṣṭe tasmiṃśca kiṃ bhavet
]

`v 23 [
śrīdevyuvāca |
yadyena `note[yadaiva kriyate pāṭhaḥ] kriyate kiṃcidyena yena yadā yadā |
vinābhyāsena tanneha siddhimeti kadācana
]

`v 24 [
taccintanaṃ tatkathanamanyonyaṃ tatprabodhanam |
etadekaparatvaṃ ca tadabhyāsaṃ vidurbudhāḥ
]

`v 25 [
ye viraktā mahātmāno bhogabhāvanatānavam |
bhāvayantyabhavāyāntarbhavyā bhuvi jayanti te
]

`v 26 [
p. 185)
uditaudāryasaundaryavairāgyarasarañjitā `note[rasagarbhiṇī iti pāṭhaḥ] |
ānandaspandinī yeṣāṃ matiste'bhyāsinaḥ pare
]

`v 27 [
atyantābhāvasaṃpattau jñātṛjñeyasya vastunaḥ |
yuktyā śāstrairyatante ye te brahmābhyāsinaḥ sthitāḥ
]

`v 28 [
sargādāveva notpannaṃ dṛśyaṃ nāstyeva tatsadā |
idaṃ jagadahaṃ ceti bodhābhyāsa `note[bodhābhyāsaṃ viduḥ pare iti
pāṭhaḥ] udāhṛtaḥ
]

`v 29 [
traikālikadṛśyabādhadarśanāvṛttirapi tadabhyāsa ityāha - sargādāviti |
28 |
dṛśyāsaṃbhavabodhena rāgadveṣāditānave |
ratirbaloditā yāsau brahmābhyāsa udāhṛtaḥ
]

`v 30 [
dṛśyāsaṃbhavabodhena vinā dveṣāditānavam |
tapa ityucyate tasmānna jñānaṃ tacca duḥkhatat
]

`v 31 [
dṛśyāsaṃbhavabodho hi jñānaṃ jñeyaṃ ca kathyate |
tadabhyāsena nirvāṇamityabhyāso mahodayaḥ
]

`v 32 [
bhavabahulaniśānitāntanidrā-
satatavivekavibodhavārisekaiḥ |
pragalati himaśītalairaśeṣā `note[raśeṣaṃ śaradi iti pāṭhaḥ]
śaradi mahāmihikeva cetasīti
]

`v 33 [
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]