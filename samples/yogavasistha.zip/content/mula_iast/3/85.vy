`v 1 [
p. 336) 203
pañcāśītitamaḥ sargaḥ 85
śrīvasiṣṭha uvāca |
purā me brahmaṇā proktaṃ sarvaṃ tatkathayānagha |
yadidaṃ tatpravakṣyāmi tvayi pṛcchati rāghava
]

`v 2 [
purā mayā hi bhagavānpṛṣṭhaḥ kamalasaṃbhavaḥ |
ime kathamupāyānti brahmansargagaṇā iti
]

`v 3 [
tadupāśrutya bhagavānbrahmā lokapitāmahaḥ |
aindavākhyānasahitaṃ māmuvāca bṛhadvacaḥ
]

`v 4 [
brahmovāca |
sarvaṃ hi mana evedamitthaṃ sphurati bhūtimat |
jalaṃ jalāśayasphārairvicitraiścakrakairiva
]

`v 5 [
dinādau saṃprabuddhasya saṃsāraṃ sraṣṭumicchataḥ |
purākalpe hi kasmiṃścicchṛṇu kiṃ vṛttamaṅga me
]

`v 6 [
kadācidakhilaṃ sargaṃ saṃhṛtya divasakṣaye |
eka evāhamekāgraḥ svasthastāmanayaṃ niśām
]

`v 7 [
niśānte saṃprabuddhātmā saṃdhyāṃ kṛtvā yathāvidhi |
prajāḥ sraṣṭuṃ dṛśau sphāre vyomni yojitavānaham
]

`v 8 [
yāvatpaśyāmi gaganaṃ na tamobhirna tejasā |
vyāptamatyantavitataṃ śunyamantavivarjitam
]

`v 9 [
vidyamānasyāpi tamaso divyasvadṛṣṭiprasārāvighātitvānna tamobhirityuktam | 8
|
sargaṃ saṃkalpayāmīti matiṃ niścitya tanmayā |
samavekṣitumārabdhaṃ śuddhaṃ sūkṣmeṇa cetasā
]

`v 10 [
athāhaṃ dṛṣṭavāṃstatra manasā vitate'mbare |
pṛthaksthitānmahārambhānsargānsthitinirargalān
]

`v 11 [
teṣu matpratibimbābhāḥ padmakośanivāsinaḥ |
rājahṃsānsamārūḍhāḥ saṃsthitā daśa padmajāḥ
]

`v 12 [
pṛthaksthiteṣu sargeṣu teṣūdyadbhūtapaṅktiṣu |
jalajāleṣu śuddheṣu jagatsu jaladāyiṣu
]

`v 13 [
pravahanti mahānadyaḥ pradhvananti yathābdhayaḥ |
pratapantyuṣṇārucayaḥ prasphurantyambare'nilāḥ
]

`v 14 [
divi krīḍanti vibudhā bhuvi krīḍanti mānavaḥ |
dānavā bhoginaścaiva pātāleṣu ca saṃsthitāḥ
]

`v 15 [
kālacakrapariprotā yadbhāvāḥ sakalartavaḥ |
yathākālaṃ phalāpūrṇā bhūṣayantyabhito mahīm
]

`v 16 [
yadbhāvāḥ yādṛśaśītātapavarṣādisvabhāvāḥ | sakalā ṛtavo vasantādayaḥ |
15 |
prauḍhyaṃ śubhāśubhācārasmṛtayaḥ kakubhaṃ prati |
narakasvargaphaladāḥ sarvatra samupāgatāḥ
]

`v 17 [
bhogamokṣaphalārthinyaḥ samastā bhūtajātayaḥ |
svamīhitaṃ yathākālaṃ prayatante yathākramam
]

`v 18 [
saptalokāstathā dvīpāḥ samudrā girayastathā |
apyeṣyamāṇāḥ kalpāntaṃ sphurantyurutarāravam
]

`v 19 [
kvaciddhrāsitvamāyātaṃ kvacitsthirataraṃ sthitam |
sthitaṃ sarvatra kuñjeṣu tamastejolavādṛtam
]

`v 20 [
nabhonīlotpalasyāntarbhramadabhramadhuvratam |
prasphurattārakājālakesarāpūrṇatāṃ gatam
]

`v 21 [
kalpāntaghananīhāro merukuñjeṣu saṃsthitaḥ |
śālmaleramalaṃ tūlamaṣṭhīlākoṭareṣviva `note[aṣṭhilā iti mudritapustake
pāṭhaḥ]
]

`v 22 [
lokālokādrirasanāraṇadarṇavaghuṃghumā |
tamaḥkhaṇḍendranīlābhā nijaratnavirājitā
]

`v 23 [
dhānādharasudhā bhūtaravakākalighuṃghumā |
saṃsthitā bhuvanābhoge svāntaḥpura ivāṅganā
]

`v 24 [
p. 337) 203
gaurāṅgapaṅktirmadhyasthā rajanīrājirañjitā |
padmotpalasraja iva lakṣyate vatsaraśriyaḥ
]

`v 25 [
bahugartavibhāgasthabhūtā lokāḥ pṛthakpṛthak |
jātāruṇā vilokyante dāḍimānīva kāntikāḥ
]

`v 26 [
tripravāhā tripathagā kṛtordhvādhogamāgamā |
jagadyajñopavītābhā sphuratīndukalāmalā
]

`v 27 [
itaścetaśca gacchanti śīryante prodbhavanti ca |
diglatāsu taḍitpuṣpā vātārtā meghapallavāḥ
]

`v 28 [
gandharvanagarodyānalatāvitānamālinī |
samudrabhūminabhasāṃ padavī pravirājate
]

`v 29 [
lokāntareṣu saṅghena devāsuranaroragāḥ |
udumbareṣu maśakā iva ghuṃghumitāḥ sthitāḥ
]

`v 30 [
yugaklpakṣaṇalavakalākāṣṭhākalaṅkitaḥ |
kālo vahatyakalitasarvanāśapratīkṣakaḥ
]

`v 31 [
evamālokya śuddhena pareṇa svena cetasā |
bhṛśaṃ vismayamāpannaḥ kimetatkathamityalam
]

`v 32 [
kathaṃ māṃsamayenākṣṇā yanna paśyāmi kiṃcana |
tanmāyājālamatulaṃ paśyāmi manasāmbare
]

`v 33 [
athālokya ciraṃ kālaṃ manasaivāhamambarāt |
arkaṃ tasmājjagajālādekamānīya pṛṣṭhavān
]

`v 34 [
āgaccha devadeveśa bho bhāskara mahādyute |
svāgataṃ te'stviti prokto mayāsau kathitopyatha
]

`v 35 [
kastvaṃ kathamidaṃ jātaṃ jagadeva jaganti ca |
yadi jānāsi bhagavaṃstadetatkathayānagha
]

`v 36 [
ityukto māṃ samālokya saṃparijñātavānatha |
namaskṛtvābhyuvācedamanindyapadayā girā
]

`v 37 [
śrībhānuruvāca |
asya dṛśyaprapañcasya nityaṃ kāraṇatāmasi |
gataḥ kasmānna jānīṣe kiṃ māmīśvara pṛcchasi
]

`v 38 [
atha madvākyasaṃdarbhe līlā cettava sarvaga |
acintitāṃ madutpattiṃ tacchṛṇuṣva vadāmyaham
]

`v 39 [
sadasaditi kalābhirātataṃ yat
sadasadabodhavimohadāyinībhiḥ |
avirataracanābhirīśvarātman
pravilasatīha mano mahanmahātman
]