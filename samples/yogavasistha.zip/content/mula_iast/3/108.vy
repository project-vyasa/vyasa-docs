`v 1 [
p. 381) 226
aṣṭottaraśatatamaḥ sargaḥ 108
rājovāca |
atha gacchati kāle'tra jarājarjaritāyuṣi |
tuṣārapūrṇaśaṣpaughasamaśmaśrubhṛte mayi
]

`v 2 [
karmavātāpanunneṣu saraseṣvaraseṣvapi |
patatsu vāsaraugheṣu śīrṇaparṇagaṇeṣviva
]

`v 3 [
ājāviva śaraugheṣu sukhaduḥkheṣvanāratam |
kalaheṣvapyakāryeṣu cāgacchatsu patatsu ca
]

`v 4 [
vikalpakalpanāvartavartini dvijage jaḍe |
samudra iva kallolabhare bhramitacetasi
]

`v 5 [
calaccintācitaṃ cakramārūḍhe bhrānta ātmani |
prohyamāne tṛṇa iva sāvartaṃ kālasāgare
]

`v 6 [
vindhyorvīvanakīṭasya grāsaikaśaraṇasya me |
dvibāhorgardabhasyātra kṣīṇa itthaṃ samāgaṇe
]

`v 7 [
vismṛte mama bhūpatve śavasyeva mahājave |
cāṇḍālatve sthirībhūte pakṣacchinna ivācale
]

`v 8 [
saṃsāramiva kalpānto dāvāgniriva kānanam |
sāgarormistaṭamiva śuṣkavṛkṣamivāśaniḥ
]

`v 9 [
akāṇḍe maraṇoḍḍīnaṃ caṇḍacaṇḍālamaṇḍalam |
nirannatṛṇapatrāmbu vindhyakacchaṃ tadāyayau
]

`v 10 [
na varṣati ghanavrāte dṛṣṭanaṣṭe kvacitsthite |
pūtāṅgārakaṇonmiśragatau vahati mārute
]

`v 11 [
śīrṇamarmaraparṇāsu dāvāgnivalitāsu ca |
vanasthalīṣu śūnyāsu cirapravrajitāsviva
]

`v 12 [
akāṇḍamabhavadbhīmamuddāmadavapāvakam |
śoṣitāśeṣagahanaṃ bhasmaśeṣatṛṇolapam `note[tṛṇopalam iti
pāṭhaḥ]
]

`v 13 [
pāṃsudhūsarasarvāṅgaṃ kṣudhitāśeṣamānavam |
nirannatṛṇapānīyaṃ deśādyuddāvamaṇḍalam
]

`v 14 [
kacanmarumarīcyambumajjanmahiṣamaṇḍalam |
vātotthasīkaravyūhāparivāhavanāmbaram
]

`v 15 [
pānīyaśabdamātraikaśravaṇotkanaravrajam |
ātapātatisaṃśoṣasīdatsakalamānavam
]

`v 16 [
patragrasanasaṃrabdhakṣudhitotthitajīvitam |
svāṅgacarvaṇasaṃrambhaluṭhaddaśanamaṇḍalam
]

`v 17 [
patragrasanodyogena kṣubhitebhya utthitaṃ prasthitaṃ jīvitaṃ yatra | svāṅgacarvaṇe
saṃrambheṇābhilāṣeṇa luṭhanti parasparamupaghnanti daśanamaṇḍalāni yatra |
16 |
māṃsaśaṅkānigīrṇograkhadirāgnikaṇotkaram |
maṇḍakāsārasaṃgrastavanapāṣāṇakhaṇḍakam
]

`v 18 [
anyonyabhūtasaṃsaktamātṛputrapitṛvrajam |
gṛdhrodararaṭatsāranigīrṇavarasārikam
]

`v 19 [
parasparāṅgavicchedaraktasiktadharātalam |
harigrasanasaṃrabdhamattakṣudhitavāraṇam
]

`v 20 [
darīnigaraṇaikaikasiṃhabhramaṇabhīṣaṇam |
anyonyagrasanodyuktalokamallakṛtaṃ vahat
]

`v 21 [
niṣpatrapādapoḍḍīnaprauḍhāṅgāramayānilam |
raktapānotkamārjāralīḍhadhātutaṭāvani
]

`v 22 [
jvālāghanaghaṭāṭopasāvartasavanānilam |
sarvasthalarasadvahnipuñjapiñjarajaṅgalam
]

`v 23 [
dagdhājagarakuñjotthadhūmamāṃsalagulmakam |
mārutāvalitajvālāsaṃdhyābhravalitāmbaram
]

`v 24 [
uddāmaravamudbhrāntabhasmanā'stambhamaṇḍalam |
sākrandanaradārāgradīnārbhakakṛtāravam
]

`v 25 [
saṃbhrāntapuruṣavyūhadantakṛttamahāśavam |
māṃsagandhajavagrastaraktāraktanijāṅguli
]

`v 26 [
p. 382) 227
nīlapatralatāśaṅkāpītadhūmaghanacchavi |
bhramadgṛdhranigīrṇogranabhobhrāntolmukābhiṣam
]

`v 27 [
itaretarabhinnāṅgalokavidravaṇākulam |
jvalitāgniṭaṇatkāravidīrṇahṛdayodaram
]

`v 28 [
gartamārutakrāṅkārabhīmadāvāgnivalganam |
bhītājagaraphūtkārapatadaṅgārapādapam
]

`v 29 [
sadakāṇḍasphuṭaddeśaṃ prāpya tacchuṣkakoṭaram |
dvādaśārkāgnidagdhasya jagato'nukṛtiṃ yayau
]

`v 30 [
jvaladanalajaṭālavṛkṣakhaṇḍa-
prasaramarutprasarāvanunnalokaḥ |
jvalanatapanabhāskarātmajānāṃ
ramaṇagṛhānukṛtiṃ jagāma deśaḥ
]