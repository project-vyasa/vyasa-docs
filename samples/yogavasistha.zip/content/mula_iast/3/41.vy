`v 1 [
ekacatvāriṃśaḥ sargaḥ 41
śrīvasiṣṭha uvāca |
tayoḥ praviṣṭayordevyoḥ padmasadma babhūva tat |
candradvayodayodyotadhavalodarasundaram
]

`v 2 [
komalāmalasaugandhyamṛdumandāramārutam |
tatprabhāvena nidrālunṛpetaranarāṅganam
]

`v 3 [
saubhāgyanandanodyānaṃ vidrutavyādhivedanam |
savasantaṃ vanamiva phullaṃ prātarivāmbujam
]

`v 4 [
tayordehaprabhāpūraiḥ śaśinisyandaśītalaiḥ |
āhlādito'sau bubudhe rājokṣita ivāmṛtaiḥ
]

`v 5 [
āsanadvayaviśrāntaṃ sa dadarśāpsarodvayam |
meruśṛṅgadvaye candrabimbadvayamivoditam
]

`v 6 [
nimeṣamiva saṃcintya sa vismitamanā nṛpaḥ |
uttasthau śayanāccheṣādiva cakragadādharaḥ
]

`v 7 [
parisaṃyamitālambimālyahārādharāmbaraḥ |
puṣpāhāra ivotphullaṃ jagrāha kusumāñjalim
]

`v 8 [
p. 230)
upadhānapradeśasthātsvayaṃ paṭalakoṭarāt |
baddhapadmāsano bhūmau bhūtvovācedamānataḥ
]

`v 9 [
jayatāṃ janmadausthityadāhadoṣaśaśiprabhe |
devyau vāhyāntaratamovidrāvaṇaraviprabhe
]

`v 10 [
tayoruktveti tatyāja pādayoḥ kusumāñjalim |
tīradrumo vikasitaḥ padminyoḥ padmayoriva
]

`v 11 [
līlāyai bhūpajanmātha vaktuṃ mantriṇamīśvarī |
bodhayāmāsa pārśvasthaṃ saṃkalpena sarasvatī
]

`v 12 [
prabuddhopsarasau dṛṣṭvā praṇamya kusumāñjalim |
tayoḥ pādeṣu saṃtyajya viveśa purato nataḥ
]

`v 13 [
uvāca devī he rājankastvaṃ kasya sutaḥ kadā |
iha jāta iti śrutvā sa mantrī vākyamabravīt
]

`v 14 [
devyau yuṣmatprasādo'yaṃ bhavatyorapi yatpuraḥ |
vaktuṃ śaknomi taddevyau `note[tadidaṃ iti pāṭhaḥ] śrūyetāṃ janma
matprabhoḥ
]

`v 15 [
āsīdikṣvākuvaṃśottho rājā rājīvalocanaḥ |
śrīmānkundaratho nāma dośchāyācchāditāvaniḥ
]

`v 16 [
dośchāyayā ācchāditeva śatrudāridryādisaṃtāpanivāraṇena pālitā avaniryena |
15 |
tasyābhūdinduvadanaḥ putro bhadrarathābhidhaḥ |
tasya viśvarathaḥ putrastasya putro bṛhadrathaḥ
]

`v 17 [
tasya sindhurathaḥ putrastasya śailarathaḥ sutaḥ |
tasya kāmarathaḥ putrastasya putro mahārathaḥ
]

`v 18 [
tasya viṣṇurathaḥ putrastasya putro nabhorathaḥ |
ayamasmtprabhustasya putraḥ pūrṇāmalākṛtiḥ
]

`v 19 [
amṛtāpūritajanaḥ kṣīrodasyeva candramāḥ |
mahadbhiḥ puṇyasaṃbhārairvidūratha iti śrutaḥ
]

`v 20 [
jāto mātuḥ sumitrāyā gauryā guha ivāparaḥ |
pitāsya daśavarṣasya dattvā rājyaṃ vanaṃ gataḥ
]

`v 21 [
pālayatyeṣa bhūpīṭhaṃ tataḥ prabhṛti dharmataḥ |
bhavatyāvadyasaṃprāpte phalite sukṛtadrume
]

`v 22 [
devyau dīrghatapaḥkleśaśatairduṣprāpadarśane |
ityayaṃ vasudhādhīśo vidūratha iti śrutaḥ
]

`v 23 [
adya yuṣmatprasādena parāṃ pāvanatāṃ gataḥ |
ityuktvā saṃsthite tūṣṇīṃ mantriṇyavanipe tathā
]

`v 24 [
kṛtāñjalau natamukhe baddhapadmāsane'vanau |
rājansmara vivekena pūrvajātimiti svayam
]

`v 25 [
vadantī mūrdhni pasparśa taṃ kareṇa sarasvatī |
atha hārdaṃ tamo māyāpadmasya kṣayamāyayau
]

`v 26 [
suvikāsaṃ ca hṛdayaṃ jñaptisparśodaye'bhavat |
sasmāra pūrvavṛttāntamantaḥ sphuradiva sthitam
]

`v 27 [
tyaktadehaikarājyatvaṃ līlāvilasitānvitam |
jñātvā prajñaptivṛttāntaṃ līlāyāstu vijṛmbhitam
]

`v 28 [
ātmodantaṃ babhūvāsāvuhyamāna ivārṇave |
uvācātmani saṃsāre bata māyeyamātatā
]

`v 29 [
parijñātā prasādena devyoriha mayādhunā |
rājovāca |
he devyau kimidaṃ nāma dinamekaṃ mṛtasya me
]

`v 30 [
gatamadyeha jātāni vayo varṣāṇi saptatiḥ |
smarāmyanekakāryāṇi smarāmi prapitāmaham
]

`v 31 [
smarāmi bālyaṃ tāruṇyaṃ mitraṃ bandhuparicchadam |
jñaptiruvāca |
rājanmṛtimahāmohamūrcchāyāḥ samanantaram
]

`v 32 [
tasmiṁllokāntare'tīte tasminneva muhūrtake |
tasminneva gṛhe cāsminneva vyomnyapi sadmani
]

`v 33 [
ayaṃ tasya gṛhasyāntarvyomanyeva kila sthite |
girigrāmakaviprasya gṛhe'ntarbhūpa maṇḍapaḥ
]

`v 34 [
tasyāntare'yamābhāti pratyekaṃ ca jagadgṛham |
kila brāhmaṇagehāntarjīvaste madupāsthitaḥ
]

`v 35 [
p. 231)
tatraiva tasya bhūpīṭhaṃ tasmiṃśca kila maṇḍape |
tasyaiva ca gṛhasyāntaridaṃ saṃsāramaṇḍalam
]

`v 36 [
tatraivedaṃ tava gṛhaṃ sthitamārambhamantharam |
tatraiva cetasi tava nirmalākāśanirmale
]

`v 37 [
pratibhāmāgatamdaṃ vyavahārabhramātatam |
yathedaṃ nāma me janma tathekṣvākukulaṃ mama
]

`v 38 [
evaṃnāmāna ete me purābhūvanpitāmahāḥ |
jāto'hamabhavaṃ bālo daśavarṣasya me pitā
]

`v 39 [
parivrāḍvipinaṃ yāta iha rājye'bhiṣicya mām |
tato digvijayaṃ kṛtvā kṛtvā rājyamakaṇṭakam
]

`v 40 [
amībhirmantribhiḥ pauraiḥ pālayāmi vasundharām |
yajñakriyākramavato dharme pālayataḥ prajāḥ
]

`v 41 [
vayasaḥ samatītāni mama varṣāṇi saptatiḥ |
idaṃ parabalaṃ prāptaṃ mama dāruṇavigrahaḥ
]

`v 42 [
yuddhaṃ kṛtvedamāyāto gṛhamasminyathāsthitam |
ime devyau gṛhe prāpte mamaite pūjayāmyaham
]

`v 43 [
pūjitā hi prayacchanti devatāḥ svasamīhitam |
mameyametayorekā jñānaṃ jātismṛtipradam
]

`v 44 [
iha dattavatī devī bhābjasyeva vikāsanam |
idānīṃ kṛtakṛtyo'smi jāto'smi gatasaṃśayaḥ
]

`v 45 [
śāmyāmi parinirvāmi sukhamāse ca kevalam |
itīyamātatā bhrāntirbhavato bhūrisaṃbhramā
]

`v 46 [
nānācāravihārāḍhyā salokāntarasaṃcarā |
yasminneva muhūrte tvaṃ mṛtimabhyāgataḥ purā
]

`v 47 [
tadaiva pratibhaiṣā te svayamevoditā hṛdi |
ekāmāvartacalanāṃ tyaktvā datte yathā'parām `note[yathā purā iti
pāṭhaḥ]
]

`v 48 [
kṣiprameva nadīvāho vitpravāhastathaiva ca |
āvartāntarasaṃmiśro `note[saṃsiddho iti pāṭhaḥ] yathāvartaḥ pravartate
]

`v 49 [
kadācidevaṃ sargaśrīrmiśrā'miśrā ca vardhate |
tasminmrtimuhūrte te pratibhānamupāgatam
]

`v 50 [
etajjālamasadrūpaṃ cidbhānoḥ samupasthitam |
yathā svapnamuhūrte'ntaḥ saṃvatsaraśatabhramaḥ
]

`v 51 [
yathā saṃkalpanirmāṇe jīvanaṃ maraṇaṃ punaḥ |
yathā gandharvanagare kuḍyamaṇḍanavedanam
]

`v 52 [
yathā nauyānasaṃrambhe vṛkṣaparvatavepanam |
yathā svadhātusaṃkṣobhe pūrvaparvatanartanam
]

`v 53 [
yathā samañjasaṃ svapne svaśiraḥpravikartanam |
mithaivaivamiyaṃ prauḍhā bhrāntirātatarūpiṇī
]

`v 54 [
vastutastu na jāto'si na mṛto'si kadācana |
śuddhavijñānarūpastvaṃ śānta ātmani tiṣṭhasi
]

`v 55 [
paśyasīvaitadakhilaṃ na ca paśyasi kiṃcana |
sarvātmakatayā nityaṃ prakacasyātmanātmani
]

`v 56 [
dṛśyamithyātve tatsaṃvalitacidābhāsalakṣaṇaṃ taddarśanamapi mithyaiveti
nirviṣayacinmātrapariśeṣa ityāśayenāha - paśyasīveti | prakacasi pradīpyase |
55 |
mahāmaṇirivodāra āloka iva bhāsvaraḥ |
vastutastu na bhūpīṭhamidaṃ na ca bhavānayam
]

`v 57 [
na ceme girayo grāmā na caite na ca vai vayam |
girigrāmakaviprasya maṇḍapākāśake kila
]

`v 58 [
tallīlābhartṛdārāḍhyaṃ jagadābhāti bhāsvaram |
tatra līlārājadhānī maṇḍapāmaṇḍitākṛtiḥ
]

`v 59 [
bhāti tasyodare vyomni tadevaṃ viditaṃ jagat |
tasmiñjagati gehe'ntaryasminvayamiha sthitāḥ
]

`v 60 [
evaṃ teṣāṃ maṇḍapānāṃ vyomāvyomaiva nirmalam |
tathaiva maṇḍapeṣvasti na mahī na ca pattanam
]

`v 61 [
p. 232)
na vanāni na śailaughā na meghasaridarṇavāḥ |
kevalaṃ tatra niḥśūnye viharanti gṛhe janāḥ
]

`v 62 [
na paśyanti janā nāpi pārthivā na ca bhūdharāḥ |
vidūratha uvāca |
evaṃ cettatkathaṃ devi mamehānucarā ime
]

`v 63 [
saṃpannā ātmanā santi te kimātmani no'thavā |
jagatsvapnārthavadbhāti tasya svapnanarādayaḥ
]

`v 64 [
kathamātmani satyāḥ syurna satyā veti me vada |
śrīsarasvatyuvāca |
rājanviditavedyeṣu śuddhabodhaikarūpiṣu
]

`v 65 [
na kiṃcidetatsadrūpaṃcidvyomātmasu jāgatam |
śuddhabodhātmano bhāti kṛto nāma jagadbhramaḥ
]

`v 66 [
rajjvāṃ sarpabhrame śānte punaḥ sarpabhramaḥ kutaḥ |
asadbhāve parijñāe kutaḥ sattā jagadbhrame
]

`v 67 [
parijñāte mṛgajale punarjalamatiḥ kutaḥ |
svapnakāle parijñāte sve svapnamaraṇaṃ kutaḥ |
svasvapne svapnamṛtibhīramṛtasyaiva jāyate
]

`v 68 [
buddhasya śuddhasya śarannabhaḥśrīḥ
svacchāvadātātitatāśayasya |
ahaṃ jagacceti kuśabdakārtho
na vastutaḥ so'ṅga hi vācikaṃ tat
]

`v 69 [
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]