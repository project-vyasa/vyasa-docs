`v 1 [
ṣaṭcatvāriṃśaḥ sargaḥ 46
śrīrāma uvāca |
evaṃ saṃkathayantīṣu tāsu tasmingṛhodare |
vidūrathaḥ kimakaronnirgatya kupito gṛhāt
]

`v 2 [
śrīvasiṣṭha uvāca |
vidūrathaḥ svasadanānnirgataḥ parivāritaḥ |
parivāreṇa mahatā ṛkṣaugheṇeva candramāḥ
]

`v 3 [
sannaddhasarvāvayavo lagnahāravibhūṣaṇaḥ |
mahājayajayārāvaiḥ surendra iva nirgataḥ
]

`v 4 [
samādiśanyodhagaṇaṃ śṛṇvanmaṇḍalasaṃsthitim |
ālokayanvīragaṇānāruroha nṛpo ratham
]

`v 5 [
kūṭākārasamākāraṃ muktāmāṇikyamaṇḍitam |
patākāpañcabhirvyāptaṃ dyuvimānamivottamam
]

`v 6 [
p. 242)
cakrabhittipariprotaprakacatkāñcanāṅkuram |
muktājālaraṇatkāracāruvikramakūbaram
]

`v 7 [
sugrīvairlakṣaṇopetaiḥ praśastaiḥ pracalaiḥ kṛśaiḥ |
javoḍḍayanavegena pravahadbhiḥ surāniva
]

`v 8 [
vāyuṃ javena sahasā asahadbhirgatikramaiḥ |
prohyadbhiriva paścārdhamāpibadbhirivāmbaram
]

`v 9 [
yojitairiva saṃpūrṇaiścandraiścāmaradīptibhiḥ |
aśvairaṣṭabhirābaddhamāśāpūrakaheṣitaiḥ
]

`v 10 [
athodapataduddāmanāgābhraravanirbharaḥ |
śailabhittipratidhvānadāruṇo dundubhidhvaniḥ
]

`v 11 [
mattasainikanirmuktairvyāptaṃ kalakalāravaiḥ |
kiṃkiṇījālanirdhvānairhetisaṃghaṭṭaghaṭṭitaiḥ
]

`v 12 [
hetīnāmāyudhānāṃ saṃghaṭṭena saṃghaṭṭanaśabdena ghaṭṭitairnibiḍitaiḥ | 11
|
dhanuścaṭacaṭāśabdaiḥ śarasītkāragāyanaiḥ |
parasparāṅganiṣpiṣṭakavacaughajhaṇjjhaṇaiḥ
]

`v 13 [
jvaladagniṭaṇatkārairārtimatkrandanāravaiḥ |
parasparabhaṭāhvānairbandivikṣubdharodanaiḥ
]

`v 14 [
śilāghanīkṛtāśeṣabrahmāṇḍakuharo dhvaniḥ |
hastagrāhyo'bhavadbhīmo daśāśākuñjapūrakaḥ
]

`v 15 [
athodapatadādityapathapīvararodhakam |
rajonibhena bhūpīṭhamambaroḍḍayanonmukham
]

`v 16 [
ādityapathasya pīvaraṃ sat rodhaṃ kāmayate iti rodhakam | kameḥ kvip | rajonibhena
veṣeṇa bhūpīṭhameva ambaroḍḍayanonmukhaṃ bhūtvā udatiṣṭhadityutprekṣā | 15
|
garbhavāsamivāpannaṃ tenāsīttanmahāpuram |
mūḍhatvaṃ yauvaneneva ghanatāmāyayau tamaḥ
]

`v 17 [
prayayuḥ kvāpi dīpaughā divaseneva tārakāḥ |
āyayurbalamālolā naiśabhūtapramparāḥ
]

`v 18 [
dadṛśustanmahāyuddhaṃ dve līle sā kumārikā |
prasphuṭaddhṛdayeneva devīdattamahādṛśau
]

`v 19 [
praśemuratha hetīṣu prodyatkaṭakaṭāravāḥ |
ekārṇavapayaḥpūrairvālavā iva vahnayaḥ
]

`v 20 [
śanaiḥ senāṃ samākarṣannājñāyata balāntaram |
viveśapakṣaproḍḍīno merurekamivārṇavam
]

`v 21 [
athodabhūdguṇadhvānaṃ caṭaccaṭaditi sphuṭam |
racitāṃśumayāmbhodāśceruḥ paraparamparāḥ
]

`v 22 [
yayurambaramāśritya nānāhetivihaṃgamāḥ |
prasabhruralamāttāsumalināḥ śastradīptayaḥ
]

`v 23 [
jajvaluḥ śastrasaṃghaṭṭajvalanā ulmukāgnivat |
jagarjuḥ śaradhāraughānvarṣanto vīravāridāḥ
]

`v 24 [
viviśuḥ krakacakrūrā vīrāṅgeṣu ca hetayaḥ |
petuḥ paṭapaṭārāvaṃ hetiniṣpiṣṭayo'mbare
]

`v 25 [
hetiniṣpiṣṭayaḥ khaḍgaprahārā eva paṭapaṭārāvātmanā ambare peturutpetuḥ | 24
|
jagmuḥ śamaṃ tamāṃsyāśu śastrakānaladīpakaiḥ |
babhūvurakhilā senā navanārācaromaśāḥ
]

`v 26 [
uttasthuryamayātrāyāṃ kabandhanaṭapaṅktayaḥ |
jaguruccai raṇodrekaṃ piśācyo raṇadārikāḥ
]

`v 27 [
udagurdantasaṃghaṭṭaṭaṃkārā dantināṃ balāt |
ūhuḥ kṣepaṇapāṣāṇamahānadyo nabhastale
]

`v 28 [
petuḥ śavā nivātāstasaṃśuṣkavanaparṇavat |
niryayurlohitā nadyo raṇādrermṛtivarṣiṇaḥ
]

`v 29 [
p. 243)
praśemuḥ pāṃsavo raktaistamāṃsyāyudhavahnibhiḥ |
yuddhaikadhyānataḥ śabdā bhayāni mṛtiniścayaiḥ
]

`v 30 [
abhavatkevalaṃ yuddhamapaśabdamasaṃbhramam |
anākulāmbuvāhābhaṃ khaḍgavīcisaṭākṛtam
]

`v 31 [
khadakhadaravasaṃvahaccharaughaṃ
ṭakaṭakakitāravasaṃpatadbhuśuṇḍi |
jhaṇajhaṇaravasaṃmilanmahāstraṃ
timitimivadraṇamāsa dustaraṃ tat
]