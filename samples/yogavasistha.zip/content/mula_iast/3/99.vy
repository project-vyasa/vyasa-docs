`v 1 [
ekonaśatatamaḥ sargaḥ 99
śrīrāma uvāca |
kāsau mahāṭavī brahmankadā dṛṣṭā kathaṃ mayā |
ke ca te puruṣāstatra kiṃ tatkartuṃ kṛtodyamāḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
raghunātha mahābāho śṛṇu vakṣyāmi te'khilam |
na sā mahāṭavī rāma dūre naiva ca te narāḥ
]

`v 3 [
yeyaṃ saṃsārapadavī gambhīrā'pārakoṭarā |
tāṃ tāṃ śūnyāṃ vikārāḍhyāṃ viddhi rāma mahāṭavīm
]

`v 4 [
vicārālokalabhyeyaṃ yadaikenaiva vastunā |
pūrṇā nānyena saṃyuktā kevaleva tadaiva sā
]

`v 5 [
tatra ye te mahākārāḥ puruṣāḥ prabhramanti hi |
manāṃsi tāni viddhi tvaṃ duḥkhe nipatitānyalam
]

`v 6 [
draṣṭā yo'yamahaṃ teṣāṃ saviveko mahāmate |
vivekena mayā tāni dṛṣṭānyanyeva nānagha
]

`v 7 [
mayā tānyeva bodhyante vivekena manāṃsi hi |
satataṃ suprakāśena kamalānīva bhānunā
]

`v 8 [
matprabodhaṃ samāsādya matprasādānmahāmate |
manāṃsi kāni cittāni gatānyupaśamātparam
]

`v 9 [
p. 364) 217
kānicinnābhinandanti māṃ vivekaṃ vomohataḥ |
mattiraskāravaśataḥ kūpeṣveva patantyadhaḥ
]

`v 10 [
ye te'ndhakūpā gahanā narakāste raghūdvaha |
kadalīkānanaṃ yāni saṃpraviṣṭāni tāni tu
]

`v 11 [
svargaikarasikāni tvaṃ manāṃsi jñātumarhasi |
praviṣṭānyandhakūpāntarnirgatāni na yāni tu
]

`v 12 [
mahāpātakayuktāni tāni cittāni rāghava |
kadalīkānanasthāni nirgatāni na yāni tu
]

`v 13 [
puṇyasaṃbhārayuktāni tāni cittāni rāghava |
karañjavanayātāni nirgatāni na yāni tu
]

`v 14 [
tāni mānuṣyajātāni cittāni raghunandana |
kānicitsaṃprabuddhāni tatra muktāni bandhanāt
]

`v 15 [
kānicidbahurūpāṇi yoneryoniṃ viśanti hi |
manāṃsi tāni tiṣṭhanti nipatantyutpatanti ca
]

`v 16 [
yattatkarañjagahanaṃ tatkalatrarasaṃ viduḥ |
duḥkhakaṇṭakasaṃbādhaṃ mānuṣyaṃ vividhaiṣaṇam
]

`v 17 [
karañjagahanaṃ yāni praviṣṭāni manāṃsi tu |
mānuṣye tāni jātāni tatraiva rasikāni ca
]

`v 18 [
kadalīkānanaṃ yattacchaśāṅkakaraśītalam |
tanmanohlādanakaraṃ svargaṃ viddhi raghudvaha
]

`v 19 [
kānicitpuṇyabhūtena tapasā dhāraṇātmanā |
dhārayanti śarīrāṇi saṃsthitānyuditānyapi
]

`v 20 [
yairahaṃ puṃbhirabudhairbuddhicittatiraskṛtaḥ |
tairmanobhiranātmajñaiḥ svavivekastiraskṛtaḥ
]

`v 21 [
buddhibhiścittairvā tiraskṛta upekṣitaḥ | nādhyavasito na smṛtaścetyarthaḥ | 20
|
tvayā dṛṣṭo vinaṣṭo'smi tvaṃ me śatruriti drutam |
yaduktaṃ taddhi cittena galatā paridevitam
]

`v 22 [
ruditaṃ yanmahākrandaṃ puṃsā bahvāśu rāghava |
tadbhogajālaṃ tyajatā manasā rodanaṃ kṛtam
]

`v 23 [
ardhaprāptavivekasya na prāptasyāmalaṃ padam |
cetasastyajato bhogānparitāpo bhṛśaṃ bhavet
]

`v 24 [
rudatāṅgāni dṛṣṭāni kāruṇyenāvabodhinā |
kaṣṭametāni saṃtyajya kiṃ prayāmīti cetasā
]

`v 25 [
ardhaprāptavivekasya na prāptasyāmalaṃ padam |
cetasastyajato'ṅgāni paritāpo hi vardhate
]

`v 26 [
hasitaṃ tu yadānandi puṃsā madavabodhataḥ |
pariprāptavivekena tattuṣṭaṃ rāma cetasā
]

`v 27 [
pariprāptavivekasya tyaktasaṃsārasaṃsthiteḥ |
cetasastyajato rūpamānando hi vivardhate
]

`v 28 [
hasatāṅgāni dṛṣṭāni puṃsā yānyupahāsataḥ |
tāni dṛṣṭāni manasā vipralambhapadāni ha
]

`v 29 [
mithyāvikalparacitairvipralabdhamaho ciram |
ityaṅgānyupahāsena dṛṣṭāni svāni cetasā
]

`v 30 [
manaḥ prāptavivekaṃ hi viśrāntaṃ vitate pade |
prāktanādīnatādhāraṃ hasanpaśyati dūrataḥ
]

`v 31 [
yadasau samavaṣṭabhya mayā pṛṣṭaḥ prayatnataḥ |
tadviveko balāccittamādatta iti darśitam
]

`v 32 [
yadaṅgāni viśīrṇāni gatānyantardhimagrataḥ |
taccittena vinārthāśā śāmyatīti pradarśitam
]

`v 33 [
sahasranetrahastatvaṃ yatpuṃsaḥ parivarṇitam |
tadanantākṛtitvaṃ hi cetasaḥ paridarśitam
]

`v 34 [
yadātmani prahāraughaiḥ pumānpraharati svayam |
tattatkukalpanāghātaiḥ praharatyātmano manaḥ
]

`v 35 [
palāyate yatpuruṣaḥ svātmanaḥ praharansvayam |
svavāsanāprahārebhyastanmanaḥ prapalāyate
]

`v 36 [
svayaṃ praharati svāntaṃ svayameva svayecchayā |
palāyate svayaṃ caiva paśyājñānavijṛmbhitam
]

`v 37 [
svavāsanopataptāni sarvāṇyeva manāṃsi hi |
svayameva palāyante gantuṃ yuktāni tatpadam
]

`v 38 [
p. 365) 217
yadidaṃ duḥkhaṃ tattanoti svayaṃ manaḥ |
svayamevātikhinnaṃtu punastasmātpalāyate
]

`v 39 [
saṃkalpavāsanājālaiḥ svayamāyāti bandhanam |
mano lālāmayairjālaiḥ kośakārakṛmiryathā
]

`v 40 [
yathānarthamavāpnoti tathā krīḍati cañcalam |
bhāviduḥkhamapaśyansvaṃ durlīlābhirivārbhakaḥ
]

`v 41 [
apaśyankāṣṭharandhrasthavṛṣaṇākramaṇaṃ yathā |
kīlotpāṭī kapirduḥkhametīdaṃ hi tathā manaḥ
]

`v 42 [
cirapālanayā caiva cirabhāvanayā tathā |
abhyāsāttucchatāmetya na bhūyaḥ pariśocati
]

`v 43 [
manaḥpramādādvardhante duḥkhāni girikūṭavat |
tadvaśādeva naśyanti sūryasyāgre himaṃ yathā
]

`v 44 [
tathāca mana eva pramādavivekābhyāṃ bandhamokṣayorheturiti phalitamityāha ##-
yāvajjīvamanindyayā ca ramate śāstrārthasaṃjātayā
tulyaṃ vāsanayā mano hi munivanmaunena rāgādiṣu |
paścātpāvanapāvanaṃ padamajaṃ tatprāpya tacchītalaṃ
tatsaṃsthena na śocyate punaralaṃ puṃsā mahāpatsvapi
]