`v 1 [
ṣoḍaśaḥ sargaḥ 16
śrīvasiṣṭha uvāca |
bhūtalāpsarasā sārdhamananyadayitāpatiḥ |
akṛtrimapremarasaṃ sa reme kāntayā tayā
]

`v 2 [
udyānavanagulmeṣu tamālagahaneṣu ca |
puṣpamaṇḍaparamyeṣu latāvalayasadmasu
]

`v 3 [
puṣpāntaḥpuraśayyāsu puṣpasaṃbhāravīthiṣu |
vasantodyānadolāsu krīḍāpuṣkariṇīṣu ca
]

`v 4 [
candanadrumaśaileṣu saṃtānakataleṣu ca |
kadambanīpageheṣu pāribhadrodareṣu ca
]

`v 5 [
vikasatkundamandāramakarandasugandhiṣu |
vasantavanajāleṣu kūjatkokilapakṣiṣu
]

`v 6 [
nānāraṇyatṛṇānāṃ ca sthaleṣu mṛdudīptiṣu |
nirjhareṣu tarattārasīkarāsāravarṣiṣu
]

`v 7 [
śailānāṃ maṇimāṇikyaśilānāṃ phalakeṣu ca |
devarṣimunigeheṣu dūrapuṇyāśrameṣu ca
]

`v 8 [
p. 169)
kumudvatīṣu phullāsu smerāsu nalinīṣu ca |
vanasthalīṣu kṛṣṇāsu phullāsu phalinīṣu ca
]

`v 9 [
surataiḥ suratāruṇyaiḥ sundaraḥ sundarehitaiḥ |
īhitaiḥ peśalānyonyaghanapremarasādhikaiḥ
]

`v 10 [
prahelikābhirākhyānaistathā cākṣaramuṣṭibhiḥ |
aṣṭāpadairbahudyūtaistathā gūḍhacaturthakaiḥ
]

`v 11 [
nāṭikākhyāyikābhiśca ślokairvindumatikramaiḥ |
deśakālavibhāgaiśca nagaragrāmaceṣṭitaiḥ
]

`v 12 [
sragdāmamālāvalitairnānābharaṇayojanaiḥ |
līlāvilolacalanairvicitrarasabhojanaiḥ
]

`v 13 [
ārdrakuṅkumakarpūratāmbūlīdalacarvaṇaiḥ |
phullapuṣpalatāguñjādehagopanakhavraṇaiḥ
]

`v 14 [
samālambhanalīlābhirmālāpraharaṇakramaiḥ |
gṛhe kusumadolābhiranyonyaṃ dolanakramaiḥ
]

`v 15 [
nauyānayugmahastyaśvadāntoṣṭrādigamāgamaiḥ |
jalakelivilāsena parasparasamukṣaṇaiḥ
]

`v 16 [
nṛtyagītakalālāsyatālatāṇḍavamaṇḍanaiḥ |
saṃgītakaiḥ saṃkathanirvīṇāmurajavādanaiḥ
]

`v 17 [
udyāneṣu sarittīravṛkṣeṣu varavīthiṣu |
antaḥpureṣu harmyeṣu phulladolāvadolanaiḥ
]

`v 18 [
sā tathā sukhasaṃvṛddhā tasya praṇayinī priyā |
ekadā cintayāmāsa subhrūḥ saṃkalpaśālinī
]

`v 19 [
prāṇebhyo'pi priyo bhartā mamaiṣa jagatīpatiḥ |
yauvanollāsavānśrīmānkathaṃ syādajarāmaraḥ
]

`v 20 [
bhartrānena sahottuṅgastanī kusumasadmasu |
kathaṃ svairaṃ ciraṃ kāntā rame yugaśatānyaham
]

`v 21 [
tathā yate yatnamatastapojapayamehitaiḥ |
rajanīśamukho rājā yathā syādajarāmaraḥ
]

`v 22 [
jñānavṛddhāṃstapovṛddhānvidyāvṛddhānahaṃ dvijān |
pṛcchāmi tāvanmaraṇaṃ kathaṃ na syānnṛṇāmiti
]

`v 23 [
ityānīyātha saṃpūjya dvijānpapraccha sā natā |
amaratvaṃ kathaṃ viprā bhavediti punaḥpunaḥ
]

`v 24 [
viprā ūcuḥ |
tapojapayamairdevi samastāḥ siddhasiddhayaḥ |
saṃprāpyante'maratvaṃ tu na kadācana labhyate
]

`v 25 [
ityākarṇya dvijamukhāccintayāmāsa sā punaḥ |
idaṃ svaprajñayaivāśu bhītā priyaviyogataḥ
]

`v 26 [
maraṇaṃ bharturagre me yadi daivādbhaviṣyati |
tatsarvaduḥkhanirmuktā saṃsthāsye sukhamātmani
]

`v 27 [
atha varṣasahasreṇa bhartādau cenmariṣyati |
tatkariṣye tathā yena jīvo gehānna yāsyati
]

`v 28 [
tadbhramadbhartṛjīve'sminnije śuddhāntamaṇḍape |
bhartrā vilokitā nityaṃ nivatsyāmi yathāsukham
]

`v 29 [
adyaivārabhyaitadarthaṃ devīṃ jñaptiṃ sarasvatīm |
japopavāsaniyamairātoṣaṃ pūjayāmyaham
]

`v 30 [
iti niścitya sā nāthamanuktvaiva varāṅganā |
yathāśāstraṃ cacārograṃ tathā niyamamāsthitā
]

`v 31 [
trirātrasya trirātrasya paryante kṛtapāraṇā |
devadvijaguruprājñavidvatpūjāparāyaṇā
]

`v 32 [
snānadānatapodhyānanityodyuktaśarīrikā |
sarvāstikyasadācārakāriṇī kleśahāriṇī
]

`v 33 [
yathākālaṃ yathodyogaṃ yathāśāstraṃ yathākramam |
toṣayāmāsa bhartāramaparijñātasaṃsthitiḥ
]

`v 34 [
trirātraśatamevaṃ sā bālā niyamaśālinī |
anārataṃ taponiṣṭhāmatiṣṭhatkaṣṭaceṣṭayā
]

`v 35 [
p. 170)
trirātrāṇāṃ śate cātha pūjitā pratimānitā |
tuṣṭā bhagavatī gaurī vāgīśā samuvāca tām
]

`v 36 [
śrīsarasvatyuvāca |
nirantareṇa tapasā bhartṛbhaktyatiśālinā |
parituṣṭāsmi te vatse gṛhāṇa varamīpsitam
]

`v 37 [
śrīrājñyuvāca |
jaya janmajarājvālādāhadoṣaśaśiprabhe |
jaya hārdāndhakāraughanivāraṇaraviprabhe
]

`v 38 [
amba mātarjaganmātastrāyasva kṛpaṇāmimām |
idaṃ varadvayaṃ dehi yadahaṃ prārthaye śubhe
]

`v 39 [
ekaṃ tāvadvidehasya bharturjīvo mamāmbike |
asmādeva hi mā yāsīnnijāntaḥpuramaṇḍapāt
]

`v 40 [
dvitīyaṃ tvāṃ mahādevi prārthaye'haṃ yadā yadā |
darśanāya varārthāya tadā me dehi darśanam
]

`v 41 [
ityākarṇya jaganmātā tavāstvevamiti svayam |
uktvāntardhānamagamatprotthāyormirivārṇave
]

`v 42 [
atha sā rājamahiṣī parituṣṭeṣṭadevatā |
śrutagīteva hariṇī babhūvānandadhāriṇī
]

`v 43 [
pakṣamāsartukaṭake dināre varṣadaṇḍake |
kṣaṇanābhau spandamaye kālacakre vahatyatha
]

`v 44 [
antardhimājagāmāsyāḥ patyustaccetanaṃ tanau |
saṃdṛśyamānamevāśu śuṣkapatraraso yathā
]

`v 45 [
raṇakhaṇḍitadehe'sminmṛte'ntaḥpuramaṇḍape |
nirjalā nalinīvāsau parāṃ mlānimupāyayau
]

`v 46 [
viṣoṣṇaśvasanadhvastasakalādharapallavā |
prāpa sā maraṇāvasthāṃ saśalyeva mṛgī yathā
]

`v 47 [
prāpa sā tamasāndhatvaṃ tasminmaraṇamāgate |
dīpajvālālave kṣīṇe sadmaśrīriva bhūṣitā
]

`v 48 [
kārśyamāpa kṣaṇenāsau bālā virasatāṃ gatā |
yathā srotasvinī srotaḥkṣaye kṣāravidhūsarā
]

`v 49 [
kṣipramākrandinī kṣipraṃ maunamūkā viyoginī |
babhūva cakravākrīva māninī maraṇonmukhī
]

`v 50 [
atha tāmatimātravihvalāṃ
sakṛpākāśabhavā sarasvatī |
śapharīṃ hṛdaśoṣavihvalāṃ
prathamā vṛṣṭirivānvakampataḥ
]