`v 1 [
ekonatriṃśaḥ sargaḥ 29
śrīvasiṣṭha uvāca |
tatra te tetaturdevyau grāme'ntaḥśītalātmani |
bhogamokṣaśriyau śānte puṃsīva viditātmani
]

`v 2 [
kālenaitāvatā līlā tenābhyāsena sābhavat |
śuddhajñānaikadehatvāttrikālāmaladarśinī
]

`v 3 [
atha sasmāra sarvāstāḥ prāktanīḥ saṃsṛtergatīḥ |
sā svayaṃ svarasenaiva prāgjanmamaraṇādikāḥ
]

`v 4 [
līlovāca |
devi deśamimaṃ dṛṣṭvā tvatprasādātsmarāmyaham |
iha tatprāktanaṃ sarvaṃ ceṣṭitaṃ ceṣṭitāntaram
]

`v 5 [
ihābhūvamahaṃ jīrṇā śirālāṅgī kṛśā sitā |
brāhmaṇī śuṣkadarbhāgrabhedarūkṣakarodarā
]

`v 6 [
bhartuḥ kulakarī bhāryā dohamanthānaśālinī |
mātā sakalaputrāṇāmatithīnāṃ priyaṃkarī
]

`v 7 [
devadvijasatāṃ bhaktā siktāṅgī ghṛtagorasaiḥ |
bharjanī carukumbhādibhāṇḍopaskaraśodhinī
]

`v 8 [
p. 201)
nityamannalavāktaikakācakambuprakoṣṭhakā |
jāmātṛduhitṛbhrātṛpitṛmātṛprapūjanī
]

`v 9 [
ādehaṃ sadmabhṛtyaiva prakṣīṇadinayāinī |
vācaṃ ciraṃ ciramiti vādinyaniśamākulā
]

`v 10 [
kāhaṃ ka iva saṃsāra iti svapne'pyasaṃkathā |
jāyā śrotriyamūḍhasya tādṛśasyaiva durdhiyaḥ
]

`v 11 [
ekaniṣṭhā samicchākagomayendhanasaṃcaye |
mlānakambalasaṃvītaśirālakṛśagātrikā
]

`v 12 [
tarṇakīkarṇajāhasthakṛtminiṣkāsatatparā |
gṛhaśākāyanāsekasatvarāhūtakarparā
]

`v 13 [
tarṇakī vatsā tasyāḥ karṇajāhe karṇamūle sthitānāṃ kṛmīṇāṃ niṣkāsanaṃ
niṣkāsastatra tatparā | tasya pākamūle pīlvādikarṇādibhyaḥ kuṇabjāhacau iti jāhac
| gṛhe kṛtaṃ śākāyanaṃ śākakedārastasyāsekāyāhūtāni
sekasādhanakarparāṇi yayā | karparapadena tatpāṇayo bhṛtyā lakṣaṇayocyante |
12 |
nīlanīrataraṅgāntatṛṇatarpitatarṇikā |
pratikṣaṇaṃ gṛhadvārakṛtalepanavarṇakā
]

`v 14 [
nītyarthaṃ gṛhabhṛtyānāmādīnakṛtavācyatā |
maryādāniyamādabdhervelevāniśamacyutā
]

`v 15 [
jīrṇaparṇasavarṇaikakarṇadolādhirūḍhayā |
kāṣṭhatāḍyajarābhītajīvavṛttyeva cihnitā
]

`v 16 [
śrīvasiṣṭha uvāca |
ityuktvā saṃcarantī sā śikharigrāmakoṭare |
saṃcarantyāḥ sarasvatyā darśayāmāsa sasmayam
]

`v 17 [
iyaṃ me pāṭalākhaṇḍamaṇḍitā puṣpavāṭikā |
iyaṃ me puṣpitodyānamaṇḍapāśokavāṭikā `note[śokapeṭikā iti
pāṭhaḥ]
]

`v 18 [
iyaṃ puṣkariṇītīradrumā'granthitatarṇakā |
iyaṃ sā karṇikānāmnī tarṇikā muktaparṇikā
]

`v 19 [
iyaṃ sā me'lasākīrṇā varākī jalahārikā |
adyāṣṭamaṃ dinaṃ vāṣpaklinnākṣī pariroditi
]

`v 20 [
iha devi mayā bhuktamihopitamiha sthitam |
iha suptamihāpītamiha dattamihāhṛtam
]

`v 21 [
eṣa me jyeṣṭhaśarmākhyaḥ putro roditi mandire |
eṣā me jaṅgale dhenurdogdhrī carati śādbalam
]

`v 22 [
gṛhe vasantadāhāya rūkṣakṣāravidhūsaram |
svadehamiva pañcākṣaṃ paśyemaṃ praghaṇaṃ mama
]

`v 23 [
tumbīlatābhirugrābhiḥ puṣṭābhiriva veṣṭitam |
mahānasasthānamidaṃ mama dehamivāparam
]

`v 24 [
ete rodanatāmrāks.ā bandhavo bhuva bandhanam |
aṅgadārpitarudrākṣā āharantyanalendhanam
]

`v 25 [
anārataṃ śilākacche gucchācchoṭanakāribhiḥ |
taraṅgaiḥ sthagitākāraṃ spṛṣṭatīralatādalaiḥ
]

`v 26 [
sīkarākīrṇaparyantaśādbalasthalasallataiḥ |
śilāphalahakāsphālaphenilotpalasīkaraiḥ
]

`v 27 [
p. 202)
tuṣārīkṛtamadhyāhnadivākarakarotkaraiḥ |
phullapuṣpotkarāsārapranādotkataṭadrumaiḥ
]

`v 28 [
vidrumairiva saṃkrāntaphullakiṃśukakāntibhiḥ |
vyāptayā puṣparāśīnāṃ samullāsanakāribhiḥ
]

`v 29 [
uhyamānaphalāpūrasuvyagragrāmabālayā |
mahākalakalāvartamattayā grāmakulyayā
]

`v 30 [
veṣṭitastaralāsphālajaladhautatalopalaḥ |
ghanapatratarucchannacchāyāsatataśītalaḥ
]

`v 31 [
ayamālakṣyate phūllalatāvalanasundaraḥ |
daladgulucchakācchannagavākṣo gṛhamaṇḍapaḥ
]

`v 32 [
atra me saṃsthito bhartā jīvākāśatayā'kṛtiḥ |
catuḥsamudraparyantamekhalāyā bhuvaḥ patiḥ
]

`v 33 [
ā smṛtaṃ pūrvametena kilāsīdabhivāñchitam |
śīghraṃ syāmeva rājeti tīvrasaṃvegadharmiṇā
]

`v 34 [
dinairaṣṭabhirevāsau tena rājyaṃ samṛddhimat |
cirakālapratyayadaṃ prāptavānparameśvari
]

`v 35 [
atrāsau bhartṛjīvo me sthito vyomni gṛhe nṛpaḥ |
adṛśyaḥ khe yathā vāyurāmodo vānile yathā
]

`v 36 [
ihaivāṅguṣṭhamātrānte tadvyomnyeva padaṃ sthitam |
madbhartṛrājyaṃ samavagataṃ yojanakoṭibhāk
]

`v 37 [
sthitaṃ padaṃ paramārthavastuyojanakoṭibhāk samadhigataṃ bhrāntyetyarthaḥ | 36
|
āvāṃ khameva khasthaṃ ca bhartṛrājyaṃ mameśvari |
pūrṇaṃ sahasraiḥ śailānāṃ mahāmāyeyamātatā
]

`v 38 [
taddevi bhartṛnagaraṃ punargantuṃ mamepsitam |
tadehi tatra gacchāvaḥ kiṃ dūraṃ vyavasāyinām
]

`v 39 [
śrīvasiṣṭha uvāca |
ityuktvā praṇatā devīṃ sā praviśyāśu maṇḍapam |
vihaṃgīva tayā sākaṃ pupluve sinibhaṃ `note[sitibhaṃ iti pāṭhaḥ] namaḥ
]

`v 40 [
bhinnāñjanacayaprakhyaṃ saumyaikārṇavasundaram |
nārāyaṇāṅgasadṛśaṃ bhṛṅgapṛṣṭāmalacchavi
]

`v 41 [
meghamārgamatikramya vātaskandhāvaniṃ tathā |
sauramārgamathākramya candramārgamatītya ca
]

`v 42 [
dhruvamārgottaraṃ gatvā sādhyānāṃ mārgametya ca |
siddhānāṃ samatītyorvīmullaṅghya svargamaṇḍalam
]

`v 43 [
brahmalokottaraṃ gatvā tuṣitānāṃ ca maṇḍalam |
golokaṃ śivalokaṃ ca pitṛlokamatītya ca
]

`v 44 [
tuṣitānāṃ nityasaṃtuṣṭānāṃ maṇḍalaṃ vaikuṇṭham | jagataḥ pitarau śivau
lokyete yatreti pitṛbhyāṃ vālokyata iti pitṛloko'tra śivaloka eva |
kavyavāḍādipitṛdevādhiṣṭhitalokasya dūramadha evāvasthānādatrāprasakteḥ |
43 |
videhānāṃ sadehānāṃ lokānuttīrya `note[lokamuttirya iti pāṭhaḥ]
dūragam |
dūrāddūramatho gatvā kiṃcidbuddhā babhūva sā
]

`v 45 [
paścādālokayāmāsa samatītaṃ nabhasthalam |
yāvanna kiṃciccandrārkatārādyālakṣyate hyadhaḥ
]

`v 46 [
tamastimitagambhīramāśākuharapūrakam |
ekārṇavodaraprakhyaṃ śilodaraghanaṃ sthitam
]

`v 47 [
līlovāca |
taddevi bhāskarādīnāṃ kvādhastejo gataṃ vada |
śilājaṭharaniṣpandaṃ muṣṭigrāhyaṃ tamaḥ kutaḥ
]

`v 48 [
śrīdevyuvāca |
etāvatīmimāṃ vyomnaḥ padavīmāgatāsi bhoḥ |
arkādīnyapi tejāṃsi yato dṛśyanta eva no
]

`v 49 [
yathā mahāndhakūpādhaḥ khadyoto nāvalokyate |
pṛṣṭhagena tathehāto nādhaḥ sūryo'valokyate
]

`v 50 [
līlovāca |
aho nu padavīṃ dūramāvāmetāmupāgate |
sūryo'pyadhoṇukaṇavanna manāgapi lakṣyate
]

`v 51 [
p. 203)
ita uttaramanyā syātpadavī kā nu kīdṛśī |
kathaṃ ca mātaretavyā kathyatāmiti devi me
]

`v 52 [
śrīdevyuvāca |
ita uttaramagre te brahmāṇḍapuṭakarparam |
yasya candrādayo nāma dhūlileśāḥ samutthitāḥ
]

`v 53 [
śrīvasiṣṭha uvāca |
iti prakathayantyau te prāpte brahmāṇḍakarparam |
bhramaryāviva śailasya kuḍyaṃ nibiḍamaṇḍapam
]

`v 54 [
akleśenaiva te tasmānnirgate gaganādiva |
niścayasthaṃ hi yadvastu tadvajraguru netarat
]

`v 55 [
nirāvaraṇavijñānā sā dadarśa tatastatam |
jalādyāvaraṇaṃ pāre brahmāṇḍasyātibhāsuram
]

`v 56 [
brahmāṇḍāddaśaguṇatastoyaṃ tatra vyavasthitam |
āsthitaṃ veṣṭayitvā tu tvagivākṣoṭapṛṣṭhagā
]

`v 57 [
tasmāddaśaguṇo vahnistamāddaśaguṇo'nilaḥ |
tato daśaguṇaṃ vyoma tataḥ paramamambaram
]

`v 58 [
tasminparamake vyomni madhyādyantavikalpanāḥ |
na kāścana samudyanti vandhyāputrakathā iva
]

`v 59 [
kevalaṃ vitataṃ śāntaṃ tadanādi gatabhramam |
ādyantamadhyarahitaṃ mahatyātmani tiṣṭhati
]

`v 60 [
ākalpamuttamabalena śilā patecce-
ttasminbalātpatagarāḍapi cotpateccet |
tadyojanaṃ na labhate vimale'mbare'nta-
rmākalpamekajavago'pyatha māruto'pi
]