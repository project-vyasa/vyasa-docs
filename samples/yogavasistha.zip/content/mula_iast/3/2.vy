`v 1 [
dvitīyaḥ sargaḥ 2
śrīvasiṣṭha uvāca |
idamākāśajākhyānaṃ śṛṇu śravaṇabhūṣaṇam |
utpattyākhyaṃ prakaraṇaṃ yena rāghava budhyase `note[budhyate iti
pāṭhaḥ]
]

`v 2 [
asti hyākāśajo nāma dvijaḥ paramadhārmikaḥ |
dhyānaikaniṣṭhaḥ satataṃ prajānāṃ ca hite rataḥ
]

`v 3 [
p. 131)
sa ciraṃ jīvati yadā tadā mṛtyuracintayat |
sarvāṇyeva krameṇāhaṃ bhūtānyadmi kilākṣayaḥ
]

`v 4 [
enamākāśajaṃ vipraṃ na kasmādbhakṣayāmyaham |
atra me kuṇṭhitā śaktiḥ khaḍgadhārā ivopale
]

`v 5 [
iti saṃcintya taṃ hantumagacchattatpuraṃ tadā |
tyajantyudyamamudyuktā na svakarmāṇi kecana
]

`v 6 [
tatastatsadanaṃ yāvanmṛtyuḥ praviśati svayam |
tāvadenaṃ dahatyagniḥ kalpāntajvalanopamaḥ
]

`v 7 [
agnijvālāmahāmālāṃ vidāryāntargato hyasau |
dvijaṃ dṛṣṭvā samadātuṃ hastenaicchatprayatnataḥ
]

`v 8 [
nacāśakatpuro dṛṣṭamapi hastaśatairdvijam |
balavānapyavaṣṭabdhuṃ saṃkalpapuruṣaṃ yathā
]

`v 9 [
athāgatya yamaṃ mṛtyurapṛcchatsaṃśayacchidam |
kimityahaṃ na śaknomi bhoktumākāśajaṃ vibho
]

`v 10 [
yama uvāca |
mṛtyuo na kiṃcicchaktastvameko mārayituṃ balāt |
māraṇīyasya karmāṇi tatkartṝṇīti netarat
]

`v 11 [
tasmādetasya viprasya māraṇīyasya yatnataḥ |
karmāṇyanviṣya teṣāṃ tvaṃ sāhāyyenainamatsyasi
]

`v 12 [
tataḥ sa mṛtyurbabhrāma tatkarmānveṣaṇādṛtaḥ |
maṇḍalāni digantāṃśca sarāṃsi sarito diśaḥ
]

`v 13 [
vanajaṅgalajālāni śailānabdhitaṭāni ca |
dvīpāntarāṇyaraṇyāni nagarāṇi purāṇi ca
]

`v 14 [
grāmāṇyakhilarāṣṭrāṇi deśāntargahanāni ca |
evaṃ bhūmaṇḍalaṃ bhrāntvā na kutaścitsa kānicit
]

`v 15 [
tānyākāśajakarmāṇi labdhavānmṛtyurudyataḥ |
vandhyāputramiva prājñaḥ saṃkalpādrimivāparaḥ
]

`v 16 [
samapṛcchadathāgatya yamaṃ sarvārthakovidam |
parāyaṇaṃ hi prabhavaḥ saṃdeheṣvanujīvinām
]

`v 17 [
mṛtyuruvāca |
ākāśajasya karmāṇi kva sthitāni vada prabho |
dharmarājo'tha saṃcintya suciraṃ proktavānidam
]

`v 18 [
dharmarāja uvāca |
ākāśajasya karmāṇi mṛtyo santi na kānicit |
eṣa ākāśajo vipro jātaḥ khādeva kevalāt
]

`v 19 [
ākāśādeva yo jātaḥ sa vyomaivāmalaṃ bhavet |
sahakārīṇi no santi na karmāṇyasya kānicit
]

`v 20 [
saṃbandhaḥ prāktanenāsya na manāgapi karmaṇā |
asti vandhyāsutasyeva tathā'jātākṛteriva
]

`v 21 [
kāraṇānāmabhāvena tasmādākāśameva saḥ |
naitasya pūrvakarmāsti nabhasīva mahādrumaḥ
]

`v 22 [
kāraṇānāmavidyādīnāṃ nirvikārasya vikārahetūnāṃ vā | tasmādvikārāyogāt |
21 |
naitadasyāvaśaṃ cittamabhāvātpūrvakarmaṇām |
adya tāvadanenādyaṃ `note[anenānyatra kiṃcit iti pāṭhaḥ] na
kiṃcitkarma saṃcitam
]

`v 23 [
evamākāśakośātmā viśadākāśarūpiṇi |
svakāraṇe sthito nityaḥ `note[nityaṃ karmāṇyasya na kānicit iti pāṭhaḥ]
kāraṇāni na kānicit
]

`v 24 [
prāktanāni na santyasya karmāṇyadya karoti no |
kiṃcidapyevameṣo'tra vijñānākāśamātrakaḥ
]

`v 25 [
prāṇaspando'sya yatkarma lakṣyate cāsmadādibhiḥ |
dṛśyate'smābhirevaṃ `note[revaitat iti pāṭhaḥ] tanna tvasyāstyatra
karmadhīḥ
]

`v 26 [
saṃsthitā bhāvayantīva cidrūpaiva parātpadāt |
bhinnamākāramātmīyaṃ citstambhe śālabhañjikā
]

`v 27 [
p. 132)
tathaiva paramārthātsakhātmabhūtaḥ `note[paramārthantaḥ svātmabhūta iti
pāṭhaḥ] sthito dvijaḥ |
yathā dravatvaṃ payasi śūnyatvaṃ ca yathāmbare
]

`v 28 [
spandatvaṃ ca yathā vāyostathaiṣa parame pade |
karmāṇyadyatanānyasya saṃcitāni na santi hi
]

`v 29 [
na pūrvāṇyeṣa teneha na saṃsāravaśaṃ gataḥ |
sahakārikāraṇānāmabhāve yaḥ prajāyate
]

`v 30 [
nāsau svakāraṇādbhinno bhavatītyanubhūyate |
kāraṇānāmabhāvena tasmādeṣa svayaṃbhavaḥ
]

`v 31 [
kartā na pūrvaṃ nāpyadya kathamākramyate vada |
yadaiṣa kalpanāṃ buddhyā mṛtināmnīṃ kariṣyati
]

`v 32 [
pṛthvyādimānayamahamiti yasya ca niścayaḥ |
sa pārthivo bhavatyāśu grahītuṃ sa ca śakyate
]

`v 33 [
pṛthvyādikalanābhāvādeṣa vipro na rūpavān |
dṛḍharajjveva gaganaṃ grahītuṃ naiva yujyate
]

`v 34 [
mṛtyuruvāca |
bhagavañjāyate śūnyātkathaṃ nāma vadeti me |
pṛthvyādayaḥ kathaṃ santi na santi vada vā katham
]

`v 35 [
yama uvāca |
na kadācana jāto'sau na ca nāsti kadācana |
dvijaḥ kevalavijñānabhāmātraṃ tattathā sthitaḥ
]

`v 36 [
mahāpralayasaṃpattau na kiṃcidavaśiṣyate |
brahmāste śāntamajaramanantātmaiva kevalam
]

`v 37 [
śūnyaṃ nityoditaṃ sūkṣmaṃ nirupādhi paraṃ sthitam |
tadā tadanu yenāsya nikaṭe'drinibhaṃ mahaḥ
]

`v 38 [
saṃvinmātrasvabhāvatvāddeho'hamiti cetati |
kākatālīyavadbhrāntamākāraṃ tena paśyati
]

`v 39 [
sa eṣa brāhmaṇastasminsargādāvambarodare |
nirvikalpaścidākāśarūpamāsthāya saṃsthitaḥ
]

`v 40 [
nāsya deho na karmāṇi na kartṛtvaṃ na vāsanā |
eṣa śuddhacidākāśo vijñānaghana ātataḥ
]

`v 41 [
prāktanaṃvāsanājālaṃ kiṃcidasya na vidyate |
kevalaṃ vyomarūpasya bhārūpasyeva tejasaḥ
]

`v 42 [
vedanāmātrasaṃśāntāvīdṛśo'pi na dṛśyate |
tasmādyathā cidākāśastathā tatpratipattayaḥ
]

`v 43 [
kutaḥ kilātra pṛthvyādeḥ kīdṛśaḥ saṃbhavaḥ katham |
etadākramaṇe mṛtyo tasmānmā yatnavānbhava
]

`v 44 [
grahītuṃ yujyate vyoma na kadācana kenacit |
śrutvaitadvismito mṛtyurjagāma nijamandiram
]

`v 45 [
śrīrāma uvāca |
brahmaiṣa kathito devastvayā me prapitāmahaḥ |
svayaṃbhūraja ekātmā vijñānātmeti me matiḥ
]

`v 46 [
ākāśajadvija iti nāmāntarapratipādito brahmaiva mayā ākhyāyikātātparyārtho
jaganmithyātvamapi parijñātamiti sūcanena guruṃ praharṣayan śrīrāma uvāca ##-
p. 133)
śrīvasiṣṭha uvāca |
evametanmayā rāma brahmaiṣa kathitastava |
vivādamakaronmṛtyuryamenaitatkṛte purā
]

`v 47 [
manvantare sarvabhakṣo yadā mṛtyurharanprajāḥ |
balametyabjajākrāntāvārambhamakarotsvayam
]

`v 48 [
tadaiva dharmarājena yaemnāśvanuśāsitaḥ |
yadeva kriyate nityaṃ ratistatraiva jāyate
]

`v 49 [
brahmā kila parākāśavapurākramyate katham |
manomātraṃ ca saṃkalpaḥ pṛthvyādirahitākṛtiḥ
]

`v 50 [
yaścidvyomacamatkāraḥ kilākārānubhūtimān |
sa cidvyomaiva no tasya kāraṇatvaṃ na kāryatā
]

`v 51 [
ākāśasphuradākāraḥ saṃkalpapuruṣo yathā |
pṛthvyādirahito bhāti svayaṃbhūrbhāsate tathā
]

`v 52 [
nirmale vyomni muktālīsaṃkalpasvapnayoḥ puram |
apṛtvyādi yathā bhāti svayaṃbhurbhāsate tathā
]

`v 53 [
na dṛśyamasti na draṣṭā paramātmani kevale |
svayaṃcittā tathāpyeṣa svayaṃbhūriti bhāsate
]

`v 54 [
saṃkalpamātramevaitanmano brahmeti kathyate |
saṃkalpākāśapuruṣo nāsya pṛtvyādi vidyate
]

`v 55 [
yathā citrakṛdantaḥsthā nirdehā bhāti putrikā |
tathaiva bhāsate brahmā cidākāśāccharañjanam
]

`v 56 [
cidvyomakevalamanantamanādimadhyaṃ
brahmeti bhāti nijacittavaśātsvayaṃbhūḥ |
ākāravāniva pumāniva vastutastu
vandhyātanūja iva tasya tu nāsti dehaḥ
]