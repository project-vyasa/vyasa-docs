`v 1 [
viṃśaḥ sargaḥ 20
śrīdevyuvāca |
sa te bhartādya saṃpanno dvijo bhūpatvamāgataḥ |
yā sāvarundhatī nāma brāhmaṇī sā tvamaṅgane
]

`v 2 [
ihemau kuruto rājyaṃ tau bhavantau sudampatī |
cakravākāviva navau bhuvi jātau śivāviva
]

`v 3 [
p. 177)
eṣa te kathitaḥ sarvaḥ prāktanaḥ saṃsṛtikramaḥ |
bhrāntimātrakamākāśamevaṃ jīvasvarūpadhṛk
]

`v 4 [
uktāṃ kathāmupasaṃharantī sargadvayavatprāktano'pi sargo bhrama evetyāha -
eṣa iti | tatra brahmākāśasya jīvabhāvabhrama eva mūlamityāha - bhrāntīti | 3
|
bhramādasmāccidākāśe bhramo'yaṃ pratibimbitaḥ |
asatya eva vā satyo bhavatorbhavabhaṅgadaḥ
]

`v 5 [
tasmādbhrāntimayaḥ kaḥ syātko vā bhrāntyujjhito bhavet |
sargo nirargalānarthabodhānnānyo vijṛmbhate
]

`v 6 [
evaṃ ca mithyānarthabodhatvena sarvasargāṇāṃ tulyataivetyāha - tasmāditi | 5
|
śrīvasiṣṭha uvāca |
ityākarṇya ciraṃ cāru vismayotphullalocanā |
bhūtvovāca vaco līlā līlālasapadākṣaram
]

`v 7 [
līlovāca |
devi bhostvadvaco mithyā kathaṃ saṃpannamīdṛśam |
kva viprajīvaḥ svagṛhe kveme vayamiha sthitāḥ
]

`v 8 [
tādṛglokāntaraṃ sā bhūste śailāstā diśo daśa |
kathaṃ bhānti gṛhasyāntarmadbhartā yeṣvavasthitaḥ
]

`v 9 [
matta airāvato baddhaḥ sarṣapasyeva koṭare |
maśakena kṛtaṃ yuddhaṃ siṃhaughairaṇukoṭare
]

`v 10 [
padmākṣe sthāpito merurnirgirṇo bhṛṅgasūnunā |
svapnābdagarjitaṃ śrutvā citraṃ nṛtyanti barhiṇaḥ
]

`v 11 [
asamaṃjasamevaitadyathā sarveśvareśvari |
tathā gṛhāntaḥ pṛthvī śailāścetyasamañjasam
]

`v 12 [
yathāvadetaddeveśi kathayāmalayā dhiyā |
prasādānugṛhīte hi nodvijante mahaujasaḥ
]

`v 13 [
śrīdevyuvāca |
nāhaṃ mithyā vadāmīdaṃ yathāvacchṛṇu sundari |
bhedanaṃ niyatīnāṃ hi kriyate nāsmadādibhiḥ
]

`v 14 [
vibhidyamānāmanyena sthāpayāmyahameva yām |
maryādāṃ tāṃ mayā bhinnāṃ ko'paraḥ pālayiṣyati
]

`v 15 [
sagrāmadvijajīvātmā tasminneva svasadmani |
vyomnyevedaṃ mahārāṣṭraṃ vyomātmaiva prapaśyati
]

`v 16 [
prāktanī sā smṛtirluptā `note[smṛtirnaṣṭā iti pāṭhaḥ]
yuvayoruditānyathā |
svapne jāgratsmṛtiryadvadetanmaraṇamaṅgane
]

`v 17 [
yathā svapne tribhuvanaṃ saṃkalpe trijagadyathā |
yathā kathāryasaṃgrāmo marubhūmau jalaṃ yathā
]

`v 18 [
tasya brāhmaṇagehasya saśailavanapattanā |
iyamantaḥ sthitāḥ bhūmiḥ saṃkalpādarśayoriva
]

`v 19 [
astyaiveyamābhāti satyeva ghanasargatā |
tasmātsatyāvabhāsasya cidvyomnaḥ kośakoṭare
]

`v 20 [
asatyādyatsamutpannaṃ smṛtyā nāma tadapyasat |
mṛtatṛṣnātaraṅgiṇyāṃ taraṅgo'pi na sadyataḥ
]

`v 21 [
idaṃ tvadīyaṃ sadanaṃ tadgehākāśakośagam |
viddhi māṃ tvāṃ ca sarvaṃ ca taccidvyomaiva kevalam
]

`v 22 [
svapnasaṃbhramasaṃkalpasvānubhūtiparamparāḥ |
pramāṇānyatra mukhyāni saṃbodhāya pradīpavat
]

`v 23 [
sthito brāhmaṇagehāntardvijajīvastadambare |
sasamudravanā pṛthvī sthitābja iva ṣaṭpadaḥ
]

`v 24 [
tasyāḥ kasmiṃścidekasminpelave koṇakoṭare |
idaṃ pattanadehādi keśoṇḍraka ivāmbare
]

`v 25 [
tasminnasminpure tanvi tadeva sadanaṃ sthitam |
tasmātkiṃ trasareṇvantarjagadvṛndamiva sthitam
]

`v 26 [
paramāṇau paramāṇau santi vatse cidātmani |
antarantarjagantīti kiṃtvetannāma śaṅkyate
]

`v 27 [
p. 178)
līlovāca |
aṣṭame divase vipraḥ sa mṛtaḥ parameśvari |
gato varṣagaṇo'smākaṃ mātaḥ kathamidaṃ bhavet
]

`v 28 [
śrīdevyuvāca |
deśadairghyaṃ yathā nāsti kāladairghyaṃ tathāṅgane |
nāstyeveti yathānyāyaṃ kathyamānaṃ mayā śṛṇu
]

`v 29 [
yathaitatpratibhāmātraṃ jagatsargāvabhāsanam |
tathaitatpratibhāmātraṃ kṣaṇakalpāvabhāsanam
]

`v 30 [
kṣaṇakalpaṃ jagatsarvaṃ tvattāmattātmajanmanām |
yathāvatpratibhāsasy vakṣye kramamimaṃ śṛṇu
]

`v 31 [
anubhūya kṣaṇaṃ jīvo mithyāmaraṇamūrcchanam |
vismṛtya prāktanaṃ bhāvamanyaṃ paśyati suvrate
]

`v 32 [
tadevonmeṣamātreṇa vyomnyeva vyomarūpyapi |
ādheyo'yamihādhāre sthito'hamiti cetati `note[cetasi iti sarvatra pāṭhaḥ] |
32 |
vyomevādhāradehādiśūnyo'pi cetati `note[cetasi iti sarvatra pāṭhaḥ] smarati |
saṃskāra udbhavatīti yāvat
]

`v 34 [
hastapādādimāndeho mamāyamiti paśyati |
yadeva cetati `note[cetasi iti sarvatra pāṭhaḥ] vapustadevedaṃ sa paśyati |
33 |
etasyāhaṃ pituḥ putro varṣāṇyetāni santi me |
ime me bāndhavā ramyā mamedaṃ ramyamāspadam
]

`v 35 [
jāto'hamabhavaṃ bālo vṛddhiṃ yāto'hamīdṛśaḥ |
bāndhavāścāsya me sarve tathaiva vicarantyamī
]

`v 36 [
cittākāśaghanaikatvātsve'pyanye'pi bhavanti te |
evaṃ nāmodite'pyasya citte saṃsārakhaṇḍake
]

`v 37 [
na kiṃcidapyabhyuditaṃ sthitaṃ vyomaiva nirmalam |
svapne draṣṭari yadvaccittadvaddṛśye cideva sā
]

`v 38 [
sarvagaikatayā yasmātsā svapne dṛṣṭadarśanā |
yathā svapne tathodeti paralokadṛgādibhiḥ
]

`v 39 [
paraloke yathodeti tathaivehābhyudeti sā |
tatsvapnaparalokehalokānāmasatāṃ satām
]

`v 40 [
na manāgapi bhedo'sti vīcīnāmiva vāriṇi |
ato jātamidaṃ viśvamajātatvādanāśi ca
]

`v 41 [
svarūpatvāttu nāstyeva yacca bhāti cideva sā |
yathaiva `note[tathaiva iti pāṭhaḥ] cetyanirhīṇā paramavyomarūpiṇī
]

`v 42 [
svaṃ ātmaiva pāramārthikaṃ rūpaṃ yasya tattvājjagadrūpeṇa nāstyeva | kiṃ tarhi
pratyakṣādipramāṇairbhāti tatrāha - yacceti | adhiṣṭhānacaitanyameva
sarvapramāṇairbhāti tasyaivājñātatvena abādhyatvena ca pramāṇayogyatvānnatu
jaḍaṃ tatrāvaraṇakṛtyābhāvena pramāṇapravṛttiphalābhāvāditi bhāvaḥ | 41
|
sacetyāpi tathaivaiṣā paramavyomarūpiṇī |
tasmāccetyamato nānyadvīcitvādīva vāritaḥ
]

`v 43 [
vīcitvaṃ ca rase nāsti śaśaśṛṅgavadeva hi |
saiva cetyamivāpannā svabhāvādacyutāpyalam `note[svabhāvādattyutāpyalam
iti pāṭhaḥ]
]

`v 44 [
tasmānnāstyeva dṛśyo'rthaḥ kuto'to draṣṭṛdṛśyadhīḥ |
nimiṣeṇaiva jīvasya mṛtimohādanantaram
]

`v 45 [
trijagaddṛśyasargaśrīḥ pratibhāmupagacchati |
yathādeśaṃ yathākālaṃ yathārambhaṃ yathākramam
]

`v 46 [
vāsanānāṃ pratiniyatadeśakālādiviṣayatvāttatprayuktapratibhāpi tathaivetyāha ##-
yathotpādaṃ yathāmātṛ yathāpitṛ yathaurasam |
yathāvayo yathāsaṃvidyathāsthānaṃ yathehitam
]

`v 47 [
yathābandhu yathābhṛtyaṃ yathehāstamayodayam |
ajāta eva jāto'hamiti cetati `note[cetasi iti sarvatra pāṭhaḥ] cidvapuḥ
]

`v 48 [
deśakālakriyādravyamanobuddhīndriyādi ca |
jhaṭityeva mṛterante vapuḥ paśyati yauvane
]

`v 49 [
rākṣasayonau śaṃbhorvarāt mātṛsamānavayaḥprāptyā prathamaṃ yauvane
prāpte'pi kalpitabālyādismṛtimayaḥ kramaḥ paścādudetīti pareṇa saṃbandhaḥ |
48 |
eṣā mātā pitā hyeṣa bālo'bhūvamahaṃ tviti |
nānubhūto'nubhūto vā yaḥ syātsmṛtimayaḥ kramaḥ
]

`v 50 [
paścādudetyasau tasya puṣpasyeva phalodayaḥ |
nimiṣeṇaiva me kalpo gata ityanubhūyate
]

`v 51 [
rātrirdvādaśavarṣāṇi hariścandre tathā hyabhūt |
kāntāvirahiṇāmekaṃ vāsaraṃ vatsarāyate
]

`v 52 [
mṛto jāto'hamanyo me piteti svapnatāsviva |
abhuktasyaiva bhogasya bhuktadhīrupajāyate
]

`v 53 [
p. 179)
bhukte'pyabhuktadhīrdṛṣṭamityalaṅkitavādiṣu |
śūnyamākīrṇatāmeti tulyaṃ vyasanamutsavaiḥ |
vipralambho'pi lābhaśca madasvapnādisaṃvidi
]

`v 54 [
taikṣṇyaṃ yathā maricabījakaṇe sthitaṃ svaṃ
stambheṣu cāracitaputrakajālamantaḥ |
dṛśyaṃ tvananyadidamevamaje'sti śāntaṃ
tasyāstibandhanavimokṣadṛśaḥ kutaḥ kāḥ
]