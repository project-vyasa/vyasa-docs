`v 1 [
p. 216)
ṣaṭtriṃśaḥ sargaḥ 36
śrīvasiṣṭha uvāca |
atha śṛṅgopamāneṣu sthiteṣu śararāśiṣu |
sarvabhīruṣu bhagneṣu vidruteṣu diśo daśa
]

`v 2 [
mātaṅgaśavaśaileṣu viśrāntāmbudapaṅktiṣu |
yakṣarakṣaḥpiśāceṣu krīḍatsu rudhirārṇave
]

`v 3 [
mahatāṃ dharmaniṣṭhānāṃ śīlaujaḥsattvaśālinām |
śuddhānāṃ kulapadmānāṃ vīrāṇāmanivartinām
]

`v 4 [
dvandvayuddhāni jātāni meghānāmiva garjatām |
mithonigaraṇotkāni milantyāpagapūravat
]

`v 5 [
pañjaraḥ pañjareṇeva gajaughena gajoccayaḥ |
savanaḥ savanenādriradriṇevāmiladbalāt
]

`v 6 [
aśvaugho miladaśvānāṃ vṛndenārāviraṃhasā |
taraṅgaughena ghoṣeṇa taraṅgaugha ivārṇave
]

`v 7 [
narānīkaṃ narānīkaḥ samāyudhamayodhayat |
veṇvoghamiva veṇvogho marullolo marudvalam
]

`v 8 [
rathaughaśca rathaughena niṣpipeṣākhilaṃ vapuḥ |
nagaraṃ nagareṇeva daivenoḍḍīnamāsuram
]

`v 9 [
saraccharabharāsāraracitāpūrvavāridam |
yuyudhe sthagitākāśā dhanurdharapatākinī
]

`v 10 [
viṣamāyudhayuddheṣu yoddhāraḥ pelavāśayāḥ |
yadā yuktyā palāyante raṇakalpānale tadā
]

`v 11 [
militāścakriṇaścakrairdhanurdhārairdhanurdharāḥ |
khaḍgibhiḥ khaḍgayoddhāro bhuśuṇḍībhirbhuśuṇḍayaḥ
]

`v 12 [
musalairmusalodārāḥ kuntinaḥ kuntidhāribhiḥ |
ṛṣṭyāyudhā ṛṣṭidharaiḥ prāsibhiḥ prāsapāṇayaḥ
]

`v 13 [
samudgarā mudgaribhiḥ sagadairvilasadgadāḥ |
śāktikaiḥ śaktiyoddhāraḥ śūlaiḥ śūlaviśāradāḥ
]

`v 14 [
prāsāsanavidaḥ prāsaiḥ paraśūktāḥ paraśvadhaiḥ |
lakuṭodyairlakuṭinaścopalairupalāyudhāḥ
]

`v 15 [
pāśibhiḥ pāśadhāriṇyaḥ śaṅkubhiḥ śaṅkudhāriṇaḥ |
kṣurikābhistu kṣurikā bhindipālaiśca tadgatāḥ
]

`v 16 [
vajramuṣṭidharā vajrairaṅkuśairaṅkuśoddhatāḥ |
halairhalanikāṣajñāstriśūlaiśca triśūlinaḥ
]

`v 17 [
śṛṅkhalājālini jālaiḥ śṛṅkhalairalikomalaiḥ |
kṣubhitākalpavikṣubdhasāgarormighaṭā iva
]

`v 18 [
kṣubdhacakradalāvartaḥ śarasīkaramārutaḥ |
prabhramaddhetimakaro vyomaikārṇava ābabhau
]

`v 19 [
utphullāyudhakallolaśirākulajalecaraḥ |
rodorandhrasamudro'sau babhūvāmaradustaraḥ
]

`v 20 [
divyāṣṭakajanānīkaṃ pakṣadvayatayā tayā |
ardhānārdhena kupitaṃ bhūpālābhyāṃ tathā sthitam
]

`v 21 [
madhyadeśādisaṃkhyāne prāgdibhyo'bhyāgatānimān |
līlānāthasya padmasya pakṣe janapadāñchṛṇu
]

`v 22 [
idānīṃ padmasindhurājayoḥ sahāyabhūtān janān
prācyādidigbhedatattaddeśabhedaiḥ krameṇa varṇayituṃ vasiṣṭhaḥ pratijānīte ##-
p. 217)
pūrvasyāṃ kosalāḥ kāśimāgadhā mithilotkalāḥ |
mekhalāḥ karkarā mudrāstathā saṃgrāmaśauṇḍakāḥ
]

`v 23 [
mukhyā himā rudramukhyāstāmraliptāstathaiva ca |
prāgjyotiṣā vājimukhā ambaṣṭhāḥ puruṣādakāḥ
]

`v 24 [
varṇakoṣṭhāḥ saviśvotrā āmamīnāśanāstathā |
vyāghravakrāḥ kirātāśca sauvīrā ekapādakāḥ
]

`v 25 [
mālyavānnāma śailo'tra śibirāñjana eva ca |
vṛṣaladhvajapadmādyāstathodayakaro giriḥ
]

`v 26 [
atha prāgdakṣiṇāyāṃ tu ime vindhyādivāsinaḥ |
cedayo vatsadāśārṇā aṅgavaṅgopavaṅgakāḥ
]

`v 27 [
kaliṅgapuṇḍrajaṭharā vidarbhā mekhalāstathā |
śabarānanavarṇāśca karṇātripurapūrakāḥ
]

`v 28 [
kaṇṭakasthalanāmānaḥ pṛthagdīpakakomalāḥ |
karṇāndhrāścaulikāścaiva tathā cārmaṇvatā api
]

`v 29 [
kākakā hemakuḍyāśca tathā śmaśrudharā api |
baligrīvamahāgrīvāḥ kiṣkindhā nālikeriṇaḥ
]

`v 30 [
atha līlāpaterasya dakṣiṇasyāmime nṛpāḥ |
vindhyo'tha kusumāpīḍo mahendro dardurastathā
]

`v 31 [
malayaḥ sūryavāṃścaiva gaṇā rājyasamṛddhakāḥ |
avantīriti vikhyātāstathā śāmbavatīti ca
]

`v 32 [
daśapūrakathācakrāreṣikāturakacchapāḥ |
vanavāsopagirayaste bhadragirayastathā
]

`v 33 [
nāgarā daṇḍakāścaiva gaṇarāṣṭranṛrāṣṭrakāḥ |
sāhā śaivārṣyamūkāśca karkoṭā vanabimbalāḥ
]

`v 34 [
pampānivāsinaścaiva kairakāḥ karkavīrakāḥ |
sverikā yāsikāścaiva dharmapattanapañjikāḥ
]

`v 35 [
kāśikāstṛṣṇakhallūlā yādāste tāmraparṇakāḥ |
gonardāḥ kanakāścaiva dīnapattanamāmakāḥ
]

`v 36 [
tāmrīkā `note[tāmrīkadaṃbharākīrṇā iti pāṭhaḥ] dambharākīrṇāḥ
sahakāraiṇakāstathā |
vaituṇḍakāstumbavanālājinadvīpakarṇikāḥ
]

`v 37 [
karṇikābhāśca śivayaḥ kauṅkaṇāścitrakūṭakāḥ |
karṇāṭamaṇṭavaṭakā mahākaṭakikāstathā
]

`v 38 [
āndrāśca kolagirayaścāvantikavicerikāḥ |
caṇḍāyattā devanakāḥ krauñcā vāhāstathaiva ca
]

`v 39 [
śilākṣārodabhonandamardanā malayābhidhāḥ |
te citrakūṭaśikharā laṅkārakṣogaṇāḥ smṛtāḥ
]

`v 40 [
atha pratyagdakṣiṇasyāṃ mahārājyasurāṣṭrakāḥ |
sindhusauvīraśūdrākhyā ābhīrā draviḍāstathā
]

`v 41 [
kīkaṭāḥ siddhakhaṇḍākhyāstathā kāliruhā api |
atra hemagiriḥ śailastathā raivatako giriḥ
]

`v 42 [
jayakaccho mayavaro yavanāstatra `note[paṭanāstatra iti pāṭhaḥ]
jantavaḥ |
bāhlīkā mārgaṇāvantā dhūmrāstumbakanāmakāḥ
]

`v 43 [
tathā lājagaṇāścaiva tathātra girivāsinaḥ |
tato'bdhitokaniyutā ete līlāpaterjanāḥ
]

`v 44 [
atha tatpratipakṣasthānimāñjanapadāñśṛṇu |
paścimāyāṃ diśi prauḍhā ime tāvanmahādrayaḥ
]

`v 45 [
maṇimānnāma śailendraḥ kurārpaṇagiristathā |
vano'rkaho meghabhavaścakravānastaparvataḥ
]

`v 46 [
janāḥ pañcajanā nāma kāśabrahmacayāntakāḥ |
tathaiva bhārakṣatathāḥ pārakāḥ śāntikāstathā
]

`v 47 [
śaibyāramarakāyācchā `note[karachāyāmahulā niyamāstathā] guhutvā
niyamāstathā |
haihayāḥ suhmagāyāśca tājikā hūṇakāstathā
]

`v 48 [
pārśvekatakayoḥ karkā giriparṇāvamāstathā |
saṃtyaktadharmamaryādāste varṇā mlecchajātayaḥ
]

`v 49 [
tato'janapadā bhūmiryojanānāṃ śatadvayam |
tato mahendraśikharī muktāmaṇimayāvaniḥ
]

`v 50 [
yute mahīdharaśatairathāśvo nāma parvataḥ |
tato mahārṇavo bhīmaḥ pāriyātragiristaṭe
]

`v 51 [
paścimottaradigbhāge deśo girimati sthitaḥ |
tathā veṇupatiścaiva tato narapatirmahī
]

`v 52 [
tathā phalguṇakāścaiva māṇḍavyānekanetrakāḥ |
purukundāśca pārāśca bhānumaṇḍalabhāvanāḥ
]

`v 53 [
vanmilā nalinā dīrghā dīrghakeśāṅgabāhavaḥ |
raṅgāśca stanikāścānyā guruhāścaluhāstathā `note[clahāstathā iti
pāṭhaḥ]
]

`v 54 [
p. 218)
tataḥ strīrāṣṭramatulaṃ govṛṣāpatyabhojanam |
athottarasyāṃ himavānkrauñco'tha madhumāngiriḥ
]

`v 55 [
kailāso vasumānmerustatpādeṣu janā ubhe |
madrāvārevayaudheyā mālavāḥ śūrasenikāḥ
]

`v 56 [
rājanyāśca tathā jñeyā arjunātanayastathā |
trigarta ekapātkṣudrāmabalāsvastavāsinaḥ
]

`v 57 [
abalāḥ prakhalāḥ śākāḥ kṣemadhūrtaya eva ca |
daśadānāgāvasanyadaṇḍāhanyasanāstathā
]

`v 58 [
dhānadāḥ sarakāścaiva vāṭadhānāstathaiva ca |
antaradvīpagāndhārāstathāvantisurāstathā
]

`v 59 [
atha takṣaśilā nāma tato vīlavagodhanī |
puṣkarāvartadeśasya yaśovatimahī tataḥ
]

`v 60 [
tato nābhimatirbhūmistikṣā kālavarāstathā |
kāhakaṃ nagaraṃ caiva surabhūtipuraṃ tathā
]

`v 61 [
tathaiva ratikādarśā antarādarśa eva ca |
tataḥ piṅgalapāṇḍavyaṃ yāmune yātudhānakāḥ
]

`v 62 [
mānavā nāṃganā hematālāḥ svasvamukhāstathā |
himavānvasumānkrauñcakailāsāvityagāstathā
]

`v 63 [
tato'janapadā bhūmiraśītiśatayojanā |
atha prāguttarasyāṃ tu kramājjanapadāñchṛṇu
]

`v 64 [
kālutā brahmaputrāśca kuṇidāḥ khadināstathā |
mālavā randhrarājyāśca vanā rāṣṭrāstathaiva ca
]

`v 65 [
keḍavastāḥ siṃhaputrāstathā vāmanatāṃ gatāḥ |
sāvākaccāpalavahāḥ kāmirā daradāstathā
]

`v 66 [
abhisāsadajārvākāḥ palolakuvikautukāḥ |
kirātāyāmupātāśca dīnāḥ svarṇamahī tataḥ
]

`v 67 [
devasthalopavanabhūstadanūditaśrī-
rviśvāvasostadanu mandiramuttamaṃ ca |
kailāsabhūstadanu mañjuvanaścaśailo
vidyādharāmaravimānasamānabhūmiḥ
]