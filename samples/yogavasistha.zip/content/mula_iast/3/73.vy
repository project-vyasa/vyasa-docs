`v 1 [
trasaptatitamaḥ sargaḥ 73
śrīvasiṣṭha uvāca |
karkaṭīkaṭuvṛttāntaṃ sarvamākarṇya vāsavaḥ |
nāradaṃ paripapraccha punarjātakutūhalaḥ
]

`v 2 [
śakra uvāca |
sūcīvṛttapiśācatvaṃ tapasopārjya tattayā |
karkaṭyā himamarkaṭyā ke bhuktā vibhavā mune
]

`v 3 [
śrīnārada uvāca |
jīvasūcyāḥ piśācatvaṃ gatāyāḥ śakra pelavam |
āsītkārṣṇāyasī sūcī tasyāḥ samavalambanam
]

`v 4 [
tatsamālambanaṃ tyaktvā vyomavātarathasthayā |
prāṇamārutamārgeṇa tayā dehapraviṣṭayā
]

`v 5 [
sarveṣāmāntratantrīṇāṃ snāyumedovasāsṛjām |
randhreṇa pakṣiṇevāntarnilīnaṃ malinātmanām
]

`v 6 [
yasyāṃ nāḍyāṃ nabhovāyurmāti tattāmupetayā |
tatra śūlaṃ kṛtaṃ sthūlanyagrodhāya ivotkaṭam
]

`v 7 [
taccharīrendriyaistāni tathānyāni bahūni ca |
bhuktāni naramāṃsāni bhojanānyucitāni ca
]

`v 8 [
suptaṃ vivalitānlpamālayā mugdhabālayā |
kāntavakṣaḥsthalasyūtasṛṣṭapatrakapolayā
]

`v 9 [
vidrutaṃ vītaśokāsu vihaṅgyā vanavīthiṣu |
kalpadrumaughapuṣpāgradviguṇāmbhojapaṅktiṣu
]

`v 10 [
pīta āmodamandāramakarandakaṇāsavaḥ |
vaneṣvamara"ailānāmalinyāmalilīlayā
]

`v 11 [
carvitāni śavāṅgāni gṛdhnyā'gartāni vṛddhayā |
khaḍgapṛṣṭhyeva saṃgrāme vīrāṅgāni javeddhayā
]

`v 12 [
sarvāṅgakośanāḍīṣu dikṣvivānilalekhayā |
uḍḍīnamavaḍīnaṃ ca kācaughavyomavīthiṣu
]

`v 13 [
virāḍātmahṛdi prāṇavātaspandāḥ sphuranti tu |
yathā tathā prasphuritaṃ pratidehagṛhaṃ tayā
]

`v 14 [
sarvaprāṇiśarīreṣu bhānti cicchaktayastathā |
dīpaprabhābhāsitayā gṛhiṇyeva svasadmasu
]

`v 15 [
vihṛtaṃ rudhireṣvantardravaśaktyeva vāriṣu |
abdhiṣvāvartavṛttyeva jaṭhareṣu vivalgitam
]

`v 16 [
suptaṃ medaḥsu śubhreṣu śeṣāṅgeṣviva śauriṇā |
svāditaścāṅgagandho'ntaḥ pītaśaktyāmṛtaṃ yathā
]

`v 17 [
p. 309)
tarugulmauṣadhādīnāṃ hṛdaujānyanilaśriyā |
paribhuktānyaśuklāni hiṃsayodhīkṛtāni ca
]

`v 18 [
atho jīvamayī sūcī syāmiti sthāvareṇa sā |
saṃpannā tāpasī sūcī cetanā pāvanī sitā
]

`v 19 [
saiveyaṃ svasaṃkalpā tapasi sthairyeṇa tāpasī satī paramapāvanī saṃpannetyāha ##-
adṛśyayā tayā ceha mārutograturaṃgayā |
ayaḥsūcyā'nilatayā vahantyā dikṣvaruddhayā
]

`v 20 [
pītaṃ bhuktaṃ vilasitaṃ dattaṃ dāpitamāhṛtam |
nartitaṃ gītamuṣitamanantaiḥ prāṇidehakaiḥ
]

`v 21 [
adṛśyayā'śarīriṇyā manaḥpavanadehayā |
kṛtamākāśarūpiṇyā na tadasti na yattayā
]

`v 22 [
mattayā śaktayāsvādarasāccalitametayā |
kālamālānamāśritya kariṇyeva vivalgitam
]

`v 23 [
kallolabahulādhūtadehadṛṣṭanadīṣvalam |
vegairvedhuryakāriṇyā mattayā makarāyitam
]

`v 24 [
aśaktayā nigirituṃ medomāṃsaṃ tathā hṛdi |
nūnaṃ ruditamarthāḍhyavṛddhāturadhiyā yathā
]

`v 25 [
ajoṣṭramṛgahastyaśvasiṃhavyāghrādinartitam |
nartakyeva ciraṃ raṅge valayāṅgadamaṅgake
]

`v 26 [
bahirantaśca vāyūnāmekatvamanujātayā |
gandhalekhikayevāntaḥ sthitaṃ durbalayā tathā
]

`v 27 [
bahiḥ vātaskandheṣu | antaḥ prāṇeṣu | durbalayā | vāyugatiparavaśayeti yāvat | 26
|
mantrauṣadhitapodānadevapūjādibhirhatā |
bahirgirinadītuṅgataraṅgavadupadrutā
]

`v 28 [
dīpaprabhevāvijñātagatirgatyāśu līyate |
ayaḥsūcyāṃ mātarīva tatra nirvṛtimeti sā
]

`v 29 [
svavāsanānusāreṇa sarva āspadamīhate |
sūcitvameva rākṣasyā sūcītvenāspadīkṛtam
]

`v 30 [
sarvā vihṛtyāpi diśaḥ svamevāspadamāpadi |
jīvasūcī lohasūcīmivāyāti jaḍo janaḥ
]

`v 31 [
evaṃ prayatamānā sā viharantī diśo daśa |
mānasīṃ tṛptimāyātā na śārīrīṃ kadācana
]

`v 32 [
sati dharmiṇi dharmā hi saṃbhavantīha nāsati |
śarīraṃ vidyate yasya tasya tatkila tṛpyati
]

`v 33 [
atha tṛptasya dehasya smaraṇātprāktanasya sā |
babhūva duḥkhitasvāntā pūrṇodarasukhārthinī
]

`v 34 [
tataḥ prāktanadehārthaṃ kariṣye vipulaṃ tapaḥ |
iti saṃcintya tapase deśaṃ nirṇīya sātmanā
]

`v 35 [
veveśākāśagṛdhrasya hṛdayaṃ taruṇasya sā |
prāṇamārutamārgeṇa khaṃ khagīva vileśayā
]

`v 36 [
gṛdhraḥ svāmayasūcitvaṃ kaścidetatsamāśritaḥ |
nitāntapreritaḥ sūcyā kartuṃ mana upādade
]

`v 37 [
sūcīmādāya gṛdhro'sau yayau taccintitaṃ girim |
antaḥsūcipiśācyante nunno'bda iva vāyunā
]

`v 38 [
tatrājane mahāraṇye sthāpayāmāsa tāmasau |
sarvasaṃkalparahite pade yogīva cetanām
]

`v 39 [
ekenaivāśu sā tena pādaprāntena susthitā |
saṃpratiṣṭhāpitevadrimūrdhni gṛdhreṇa devatā
]

`v 40 [
rajaḥkaṇagṛhasthāṇuśirasyekena sānunā |
pādenātiṣṭhadudgrīvaṃ śikhīva girimūrdhani
]

`v 41 [
`note[ujjihvaṃ śikhīva iti pāṭhaḥ sādhīyān | śikhī agniriva iti
vyākhyānurodhāt]
p. 310) 189
utthitāṃ sthāpitāṃ sūcīṃ gṛdhreṇa jīvasūcikā |
dṛṣṭvā bahirvinirgantuṃ khagadehātpracakrame
]

`v 42 [
khagadehānnirjagāma sūcī pronmukhacetanā |
pavanādgandhalekheva ghrāṇavātalavonmukhī
]

`v 43 [
jagāma gṛdhraḥ svaṃ deśaṃ bhāraṃ tyaktveva bhārikaḥ |
nivṛttavyādhiriva sa babhūvāntaranākulaḥ
]

`v 44 [
ataḥ sūcistayādhārastapase parikalpitā |
dṛḍhaḥ susadṛśo'rthānāṃ viniyogo hi rājate
]

`v 45 [
na hyamūrtasya siddhyanti vinādhāraṃ kila kriyāḥ |
ityādhāraikaniṣṭhatvamāśrityāsau tapaḥsthitā
]

`v 46 [
jīvasūcī lohasūcīṃ piśācī śiṃśapāmiva |
sarvato valayāmāsa vātyevāmodalekhikām
]

`v 47 [
tatastataḥ prabhṛtyeṣā sūcī dīrghatapasvinī |
araṇyānyāṃ sthitā śakra tatra varṣagaṇānbahūn
]

`v 48 [
tasyā varārthaṃ yatnaṃ tvaṃ kuru kartavyakovida |
cireṇa saṃbhṛtaṃ lokamalaṃ dagdhuṃ hi tattapaḥ
]

`v 49 [
śrīvasiṣṭha uvāca |
iti nāradataḥ śrutvā śakraḥ sūcīnirīkṣaṇe |
mārutaṃ preṣayāmāsa daśadiṅmaṇḍalānyatha
]

`v 50 [
jagāmātha marutsaṃvidātmanā tāmavekṣitum |
athāmucya nabhomārgaṃ vicacāra tvarānvitaḥ
]

`v 51 [
sā tasya saṃvitkṣiprārdhenaiva sarvagatā satī |
paramārcirivāvighnaṃ sahasaiva dadarśa ha
]

`v 52 [
bhūmeḥ saptasamudrānte nibaddhāṃ vipulasthalīm |
lokālokādrirasanāṃ tato maṇimayopamam
]

`v 53 [
svādūdakābdhivalayaṃ sakoṭarakakubgaṇam |
puṣkaradvīpavalayaṃ tadantargirimaṇḍale
]

`v 54 [
madirāmbhodhivalayaṃ tajjalecarasaṃsthitam |
gomedadvīpakaṭakaṃ tanmadhyaviṣayavrajam
]

`v 55 [
ikṣūdakābdhiparikhaṃ śāntaṃ girigaṇāntaram |
krauñcadvīporvarāpīṭhaṃ śāntaṃ gatagirikramam
]

`v 56 [
kṣīrābdhimuktāvalayaṃ samadhyagatanāyakam |
śvetākhyadvīpavalayaṃ sabhūtapravibhāgakam `note[saṃbhūta iti
pāṭhaḥ]
]

`v 57 [
tato ghṛtodavalayasvāntasthapuramandiram |
kuśadvīpavṛtivyāptaṃ samahāśailakoṭaram
]

`v 58 [
dadhyambhorāśiraśanāsāntāmbarapurodaram |
śākadviporvarākāraṃ sāntasthaviṣayāntaram
]

`v 59 [
kṣārāmbhorāśiparidhiṃ sāntasthaviṣayāntaram |
jambūdvīpe mahāmeruṃ kulaparvatasaṃkulam
]

`v 60 [
vātaskandhebhya evādau patitānilavedanā |
krameṇānena paryante tenaiva prasṛto'ñjasā
]

`v 61 [
vāyurālokayannaddhā jambūdvīpaṃ nirīkṣya ca |
tatprāpa himavacchṛṅgaṃ yatra sūcī tapasvinī
]

`v 62 [
śṛṅgamūrdhni mahatyugre sāraṇyānīmavāpa tām |
dvitīyākāśavitatāṃ varjitāṃ prāṇikarmabhiḥ
]

`v 63 [
asaṃjātatṛṇavyūhāṃ nikaṭatvādvivasvataḥ |
rajomayīmeva tatāṃ saṃsāraracanāmiva
]

`v 64 [
mṛgatṛṣṇānadīsārthapūraṇīyābdhitāṃ gatām |
śakrakodaṇḍasaṃkāśamṛgatṛṣṇāsaricchatām
]

`v 65 [
amitānantaparyantāṃ lokapālekṣitairapi |
kevalaṃ pavanaspandapravahaddhūlikuṇḍalām
]

`v 66 [
sūryāṃśukuṅkumāliptāṃ lagnacandrāṃśucandanām |
vilāsinīmiva vyomno vātasūtkārapāyinīm
]

`v 67 [
kāntāliṅganasukhavyañjakodhvaniḥ sūtkārastaṃ pāyayati śrāvayati tacchīlām |
66 |
p. 311) 189
saptadvīpasamudramudraṇasamucchannaikadeśāśrayaṃ
bhūpīṭhaṃ parito vihṛtya pavano dīrghādhvanā jarjaraḥ |
tāṃ prāpyogragiristhalīmalivapurvyomāṅgalagnāmiva
vyāptānantadigantapūrakabṛhaddeho viśaśrāma saḥ
]