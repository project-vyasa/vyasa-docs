`v 1 [
ṣaḍaśītitamaḥ sargaḥ 86
śrībhānuruvāca |
kalpanāmni mahādeva hyastane divase tava |
tale kailāsaśailasya jambūdvīpaikakoṇake
]

`v 2 [
p. 338) 204
suvarṇajaṭanāmnā yastvatputrairjanitaprajaiḥ |
maṇḍalaṃ kalpitaṃ śrīmadanalpasukhasundaram
]

`v 3 [
tatrābhūdatidharmātmā brāhmaṇo brahmavittamaḥ |
indunāmātiśāntātmā kaśyapasya kulodbhavaḥ
]

`v 4 [
tasmiṃstadā nivasato nityaṃ svajanamaṇḍale |
tasya prāṇasamā bhāryā kācittasyāṃ mahātmanaḥ
]

`v 5 [
na babhūvātmajastasya marubhūmau tṛṇaṃ yathā |
na vyarājata sā bhāryā tasya niṣphalapuṣpitā
]

`v 6 [
ṛjvī gaurī suśuddhāpi śūnyā śaralatā yathā |
tau tato daṃpatī khinnau putrārthaṃ tapase gireḥ
]

`v 7 [
kailāsasyāṃśamārūḍhau rūḍhāviva navadrumau |
bhūtairanāvṛte śūnye tasminkailāsakuñjake
]

`v 8 [
tepatustau tapo ghoraṃ jalāhārau tarusthitī |
ekaṃ pānīyaculakaṃ pītvā divasaparyaye
]

`v 9 [
nispandamutthitau vārkṣīṃ vṛttimāśritya saṃsthitau |
tasthatustau tadā tatra tāvatkālaṃ taruvratau
]

`v 10 [
yāvattretā dvāparaṃ ca yuge dve eva te gate |
tatastuṣṭo'bhavaddevastayoḥ śaśikalādharaḥ
]

`v 11 [
dinātapātāpitayorinduḥ kumudayoriva |
ājagāma tamuddeśaṃ yatra tau vipradaṃpatī
]

`v 12 [
salatāpādapaṃ deśaṃ puṣpākara iveśvaraḥ |
daṃpatī tau vṛṣārūḍhaṃ somaṃ somārdhaśekharam
]

`v 13 [
phullānanau dadṛśatuḥ kumude śaśinaṃ yathā |
tau taṃ praṇematurdevaṃ tuṣārāmalamīśvaram
]

`v 14 [
dyāvāpṛthivyāvuditaṃ paripūrṇamivoḍupam |
tarjayanpavanādhūtanavavṛkṣānanasvaram
]

`v 15 [
mṛdūddāmasthitaspandi provācātha vacaḥ śivaḥ |
īśvara uvāca |
varaṃ vipra gṛhāṇāśu tuṣṭo'smi tava vāñchitam
]

`v 16 [
madhumāsarasākrāntavṛkṣavanmudito bhava |
vipra uvāca |
bhagavandevadeveśa daśa putrā mahādhiyaḥ
]

`v 17 [
bhavyā bhavantu me bhūyaḥ śoko yena na bhādhate |
bhānuruvāca |
athaivamastviti procya jagāmāntardhimīśvaraḥ
]

`v 18 [
vyomni vārinidhirhrādaṃ kṛtvevormimahāvapuḥ |
tatastau dampatī tuṣṭau śivalabdhavarau gṛham
]

`v 19 [
gatau gīrvāṇasadṛśau svamivomāmaheśvarau |
tatrāsau brāhmaṇī gehe babhūvodāragarbhiṇī
]

`v 20 [
babhau pūrṇodarā śyāmā meghalekheva vāriṇā |
kāle'tha suṣuve putrānpratipaccandrakomalān
]

`v 21 [
daśabālāṃstato mugdhānvasudheva navāṅkurān |
kṛtabrāhmaṇasaṃskārā vṛddhimīyurmahaujasaḥ
]

`v 22 [
svalpenaiva hi kālena prāvṛṣeva navāmbudāḥ |
te saptavarṣavayaso babhūvurjñātavāṅmayāḥ
]

`v 23 [
virejustejasā tatra nabhasīvāmalā grahāḥ |
atha kālena mahatā teṣāṃ tau pitarau tadā
]

`v 24 [
saṃjagmatustanuṃ tyaktvā svāṃ gatiṃ gatikovidau |
mātāpitṛbhyāṃ rahitā daśa te brāhmaṇāstataḥ
]

`v 25 [
yayuḥ kailāsaśikharaṃ gṛhaṃ saṃtyajya khedinaḥ |
tatra saṃcintayāmāsurudvignāste vibandhavāḥ(?)
]

`v 26 [
khedino duḥkhitāḥ | teṣāṃ
bhāgyavaśādbhāvihairaṇyagarbhaiśvaryaprāptyanusāri vicāra utpanna ityāha ##-
kiṃ syādiha paraṃ śreya ūcuścedaṃ parasparam |
kimiha syātsamucitaṃ bhrātaraḥ kimaduḥkhadam
]

`v 27 [
p. 339) 204
kiṃ mahattvaṃ kimaiśvaryaṃ kiṃ mahāvibhavaṃ śubham |
kiṃ tadetajjanaiśvaryaṃ sāmanto hi maheśvara
]

`v 28 [
sāmantasaṃpatkiṃnāma rājāno hi maheśvarāḥ |
kā nāma saṃpadbhūpānāṃ samrāḍiha maheśvaraḥ
]

`v 29 [
kiṃ nāma tanmahendratvaṃ yanmuhūrtaṃ prajāpateḥ |
vinaśyati na yatkalpe kiṃ syāttadiha śobhanam
]

`v 30 [
bhāṣamāṇeṣvathaiteṣu jyeṣṭho bhrātā mahāmatiḥ |
gambhīravāguvācedaṃ mṛgayūthānmṛgo yathā
]

`v 31 [
aiśvaryāṇāṃ hi sarveṣāmākalpaṃ na vināśi yat |
rocate bhrātarastanme brahmatvamiha netarat
]

`v 32 [
etaduktaṃ tadakhilā dvijaputrāsta uttamāḥ |
vacobhiraindavāstatra sādhu sādhvityapūjayan
]

`v 33 [
ūcuścedaṃ kathaṃ tāta sarvaduḥkhopamārjanam |
padmāsanaṃ jagatpūjyaṃ virañcitvamavāpnumaḥ
]

`v 34 [
bhrātrā tena punaḥ proktā bhrātaro bhūritejasaḥ |
maduktaṃ sarva eveme bhavantaḥ pālayantu vai
]

`v 35 [
padmāsanagato bhāsvānbrahmāhamiti tejasā |
sṛjāmi saṃharāmīti dhyānamastu cirāya vaḥ
]

`v 36 [
agrajeneti kathite bāḍhaṃ kṛtvā ta uttamāḥ |
dhyānādhīnadhiyastasthuḥ sahaiva jyāyasā rasāt
]

`v 37 [
lipikarmārpitākārā dhyānāsaktadhiyaśca te |
antasthenaiva manasā cintayāmāsurādṛtāḥ
]

`v 38 [
atha utphullakamalakośavakronnatāsanaḥ |
brahmāhaṃ jagatāṃ sraṣṭā kartā bhoktā maheśvaraḥ
]

`v 39 [
yajñakriyākramavataḥ sāṅgopāṅgā maharṣayaḥ |
sarasvatyātha gāyatryā yuktā vedā narā ime
]

`v 40 [
lokapālaparākrāntaḥ saṃcaratsiddhamaṇḍalaḥ |
ayamuddāmasaubhāgyaḥ svargaḥ svaravibhūṣitaḥ
]

`v 41 [
parvatadvīpajaladhikānanaiḥ samalaṃkṛtam |
idaṃ bhūmaṇḍalaṃ caiva trilokīkarṇakuṇḍalam
]

`v 42 [
etatpātālakuharaṃ daityadānavabhojitam |
amṛtastrīgaṇākīrṇaṃ gṛhaṃ gaganakoṭaram
]

`v 43 [
ayamindro mahābāhuḥ prajālaṃkṛtadottamaḥ |
trailokyanagarīmekaḥ pāti pāvanayajñabhuk
]

`v 44 [
dīprajālavaratrābhiravaṣṭabhyātha diggaṇam |
krameṇa pratapantyete bhānavo bhūribhānavaḥ
]

`v 45 [
lokapālā ime lokaṃ rakṣanti `note[rakṣantyakṣubdhavṛttayaḥ iti
pāṭhaḥ] śuddhavṛttayaḥ |
maryādābhiratucchābhirgopālā gogaṇaṃ yathā
]

`v 46 [
unmajjanti nimajjanti prasphuranti patanti ca |
taraṅgā iva toyānāmimāḥ pratidinaṃ prajāḥ
]

`v 47 [
p. 340) 205
sṛjāmīmamahaṃ sargaṃ saṃharāmi tathādṛtaḥ |
ayamātmani tiṣṭhāmi śāmyāmi bhuvaneśvaraḥ
]

`v 48 [
ayaṃ saṃvatsaro yāta idaṃ pariṇataṃ yugam |
sṛṣṭerayamasau kālaḥ svayaṃ saṃharaṇasya ca
]

`v 49 [
ayameva gataḥ kalpo brāhmī rātririyaṃ tatā |
ayamātmani tiṣṭhāmi pūrṇātmā parameśvaraḥ
]

`v 50 [
iti bhāvitayā uddhyā te dvijā atha aindavāḥ |
daśādrivṛttayastasthuḥ samutkīrṇā ivopalāt
]

`v 51 [
atha aindavā ityasaṃdhiḥ saṃhitā'nityatvāt | adrivṛttayo dṛḍhabaddhāsanāḥ |
50 |
adhigatakamalāsanakramāste
parigalitetaratucchavṛttijālāḥ |
satatamatitarāṃ kuśāsanasthā-
ściramiti paṅkajakalpane virejuḥ
]