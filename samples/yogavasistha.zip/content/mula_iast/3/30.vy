`v 1 [
triṃśaḥ sargaḥ 30
śrīvasiṣṭha uvāca |
pṛthivyaptejasāṃ tatra nabhasvannabhasorapi |
yathottaraṃ daśaguṇānatītyāvaraṇānkṣaṇāt
]

`v 2 [
dadarśa paramākāśaṃ tatpramāṇavivarjitam |
tathā tataṃ jagadidaṃ yathā tatrāṇḍamātrakam
]

`v 3 [
tādṛśāvaraṇānsargānbrahmāṇḍeṣu dadarśa sā |
koṭiśaḥ sphuritānvyomni trasareṇūnivātape
]

`v 4 [
mahākāśamahāmbhodhau mahāśūnyatvavāriṇi |
mahāciddravabhāvotthānbudbudānarbudaprabhān
]

`v 5 [
kāṃścidāpatato'dhastātkāṃściccopari gacchataḥ |
kāṃścittiryaggatīnanyānsthitāṃstabdhānsvasaṃvidā
]

`v 6 [
yatra yatroditā saṃvidyeṣāṃ yeṣāṃ yathā yathā |
tatra tatroditaṃ rūpaṃ teṣāṃ teṣāṃ tathā tathā
]

`v 7 [
nehaiva tatra nāmordhvaṃ nādho naca gamāgamāḥ |
anyadeva padaṃ kiṃcittasmāddehāgamaṃ hi tat
]

`v 8 [
utpadyotpadyate tatra svayaṃ saṃvitsvabhāvataḥ |
svasaṃkalpaiḥ śamaṃ yāti bālasaṃkalpajālavat
]

`v 9 [
p. 204)
śrīrāma uvāca |
kimadhaḥ syātkimūrdhvaṃ syātkiṃ tiryaktatra bhūasure |
iti brūhi mama brahmannihaiva yadi na sthitam
]

`v 10 [
śrīvasiṣṭha uvāca |
sasarvāvaraṇā ete mahatyantavivarjite |
brahmāṇḍā bhānti durdṛṣṭervyomni keśoṇḍrako yathā
]

`v 11 [
māyike prapañce naitādṛśaniyamavyabhicāro doṣāyetyāśayena
prathammuttaramāha vasiṣṭhaḥ - sasarveti | durdṛṣṭestimiradūṣitadṛṣṭeḥ |
10 |
asvātantryātpradhāvanti padārthāḥ sarva eva yat |
brahmāṇḍe pārthivo bhāgastadadhastūrdhvamanyathā
]

`v 12 [
pipīlikānāṃ mahatāṃ vyomni vartulaloṣṭake |
daśadikkamadhaḥ pādāḥ pṛṣṭhamūrdhvamudāhṛtam
]

`v 13 [
vṛkṣavalmīkajālena keṣāṃciddhṛdi bhūtalam |
sasurānaradaityena veṣṭitaṃ vyoma nirmalam
]

`v 14 [
saṃbhūtaṃ saha bhūtena sagrāmapuraparvatam |
idaṃ kalpanabhūtena pakvākṣoṭamivatvacā
]

`v 15 [
yathā vindhyavanābhoge prasphuranti kareṇavaḥ |
tathā tasminparābhoge brahmāṇḍatrasareṇavaḥ
]

`v 16 [
tasminsarvaṃ tataḥ sarvaṃ tatsarvaṃ sarvataśca yat |
tacca sarvamayo nityaṃ tathā tadaṇukaṃ prati
]

`v 17 [
śuddhabodhamaye tasminparamālokavārdidhau |
ajasrametya gacchanti brahmāṇḍākhyāstaraṅgakāḥ
]

`v 18 [
antaḥśūnyāḥ sthitāḥ kecitsaṃkalpakṣayarātrayaḥ |
taraṅgā iva toye'bdhau prohyante śūnyatārṇave
]

`v 19 [
keṣāṃcidantaḥkalpāntaḥ pravṛtto ghargharāravaḥ |
na śruto'nyairna ca jñātaḥ svabhāvena rasākulaiḥ
]

`v 20 [
anyeṣāṃ prathamārambhe śuddhabhūṣu vijṛmbhate |
sargaḥ saṃsiktabījānāṃ kośe'ṅkurakalā yathā
]

`v 21 [
mahāpralayasaṃpattau sūryārcirvidyuto'drayaḥ |
pravṛttā galituṃ kecittāpe himakaṇā iva
]

`v 22 [
ākalpaṃ nipatantyeva kecidaprāptabhūmayaḥ |
yāvadviśīrya jāyante tathā saṃvinmayāḥ kila
]

`v 23 [
p. 205)
stabdhā iva sthitāḥ kecitkeśoṇḍrakamivāmbare |
vāyoḥ spandā ivābhānti tathā proditasaṃvidaḥ
]

`v 24 [
ācārādvedaśāstrāṇāmādya evānyathodite |
ārambho'pi tathānyeṣāmanityaḥ saṃsthitaḥ kramaḥ
]

`v 25 [
kecidbrahmādipuruṣāḥ kecidviṣṇvādisargapāḥ |
keciccānyaprajānāthāḥ kecinnirnāthajantavaḥ
]

`v 26 [
kecidvicitrasargeśāḥ kecittiryaṅmayāntarāḥ |
kecidekārṇavāpūrṇā itare janivarjitāḥ
]

`v 27 [
brahmādīnāṃ samaprādhānye vicitrasargeśāḥ | itthaṃ ca
prāṇikarmavāsanāvaicitryātsraṣṭṝṇāmicchābodhādivaicitryācca yathecchaṃ
brahmāṇḍavaicitryaṃ sukalpamityāśayenāha - tiryaṅmayāntarā ityādinā |
26 |
kecicchilāṅganiṣpiṇḍāḥ kecitkṛmimayāntarāḥ |
keciddevamayā eva kecinnaramayāntarāḥ
]

`v 28 [
kecinnityāndhakārāḍhyāstathā śīlitajantavaḥ |
kecinnityaprakāśāḍhyāstathā śīlitajantavaḥ
]

`v 29 [
kecinmaśakasaṃpūrṇā udumbaraphalaśriyaḥ |
nityaṃ śūnyāntarāḥ kecicchūnyaspandātmajantavaḥ
]

`v 30 [
sargeṇa tādṛśenānye pūrṇā ye'ntardhiyāmiha |
kalpanāmapi nāyānti vyomapūrṇācalo yathā
]

`v 31 [
tādṛgambarameteṣāṃ mahākāśaṃ tataṃ sthitam |
ājīvitaṃ pragacchadbhirvisṁvādyairyanna mīyate
]

`v 32 [
pratyekasyāṇḍagolasya sthitaḥ kaṭakaratnavat |
bhūtākṛṣṭikaro bhāvaḥ pārthivaḥ svasvabhāvataḥ
]

`v 33 [
yaḥ sarvavibhavo'smākaṃ dhiyāṃ na viṣayaṃ tataḥ |
tajjagatkathane śaktirna `note[śaktirmama nāsti iti pāṭhaḥ] mamāsti
mahāmate
]

`v 34 [
bhīmāndhakāragahane sumahṛtyaraṇye
nṛtyantyadarśitaparasparameva mattāḥ |
yakṣā yathā pravitate paramāmbare'nta-
revaṃ sphuranti subahūni mahājaganti
]