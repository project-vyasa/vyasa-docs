`v 1 [
saptadaśottaraśatatamaḥ sargaḥ 117
śrīrāma uvāca |
kīdṛśyo bhagavanyogabhūmikāḥ saptasiddhidāḥ |
samāseneti me brūhi sarvatattvavidāṃvara
]

`v 2 [
śrīvasiṣṭha uvāca |
ajñānabhuḥ saptapadā jñabhuḥ saptapadaiva hi |
padāntarāṇyasaṃkhyāni bhavantyanyānyathaitayoḥ
]

`v 3 [
svayatnasādhakarasānmahāsattābharonnateḥ |
ete pratipadaṃ baddhamūle saṃphalataḥ phalam
]

`v 4 [
p. 401) 236
tatra saptaprakārāṃ tvamajñānasya bhuvaṃ śṛṇu |
tataḥ saptaprakārāṃ tvaṃ śroṣyasi jñānabhūmikām
]

`v 5 [
svarūpāvasthitirmuktistadbhraṃśo'haṃtvavedanam |
etatsaṃkṣepataḥ proktaṃ tajjñatvājñatvalakṣaṇam
]

`v 6 [
śuddhasanmātrasaṃvitteḥ svarūpānna calanti ye |
rāgadveṣodayābhāvātteṣāṃ nājñatvasaṃbhavaḥ
]

`v 7 [
yatsvarūpaparibhraṃśāccetyārthe citimajjanam |
etasmādaparo moho na bhūto na bhaviṣyati
]

`v 8 [
arthādarthāntaraṃ citte yāti madhye hi yā sthitiḥ |
nirastamananā yāsau svarūpasthitirucyate
]

`v 9 [
saṃśāntasarvasaṃkalpā yā śilāntariva sthitiḥ |
jāḍyanidrāvinirmuktā sā svarūpasthitiḥ smṛtā
]

`v 10 [
ahaṃtāṃśe kṣate śānte bhede niḥspandatāṃ gate |
ajaḍā yā prakacati tatsvarūpamiti sthitam
]

`v 11 [
tatrāropitamajñānaṃ tasya bhūmīrimāḥ śṛṇu |
bījajāgrattathā jāgranmahājāgrattathaiva ca
]

`v 12 [
jāgratsvapnastathā svapnaḥ svapnajāgratsuṣuptakam |
iti saptavidho mohaḥ punareva parasparam
]

`v 13 [
śliṣṭo bhavatyanekākhyaḥ śṛṇu lakṣaṇamasya ca |
prathame cetanaṃ yatsyādanākhyaṃ nirmalaṃ citaḥ
]

`v 14 [
bhaviṣyaccittajīvādināmaśabdārthabhājanam |
bījarūpaṃ sthitaṃ jāgradbījajāgrattaducyate
]

`v 15 [
eṣā jñapternavāvasthā tvaṃ jāgratsaṃsṛtiṃ śṛṇu |
navaprasūtasya parādayaṃ cāhamidaṃ mama
]

`v 16 [
iti yaḥ pratyayaḥ svasthastajjāgratprāgabhāvanāt |
ayaṃ so'hamidaṃ tanma iti janmāntaroditaḥ
]

`v 17 [
pīvaraḥ pratyayaḥ prokto mahājāgraditi sphuran |
arūḍhamatha vā rūḍhaṃ sarvathā tanmayātmakam
]

`v 18 [
yajjāgrato manorājyaṃ jāgratsvapnaḥ sa ucyate |
dvicandraśuktikārūpyamṛgatṛṣṇādibhedataḥ
]

`v 19 [
dvicandraśuktirūpyādibhrāntayo'pi jāgratsvapnabhedā evetyāha - dvicandreti |
18 |
abhyāsātprāpya jāgrattvaṃ svapno'nekavidho bhavet |
alpakālaṃ mayā dṛṣṭamevaṃ no satyamityapi
]

`v 20 [
nidrākālānubhūte'rthe nidrānte pratyayo hi yaḥ |
sa svapnaḥ kathitastasya mahājāgratsthiterhṛdi
]

`v 21 [
cirasaṃdarśanābhāvādapraphullabṛhadvapuḥ |
svapno jāgrattayā rūḍho mahājāgratpadaṃ gataḥ
]

`v 22 [
akṣatevākṣate dehe svapnajāgranmataṃ hi tat |
ṣaḍavasthāparityāge jaḍā jīvasya yā sthitiḥ
]

`v 23 [
p. 402) 237
bhaviṣyadduḥkhabodhāḍhyā sauṣuptī socyate gatiḥ |
ete tasyāmavasthāyāṃ tṛṇaloṣṭaśilādayaḥ
]

`v 24 [
padārthāḥ saṃsthitāḥ sarve paramāṇupramāṇinaḥ |
saptāvasthā iti proktā mayā'jñānasya rāghava
]

`v 25 [
ekaikā śataśākhātra nānāvibhavarūpiṇī |
jāgratsvapnaściraṃ rūḍho jāgṛtāveva gacchati
]

`v 26 [
nānāpadārthabhedena savikāsaṃ vijṛmbhate |
asyāmapyudare santi mahājāgraddaśādṛśaḥ
]

`v 27 [
tāsāmapyantare loko mohānmohāntaraṃ vrajet |
antaḥpātijalāvarta iva dhāvati naurbhramam
]

`v 28 [
loko janaḥ jīva iti yāvat | nadyantaḥpātijalāvarte nauriva bhramaṃ dhāvati gacchati |
27 |
kāścitsaṃsṛtayo dīrghaṃ svapnajāgrattayā sthitāḥ |
kāścitpunaḥ svapnajāgrajjāgratsvapnāstathetarāḥ
]

`v 29 [
ajñānabhūmiriti saptapadā mayoktā
nānāvikārajagadantaramedahīnā |
asyāḥ samuttarasi cāruvicāraṇābhi-
rdṛṣṭe prabodhavimale svayamātmanīti
]