`v 1 [
ekonāśītitamaḥ sargaḥ 79
śrīvasiṣṭha uvāca |
ityuktvā rākṣasī praśnānsā vaktumupacakrame |
ucyatāmiti rājñokte tānimānśṛṇu rāghava
]

`v 2 [
rākṣasyuvāca |
ekasyānekasaṃkhyasya kasyāṇorambudheriva |
antarbrahmāṇḍalakṣāṇi līyante budbudā iva
]

`v 3 [
kimākāśamanākāśaṃ na kiṃcitkiṃcideva kim |
ko'hamevāsi saṃpannaḥ ko bhavānapyahaṃ sthitaḥ
]

`v 4 [
anākāśamaśūnyam | laukikaprasiddhaṃ na kiṃcittattvavitprasiddhaṃ kiṃcideva | 3
|
gacchanna gacchati ca kaḥ ko'tiṣṭhannapi tiṣṭhati |
kaścetano'pi pāṣāṇaḥ kaścidvyomni vicitrakṛt
]

`v 5 [
vahnitāmajahaccaiva kaśca vahniradāhakaḥ |
avahnerjāyate vahniḥ kasmādrājannirantaram
]

`v 6 [
acandrārkāgnitāro'pi ko'vināśaḥ prakāśakaḥ |
anetralabhyātkasmācca prakāśaḥ saṃpravartate
]

`v 7 [
latāgulpāṅkurādīnāṃ jātyandhānāṃ tathaiva ca |
anyeṣāmapyanakṣāṇāmālokaḥ ka ivottamaḥ
]

`v 8 [
janakaḥ ko'mbarādīnāṃ sattāyāḥ kaḥ svabhāvadaḥ |
ko jagadratnakośaḥ syātkasya kośo maṇerjagat
]

`v 9 [
ko'ṇustamaḥprakāśaḥ syātko'ṇurasti ca nāsti ca |
ko'ṇurdūre'pyadūre ca ko'ṇureva mahāgiriḥ
]

`v 10 [
nimeṣa eva kaḥ kalpaḥ kaḥ kalpo'pi nimeṣakaḥ |
kiṃ pratyakṣamasadrūpaṃ kiṃ cetanamacetanam
]

`v 11 [
kaśca vāyuravāyuśca kaḥ śabdo'śabda eva kaḥ |
kaḥ sarvaṃ na ca kiṃcicca ko'haṃ nāhaṃ ca kiṃ bhavet
]

`v 12 [
kiṃ prayatnaśataprāpyaṃ labdhvāpi bahujanmani |
labdhaṃ na kiṃcidbhavati kiṃtu sarvaṃ na labhyate
]

`v 13 [
svasthena jīvitenoccaiḥ kenātmaivāpahāritaḥ |
kenāṇunāntaḥ kriyate merustribhuvanaṃ tṛṇam
]

`v 14 [
kenāpyaṇukamātreṇa pūritā śatayojanī |
ko'ṇureva bhavanmāti na yojanaśateṣvapi
]

`v 15 [
kenālokanamātreṇa jagadbālaḥ pranāṭyate |
kasyāṇorudare santi kilāvanibhṛtāṃ ghaṭāḥ
]

`v 16 [
aṇutvamajahatko'ṇurmeroḥ sthūlatarākṛtiḥ |
vālāgraśatabhāgātmā ko'ṇuruccaiḥ śiloccayaḥ
]

`v 17 [
p. 319) 193
ko'ṇu prakāśatamasāṃ dīpaḥ prakaṭanapradaḥ |
kasyāṇorudare santi samagrānubhavāṇavaḥ
]

`v 18 [
ko'ṇuratyantaniḥsvādurapi saṃsvadate'niśam |
kena saṃtyajatā sarvamaṇunā sarvamāśritam
]

`v 19 [
kenātmācchādanāśaktenāṇunācchāditaṃ jagat |
jagallaye na kasyāṇoḥ sadbhūtamapi jīvati
]

`v 20 [
ajātāvayavaḥ ko'ṇuḥ sahasrakaralocanaḥ |
ko nimeṣo mahākalpaḥ kalpakoṭiśatāni ca
]

`v 21 [
aṇau jaganti tiṣṭhanti kasminbīja iva drumaḥ |
bījāni niṣkalāntāni sphuṭānyanuditānyapi
]

`v 22 [
kalpaḥ kasya nimeṣasya bījasyevāntarasthitaḥ |
kaḥ prayojanakartṛtvamapyanāśritya kārakaḥ
]

`v 23 [
dṛśyasaṃpattaye draṣṭā svātmānaṃ dṛśyatāṃ nayan |
dṛśyaṃ paśyansvamātmānaṃ ko hi paśyatyanetravān
]

`v 24 [
antargalitadṛśyaṃ ca ka ātmānamakhaṇḍitam |
dṛśyāsaṃpattaye paśyanpuro dṛśyaṃ na paśyati
]

`v 25 [
ātmānaṃ darśanaṃ dṛśyaṃ ko bhāsayati dṛśyavat |
kaṭakādīni hemneva vikīrṇaṃ kena ca trayam
]

`v 26 [
kasmānna kiṃcicca pṛthagūrmyādīva mahāmbhasaḥ |
kasyecchayā pṛthakāsti vīciteva mahāmbhasaḥ
]

`v 27 [
dikkālādyanavacchinnādekasmādasataḥ sataḥ |
dvaitamapyapṛthakkasmāddravateva mahāmbhasaḥ
]

`v 28 [
ātmānaṃ darśanaṃ dṛśyaṃ sadasacca `note[sadasacca gatakramam iti
pāṭhaḥ] jagattrayam |
ko'ntarbījamivāntasthaṃ kṛtvā trikālagaḥ
]

`v 29 [
bhūtaṃ bhavadbhaviṣyacca jagadvṛndaṃ bṛhadbhramam |
nityaṃ samasya kasyāntarbījasyāntariva drumaḥ
]

`v 30 [
bījaṃ drumatayevāśu drumo bījatayeva ca |
svamekamajahadrūpamudetyanudito'pi kaḥ
]

`v 31 [
bisatanturmahāmerurbho rājanyadapekṣayā |
tasya kasyodare santi merumandarakoṭayaḥ
]

`v 32 [
kenedamātatamanekacideva viśvaṃ
kiṃsāra evamativalgasi haṃsi pāsi |
kiṃdarśanena na bhavasyathavā sadaiva
nūnaṃ bhavasyamaladṛgvadanaḥ svaśāntyai
]

`v 33 [
eṣo'sau pragalatu saṃśayo mamoccai-
ścittaśrīmukhamihikāmalānulepaḥ |
yasyāgre na galati saṃśayaḥ samūlo
naivāsau kvacidapi paṇḍitoktimeti
]

`v 34 [
evaṃ me yadi na vineṣyathaḥ kramoktaṃ
saṃśāntaṃ laghutarasaṃśayaṃ `note[masaṃśayaṃ iti kvacit] subuddhī |
tadrakṣojaraṭhahutāśanendhanatvaṃ
nirvighnaṃ jhaṭiti gamiṣyathaḥ kṣaṇena
]

`v 35 [
paścāttāṃ janapadamaṇḍalīṃ samantā-
dbhāvatkīmurujaṭharā kṣaṇādgrase'ham |
evaṃ te bhavatu surājateti manye
mūrkhāṇāmatirasa eva saṃkṣayāya
]

`v 36 [
p. 320) 194
ityuktvā vipulagabhīrameghanāda-
prollāsaprakaṭagirā niśācarī sā |
tūṣṇīmapyativikaṭākṛtistadāsī-
cchuddhāntaḥ śaradamalābhramaṇḍalīva
]