`v 1 [
p. 136)
caturthaḥ sargaḥ 4
śrīvālmīkiruvāca |
kathayatyevamuddāmavacane munināyake |
śrotumekarase jāte jane maunmupasthite
]

`v 2 [
śānteṣu kiṅkiṇījālaraveṣu spandanaṃ vinā |
pañjarāntarahārītaśukeṣvapyastakeliṣu
]

`v 3 [
ekarasatāmeva liṅgairdarśayati - śānteṣvityādinā | hārītāḥ pakṣiviśeṣāḥ |
2 |
suvismṛtavilāsāsu sthitāsu lalanāsvapi |
citabhittāviva nyaste samaste rājasadmani
]

`v 4 [
muhūrtaśeṣamabhavaddivasaṃ madhurātapam |
vyavahārā ravikaraiḥ saha tānavamāyayuḥ
]

`v 5 [
vavurutphullakamalaprakarāmodamāṃsalāḥ |
vāyavo madhuraspandāḥ śravaṇārthamivāgatāḥ
]

`v 6 [
śrutaṃ cintayituṃ bhānurivāhoracanābhramam |
tatyājaikāntamagamacchūnyamastagirestaṭam
]

`v 7 [
uttasthurmihikārambhasamatā vanabhūmiṣu |
vijñānaśravaṇādantaḥśītalāḥ śāntatā iva
]

`v 8 [
babhūvuralpasaṃcārā janā daśasu dikṣvapi |
sāvadhānatayā śrotumiva saṃtyaktaceṣṭitāḥ
]

`v 9 [
chāyā dīrghatvamājagmurvāsiṣṭhaṃ vacanakramam |
iva śrotumaśeṣāṇāṃ vastūnāṃ dīrghakandharāḥ
]

`v 10 [
pratīhāraḥ puraḥ prahvo bhūtvāha vasudhādhipam |
deva snānadvijārcāsu kālo vyatigato bhṛśam
]

`v 11 [
tato vasiṣṭho bhagavānsaṃhṛtya madhurāṃ giram |
adya tāvanmahārāja śrutametāvadastu vaḥ
]

`v 12 [
prātaranyadvadiṣyāmi ityuktvā maunavānabhūt |
ityākarṇaivamastūktvā bhūpatirbhūtivṛddhaye
]

`v 13 [
puṣpapādyārghasanmānadakṣiṇādānapūjayā |
sadevarṣimunīnviprānpūjayāmāsa sādaram
]

`v 14 [
athottasthau sabhā sarvā sarājamunimaṇḍalā |
maṇḍalākīrṇaratnaughapariveṣāvṛtānanā
]

`v 15 [
parasparāṅgasaṃghaṭṭaraṇatkeyūrakaṅkaṇā |
hārabhārāhṛtasvarṇapaṭṭābhorustanāntarā
]

`v 16 [
śekharotsaṅgaviśrāntaprabuddhamadhupasvanaiḥ |
saghuṃghumaśirobhārā vadadbhiriva mūrdhajaiḥ
]

`v 17 [
kāñcanābharaṇoddyotakanakīkṛtadiṅmukhāḥ |
buddhisthamunivāgarthasaṃśāntendriyavṛttayaḥ
]

`v 18 [
jagmurnabhaścarā vyoma bhūcarā bhūmimaṇḍalam |
cakrurdinasamācāraṃ sarve te sveṣu sadmasu
]

`v 19 [
etasminnantare śyāmā yāminī samadṛśyata |
janasaṅgādvinirmuktā `note[janasaṅghāt iti pāṭhaḥ] gṛhe
bālāṅganā yathā
]

`v 20 [
deśāntaraṃ bhāsayituṃ yayau divasanāyakaḥ |
sarvatrālokakartṛtvameva satpuruṣavratam
]

`v 21 [
udabhūdabhitaḥ saṃdhyā tārānikaradhāriṇī |
utphullakiṃśukavanā vasantaśrīrivoditā
]

`v 22 [
cūtanīpakadambāgragrāmacaityagṛhodare |
nililyire khagāścitte'vadātā vṛttayo yathā
]

`v 23 [
bhānorbhāsā bhūṣitairmeghaleśaiḥ
kiṃcitkiṃcitkuṅkumacchāyayeva |
pāścāttyo'driḥ pītavāsāḥ sameghai-
stārāhāraḥ śrīyutaḥ khavaṃ sametaḥ
]

`v 24 [
p. 137)
pūjāmādāya saṃdhyāyāṃ pragatāyāṃ yathāgatam |
andhakārāḥ samuttasthurvetālā vapuṣā yathā
]

`v 25 [
avaśyāyakaṇāspandī helāvidyutapallavaḥ |
komalaḥ kumudāśaṃsī vavāvāśītalo'nilaḥ
]

`v 26 [
kalikāvikāsātkumudānyāsamantācchaṃsatyanumāpayati tacchīlaḥ |
viśeṣaṇatrayānusārādāśītalagrahaṇaṃ māndyasaurabhyayorapyupalakṣaṇam | 25
|
paramāndhyamupājagmurdiśo'visphuṭatārakāḥ |
lambadīrghatamaḥkeśyo vidhavā iva yoṣitaḥ
]

`v 27 [
āyayau bhuvanaṃ tejaḥ kṣīrapūreṇa pūrayan |
rasāyanamayākāraḥ śaśikṣīrārṇavo `note[kṣīrārṇavopamaḥ iti
pāṭhaḥ] nabhaḥ
]

`v 28 [
tejolakṣaṇena dugdhapravāheṇa pūrayan | rasāyanamamṛtaṃ tanmayākāraḥ | 27
|
jagmustimirasaṃghātāḥ palāyya kvāpyadṛśyatām |
śrutajñānagiraścittānmahīpānāmivājñatāḥ
]

`v 29 [
ṛṣayo bhūmipālāśca munayo brāhmaṇāstathā |
cetasīva vicitrārthāḥ svāspadeṣu viśaśramuḥ
]

`v 30 [
yamakāyopamāśyāmā yayau timiramāṃsalā |
āyayau mihikāsphārā tatra teṣāmuṣaḥ śanaiḥ
]

`v 31 [
antardhānamupājagmustārā nabhasi bhāsurāḥ |
prabhātapavaneneva hṛtāḥ kusumavṛṣṭayaḥ
]

`v 32 [
hṛtā apanītāḥ | kusumavṛṣṭayo vṛṣṭinipatitakusumānīvetyatra tātparyam | 31
|
dṛśyatāmājagāmārkaḥ prabhonmīlitalocanaḥ |
vivekavṛttirmahatāṃ manasīva navoditā
]

`v 33 [
bhānorbhāsā bhūṣitairmeghaleśaiḥ
kiṃcitkiṃcitkuṅkumacchāyayeva |
pūrvakṣmābhṛtpītavāsāḥ sameghai-`note[stamoghnaiḥ iti pāṭhaḥ]
stārāhāraḥ śrīyutaḥ khaṃ sametaḥ
]

`v 34 [
sabhāṃ punarupājagmurnabhaścaramahīcarāḥ |
hyastanena krameṇaiva kṛtaprātastanakramāḥ
]

`v 35 [
pūrvavatsaṃniveśena viveśa sakalā sabhā |
babhūvāspanditākārā vātamukteva padminī
]

`v 36 [
atha prasaṅgamāsādya rāmo madhurayā girā |
uvāca muniśārdūlaṃ vasiṣṭhaṃ vadatāṃ varam
]

`v 37 [
śrīrāma uvāca |
bhagavanmanaso rūpaṃ kīdṛśaṃ vada me sphuṭam |
yasmātteneyamakhilā tanyate lokamañjarī
]

`v 38 [
śrīvasiṣṭha uvāca |
rāmāsya manaso rūpaṃ na kiṃcidapi dṛśyate |
nāmamātrādṛte vyomno yathā śūnyajaḍākṛteḥ
]

`v 39 [
na bāhye nāpi hṛdaye sadrūpaṃ vidyate manaḥ |
sarvatraiva sthitaṃ caitadviddhi rāma yathā nabhaḥ
]

`v 40 [
idamasmātsamutpannaṃ mṛgatṛṣṇāmbusaṃnibham |
rūpaṃ tu kṣaṇasaṃkalpāddvitīyendubhramopamam
]

`v 41 [
madhye yadetadarthasya pratibhānaṃ prathāṃ gatam |
sato vāpyasato vāpi tanmano viddhi netarat
]

`v 42 [
yadarthapratibhānaṃ tanmana ityabhidhīyate |
anyatra kiṃcidapyasti mano nāma kadācana
]

`v 43 [
saṃkalpanaṃ mano viddhi saṃkalpāttatra bhidyate |
yathā dravatvātsalilaṃ tathā spando yathānilāt
]

`v 44 [
yatra saṃkalpanaṃ tatra tanmano'ṅga tathā sthitam |
saṃkalpamanasī bhinne na kadācana kecana
]

`v 45 [
satyamastvathavā'satyaṃ padārthapratibhāsanam |
tāvanmātraṃ mano viddhi tadbrahmaiva pitāmahaḥ
]

`v 46 [
p. 138)
ātivāhikadehātmā mana ityabhidhīyate |
ādhibhautikabuddhiṃ tu sa ādhatte cirasthiteḥ
]

`v 47 [
avidyā saṃsṛtiścittaṃ mano bandho malastamaḥ |
iti paryāyanāmāni dṛśyasya viduruttamāḥ
]

`v 48 [
nahi dṛśyādṛte kiṃcinmanaso rūpamasti hi |
dṛśyaṃ cotpannamevaitanneti vakṣyāmyahaṃ punaḥ
]

`v 49 [
yathā kamalabījāntaḥ sthitā kamalavallarī |
mahācitparamāṇvantastathā dṛśyaṃ jagatsthitam
]

`v 50 [
prakāśasya yathā'loko yathā vātasya cāpalam |
yathā dravatvaṃ payasi dṛśyatvaṃ draṣṭarīdṛśam
]

`v 51 [
aṅgadatvaṃ yathā hemni mṛganadyāṃ yathā jalam |
bhittiryathā svapnapure tathā draṣṭari dṛśyadhīḥ
]

`v 52 [
evaṃ draṣṭari dṛśyatvamananyadiva yatsthitam |
tadapyunmārjayāmyāśu tvaccittādarśato malam
]

`v 53 [
yaddraṣṭurasyādraṣṭṛtvaṃ dṛśyābhāve bhavedbalāt |
tadviddhi kevalībhāvaṃ tata evāsataḥ sataḥ
]

`v 54 [
tattāmupagate bhāve rāgadveṣādivāsanāḥ |
śāmyantyaspandite vāte spandanakṣubdhatā yathā
]

`v 55 [
asaṃbhavati sarvasmindigbhūmyākāśarūpiṇi |
prakāśye yādṛśaṃ rūpaṃ prakāśasyāmalaṃ bhavet
]

`v 56 [
trijagattvamahaṃ ceti dṛśye'sattāmupāgate |
draṣṭuḥ syātkevalībhāvastādṛśo vimalātmanaḥ
]

`v 57 [
anāptākhilaśailādi pratibimbe hi yādṛśī |
syāddarpaṇe darpaṇatā kevalātmasvarūpiṇī
]

`v 58 [
ahaṃ tvaṃ jagadityādau praśānte dṛśyasaṃbhrame |
syāttādṛśī kevalatā sthite draṣṭaryavīkṣaṇe
]

`v 59 [
śrīrāma uvāca |
saccenna śāmyatyevedaṃ nābhāvo vidyate sataḥ |
asattāṃ ca na vidmo'smindṛśye doṣapradāyini
]

`v 60 [
tasmātkathamiyaṃ śāmyedbrahmandṛśyaviṣūcikā |
manobhavabhramakarī duḥkhasaṃtatidāyinī
]

`v 61 [
śrīvasiṣṭha uvāca |
asya dṛśyapiśācasya śāntyai mantramimaṃ śṛṇu |
rāmātyantamayaṃ yena mṛtimeṣyati naṅkṣyati
]

`v 62 [
yadasti tasya nāśo'sti na kadācana rāghava |
tasmāttannaṣṭamapyantarbījabhūtaṃ `note[bījarūpaṃ iti pāṭhaḥ]
bhaveddhṛdi
]

`v 63 [
smṛtibījāccidākāśe punarudbhūya dṛśyadhīḥ |
lokaśailāmbarākāraṃ doṣaṃ vitanute'tanum
]

`v 64 [
smṛtigrahaṇaṃ bhogopayuktāntaḥkaraṇavṛttipramukhajaganmātropalakṣaṇam |
63 |
ityanirmokṣadoṣaḥ syānna ca tasyeha saṃbhavaḥ |
yasmāddevarṣimunayo dṛśyante muktibhājanam
]

`v 65 [
yadi syājjagadādīdaṃ tasmānmokṣo na kasyacit |
bāhyasthamastu hṛtsthaṃ vā dṛśyaṃ nāśāya kevalam
]

`v 66 [
p. 139)
tasmādimāṃ pratijñāṃ tvaṃ śṛṇu rāmātibhīṣaṇām |
yāmuttareṇa granthena nūnaṃ tvamavabudhyase
]

`v 67 [
ayamākāśabhūtādirūpo'haṃ ceti lakṣitaḥ |
jagacchabdasya nāmārtho nanu nāstyeva kaścana
]

`v 68 [
yadidaṃ dṛśyate kiṃciddṛśyajātaṃ purogatam |
paraṃ brahmaiva tatsarvamajarāmaramavyayam
]

`v 69 [
pūrṇe pūrṇaṃ prasarati śānte śāntaṃ `note[paraṃ sthitaṃ iti pāṭhaḥ]
vyavasthitam |
vyomanyevoditaṃ vyoma brahmaṇi brahma tiṣṭhati
]

`v 70 [
na dṛśyamasti sadrūpaṃ na draṣṭā na ca darśanam |
na śūnyaṃ na jaḍaṃ no cicchāntamevedamātatam
]

`v 71 [
śrīrāma uvāca |
vandhyāputreṇa piṣṭo'driḥ śaśaśṛṅgaṃ pragāyati |
prasārya bhujasaṃpātaṃ śilā nṛtyati tāṇḍavam
]

`v 72 [
sravanti sikatāstailaṃ paṭhantyupalaputrikāḥ |
garjanti citrajaladā itīvedaṃ vacaḥ prabho
]

`v 73 [
jarāmaraṇaduḥkhādiśailākāśamayaṃ jagat |
nāstīti kimidaṃ nāma bhavatā'pi mamocyate
]

`v 74 [
yathedaṃ na sthitaṃ viśvaṃ notpannaṃ na ca vidyate |
tathā kathaya me brahmanyenaitanniścitaṃ bhavet
]

`v 75 [
śrīvasiṣṭha uvāca |
nāsamanvitavāgasmi śṛṇu rāghava kathyate |
yathedamasadābhāti vandhyāputra ivā'ravī
]

`v 76 [
idamādāvanutpannaṃ sargādau tena nāstyalam |
idaṃ hi manaso bhāti svapnādau pattanaṃ yathā
]

`v 77 [
mana eva ca sargādāvanutpannamasadvapuḥ |
tadetacchṛṇu vakṣyāmi yathaivamanubhūyate
]

`v 78 [
manodṛśyamayaṃ doṣaṃ tanotīmaṃ kṣayātmakam |
asadeva sadākāraṃ svapnaḥ svapnāntaraṃ yathā
]

`v 79 [
tatsvayaṃ svairamevāśu saṃkalpayati dehakam |
teneyamindrajālaśrīrvitatena vitanyate
]

`v 80 [
sphurati valgati gacchati yācate
bhramati majjati saṃharati svayam |
aparatāmupayātyapi kevalaṃ
calati cañcalaśaktitayā manaḥ
]