`v 1 [
saptaviṃśaḥ sargaḥ 27
śrīvasiṣṭha uvāca |
tasmin giritaṭe grāme tasya maṇḍapakoṭare |
antardhimāśvāyayatustatrasthe `note[antardhimāpaturdṛṅgā tataste
siddhayoṣitau iti pāṭhaḥ] eva te striyau
]

`v 2 [
asmākaṃ vanadevībhyāṃ prasādaḥ kṛta ityatha |
śāntaduḥkhe gṛhajane svavyāpārapare `note[parasthite iti pāṭhaḥ]
sthite
]

`v 3 [
maṇḍapākāśasaṃlīnāṃ līlāmāha sarasvatī |
vyomarūpā vyomarūpāṃ smayāttūṣṇīmiva `note[tūṣṇīṃ vyavasthitām iti
pāṭhaḥ] sthitām
]

`v 4 [
saṃkalpasvapnayoryeṣāṃ yatra saṃkathanaṃ mithaḥ |
yathehārthakriyāṃ dhatte tayoḥ sā saṃkathā tathā
]

`v 5 [
pṛthvyādināḍīprāṇādi-ṛte'pyabhyuditā tayoḥ |
sā saṃkathanasaṃvittiḥ svapnasaṃkalpayoriva
]

`v 6 [
śrīsarasvatyuvāca |
jñeyaṃ jñātamaśeṣeṇa dṛṣṭādṛṣṭārthasaṃvidaḥ
`note[draṣṭavyasaṃvidaḥ iti pāṭhaḥ] |
īdṛśīyaṃ brahmasattā kimanyadvada pṛcchasi
]

`v 7 [
līlovāca |
mṛtasya bharturjīvo'sau yatra rājyaṃ karoti me |
tatrāhaṃ kiṃ na terdṛṣṭā dṛṣṭāsmīha sutena kim
]

`v 8 [
śrīsarasvatyuvāca |
abhyāsena vinā vatse tadā te dvaitaniścayaḥ |
nūnamastaṃgato nābhūnniḥśeṣaṃ varavarṇini
]

`v 9 [
advaitaṃ yo na yāto'sau kathamadvaitakarmabhiḥ |
yujyate tāpasaṃsthasya cchāyāṅgānubhavaḥ kutaḥ
]

`v 10 [
līlāsmīti vinābhyāsaṃ tava nāstagato'bhavat |
yadā bhāvastadā satyasaṃkalpatvamabhūnna te
]

`v 11 [
adyāsi satyasaṃkalpā saṃpannā tena māṃ sutaḥ |
saṃpaśyatvityabhimataṃ phalitaṃ tava sundari
]

`v 12 [
p. 195)
idānīṃ tasya bhartustvaṃ samīpaṃ yadi gacchasi |
tattena vyavahāraste pūrvavatsaṃpravartate
]

`v 13 [
līlovāca |
ihaiva mandirākāśe patirvipro mamābhavat |
ihaiva sa mṛto bhūtvā saṃpanno vasudhādhipaḥ
]

`v 14 [
ihaiva tasya saṃsāre tasminbhūmaṇḍalāntare |
rājadhānīpure tasminpurandhryasmi `note[purato'sminvyavasthitā iti
pāṭhaḥ] vyavasthitā
]

`v 15 [
ihaivāntaḥpure tasminsa mṛto mama bhūpatiḥ |
ihaivāntaḥpurākāśe tasminneva pure nṛpaḥ
]

`v 16 [
saṃpanno vasudhāpīṭhe nānājanapadeśvaraḥ |
sarvārjavajavībhāva ihaivaivaṃ vyavasthitaḥ
]

`v 17 [
asminneva gṛhākāśe sarvā brahmāṇḍabhūmayaḥ |
sthitāḥ samudrake manye yathāntaḥ sarṣapotkarāḥ
]

`v 18 [
sadā'dūramahaṃ manye tadbhrturmama maṇḍalam |
kvacitpārśve sthitamiha yathā paśyāmi tatkuru
]

`v 19 [
śrīdevyuvāca |
bhūtalārundhatisute bhartārastava saṃprati |
trayo nāmāthavābhūvanbahavaḥ śatasaṃmatāḥ
]

`v 20 [
na kevalaṃ sāṃpratikamevaitanmaṇḍapākāśe asti kiṃtvatītānāgataṃ sarvamapi
tatra te'nekajanmasaṃbandhiṣvanekabhartṛśabdavācyaśarīreṣu sarveṣāṃ
darśanāyogātsaṃnihiteṣu triṣu katamamaṇḍalaṃ pradarśyatāmityāśayenāha ##-
nedīyasāṃ trayāṇāṃ tu dvijaste bhasmatāṃ gataḥ |
rājā mālyāntaragataḥ saṃsthito'ntaḥpure śavaḥ
]

`v 21 [
saṃsāramaṇḍale hyasmiṃstṛtīyo vasudhādhipaḥ |
mahāsaṃsārajaladhiṃ patito bhramamāgataḥ
]

`v 22 [
bhogakallolakalanāvikalo malacetanaḥ |
jāḍyajarjaracidvṛttiḥ saṃsārāmbhodhikacchapaḥ
]

`v 23 [
citrāṇi rājakāryāṇi kurvannapyākulānyapi |
suptaḥ sthito jaḍatayā na jāgarti bhavabhrame
]

`v 24 [
īśvaro'hamahaṃ bhogī siddho'haṃ balavānsukhī |
ityanarthamahārajjvā valito vaśatāṃ gataḥ
]

`v 25 [
tatkasya vada bhartustvāṃ samīpaṃ varavarṇini |
vātyā vanāntaraṃ gandhalekhāmiva vanānnaye
]

`v 26 [
anya eva hi saṃsāraḥ so'nyo brahmāṇḍamaṇḍapaḥ |
anyā eva tatā vatse vyavahāraparamparāḥ
]

`v 27 [
saṃsāramaṇḍalānīha tāni pārśve sthitānyapi |
dūraṃ yojanakoṭīnāṃ koṭayasteṣvihāntaram
]

`v 28 [
ākāśamātrameteṣāmidaṃ paśya vapuḥ `note[punaḥ punaḥ iti pāṭhaḥ]
punaḥ |
merumandarakoṭīnāṃ koṭayasteṣvavasthitāḥ
]

`v 29 [
paramāṇau paramāṇau sarvavargānirargalam |
mahāciteḥ sphurantyarkarucīva trasareṇavaḥ
]

`v 30 [
mahārambhagurūṇyevamapi brahmāṇḍakāni hi |
tulayā dhānakāmātramapi tāni bhavanti no
]

`v 31 [
nānāratnāmaloddyoto vanavadbhāti khe yathā |
pṛthvyādibhūtarahitā jagaccidbhāti cintayā
]

`v 32 [
kacati jñaptirevedaṃ jagadityādi nātmani |
natu pṛthvyādi saṃpannaṃ sargādāveva kiṃcana
]

`v 33 [
yathā taraṅgaḥ sarasi bhūtvā bhūtvā punarbhavet |
vicitrākārakālāṅgadeśājñaptāvalaṃ tathā
]

`v 34 [
līlovāca |
evametajjaganmātarmayā smṛtamihādhunā |
mamedaṃ rājasaṃ janma na tamo na ca sāttvikam
]

`v 35 [
p. 196)
brahmaṇastvavatīrṇāyā aṣṭau janmaśatāni me |
nānāyonīnvatītāni paśyāmīvādhunā punaḥ
]

`v 36 [
saṃsāramaṇḍale devi kasmiṃścidabhavaṃ purā |
lokāntarābjabhramarī vidyādharavarāṅganā
]

`v 37 [
durvāsanākaluṣitā tato'haṃ mānuṣī sthitā |
saṃsāramaṇḍale'nyasminpannageśvarakāminī
]

`v 38 [
kadambakundajambīrakarañjavanavāsinī |
patrāmbaradharā śyāmā śavaryahamathābhavam
]

`v 39 [
vanavāsanayā mugdhā saṃpannāhamathoddhatā |
gulucchanayanā patrahastā vanavilāsinī
]

`v 40 [
puṇyāśramalatā sāhaṃ munisaṅgapavitritā |
vanāgnidagdhā tasyaiva kanyābhūvaṃ mahāmuneḥ
]

`v 41 [
astrītvaphaladātṝṇāṃ karmaṇāṃ pariṇāmataḥ |
rājāhamabhavaṃ śrīmānsurāṣṭreṣu samā śatam
]

`v 42 [
tālīnāṃ talakaccheṣu rājaduṣkṛtadoṣataḥ |
nakulī navavarṣāṇi kuṣṭhanaṣṭāṅgikābhavam
]

`v 43 [
varṣāṇyaṣṭau surāṣṭreṣu devi gotvaṃ kṛtaṃ mayā |
mohāddurjanaduṣṭājñabālagopālalīlayā
]

`v 44 [
vihaṃgyā vairavinyastā vāgurā vipināvanau |
kleśena mahatā cchinnā adhamā vāsanā iva
]

`v 45 [
karṇikākroḍaśayāsu viśrāntamalinā saha |
padmakuḍmalakośeṣu bhuktakiṃjalkayā rahaḥ
]

`v 46 [
bhrāntamuttuṅgaśṛṅgāsu hariṇyā hārinetrayā |
vanasthalīṣu ramyāsu kirātāhatamarmayā
]

`v 47 [
dṛṣṭaṃ naṣṭāsu dikṣvabdhikallolairuhyamānayā |
matsyāmbukacchapācchoḍe moghamānanatāḍanam
]

`v 48 [
pītaṃ carmaṇvatītīre gāyantyā madhurasvaram |
pulindyā `note[pulindasuratānteṣu iti pāṭhastatra pulindyetyarthaḥ]
suratānteṣu nālikerarasāsavam
]

`v 49 [
sārasīsarasālinyā `note[sarasī iti pāṭhaḥ] sītkāramadhurasvaram |
sārasaḥ surataiḥ svairaṃ sāmantaścārurañjitaḥ
]

`v 50 [
tālītamālakuñjeṣu taralānananetrayā |
kṣībaprekṣaṇavikṣobhaiḥ kṛtaṃ kāntāvalokanam
]

`v 51 [
kanakasyandasaṃdohasundarairaṅgapañjaraiḥ |
svarge'psarombujinyāśu toṣitāḥ suraṣaṭpadāḥ
]

`v 52 [
maṇikāñcanamāṇikyamuktānikarabhūtale |
kalpadrumavane merau yūnā saha rataṃ kṛtam
]

`v 53 [
kallolākulakacchāsu lasadgucchalatāsu ca |
velāvanaguhāsvabdheściraṃ kūrmatayā sthitam
]

`v 54 [
tarattārataṅgāsu dolanaṃ sarasālinām |
calacchadapaṭālīṣu rājahaṃsyaṃ mayā kṛtam
]

`v 55 [
śālmalīdalalolānāmāndolanadaridratām |
maśakasya mayālokya dīnaṃ maśakayā sthitam
]

`v 56 [
p. 197)
tarattārataraṅgāsu cañcadvīcyagracimbanaiḥ |
bhrāntaṃ śailasravantīṣu jalavañjulalīlayā
]

`v 57 [
gandhamādanamandāramandire madanāturāḥ |
pātitāḥ pādayoḥ pūrvaṃ vidyādharakumārakāḥ
]

`v 58 [
sthāvarāntādhamayonijanmānyuktvottamajanmānyapyāha - gandhamādaneti |
57 |
kīrṇakarpūrapūreṣu talpeṣu vyasanāturā |
ciraṃ vilulitāsmīndubimbeṣviva śaśiprabhā
]

`v 59 [
yoniṣvanekavidhaduḥkhaśatānvitāsu
bhrāntaṃ mayonnamanasannamanākulāṅgyā |
saṃsāradīrghasaritaścalayā laharyā
durvāravātahariṇīsaraṇakrameṇa
]