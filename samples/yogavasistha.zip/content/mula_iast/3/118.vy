`v 1 [
aṣṭādaśottaraśatatamaḥ sargaḥ 118
śrīvasiṣṭha uvāca |
imāṃ saptapadāṃ jñānabhūmimākarṇayānagha |
nānayā jñātayā bhūyo mohapaṅke nimajjasi
]

`v 2 [
vadanti bahubhedena vādino yogabhūmikāḥ |
mama tvabhimatā nūnamimā eva śubhapradāḥ
]

`v 3 [
avabodhaṃ vidurjñānaṃ tadidaṃ saptabhūmikam |
muktistu jñeyamityuktaṃ bhūmikāsaptakātparam
]

`v 4 [
satyāvabodho mokṣaścaiveti paryāyanāmanī |
satyāvabodho jīvo'yaṃ neha bhūyaḥ prarohati
]

`v 5 [
jñānabhūmiḥ śubhecchākhyā prathamā samudāhṛtā |
vicāraṇā dvitīyā tu `note[bhaviṣyaduḥkheti mudritapustake pāṭhaḥ]
tṛtīyā tanumānasā
]

`v 6 [
sattvāpattiścaturthī syāttato'saṃsaktināmikā |
padārthābhāvanī ṣaṣṭhī saptamī turyagā smṛtā
]

`v 7 [
āsāmante sthitā muktistasyāṃ bhūyo na śocyate |
etāsāṃ bhūmikānāṃ tvamidaṃ nirvacanaṃ śṛṇu
]

`v 8 [
sthitaḥ kiṃ mūḍha evāsmi prekṣye'haṃ śāstrasajjanaiḥ |
vairāgyapūrvamiccheti śubhecchetyucyate budhaiḥ
]

`v 9 [
śāstrasajjanasaṃparkavairāgyābhyāsapūrvakam |
sadācārapravṛttiryā procyate sā vicāraṇā
]

`v 10 [
p. 403) 237
vicāraṇāśubhecchābhyāmindriyārtheṣvasaktatā |
yātra sā tanutā bhāvātprocyate tanumānasā
]

`v 11 [
bhūmikātritayābhyāsāccitte'rthe viratervaśāt |
satyātmani sthitiḥ śuddhe sattvāpattirudāhṛtā
]

`v 12 [
daśācatuṣṭayābhyāsādasaṃsaṅgaphalena ca |
rūḍhasattvacamatkārātproktā'saṃsaktināmikā
]

`v 13 [
bhūmikāpañcakābhyāsātsvātmārāmatayā dṛḍham |
ābhyantarāṇāṃ bāhyānāṃ padārthānāmabhāvanāt
]

`v 14 [
paraprayuktena ciraṃ prayatnenārthabhāvanāt |
padārthābhāvanānāmnī ṣaṣṭhī saṃjāyate gatiḥ
]

`v 15 [
bhūmiṣaṭkacirābhyāsādbhedasyānupalambhataḥ |
yatsvabhāvaikaniṣṭhatvaṃ sā jñeyā turyagā gatiḥ
]

`v 16 [
eṣā hi jīvanmukteṣu turyāvastheha vidyate |
videhamuktiviṣayasturyātītamataḥ param
]

`v 17 [
ye hi rāma mahābhāgāḥ saptamīṃ bhūmikāṃ gatāḥ |
ātmārāmā mahātmānaste mahatpadamāgatāḥ
]

`v 18 [
jīvanmuktā na sajjanti sukhaduḥkharasasthitau |
prakṛtenārthakāryāṇi kiṃcitkurvanti vā na vā
]

`v 19 [
pārśvasthabodhitāḥ santaḥ sarvācārakramāgatam |
ācāramācarantyeva suprabuddhavadakṣatam
]

`v 20 [
kurvanti vā navetyukteryatheṣṭācāraparatvāśaṅkāṃ vārayan svāśayaṃ
prakaṭayati - pārśvastheti | sarveṣāṃ
tattadāśramaniṣṭhānāmācārakrameṇāgatamācāraṃ sadācāramevācaranti
ācarantyeveti dvividho'pi niyamo'tra vivakṣitaḥ | akṣataṃ āsaṅgenādūṣitam |
akṣatā iti pāṭhe phalāsaktilakṣaṇakṣatarahitā ityarthaḥ | tathāca na
yatheṣṭācaraṇaprasaktiriti bhāvaḥ | tathācāhuḥ - viditabrahmatattvasya
yatheṣṭācaraṇaṃ yadi | śunāṃ tattvavidāṃ caiva ko bhedo'śucibhakṣaṇe | iti | 19
|
ātmārāmatayā tāṃstu sukhayanti na kāścana |
jagatkriyā susaṃsuptānrūpālokāḥ striyo yathā
]

`v 21 [
bhūmikāsaptakaṃ caitaddhīmatāmeva gocaram |
na paśusthāvarādīnāṃ na ca mlecchādicetasām
]

`v 22 [
prāptā jñānadaśāmetāṃ paśumlecchādayo'pi ye |
sadehā vāpyadehā vā te muktā nātra saṃśayaḥ
]

`v 23 [
jñaptirhi granthivicchedastasminsati hi muktatā |
mṛgatṛṣṇāmbubuddhyādi śāntimātrātmakastvasau
]

`v 24 [
p. 404) 238
ye tu mohātsamuttīrṇā na prāptāḥ pāvanaṃ padam |
āsthitā bhūmikāsvāsu svātmalābhaparāyaṇāḥ
]

`v 25 [
sarvabhūmigatāḥ kecitkeciddvitraikabhūmikāḥ |
bhūmiṣaṭkagatāḥ kecitkecitsaptaikabhūmikāḥ
]

`v 26 [
bhūmitrayagatāḥ kecitkecidntyāṃ bhuvaṃ gatāḥ |
bhūcatuṣṭayagāḥ kecitkecidbhūmidvaye sthitāḥ
]

`v 27 [
bhūcatuṣṭayagāḥ kecidityetadanyasya pūrvoktasyaivānuvādaḥ prapañcārthaḥ | 26
|
bhūmyaṃśabhājanāḥ kecitkecitsārdhatribhūmikāḥ |
kecitsārdhacaturbhūgāḥ sārdhaṣaḍbhūmikāḥ pare
]

`v 28 [
vivekino narā loke caranta iti bhūmiṣu |
grahāyatanatāpasya dṛśāveśeṣu saṃsthitāḥ
]

`v 29 [
te hi dhīrāḥ surājāno daśāsvāsu jayanti ye |
tṛṇāyate'tra digdantighaṭābhaṭaparājayaḥ
]

`v 30 [
ye tāsu bhūmiṣu jayanti hi ye mahānto
vandyāsta eva hi jitendriyaśatravaste |
samnāḍvirāḍapi ca yatra tṛṇāyate vai
tasmātparaṃ jagati te samavāpnuvanti
]