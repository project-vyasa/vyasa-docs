`v 1 [
pañcadaśottaraśatatamaḥ sargaḥ 115
śrīvālmīkiruvāca |
evamukto bhagavatā vasiṣṭhena mahātmanā |
rāmaḥ kamalapatrākṣa unmīlita ivābabhau
]

`v 2 [
vikāsitāntaḥkaraṇaḥ śobhāmalamupāyayau |
āśvastastamasi kṣīṇe padmo'rkālokanādiva
]

`v 3 [
bodhavismayasaṃjātasaumyasmitasitānanaḥ |
dantaraśmisudhādhautāmimāṃ vācamuvāca ha
]

`v 4 [
bodhaprayuktavismayātsaṃjātena saumyena smitena sitaṃ dhavalitamānanaṃ yasya |
3 |
śrīrāma uvāca |
aho nu citraṃ padmotthairbaddhāstantubhiradrayaḥ |
avidyamānā yā vidyā tayā sarve vaśīkṛtāḥ
]

`v 5 [
p. 397) 234
idaṃ tadvajratāṃ yātaṃ tṛṇamātraṃ jagattraye |
avidyayāpi yannāmāsadeva sadiva sthitam
]

`v 6 [
asyāḥ saṃsāramāyāyā nadyāstribhuvanāṅgaṇe |
rūpaṃ madavabodhārthaṃ kathayānugrahātpunaḥ
]

`v 7 [
anyo yatsaṃśayo'yaṃ me mahātmanhṛdi vartate |
lavaṇo'sau mahābhāgaḥ kiṃ nāmāpadamāptavān
]

`v 8 [
saṃśliṣṭayorāhatayordvayorvā dehadehinoḥ |
brahmanka iva saṃsārī śubhāśubhaphalaikabhāk
]

`v 9 [
lavaṇasya tathā dattvā tāmāpadamanuttamām |
kiṃ gataścañcalārambhaḥ kaścāsāvaindrajālikaḥ
]

`v 10 [
śrīvasiṣṭha uvāca |
kāṣṭhakuḍyopamo deho na kiṃcana ihānagha |
svapnāloka ivānena cetasā parikalpyate
]

`v 11 [
cetastu jīvatāṃ yātaṃ cicchaktiparibhūṣitam |
vidyātsaṃsārasaṃrambhaṃ kapipotakacañcalam
]

`v 12 [
dehī hi karmabhāgyo hi nānākāraśarīradhṛk |
ahaṃkāramanojīvanāmabhiḥ parikalpyate
]

`v 13 [
tasyemānyaprabuddhasya na prabuddhasya rāghava |
sukhaduḥkhānyanantāni śarīrasya na kānicit
]

`v 14 [
aprabuddhaṃ mano nānāsaṃjñākalpitakalpanam |
vṛtīranupataccitrā vicitrākṛtitāṃ gatam
]

`v 15 [
aprabuddhaṃ mano yāvannidritaṃ tāvadeva hi |
saṃbhramaṃ paśyati svapne na prabuddhaṃ kadācana
]

`v 16 [
ajñānanidrākṣubhito jīvo yāvanna bodhitaḥ |
tāvatpaśyati durbhedaṃ saṃsārārambhavibhramam
]

`v 17 [
saṃprabuddhasya manasastamaḥ sarvaṃ vilīyate |
kamalasya yathā hārdaṃ dinālokavikāsinaḥ
]

`v 18 [
cittāvidyāmanojīvavāsaneti kṛtātmabhiḥ |
karmātmeti ca yaḥ proktaḥ sa dehī duḥkhakovidaḥ
]

`v 19 [
jaḍo deho na duḥkhārho duḥkhī dehyavicārataḥ |
avicāro ghanājñānādajñānaṃ duḥkhakāraṇam
]

`v 20 [
śubhāśubhānāṃ dharmāṇāṃ jīvo viṣayatāṃ gataḥ |
avivekaikadoṣeṇa kośeneva hi kīṭakaḥ
]

`v 21 [
avivekāmayonnaddhaṃ mano vividhavṛttimat |
nānākāravihāreṇa paribhramati cakravat
]

`v 22 [
udeti rauti hantyatti yāti valgati nindai |
mana eva śarīre'sminna śarīraṃ kadācana
]

`v 23 [
yathā gṛhapatirgehe vividhaṃ hi viceṣṭate |
na gṛhaṃ tu jaḍaṃ rāma tathā dehe hi jīvakaḥ
]

`v 24 [
sarveṣu sukhaduḥkheṣu sarvāsu kalanāsu ca |
manaḥ kartṛ mano bhoktṛ mānasaṃ viddhi mānavam
]

`v 25 [
atra te śṛṇu vakṣyāmi vṛttāntamimamuttamam |
lavaṇo'sau yathā yātaścaṇḍālatvaṃ manobhramāt
]

`v 26 [
manaḥ karmaphalaṃ bhuṅkte śubhaṃ vā'śubhameva vā |
yathaitadbuddhyase nūnaṃ tathākarṇaya rāghava
]

`v 28 [
hariścandrakulotthena lavaṇena purānagha |
ekaṃ `note[ekānteneti iti pāṭhaḥ] tenopaviṣṭena cintitaṃ manasā ciram |
27 |
pitāmaho me sumahāvrājasūyasya yājakaḥ |
ahaṃ tasya kule jātastaṃ yaje manasā makham
]

`v 29 [
iti saṃcintya manasā kṛtvā saṃbhāramādṛtaḥ |
rājasūyasya dīkṣāyāṃ praviveśa mahīpatiḥ
]

`v 30 [
ṛtvijaścāhvayāmāsa pūjayāmāsa sanmunīn |
devānāmantrayāmāsa jvālayāmāsa pāvakam
]

`v 31 [
yathecchaṃ yajamānasya manasopavanāntare |
yayau saṃvatsaraḥ sāgro devarṣidvijapūjayā
]

`v 32 [
bhūtebhyo dvijapūrvebhyo dattvā sarvasvadakṣiṇām |
vibudhyata dinasyānte sva evopavane nṛpaḥ
]

`v 33 [
p. 398) 235
evaṃ sa lavaṇo rājā rājasūyamavāptavān |
manasaiva hi tuṣṭena yuktaṃ tasya phalena ca
]

`v 34 [
ataścittaṃ naraṃ viddhi bhoktāraṃ sukhaduḥkhayoḥ |
tanmanaḥ pāvanopāye satye yojaya rāghava
]

`v 35 [
pūrṇe deśe susaṃpūrṇaḥ pumānnaṣṭe vinaśyati |
deho'hamiti yeṣāṃ tu niścayastairalaṃ budhāḥ
]

`v 36 [
uccairvivekavati cetasi saṃprabuddhe
duḥkhānyalaṃ vigalitāni viviktabuddheḥ |
bhāsvatkaraprakaṭite nanu padmakhaṇḍe
saṃkocajāḍyatimirāṇi ciraṃ kṣatāni
]