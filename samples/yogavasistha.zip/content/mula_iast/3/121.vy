`v 1 [
ekaviṃśatyuttaraśatatamaḥ sargaḥ 121
caṇḍālyuvāca |
kenacittvatha kālena grāmake'smiñjaneśvara |
avṛṣṭiduḥkhamabhavadbhīṣaṇaṃ bhagnamānavam
]

`v 2 [
mahatānena duḥkhena sarve te grāmakā janāḥ |
vinirgatya gatā dūraṃ sarve pañcatvamāgatāḥ
]

`v 3 [
tenemā duḥkhabhāginyaḥ śūnyā vayamiha prabho |
saumya śocāma sadbāṣpamācāntekṣaṇadhārayā
]

`v 4 [
ityākarṇyāṅganāvaktrādrājā vismayamāgataḥ |
mantriṇāṃ mukhamālokya citrārpita ivābhavat
]

`v 5 [
bhūyo vicārayāmāsa tadāścaryamanuttamam |
bhūyo bhūyo'tha babhūvāścaryavāniti
]

`v 6 [
teṣāṃ samucitairdānasanmānairduḥkhasaṃkṣayam |
kṛtvā karuṇayāviṣṭo iṣṭalokaparāvaraḥ
]

`v 7 [
sthitvā tatra ciraṃ kālaṃ vimṛśya niyatergatīḥ |
ājagāma gṛhaṃ paurairvanditaḥ praviveśa ha
]

`v 8 [
prātastatra sabhāsthāne māmapṛcchadasau nṛpaḥ |
kathamevaṃ mune svapnaḥ pratyakṣamiti vismitaḥ
]

`v 9 [
yathāvastutayā tasya tata uktaḥ sa tādṛśaḥ |
saṃśayo hṛdayānnunno vātenevāmbudo divaḥ
]

`v 10 [
ityevaṃ rāghavāvidyā mahatī bhramadāyinī |
asatsattāṃ nayatyāśu saccāsattaṃ nayatyalam
]

`v 11 [
śrīrāma uvāca |
kathamevaṃ vada brahmansvapnaḥ satyatvamāgataḥ |
bhramodāra ivaiṣo'rtho na me galati cetasi
]

`v 12 [
śrīvasiṣṭha uvāca |
sarvametadavidyāyāṃ saṃbhavatyeva rāghava |
ghaṭeṣu paṭatā dṛṣṭā svapnasaṃbhramitādiṣu
]

`v 13 [
dūraṃ nikaṭavadbhāti mukure'ntarivācalaḥ |
ciraṃ śīghratvamāyāti punaḥ śreṣṭheva yāminī
]

`v 15 [
asaṃbhavacca bhavati svapne svamaraṇaṃ yathā |
asacca sadivābhāti `note[sadivodetīti iti pāṭhaḥ] svapneṣviva nabhogatiḥ |
14 |
susthitaṃ suṣṭhu calati bhrame bhūparivartavat |
acalaṃ calatāmeti madavikṣubdhacittavat
]

`v 16 [
vāsanāvalitaṃ ceto yadyathā bhāvayatyalam |
tattathānubhavatyāśu na tadasti na vāpyasat
]

`v 17 [
yadaivābhyuditā vidyā tvahaṃtvādimayī mudhā |
tadaivānādimadhyāntā bhramasyānantatoditā
]

`v 18 [
p. 410) 241
pratibhāsavaśādeva sarvo viparivartate |
kṣaṇaḥ kalpatvamāyāti kalpaśca bhavati kṣaṇaḥ
]

`v 19 [
viparyastamatirjantuḥ paśyatyātmānameḍakam |
bibharti siṃhatāmeḍo vāsanāvaśataḥ svayam
]

`v 20 [
viṣamabhramadāvidyāmohāhantādayah samāḥ |
sarve cittaviparyāsaphalasaṃpattihetutaḥ
]

`v 21 [
kākatālīyavaccetovāsanāvaśataḥ svataḥ |
saṃvadanti mahārambhā vyavahārāḥ parasparam
]

`v 22 [
vṛttaṃ prākpakkaṇe rājñaḥ kasyacillavaṇasya yat |
pratibhātaṃ tadetasya sadvāsadvā manogatam
]

`v 23 [
vismaratyapi vistīrṇāṃ kṛtāṃ cetaḥkriyāṃ yathā |
tathā krtāmapyakṛtāmiti smarati niścitam
]

`v 24 [
tathā na bhuktavānasmi bhuktavāniti cetasi |
svapne deśāntaragame prākṛto'pyavabuddhyate
]

`v 25 [
vindhyapuṣkasasugrāme vyavahāro'yamīdṛśaḥ |
pratibhāsāgatastasya svapne pūrvakathā yathā
]

`v 26 [
athavā lavaṇenāśu dṛṣṭo yaḥ svapnavibhramaḥ |
sa eva saṃvidaṃ prāpto vindhyapuṣkasacetasi
]

`v 27 [
lāvaṇī pratibhā'rūḍhā vindhyāpuṣkasacetasi |
vindhyapuṣkasasaṃvidvā'rūḍhā pārthivacetasi
]

`v 28 [
yathā bahūnāṃ sadṛśaṃ vacanaṃ nāma mānasam |
tathā svapne'pi bhavati kālo deśaḥ kriyāpi ca
]

`v 29 [
vyavahāragatestasyāḥ sattāsti pratibhāsataḥ |
sattā sarvapadārthānāṃ nānyā saṃvedanādṛte
]

`v 30 [
saṃvedanetarā bhāti vīcirvā jalasaṃgatiḥ `note[saṃgata iti pāṭhaḥ] |
bhūtabhavyabhaviṣyasthā tarubīje taruryathā
]

`v 31 [
tasyāḥ sattvamasattvaṃ ca na sannāsaditi sthitam |
satsadeva hi saṃvitterasaṃvitterasanmayam
]

`v 32 [
nāvidyā vidyate kiṃcittailādi sikatāsviva |
hemnaḥ kiṃ kaṭakādanyatpadaṃ syāddhematāṃ vinā
]

`v 33 [
avidyayātmatattvasya saṃbandho nopapadyate |
saṃbandhaḥ sadṛśānāṃ ca yaḥ sphuṭaḥ svānubhūtitaḥ
]

`v 34 [
jatukāṣṭhādisaṃbandho yaḥ samāsamayogataḥ |
nānyonyānubhavāyāsau tadekaspandamātrakam
]

`v 35 [
paramārthamayaṃ sarvaṃ yathā tenopalādayaḥ |
citā samabhicetyante saṃbandhavaśataḥ samāḥ
]

`v 36 [
yadā cinmātrasanmātramayāḥ sarve jagadgatāḥ |
bhāvāstadā vibhāntyete mithaḥ svānubhavasthiteḥ
]

`v 37 [
na saṃbhavati saṃbandho viṣamāṇāṃ nirantaraḥ |
na parasparasaṃbandhādvinānubhavanaṃ mithaḥ
]

`v 38 [
sadṛśe `note[sadaṃśe iti pāṭhaḥ] sadṛśaṃ vastu
kṣaṇādgatvaikatāmalam |
rūpamāsphārayatyekamekatvādeva nānyathā
]

`v 39 [
p. 411) 241
ciccetyamilitā `note[ciccetyacititārūpadṛśyayodeti cetana iti
pāṭhaṣṭīkānuguṇaḥ] dṛśyarūpayodeti cetanaḥ |
(jaḍaṃ `note[jaḍaṃ jaḍena iti ślokārdha kvacinna paṭhyate] jaḍena
militaṃ ghanaṃ saṃpadyate jaḍam |)
na ca cijjaḍayoraikyaṃ vailakṣaṇyātkvacidbhavet
]

`v 40 [
cijjaḍau citra ekatra na tau saṃmilataḥ kvacit |
cinmayatvāccidālambhaścidālambhena vedanam
]

`v 41 [
dārupāṣāṇabhedānāṃ natu hyete cidātmakāḥ |
padārtho hi padārthena pariṇāmyanubhūyate
]

`v 42 [
jihvayaiva rasāsvādaḥ sajātīyāmalodayaḥ |
aikyaṃ ca viddhi saṃbandhaṃ nāstyasāvasamānayoḥ
]

`v 43 [
jaḍacetanayostena nopalādi jaḍaṃ matam |
cidevopalakuḍyādirūpiṇīti mitā citā
]

`v 44 [
jaḍacetanayoriti pūrvānvayi | tena kiṃ phalitaṃ tadāha - teneti | iti mitā satī | 43
|
ekībhāvaṃ gatā draṣṭṛdṛśyādi kurute bhramam |
kāṣṭhopalādyaśeṣaṃ hi paramārthamayaṃ yataḥ
]

`v 45 [
tadātmanā tatsaṃbandhaṃ `note[tatsaṃbandha iti pāṭhaḥ sādhuḥ]
dṛśyatvenopalabhyate |
sarvaṃ sarvaprakārāḍhyamanantamiva yatnataḥ
]

`v 46 [
viśvaṃ sanmātramevaitadviddhi tattvavidāṃ vara |
asattātyāganiṣṭhena viśvaṃ lakṣaśatabhramaiḥ
]

`v 47 [
pūritaṃ ciccamatkāro naca kiṃcana pūritam |
saṃkalpanāgarā nṝṇāṃ mithaḥ spandanti no yathā
]

`v 48 [
na deśakālarodhāya tathā sargeṣviti sthitiḥ |
bhedabodhe hi sargatvamahaṃtvādibhramodayaḥ
]

`v 49 [
hemasaṃvitparityāge kaṭakādibhramo yathā |
kaṭakādibhramo hemni deśāddeśaṃ bhavādbhavam
]

`v 50 [
dṛgdarśanaparityāge nāvidyāsti pṛthaksadā |
kaṭakādimahābhedamekaṃ hema yathāmalam
]

`v 51 [
bodhaikatvādayaṃ sargastadevāsannayatyalam |
senā mṛtsaṃvidā citrā mṛnmātramiva mṛnmayī
]

`v 52 [
jalamekaṃ taraṅgādi dārvekaṃ śālabhañjikā |
mṛnmātramekaṃ kumbhādi brahmaikaṃ trijagadbhramaḥ
]

`v 53 [
saṃbandhe dṛśyadṛṣṭīnāṃ madhye draṣṭurhi yadvapuḥ |
draṣṭṛdarśanadṛśyādivarjitaṃ tadidaṃ param
]

`v 54 [
deśāddeśaṃ gate citte madhye yaccetaso vapuḥ |
ajāḍyasaṃvinmananaṃ tanmayo bhava sarvadā
]

`v 55 [
tasya tripuṭīśūnyatā kadā prasiddhā tatrāha - deśāditi | prāgvyākhyātam |
54 |
ajāgratsvapnanidrasya yatte rūpaṃ sanātanam |
acetanaṃ cājaḍaṃ ca tanmayo bhava sarvadā
]

`v 56 [
jaḍatāṃ varjayitvaikāṃ śilāyā hṛdayaṃ hi tat |
akṣubdho vāthavā kṣubdhastanmayo bhava sarvadā
]

`v 57 [
kasyacitkiṃcanāpīha nodeti na vilīyate |
akṣubdho vāthavā kṣubdhaḥ svasthastiṣṭha yathāsukham
]

`v 58 [
nābhivāñchati no dveṣṭi dehe kiṃcitkvacitpumān |
svasthastiṣṭha nirāśaṅkaṃ dehavṛttiṣu mā pata
]

`v 59 [
bhaviṣyadgrāmakagrāmyakāryavyavasito yathā |
cittavṛttiṣu mā tiṣṭha tathā satyātmatāṃ gataḥ
]

`v 60 [
p. 412) 242
yathā deśāntaranaro yathā kāṣṭhaṃ yathopalaḥ |
tathaiva paśya cittaṃ tvamacittaiva yadātmanā
]

`v 61 [
yathā dṛṣadi nāstyambu yathāmbhasyanalastathā |
svātmanyevāsti no cittaṃ paramātmani tatkutaḥ
]

`v 62 [
prekṣyamāṇaṃ na yatkiṃcittena yatkriyate kvacit |
kṛtaṃ bhavati tanneti matvā cittātigo bhavet
]

`v 63 [
cittasyāvastutve cittakāryāṇāṃ sutarāmasattvamityāha - prekṣyamāṇamiti |
62 |
atyantānātmabhūtasya yaścittasyānuvartate |
paryantavāsinaḥ kasmānna mlecchasyānuvartate
]

`v 64 [
nirantaramanādṛtya tvamārāccittapuṣkasam |
svasthamāssva nirāśaṅkaṃ paṅkeneva kṛto jaḍaḥ
]

`v 65 [
cittaṃ nāstyeva me bhūtaṃ mṛtamevādya vetti vā |
bhava niścayavānbhūtvā śilāpuruṣaniścalaḥ
]

`v 66 [
prekṣāyāmasti no cittaṃ tadvihīno'si tattvataḥ |
sa kimarthamanarthena tadvyarthena kadarthyase
]

`v 67 [
asatā cittayakṣeṇa ye mudhā svavaśe kṛtāḥ |
teṣāṃ pelavabuddhīnāṃ candrādaśanirutthitaḥ
]

`v 68 [
cittaṃ dūre parityajya yo'si so'si sthiro bhava |
bhava bhāvanayā mukto yuktyā paramayānvitaḥ
]

`v 69 [
asato ye'nuvartante cetaso'satyarūpiṇaḥ |
vyomamāraṇakarmaikanītakālāndhigastu tān
]

`v 70 [
vyapagalitamanā mahānubhāvo
bhava bhavapāragato bhavāmalātmā |
suciramapi vicāritaṃ na labdhaṃ
malamamalātmani mānasātma kiṃcit
]