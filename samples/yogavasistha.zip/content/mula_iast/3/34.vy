`v 1 [
catustriṃśaḥ sargaḥ 34
śrīvasiṣṭha uvāca |
atha rājñāṃ yuyutsūnāṃ bhaṭānāṃ mantriṇāmapi |
nabhasaḥ prekṣakāṇāṃ ca tatremāḥ prodagurgiraḥ
]

`v 2 [
calatpadmaṃ sara iva vahadvihagameva ca |
nabhaḥ śūraśiraḥkīrṇaṃ bhāti tārakitākṛti
]

`v 3 [
paśya raktapṛṣatpūrasindūrāruṇamārutaiḥ |
sāṃdhyā iva vibhāntyete madhyāhne'mbudabhānavaḥ
]

`v 4 [
p. 212)
kimidaṃ bhagavanvyoma palālabharitaṃ sthitam |
nedaṃ palālaṃ vīrāṇāmete śarabharāmbudāḥ
]

`v 5 [
yāvanto bhuvi sicyante rudhirai raṇareṇavaḥ |
tāvantyabdasahasrāṇi bhaṭānāmāspadaṃ divi
]

`v 6 [
mā bhaiṣṭa naite nistriṃśā nīlatpaladalatviṣaḥ |
amī vīrāvalokinyā lakṣmyā nayanavibhramāḥ
]

`v 7 [
vīrāliṅganalolānāṃ nitambe surayoṣitām |
mekhalāḥ śithilīkartuṃ pravṛttaḥ kusumāyudhaḥ
]

`v 8 [
lasadbhujalatālolā raktapallavapāṇayaḥ |
mañjarīmattanayanā madhvāmodasugandhayaḥ
]

`v 9 [
gāyantyo madhurālāpairnandanodyānadevatāḥ |
tavāgamanamāśaṅkya pravṛttaḥ parinartitum
]

`v 10 [
pratyanīkaṃ bhinattyantaḥ kuṭhāraiḥ kaṭhinairiyam |
senā grāmyeva vanitā dayitaṃ dṛṣṭiceṣṭitaiḥ
]

`v 11 [
hā piturmama bhallena śiro jvalitakuṇḍalam |
sūryasya nikaṭaṃ nītaṃ kālenevāṣṭamo grahaḥ
]

`v 12 [
āpādaśṛṅkhalāprotabhramatsthūlopaladvayam |
bhrāmayaṃścitradaṇḍākhyaṃ cakramūrdhvabhujo javāt
]

`v 13 [
yodho yama ivābhāti yāmyādāyāti diktaṭāt |
sarvataḥ saṃharansenāmehi yāmo yathāgatam
]

`v 14 [
sadyaśchinnaśiraḥśvabhramajjatkaṅkakulākulāḥ |
kabandhāḥ parinṛtyanti tālottālā raṇāṅgaṇe
]

`v 15 [
gīrvāṇagaṇagoṣṭhīṣu pravṛttāḥ saṃkathā mithaḥ |
kadā lokāntaraṃ dhīrāḥ kathaṃ yāsyanti ke kutaḥ
]

`v 16 [
nigiratyāgatāḥ senāḥ sravantīriva sāgaraḥ |
samatsyamakaravyūhā aho nu viṣamo bhaṭaḥ
]

`v 17 [
kaṭeṣu kariṇāṃ kīrṇā dhārānārācarājayaḥ |
patitā iva saṃpūrṇāḥ śṛṅgasaṃgheṣu vṛṣṭayaḥ
]

`v 18 [
hā kuntena śiro nītaṃ mametyevaṃ vivakṣataḥ |
śirasā'jīvamityevaṃ khe khageneva vāśitam
]

`v 19 [
yantrapāṣāṇavarṣeṇa yaiṣāsmānpariṣiñcati |
senānuśṛṅkhalājālavalanā kriyatāṃ balāt
]

`v 20 [
valīpalitanirmuktaṃ pūrvabhāryāpsarāḥ satī |
aṅgīkaroti bhartāraṃ parijñāya raṇe hatam
]

`v 21 [
ādivaṃ racitākārāḥ kuntakānanakāntayaḥ |
vīrāṇāṃ svargamāroḍhumiva sopānapaṅktayaḥ
]

`v 22 [
kāntakāñcanakāntāṅge bhaṭasyorasi kāminī |
dṛṣṭā devapurandhrīyaṃ bharturanveṣaṇānvitā
]

`v 23 [
hā hataṃ sainyamasmākaṃ bhaṭaruddhatamuṣṭibhiḥ |
mahāpralayakallolaiḥ suraśailasthalaṃ yathā
]

`v 24 [
yudhyadhvamagrato mūḍhā nayatārdhamṛtānnarān |
nijānpādaprahāreṇa maitāndārayatādhamāḥ
]

`v 25 [
dhammillavalanāvyagre ghanotkaṇṭhe'psarogaṇe |
bhaṭo divyaśarīreṇa pārśvaprāpto nirīkṣyatām
]

`v 26 [
phullahemāravindāsu cchāyāśītajalānilaiḥ |
svarganadyāstaṭīṣvenaṃ dūrāyātaṃ vinodaya
]

`v 27 [
vividhāyudhasaṃghaṭṭakhaṇḍitogrāsthikoṭayaḥ |
khe kavantyaḥ kaṇṭkāraiḥ prasṛtāstārakā iva
]

`v 28 [
vyomni jīvanadīvāhe vahatsāyakavāriṇi |
cakrāvartini gacchanti girayo'pyaṇupaṅkatām
]

`v 29 [
bhramadbhirgrahamārgeṣu śirobhirvīrabhūbhṛtām |
āyudhāṃśulatānālalagnāsidalakaṇṭakaiḥ
]

`v 30 [
p. 213)
ketupaṭṭamṛṇālāṅgadalairlabdhaśilīmukhaiḥ |
avahadvātacalatpadmaṃ nabhaḥ padmasaraḥ kṛtam
]

`v 31 [
mṛtamātaṅgasaṃghāte girāviva pipīlikāḥ |
bhīravaḥ parilīyante `note[parihīyante iti pāṭhaḥ] striyaḥ puṃvakṣasīva ca
]

`v 32 [
apūrvottamasaundaryakāntasaṃgamaśaṃsinaḥ |
vānti vidyādharastrīṇāmalakollāsino'nilāḥ
]

`v 33 [
chatreṣūḍḍiyamāneṣu sthiteṣu vyomni candratā |
induneva yaśomūrtyā kṛtā śubhrātapatratā
]

`v 34 [
bhaṭo maraṇamūrcchānte nimeṣeṇāmaraṃ vapuḥ |
svakarmaśilpiracitaṃ prāptaḥ svapnapuraṃ yathā
]

`v 35 [
śūlaśaktyṛṣṭicakrāṇāṃ vṛṣṭayo muktatuṣṭayaḥ |
vyomābdhau matsyamakarasaṃkulāvayavāḥ sthitāḥ
]

`v 36 [
śarotkṛttasitacchatrakalahaṃsairnabhaḥsthalam |
bhāti saṃcitapūrṇendubimbalakṣairivāvṛtam
]

`v 37 [
kriyate gaganoḍḍīnaiścāmaraiścārughargharaiḥ |
vātāvadhūtasaṃrodhataraṅganikaradyutiḥ
]

`v 38 [
dṛśyante hetidalitāśchatracāmaraketavaḥ |
ākāśakṣetravikṣiptā yaśaḥśālilatā iva
]

`v 39 [
vahadbhirvyomni sakṣema paśya nītā kṣayaṃ śaraiḥ |
śaktivṛṣṭirupāyāntī sasyaśrīḥ śalabhairiva
]

`v 40 [
eṣā prasṛtadordaṇḍabhaṭakhaḍgacchaṭātkṛtiḥ |
kaṭhinātkaṃkaṭājjātā mṛtyorevograhuṃkṛtiḥ
]

`v 41 [
hetikalpānilakṣuṇṇā dantanirjharavārayaḥ |
janatākṣayakāle'sminbhagnā nāgā nagā iva
]

`v 42 [
sacakranāthasūtāśvaṃ vyūḍhaṃ raktamahāhrade |
hāhābhibhūtagatikaṃ `note[mahābhibhūta iti pāṭhaḥ] ceṣṭate
rathapattanam
]

`v 43 [
karakaṃkaṭakuṭyaṅkakhaḍgasaṃghaṭṭaṭāṃkṛtaiḥ |
kālarātryā pranṛtyantyā raṇavīṇeva vādyate
]

`v 44 [
narebhakharavājibhyo ye cyutā raktanirjharāḥ |
paśya tadbindusiktena vāyunāruṇitā diśaḥ
]

`v 45 [
śastrāṃśujalade vyomni kālīcikuramecake |
śarakorakabhārasraṅmeghe vidyudivoditā
]

`v 46 [
anantaraktasaṃsaktasannāvanitalāyudhaiḥ |
bhuvanaṃ bhātyabhijvālamagniloka ivākulam
]

`v 47 [
bhuśuṇḍīśaktiśūlāsimusalaprāsavṛṣṭayaḥ |
anyonyacchedabhedābhyāṃ karaprakarato'patan
]

`v 48 [
akṣobhaikapraharaṇādyātudhānyo'nyaceṣṭitam |
saṃrambhāvekṣaṇaprajñaṃ raṇaṃ svapnamiva sthitam
]

`v 49 [
ananyaśabdāviratahatāhatiraṇajjhaṇaiḥ |
gāyatīva kṣatakṣobhamudito raṇabhairavaḥ
]

`v 50 [
anyonyaraṇahetyugracūrṇapūrṇo raṇārṇavaḥ |
vālukāmaya evābhūcchinnacchatrataraṅgakaḥ
]

`v 51 [
sarabhasarasavadvisāritūrya-
pratiravapūritalokapālalokaḥ |
raṇagirirayamugrapakṣadakṣa- `note[ravamugra iti pāṭhaḥ]
pratisṛtivṛtta ivāmbare yugānte
]

`v 52 [
p. 214)
hā hā dhikpravikaṭakaṅkaṭānanodya-
tproḍḍīnaprakaṭataḍicchaṭāprataptāḥ |
kreṅkārasphuritaguṇeritā raṇanto
nārācāḥ śikhariśilāgaṇaṃ vahanti
]

`v 53 [
chinnecchācchamiti na yāvadaṅgabhaṅgaṃ
kurvanto jvaladanalojjvalāḥ pṛṣatkāḥ |
tāvadrāgdrutamita ehi mitra yāmo
yāmo'yaṃ pravahati vāsaraścaturthaḥ
]