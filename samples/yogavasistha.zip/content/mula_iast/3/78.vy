`v 1 [
aṣṭasaptatitamaḥ sargaḥ 78
śrīvasiṣṭha uvāca |
atha sā rākṣasī rakṣaḥkulakānanamañjarī |
tamasyevābhralekheva gambhīraṃ vinanāda ha
]

`v 2 [
nādānte samuvācedaṃ huṃkārāparuṣaṃ vacaḥ |
garjitānantaraṃ jātakarakāśaniśabdavat
]

`v 3 [
bho bho ghorāṭavīvyomapadavīśaśibhāskarau |
mahāmāyātamaḥpīṭhaśilākoṭarakīṭakau
]

`v 4 [
kau bhavantau mahābuddhī durbuddhī vā samāgatau |
madgrāsapadamāpannau kṣaṇānmaraṇakocitau
]

`v 5 [
rājovāca |
bho bho bhūtaka kiṃ syāstvaṃ kva tiṣṭhasi ca dehakam |
darśayāsyāstava giraḥ ko bibhetyalinīdhvaneḥ
]

`v 6 [
siṃhavatsarvavegena patantyarthe kilārthinaḥ |
tyaja saṃrambhamārambhaṃ svasāmarthyaṃ pradarśaya
]

`v 7 [
kiṃ prārthayasi me brūhi dadāmi tava suvrata |
kiṃ vā saṃrambhaśabdābhyāṃ bhīṣayāsmānbibheṣi kim
]

`v 8 [
kṣipramākāraśabdābhyāṃ māyayā sanmukhībhava |
na kiṃciddīrghasūtrāṇāṃ siddhyatyātmakṣayādṛte
]

`v 9 [
rājñetyukte ramyamuktamiti saṃcintya sā tayoḥ |
prakāśāyāpya dhairyāya nanāda ca jahāsa ca
]

`v 10 [
tato dadṛśatustāṃ tau śabdapūritadiggaṇām |
sāṭṭahāsaprabhāpiṇḍapūraprakaṭitākṛtim
]

`v 11 [
kalpābhrāśanikāṣeṇa ghṛṣṭāmadritaṭīmiva |
svanetravidyudvalayabalākojjvalitāmbarām
]

`v 12 [
timiraikārṇavaurvāgnijvālāvivalanāmiva |
garjadghanaghaṭāto.papīvarāsitakandharām
]

`v 13 [
raṇaddaśanasaṃrambhahāhāhataniśācarām |
rodasīkajjalastambhāṃ līlayollasitāṃ punaḥ
]

`v 14 [
ūrdhvakeśīṃ śirālāṅgīṃ kapilākṣīṃ tamomayīm |
yakṣarakṣaḥpiśācānāmapyanarthabhayapradām
]

`v 15 [
deharandhraviśacchvāsavātabhāṃkārabhīṣaṇām |
musalolūkhalālātahalaśūrpakaśekharām
]

`v 16 [
p. 317) 192
sphurantīmiva kalpānte vaidūryaśikharasthalīm |
hāsaghaṭṭitaviśveśāṃ kālarātrimivoditām
]

`v 17 [
śaradvyomāṭavīṃ sābhrāṃ kṛtadehāmivāgatām |
śarīriṇīṃ mahābhrāḍhyāṃ yāminīmiva māṃsalām
]

`v 18 [
śarīrasaṃniveśena paṅkapīṭhamivotthitām |
tanuṃ candrārkayudhāya tamaseva samāśritām
]

`v 19 [
indranīlamahāśubhralambābhrayugalopamau |
ulūkhalādihāraughau dadhānāmasitau stanau
]

`v 20 [
lagnāmaṅgārakāṣṭhena samānāṃ ca mahātanum |
drumābhāspandasaśiralasadbhujalatātanum
]

`v 21 [
tāmavekṣya mahāvīrau tathaivākṣubhitau sthitau |
na tadasti vimohāya yadviviktasya cetasaḥ
]

`v 22 [
mantryuvāca |
mahārākṣasi saṃrambho mahātmā kimayaṃ tava |
laghavo hyathavā kārye laghāvapyatisaṃbhramāḥ
]

`v 23 [
tyaja saṃrambhamārambho nāyaṃ tava virājate |
viṣaye hi pravartante dhīmantaḥ svārthasādhakāḥ
]

`v 24 [
tvādṛśānāṃ sahasrāṇi maśakānāmivābale |
asmākaṃ dhīratāvātyāvyūḍhāni tṛṇaparṇavat
]

`v 25 [
saṃrambhadvāramutsṛjya samatāsvacchayā dhiyā |
yuktyā ca vyavahāriṇyā svārthaḥ prājñena sādhyate
]

`v 26 [
svenaiva vyavahāreṇa kāryaṃ siddhyatu vā na vā |
mahāniyatirityeva bhramasyāvasaro hi kaḥ
]

`v 27 [
kāryasiddhisaṃśaye'pyanādiniyatisiddhaḥ sāmopāyo na heyaḥ kiṃ vācyaṃ
tanniścaye ityāśayenāha - svenaiveti | bhramasya bhrāntocitasaṃrambhasya |
26 |
kathayābhimataṃ kiṃ te kimarthayasi cārthinī |
arthī svapne'pi nāsmākamaprāptārthaḥ puro gataḥ
]

`v 28 [
ityuktā sā tadā tena cintayāmāsa rākṣasī |
aho nu vimalācāraṃ sattvaṃ puruṣasiṃhayoḥ
]

`v 29 [
na sāmānyāvimau manye vicitreyaṃ camatkṛtiḥ |
vacovakrekṣaṇenaiva vadatyantarviniścayam
]

`v 30 [
vacovakrekṣaṇadvārairdhīmatāmāśayā mithaḥ |
ekībhavanti saritāṃ payāṃsi valanairiva
]

`v 31 [
ābhyāṃ prāyaḥ parijñāto mama bhāvo'nayormayā |
na vināśyau mayā cemau svayamevāvināśinau
]

`v 32 [
manye bhavetāmātmajñau nātmajñānādṛte matiḥ |
pramṛṣṭasadasadbhāvādbhavatyastabhayā mṛtau
]

`v 33 [
tadetau paripṛcchāmi kiṃcitsaṃdehamutthitam |
prājñaṃ prāpya na pṛcchanti ye kecitte narādhamāḥ
]

`v 34 [
iti saṃcintya pṛcchāyai tanvānāvasaraṃ tataḥ |
akālakalpābhraravaṃ hāsaṃ saṃyamya sāvravīt
]

`v 35 [
kau bhavantau narau dhīrau kathyatāmiti me'naghau |
jāyate darśanādeva maitrī viśadacetasām
]

`v 36 [
mantryuvāca |
ayaṃ rājā kirātānāmasyāhaṃ mantritāṃ gataḥ |
udyatau rātricaryeṇa tvādṛgjanavinigrahe
]

`v 37 [
rājño rātriṃdivaṃ dharmo duṣṭabhūtavinigrahaḥ |
svadharmatyāgino ye tu te vināśānalendhanam
]

`v 38 [
rākṣasyuvāca |
rājaṃstvamasi durmantrī durmantrī na nṛpo bhavet |
sadrūpasya bhavenmantrī rājā sanmantriṇo bhavet
]

`v 39 [
rājā cādau vivekena yojanīyaḥ sumantriṇā |
tenāryatāmupāyāti yathā rājā tathā prajāḥ
]

`v 40 [
samastaguṇajālānāmadhyātmajñānamuttamam |
tadvidrājā bhavedrājā tadvinmantrī ca mantravit
]

`v 41 [
samasteti | tathācāhuḥ - tatkarmayanna bandhāya sā vidyā yā vimuktaye |
āyāsāyāparaṃ karma vidyānyā śilpanaipuṇam | iti | mantravidvicārarahasyavit |
40 |
p. 318) 193
prabhutvaṃ samadṛṣṭitvaṃ tacca syādrājavidyayā |
tāmeva yo na jānāti nāsau mantrī na so'dhipaḥ
]

`v 42 [
bhavantau tadvidau sādhū yadi tacchreya āpnuthaḥ |
no cedanarthadau svasyāḥ prakṛteradmyahaṃ yuvām
]

`v 43 [
ekopāyena matpārśvādbālakāvuttariṣyathaḥ |
matpraśnapañjaraṃ sāraṃ cedvicārayatho dhiyā
]

`v 44 [
praśnānimānkathaya pārthiva vā ca mantriṃ-
statrārthinī bhṛśamahaṃ paripūrayārtham |
aṅgīkṛtārthamadadatka ivāsti loke
doṣeṇa saṃkṣayakareṇa na yujyate yaḥ
]