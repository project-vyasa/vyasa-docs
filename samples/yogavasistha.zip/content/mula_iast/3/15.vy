`v 1 [
tṛtīyo divasaḥ |
p. 167)
pañcadaśaḥ sargaḥ 15
jgadākāśamevedaṃ yathā hi vyomni mauktikam |
vimale bhāti svātmaiva jagccidgaganaṃ yathā
]

`v 2 [
anutkīrṇaiva bhātīva trijagacchālabhañjikā |
citstambhenaiva sotkīrṇā nacotkartātra vidyate
]

`v 3 [
samudre'ntarjalaspandāḥ svabhāvādacyutā api |
vīcivegā bhavantīva pare dṛśyavidastathā
]

`v 4 [
jālāntargatasūryābhā jālākārarajāṃsyapi |
jagadbhānaṃ prati sthūlānyaṇuṃ prati yathācalāḥ
]

`v 5 [
jagadbhānaṃ na bhātīdaṃ brahmaṇo vyatirekataḥ |
jālasūryāṃśujālaṃ tu vyatirekānubhūtidam
]

`v 6 [
anubhūtānyapīmāni jaganti vyomarūpiṇi |
pṛthvyādīni na santyeva svapnasaṃkalpayoriva
]

`v 7 [
piṇḍagraho jagatyasminvijñānākāśarūpiṇi |
marunadyāṃ jalamiva na saṃbhavati kutracit
]

`v 8 [
jagatyapiṇḍagrāhe'sminsaṃkalpanagaropame |
marau saridivābhāti dṛśyatā bhrāntirūpiṇī
]

`v 9 [
svapnāddṛśyeva jagatāṃ tulādeśena kena ca |
tulitā kalanonmuktā dṛśyaśrīrvyoma jṛmbhate
]

`v 10 [
varjayitvā jñavijñānaṃ jagacchabdārthabhājanam |
jagadbrahmasvaśabdānāmarthe nāstyeva bhinnatā
]

`v 11 [
idaṃ tvacetyacinmātraṃ bhānorbhātaṃ nabhaḥ prati |
tathā sūkṣmaṃ yathā meghaṃ prati saṃkalpavāridaḥ
]

`v 12 [
yathā svapnapuraṃ svacchaṃ jāgratpuravaraṃ prati |
tathā jagadidaṃ svacchaṃ sāṃkalpikajagatprati
]

`v 13 [
tasmādacetyacidrūpaṃ jagadvyomaiva kevalam |
śūnyau vyomajagacchabdau paryāyau viddhi cinmayau
]

`v 14 [
tasmānna kiṃcidutpannaṃ jagadādīha dṛśyakam |
anākhyamanabhivyaktaṃ yathāsthitamavasthitam
]

`v 15 [
jagadevaṃ mahākāśe cidākāśamabhittimat |
taddeśasyāṇumātrasya tulāyāścāprapūrakam
]

`v 16 [
ākāśarūpamevācchaṃ piṇḍagrahavivarjitam |
vyomni vyomamayaṃ citraṃ saṃkalpapuravatsthitam
]

`v 17 [
atredaṃ maṇḍapākhyānaṃ śṛṇu śravaṇabhūṣaṇam |
niḥsaṃdeho yathaiṣo'rthaścitte viśrāntimeṣyati
]

`v 18 [
p. 168)
śrīrāma uvāca |
sadbodhavṛddhaye brahmansamāsena vadāśu me |
maṇḍapākhyānamakhilaṃ yena bodho vivardhate
]

`v 19 [
śrīvasiṣṭha uvāca |
abhūdasminmahīpīṭhe kulapadmo vikāśavān |
padmo nāma nṛpaḥ śrīmānbahuputro vivekavān
]

`v 20 [
maryādāpālanāmbhodhirdviṣattimirabhāskaraḥ |
kāntākumudinīcandro doṣatṛṇahutāśanaḥ
]

`v 21 [
merurvibudhavṛndānāṃ yaśaścandro bhavārṇave |
saraḥ sadguṇahaṃsānāṃ kamalāmalabhāskaraḥ
]

`v 22 [
saṃgrāmavīrutpavano manomātaṅgakesarī |
samastavidyādayitaḥ sarvāścaryaguṇākaraḥ
]

`v 23 [
surārisāgarakṣobhavilasanmandarācalaḥ |
vilāsapuṣpaughamadhuḥ saubhāgyakusumāyudhaḥ
]

`v 24 [
līlālatālāsyamarutsāhasotsāhakeśavaḥ |
saujanyakairavaśaśī durlīlāvallikānalaḥ
]

`v 25 [
tasyāsti subhagā bhāryā līlā nāma vilāsinī |
sarvasaubhāgyavalitā kamalevoditā'vanau
]

`v 26 [
sarvānuvṛttilalitā līlā madhurabhāṣiṇī |
sānandamandacalitā dvitīyendūdayasmitā
]

`v 27 [
alakālimanohārivadanāmbhojaśālinī |
sitāṅgī karṇikāgaurī jaṅgameva sarojinī
]

`v 28 [
latavilāsakundaughabhāsinī rasaśālinī |
pravālahastā puṣpābhā madhuśrīriva dehinī
]

`v 29 [
avadātatanuḥ puṇyā sparśanāhlādakāriṇī |
gaṅgeva gāṃ gatā dehavatī haṃsavilāsinī
]

`v 30 [
tasya bhūtalapuṣpeṣoḥ sakalāhlādadāyinaḥ |
paricaryāṃ ciraṃ kartumanyā ratirivoditā
]

`v 31 [
udvigne prodvignā
mudite muditā samākulākulite |
pratibimbasamā kāntā
saṃkruddhe kevalaṃ bhītā
]