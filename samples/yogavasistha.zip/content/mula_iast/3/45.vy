`v 1 [
pañcacatvāriṃśaḥ sargaḥ 45
śrīsarasvatyuvāca |
vidūrathaste bhartaiṣa tanuṃ tyaktvā raṇāṅgaṇe |
tadevāntaḥpuraṃ prāpya tādṛgātmā bhaviṣyati
]

`v 2 [
śrīvasiṣṭha uvāca |
ityākarṇya vaco devyā līlā sā tatpurāspadā |
puraḥ prahvā sthitovāca vacanaṃ vihitāñjaliḥ
]

`v 3 [
dvitīyalīlovāca |
devī bhagavatī jñaptirnityamevārcitā mayā |
svapne saṃdarśanaṃ `note[svamityapi pāṭhaḥ] devī sā dadāti niśāsu me
]

`v 4 [
sā yādṛśyeva deveśi tādṛśyeva tvamambike |
tanme kṛpaṇakāruṇyādvaraṃ dehi varānane
]

`v 5 [
śrīvasiṣṭha uvāca |
ityuktā sā tadā jñaptiḥ smṛtvā tadbhaktibhāvanam |
idaṃ prasannā provāca tāṃ līlāṃ tatpurāspadām
]

`v 6 [
śrīdevyuvāca |
ananyayā bhāvanayā yāvajjīvamajīrṇayā |
parituṣṭāsmi te vatse gṛhāṇābhimataṃ varam
]

`v 7 [
taddeśalīlovāca |
raṇāddehaṃ parityajya yatra tiṣṭhati me patiḥ |
anenaiva śarīreṇa tatra syāmetadaṅganā
]

`v 8 [
śrīdevyuvāca |
evamastu tvayā'vighnaṃ pūjitāsmi sute ciram |
ananyabhāvayā bhūri puṣpadhūpasaparyayā
]

`v 9 [
śrīvasiṣṭha uvāca |
atha taddeśalīlāyāṃ phullāyāṃ tadvarodayāt |
pūrvalīlābravīddevīṃ saṃdehalulitāśayā
]

`v 10 [
p. 241)
pūrvalīlovāca |
ye satyakāmāḥ santyevaṃsaṃkalpā brahmarūpiṇaḥ |
tvādṛśāḥ sarvamevāśu teṣāṃ siddhyatyabhīpsitam
]

`v 11 [
tattenaiva śarīreṇa kimarthaṃ nāhamīśvari |
lokāntaramidaṃ nītā taṃ girigrāmakaṃ vada
]

`v 12 [
śrīdevyuvāca |
na kiṃcitkasyacidahaṃ karomi varavarṇini |
sarvaṃ saṃpādayatyāśu svayaṃ jīvaḥ svamīhitam
]

`v 13 [
ahaṃ hitaṃ raṭe jñaptiḥ saṃvinmātrādhidevatā |
pratyekamasti cicchaktirjīvaśaktisvarūpiṇī
]

`v 14 [
jīvasyodeti yā śaktiryasya yasya yathā yathā |
bhāti tatphaladā nityaṃ tasya tasya tathā tathā
]

`v 15 [
māṃ samārādhayantyāstu jīvaśaktistavoditā |
tadā bhavadyadīha syāṃ muktāsmīti ciraṃ tadā
]

`v 16 [
asmītyahaṃśabdaparyāyaṃ tiṅantapratirūpakamavyayam | ahaṃ muktā syāṃ iti
bhāvikarmatatphalasūkṣmāvasthānagarbhakāmanāvacchinnacidrūpā jīvaśaktiḥ |
15 |
tena tena prakāreṇa tvaṃ mayā saṃprabodhitā |
tayā yuktyāmalaṃ bhāvaṃ nītāsi varavarṇini
]

`v 17 [
anayaivaṃ bhāvanayā bodhitāsi ciraṃ tadā |
tamevārthaṃ prāptavatī sadā svacitiśaktitaḥ
]

`v 18 [
yasya yasya yathodeti svacitprayatanaṃ ciram |
phalaṃ dadāti kālena tasya tasya tathā tathā
]

`v 19 [
tapo vā devatā vāpi bhūtvā svaiva cidanyathā |
phalaṃ dadātyatha svairaṃ nabhaḥphalanipātavat
]

`v 20 [
svasaṃvidyatanādanyanna kiṃcicca kadācana |
phalaṃ dadāti tenāśu yathecchasi tathā kuru
]

`v 21 [
cidbhāva eva nanu sargagato'ntarātmā `note[sarvagataḥ iti pāṭhaḥ]
yaccetati prayatate ca tadaiti tacchrīḥ |
ramyaṃ hyaramyamathaveti vicārayasva
yatpāvanaṃ tadavabudhya tadantarāssva
]