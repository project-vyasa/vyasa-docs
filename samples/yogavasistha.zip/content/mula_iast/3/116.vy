`v 1 [
ṣoḍaśottaraśatatamaḥ sargaḥ 116
śrīrāma uvāca |
rājasūyaphalaṃ prāptaṃ lavaṇena kila prabho |
pramāṇaṃ kimivātra syātkalpanājālaśambare
]

`v 2 [
śrīvasiṣṭha uvāca |
yadā śāmbarikaḥ kāle saṃprāpto lāvaṇīṃ sabhām |
tadāhamavasaṃ tatra tatpratyakṣeṇa dṛṣṭavān
]

`v 3 [
ahaṃ sabhyaistatastatra gate śāmbarikarmaṇi |
kimetaditi yatnena pṛṣṭaśca lavaṇena ca
]

`v 4 [
cintayitvā mayā dṛṣṭvā tatra tatkathitaṃ tataḥ |
śṛṇu tatte pravakṣyāmi rāma śāmbarikehitam
]

`v 5 [
rājasūyasya kartāro ye hi te dvādaśābdikam |
āpaduḥkhaṃ prāpnuvanti nānākāravyathāmayam
]

`v 6 [
ataḥ śakreṇa gaganādduḥkhāya lavaṇasya saḥ |
prahito devadūto hi rāma śāmbarikākṛtiḥ
]

`v 7 [
rājasūyakriyākartustasya dattvā mahāpadam |
agacchatsa nabhomārgaṃ surasiddhaniṣevitam
]

`v 8 [
tasmātpratyakṣamevaitadrāma nātra saṃdeho'sti | mano hi vilakṣaṇānāṃ
kriyāṇāṃ kartṛ bhoktṛ ca tadeva nirghṛṣya saṃśodhya cittaratnamiha
himakaṇamivātapena vilīnatāṃ vivekena nītvā paraṃ śreyaḥ prāpsyasi |
cittameva sakalabhūtāḍambarakāriṇīmavidyāṃ viddhi | sā
vicitrakendrajālavaśādidamutpādayati | avidyācittajīvabuddhiśabdānāṃ
bhedo nāsti vṛkṣataruśabdayoriveti jñātvā cittameva vikalpanaṃ kuru |
abhyudite cittavaimalyārkabimbe sakalaṅkavikalpotthadoṣatimirāpaharaṇaṃ
na tadasti rāghava yanna dṛśyate yannātmīkriyate yanna parityajyate yanna
mriyate yannātmīyaṃ yanna parakīyaṃ sarvaṃ sarvadā sarvo bhavatīti
paramārthaḥ
]

`v 9 [
p. 399) 235
bhāvarāśistathā bodhaḥ sarvo yātyekapiṇḍatām |
vicitramṛdbhāṇḍagaṇo yathā'pakvo jale sthitaḥ
]

`v 10 [
śrīrāma uvāca |
evaṃ manaḥparikṣaye sakalasukhaduḥkhānāmantaḥ prāpyata iti bhavatā
proktaṃ tatkathaṃ mahātmaṃścapalavṛttirūpasyāsya manaso'sattā bhavati
]

`v 11 [
śrīvasiṣṭha uvāca |
raghukulendo śṛṇu manaḥpraśamane yuktiṃ yāṃ jñātvā
svasvācāradūre manaḥsaṃdhirayameṣyasi
]

`v 12 [
iha hi tāvadbrahmaṇaḥ sarvabhūtānāṃ trividhotpattiriti tatpūrvoktam
]

`v 13 [
tatredaṃprathamayā manaḥkalpanayā dehīti sā brahmarūpiṇī saṃkalpamayī
bhūtvā yadeva saṃkalpayati tadeva paśyati tenedaṃ bhuvanāḍambaraṃ
kalpyate
]

`v 14 [
tatra jananamaraṇasukhaduḥkhamohādikaṃ saṃsaraṇaṃ kalpayantī
kalpānuracanā bahunāmamantharaṃ sthitvā svayaṃ vilīyate
himakaṇikevātapagatā
]

`v 15 [
kāloditaḥ saṃkalpavaśāt punaranyatayā jāyate sāpi punarvilīyate
punarapyudeti saiveti bhūyobhūyo'nusaṃsarantī svayamupaśāmyati
]

`v 16 [
itthamanantā brahmakoṭayo'sminbrahmāṇḍe'nyeṣu ca samatītā bhaviṣyantīti
santi cetarā anantā yāsāṃ saṃkhyāpi na vidyate
]

`v 17 [
p. 400) 236
evamasyāṃ tādṛśi vartamānāyāmīśvarādāgatya jīvo yathā jīvyate
vimucyate tacchṛṇu
]

`v 18 [
brahmaṇo manaḥśaktirabhyuditā puraḥsthitakāśaśaktimavalambya
tatrasthapavanatānupātinī ghanasaṃkalpatvaṃ gacchati
]

`v 19 [
saṃkṣepeṇa sūtritamarthaṃ vivarītukāmaḥ prathamamīśvarādāgatyetyaṃśaṃ
vivṛṇoti - manaḥśaktiriti | pralaye upādhivilayādavyākṛte līnānāṃ
jīvānāṃ saṃskāramātreṇa pariśiṣṭā manaḥśaktiḥ prathamamavyākṛtāt
śabdatanmātrātmakākāśaśaktyāvirbhāve sati puraḥsthitāṃ prathamotpannāṃ
tāmavalambya svayamapyabhuditā satī pavanaśaktyātmakasparśatanmātrotpattau
tatratyapavanatānupātinī īṣaccalanayogyatālakṣaṇaṃ ghanasaṃkalpatvaṃ gacchati |
18 |
tataḥ puraḥprāptabhūtatanmātrapañcakatāmetyāntaḥkaraṇatāṃ nītvā
sātvasūkṣmā prakṛtirbhūtvā
gaganapavanatejorūpatāsaṃkalpātprāleyarūpatāmupetya śālyoṣadhiṃ
viśantī prāṇināṃ garbhatāṃ ca gacchati
]

`v 20 [
jāyate tasmāttataḥ puruṣaḥ saṃpadyate
]

`v 21 [
tasmājjāyate prasūyate tato janmanaḥ
kadācitsukṛtādhikyātkarmajñānādhikṛtaḥ puruṣaḥ saṃpadyata ityarthaḥ | 20
|
tena puruṣeṇa jātamātreṇaiva bālyātprabhṛti vidyāgrahaṇaṃ kartavyaṃ
guravo'nugantavyāḥ
]

`v 22 [
tataḥ kramātpuṃsastaveva camatkṛtirjāyate
]

`v 23 [
svacchadṛśā cittavṛtteḥ puruṣasya heyopādeyavicāra utpadyate
]

`v 24 [
tādṛgvivekavati saṃkalitābhimāne
puṃsi sthite vimalasattvamayāgryajātau |
saptātmikāvatarati kramaśaḥ śivāya
cetaḥprakāśanakarī nanu yogabhūmiḥ
]