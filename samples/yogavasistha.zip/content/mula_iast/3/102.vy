`v 1 [
dvyuttaraśatatamaḥ sargaḥ 102
śrīvasiṣṭha uvāca |
svasaṃkalpavaśānmūḍho mohameti na paṇḍitaḥ |
akṣaye kṣayasaṃkalpānmuhyate śiśureva hi
]

`v 2 [
śrīrāma uvāca |
ko'sau saṃkalpitaḥ kena kṣayo brahmvavidāṃ vara |
asataiva mahāmohaṃ yenādāttatsadaiva hi
]

`v 3 [
śrīvasiṣṭha uvāca |
asatā bhūtasaṃdhena kṣayo'haṃkāranāmadhṛk |
vetālaḥ śiśuneveha mithyaiva parikalpitaḥ
]

`v 4 [
ekasminneva sarvasminsthite paramavastuni |
kutaḥ ko'yamahaṃ nāma kathaṃ nāma kiloditaḥ
]

`v 5 [
vastuto nāstyahaṃkāraḥ paramātmanyabhedini |
asamyagdarśanānmārgīsarittīvrātape yathā
]

`v 6 [
manomaṇimahārambhaḥ saṃsāra iti lakṣyate |
ātmanātmānamāśritya sphuratyantaryathāmbhasā
]

`v 7 [
asamyagdarśanaṃ tena tyaja rāma nirāśrayam |
sāśrayaṃ satyamānandi samyagdarśanamāśraya
]

`v 8 [
dhiyā vicāradharmiṇyā mohasaṃrambhahīnayā |
vicārayādhunā satyamasatyaṃ saṃparityaja
]

`v 9 [
abaddho baddha ityuktvā kiṃ śocasi mudhaiva hi |
anantasyātmatattvasya kiṃ kathaṃ kena badhyate
]

`v 10 [
p. 370) 220
nānā'nānātvakalanā tvavibhinnamahātmani |
sarvasminbrahmatattve'sminkiṃ baddhaṃ kiṃ vimucyate
]

`v 11 [
anārto'pyārtimānbhāti cchinne'ṅge kiṃca tāmyati |
bhedābhedavikārārtiḥ kācinnātmani vidyate
]

`v 12 [
dehe naṣṭe kṣate kṣīṇe kātmanaḥ kṣatirāgatā |
bhastrāyāṃ paridagdhāyāṃ bhastrāpūro na naśyati
]

`v 13 [
dehaḥ patatu vodetu kā naḥ kṣatirupasthitā |
ko naṣṭaḥ prakṣate puṣpe āmodo vyomasaṃśrayaḥ
]

`v 14 [
āpatantu vapuḥpadme sukhaduḥkhahimaśriyaḥ |
ākāśoḍḍayanālīnāṃ kā naḥ kṣatirupasthitā
]

`v 15 [
dehaḥ patatu vodetu yātu vā gaganāntaram |
tadvilakṣaṇarūpasya kāsau bhavati me kṣatiḥ
]

`v 16 [
yathā payodamarutoryathā ṣaṭpadapadmayoḥ |
tathā rāghava saṃbandhastvaccharīratvadātmanoḥ
]

`v 17 [
mano rāma śarīraṃ hi jagataḥ sakalasya ca |
ādyā śaktiścidadhyātmā na naśyati kadācana
]

`v 18 [
yo'sāvātmā mahāprājña na naśyati na gacchati |
na naśyati kadācicca kiṃ mudhā paritapyase
]

`v 19 [
ātmanāśādibhrāntereva sarvaśokādimūlatvāttāṃ punaḥ punarvārayannāha ##-
viśīrṇe'bhre yathā vātaḥ śuṣke'bje ṣaṭpado yathā |
yātyanantapadaṃ vyoma tathātmā dehasaṃkṣaye
]

`v 20 [
saṃsāre'sminviharato mano'pi hi na naśyati |
jñānāgninā vinā jantorātmanāśe tu kā kathā
]

`v 21 [
yaḥ kuṇḍabadaranyāyo yo ghaṭākāśayoḥ kramaḥ |
sthitirdehātmanoḥ saiva savināśāvināśayoḥ
]

`v 22 [
badaraṃ hastamāyāti yathā sphuṭati kuṇḍake |
ātmā gaganamāyāti tathā calati dehake
]

`v 23 [
kumbhe gacchatyakumbhatvaṃ kumbhākāśo yathāmbare |
tiṣṭhatyevamayaṃ kṣīṇe dehe dehī nirāmayaḥ
]

`v 24 [
manodeho hi jantūnāṃ deśakālatirohitaḥ |
muhurmṛtipaṭācchannaḥ śaṭhe kiṃ paridevanā
]

`v 25 [
deśakālatirodhāne mūḍho'pi maraṇe naraḥ |
kiṃ bibheti mahābāho neha paśyati kaścana
]

`v 26 [
atastvaṃ vāsanāṃ rāma mithyaivāhamiti sthitām |
tyaja pakṣīśvaro vyomagamanotka ivāṇḍakam
]

`v 27 [
eṣā hi mānasī śaktiriṣṭāniṣṭanibandhanī |
anayaiva mudhā bhrāntyā svapnavatparikalpanā
]

`v 28 [
avidyaiṣā durantaiṣā duḥkhāyaiṣā vivardhate |
aparijñānamānaiṣā tanotīdamasanmayam
]

`v 29 [
eṣā tucchavadākā"aṃ tuṣāramalinaṃ yathā |
paripaśyati vibhrāntā svarūpasya svabhāvataḥ
]

`v 30 [
asadevedamārambhamantharaṃ sadivotthitam |
kalpitaṃ jagadābhogi dīrghasvapna ivaitayā
]

`v 31 [
bhāvanāmātra evāsyāḥ svarūpaṃ kartṛtāṃ gatam |
jagannāmāvilaṃ cakṣurvyomni bimbarucāmiva
]

`v 32 [
p. 371) 220
layamasyāḥ svarūpaṃ tvaṃ naya rāma vicāraṇāt |
yathā himaśilāyāstu tapanāddivasādhipaḥ
]

`v 33 [
himābhāvārthino'rkasya svodayenepsitaṃ yathā |
siddhyatyevaṃ vicāreṇa manonāśārthino'rthitam
]

`v 34 [
avidyā'saṃprabuddhā hi vitatānarthadurgamā |
nānendrajālakalanāṃ śambaro hema varṣati
]

`v 35 [
svavināśakriyāṃ caitāṃ mana eva karotyalam |
mano hyātmavadhaṃ nāma nāṭakaṃ parinṛtyati
]

`v 36 [
ātmānamīkṣate cetaḥ svavināśāya kevalam |
nahi jānāti durbuddhirvināśaṃ pratyupasthitam
]

`v 37 [
svayaṃ saṃkalpamātreṇa svavināśadṛśāmidam |
manaḥ saṃsādhayatyāśu kleśo nātropayujyate
]

`v 38 [
svasaṃkalpavikalpāṃśaṃ vivekopahitaṃ manaḥ |
saṃtyajya rūpamābhogi karotyātmāvabodhanam
]

`v 39 [
mahodayo manonāśo mahocchedasya tūdayaḥ |
manonāśe prayatnaṃ tvaṃ kuru mā manaso jave
]

`v 40 [
aviralasukhaduḥkhavṛkṣakhaṇḍe
viṣamakṛtāntamahorage vane'smin |
prabhuridamakhile vivekahīnaṃ
subhaga mano mahadāpadekahetuḥ
]

`v 41 [
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]