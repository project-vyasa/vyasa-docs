`v 1 [
aṣṭanavatitamaḥ sargaḥ 98
śrīvasiṣṭha uvāca |
yataḥkutaścidutpannaṃ cittaṃ yatkiṃcideva hi |
nityamātmavimokṣāya yojayedyatnato'nagha
]

`v 2 [
nityamuktasyāpyātmano'jñānānmanobhrāntikṛto bandhapratyaya ityevaṃ
nirṇayāya manaso'jñātādātmana utpattirvistareṇoktā rogatattvanirṇayāyeva
roganidānāpathyāśanoktirityam | nirṇīte tu manastattve sāṃprataṃ
taccikitsāprayatna evāvaśyaṃ kāryo na punaḥ punarnidānacintāyāḥ
prayojanamastītyāśayenāha - yataḥkutaściditi | yojayet ātmani samādadhyāt |
1 |
saṃyojitaṃ pare cittaṃ śuddhaṃ nirvāsanaṃ bhavet |
tatastu kalpanāśūnyamātmatāṃ yāti rāghava
]

`v 3 [
cittāyattamidaṃ sarvaṃ jagatsthiracarātmakam |
cittādhīnavato rāma bandhamokṣāvapi sphuṭam
]

`v 4 [
atrārthe kathyamānaṃ me cittākhyānamanuttamam |
brahmaṇā yatpurā proktaṃ śṛṇu rāmātiyatnataḥ
]

`v 5 [
asti rāmāṭavī sphārā śūnyāśāntātibhīṣaṇā |
yojanānāṃ śataṃ yasyāṃ lakṣyate kaṇamātrakam
]

`v 6 [
tasyāmeko hi puruṣaḥ sahasrakaralocanaḥ |
paryākulamatirbhīmaḥ saṃsthito vitatākṛtiḥ
]

`v 7 [
p. 362) 216
sa sahasreṇa bāhūnāmādāya parighānbahūn |
praharasyātmanaḥ pṛṣṭhe svātmanaiva palāyate
]

`v 8 [
dṛḍhaprahāraiḥ praharansvayamevātmanātmani |
pravidravati bhītātmā sa yojanaśatānyapi
]

`v 9 [
krandanpalāyamāno'sau gatvā dūramitastataḥ |
śramavānvivaśākāro viśīrṇacaraṇāṅgakaḥ
]

`v 10 [
patito'vaśa evāśu mahatyandho'ndhakūpake |
kṛṣṇarātritamobhīme nabhogambhīrakoṭare
]

`v 11 [
tataḥ kālena bahunā so'ndhakūpātsamutthitaḥ |
punaḥ prahāraiḥ praharanvidravatyātmanātmanaḥ
]

`v 12 [
punardūrataraṃ gatvā karañjavanagulmakam |
praviṣṭaḥ kaṇṭakavyāptaṃ śalabhaḥ pāvakaṃ yathā
]

`v 13 [
tasmātkarañjagahanādviniḥsṛtya kṣaṇādiva |
punaḥ prahāraiḥ praharanvidravatyātmanātmanaḥ
]

`v 14 [
punardūrataraṃ gatvā śaśāṅkakaraśītalam |
kadalīkānanaṃ kāntaṃ saṃpraviṣṭo hasanniva
]

`v 15 [
kadalīkhaṇḍakāttasmādviniḥsṛtya kṣaṇātpunaḥ |
svayaṃ prahāraiḥ praharanvidravatyātmanātmani `note[ātmana iti
pāṭhaḥ]
]

`v 16 [
punardūrataraṃ gatvā tamevāndho'ndhakūpakam |
sa saṃpraviṣṭastvarayā viśīrṇāvayavākṛtiḥ
]

`v 17 [
andhakūpātsamutthāya praviṣṭaḥ kadalīvanam |
kadalīkānanācchvabhraṃ karañjavanagulmakam
]

`v 18 [
karañjakānanātkūpaṃ kūpādrambhāvanāntaram |
praviśanpraharaṃścaiva svayamātmani saṃsthitaḥ
]

`v 19 [
evaṃrūpanijācāraḥ so'valokya ciraṃ mayā |
avaṣṭabhya balādeva muhūrtaṃ rodhitaḥ pathi
]

`v 20 [
pṛṣṭaḥ sa kastvaṃ kimidaṃ kenārthena karoṣi vā |
kiṃ nāmābhimataṃ te'tra kiṃ mudhā parimuhyasi
]

`v 21 [
iti pṛṣṭena kathitaṃ tena me raghunandana |
nāhaṃ kaścinna caivedaṃ mune kiṃcitkaromyaham
]

`v 22 [
tvayāhamavabhagno'smi tvaṃ me śatruraho bata |
tvayā dṛṣṭo'smi naṣṭo'smi duḥkhāya ca sukhāya ca
]

`v 23 [
ityuktvā viklavānyaṅgānyālokya svānyatuṣṭimān |
rurodātiravaṃ dīno megho varṣannivāṭavīm
]

`v 24 [
kṣaṇamātreṇa tatrāsāvupasaṃhṛtya rodanam |
svānyaṅgāni samālokya jahāsa ca nanāda ca
]

`v 25 [
athāṭṭahāsaparyante sa pumānpurato mama |
krameṇa tāni tatyāja svānyaṅgāni samaṃtataḥ
]

`v 26 [
prathamaṃ patitaṃ tasya śiraḥ paramadāruṇam |
tataste bāhavaḥ paścādvakṣastadanu codaram
]

`v 27 [
saṃkalpātmakaṃ śiraḥ tadeva sarvānarthamūlatvātparamadāruṇam bāhavo
vikalpāśayāḥ viṣayābhiniveśo vakṣaḥ tṛṣṇā udaramiti yogyatayā kalpyam | 26
|
atha kṣaṇena sa pumāṃstānyaṅgāni yathākramam |
saṃtyajya niyateḥ śaktyā kvāpi gantumupasthitaḥ
]

`v 28 [
dṛṣṭavānahamekānte punaranyaṃ tathā naram |
so'pi prahārānparitaḥ prayacchansvayamātmani
]

`v 29 [
bāhubhiḥ pīvarākāraiḥ svayameva palāyate |
kūpe patati kūpāttu samutthāyābhidhāvati
]

`v 30 [
punaḥ patati kuṇḍe'ntaḥ punarārtaḥ palāyate |
punaḥ praviśati śvabhraṃ kṣaṇaṃ śiśirakānanam
]

`v 31 [
kuṇḍe'ndhakūpe | śvabhraṃ karañjavanagartam | śiśirakānanaṃ kadalīvanam | 30
|
kaṣṭaṃ punaḥpunastuṣṭaḥ punaḥ praharati svayam |
evaṃprāyanijācāraściramālokya sasmayam
]

`v 32 [
sa mayā samavaṣṭabhya paripṛṣṭastathaiva hi |
tenaivasau krameṇādya ruditvā saṃprahasya ca
]

`v 33 [
aṅgairviśīrṇatāmetya yayāvalamalakṣyatām |
vicārya niyateḥ śaktiṃ tato gantumupasthitaḥ
]

`v 34 [
dṛṣṭavānahamekānte punaranyaṃ tathā naram |
praharaṃstadvadevāsau svayameva palāyate
]

`v 35 [
palāyāmanaḥ patito mahatyandhe'ndhakūpake |
tatrāhaṃ suciraṃ kālamavasaṃ tatpratīkṣakaḥ
]

`v 36 [
yāvatsa sucireṇāpi kūpānnābhyuditaḥ śaṭhaḥ |
athāhamutthito gantuṃ dṛṣṭavānpuruṣaṃ punaḥ
]

`v 37 [
tādṛśaṃ tādṛśākāraṃ prapatantaṃ tathaiva ca |
avaṣṭabhya tathaivāśu tasya proktaṃ punarmayā
]

`v 38 [
p. 363) 216
tathaivotpalapatrākṣa nāsau tadavabuddhavān |
kevalaṃ māmasau mūḍho naiva jānāsi kiṃcana
]

`v 39 [
āḥ pāpa durdvijetyuktvā svavyāpāraparo yayau |
atha tasminmahāraṇye tathā viharatā mayā
]

`v 40 [
bahavastādṛśā dṛṣṭāḥ puruṣā doṣakāriṇaḥ |
matpṛṣṭāḥ kecidāyānti svapnasaṃbhramavacchamam
]

`v 41 [
maduktaṃ nābhinandanti kecicchavatanuṃ yathā |
vinipatyāndhakūpebhyaḥ kecittatprotthitāḥ punaḥ
]

`v 42 [
kadalīkhaṇḍakātkeciccireṇāpi na nirgatāḥ |
kecidantarhitāḥ sphāre karañjavanagulmake
]

`v 43 [
na kvacitsthitimāyānti keciddharmaparāyaṇāḥ |
evaṃvidhā sā vitatā raghūdvaha mahāṭavī
]

`v 44 [
matpṛṣṭā mayā bodhitāḥ santaḥ śamaṃ
prāguktasvarūpanāśalakṣaṇamuparamam
]

`v 45 [
sā bhīṣaṇā vividhakaṇṭakasaṅkaṭāṅgī
ghorāṭavī ghanatabhogahanāpi loke |
āgatya nirvṛtimalabdhaparāvabodhai-
rāsevyate kusumagulmakavāṭikeva `note[kusumapradhānā gulmakā
yasmiṃstatkusumagulmakaṃ kānanaṃ tadrūpā vāṭiketyarthaḥ |
etatphalitārthakaiva kusumakānanetyādiṣṭīkā]
]