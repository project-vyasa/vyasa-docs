`v 1 [
p. 287) 176
catuḥṣaṣṭitamaḥ sargaḥ 64
śrīvasiṣṭha uvāca |
yo'yaṃ sarvagato devaḥ paramātmā maheśvaraḥ |
svacchaḥ svānubhavānandasvarūpo'ntādivarjitaḥ
]

`v 2 [
etasmātparamānandācchuddhacinmātrarūpiṇaḥ |
jīvaḥ saṃjāyate pūrvaṃ sa cittaṃ cittato jagat
]

`v 3 [
śrīrāma uvāca |
svānubhūtipramāṇe'sminbrahmaṇi brahmabṛṃhite |
kathaṃ sattāmavāpnoti jīvako dvaitavarjite
]

`v 4 [
śrīvasiṣṭha uvāca |
asadābhāsamacchātma brahmāstīha prabṛṃhitam |
bṛhaccidbhairavavapurānandābhidhamavyayam
]

`v 5 [
tasya yatsamamāpūrṇaṃ śuddhaṃ satvamacihnitam |
tadvidāmapyanirdeśyaṃ tacchantaṃ paramaṃ padam
]

`v 6 [
tasyaivodyadivāśānti yatsattvaṃ saṃvidātmakam |
svabhāvātspandanaṃ tattu jīvaśabdena kathyate
]

`v 7 [
tatremāḥ paramādarśe cidvyomnyanubhavātmikāḥ |
asaṃkhyāḥ pratibimbanti jagajjālaparamparāḥ
]

`v 8 [
brahmaṇaḥ sphuraṇaṃ kiṃcidyadavātāmbudheriva |
dīpasyevāpyavātasya taṃ jīvaṃ viddhi rāghava
]

`v 9 [
śāntatvāpagame'cchasya manāksaṃvedanātmakam |
svābhāvikaṃ yatsphuraṇaṃ cidvyomnaḥ so'ṅga jīvakaḥ
]

`v 10 [
yathā vātasya calanaṃ kṛśānoruṣṇatā yathā |
śītatā vā tuṣārasya tathā jīvatvamātmanaḥ
]

`v 11 [
cidrūpasyātmatattvasya svabhāvavaśataḥ svayam |
manāksaṃvedanamiva yattajjīva iti smṛtam
]

`v 12 [
tadeva ghanasaṃvittyā yātyahaṃtāmanukramāt |
vahnyaṇuḥ svendhanādhikyātsvāṃ prakāśakatāmiva
]

`v 13 [
yathā svatārakāmārge vyomnaḥ sphurati nīlimā |
śūnyasyāpyasya jīvasya tathāhaṃbhāvabhāvanā
]

`v 14 [
jīvo'haṃkṛtimādatte saṃkalpakalayeddhayā |
svayaitayā ghanatayā nīlimānamivāmbaram
]

`v 15 [
ahaṃbhāvo hi dikkālavyavacchedī kṛtākṛtiḥ |
svayaṃ saṃkalpavaśato vātaspanda iva sphuran
]

`v 16 [
saṃkalponmukhatāṃ yātastvahaṃkārābhidhaḥ sthitaḥ |
cittaṃ jīvo mano māyā prakṛtiśceti nāmabhiḥ
]

`v 17 [
tatsaṃkalpātmakaṃ ceto bhūtatanmātrakalpanam |
kurvaṃstato vrajatyeva saṃkalpādyāti pañcatām
]

`v 18 [
p. 288) 177
tanmātrapañcakākāraṃ cittaṃ tejaḥkaṇo bhavet |
ajātajagati vyomni tārakā pelavā yathā
]

`v 19 [
tejaḥkaṇatvamādatte cittaṃ tanmātrakalpanāt |
śanaiḥ svasmātparispandādbījamaṅkuratāmiva
]

`v 20 [
asau tejaḥkano'ṇḍākhyaḥ kalpanātkaścidaṇḍatām |
prayātyantaḥsphuradbrahmā jalamāpiṇḍatāmiva
]

`v 21 [
kaściddrāgiti dehādikalanādyāti dehatām |
bhrāntitvaṃ tadatadrūpaṃ gandharvaiśca vasatpuram
]

`v 22 [
kaścitsthāvaratāmeti kaścijjaṃgamatāmapi |
kaścidyāti khacāryādirūpaṃ saṃkalpataḥ svataḥ
]

`v 23 [
sargādāvādijo deho jīvaḥ saṃkalpasaṃbhavaḥ `note[bhāvanaḥ iti
pāṭhaḥ] |
krameṇa padamāsādya vairiñcaṃ kurute jagat
]

`v 24 [
ātmabhūkalanātmāsau yatsaṃkalpayati kṣaṇāt |
tatsvabhāvavaśādeva jātameva prapaśyati
]

`v 25 [
citsvabhāvātsamāyātaṃ brahmatvaṃ sarvakāraṇam |
saṃsṛtau kāraṇaṃ paścātkarma nirmāya saṃsthitam
]

`v 26 [
cittaṃ svabhāvātsphurati cittaḥ phena ivāmbhasaḥ |
karmabhirbadhyate paścāḍḍiṇḍīramiva rajjubhiḥ
]

`v 27 [
saṃkalpaḥ kalanābījaṃ tadātmaiva hi jīvakaḥ |
karma paścāttanotyuccairutthāyākarmataḥ kramāt
]

`v 28 [
kroḍīkṛtāṅkuraṃ pūrvaṃ jīvo dhatte svajīvitam |
paścānnānātvamāyāti patrāṅkuraphalakramaiḥ
]

`v 29 [
anye sva eva ye jīvā evamevākṛtiṃ gatāḥ |
pūrvotpanne jagati te yānti bhūtāśrayāṃ sthitim
]

`v 30 [
svakarmabhistato janmamṛtikāraṇatāṃ gataiḥ |
prayāntyūrdhvamadhastādvā karma citspanda ucyate
]

`v 31 [
citspandanaṃ bhavati karma tadeva daivaṃ
cittaṃ tadeva mavatīha śubhāśubhādi |
tasmājjaganti bhuvanāni bhavanti pūrvaṃ
bhūtvā nijāṅgakusumāni tarorivādyāt
]