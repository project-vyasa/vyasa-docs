`v 1 [
ekanavatitamaḥ sargaḥ 91
bhānuruvāca |
tenaitadvacmi bhavaganyathākālaṃ mano mune |
anigrāhyamabhedyaṃ ca śāpairapi durāsadaiḥ
]

`v 2 [
aindavānāmataḥ sṛṣṭikramāṇāṃ pravināśanam |
yujyate na ca tadbrahmanyuktametanmahātmanaḥ
]

`v 3 [
kiṃ tadasti jagatyasminvividheṣu jagatsu ca |
tavāpi nātha nāthasya yaddainyāya mahātmanaḥ
]

`v 4 [
mano hi jagatāṃ kartṛ mano hi puruṣaḥ smṛtaḥ |
yanmanoniścayakṛtaṃ taddravyauṣadhidaṇḍanaiḥ
]

`v 5 [
hantuṃ na śakyate jantoḥ pratibimbaṃ maṇeriva |
tasmādete'tra tiṣṭhantu bhāsuraiḥ sargasaṃbhramaiḥ
]

`v 6 [
tvaṃ sṛṣṭveha prajāstiṣṭha buddhyākāśo hyanantakaḥ |
cittākāśaścidākāśa ākāśaśca tṛtīyakaḥ
]

`v 7 [
anantāstraya evaite cidākāśaprakāśitāḥ |
ekaṃ dvau trīnbahūnvāpi kuru sargāñjagatpate
]

`v 8 [
svecchayātmani tiṣṭha tvaṃ kiṃ gṛhītaṃ tavaindavaiḥ |
brahmovāca |
athaindavajagajjāle bhānunaivamudāhṛte
]

`v 9 [
mayā saṃcintya suciramidamuktaṃ mahāmune |
yuktamuktaṃ tvayā bhāno vitataṃ hi kilāmbaram
]

`v 10 [
manaśca vitataṃ vāpi cidākāśaśca vistṛtaḥ |
tadyathābhimataṃ sargaṃ nityakarma karomyaham
]

`v 11 [
kalpayāmi bahūnyāśu bhūtajālāni bhāskara |
tattvamevāśu bhagavanprathamo me manurbhava
]

`v 12 [
kuru sargaṃ yathākāmaṃ mayā samabhicoditaḥ |
athaitatsa mahātejā mama vākyaṃ prabhākaraḥ
]

`v 13 [
aṅgīkṛtya dvidhātmānaṃ cakāra tapatāṃvara |
ekena prāktanenāsminvapuṣā sūryatāṃ gataḥ
]

`v 14 [
vyomādhvagatayā sarge tatān divasāvalim |
manmanutvaṃ dvitīyena kṛtvā svavapuṣā kṣaṇāt
]

`v 15 [
sasarja sakalāṃ sṛṣṭiṃ tāṃ tāmabhimatāṃ mama
]

`v 16 [
etatte kathitaṃ sarvaṃ vasiṣṭhamanaso mune |
svarūpaṃ sarvakṛttvaṃ ca śaktatvaṃ ca mahātmanaḥ
]

`v 17 [
pratibhāsamupāyāti yadyadasya hi cetasaḥ |
tattatprakaṭatāmeti sthairyaṃ saphalatāmapi
]

`v 18 [
sāmānyabrāhmaṇā bhūtvā pratibhāsavaśātkila |
aindavā brahmatāṃ yātā manasaḥ paśya śaktatām
]

`v 19 [
yathā caindavajīvāste citratvādbrahmatāṃ gatāḥ |
vayaṃ tathaiva cidbhāvāccittatvādbrahmatāṃ gatāḥ
]

`v 20 [
cittaṃ hi pratibhāsātma yacca tatpratibhāsanam |
tadidaṃ bhāti dehādi svāntaṃ nānyāsti dehadṛk
]

`v 21 [
cittamātmacamatkāraṃ tacca tatkurute svataḥ |
yathāvatsaṃbhavaṃ svātmanyevāntarmaricādivat
]

`v 22 [
p. 346) 208
tadetaccittavadbhātamātivāhikanāmakam |
tadevodāharantyevaṃ dehanāmnā ghanabhramam
]

`v 23 [
kathyate jīvanāmnaitaccittaṃ pratanuvāsanam |
śāntadehacamatkāraṃ jīvaṃ viddhi kramātparam
]

`v 24 [
nāhaṃ na cānyadastīha citraṃ cittamidaṃ sthitam |
vasisṭhaindavasaṃvidvadasatsattāmivāgatam | 24 |
evaṃca tantubhyaḥ paṭa iva na kasyāpi deho nāma pṛthagastītyāha - nāhamiti
]

`v 25 [
yathaindava mano brahmā tathaivāyamahaṃ sthitaḥ |
tatkṛtaṃ cāhamevedaṃ saṃkalpātmaiva bhāsate
]

`v 26 [
kaściccittavilās'yaṃ brahmāhamiha saṃsthitaḥ |
svabhāva eva dehādi viddhi śūnyatarātmakhāt
]

`v 27 [
śuddhacitparamārthaikarūpiṇītyeva bhāvanāt |
jīvo bhūyo mano bhūtvā vettītthaṃ dehatāṃ mudhā
]

`v 28 [
sarvamaindavasaṃsāravadidaṃ bhāti cidvapuḥ |
saṃpannasaṃprabodhātmā svapno dīrghaḥ svaśaktijaḥ
]

`v 29 [
cidvapuḥ paramātmaiva aindavasaṃsāravatsarvātmā bhāti | yathā
svājñānaśaktijaḥ svapno dīrghaḥ sansaṃpannajāgradātmā bhāti tadvadityarthaḥ |
28 |
dvicandravibhramākāraṃ tanmātrābhāsapūrvakam |
aindavāmbaravadrūḍhaṃ cittādevākhilaṃ bhavet
]

`v 30 [
na sannāsadahaṃrūpaṃ sattāsatte tadeva ca |
upalambhena sadrūpamasatyaṃ tadvirodhataḥ
]

`v 31 [
jaḍājaḍaṃ mano viddhi saṃkalpātma bṛhadvapuḥ |
ajaḍaṃ brahmarūpatvājjaḍaṃ dṛśyātmatāvaśāt
]

`v 32 [
dṛśyānubhavasatyātma na sadbhāve vilāsi tat |
kaṭakatvaṃ yathā hemni tathā brahmaṇi saṃsthitam
]

`v 33 [
sarvatvādbrahmaṇaḥ sarvaṃ jaḍaṃ cinmayameva ca |
asmadādiśilāntātma na jaḍaṃ na ca cetanam
]

`v 34 [
evaṃ jagato'pi jaḍājaḍaviruddhasvabhāvatvānmāyikatvamevetyāśayenāha -
sarvatvāditi | asmadādiśilāntātma brahmādisthāvarāntaṃ yauktikadṛśā
viruddhasvabhāvamapi paramārthadṛśā na jāḍyacaitanyadharmakamityarthaḥ | 33
|
dārvādīnāmacittvena nopalambhasya saṃbhavaḥ |
upalambho hi sadṛśasaṃbandhādeva jāyate
]

`v 35 [
upalabdhe'jaḍe viddhi tenedaṃ sarvameva hi |
upalambho hi sadṛśasaṃbandhātsyātsamātmanoḥ
]

`v 36 [
jaḍacetanabhāvādiśabdārthaśrīrna vidyate |
anirdeśyapade patralatādīva mahāmarau
]

`v 37 [
cito yaccetyakalanaṃ tanmanastvamudāhṛtam |
cidbhāgo'trājaḍo bhāgo jāḍyamatra hi cetyatā
]

`v 38 [
cidbhāgo'trāvabodhāṃśo jaḍaṃ cetyaṃ hi dṛśyate |
iti jīvo jagadbhrāntiṃ paśyangacchati lolatām
]

`v 39 [
p. 347) 208
cittastha eva bhāvo'sau śuddha eva dvidhā kṛtaḥ |
ataḥ sarvaṃ jagatsaiva dvaitalabdhaṃ ca saiva tat
]

`v 40 [
svamevānyatayā dṛṣṭvā citirdṛśyatayā vapuḥ |
nirbhāgāpyekabhāgābhaṃ bhramatīva bhramāturā
]

`v 41 [
na bhrāntirasti bhramabhāṅgā naivetīha niścayaḥ |
paripūrṇārṇavaprakhyāvetītthaṃ saṃsthitā citiḥ
]

`v 42 [
sarvaṃ syājjāḍyamapyasyāścitiścittvaṃ ca vetsi tat |
cidbhāgoṃśo'vabodhasya tvahaṃtājaḍatodayaḥ
]

`v 43 [
ahaṃtādipare tattve manāgapi na vidyate |
ūrmyādīva pṛthaktoye saṃvitsāraṃ hi tadyataḥ
]

`v 44 [
ahaṃpratyayasaṃdṛśyaṃ cetyaṃ viddhi samutthitam |
mṛgatṛṣṇāmbvivāntasthaṃ nūnaṃ vidyata eva no
]

`v 45 [
ahaṃtāpadamantātmapadaṃ viddhi nirāmayam |
vidaṃ vidurahaṃtādi śaityameva yathā himam
]

`v 46 [
citteva cetyate jāḍyaṃ svapne svamaraṇopamam |
sarvātmatvātsarvaśaktīḥ kurvatī naiti sāmyatām
]

`v 47 [
manaḥ padārthāditayā sarvarūpaṃ vijṛmbhate |
nānātmācittadeho'yamākāśaviśadākṛtiḥ
]

`v 48 [
dehādidehapratibhārūpātmyaṃ tyajatā satā |
vicāryaṃ pratibhāsātma cittaṃ cittena vai svayam
]

`v 49 [
cittatāmre śodhite hi paramārthasuvarṇatām |
gate'kṛtrima ānandaḥ kiṃ dehopalakhaṇḍakaiḥ
]

`v 50 [
yadvidyate śodhyate tadbodhaḥ ke ca svapādapāḥ |
dehādyavidyā satyā cedyukta etāṃ prati grahaḥ
]

`v 51 [
asatyaviniviṣṭānāṃ dehavācitayā tviha |
ye nāmopadiśantyajñāḥ kiṃcitte puruṣaiḍakāḥ
]

`v 52 [
yathaitadbhāvayetsvāntaṃ tathaiva bhavati kṣaṇāt |
dṛṣṭānto'traindavāhalyākṛtrimendrādiniścayāḥ
]

`v 53 [
yadyadyathā sphurati supratibhātmacittaṃ
tattattathā bhavati dehatayoditātma |
deho'yamasti na na cāhamiti svarūpaṃ
vijñānamekamavagamya niricchamāssva
]

`v 54 [
deho'yameṣa ca kilāyamiti svabhāvā-
ddeho'yametadakhilaṃ tata eti nāśam |
yakṣādikalpanavaśādbhayameti bālo
niryakṣadehagata eva kayāpi yuktyā
]