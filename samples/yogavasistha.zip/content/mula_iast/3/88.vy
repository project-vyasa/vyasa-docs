`v 1 [
p. 341) 205
aṣṭāśītitamaḥ sargaḥ 88
śrībrahmovāca |
brahmāṇo brāhmaṇā bhānurityuktvā brahmaṇo mama |
brahmanbrahmavidāṃ śreṣṭha tūṣṇīmeva babhūva saḥ
]

`v 2 [
tata uktaṃ mayā tasya ciraṃ saṃcintya cetasā |
bhāno bhāno vadāśu tvaṃ kimanyatsaṃsṛjāmyaham
]

`v 3 [
etāni daśa vidyante kila yatra jaganti vai |
tatrānyo mama sargeṇa ko'rthaḥ kathaya bhāskara
]

`v 4 [
ityukto'tha mayā bhānuḥ saṃcintya suciraṃ dhiyā |
idamatra vaco yuktamuvāca sa mahāmune
]

`v 5 [
bhānuruvāca |
nirīhasya niricchasya ko'rthaḥ sargeṇa te prabho |
vinodamātramevedaṃ sṛṣṭistava jagatpate
]

`v 6 [
niṣkāmādeva bhavataḥ sargaḥ saṃpadyate prabho |
arkādiva jalādityapratibimbamivādhiyaḥ
]

`v 7 [
śarīrasaṃniveśasya tyāge rāge ca te yadā |
niṣkāmo bhagavanbhāvo nābhivāñchati nojjhati
]

`v 8 [
sṛjasīdaṃ tathā deva vinodāyaiva bhūtapa |
punaḥ saṃhṛtya saṃhṛtya dinaṃ dinapatiryathā
]

`v 9 [
tava nityamasaṃsaktaṃ vinodāyaiva kevalam |
idaṃ kartavyameveti jaganna tūdyamecchayā
]

`v 10 [
sṛṣṭiṃ cenna karoṣi tvaṃ maheśa `note[maheccha iti pāṭhaḥ tatra he
maheccha mahāśayetyarthaḥ] paramātmanaḥ |
nityakarmaparityāgātkimapūrvamavāpsyasi
]

`v 11 [
yathāprāptaṃ hi kartavyamasaktena sadā satā |
mukureṇākalaṅkena pratibimbakriyā yathā
]

`v 12 [
yathaiva karmakaraṇe kāmanā nāsti dhīmatām |
tathaiva karmasaṃtyāge kāmanā nāsti dhīmatām
]

`v 13 [
ataḥ suṣuptopamayā dhiyā niṣkāmayā tayā |
suṣuptabuddhasamayā kuru kāryaṃ yathāgatam
]

`v 14 [
sargairathenduputrāṇāṃ toṣameṣi jagatprabho |
tadete toṣayiṣyanti taṃ tvāṃ sargātsureśvara
]

`v 15 [
cittanetrairbhavānetānsargānanyasya no dṛśā |
avaśyaṃ cakṣuṣā sargaṃ sṛṣṭamityeva vetti kaḥ
]

`v 16 [
yenaiva manasā sargo nirmitaḥ parameśvara |
sa eva māṃsanetreṇa taṃ paśyati hi netaraḥ
]

`v 17 [
na caitāndaśa saṃsārāndaśa nīrajasaṃbhavān |
kaścinnāśayituṃ śaktaścittadārḍhyāccirasthitān
]

`v 18 [
karmendriyairyatkriyate tadroddhuṃ kila yujyate |
na manoniścayakṛtaṃ kaścidrodhayituṃ kṣamaḥ
]

`v 19 [
yo baddhapadatāṃ yāto jantormanasi niścayaḥ |
sa tenaiva vinā brahmannānyena vinivāryate
]

`v 20 [
bahukālaṃ yadabhyastaṃ manasā dṛḍhaniścayam |
śāpenāpi na tasyāsti kṣayo naṣṭe'pi dehake
]

`v 21 [
p. 342) 206
yadvaddhapīṭhamabhito manasi prarūḍhaṃ
tadrūpameva puruṣo bhavatīha nānyat |
tadbodhanāditaramatra kilābhyupāyaṃ
śailaughasekamiva niṣphalameva manye
]