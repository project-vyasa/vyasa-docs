`v 1 [
pañcāśaḥ sargaḥ 50
śrīvasiṣṭha uvāca |
tasmiṃstadā vartamāne ghore samaravibhrame |
sarvārisainyanāśārthamekaṃ svabalaśāntaye
]

`v 2 [
ekamasādhāraṇam | svabalasya svasainyasya śāntaye rakṣaḥpiśācapīḍāśāntaye |
1 |
sasmāra smṛtimānanto mahodārādhidhairyabhṛt |
astramastreśvaraṃ śrīmadvaiṣṇavaṃ śaṃkaropamam
]

`v 3 [
atha yo'sau śarastena vaiṣṇavāstrābhimantritaḥ |
muktastasya phalaprāntādulmukā divi niryayau
]

`v 4 [
paṅktayaḥ sphāracakrāṇāṃ śatārkīkṛtadiktaṭāḥ |
gadānāmabhiyāntīnāṃ śatavaṃśīkṛtāmbarāḥ
]

`v 5 [
vajrāṇāṃ śatadhārāṇāṃ tṛṇarājīkṛtāmbarāḥ
`note[taracchṛṅgīkṛtāmbarā iti pāṭhaḥ] |
paṭṭiśānāṃ sapadmānāṃ dīnavṛkṣīkṛtāmbarāḥ
]

`v 6 [
śarāṇāṃ śitadhārāṇāṃ puṣpajālīkṛtāmbarāḥ
`note[tṛṇajālīkṛtāmbarā iti pāṭhaḥ] |
khaḍgānāṃ śyāmalāṅgānāṃ patrarāśīkṛtāmbarāḥ
]

`v 7 [
atha rājā dvitīyo'pi vaiṣṇavāstrasya śāntaye |
dadau vaiṣṇavamevāstraṃ śatruniṣṭhāvapūrakam
]

`v 8 [
tato'pi niryayurnadyo hetīnāṃ hatahetayaḥ |
śaraśaktigadāprāsapaṭṭiśādipayomayāḥ
]

`v 9 [
śastrāstrasaritāṃ tāsāṃ vyomni yuddhamavartata |
rodorandhrakṣayakaraṃ kulaśailendradāraṇam
]

`v 10 [
śarapātitaśūlāsikhaḍgakuṭṭitapaṭṭiśam `note[śarāpatita iti
ṭīkākārasammataḥ pāṭhaḥ] |
musalapratanāprāsaśūlaśātitaśaktikam
]

`v 11 [
śarāmburāśimathanamattamudgaramandaram |
gadāvadanato yuktaṃ durvārāstrinibhāsini
]

`v 12 [
riṣṭāriṣṭapraśamanabhramatkuntendumaṇḍalam |
prāsaprasarasaṃrabdhaprodyatāntakṛtāntakam
]

`v 13 [
p. 251) 150
cakrāvakuṇṭhitordhvāstraṃ sarvāyudhakṣayaṃkaram |
śabdasphuṭadviriñcāṇḍaṃ ghātabhagnakulācalam
]

`v 14 [
dhārānikṛttaśastraughamastrayoryudhyamānayoḥ |
madastravāraṇeneva vajrāvijaraparvatam
]

`v 15 [
śaṅkuśaṅkitasūtkārakāśiśūlaśilāśatam |
bhuśuṇḍīnirjitoddaṇḍabhindipālogramaṇḍalam
]

`v 16 [
paraśūlakarābhaikaparaśūlaikalampitam |
vahaducchinnacañcūracāraṇaṃ śatruvāraṇam
]

`v 17 [
sphuṭaccaṭacaṭāsphoṭaruddhattripathagārayam `note[ruddhatripathagā iti
pāṭhaḥ] |
hetyastrīcūrṇasaṃbhāramahādhūmavitānakam
]

`v 18 [
anyonyaśastrasaṃghaṭṭādbhramajjālollasattaḍit |
śabdasphuṭadviriñcāṇḍaṃ dhātamagnakulācalam
]

`v 19 [
dhārānikṛttaśastraughamastrayoryudhyamānayoḥ |
madastravāraṇenaiva kālopāyo'calātmanaḥ
]

`v 20 [
ayaṃ kiyadbala iti sindhau tiṣṭhati helayā |
vidūratho'stramāgneyaṃ tatyājāśaniśabdavat
]

`v 21 [
jvālayāmāsa sa rathaṃ sindhoḥ kakṣamivārasam |
etasminnantare vyomni hetinirvivarodare
]

`v 22 [
sasannāha iva prāvṛṭpayodataṭinīva yaḥ |
astre rājñoḥ kṣaṇaṃ kṛtvā yuddhaṃ paramadāruṇam
]

`v 23 [
anyonyaṃ śamamāyāte savīrye subhaṭāviva |
etasminnantare so'gnī rathaṃ kṛtvā tu bhasmasāt
]

`v 24 [
prāpa dagdhvā vanaṃ sindhuṃ mṛgendramiva kandarāt |
sindhurabhyāsato'gnyastraṃ vāruṇāstreṇa śāmayan
]

`v 25 [
rathaṃ tyaktvāvaniṃ prāpya khaḍgāsphoṭakavānabhūt |
akṣṇornimeṣamātreṇa rathāśvānāṃ ripoḥ khurān
]

`v 26 [
lulāva karavālena mṛṇālānīva lāghavāt |
vidūratho'pi viratho babhūvāsphoṭakāsimān
]

`v 27 [
samāyudhau samotsāhau ceraturmaṇḍalāni tau |
khaḍgau krakacatāṃ yātau mithaḥ praharatostayoḥ
]

`v 28 [
krakacatāṃ krakacavatkaṭhinataracarmādividāraṇasamarthatāṃ yātau prāptau | 27
|
dantamāleyamasyeva bale carvayataḥ prajāḥ |
śaktimādāya cikṣepa khaḍgaṃ tyaktvā vidūrathaḥ
]

`v 29 [
sindhvambughargarārāvo mahotpāta ivāśaniḥ |
avicchinnā samāyātā patitā sāsya vakṣasi
]

`v 30 [
apriyasya yathā bharturanicchantī svakāminī |
tena śaktiprahāreṇa nāsau maraṇamāptavān
]

`v 31 [
kevalaṃ rudhiravrātaṃ nāgo jalamivātyajat |
taddeśalīlā taṃ dṛṣṭvā bhagnaṃ tama ivendunā
]

`v 32 [
savikāsaghanānandā pūrvalīlāmuvāca ha |
devi paśya nṛsiṃhena hato bhartrāyamāvayoḥ
]

`v 33 [
āvayorbhartrā nṛsiṃhena sindhurdaityo hiraṇyakaśipurhata iti vyastarūpakam | 32
|
śaktikoṭinakhairdaityaḥ sindhuruddhurakandharaḥ |
saraḥsthalasthanāgendrakaraphūtkṛtavārivat
]

`v 34 [
piṣṭo raso'sya niryāti raktaṃ culaculāravaiḥ |
hā kaṣṭaṃ rathamānītaṃ sindhurāroḍhumudyataḥ
]

`v 35 [
sauvarṇaṃ mairavaṃ śṛṅgaṃ puṣkarāvartako yathā |
paśya devi ratho'syāsau mudgareṇa vicūrṇitaḥ
]

`v 36 [
bhramtpārthanipātena sauvarṇaṃ nagaraṃ yathā |
pravṛtto rathamāroḍhumānītaṃ patireṣa me
]

`v 37 [
p. 252) 151
kaṣṭaṃ vajramivendreṇa musalaṃ sindhunekṣitam |
javātpatiḥ prayāto me saindhavaṃ musalāyudham
]

`v 38 [
vañcayitvā vilāsena rathamāruhya lāghavāt |
hā dhikkaṣṭamasau sindhurāryaputrarathaṃ rayāt
]

`v 39 [
hariśvabhramivārūḍhaṃ plavenordhvamiva drumam |
krīḍitvā pīḍayāmāsa śaravarṣirvidūratham
]

`v 40 [
chinnadhvajaṃ chinnarathaṃ chinnāśvaṃ chinnasārathim |
chinnakārmukavarmāṇaṃ bhinnasarvāṅgamākulam
]

`v 41 [
hṛdi sphoṭaśilāpaṭṭadṛḍhe pīvaramūrdhani |
bhittvā vajrasamairbāṇaiḥ pātayatyeṣa bhūtale
]

`v 42 [
athānyaṃ rathamānītaṃ kṛcchreṇa prāpya cetanām |
khaḍgenārohato'syāṃsaṃ chinnaṃ bharturvilokaya
]

`v 43 [
padmarāgagiridyotamivarddhāsṛgvimuñcati |
hā hā dhikkaṣṭametena sindhunā khaḍgadhārayā
]

`v 44 [
jaṅghayorme patiśchinnaḥ krakaceneva pādapaḥ |
hā hā hatāsmi dagdhāsmi mṛtāsmyupahatāsmi ca
]

`v 45 [
mṛṇāle iva patyurme lūne dve api jānunī |
ityuktvā sā tadālokya bharturbhāvabhayāturā
]

`v 46 [
latā paraśukṛtteva mūrcchitā bhuvi sāpatat |
vidūratho'pi nirjānuḥ praharanneva vidviṣi
]

`v 47 [
papāta syandanasyādhaśchinnamūla iva drumaḥ |
patannevaiṣa sūtena rathenaivāpavāhitaḥ
]

`v 48 [
yadā tadāhatiṃ tasya kaṇṭhe'dātsindhuruddhataḥ |
ardhavicchinnakaṇṭha'sāvanuyāto'tha sindhunā
]

`v 49 [
syandanenāviśatsadma padmaṃ ravikaro yathā |
sarasvatyāḥ prabhāvāḍhyaṃ tatpraveṣṭumasau gṛham |
nāśakanmaśako matto mahājvālodaraṃ yathā
]

`v 50 [
khaḍgāvakṛttagalagartagalatsavāta-
raktacchaṭāchuritavastratanutragātram |
tatyāja taṃ bhagavatīmabhito gṛhāntaḥ
sūtaḥ praveśya mṛtitalpatale gato'riḥ
]