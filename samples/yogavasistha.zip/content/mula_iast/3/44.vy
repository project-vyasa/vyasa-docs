`v 1 [
catuścatvāriṃśaḥ sargaḥ 44
śrīvasiṣṭha uvāca |
etasminnantare rājamahiṣī mattayauvanā |
tadviveśa gṛhaṃ lakṣmīriva paṅkajakoṭaram
]

`v 2 [
ālolamālyavasanā bhinnahāralatākulā |
anuyātā vayasyābhirdāsībhirbhayavihvalā
]

`v 3 [
candrānanāvadātāṅgī śvāsotkampipayodharā |
tārakākāradaśanā sthitā dyauriva rūpiṇī
]

`v 4 [
atha tasyā vayasyaikā rājānaṃ taṃ vyajijhapat |
bhūtasaṃgrāmasaṃrabdhamamarendramivāpsarāḥ
]

`v 5 [
deva devī sahāsmābhiḥ palāyyāntaḥpurāntarāt |
śaraṇaṃ devamāyātā vātārteva latā drumam
]

`v 6 [
rājandārā hṛtāstāste balavadbhirudāyudhaiḥ |
ūrmijālairmahābdhīnāṃ tīradrumalatā iva
]

`v 7 [
antaḥpurādhipāḥ sarve piṣṭāḥ śatrubhiruddhataiḥ |
aśaṅkitābhipatitairvātairiva varadrumāḥ
]

`v 8 [
dūreṇāśaṅkamāyātaiḥ parairnaḥ puramāhṛtam |
rātrau varṣāsvivodghoṣaiḥ kamalānīva vāribhiḥ
]

`v 9 [
dūreṇa dūrāt | dūrāntikārthebhyo dvitīyā ca iti cāttṛtīyā | āhṛtamāskanditam |
8 |
p. 238)
dhūmaṃ varṣadbhirunnādairlelihānograhetibhiḥ |
vahnibhirnaḥ puraṃ prāptaṃ parayodhaiśca bhūribhiḥ
]

`v 10 [
parivārairvilāsinyo devya āhṛtya mūrdhajaiḥ |
ākrandantyo balānnītāḥ kurarya iva dhīvaraiḥ
]

`v 11 [
parivāraiḥ śatrusainikaiḥ | kuraryo mṛgyaḥ pakṣiṇyaśca | dhīvarairlubdhakaiḥ |
10 |
iti no yeyamāyātā śākhā prasaraśālinī |
āpattāmalamuddhartuṃ devasyaivāsti śaktatā
]

`v 12 [
ityākarṇyāvalokyāsau devyau yuddhāya yāmyataḥ |
kṣamyatāṃ mama bhāryeyaṃ yuṣmatpādābjaṣaṭpadī
]

`v 13 [
asau rājā iti vākyamākarṇya devyau vilokya uvāceti śeṣaḥ | he devyau ahaṃ
yuddhāya yāmi gacchāmi kṣamyatām | ājñāṃ vinaivāntarāle
nirgamanāparādhaḥ | yuṣmatpādābjaṣaṭpadīti yuvābhyāṃ rakṣaṇīyetyāśayaḥ |
12 |
ityuktvā niryayau rājā kopāruṇitalocanaḥ |
mattebhanirbhinnavanaḥ kandarādiva kesarī
]

`v 14 [
līlā līlāṃ dadarśātha svākārasadṛśākṛtim |
pratibimbamivāyātāmādarśe cārudarśanām
]

`v 15 [
prabuddhalīlovāca |
kimidaṃ devi he brūhi `note[me brūhīti pāṭhaḥ] kasmādiyamahaṃ sthitā |
yā sā'bhavamahaṃ pūrvaṃ kathaṃ seyamahaṃ sthitā
]

`v 16 [
mantriprabhṛtayaḥ paurā yodhāḥ sabalavāhanāḥ |
sarva eva ta eveme sthitāstatra tathaiva te
]

`v 17 [
tatrāpīha ca he devi sarve kathamavasthitāḥ |
bahirantaśca mukure ivaite kiṃ pracetanāḥ
]

`v 18 [
śrīdevyuvāca |
yathā jñaptirudetyantastathānubhavati kṣaṇāt |
citiścetyārthatāmeti cittaṃ cittārthatāmiva
]

`v 19 [
yādṛgarthaṃ jagadrūpaṃ tatraivodeti tatkṣaṇāt |
na deśakāladīrghatvaṃ na vaicitryaṃ padārthajam
]

`v 20 [
bāhyamābhyantaraṃ bhāti svapnārtho'tra nidarśanam |
yadantaḥ svapnasaṃkalpapuraṃ ca kacanaṃ citeḥ
]

`v 21 [
tadetadbāhyanāmnaiva svabhyāsātsatsphuṭaṃ sthitam |
yādṛgbhāvo bhṛto bhartā tava tasmiṃstadā pure
]

`v 22 [
tādṛgbhāvastamevārthaṃ tatraiva samupāgataḥ |
anya eva hyamī bhūtāstebhyastāstādṛśā api
]

`v 23 [
sadrūpā eva caitasya svapnasaṃkalpasainyavat |
avisaṃvādi sarvārtharūpaṃ yadanubhūyate
]

`v 24 [
tasya tāvadvada kathaṃ kīdṛśī vāpi satyatā |
athavottarakāle tu bhaṅguratvādavastu tat
]

`v 25 [
uttarakāle bādhyatvātsvapnasyāsatyatvaṃ cejjāgratyapi samānaṃ
nāśabādhayorvastuni viśeṣābhāvādityāśayenāha - athaveti | tatsvāpnam |
24 |
īdṛkca sarvamevedaṃ tatra kā nāstitādhikā |
svapne jāgradasadrūpā svapno jāgratyasanmayaḥ
]

`v 26 [
mṛtirjanmanyasadrūpā mṛtyāṃ janmāpyasanmayam |
viśaredviśarārutvādanubhūteśca rāghava
]

`v 27 [
nāśe'pi bādhavatparasparakālāsattvaṃ tulyamityāha - mṛtiriti | nāśe
avayavānāṃ viśarārutvāddravyaṃ viśarennaśyet | bādhe
tvanubhūteranubhavabalādviśaret | iti nimittabhede'pi na viśaraṇe viśeṣa ityarthaḥ |
26 |
evaṃ na sannāsadidaṃ bhrāntimātraṃ vibhāsate |
mahākalpāntasaṃpattāvapyadyātha yuge'nagha
]

`v 28 [
p. 239)
na kadācana yannāsti tadbrahmaivāsti tajjagat |
tasminmadhye kacantīmā bhrāntayaḥ sṛṣṭināmikāḥ
]

`v 29 [
vyomni keśoṇḍrakānīva na kacantīva vastutaḥ |
yathā taraṅgā jaladhau tathemāḥ sṛṣṭayaḥ pare
]

`v 30 [
utpattyotpattya līyante rajāṃsīva mahānile |
tasmādbhrāntimayābhāse mithyātvamahamātmani
]

`v 31 [
mṛgatṛṣṇājalacaye kaivāsthā sargabhasmani |
bhrāntayaśca na tatrānyāstāstadeva paraṃ padam
]

`v 32 [
ghane tamasi yakṣābhāstama eva na yakṣakaḥ |
tasmājjanmamṛtirmoho vyāmohatvamidaṃ tatam
]

`v 33 [
sarvaṃ tatsamahākalpaṃ śāntau yadavaśiṣyate |
nātaḥ satyamidaṃ dṛśyaṃ na cāsatyaṃ kadācana
]

`v 34 [
dvayamevaitadathavā brahma tatraiva saṃbhavāt |
ākāśe paramāṇvantardravyāderaṇuke'pi ca
]

`v 35 [
jīvāṇuryatra tatredaṃ jagadvetti nijaṃ vapuḥ |
agnirauṣṇyaṃ yathā vetti nijabhāvakramoditam
]

`v 36 [
vāsanābalenātmanyanātmādhyāse dṛṣṭāntamāha - agniriti |
pūrvamanagnirevopāsako'hamevāgnirityupāsanātmakanijabhāvanā##-
paśyatīdaṃ tathaivātmā svātmabhūtaṃ viśuddhacit |
yathā sūryodaye gehe bhramanti trasareṇavaḥ
]

`v 37 [
tatheme paramākāśe brahmāṇḍatrasareṇavaḥ |
yathā vāyau sthitaḥ spanda āmodaḥ śūnyamambare
]

`v 38 [
piṇḍagrahavinirmuktaṃ yathā viśvaṃ sthitaṃ pare |
bhāvābhāvagrahotsargasthūlasūkṣmacarācarāḥ
]

`v 39 [
vivarjitasyāvayavairbhāgā brahmaṇa īdṛśāḥ |
sākārasyāvabodhāya vijñeyā bhavatādhunā
]

`v 40 [
ananyāḥ svātmanastasya tenānavayavā iva |
yathāsthitamidaṃ viśvaṃ nijabhāvakramoditam
]

`v 41 [
riktaṃ na viśvaśabdārthairananyadbrahmaṇi sthitam |
na tatsatyaṃ na cāsatyaṃ rajjusarpabhramo yathā
]

`v 42 [
tatra hetuḥ - ananyaditi | tarhi yatsāvayavaṃ viśvaṃ bhāsate tatkiṃ tatrāha ##-
mithyānubhūtitaḥ satyamasatyaṃ satparīkṣitam |
paramaṃ kāraṇaṃ cittvājjīvatvamiti cetyalam
]

`v 43 [
tatastathaivānubhavājjīvatvaṃ vindati sphuṭam |
satyaṃ bhavatvasatyaṃ vā khe vibhātamidaṃ jagat
]

`v 44 [
anubhavāccirasaṃvedanadṛḍhānubhavāt | saṃsārasya ca jaivī bhogecchā
heturviṣayarañjanaivopayujyate na satyatvamasatyatvaṃ vetyāha - satyamiti | 43
|
rañjayatyeva jīvāṇuḥ svecchābhiranubhūtibhiḥ |
anubhūyanta evāśu kāścitpūrvānubhūtitaḥ
]

`v 45 [
apūrvānubhavāḥ kāścitsamāścaivāsamāstathā |
kvacitkadācittā eva kvacidardhasamā api
]

`v 46 [
p. 240)
kacantyasatyāḥ satyābhā jīvākāśe'nubhūtayaḥ |
tatkulāstatsamācārāstajjanmānastadīhitāḥ
]

`v 47 [
ta eva mantriṇaḥ paurāḥ pratibhāne bhavanti ca |
te caivātmanyalaṃ satyā deśakālehitaiḥ samāḥ
]

`v 48 [
sarvagātmasvarūpāyāḥ pratibhāyā iti sthitiḥ |
yathā rājātmani vyomni pratibhodeti sanmayī
]

`v 49 [
tathā tadagragodeti satyeva pratibhāmbare |
tvacchīlā tvatsamācārā tvatkulā tvadvapurmayī
]

`v 50 [
iti līleyamābhāti pratibhāpratibimbajā |
sarvage saṃvidādarśe pratibhā pratibimbati
]

`v 51 [
yādṛśī yatra sā tatra tathodeti nirantaram |
jīvākāśasya yāntasthā pratibhā kurute svayam |
sā bahiśca cidādarśe pratibimbādiyaṃ sthitā
]

`v 52 [
eṣā tvamambaramahaṃ bhuvanaṃ dharā ca
rājeti sarvamahameva vibhātamātram |
cidvyomabilvajaṭharaṃ viduraṅga viddhi
tvaṃ tena śāntamalamāssva yathāsthiteha
]