`v 1 [
saptaviṃśaḥ sargaḥ 27
śrīvasiṣṭha uvāca |
surāsurasabhājyeṣṭhe tasminbhṛgusute gate |
manasā cintayāmāsa balirbuddhimatāṃ varaḥ
]

`v 2 [
yuktamuktaṃ bhagavatā cidevedaṃ jagattrayam |
cidahaṃ cidime lokāścidāśāścidiyaṃ kriyā
]

`v 3 [
sabāhyābhyantaraṃ sarvaṃ cideva paramārthataḥ |
asti cidvyatirekeṇa neha kiṃcana kutracit
]

`v 4 [
ayamāditya ityarko na citā yadi cetyate |
tadarkatamasorbhedaḥ ka ihevopalabhyate
]

`v 5 [
iyaṃ bhūriti bhūreṣā citā yadi na cetyate |
bhūmeḥ kiṃ nāma bhūmitvaṃ tadbhavye bhavyatāṃ gatam
]

`v 6 [
imā diśo diśa iti cetyante na citā yadi |
tatkiṃ nāma diśāṃ diktvaṃ śailānāṃ cāpi kādritā
]

`v 7 [
idaṃ jagajjagaditi citā yadi na cetyate |
tatkiṃ jagattvaṃ jagato nabhastvaṃ nabhaso'tha kim
]

`v 8 [
kāyo'yaṃ parvatākāraścitā yadi na cetyate |
tatkiṃ nāma śarīratvaṃ śarīrasya śarīriṇām
]

`v 9 [
cidindriyāṇi citkāyaścinmanaścittadeṣaṇā |
cidantaścidbahiścitkhaṃ cidbhāvāścidbhavasthitiḥ
]

`v 10 [
citaivainamahaṃ sarvaṃ sparśanaiṣaṇapūrvakam |
karomi mātrāsaṃsparśaṃ śarīreṇa na kiṃcana
]

`v 11 [
kimanena śarīreṇa kāṣṭhaloṣṭasamena me |
aśeṣajagadekātmā cidahaṃ cetanātmakaḥ
]

`v 12 [
ahaṃ cidambare bhānāvahaṃ cidbhūtapañjare |
surāsureṣu cidahaṃ sthāvareṣu careṣu ca
]

`v 13 [
cidastīha dvitīyā hi kalpanaiva na vidyate |
dvitvasyāsaṃbhavālloke kaḥ śatruḥ kaśca vāsuhṛt
]

`v 14 [
balināmnaḥ śarīrasya cchinne śirasi bhāsure |
citaḥ kiṃ tadbhavecchinnaṃ sarvalokāvapūraṇāt
]

`v 15 [
citā saṃcetito dveṣo dveṣo bhavati nānyathā |
tasmāddveṣādayaḥ sarve bhāvābhāvāścidātmakāḥ
]

`v 16 [
na cito vyatirekeṇa pravicāryāpi kiṃcana |
āsādyate kila sphārādasmāttribhuvanodarāt
]

`v 17 [
na dveṣo'sti na rāgo'sti na mano nāsya vṛttayaḥ |
cinmātrasyātiśuddhasya vikalpakalanā kutaḥ
]

`v 18 [
cidahaṃ sarvago vyāpī nityānandamayātmakaḥ |
vikalpakalanātīto dvitīyāṃśavivarjitaḥ
]

`v 19 [
citaściditi yannāma nirnāmāyā na nāma tat |
śabdātmikaiṣā cicchaktiḥ parisphurati sarvagā
]

`v 20 [
dṛśyadarśananirmuktakevalāmalarūpavān |
nityodito nirābhāso draṣṭāsmi parameśvaraḥ
]

`v 21 [
evaṃ ca ko'hamiti praśnottaramapi svayameva mayāvagatamityāha - dṛśyeti |
20 |
kalpanāvikalākāraḥ kālakāntakalāmayaḥ |
ābhāsamātramudito nityābhāsavivarjitaḥ
]

`v 22 [
īdṛśe bhārūpaikasvarūpe asminmayi nityasvātmāvabhāsavivarjitaḥ ke jale
alakānte keśāgre vā pratibimbitacandrakalāprāyaḥ śuklapakṣakāle
upacayātkāntāḥ kalā yasya candrasya tatprāyo vā svakalpanārūpo vikalākāraḥ
paricchinnajīvabhāvo ya uditaḥ sa ābhāsamātraṃ bhrāntireva na vāstava ityarthaḥ |
21 |
bhārūpaikasvarūpe'sminsvarūpeṇa jayāmyaham |
cetyarañjanariktāya vimuktāya mahātmane
]

`v 23 [
pratyakcetanarūpāya svarūpāya namo'stu te |
citaye cetyamuktāya yuktyā yuktāya yogyayā
]

`v 24 [
sarvāvabhāsadīpāya `note[rūpāya iti pāṭhaḥ] mahyameva namo'stu te |
cetyanirmuktacidrūpaṃ viṣvagviśvāvapūrakam
]

`v 25 [
saṃśāntasarvasaṃvedyaṃ saccinmātramahaṃ mahat |
ākāśavadananto'hamapyaṇoraṇurātataḥ
]

`v 26 [
nāsādayanti māmetāḥ sukhaduḥkhadaśā dṛśaḥ |
saṃvedanamasaṃvedyamacetyaṃ cetanaṃ tatam
]

`v 27 [
na śaktā māṃ paricchettuṃ bhāvābhāvā jagadgatāḥ |
atha caite jagadbhāvāḥ paricchindantu māmimam
]

`v 28 [
yathābhimatamevaite matto na vyatirekiṇaḥ |
yadi `note[mayi ityapi kvacillabhyate] svabhāvabhūtena vastunā vastu nīyate
]

`v 29 [
hriyate dīyate vāpi tatkiṃ kasya kila kṣatam |
sarvadā sarvamevāhaṃ sarvakṛtsarvasaṃgataḥ
]

`v 30 [
cetyamasmyahamevaitanna kiṃcidapi coditam |
kiṃ saṃkalpavikalpābhyāṃ citaṃ cidiyamekikā
]

`v 31 [
saṃkṣobhayāmyahaṃ tāvacchāmyāmyātmani pāvane |
iti saṃcintayanneva baliḥ paramakovidaḥ
]

`v 32 [
oṃkārādardhamātrārthaṃ bhāvayanmaunamāsthitaḥ |
saṃśāntasarvasaṃkalpaḥ praśāntakalanāgaṇaḥ
]

`v 33 [
niḥśaṅkamapi dūrāstacetyacintakacintanaḥ |
dhyātṛdhyeyadhyānahīno nirmalaḥ śāntavāsanaḥ
]

`v 34 [
dūre astāni cetyacintakacintanāni yena | tripuṭīmātratyāgopalakṣaṇametat | tatra
hetuḥ - dhyātriti
]

`v 35 [
praśamitaiṣaṇayā paripūrṇayā
mananadoṣadaśojjhitayaitayā |
balirarājata nirmalasattayā
vighanamacchatayeva śarannabhaḥ
]