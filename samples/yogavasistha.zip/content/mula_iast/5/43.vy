`v 1 [
tricatvāriṃśaḥ sargaḥ 43
śrīrāma uvāca |
bhagavansarvadharmajña śuddhaistvadvacanāṃśubhiḥ |
nirvṛtāḥ sma śaśāṅkasya karairoṣadhayo yathā
]

`v 2 [
karṇābhivāñchayamānāni pavitrāṇi mṛdūni ca |
sukhayanti gṛhītāni puṣpāṇīva vacāṃsi te
]

`v 3 [
pauruṣeṇa prayatnena sarvamāsādyate yadi |
prahrādastatkathaṃ buddho na mādhavavaraṃ vinā
]

`v 4 [
śrīvasiṣṭha uvāca |
yadyadrāghava saṃprāptaṃ prahrādena mahātmanā |
tattadāsāditaṃ tena pauruṣādeva nānyataḥ
]

`v 5 [
svapauruṣasādhyāyāṃ puruṣārthasiddhau mādhavavaro'pi dvāraviśeṣa eva na
svatantra iti noktaniyamabhaṅga ityāśayena saṃkṣipyottaramāha - yadyaditi | 4
|
ātmā nārāyaṇaścaiva na bhinnastilatailavat |
tathaiva śauklyapaṭavatkusumāmodavattathā
]

`v 6 [
yo hi viṣṇuḥ sa evātmā yo hyātmāsau janārdanaḥ |
viṣṇvātmaśabdau paryāyau yathā viṭapipādapau
]

`v 7 [
prahrādanāmā prathamamātmaiva svayamātmanā |
svayaiva parayā śaktyā viṣṇubhaktau niyojitaḥ
]

`v 8 [
prahrādo hyātmanaivainaṃ varamarjitavānsvayam |
svayaṃ vicāragaṃ kṛtvā svayaṃ viditavānmanaḥ
]

`v 9 [
kadācidātmanaivātmā svayaṃ śaktyā prabudhyate |
kadācidviṣṇudehena bhaktilabhyena bodhyate
]

`v 10 [
ciramārādhito'pyeṣa paramaprītimānapi |
nāvicāravato jñānaṃ dātuṃ śaknoti mādhavaḥ
]

`v 11 [
anvayena darśitamarthaṃ vyatirekasyāpi pradarśanena draḍhayati - ciramiti | 10
|
mukhyaḥ puruṣayatnottho vicāraḥ svātmadarśane |
gauṇo varādiko heturmukhyahetuparo bhava
]

`v 12 [
pūrvameva balāttasmādākramyendriyapañcakam |
abhyasansarvayatnena cittaṃ kuru vicāravat
]

`v 13 [
yadyadāsādyate kiṃcitkenacitkvacideva hi |
svaśaktisaṃpravṛttyā tallabhyate nānyataḥ kvacit
]

`v 14 [
pauruṣaṃ yatnamāśritya prollaṅghyendriyaparvatam |
saṃsārajaladhiṃ tīrtvā pāraṃ gaccha paraṃ padam
]

`v 15 [
vinā puruṣayatnena dṛśyate cejjanārdanaḥ |
mṛgapakṣigaṇaṃ kasmāttadāsau noddharatyajaḥ
]

`v 16 [
guruśceduddharatyajñamātmīyātpauruṣādṛte |
uṣṭraṃ dāntaṃ balivardaṃ tatkasmānnoddharatyasau
]

`v 17 [
na harerna gurornārthātkiṃcidāsādyate mahat |
ākrāntamanasaḥ svasmādyadāsāditamātmanaḥ
]

`v 18 [
abhyāsavairāgyayutādākrāntendriyapannagāt |
nātmanaḥ prāpyate yattatprāpyate na jagattrayāt
]

`v 19 [
ārādhayātmanātmānamātmanātmānamarcaya |
ātmanātmānamālokya saṃtiṣṭhasvātmanātmani
]

`v 20 [
śāstrayatnavicārebhyo mūrkhāṇāṃ prapalāyinām |
kalpitā vaiṣṇavī bhaktiḥ pravṛttyarthaṃ śubhasthitau
]

`v 21 [
abhyāsayatnau prathamaṃ mukhyo vidhirudāhṛtaḥ |
tadabhāve tu gauṇaḥ syātpūjyapūjāmayakramaḥ
]

`v 22 [
asti cedindriyākrāntiḥ kiṃ prāpyaṃ pūjanaiḥ phalam |
nāsti cedindriyākrāntiḥ kiṃ prāpyaṃ pūjanaiḥ phalam
]

`v 23 [
vicāropaśamābhyāṃ hi na vināsādyate hariḥ |
vicāropaśamābhyāṃ ca muktasyābjakareṇa kim
]

`v 24 [
vicāropaśamopetaṃ cittamārādhayātmanaḥ |
tasminsiddhe bhavānsiddho no cettvaṃ vanagardabhaḥ
]

`v 25 [
kriyate mādhavādīnāṃ praṇayaprārthanā svayam |
tathaiva kriyate kasmānna svakasyaiva cetasaḥ
]

`v 26 [
sarvasyaiva janasyāsys viṣṇurabhyantare sthitaḥ |
taṃ parityajya ye yānti bahirviṣṇuṃ narādhamāḥ
]

`v 27 [
hṛdguhāvāsicittattvaṃ mukhyaṃ sānātanaṃ vapuḥ |
śaṅkhacakragadāhasto gauṇa ākāra ātmanaḥ
]

`v 28 [
yo hi mukhyaṃ parityajya gauṇaṃ samanudhāvati |
tyaktvā rasāyanaṃ siddhaṃ sādhyaṃ saṃsādhayatyasau
]

`v 29 [
yastu bhoḥ sthitimevāsyāmātmajñānacamatkṛtau |
nāsādayati saṃmattamanāḥ sa raghunandana
]

`v 30 [
aprāptātmaviveko'ntarajñacittavaśīkṛtaḥ |
śaṅkhacakragadāpāṇimarcayetparameśvaram
]

`v 31 [
* *? janena kaṣṭena tapasā tasya rāghava |
kāle nirmalatāmeti cittaṃ vairāgyakāriṇā
]

`v 32 [
nityābhyāsavivekābhyāṃ cittamāśu prasīdati |
āmra eva daśāmeti sāhakārīṃ śanaiḥ śanaiḥ
]

`v 33 [
etadapyātmanaivātmā phalamāpnoti bhāṣitam |
haripūjākramākhyena nimittenārisūdana
]

`v 34 [
varamāpnoti yo vāpi viṣṇoramitatejasaḥ |
tena svasyaiva tatprāptaṃ phalamabhyāsaśākhinaḥ
]

`v 35 [
sarveṣāmuttamasthānāṃ sarvāsāṃ cirasaṃpadām |
svamanonigraho bhūmirbhūmiḥ sasyaśriyāmiva `note[svasya iti pāṭhaḥ] |
35 |
uttamasthānāṃ praśastapuruṣārthābhiniveśānāṃ cirasaṃpadāṃ
cirabhogyamanvādisaṃpadāṃ ca svamanonigraha eva
bhūmirudbhavasthānamityarthaḥ
]

`v 36 [
apyurvīsvananotkasya karṣato'pi śiloccayam |
svamanonigrahādanyo nopāyo'stīha kaścana
]

`v 37 [
tāvajjanmasahasrāṇi bhramanti bhuvi mānavāḥ |
yāvannopaśamaṃ yāti manomattamahārṇavaḥ
]

`v 38 [
brahmaviṣṇvindrarudrādyāścirasaṃpūjitā api |
upaplavānmanovyādherna trāyante'pi vatsalāḥ
]

`v 39 [
ākārabhāsuraṃ tyaktvā bāhyamāntaramapyajam |
kuru janmakṣayāyāśu saṃvinmātraikacintanam
]

`v 40 [
saṃvedyanirmuktanirāmayaika-
saṃvinmayāsvādamanantarūpam |
sanmātramāsvādaya sarvasāraṃ
pāraṃ paraṃ prāpsyasi janmanadyāḥ
]