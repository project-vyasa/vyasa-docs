`v 1 [
aṣṭacatvāriṃśaḥ sargaḥ 48
śrīvasiṣṭha uvāca |
luṭhitaṃ śvapacāgāre punarvismayamāyayau |
gādhermano hi nāyāti tṛptimāścaryadarśane
]

`v 2 [
tatrāvalokayāmāsa sthānāni sadanāni ca |
kalpakṣobhavivṛttāni jagantīvāmbujodbhavaḥ
]

`v 3 [
uvāca svātmanaivedamaraṇye luṭhitālaye |
śuṣkāsthimālāvalite piśācaka iva drume
]

`v 4 [
imāstā mṛtamātaṅgadantamālā vṛtau kṛtāḥ |
adyāpi saṃsthitāḥ kalpaṃ pratimeruśikhā iva
]

`v 5 [
iha tadvānarīmāṃsaṃ pakvavaṃśāṅkuraiḥ saha |
bhuktaṃ purāsavonmattaiḥ saha śvapacabandhubhiḥ
]

`v 6 [
āliṅgya śvapacaśyāmāmiha kesari varmaṇi |
suptamāpīya maireyaṃ tiktaṃ gajamadena ca
]

`v 7 [
kauleyakakuṭumbinyaḥ piṇyākapalavardhitāḥ |
iha baddhā varatrābhirmṛtebharadakāṣṭhake
]

`v 8 [
iha vāraṇamuktānāṃ dadāsītpiṭhara trayam |
pinaddhaṃ māhiṣeṇogracarmaṇāmbudaśobhinā
]

`v 9 [
sthalīṣvetāsu tāsvatra saha śvapacabālakaiḥ |
ciraṃ viluṭhitaṃ cūtapatrapuñje pikairiva
]

`v 10 [
atra tadālaniḥśvāsaraṇadvaṃśapravṛttavat |
gītaṃ pītaṃ śunīraktaṃ sādhitā śavabhūṣitaḥ
]

`v 11 [
atra sārdhaṃ kuṭumbena janyatreṣu kuṭumbinā |
mṛttaṃ tatkṛtamunnādaṃ kallolairjaladhāviva
]

`v 12 [
atroḍḍayanalolānāṃ kākabhāsapatattriṇām |
dhṛtānāmanyadāśārthaṃ grathitaṃ vaṃśapañjaram
]

`v 13 [
śrīvasiṣṭha uvāca |
evaṃprāyāḥ smarangādhiḥ prāktanīḥ śvapacakriyāḥ |
vismayotkampitaśirā dhātuśceṣṭāṃ parāmṛśat
]

`v 14 [
cacāla tasmāddīrgheṇa deśātkālena kāryavit |
bhūtamaṇḍalamutsṛjya prāpa deśāntaraṃ kramāt
]

`v 15 [
sapullaṅghya nadīśailamaṇḍalāraṇyasaṃtatim |
*? sasāda tuṣārādriratnaṃ kila janāspadam
]

`v 16 [
tatra prāpa mahīpālanagaraṃ nagasaṃnibham |
jagadbhramaṇakhinnātmā svarlokamiva nāradaḥ
]

`v 17 [
athātmanānubhūtāni dṛṣṭānyasevitāni ca |
sthānāni nagare paśyanpapraccha janamādṛtaḥ
]

`v 18 [
sādho smarasi kiṃcittvamiha śvapacamīśvaram |
yadi jānāsi tattvaṃ me varṇayāśu yathāvidhi
]

`v 19 [
nāgarā ūcuḥ |
amūdihāṣṭau varṣāṇi śvapaco bhūmipo dvija |
rājatvamarpitaṃ yasya nāma maṅgalahastinā
]

`v 20 [
ante ca saṃparijñātaḥ sa praviṣṭo hutāśanam |
adya dvādaśavarṣāṇi samatītāni tāpasa
]

`v 21 [
yaṃ yaṃ pṛcchatyasau gādhirjanaṃ jātakutūhalaḥ |
tasya tasya mukhādeva śṛṇotyāsvādayatyapi
]

`v 22 [
antaḥ svapratyabhijñāsaṃvādādāsvādayati camatkāramanubhavatyapītyarthaḥ | 21
|
athāpaśyatpure tasminnṛpaṃ sabalavāhanam |
devaṃ cakradharaṃ viṣṇuṃ mandirānnirgataṃ bahiḥ
]

`v 23 [
sa dṛṣṭvā sthagitākāśaṃ calareṇupayodharaiḥ |
prāktanīṃ rājatāṃ smṛtvā samuvācāti vismayaḥ
]

`v 24 [
imāstāḥ kīrakāminyaḥ padmagarbhopamatvacaḥ |
kanakadravavarṇinyo lolanīlotpalekṣaṇāḥ
]

`v 25 [
cāmaraughā ime candrakarasaṃpiṇḍapāṇḍurāḥ |
sthiranirjharasaṃkāśāḥ kāśapuṣpacayā iva
]

`v 26 [
kāntābhiravadhūyante bālavyajanararājayaḥ |
imāstā vanavallībhirdīpyamānā ivarddhayaḥ
]

`v 27 [
imāstā mattamātaṅgaghaṭā ghaṭitadiktaṭāḥ |
saṃkalpapādapā meroriva śṛṅgaparamparāḥ
]

`v 28 [
mattamātaṅgānāṃ ghaṭāḥ saṅghāḥ | ghaṭitā dantāgranirbhinnā diktaṭā
yābhistāḥ | saṃbhāvanayātiśayoktiḥ | saṃkalpānusāriphaladāḥ pādapā yeṣu |
27 |
ete te yamavārīśakuberapratimaujasaḥ |
sāmantā vāsavasyeva lokapālā mahībhṛtaḥ
]

`v 29 [
imāstāḥ sarvavastvoghāḥ sarvābhimatadāstatāḥ |
kalpavṛkṣalatākuñjasundaryo gṛhapaṅktayaḥ
]

`v 30 [
idaṃ tatkīrajanatārājyaṃ prāgbhuktamadya me |
ātmajanmāntarācāra eva pratyakṣatāṃ gatam
]

`v 31 [
satyaṃ svapna ivāyaṃ me jāgradbhūtaḥ punaḥ sthitaḥ |
na jāne kiṃkṛtotthānā māyeyaṃ pravijṛmbhate
]

`v 32 [
aho nu khalu dīrgheṇa manomohena valgatā |
vaivaśyamupanīto'haṃ jāleneva śakuntakaḥ
]

`v 33 [
hā dhikkaṣṭabuddhaṃ me mano vāsanayā hatam |
paśyati bhramajālāni vitatāni śiśoriva
]

`v 34 [
eṣā hi māyā mahatī tena me cakradhāriṇā |
darśitetyadhunā sādhu mayā smṛtamakhaṇḍitam
]

`v 35 [
tadidānīṃ tathā yatnaṃ kariṣye girikandare |
yathā kusaṃbhramasyāsya jāne janma tathā sthitim
]

`v 36 [
iti saṃcintya nagarādgādhistasmājjagāma ha |
kandaraṃ prāpya śailasya tasthau viśrāntasiṃhavat
]

`v 37 [
tatra saṃvatsaraṃ sārdhaṃ payaśculukabhojanam |
tapaścakre mahātejāstuṣṭaye śārṅgadhanvanaḥ
]

`v 38 [
athāsya puṇḍarīkākṣaḥ payomūrtirupāyayau |
prasādamutpalaśyāmaḥ śaradīva mahāhradaḥ
]

`v 39 [
tamājagāma śailendrakandaraṃ dvijamandiram |
payodharavadacchācchacchavirvyomanyathāvasat
]

`v 40 [
śrībhagavānuvāca |
gādhe kaccittvayā dṛṣṭā māyā mama garīyasī |
dṛṣṭaṃ tvayā jagajjālaceṣṭitaṃ daiṣṭikātmakam
]

`v 41 [
cittābhigata etasminprāpte samyaganinditaḥ |
tapo giritaṭe kurvankimanyadabhivāñchasi
]

`v 42 [
śrīvasiṣṭha uvāca |
evaṃ vadantamālokya hariṃ gādhirdvijottamaḥ |
arcāṃ kusumapūreṇa pādayoḥ paryapūrayat
]

`v 43 [
dattvārghyaṃ kīrṇakusumaḥ praṇamyāśu pradakṣiṇaiḥ |
viṣṇumāha dvijo vākyamambhodamiva cātakaḥ
]

`v 44 [
gādhiruvāca |
deva yaiṣā tvayā māyā darśitā'titamomayī |
mahīṃ prātarivādityastāṃ me prakaṭatāṃ naya
]

`v 45 [
bhramaṃ yaṃ paśyati mano vāsanāmalamālitam |
svapnavatsa kathaṃ deva jāgratyapi hi dṛśyate
]

`v 46 [
yastatra jñātavyāṃśastamāha - bhramamiti | bhramaṃ mithyāviṣayajātam |
45 |
muhūrtamupalabdhaśca jalāntaḥ svapnavibhramaḥ |
kathaṃ pratyakṣatāṃ prāpto mamāmalapadāspada
]

`v 47 [
dairghyādairghye'sya kālasya śarīrasya bhavābhavāḥ |
kathamantasthitā na syurmadīyaiḥ śvapacabhramaiḥ
]

`v 48 [
śrībhagavānuvāca |
gādhe svādhividhūtasya svarūpasyaitadātmakam |
cetaso'dṛṣṭatattvasya yatpaśyatyuruvibhramam
]

`v 49 [
bahirna kiṃcidapyasti khādryabdhyurvīdigādikam |
etatsvacitta evāsti patrapuñjamivāṅkure
]

`v 50 [
phalādi sphāratāmeti yathaiva bahiraṅkurāt |
bahiḥ prakaṭatāṃ yāti tathā pṛthvyādicetasaḥ
]

`v 51 [
satyaṃ pṛthvyādi cittasthaṃ na bahiṣṭhaṃ kadācana |
aṅkurasthaḥ pallavastu tasmādyasmātphalaśriyaḥ
]

`v 52 [
rūpālokamanaskāratattākālakriyātmakam |
kumbhakāro ghaṭamiva ceto hanti karoti ca
]

`v 53 [
ābālametatpuruṣaiḥ sarvairevānubhūyate |
svapnabhramamadāvegarāgarogādidṛṣṭiṣu
]

`v 54 [
citte vṛttāntalakṣāṇi saṃsthitānyāttavāsane |
pādape phalapuṣpāṇi mūlākrāntāvanāviva
]

`v 55 [
tyaktāvanerviṭapino bhūyaḥ patrāṇi no yathā |
nirvāsanasya jīvasya punarjanmādi no tathā
]

`v 56 [
yatrānantajagajjālaṃ saṃsthitaṃ tena tejasā |
śvapacatvaṃ prakaṭitaṃ yadi tadvismayo'tra kim
]

`v 57 [
avabuddhā śvapacatā pratibhāsavaśāttvayā |
yathaivānalpasaṃrambhā vicitrādhivikāradā
]

`v 58 [
tathaivātithirāyāto bhuktavānsuptavāndvijaḥ |
kathāṃ kathitavāṃśceti dṛṣṭavānasi saṃbhramam
]

`v 59 [
tathaivotthāya gacchāmi prāpto'haṃ bhūtamaṇḍalam |
ime bhūtā ime grāmā dṛṣṭavānasi saṃbhramam
]

`v 60 [
tathaivedaṃ kaṭaṃjasya prāktanaṃ luṭhitaṃ gṛham |
janairuktaṃ kaṭaṃjasya dṛṣṭavānasi saṃbhramam
]

`v 61 [
tathaiva kīranagaraṃ prāpto'smi kathitaṃ ca me |
kīraiḥ śvapacarājatvaṃ dṛṣṭavānasi sabhramam
]

`v 62 [
evaṃ sarvaṃ tvayā dṛṣṭaṃ mohajālaṃ dvijottama |
yatsatyamiti jānāsi yaccāsatyamavaiṣi ca
]

`v 63 [
vāsanāvalitaṃ cetaḥ kiṃ nāmāntarna paśyati |
sārthitaṃ dṛśyate svapne varṣasādhyaṃ prayojanam
]

`v 64 [
*?tithirna ca bhūtāste na kīrāste na tatpuram |
sarvametanmahābuddhe vyāmohāddṛṣṭavānasi
]

`v 65 [
gacchatā bhavatā bhūtadeśaṃ pānthena kandare |
kasmiṃścidvipra viśrāntaṃ kuraṅgeṇeva kānane
]

`v 66 [
tatraiva śramamūḍhatvādidaṃ tadbhūtamaṇḍalam |
idaṃ tacchvapacāgāramiti dṛṣṭaṃ na satyataḥ
]

`v 67 [
tathaiva kīranagaraṃ dṛṣṭavānasi tattathā |
tadaiva cānyadā vāpi māyārthaṃ hi bhavāndvija
]

`v 68 [
tattasminkandare tadaiva śramakāle kīranagaraṃ dṛṣṭavānasi anyadā
aghamarṣaṇakāle vāpi tathavia māyāmayamarthaṃ bhavān dṛṣṭavānityarthaḥ |
67 |
sarvadaiva samagrāsu viharannasi dṛṣṭavān |
dikṣu pronmattaka iva vibhramaṃ manasā mune
]

`v 69 [
taduttiṣṭha nijaṃ karma kurvaṃstiṣṭhopaśāntadhīḥ |
na svakarma vinā śreyaḥ prāpnuvantīha mānavāḥ
]

`v 70 [
śrīvasiṣṭha uvāca |
iti nigaditavānsa padmanābho
bhuvanagatāpasavṛndapūjyamānaḥ |
vibudhamunigaṇaiḥ pavitrahastai-
rvṛta udadhiṃ nijamaspadaṃ jagāma
]