`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīvasiṣṭha uvāca |
yuktāśayānāṃ mahatāmahatānāṃ kudṛṣṭibhiḥ |
svabhāvo'yaṃ mahābāho līlayā caratāmiha
]

`v 2 [
viharannapi saṃsāre jīvanmuktamanā muniḥ |
ādimadhyāntavirasā vihasejjāgatīrgatīḥ
]

`v 3 [
ādau janmādiduḥkhairmadhye ādhyātmikādiduḥkhairante
mṛtyunarakādiduḥkhairvirasāḥ | vihaset hāsayogyatayā tucchīkṛtya paśyet | 2
|
sarvaprakṛtakāryastho madhyasthaḥ sarvadṛṣṭiṣu |
dhyeyaṃ taṃ vāsanātyāgamavalambya vyavasthitaḥ
]

`v 4 [
sarvatra vigatodvegaḥ sarvārthaparipoṣakaḥ |
vivekoddyotadṛṣṭātmā prabodhopavanasthitiḥ
]

`v 5 [
sarvātītapadālambī pūrṇenduśiśirārāśayaḥ |
nodvegī naca tuṣṭātmā saṃsāre nāvasīdati
]

`v 6 [
sarvaśatruṣu madhyastho dayādākṣiṇyasaṃyutaḥ |
prāptakarmakaro'gryāṇāṃ saṃsāre nāvasīdati
]

`v 7 [
nābhinandati na dveṣṭi na śocati na kāṅkṣati |
maunasthaḥ prakṛtārambhī saṃsāre nāvasīdati
]

`v 8 [
pṛṣṭaḥ sanprakṛtaṃ vakti na pṛṣṭaḥ sthāṇuvatsthitaḥ |
īhitānīhitairmuktaḥ saṃsāre nāvasīdati
]

`v 9 [
sarvasyābhimataṃ vaktā coditaḥ peśaloktimān |
āśayajñaśca bhūtānāṃ saṃsāre nāvasīdati
]

`v 10 [
yuktāyuktadṛśā grastamāśopahataceṣṭitam |
jānāti lokadṛṣṭāntaṃ karakoṭarabilvat
]

`v 11 [
paraṃ padamupārūḍho bhaṅgurāṃ jāgatīṃ sthitim |
antaḥśītalayā buddhyā hasanniva nirīkṣate
]

`v 12 [
jitacittā mahātmāno ye hi dṛṣṭaparāvarāḥ |
svabhāva īdṛśasteṣāṃ kathitastava rāghava
]

`v 13 [
vayaṃ tu vaktuṃ mūrkhāṇāmajitātmīyacetasām |
bhogakardamamagnānāṃ na vidmo'bhimataṃ matam
]

`v 14 [
muktasthitiriva baddhasthitirapi tadāśayodghāṭanena varṇyatāmiti
cenmūrkhamanorathabhrāntīnāṃ tatprayuktaduśceṣṭānāṃ
tatphaladuḥkhavacitryāṇāṃ cānantyānna sā varṇayituṃ śakyetyāśayenāha ##-
teṣāmabhimatā nāryo bhāvābhāvavibhūṣitāḥ |
jvālānarakavahnīnāṃ yāstāḥ kanakarociṣaḥ
]

`v 15 [
anarthagahanāścārthā vyarthānarthakadarthanāḥ |
diśanto duḥkhasaṃrambhamabhitaḥ prahitāpadaḥ
]

`v 16 [
phalasaṃdhīni karmāṇi nānācāramayāni ca |
sukhaduḥkhāvapūrṇāni tāni vaktuṃ na śaknumaḥ
]

`v 17 [
pūrṇāṃ dṛṣṭimavaṣṭabhya dhyeyatyāgavilāsinīm |
jīvanmuktatayā svastho loke vihara rāghava
]

`v 18 [
antaḥ saṃtyaktasarvāśo vītarāgo vivāsanaḥ |
bahiḥ sarvasamācāro loke vihara rāghava
]

`v 19 [
udāraḥ peśalācāraḥ sarvācārānuvṛttimān |
antaḥ sarvaparityāgī loke vihara rāghava
]

`v 20 [
pravicārya daśāḥ sarvā yadatucchaṃ paraṃ padam |
tadeva bhāvenālambya loke vihara rāghava
]

`v 21 [
antarnairāśyamādāya bahirāśonmukhehitaḥ |
bahistapto'ntarāśīto loke vihara rāghava
]

`v 22 [
bahiḥ kṛtrimasaṃrambho hṛdi saṃrambhavarjitaḥ |
kartā bahirakartāntarloke vihara rāghava
]

`v 23 [
jñātavānasi sarveṣāṃ bhāvānāṃ samyagantaram |
yathecchasi tathā dṛṣṭyā loke vihara rāghava
]

`v 24 [
kṛtrimollāsaharṣasthaḥ kṛtrimodvegagarhaṇaḥ |
kṛtrimārambhasaṃrambho loke vihara rāghava
]

`v 25 [
tyaktāhaṃkṛtirāśvastamatirākāśaśobhanaḥ |
agṛhītakalaṅkāṅko loke vihara rāghava
]

`v 26 [
āśāpāśaśatonmuktaḥ samaḥ sarvāsu vṛttiṣu |
bahiḥ prakṛtikāryastho loke vihara rāghava
]

`v 27 [
prakṛtistattadvarṇāśramasvabhāvastaducitakāryasthaḥ prajāhitakāryastho vā | 26
|
na bandho'sti na mokṣo'sti dehinaḥ paramārthataḥ |
mithyeyamindrajālaśrīḥ saṃsāraparivartinī
]

`v 28 [
bhrāntimātramidaṃ mohājjagadrāghava dṛśyate |
janitapratyayaṃ sphāraṃ jalaṃ tīvrātape yathā
]

`v 29 [
abaddhasyaikarūpasya sarvagasyātmanaḥ katham |
bandhaḥ syāttadabhāve tu mokṣaḥ kasya vidhīyate
]

`v 30 [
atattvajñānajāteyaṃ saṃsārabhrāntirātatā |
tattvajñānātkṣayaṃ yāti rajjvāmiva bhujaṅgadhīḥ
]

`v 31 [
jñātavānasi tattvaṃ svamekayā sūkṣmayā dhiyā |
jāto'si nirahaṃkāro vyomavattiṣṭha nirmalaḥ
]

`v 32 [
jño'si tvitthaṃ tadakhilāḥ suhṛdbāndhavavāsanāḥ |
saṃtyajāsatsvabhāvasya kā nāma kila bhāvanā
]

`v 33 [
api cetthaṃ tadanyastvaṃ sattvavānanumīyase |
idaṃ prathamataḥ prāptaṃ paramādapi kāraṇāt
]

`v 34 [
bhogabandhujagadbhāvaiḥ karmabhiśca śubhāśubhaiḥ |
ātmano nāsti saṃbandhaḥ kimetānanuśocasi
]

`v 35 [
ātmatattvikasāro'hamiti jātadhiyo bhayaiḥ |
na te rāmāsti saṃbandhaḥ kiṃ bibheṣi jagadbhramāt
]

`v 36 [
ajātasya sato bandhorbandhuduḥkhasukhabhramaiḥ |
kaste rāghava saṃbandho yadetānanuśocasi
]

`v 37 [
tvaṃ cedbabhūvitha purā tathedānīṃ bhaviṣyasi |
adya ceha sthito'sīti jñātavānasi niścayam
]

`v 38 [
tadānantaragānanyānprāṇādīnnikaṭasthitān |
bandhūnatītānsubahūnkasmāttvaṃ nānuśocasi
]

`v 39 [
pūrvamanyastathedānīṃ babhūvitha bhaviṣyasi |
yadi rāma tathāpi tvaṃ sadrūpaṃ kiṃ vimuhyasi
]

`v 40 [
dvitīye'pyāha - pūrvamiti | idānīmanyaḥ agre'pyanyo bhaviṣyasi iti
kṣaṇikamātmānaṃ yadi jānāsi tathāpi tvaṃ kiṃ sadrūpamālambya vimuhyasi
śocasi | dvitīyakṣaṇe śocyasya śocituścāsattvena śokāvasarābhāvādityarthaḥ |
39 |
purā bhūtvādya bhūtvā ca bhūyaścenna bhaviṣyasi |
tathāpi kṣīṇasaṃsāraḥ kimarthamanuśocasi
]

`v 41 [
tasmānna duḥkhitā yuktā prākṛte jāgate krame |
tathaiva muditā yuktā yuktaṃ kāryānuvartanam
]

`v 42 [
mā gaccha duḥkhitāṃ rāma sukhitāmapi mā vraja |
samatāmehi sarvatra paramātmā hi sarvagaḥ
]

`v 43 [
anantaḥ satsvarūpastvaṃ khamivātitatāntaram |
prakāśo nityaśuddhastvaṃ jvālanāmiva koṭaram
]

`v 44 [
jāgatānāṃ padārthānāmadṛṣṭātmatanustanuḥ |
hṛtstho'si hāramuktānāmekastanturivātataḥ
]

`v 45 [
saṃsārasthitireveyaṃ yadbhūtvā bhūyate punaḥ |
ajñenaiva na tajjñena jño'si rāma sukhī bhava
]

`v 46 [
svarūpamidamasyāstu saṃsṛteḥ satatādhimat |
ajñānātsphāratāmeti jñātavānasi sanmate
]

`v 47 [
rūpaṃ kimanyadbhavatu bhramamātrādṛte bhrame |
svapnamātrādṛte svapne bhavatyanyo hi kaḥ kramaḥ
]

`v 48 [
sarvaśakteriyaṃ śaktirbhramamātramayaṃ tathā |
rāma dṛśyata evedamābhānamatibhāsvaram
]

`v 49 [
subandhuḥ kasyacitkaḥ syādiha no kaścidapyariḥ |
sadā sarve sa sarvasya sarvaṃ sarveśvarecchayā
]

`v 50 [
ālūnaśīrṇamakhilamidamanyonyasaṃśritam |
anārataṃ yāti jagattaraṅgaudha ivāmbhasaḥ
]

`v 51 [
adha ūrdhvatvamāyāti yātyūrdhvatvamadhastathā |
saṃsārasya calasyāsya cakranemirivābhitaḥ
]

`v 52 [
svargasthā narakaṃ yānti nārakāśca triviṣṭapam |
yoneyonyantaraṃ yānti dvīpāddvipāntaraṃ janāḥ
]

`v 53 [
dhīrāḥ kārpaṇyamāyānti kṛpaṇā yānti dhīratām |
parisphuranti bhūtāni pātotpātaśatabhramaiḥ
]

`v 54 [
ekarūpasthiraṃ cakraṃ svacchaṃ saṃtāpavarjitam |
neha saṃprāpyate kiṃcidagnau himakaṇo yathā
]

`v 55 [
ye ye nāma mahābhāgā bahavo bāndhavāstathā |
vinaṣṭā eva dṛśyante te te katipayairdinaiḥ
]

`v 56 [
paratātmīyatānyatvatvatvamattvādibhāvanā |
neha satyā mahābāho dvicandrādidṛśo yathā
]

`v 57 [
ayaṃ bandhuḥ paraścāyamayaṃ cāhamayaṃ bhavān |
iti mithyādṛśo rāma vigalantu tavādhunā
]

`v 58 [
krīḍārthaṃ vyavahārastha etābhirhatadṛṣṭibhiḥ |
āmūlamantaśchinnābhirbahirvihara helayā
]

`v 59 [
saṃsārasaraṇāvasyāṃ tathā vihara suvrata |
na yathaiva śramaśrānto vāsanābhāravāniva
]

`v 60 [
yathā yathaiṣā kāryāṇi vāsanākṣayakāriṇī |
vicāraṇā tavodeti saṃśāmyanti tathā tathā
]

`v 61 [
ayaṃ bandhurayaṃ neti gaṇanā laghucetasām |
udāracaritānāṃ tu vigatāvaraṇaiva dhīḥ
]

`v 62 [
na tadasti na yatrāhaṃ na tadasti na yanmama |
iti nirṇīya dhīrāṇāṃ vigatāvaraṇaiva dhīḥ
]

`v 63 [
nāstameti na codeti yaścidākāśavanmahān |
sarvaṃ saṃpaśyati svasthaḥ svastho bhūmitalaṃ yathā
]

`v 64 [
sarvā eva hi te bhūtajātayo rāma bandhavaḥ |
atyantāsaṃyutā etāstava rāma na kāścana
]

`v 65 [
vividhajanmaśatāhitasaṃbhrame
jagati bandhurabandhuritīkṣaṇam |
bhramadaśaiva vivalgati vastuta-
stribhuvanaṃ cirabandhurabandhvapi
]