`v 1 [
aṣṭaṣaṣṭitamaḥ sargaḥ 68
śrīrāma uvāca |
kīdṛśo bhagavansaṅgaḥ kathaṃ bandhāya vā nṛṇām |
kaśca mokṣāya kathitaḥ kathaṃ vaiṣa cikitsyate
]

`v 2 [
śrīvasiṣṭha uvāca |
dehadehivibhāgaikaparityāgena bhāvanāt |
dehamātre tu viśvāsaḥ saṅgo bandhārha ucyate
]

`v 3 [
anantasyātmatattvasya saparyantatvaniścaye |
yatsukhārthitvamant'h sa saṅgo bandhārha ucyate
]

`v 4 [
lakṣaṇāntarāṇyāha - anantasyetyādinā | saparyantatvaṃ
trividhaparicchedasahitatvaṃ tanniścaye sati
svāparicchinnasukhasvabhāvavismaraṇādyadviṣayebhyaḥ sukhārthitvamityarthaḥ |
3 |
sarvamātmedamakhilaṃ kiṃ vāñchāmi tyajāmi kim |
ityasaṅgasthitiṃ viddhi jīvanmuktatanusthitim
]

`v 5 [
nāhamasmi na cānyo'sti mā bhavantu bhavantu vā |
sukhānyasakta ityantaḥ kathyate muktibhāṅnaraḥ
]

`v 6 [
nābhinandati naiṣkarmyaṃ nakarmasvanuṣajjate |
susamo yaḥ phalatyāgī so'saṃsakta iti smṛtaḥ
]

`v 7 [
ātmatattvaikaniṣṭhasya harṣāmarṣavaśaṃ manaḥ |
yasya nāyatyasakto'sau jīvanmuktaḥ sa kathyate
]

`v 8 [
sarvakarmaphalādīnāṃ manasaiva na karmaṇā |
nipuṇaṃ yaḥ parityāgī so'saṃsakta iti smṛtaḥ
]

`v 9 [
asaṃsaṅgena sakalāśceṣṭā nānā vijṛmbhitāḥ |
cikitsitā bhavantīha śreyaḥ saṃpādayanti ca
]

`v 10 [
saṃsaktivaśataḥ sarve vitatā duḥkharāśayaḥ |
prayānti śataśākhatvaṃ śvabhrakaṇṭakavṛkṣavat
]

`v 11 [
rajjukṛṣṭaghanaghrāṇo yadgatyā pathi gardabhaḥ |
bhāraṃ vahati bhītātmā tatsaṃsaktivijṛmbhitam
]

`v 12 [
śītavātātapakleśamekadeśaniṣaṇṇayā |
tarurvahati yattanvā tatsaṃsaktivijṛmbhitam
]

`v 13 [
dharāvivaranirmagno yatkīṭaḥ pīḍitāṅgakaḥ |
kṣiṇoti vikalaḥ kālaṃ tatsaṃsaktivijṛmbhitam
]

`v 14 [
kṣutkṣāmakukṣiḥ kṣapayatyāyurvyāghātabhīrudhiḥ |
pakṣī vṛkṣaśikhāśāyī tatsaṃsaktivijṛmbhitam
]

`v 15 [
dūrvāṅkuratṛṇāhāraḥ kirātaśarapīḍayā |
jahāti yanmṛgo dehaṃ tatsaṃsaktivijṛmbhitam
]

`v 16 [
kṛmikīṭatvamāyānti jāyamānāḥ punaḥ punaḥ |
yadimā janatā jīrṇāstatsaṃsaktivijṛmbhitam
]

`v 17 [
utpattyotpattya līyante taraṅgiṇi taraṅgavat |
bhūtāni yadanantāni tatsaṃsaktivijṛmbhitam
]

`v 18 [
vīruttṛṇadaśāṃ yātā mriyante yatpunaḥpunaḥ |
narā vigatasaṃcārāstatsaṃsaktivijṛmbhitam
]

`v 19 [
rasātalarasāyogāttṛṇagulmalatādayaḥ |
janayanti yadākāraṃ tatsaṃsaktivijṛmbhitam
]

`v 20 [
svānarthāntarasaṃkāśapadārthaśatasaṃkulā |
yatsaṃsāranadī mattā tatsaṃsaktivijṛmbhitam
]

`v 21 [
saṃsaktirdvividhā proktā vandyā vandhyā ca rāghava |
vandhyā sarvatra mūḍhānāṃ vandyā tattvavidāṃ nijā
]

`v 22 [
ātmatattvāvabodhena hīnā dehādivastujā |
bhūyaḥ saṃsārasaktiryā dṛḍhā vandhyeti kathyate
]

`v 23 [
ātmatattvāvabodhena satyabhūtavivekajā |
vandyā hi kathyate saktirbhūyaḥ saṃsāravarjitā
]

`v 24 [
śaṅkhacakragadāhasto devo vividhayehayā |
vandyasaṃsaktivaśataḥ paripāti jagattrayam
]

`v 25 [
vandyasaṃsakterjīvanmuktavyavahārādisarvotkars'nirvāhakatvaṃ prapañcayati ##-
anāratanirālambaṃ vyoma vartmani pānthatām |
vandyasaṃsaktivaśataḥ karoti raviranvaham
]

`v 26 [
mahākalpasamādhānacirakalpitakalpanam |
vandyasaṃsaktivaśato brāhmaṃ sphurati vai vapuḥ
]

`v 27 [
līlayā lalanālānalīnaṃ bhūtivibhūṣitam |
vandyasaṃsaktivaśataḥ śarīraṃ śāṅkaraṃ sthitam
]

`v 28 [
vijñānagatayaḥ siddhā lokapālāstathetare |
vandyasaṃsaktivaśatastiṣṭhanti jagato'ṅgaṇe
]

`v 29 [
dhatte śārirayantraughamanyā bhuvanasaṃtatiḥ |
vandyasaṃsaktivaśato jarāmṛtivivarjitam
]

`v 30 [
manaḥ patati bhogeṣu gṛdhro māṃsalaveṣviva |
vandyasaṃsaktivaśato vyarthayā ramyaśaṅkayā
]

`v 31 [
saṃsaktivaśato vāti vāyurbhuvanakoṭare |
pañcabhūtāni tiṣṭhanti vahatīryaṃ jagatsthitiḥ
]

`v 32 [
divi devā bhuvi narāḥ pātāle bhogino'surāḥ |
brahmāṇḍodumbaraphale sphuranmaśakavatsthitāḥ
]

`v 33 [
jāyante ca mriyante ca nipatantyatpatanti ca |
bhūtāni yadanantāni taraṅgiṇi taraṅgavat
]

`v 34 [
utpattyotpattya līyante tatsaṃsaktivijṛmbhitam |
bhūtāni virasaṃ bhūyo nirjharāmbukaṇā iva
]

`v 35 [
parasparanigīrṇāṅgā janatā jāḍyajarjarā |
saṃbhrāntā prabhramatyaṅga śīrṇaparṇamivāmbare
]

`v 36 [
nakṣatracakraṃ gagane drume maśakasaṃtatiḥ |
sphuratyāvartavṛttyaiva pātāle'ṅga jalaughavat
]

`v 37 [
pātotpātadaśājīrṇaṃ kālabālakakandukam |
adyāpi na jahātīndurjalamāmalinaṃ vapuḥ
]

`v 38 [
nānāpārayugāvartaduḥkhālokanakarkaśam |
na lunāti manaḥkhaṇḍaṃ duḥkhigīrvāṇamaṇḍalam
]

`v 39 [
vāsanāmātravaśataḥ pare vyomani kenacit |
idamāracitaṃ citraṃ vicitraṃ paśya rāghava
]

`v 40 [
manaḥsaṅgaikaraṅgeṇa śūnye vyomni jaganmayam |
yadidaṃ racitaṃ citraṃ tatsatyaṃ na kadācana
]

`v 41 [
saṃsaktamanasāmasminsaṃsāre vyavahāriṇām |
atti tṛṣṇā śarīrāṇi tṛṇānyagniśikhā yathā
]

`v 42 [
parisaktamaterdehānsikatāḥ patyurambhasām |
kaḥ śaktaḥ parisaṃkhyātuṃ trasareṇugaṇaṃ yathā
]

`v 43 [
muktālatāyā gaṅgāyā merorāpādamastakam |
taraṅgamuktā gaṇyante na dehāḥ saktacetasām
]

`v 44 [
saṃsaktamanasāmetā ramyāntaḥpurapaṅktayaḥ |
racitā rauravā vīcikālasūtrādināmikāḥ
]

`v 45 [
saktacittaṃ janaṃ duḥkhaśuṣkamindhanasaṃcayam |
jvalatāṃ narakāgnīnāṃ viddhi tena jvalanti te
]

`v 46 [
duḥkhajālamidaṃ nāma yatkiṃcijjagatīgatam |
saṃsaktamanasāmarthe tatsarvaṃ parikalpitam
]

`v 47 [
saṃsaktacittamāyānti sarvā duḥkhaparamparāḥ |
jalakallolavalitā mahānadya ivāmbudhim
]

`v 48 [
manaḥsaṃsargarūpiṇyā bhārabhūtaśarīrayā |
kṣayodayadaśārthinyā sarvaṃ tatamavidyayā
]

`v 49 [
asaṃsaṅgena bhogānāṃ sarvā rāma vibhūtayaḥ |
paraṃ vistāramāyānti prāvṛṣīva mahāpagāḥ
]

`v 50 [
antaḥsaṃsaṅgamaṅgānāmaṅgāraṃ viddhi rāghava |
anantaḥsaṅgamaṅgānāṃ viddhi rāma rasāyanam
]

`v 51 [
saṃsaṅgenāntarasthena dahyate prakṛtiḥ svayam |
svakalotthe nairakāṅkṣī pāvakena yathauṣadhiḥ
]

`v 52 [
sarvatrāsaktamāśāntamanantamiva saṃsthitam |
asatkalpaṃ sadābhāsaṃ sukhāyaiva mano bhavet | 52 |
asaktaṃ manaḥ sarvatra sukhāyaiva | anantamākāśamiva saṃsthitam
]

`v 53 [
vidyādṛśi prodayamāgatena
kṣayaṃ tvavidyāviṣaye gatena |
sarvatra saṃsaktivivarjitena
svacetasā tiṣṭhati yaḥ sa muktaḥ
]