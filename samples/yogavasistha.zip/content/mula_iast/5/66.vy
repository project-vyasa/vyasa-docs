`v 1 [
ṣaṭṣaṣtitamaḥ sargaḥ 66
śrīvasiṣṭha uvāca |
atiśokaparābhūtau tasthaturdṛḍhatāpasau |
tāpasaṃśuṣkasarvāṅgau tāvaraṇyadrumāviva
]

`v 2 [
viraktau vipine kālaṃ kṣepayāmāsaturdvijau |
viyūthāviva sāraṅgāvanāsthāmagatau parām
]

`v 3 [
jagmurdināni māsāśca varṣāṇyatha tayostadā |
kramāddvāvapi saṃyātau jarāṃ śvabhradrumāviva
]

`v 4 [
aprāptavimalajñānau cirājjarjaratāpasau |
tāvekadā saṃghaṭitāvidamanyonyamūcatuḥ
]

`v 5 [
vilāsa uvāca |
jīvitāgryadrumaphala hṛdāvāsāmṛtāmbudhe |
jagatyasminmahābandho bhāsa svāgatamastu te
]

`v 6 [
etāvatyo dināvallyo madviyogavatā tvayā |
vada kva kṣapitāḥ sādho kaccitte saphalaṃ tapaḥ
]

`v 7 [
kaccitte vijvarāḥ buddhiḥ kaccijjātastvamātmavān |
kaccitphalitavidyastvaṃ kaccitkuśalavānasi
]

`v 8 [
śrīvasiṣṭha uvāca |
ityuktavantaṃ saṃsārasamudvignamalaṃ tathā |
prāhāprāptamahājñānaṃ suhṛtsuhṛdamādarāt
]

`v 9 [
bhāsa uvāca |
sādho svāgatatādyaiva diṣṭyā dṛṣṭo'si mānada |
kuśalaṃ tu kuto'smākaṃ saṃsāre tiṣṭhatāmiha
]

`v 10 [
yāvannādhigataṃ jñeyaṃ yāvatkṣīṇā na cittabhūḥ |
yāvattīrṇo na saṃsārastāvanme kuśalaṃ kutaḥ
]

`v 11 [
āśā yāvadaśeṣeṇa na lūnāścittasaṃbhavāḥ |
vīrudho dātrakeṇeva tāvannaḥ kuśalaṃ kutaḥ
]

`v 12 [
yāvannādhigataṃ jñānaṃ yāvanna samatoditā |
yāvannābhyudito bodhastāvannaḥ kuśalaṃ kutaḥ
]

`v 13 [
jñānaṃ śodhitatattvaṃ padārthajñānam bodho'khaṇḍavākyārtha iti bhedaḥ | 12
|
ātmalābhaṃ vinā sādho vinā jñānamahauṣadham |
udeti punareveyaṃ duḥsaṃsṛtiviṣūcikā
]

`v 14 [
śaiśavāṅkuritojjṛmbhānnavayauvanapallavaḥ |
jarākusumito'bhyeti punaḥ saṃsāradurdrumaḥ
]

`v 15 [
kāyajīrṇatarorasmādbāndhavākrandaṣaṭpadā |
jarākusumitodeti `note[puṣpasiteti pāṭhaḥ] punarmaraṇamañjarī
]

`v 16 [
bhuktakarmartuvirasā purāṇadivasombhitā |
nīyate nīrasaprāyā punaḥ saṃvatsarāvalī
]

`v 17 [
mahādarīṣu dehādrestṛṣṇākaṇṭakitāsvapi |
phalavyālāsu ca punaḥ kriyāsu pariluṭhyate
]

`v 18 [
duḥkhaiḥ sukhalavākārairdīrghādīrghaiḥ śubhāśubhaiḥ |
aparyāptāgamāpāyāḥ prayāntyāyānti rātrayaḥ
]

`v 19 [
ayathārthakriyārambhaiḥ kadāśāveśapallavaiḥ |
kṣīyate karmabhistucchairāyurāhatakarmabhiḥ
]

`v 20 [
unmūlitāśrayālāno manomattamataṅgajaḥ |
tṛṣṇākareṇukonnidro dūraṃ viparidhāvati
]

`v 21 [
jihvācapalatālagnaḥ kāyadrumamahālaye |
pataccintāmaṇau vṛddho garddhagṛdhro vivardhate
]

`v 22 [
nīrasā niḥsukhā laghvī patatpelavagātrikā |
jīrṇaparṇasavarṇeyaṃ kṣīyate divasāvalī
]

`v 23 [
avamānarajodhvastamastaṃgatavapuḥśriyam |
mukhaṃ dhūsaratāmeti himaiḥ padmamivāhatam
]

`v 24 [
śuṣyataḥ kāyasarasaḥ pragaladyauvanāmbhasaḥ |
rājahaṃsaḥ kṣaṇādāyuranivarti palāyate
]

`v 25 [
kālānilabaloddhūtājjarjarājjīvitadrumāt |
bhogapuṣpāṇi divasaparṇāni nipatantyadhaḥ
]

`v 26 [
bhogabhogiśriteṣvantarduḥkhadarduradhāriṣu |
manomohāndhakūpeṣu pūreṣu vinimajjati
]

`v 27 [
bhogeṣu nivṛtteṣvapi bhogāśā tadaśaktiduḥkhaṃ
tatprayuktacintāśokamohādhiśca vardhata evetyāśayenāha - bhogetyādinā |
26 |
nānānurañjanāspṛṣṭā tṛṣṇā taralapelavā |
caityamagrapatākeva dūraṃ samadhirohati
]

`v 28 [
caityaṃ devādyāyatanam | agre baddhā patākeva dūramucchritaṃ yathā syāttathā |
27 |
asya saṃsāratantrasya bṛhatkālabilāspadaḥ |
jīvitāśāmayaṃ tantumantakākhurnikṛntati
]

`v 29 [
yauvanotkaṭakallolā vahallolāsiphenilā |
parāvartamahāvartā yāti jīvitadurnadī
]

`v 30 [
kalākulajagatkāryakallolākulasaṃkulā |
kriyāsaridaparyantā vahatyākulakoṭarā
]

`v 31 [
anantā bandhujanatānadyo gambhīrakoṭare |
ajasraṃ nipatantyetā vitate kālasāgare
]

`v 32 [
deharatnaśalākeyaṃ nāśapaṅkārṇavodare |
na jñāyate kva magneti tāta janmani janmani
]

`v 33 [
cintācakre ciraṃ baddhaṃ kukriyācāracañcuram |
ceto bhramati sāmudre gartāvarte tṛṇaṃ yathā
]

`v 34 [
uhyamānamananteṣu cetaḥ kāryamahormiṣu |
kṣaṇameti na viśrāntiṃ cintātāṇḍavitāśayam
]

`v 35 [
idaṃ kṛtaṃ karomīdaṃ kariṣyāmīdamityalam |
kalanājālavalitā mūrcchitā matipakṣiṇī
]

`v 36 [
ayaṃ suhṛdayaṃ śatruriti dvandvamahādvipaḥ |
vinikṛntati marmāṇi yathā nīlotpalāni me
]

`v 37 [
cintānadyā mahāvarte vīcikānicaye ciram |
kṣaṇāducchūnatāmeti manomīnaḥ kṣaṇādgatiḥ
]

`v 38 [
anātmīyāni duḥkhāni bhūnyevaṃvidhānyayam |
ātmabuddhyā vicinvāno jano gacchati dīnatām
]

`v 39 [
anātmīyānyātmāsaṃsparśīni anātmadehādinimittāni ca | dehādāvātmabuddhyā |
38 |
bahuvidhasukhaduḥkhamadhyapātī
vitatajarāmaraṇapravātabhagnaḥ |
jagadudaragirau luṭhañjano'yaṃ
gatarasaparṇavadeti jarjaratvam
]