`v 1 [
ṣaṭcatvāriṃśaḥ sargaḥ 46
śrīvasiṣṭha uvāca |
vilāsinībhirvalito mantrimaṇḍalapūjitaḥ |
vanditaḥ sarvasāmantaiśchatracāmaralālitaḥ
]

`v 2 [
siddhānuśāsanaḥ kānto jñātarājyaguṇakramaḥ |
vītaśokabhayāyāsaprajñaḥ `note[prajaḥ iti sādhīyānatra]
prāptamahādaśaḥ
]

`v 3 [
vismṛtātmasvabhāvo'bhūdaniśaṃ stavamaṅgalaiḥ |
ānandapūrṇayā vṛttyā bhṛśaṃ kṣība ivāsavaiḥ
]

`v 4 [
kīreṣu śvapaco rājyaṃ varṣāṇyaṣṭau cakāra ha |
āryavṛttamaśeṣeṇa tāvatkālaṃ babhāra ha
]

`v 5 [
yadṛcchayaikadāthāsāvatiṣṭhattyaktabhūṣaṇaḥ |
atamastārakendvarkatejo'mbhodamivāmbaram
]

`v 6 [
vahvamanyata no hārakeyūravalayānyasau |
prabhutābṛṃhitaṃ ceto nāhāryamabhinandati
]

`v 7 [
eka evājiraṃ bāhyaṃ tādṛgveṣaḥ sa niryayau |
mukhyāṅgaṃ ṇānnabhobhāgādastaṃ gacchannivāṃśumān
]

`v 8 [
tatrāpaśyaddhanaṃ śyāmaṃ pīnaṃ śvapacapeṭakam |
gāyanmṛdu vasantotthaṃ kokilānāmiva vrajam
]

`v 9 [
dhunānaṃ vallakītantrīṃ karapallavalīlayā |
mṛdurephaṃ raṇadrephāmaliśreṇimiva drumam
]

`v 10 [
ekastasmātsamuttasthau jarāvānraktalocanaḥ |
kācaśṛṅgahimāpūrṇamiva śvapacanāyakaḥ
]

`v 11 [
bho kaṭaṃjeti sahasā vadankīramahīpatim |
iha rājā bhavantaṃ vā kaccidgeyakriyāvidam
]

`v 12 [
raktakaṇṭhaṃ mānayati rāgavāniva kokilam |
āpūrayati vā kaccidgṛhavastrāsanārpaṇaiḥ
]

`v 13 [
madhū rasālaviṭapaṃ phalapuṣpabharairiva |
darśanena tavādyāhaṃ parāṃ nirvṛtimāgataḥ
]

`v 14 [
padmaṃ sūryodayeneva candrodaya ivauṣadhī |
ānandānāmaśeṣāṇāṃ lābhānāṃ mahatāmapi
]

`v 15 [
viśrāmāṇāmanantānāṃ sīmānto bandhudarśanam |
śvapace pravadatyevaṃ rājā yāvattayā tayā |
vakāra tatkālajayā ceṣṭayaivāvadhīraṇam
]

`v 16 [
tāvadvātāyanagatāḥ kāntāḥ prakṛtayastathā |
śvapaco'yamiti jñātvā mlānatāmalamāyayuḥ
]

`v 17 [
padmāstuṣāraprāvṛṣṭyā grāmāḥ sāvagrahā iva |
dāvavanta ivādrīndrā nāgarā na virejire
]

`v 18 [
nṛpo'vadhīrayāmāsa tāṃ tāṃ śvapacasaṃkathām |
vṛkṣāgragatamārjāraphetkāraṃ mṛgarāḍiva
]

`v 19 [
satvaraṃ praviveśāntaḥpuramāmlānamānavam |
rājahaṃsa ivāvarṣe sīdatsarasijaṃ saraḥ
]

`v 20 [
sarvāvayavaviśrāntāṃ mlānatāmayamāyayau |
jānustambhāntaramahārandhrāgniriva durdrumaḥ
]

`v 21 [
tatrāpaśyadasau sarvaṃ viṣaṇṇavadanaṃ janam |
jālaṃ kuṅkumapuṣpāṇāṃ bhuktamūlamivākhunā
]

`v 22 [
mantriṇo nāgarā nāryastataste taṃ mahīpatim |
nāsprākṣurapi tiṣṭhantaṃ gṛha eva śavaṃ yathā
]

`v 23 [
bhṛtyāścākṛtasatkāraṃ dūra enamathātyajan |
duḥkhayuktā ghanasnehā api bālāḥ śavaṃ yathā
]

`v 24 [
anānandamukhaṃ śyāmaṃ śarīraṃ śrīvivarjitam |
dagdhaṃ sthalamivainaṃ te vahvamanyanta nākulāḥ
]

`v 25 [
dhūmāyamānadehasya paritāpadaśāvatī |
nāḍhaukatāsya janatā pārśvamagnirgireriva
]

`v 26 [
mandotsāhāḥ samudbhūtāḥ sabhyasaṃghātavarjitāḥ |
na tadājñāḥ padaṃ prāpurbhasmanīvāmbuvipruṣaḥ
]

`v 27 [
krūrakarmakarākārātsaṃgatāśubhadāyinaḥ |
tasmādviśeṣeṇa janā rākṣasādiva dudruvuḥ
]

`v 28 [
saṃgatena aśubhasya pāpasya vadhādeśca dāyinaḥ | rākṣasādiva bhītā iti śe'ḥ |
27 |
eka eva babhūvāsau janamadhyagato'pi san |
arthādiguṇanirmuktaḥ paradeśa ivādhvagaḥ
]

`v 29 [
bhṛśamālapate'pyasmai nālāpaṃ nāgarā daduḥ |
muktājālayutāyāpi kīcakāyādhvagā iva
]

`v 30 [
atha sarve vayaṃ dīrghakālaṃ śvapacadūṣitāḥ |
prāyaścittairna śuddhyāmaḥ praviśāmo hutāśanam
]

`v 31 [
iti nirṇīya nagare nāgarā mantriṇastathā |
abhito jvālayāmāsuścitāḥ śuṣkendhanaidhitāḥ
]

`v 32 [
jvalitāsvabhitastāsu tārakāsviva khe tadā |
babhūva nagaraṃ sarvamākrandaparamānavam
]

`v 33 [
karuṇārāvamukharaiḥ kalatrirbāṣpavarṣibhiḥ |
avaṣṭabdhaṃ jvalatkuṇḍopāntamandarudatprajam
]

`v 34 [
agnikuṇḍapraviṣṭānāṃ mantriṇāṃ bhṛtyarodanaiḥ |
rudatkrandaddṛḍhataramaraṇyamiva mārutaiḥ
]

`v 35 [
citādīpitaviprendramāṃsamāṃsalagandhayā |
jātanīhāramutpātavātyayāvakaroddhataiḥ
]

`v 36 [
*? tadīrghavasāgandhadūrānītakhagorjitaiḥ |
vakrairvyobhābhavacchannabhāskaraṃ jaladairiva
]

`v 37 [
vātoddhūtacitāvahniprajvaladvyomamaṇḍalam |
uḍḍīnāgnikaṇavrātatārāsāradigantaram
]

`v 38 [
pramattataskarakrandadvelladbālakumārakam |
saṃtrastanāgarāpāstajīvitākhyamasaṃsthiti
]

`v 39 [
alakṣitagṛhaṃ cauraluṇṭhitākhilasaṃcayam |
tyaktaputrakalatraṃ tanmaraṇavyagranāgaram
]

`v 40 [
tasmiṃstathā vartamāne kaṣṭe vidhiviparyaye |
aśeṣajanatāśeṣakalpāntasadṛśasthitau
]

`v 41 [
rājyasajjanasaṃparkapavitrīkṛtadhīradhīḥ |
gavalaścintayāmāsa śokenākulacetanaḥ
]

`v 42 [
madarthe hi kadartho'yaṃ deśe'sminsthitimāgataḥ |
akālakalpāntamayaḥ sarvanāyakanāśanaḥ
]

`v 43 [
kiṃ me jīvitaduḥkhena maraṇaṃ me mahotsavaḥ |
lokanindyasya durjantorjīvitānmaraṇaṃ varam
]

`v 44 [
iti niścitya gavalo jvalite jvalane punaḥ |
pataṅgavadanudvegamakarodāhutiṃ vapuḥ
]

`v 45 [
tasminbalādgavalanāmni hutāśarāśau
dehe patatyavayavākulatāṃ prayāte |
svāṅgāvadāhadahanasphuraṇānurodhā-
dantarjale jhaṭiti bodhamavāpa gādhiḥ
]

`v 46 [
tasmin gavalanāmni dehe nirvedabalāddhutāśarāśau patati sati svāṅgānāṃ
hastapādādīnāmavadāhe dahane yāni sphuraṇāni saṃcalanāni
tadanurodhādaghamarṣaṇaṃ kurvangādhirantarjale jhaṭiti bodhamavāpetyarthaḥ | 45
|
śrīvālmīkiruvāca |
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]