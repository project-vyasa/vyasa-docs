`v 1 [
ekonacatvāriṃśaḥ sargaḥ 39
śrīvasiṣṭha uvāca |
iti saṃcintya sarvātmā kṣīrodādātmakātpurāt |
cacāla parivāreṇa saha sānurivācalaḥ
]

`v 2 [
kṣīrodatalarandhreṇa tenaiva stambhitāmbhasā |
prahrādanagaraṃ prāpa śakralokamivāparam
]

`v 3 [
hemamandirakośasthaṃ dadarśātrāsuraṃ hariḥ |
atha śailaguhālīnaṃ samādhisthamivābjajam
]

`v 4 [
tatra te tejasā daityā vaiṣṇavenāvadhūlitāḥ |
dūraṃ yayurdineśāṃśuvitrastā iva kauśikāḥ
]

`v 5 [
dvitraiḥ sahāsurairmukhyaiḥ parivārayuto hariḥ |
praviveśāsuragṛhaṃ tārāvāniva khaṃ śaśī
]

`v 6 [
vainateyāsanastho'sau lakṣmīvidhutacāmaraḥ |
svāyudhādiparīvāro devarṣimunivanditaḥ
]

`v 7 [
mahātmansaṃprabudhyasvetyevaṃ viṣṇurudāharan |
pāñcajanyaṃ pradadhmau ca dhvanayankakubhāṃ gaṇam
]

`v 8 [
mahatā tena śabdena vaiṣṇavaprāṇajanmanā |
tulyakālaparikṣubdhakalpābhrārṇavaraṃhasā
]

`v 9 [
āsurī janatā bhūmau papātāgatasaṃbhramā |
mattalīlābhranādena rājahaṃsāvalī yathā
]

`v 10 [
jaharṣa janitānandā vaiṣṇavī gatasaṃbhramā |
janatā jaladadhvānaphulleva kuṭajāvalī
]

`v 11 [
babhūva saṃprabuddhātmā dānaveśaḥ śanaiḥśanaiḥ |
meghāvasara utphullakadamba iva kānane
]

`v 12 [
brahmarandhrakṛtotthānā prāṇaśaktirathāsuram |
śanairākramyāmāsa gaṅgā sarvamivārṇavam
]

`v 13 [
kṣaṇādākramayāmāsa prāṇaśrīḥ sarvato'suram |
udayānantaraṃ saurī prabheva bhuvanāntaram
]

`v 14 [
prāṇeṣu randhranavake pravṛtteṣvatha tasya cit |
cetyonmukhī babhūvāntaḥ prāṇadarpaṇabimbitā
]

`v 15 [
cetanīyonmukhī cetyaṃ cinmanastāmupāyayau |
dvitvaṃ mukurasaṃkrāntā mukhaśrīriva rāghava
]

`v 16 [
kiṃcidaṅkurite citte netre vikasanonmukhe |
śanairbabhūvatustasya prātarnīle yathotpale
]

`v 17 [
prāṇāpānaparāmṛṣṭānāḍīvivarasaṃvidaḥ |
vātārtasyeva padmasya spando'sya samajāyata
]

`v 18 [
nimeṣāntaramātreṇa manaḥ pīvaratāṃ yayau |
tasminprāṇavaśātpūrṇe taraṅga iva vāriṇi
]

`v 19 [
athāsau vikasannetramanaḥprāṇavapurbabhau |
ardhodita ivāditye saraḥ sphuritapaṅkajam
]

`v 20 [
asminnavasare yāvadbudhyasvetyavadadvibhuḥ |
prabuddhastāvadeṣo'bhūdbarhī ghanaravādiva
]

`v 21 [
praphullanayanaṃ jātamananaṃ pīvarasmṛtim |
uvācainaṃ trilokeśaḥ purā nābhyabjajaṃ yathā
]

`v 22 [
sādho smara mahālakṣmīmātmīyāṃ smara cākṛtim |
akāṇḍa eva kiṃ dehavirāmaḥ kriyate tvayā
]

`v 23 [
heyopādeyasaṃkalpavihīnasya śarīragaiḥ |
bhāvābhāvaistavārthaḥ kimuttiṣṭhottiṣṭha saṃprati
]

`v 24 [
manta(?)vyamiha dehena kalpaṃ yāvadanena te |
vayaṃ hi niyatiṃ vidmo yathābhūtāmaninditām
]

`v 25 [
jīvanmuktena bhavatā rājya eveha tiṣṭhatā |
kṣepaṇīyā gatodvegamākalpāntamiyaṃ tanuḥ
]

`v 26 [
tanvāṃ kalpāntaśīrṇāyāṃ sve mahimni tvayānagha |
vastavyaṃ sphuṭite kumbhe kumbhākāśena khe yathā
]

`v 27 [
kalpāntasthāyinī śuddhā dṛṣṭalokaparāvarā |
iyaṃ tava tanurjātā jīvanmuktavilāsinī
]

`v 28 [
noditā dvādaśādityā na pralīnāḥ śiloccayāḥ |
na jagajjvalitaṃ sādho tanuṃ tyajasi kiṃ mudhā
]

`v 29 [
vāyurvahati nonmattastrlokībhasmadhūsaraḥ |
lolāmarakapālāṅkastanuṃ tyajasi kiṃ mudhā
]

`v 30 [
aśoka iva mañjaryaḥ puṣkarāvartavidyutaḥ |
na sphuranti jagatkośe tanuṃ tyajasi kiṃ mudhā
]

`v 31 [
dharāsāraraṇacchailāḥ prajvalajjvalanojjvalāḥ |
kakubho na viśīryante tanuṃ tyajasi kiṃ mudhā
]

`v 32 [
na brahmaviṣṇurudrākhyatrayīśeṣamidaṃ sthitam |
jagajjaraṭhajīmūtaṃ tanuṃ tyajasi kiṃ mudhā
]

`v 33 [
na cehādridalaśreṇimātraikānumitāntarāḥ |
diśo jarjaratāṃ yātāstanu tyajasi kiṃ mudhā
]

`v 34 [
sphuṭadadrīndraṭaṃkārāḥ karāḥ saurā bhramanti khe |
kalpābhrāṇi na garjanti tanuṃ tyajasi kiṃ mudhā
]

`v 35 [
ahaṃ bhūtāvakīrṇāsu sālokāsu khagadhvajaḥ |
viharāmi daśāśāsu mā dehamavadhīraya
]

`v 36 [
ime vayamime śailā bhūtānīmānyayaṃ bhavān |
idaṃ jagadidaṃ vyoma mā dehamavadhīraya
]

`v 37 [
pīvarājñānayogena yasya paryākulaṃ manaḥ |
duḥkhāni vinikṛntanti maraṇaṃ tasya rājate
]

`v 38 [
kṛśo'tiduḥkhī mūḍho'hametāścānyāśca bhāvanāḥ |
matiṃ yasyāvalumpanti maraṇaṃ tasya rājate
]

`v 39 [
āśāpāśanibaddho'ntaritaścetaśca nīyate |
yo vilolamanovṛttyā maraṇaṃ tasya rājate
]

`v 40 [
yasya tṛṣṇāḥ prabhañjanti hṛdayaṃ hṛtabhāvanāḥ |
prarohamiva gardhebhyo maraṇaṃ tasya rājate
]

`v 41 [
cittavṛttilatā yasya tālottālamanovane |
phalitā sukhaduḥkhābhyāṃ maraṇaṃ tasya rājate
]

`v 42 [
romarājīlatājālaṃ yasyemaṃ dehadurdrumam |
anarthaugho haratyuccairmaraṇaṃ tasya rājate
]

`v 43 [
yasya svadehavipinamādhivyādhidavāgnayaḥ |
dahanti lolāṅgalataṃ maraṇaṃ tasya rājate
]

`v 44 [
kāmakopātmakā yasya sphūrjantyajagarāstanau |
antaḥśuṣkadrumasyeva maraṇaṃ tasya rājate
]

`v 45 [
yo'yaṃ dehaparityāgastalloke maraṇaṃ smṛtam |
na satā nāsatā tena kāraṇaṃ vedyavedanam
]

`v 46 [
yasya notkrāmati matiḥ svātmatattvāvalokanāt |
yathārthadarśino jñasya jīvitaṃ tasya śobhate
]

`v 47 [
yasya nāhaṃkṛto bhāvo buddhiryasya na lipyate |
yaḥ samaḥ sarvabhāveṣu jīvitaṃ tasya rājate
]

`v 48 [
yo'ntaḥśītalayā buddhyā rāgadveṣavimuktayā |
sākṣivatpaśyatīdaṃ hi jīvitaṃ tasya rājate
]

`v 49 [
yena samyakparijñāya heyopādeyamujjhatā |
cittasyānte'rpitaṃ cittaṃ jīvitaṃ tasya śobhate
]

`v 50 [
avastusadṛśe vastunyasaktaṃ kalanāmale |
yena līnaṃ kṛtaṃ ceto jīvitaṃ tasya śobhate
]

`v 51 [
satyāṃ dṛṣṭimavaṣṭabhya līlayeyaṃ jagatkriyā |
kriyate'vāsanaṃ yena jīvitaṃ tasya rājate
]

`v 52 [
nāntastuṣyati nodvegameti yo viharannapi |
heyopādeyasaṃprāptau jīvitaṃ tasya śobhate
]

`v 53 [
śuddhapakṣasya śuddhasya haṃsaughaḥ saraso yathā |
yasmādguṇaugho niryāti jīvitaṃ tasya śobhate
]

`v 54 [
yasminśrutipathaṃ prāpte dṛṣṭe smṛtimupāgate |
ānandaṃ yānti bhūtāni jīvitaṃ tasya śobhate
]

`v 55 [
yasyodayeṣu hṛdayena `note[hṛdayeṣu iti pāṭhaḥ] janāmbujāni
jīvālimanti sakalāni vilāsavanti |
tasyaiva bhāti parijīvitamakṣayendo-
rāpūrṇateva danujeśvara netarasya
]