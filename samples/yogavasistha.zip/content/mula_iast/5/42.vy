`v 1 [
dvicatvāriṃśaḥ sargaḥ 42
śrīvasiṣṭha uvāca |
ityuktvā puṇḍarīkākṣaḥ sanarāmarakinnaraḥ |
dvitīya iva saṃsāraścacālāsuramandirāt
]

`v 2 [
prahrādādivinirmuktaiḥ paścātpuṣpāñjalivrajaiḥ |
pūryamāṇo vihaṅgeśapāścāyāṅgaruhotkaraiḥ
]

`v 3 [
kramātkṣīrodamāsādya visṛjya suravāhinīm |
bhogibhogāsane tasthau śvetābja iva ṣaṭpadaḥ
]

`v 4 [
bhogibhogāsane viṣṇuḥ śakraḥ svarge sahāmaraiḥ |
pātāle dānavādhīśa iti tasthurgatajvarāḥ
]

`v 5 [
eṣā te kathitā rāma niḥśeṣamalanāśinī |
prāhrādī bodhasaṃprāptiraindavadravaśītalā
]

`v 6 [
tāṃ tu ye mānavā loke bahuduṣkṛtino'pi hi |
dhiyā vicārayiṣyanti te prāpsyantyacirātpadam
]

`v 7 [
sāmānyena vicāreṇa kṣayamāyāti duṣkṛtam |
yogavākyavicāreṇa ko na yāti paraṃ padam
]

`v 8 [
ajñānamucyate pāpaṃ tadvicāreṇa naśyati |
pāpamūlacchidaṃ tasmādvicāraṃ na parityajet
]

`v 9 [
imāṃ prahrādasaṃsiddhiṃ pravicārayatāṃ nṛṇām |
saptajanmakṛtaṃ pāpaṃ kṣayamāyātyasaṃśayam
]

`v 10 [
śrīrāma uvāca |
pare pade pariṇataṃ pāñcajanyasvanairmanaḥ |
kathaṃ prabuddhaṃ bhagavanprahrādasya mahātmanaḥ
]

`v 11 [
śrīvasiṣṭha uvāca |
dvividhā muktatā loke saṃbhavatyanaghākṛte |
sadehaikā videhānyā vibhāgo'yaṃ tayoḥ śṛṇu
]

`v 12 [
asaṃsaktamateryasya tyāgādāneṣu karmaṇām |
naiṣaṇā tatsthitiṃ viddhi tvaṃ jīvanmuktatāmiha
]

`v 13 [
saiva dehakṣaye rāma punarjananavarjitā |
videhamuktatā proktā tatsthā nāyānti dṛśyatām
]

`v 14 [
sṛṣṭabījopamā bhūyo janmāṅkuravivarjitāḥ `note[janmāntareti
pāṭhaḥ] |
hṛdi jīvadvimuktānāṃ śuddhā bhavati vāsanā
]

`v 15 [
pāvanī paramodārā śuddhasattvānupātinī |
ātmadhyānamayī nityaṃ suṣuptasyeva tiṣṭhati
]

`v 16 [
api varṣasahasrānte tayaivāntaravasthayā |
sati dehe prabudhyante jīvanmuktā raghūdvaha
]

`v 17 [
prahrādo'ntasthayā śuddhasattvavāsanayā svayā |
bodhamāpa mahābāho śaṅkhaśabdāvabuddhayā
]

`v 18 [
harirātmā hi bhūtānāṃ tasya yatpratibhāsate |
tattathaiva bhavatyāśu sarvamātmaiva kāraṇam
]

`v 19 [
prabodhametu prahrādo yadaiveti vicintitam |
* *? ṣādvāsudevena tadaivaitadupasthitam
]

`v 20 [
ātmanyakāraṇenaiva bhūtānāṃ kāraṇena ca |
sṛṣṭyarthaṃ vapurāttaṃ hi vāsudevamayātmanā
]

`v 21 [
ātmāvalokanenāśu mādhavaḥ paridṛśyate |
mādhavārādhanenāśu svayamātmāvalokyate
]

`v 22 [
etāṃ dṛṣṭimavaṣṭabhya rāghavātmāvalokane |
viharāśu vicārātmā padaṃ prāpsyasi śāśvatam
]

`v 23 [
duḥkhāsāravatī rāma saṃsāraprāvṛḍātatā |
jāḍyaṃ dadāti paramaṃ vicārārkamapaśyatām
]

`v 24 [
prasādādātmano viṣṇormāyeyamatibhāsurā |
prabādhate na dhīrāṃstu yakṣī mantravato yathā
]

`v 25 [
ātmecchayaiva ghanatāṃ samupāgatānta-
rātmecchayaiva anutāmupayāti kāle |
saṃsārajālaracaneyamanantamāyā-
jvāleha vātavalayādiva pāvakasya
]