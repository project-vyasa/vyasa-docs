`v 1 [
trayodaśaḥ sargaḥ 13
śrīvasiṣṭha uvāca |
evaṃ janakavadrāma vicāryātmānamātmanā |
padaṃ viditavedyānāmavighnenādhigacchasi
]

`v 2 [
ye hi pāścātyajanmānaḥ prājñā rājasasāttvikāḥ |
prāpnuvanti svayaṃ prāpyaṃ te janā janakā iva
]

`v 3 [
tāvattāvadvijityārīnindriyākhyānpunaḥpunaḥ |
yāvadātmātmanaivāyamātmanyeva prasīdati
]

`v 4 [
te kathaṃ prāpnuvanti tadāha - tāvattāvaditi | sattvopacayādyāvadātmā ātmani
prasīdati tāvattāvadrajaso viṣṭambhaśaktyā indriyārīnpunaḥpunarvijityetyarthaḥ | 3
|
prasanne sarvage deve deveśe paramātmani |
svayamālokite sarvāḥ kṣīyante duḥsvadṛṣṭayaḥ
]

`v 5 [
muṣṭayo mohabījānāṃ vṛṣṭayo vividhāpadām |
kudṛṣṭayaḥ kṣayaṃ yānti dṛṣṭe tasminparāvare
]

`v 6 [
sadā janakavadrāma sarvārambhavadātmanā |
prajñayātmānamālakṣya lakṣmīvānuttamo bhava
]

`v 7 [
nityamantarvicārasya paśyataścañcalaṃ jagat |
janakasyeva kālena svayamātmā prasīdati
]

`v 8 [
na daivaṃ naca karmāṇi na dhanāni na bāndhavāḥ |
śaraṇaṃ bhavabītānāṃ svaprayatnādṛte nṛṇām
]

`v 9 [
ye daivaniṣṭhāḥ kṛtyādau kuvikalpaparāyaṇāḥ |
teṣāṃ mandā matistāta nānugamyā vināśanī
]

`v 10 [
vivekaṃ paramāśritya vilokyātmānamātmanā |
dhiyā virāgoddhurayā saṃsārajaladhiṃ taret
]

`v 11 [
eṣā sā kathitā rāma nabhaḥphalanipātavat |
sukhadā jñānasaṃprāptirajñānataruśātanī
]

`v 12 [
janakasyeva sadbuddheḥ svayameva vilokinaḥ |
vikāsametyayaṃ dehī devaḥ prātarivāmbujam
]

`v 13 [
saṃsāramananaṃ citraṃ vicāreṇa vilīyate |
galadvaśīkṛtasparśamātapena himaṃ yathā
]

`v 14 [
ayamevāhamityasyā niśāyā udite kṣaye |
svayaṃ sarvagataḥ sphāraḥ svālokaḥ saṃpravartate
]

`v 15 [
ayamevāhamityasminsaṃkoce vilayaṃ gate |
anantabhuvanavyāpī vistāra upajāyate
]

`v 16 [
janakena parityaktā yathāhaṃkāravāsanā |
tathā tvamapi sadbuddhe vicāryāntaḥ parityaja
]

`v 17 [
ahaṃkārāmbude kṣīṇe cidvyomni vimale tate |
nūnaṃ saṃprauḍhatāmeti svāloko bhāskaraḥ paraḥ
]

`v 18 [
etāvadevātitamo yadahaṃbhāvabhāvanam |
tasmiṃśca śamamānīte prakāśa upajāyate
]

`v 19 [
nāhamasti na cānyosti naca nāstīti bhāvitam |
manaḥ praśāntimāyātaṃ nopādeyeṣu majjati
]

`v 20 [
upādeyānupatanaṃ heyaikāntavivarjanam |
yadetanmanaso rāma tadbandhaṃ viddhi netarat
]

`v 21 [
mā khedaṃ bhaja heyeṣu nopādeyaparo bhava |
heyādeyadṛśau tyaktvā śeṣasthaḥ svacchatāṃ vraja
]

`v 22 [
yeṣāmidamupādeyamidaṃ heyamiti sthitiḥ |
vilīnā te na vāñchanti ta tyajantīha kiṃcana
]

`v 23 [
heyopādeyakalane kṣīṇe yāvanna cetasaḥ |
na tāvatsamatā bhāti sābhre vyomnīva candrikā
]

`v 24 [
avastvidamidaṃ vastu yasyeti lulitaṃ manaḥ |
tasminnodeti samatā śākhoṭa iva mañjarī
]

`v 25 [
yuktāyuktaiṣaṇā yatra lābhālābhavilāsinī |
samatā svacchatā tatra kuto vairāgyabhāsinī
]

`v 26 [
ekasminbrahmatattve'sminvidyamāne nirāmaye |
nānā'nānātayā nityaṃ kimayuktaṃ kva yuktatā
]

`v 27 [
īpsitānīpsitāśaṅke markaṭyau cittapādape |
cañcale sphurato yasminkutastasyeha saumyatā
]

`v 28 [
nirāśatā nirbhayatā nityatā samatā jñatā |
nirīhatā niṣkriyatā saumyatā nirvikalpatā
]

`v 29 [
dhṛtirmaitrī matistuṣṭirmṛdutā mṛdubhāṣitā |
heyopādeyanirmukte jñe tiṣṭhantyapavāsanam
]

`v 30 [
dhāvamānamadhobhāge cittaṃ pratyāharedbalāt |
pratyāhāreṇa patitamadho vārīva setunā
]

`v 31 [
bāhyānarthānimāṃstyaktvā tiṣṭhangacchansvapanśvasan |
sarvathā sarvadā sarvānāntarāṃśca vicāraya
]

`v 32 [
gṛhītatṛṣṇāśaphari vāsanājālamāvilam |
saṃsāravāriprasṛtaṃ cintātantubhirātatam
]

`v 33 [
anayā tīkṣṇayā tāta cchindhi buddhiśalākayā |
vātyayevāmbudaṃ kāle vahantyā vitate pade
]

`v 34 [
vitate vistīrṇatare pade ākāśe brahmaṇi ca vahantyeti vātyāśalākayorviśeṣaṇam |
33 |
asya saṃsāravṛkṣasya mūlaṃ doṣāṅkurāspadam |
bhavyadhīreṇa dhairyeṇa proddharoddhurayā dhiyā
]

`v 35 [
manasaiva manaśchittva kuṭhāreṇeva pādapam |
padaṃ pāvanamāsādya sadya eva sthiro bhava
]

`v 36 [
nanu sati vikṣepahetau manasi kathaṃ mūlacchedastatrāha - manasaiveti | yathā
agraniviṣṭalohena pādapāvayavakāṣṭhātmanā kuṭhāreṇa pādapaśchidyate
tadvadagraniveśitavṛttiddhabrahmacaitanyena manasaiva manaścchittvetyarthaḥ |
35 |
manasaiva manacchittvā vismṛtyā caramaṃ manaḥ |
vartamānamapi cchittvā cchinnasaṃsāratāṃ vraja
]

`v 37 [
moho vismṛtya saṃsāraṃ na bhūyaḥ parirohati |
cittaṃ vismṛtya saṃsāro na bhūyaḥ parirohati
]

`v 38 [
tiṣthangacchansvapañjāgrannivasannutpatanpatan |
asadevedamityantarniścityāsthāṃ parityaja
]

`v 39 [
samatāmalamāśritya saṃprāptaṃ kāryamāharan |
acintayaṃstathā'prāptaṃ vihareha hi rāghava
]

`v 40 [
yathā śarvo'pi liṅgāni na bibharti bibharti ca |
tvamevamiha kāryāṇi kuru mā kuru cānagha
]

`v 41 [
tvameva vettā tvamajastvamātmā tvaṃ maheśvaraḥ |
ātmano'vyatiriktaḥ saṃstvayetthamidamātatam
]

`v 42 [
yenātmadṛśyasadbhāvādabhito bhāvanojjhitā |
sa na saṃgṛhyate doṣairharṣāmarṣaviṣādajaiḥ
]

`v 43 [
rāgadveṣavinirmuktaḥ samaloṣṭāśmakāñcanaḥ |
yukta ityucyate yogī tyaktasaṃsāravāsanaḥ
]

`v 44 [
sa yatkaroti yadbhuṅkte yaddadāti nihanti yat |
tatra muktadhiyastasya samatā sukhaduḥkhayoḥ
]

`v 45 [
prāptaṃ kartavyameveti tyakteṣṭāniṣṭabhāvanaḥ |
pravartate yaḥ kāryeṣu na sa majjati kutracit
]

`v 46 [
citsattāmātramevedamiti niścayavanmanaḥ |
tyaktabhogābhimananaṃ śamameti mahāmate
]

`v 47 [
manaḥ prakṛtyaiva jaḍaṃ cittattvamanudhāvati |
māṃsagardhena mārjāro vane mṛgapatiṃ yathā
]

`v 48 [
siṃhavīryavaśāllabdhaṃ māṃsaṃ bhuṅkte'nugo hareḥ |
cidvīryavaśataḥ prāptaṃ dṛśyamāśrayate manaḥ
]

`v 49 [
mana evamasatkalpaṃ citprasādena jīvati |
bhāvayanviśvamevaikaṃ cintāmetya cidapyuta
]

`v 50 [
jaḍaṃ yatkila nirhīnaṃ citā dīpikayaujasā |
tanmanaḥ śavasaṃkāśamaciduttiṣṭhate katham
]

`v 51 [
citsvabhāvaparāmṛṣṭā spandaśaktirasanmayī |
kalpanā cittamityuktyā kathyate śāstradṛṣṭibhiḥ
]

`v 52 [
ata eva citi spandakalpanaiva mana iti vidvatpravādo'pyastītyāha - citsvabhāveti |
51 |
yaścittaphaṇiphūtkāraḥ saiveyaṃ kalanocyate |
cidevāhamiti jñātvā sā cittāmeva gacchati
]

`v 53 [
cetyena rahitā yaiṣā cittadbrahma sanātanam |
cetyena sahitā yaiṣā citseyaṃ kalanocyate
]

`v 54 [
kiṃcidāmṛṣṭarūpaṃ yadbrahma tacca sthiraṃ manaḥ |
kalpanā satsadaivaitatsadivopasthitā hṛdi
]

`v 55 [
cittamityeva rūḍheyaṃ yadaiva kalanoditā |
tadaiva cittvaṃ vismṛtya sā jaḍeva vyavasthitā
]

`v 56 [
saṃpannā kalanānāmnī saṃkalpānuvidhāyinī |
avacchedavatī vāgrā heyopādeyadharmiṇī
]

`v 57 [
saiṣā cideva jagatāmāgateva svaśaktitaḥ |
na saṃprabodhitā yāvadrūpaṃ tāvanna budhyate
]

`v 58 [
ataḥ śāstravicāreṇa vairāgyeṇa pareṇa ca |
nigraheṇendriyāṇāṃ ca bodhayetkalanāṃ svayam
]

`v 59 [
kalanā sarvajantūnāṃ vijñānena śamena ca |
prabuddhā brahmatāmeti bhramatītarathā jagat
]

`v 60 [
vyāmohamadirāmattaṃ luṭhitāṃ viṣayāvaṭe |
ātmāvedanasaṃsuptāṃ kalanāmeva bodhayet
]

`v 61 [
aprabuddhā yadā hyeṣā na kiṃcidavabudhyate |
saṃkalpakalanevāntardṛśyamānāpyasanmayī
]

`v 62 [
nanu kalanā yadi suptā kathaṃ jagadavabudhyate avabodhe vā tasyāḥ
prasiddhacitsvabhāvātko'tiśayastatrāha - aprabuddheti | yanmanyase
jagadavabudhyata iti tanna kiṃcidavabudhyate | jagato'navabodhamātravilasitatvāt |
yato dṛśyamānāpi jagatsthitiḥ sāṃkalpikaprāsādakalaneva asanmayītyarthaḥ | 61
|
tayā paramayā dṛṣṭyā kalanaiṣāntarasthayā |
mañjarī gandhaśaktyeva padārtheṣu virājate
]

`v 63 [
tanuḥ saṃkalpitā yaiṣā kalaneti jagattraye |
sā hi kiṃcidvijānāti nityaṃ jñānaikadharmiṇī
]

`v 64 [
yadi sā sarvasākṣiṇīṃ kutastattadantaḥkaraṇadharmāneva prakāśayati na sarva
tatrāha - tanuḥsaṃkalpiteti | yā eṣā jñānaikadharmiṇī nityabodhasvabhāvā
sākṣicitsā paricchinnavṛttikalanopādhivaśāttanuralpaiveti jagattraye'pi taistaiḥ
prāṇibhiḥ saṃkalpitā ataḥ kiṃcidalpameva tattadantaḥkaraṇādi vijānātītyarthaḥ |
63 |
cetanena jaḍā rāma kalanopalarūpiṇī |
padminīvātapenāsau pareṇaiva prabodhyate
]

`v 65 [
yathā śilāmayī kanyā coditāpi na nṛtyati |
tatheyaṃ kalanā dehe na kiṃcidavabudhyate
]

`v 66 [
lipikarmanṛpairyuddhaṃ kva kṛtaṃ ghargharāravam |
kvacinna candrakiraṇairoṣadhyaḥ pratibodhitāḥ
]

`v 67 [
asṛgāliptagātraiśca śavaiḥ kva parivalgitam |
kva gītaṃ madhuradhvānaṃ vanapāṣāṇakhaṇḍakaiḥ
]

`v 68 [
kva puṃsā vihitairarkaiḥ kṣapitaṃ yāminītamaḥ |
kva saṃkalpamayaiśchāyā kriyate vyomakānanaiḥ
]

`v 69 [
kva jaḍairupalākārairmithyābhramabharotthitaiḥ |
mṛgatṛṣṇāmayairebhirmanobhiḥ kriyate kriyā
]

`v 70 [
yathātape kṣate sphāre mṛgatṛṣṇātaraṅgiṇī |
kalanā tadvadeveyaṃ sphuratyātmani satyalam
]

`v 71 [
yadetatspanditaṃ nāma tanmano'dhigataṃ śaṭhaiḥ |
marutāṃ viddhi tāṃ śaktimantaḥ prāṇaśarīriṇīm
]

`v 72 [
yeṣāṃ saṃvidanākrāntā saṃkalpalavaniścayaiḥ |
anākṣiptarasākārā prabhaiṣā pāramātmikī
]

`v 73 [
ayaṃ so'hamidaṃ tanma iti yā kalanāvilā |
prāṇātmatattvayostasyāḥ saṃjñā jīveti kathyate
]

`v 74 [
dhīścittaṃ jīva ityetāḥ saṃkalpasyāsato matāḥ |
saṃjñāḥ saṃkalpitāstajjñairna rāma paramārthataḥ
]

`v 75 [
mano no na matirnāpi dhīreṣā na śarīrakam |
astīha paramārthena svātmaivehāsti sarvadā
]

`v 76 [
ātmaivedaṃ jagatsarvamātmā kālakramastathā |
sa cākāśādacchataro nāstīvāstyeva cāmalaḥ
]

`v 77 [
acchatvādasadābhāsaḥ saṃvidrūpatayā tu sat |
ātmā sarvapadātītaḥ svānubhūtyānubhūyate
]

`v 78 [
manastatra parikṣīṇaṃ yatra saṃvitparātmanaḥ |
andhakārakṣayastatra yatrālokaḥ pravartate
]

`v 79 [
yatrātmasaṃvido'cchāyāḥ saṃkalpotthatayā matāḥ |
tatrātmano vismaraṇaṃ smaraṇaṃ cittajanmanaḥ
]

`v 80 [
parasya puṃsaḥ saṃkalpamayatvaṃ cittamucyate |
acittatvamasaṃkalpānmokṣastenābhijāyate
]

`v 81 [
etāvaccetaso janma bījaṃ saṃsārabhūtaye |
saṃkalponmukhatāṃ yātaḥ saṃvido vā kilātmanaḥ
]

`v 82 [
nirvikalpāccitaḥ sattā saṃkalpāṅkakalaṅkitā |
kalanetyucyate tena puṃstvavadbuddhyate manaḥ
]

`v 83 [
prāṇaśaktau niruddhāyāṃ mano rāma vilīyate |
dravyacchāyānu taddravyaṃ prāṇarūpaṃ hi mānasam
]

`v 84 [
deśāntarānubhavanaṃ prāṇo vetti hṛdi sthitam |
spandavedanato yattanmana ityabhidhīyate
]

`v 85 [
vairāgyātkāraṇābhyāsādyuktito vyasanakṣayāt |
paramārthāvabodhācca rodhyante prāṇavāyavaḥ
]

`v 86 [
dṛṣado vidyate śaktiḥ kadāciccalanaidhasām |
na punarmanasāmasti śaktiḥ spandāvabodhane
]

`v 87 [
spandaḥ prāṇamarucchaktiścaladrūpaiva sā jaḍā |
cicchaktiḥ svātmanaḥ svacchā sarvadā sarvagaiva sā
]

`v 88 [
cicchakteḥ spandaśakteśca saṃbandhaḥ kalpyate manaḥ |
mithyaiva tatsamutpannaṃ mithyā jñānaṃ taducyate
]

`v 89 [
eṣā hyavidyā kathitā māyaiṣā sā nigadyate |
parametattadajñānaṃ saṃsārādiviṣapradam
]

`v 90 [
cicchakteḥ spandaśakteśca saṅge saṃkalpakalpanam |
na kṛtaṃ cetparikṣīṇāstadimā bhavabhītayaḥ
]

`v 91 [
vāyutaḥ spandaśaktiryā sā citā cetyate yadā |
sacetyā cittadaivāntaḥ saṃkalpādyāti cittatām
]

`v 92 [
cittataiṣā cito mithyā kalpitā bālayakṣavat |
akhaṇḍamaṇḍalākāraspandarūpā cideva yat
]

`v 93 [
saiṣā cittā tadanyena kena saṃbādhyate kila |
akhaṇḍaśakterindrasya kena syātsaha saṃgaraḥ
]

`v 94 [
ataḥ saṃbandhino'bhāvātsaṃbandho'tra na vidyate |
saṃbandhena vinā kasya siddhaṃ tatkīdṛśaṃ manaḥ
]

`v 95 [
citspandayorekatāyāṃ kiṃ nāma mana ucyate |
kā senā hayamātaṅgasaṅgasaṃghaṭṭanaṃ vinā
]

`v 96 [
tasmānnāstyeva duṣṭātma cittaṃ rāma jagattraye |
saiṣā samyakparijñānāccetaso jāyate kṣatiḥ
]

`v 97 [
mudhā maivamanarthāya manaḥ saṃkalpayānagha |
mano mithyāsamuditaṃ nāstyatra paramārthataḥ
]

`v 98 [
mā tvamantaḥ kvacitkiṃcitsaṃkalpaya mahāmate |
manaḥ saṃkalpakaṃ rāma yasmānnāstīha kutracit
]

`v 99 [
asamyagjñānasaṃbhūtā kalpanā mṛgatṛṣṇikā |
hṛnmarau tava saṃśāntā samyagālokanānmune
]

`v 100 [
jaḍatvānniḥsvarūpatvātsarvadaiva mṛtaṃ manaḥ |
mṛtena māryate lokaścitreyaṃ maurkhyacakrikā
]

`v 101 [
yasya nātmā na deho'sti nādhāro nāpi cākṛtiḥ |
tenedaṃ bhakṣyate sarvaṃ citreyaṃ maurkhyavāgurā
]

`v 102 [
sarvasāmagryahīnena hanyate manasāpi yaḥ |
nīlotpaladalāghātairmanye dalitamastakam
]

`v 103 [
jaḍena mūkenāndhena nihato manasāpi yaḥ |
manye sa dahyate mūḍhaḥ pūrṇacandramarīcibhiḥ
]

`v 104 [
vidyamāno'pi yaḥ śūro lokastenābhibhūyate |
avidyamānamevedaṃ hanyate mugdhatoditā
]

`v 105 [
mithyāsaṃkalpakalitaṃ mithyāvasthitimāgatam |
anviṣṭamapi no dṛṣṭaṃ kā tasya kila śaktatā
]

`v 106 [
aho nu khalu citreyaṃ māyāmayavidhāyinī |
cetasāpyatilolena loko'yamabhibhūyate
]

`v 107 [
maurkhyaṃ yadāpadānviṣṭaḥ kā hi nāpadajānataḥ |
paśya maurkhyādiyaṃ sṛṣṭirajñānenaiva janyate
]

`v 108 [
hā kaṣṭamapi durbuddheḥ sṛṣṭirmaurkyavaśaṃ gatā |
asataiva yadetena jīvenāpyupapādyate
]

`v 109 [
manye maurkhyamayī sṛṣṭiriyamatyantapelavā |
vāstaraṅgapravāheṇa kaṇaśaḥ pariśīryate
]

`v 110 [
nīlāñjanālavālena yantreṇaiva vicūrṇyate |
indorābhogapūrṇasya karasparśena muhyati
]

`v 111 [
ripubhirnayanonmuktairdṛṣṭaḥ sūtrairnibadhyate |
saṃkalpakṛtayā śūrasenayā paribhūyate
]

`v 112 [
tasmātkileyaṃ manasā na sthitenaiva kutracit |
kalpitena mudhānyena kṛpaṇena nihanyate
]

`v 113 [
mūrkhalokamayī sṛṣṭirmana evāsadutthitam |
yaḥ śakto na vaśīkartuṃ nāsau rāmopadiśyate
]

`v 114 [
tasmānmanovaśīkaraṇāśakto nādhyātmaśāstrādhikārītyāha - mana eveti |
113 |
abhijātā'svarūpaiṣā prajñā kṣodeṣu na kṣamā |
nopadeśagirāṃ yogyā paripūrṇeva saṃsthitā
]

`v 115 [
bibhetyeṣāpi vīṇāyāstantrīguṇatanudhvaneḥ |
bandhorapi sanidrasya bibheti vadanadyuteḥ
]

`v 116 [
asato'pi janāduccairgītādbhītā palāyate |
svenaiva manasāpyajñā kilaiṣā vivaśīkṛtā
]

`v 117 [
sukhalavavivaśā dviṣeva taptā
hṛdayagatena nijena cetasaiva |
vidhuritadhiṣaṇā na vetti satyaṃ
tadapi kathaṃ parimohito mudhaiva
]