`v 1 [
ṣaṭpañcāśaḥ sargaḥ 56
śrīvasiṣṭha uvāca |
krameṇānena viharanvicāryātmānamātmanā |
viśrāntimehi vitate pade padmadalekṣaṇa
]

`v 2 [
śāstrārthagurucetobhistāvattāvadvicāryate |
sarvadṛśyakṣayābhyāsādyāvadāsādyate padam
]

`v 3 [
vairāgyābhyāsaśāstrārthaprajñāgurumayakramaiḥ
`note[guruyamakramairiti pāṭhaḥ | tatra yamaśabdena manonigraho
jñeyaḥ] |
padamāsādyate puṇyaṃ prajñayaivaikayāthavā
]

`v 4 [
saṃprabodhavatī tīkṣṇā kalaṅkarahitā matiḥ |
sarvasāmagryahīnāpi padaṃ prāpnoti śāśvatam
]

`v 5 [
śrīrāma uvāca |
bhagavanbhūtabhavyeśa kaścijjātasamādhikaḥ |
prabuddha iva viśrānto vyavahāraparo'pi san
]

`v 6 [
kaścidekāntamāśritya samādhiniyataḥ sthitaḥ |
tayostu kataraḥ śreyāniti me bhagavanvada
]

`v 7 [
śrīvasiṣṭha uvāca |
imaṃ guṇasamāhāramanātmatvena paśyataḥ |
antaḥśītalatā yāsau samādhiriti kathyate
]

`v 8 [
dṛśyairmanasi saṃbandha iti niścitya śītalaḥ |
kaścitsaṃvyavahārasthaḥ kaściddhyāne vyavasthitaḥ
]

`v 9 [
dvāvetau rāma sukhitāvantaścetpariśītalau `note[saṃpannāviti pāṭhaḥ] |
antaḥśītalatā yā syāttadanantatapaḥphalam
]

`v 11 [
samādhisthānakasthasya cetaścedvṛtticañcalam |
tattasya `note[tattarhītyarthaḥ] tatsamādhānaṃ samamunmattatāṇḍavaiḥ |
10 |
unmattatāṇḍavasthasya cetaścetkṣīṇavāsanam |
tadasyonmattavṛttaṃ tatsamaṃ buddhasamādhinā
]

`v 12 [
vyavahārī prabuddho yaḥ prabuddho yo vane sthitaḥ |
dvāvetau susamau nūnamasaṃdehaṃ padaṃ gatau
]

`v 13 [
asaṃdehaṃ sarvasaṃedhocchedi paramapadaṃ gatau tatra pratiṣṭhitau cetyarthaḥ | 12
|
akartṛ kurvadapyetaccetaḥ pratanuvāsanam |
dūraṃ gatamanā jantuḥ kathāsaṃśravaṇe yathā
]

`v 14 [
akurvadapi karteva cetaḥ praghanavāsanam |
nispandāṅgamapi svapne śvabhrapātasthitāviva
]

`v 15 [
cetaso yadakartṛtvaṃ tatsamādhānamuttamam |
taṃ viddhi kevalībhāvaṃ sā śubhā nirvṛtiḥ parā
]

`v 16 [
cetaścalācalatvena paramaṃ kāraṇaṃ smṛtam |
dhyānādhyānadṛśostena tadevānaṅkuraṃ kuru
]

`v 17 [
avāsanaṃ sthiraṃ proktaṃ manodhyānaṃ tadeva tu |
sa eva kevalībhāvaḥ śāntataiva ca sā sadā
]

`v 18 [
tanuvāsanamatyuccaiḥ padāyodyatamucyate |
avāsanaṃ mano kartṛpadaṃ tasmādavāpyate
]

`v 19 [
ghanavāsanametattu cetaḥ kartṛtvabhājanam |
sarvaduḥkhapradaṃ tasmādvāsanāṃ tanutāṃ nayet
]

`v 20 [
praśāntajagadāstho'ntarvītaśokabhayaiṣaṇaḥ |
svastho bhavati yenātmā sa samādhiriti smṛtaḥ
]

`v 21 [
cetasā saṃparityajya sarvabhāvātmabhāvanām |
yathā tiṣṭhasi tiṣṭha tvaṃ tathā śaile gṛhe'thavā
]

`v 22 [
gṛhameva gṛhasthānāṃ susamāhitacetasām |
śāntāhaṃkṛtidoṣāṇāṃ vijanāvanabhūmayaḥ
]

`v 23 [
araṇyasadane tulye samāhitamanodṛśām |
bhavatāmiha bhūtānāṃ bhūtānāṃ mahatāmiva
]

`v 24 [
śāntacittamahābhrasya janajvālojjvalānyapi |
nagarāṇyapi śūnyāni vanānyavanipātmaja
]

`v 25 [
vṛttimaccittamattasya vijanāni vanānyapi |
nagarāṇi mahālokapūrṇāni paravīrahan
]

`v 26 [
vyutthitaṃ cittamabhyeti bhramasyāntaḥ suṣuptatām |
nirvāṇameti nirvāṇaṃ yathecchasi tathā kuru
]

`v 27 [
sarvabhāvapadātītaṃ sarvabhāvātmakaṃ ca vā |
yaḥ paśyati sadātmānaṃ sa samāhita ucyate
]

`v 28 [
īhitānīhite kṣīṇe yasyāntarvitatākṛteḥ |
sarve bhāvāḥ samā yasya sa samāhita ucyate
]

`v 29 [
sadātmanā sadevedaṃ jagatpaśyati no manaḥ |
yathā svapne tathaivāsmiñjāgratyapi janeśvara
]

`v 30 [
yathā vipaṇikālokā viharanto'pyasatsamāḥ |
asaṃbandhāttathā jñasya grāmopi vipinopamaḥ
]

`v 31 [
antarmukhamanā nityaṃ supto buddho vrajannapi |
puraṃ janapadaṃ grāmamaraṇyamiva paśyati
]

`v 32 [
sarvamākāśatāmeti nityamantarmukhasthiteḥ |
sarvathānupayogyatvādbhūtākulamidaṃ jagat
]

`v 33 [
antaḥśītalatāyāṃ tu labdhāyāṃ śītalaṃ jagat |
vijvarāṇāmiva nṛṇāṃ bhavatyājīvitasthiteḥ
]

`v 34 [
antastṛṣṇopataptānāṃ dāvadāhamayaṃ jagat |
bhavatyakhilajantūnāṃ yadantastadbahiḥ sthitam
]

`v 35 [
dayuḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
antaḥkaraṇatattvasya bhāgā bahiriva sthitāḥ
]

`v 36 [
vaṭadhānā vaṭa iva yadantaḥsthaṃ sadātmanaḥ |
tadbahirbhāsate bhāsvadvikāse puṣpagandhavat
]

`v 37 [
na bahiṣṭhaṃ na `note[na vāntasthaṃ ityapi kvacitpaṭhyate] cāntaḥsthaṃ
kvacitkiṃcana vidyate |
yadyathā kacitaṃ cittvāttattathā tattvamutthitam
]

`v 38 [
ātmatattvāntaraṃ bhāti bahiṣṭvena jagattayā |
karpūramiva gandhena saṃkoce pravikāsi ca
]

`v 39 [
ātmaiva sphurati sphāraṃ jagattvenāpyahaṃtayā |
bāhyatvenāntaratvena sa ca nāsanna sanvibhuḥ
]

`v 40 [
bahiṣṭhenāntaraṃ bāhyamantaḥsthenāntarasthitam |
yathāviditamātmāyaṃ svacittamanupaśyati
]

`v 41 [
sabāhyābhyantaraṃ śāntamātmano bheditaṃ jagat |
ahantvādisthite bhede bhūribhaṅgabhayaṃ tu tat
]

`v 42 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
kalpādireva jvalitaṃ sarvamādhihatātmanaḥ
]

`v 43 [
yastvātmaratirevāntaḥ kurvankarmendriyaiḥ kriyāḥ |
na vaśo harṣaśokābhyāṃ sa samāhita ucyate
]

`v 44 [
yaḥ sarvagatamātmānaṃ paśyansamupaśāntadhīḥ |
na śocati dhyāyati vā sa samāhita ucyate
]

`v 45 [
sa pūrvāparaparyantāṃ yaḥ paśyañjāgatīṃ gatim |
dṛṣṭiṣvetāsu hasati sa samāhita ucyate
]

`v 46 [
same pare'pi nāhaṃtā na jagajjanmano mayi |
vīcivṛndeṣvivātaptā nākāśe phaladhātavaḥ
]

`v 47 [
yasyāntarasthitāhantvaṃ na vibhāgādi no manaḥ |
na cetanācetanatve so'sti nāstītaro janaḥ
]

`v 48 [
vyomasvaccho bahiṣṭhehāṃ samyagācaratīha yaḥ |
harṣāmarṣavikāreṣu kāṣṭhaloṣṭasamaḥ śamaḥ
]

`v 49 [
ātmavatsarvabhūtāni paradravyāṇi loṣṭavat |
svabhāvādeva na bhayādyaḥ paśyati sa paśyati
]

`v 50 [
artho'tanustanurvāpi nāsadrūpeṇa cetyate |
sadrūpo nānubhūto'jñe na jñenaiva na tattayā
]

`v 51 [
īdṛśāśayasaṃpanno mahāsattvapadaṃ gataḥ |
tiṣṭhatūdetu vā yātu mṛtimetu na tatsthitim
]

`v 52 [
vasatūttamabhogāḍhye svagṛhe vā janākule |
sarvabhogojjhitābhoge sumahatyathavā vane
]

`v 53 [
uddāmamanmathaṃ pānatatparo vāpi nṛtyatu |
sarvasaṅgaparityāgī samamāyātu vā girau
]

`v 54 [
candanāgurukarpūrairvapurvā parilimpatu |
jvālājaṭilavistāre nipatatvathavā'nale
]

`v 55 [
pāpaṃ karotu sumahadvahulaṃ puṇyameva ca |
adya vā mṛtimāyātu kalpāntanicayena vā
]

`v 56 [
nāsau kiṃcinna tatkiṃcitkṛtaṃ tena mahātmanā |
nāsau kalaṅkamāpnoti hema paṅkagataṃ yathā
]

`v 57 [
saṃvitpuruṣaśabdārthaiḥ sa kalaṅkaiḥ kalaṅkyate |
ahaṃtvaṃvāsanārūpaiḥ śuktikārajatopamaiḥ
]

`v 58 [
samastavastupraśamātsamyagjñānādyathāsthiteḥ |
svabhāvasyopaśāntontaḥkalaṅko'sattayā svataḥ
]

`v 59 [
ahaṃtvavāsanānarthaprasūteḥ saṃvidātmanaḥ |
puruṣasya vicitrāṇi sukhaduḥkhāni janmani
]

`v 60 [
rajjvāṃ sarpabhrame śānte'hirneti nirvṛtiryathā |
ahaṃtvabhāvasaṃśāntau tathāntaḥ samatā matā
]

`v 61 [
yatkaroti yadaśnāti yaddadāti juhoti vā |
na tajjñasya na tatra jño mā karotu karotu vā
]

`v 62 [
karmaṇāsti na tasyārtho nārthastasyāstyakarmaṇā |
yathāsvabhāvāvagamātsa ātmanyeva saṃsthitaḥ
]

`v 63 [
icchāstataḥ samudyanti na mañjarya ivopalāt |
yāścodyanti ca tāḥ sarvāḥ sa evāpsviva vīcayaḥ
]

`v 64 [
sakalamidamasāvasau ca sarvaṃ
jagadakhilaṃ na vibhāgitātra kācit |
paramapuruṣapāvanaikarūpī
sa saditi tatsadakiṃcideva nāsau
]