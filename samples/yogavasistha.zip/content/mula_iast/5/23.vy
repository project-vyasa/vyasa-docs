`v 1 [
trayoviṃśaḥ sargaḥ 23
virocana uvāca |
asti putrātivitato deśo vipulakoṭaraḥ |
trailokyānāṃ sahasrāṇi yatra mānti bahūnyapi
]

`v 2 [
yatra nāmbhodayo nāpi sāgarā vā na cādrayaḥ |
na vanāni na tīrthāni na nadyo na sarāṃsi ca
]

`v 3 [
na mahī nāpi cākāśaṃ na dyaurna pavanādayaḥ |
na candrārkau na lokeśā na devā naca dānavāḥ
]

`v 4 [
na bhūtayakṣarakṣāṃsi na gulmā na vanaśriyaḥ |
na kāṣṭhatṛṇabhūtāni sthāvarāṇi carāṇi ca
]

`v 5 [
nāpo na jvalano nāśā nordhvaṃ nādho na viṣṭapam |
na loko nātapo nāhaṃ na harīndraharādayaḥ
]

`v 6 [
eka evāsmi sumahāṃstatra rājā mahādyutiḥ |
sarvakṛtsarvagaḥ sarvaḥ sa ca tūṣṇīṃ vyavasthitaḥ
]

`v 7 [
tena saṃkalpito mantrī sarvasanmantraṇonmukhaḥ |
aghaṭaṃ ghaṭayatyāśu ghaṭaṃ vighaṭayatyalam
]

`v 8 [
bhoktuṃ na kiṃcicchaknoti na ca jānāti kiṃcana |
rājārthaṃ kevalaṃ sarvaṃ karotyajño'pi sansadā
]

`v 9 [
sa eva sarvakāryaikakartā tasya mahīpateḥ |
rājā kevalamekānte svastha evāvatiṣṭhate
]

`v 10 [
baliruvāca |
ādhivyādhivinirmuktaḥ kaḥ sa deśo mahāmate |
kathamāsādyate cāpi kena vādhigataḥ prabho
]

`v 11 [
kaḥ sa tādṛgvidho mantrī rājā cāpi mahābalaḥ |
helālūnajagajjālairyo'smābhirapi no jitaḥ
]

`v 12 [
apūrvametadākhyānaṃ mamāmarabhayapada |
kathayāpanayāsmākaṃ hṛdvyomnaḥ saṃśayāmbudam
]

`v 13 [
virocana uvāca |
sa tatra mantrī balavāndevāsuragaṇaiḥ suta |
sametairlakṣaguṇitairapi nākramyate manāk
]

`v 14 [
nāsau sahasranayano na yamo na dhaneśvaraḥ |
nāmaro nāsuro vāpi yadi putraka jīyate
]

`v 15 [
tatrāsimusalaprāsavajracakragadādayaḥ |
hetayaḥ kuṇṭhatāṃ yānti dṛṣadīvotpalāhatiḥ
]

`v 16 [
gamyo'sau nāstraśastrāṇāṃ na bhaṭodbhavakarmaṇām |
tena devāsurāḥ sarve sarvadaiva vaśīkṛtāḥ
]

`v 17 [
aviṣṇunāpi teneha hiraṇyākṣādayo'surāḥ |
pātitāḥ kalpavātena merukalpadrumā iva
]

`v 18 [
nārāyaṇādayo devā api sarvāvabodhinaḥ |
tenākramya yathākāmamavaṭeṣu niveśitāḥ
]

`v 19 [
sarveṣāmavabodhino vivekopadeṣṭāro'pi tenaiva
bhṛguśāpādinimittāpādanenākramya vaśīkṛtya | avaṭeṣu garbhaśvabhreṣu |
18 |
tatprasādena sāṭopaṃ pañcamātraśaraḥ smaraḥ |
trailokyamidamākramya samrāḍiva vivalgati
]

`v 20 [
surāsuraughagṛhyo'pi guṇahīno'pi durmatiḥ |
durākṛtirapi krodhastatprasādena jṛmbhate
]

`v 21 [
devāsurasahasrāṇāṃ saṃgaro yaḥ punaḥ punaḥ |
tadetatkrīḍanaṃ tasya mantriṇo mantraśālinaḥ
]

`v 22 [
sa mantrī kevalaṃ putra tenaiva prabhuṇā yadi |
jīyate tatsujeyo'sāvanyathā tvacalopamaḥ
]

`v 23 [
tasyaiva tatprabhoḥ kāle jetuṃ taṃ mantriṇaṃ nijam |
icchā saṃjāyate tena jīyate'sāvayatnataḥ
]

`v 24 [
trailokyabalināṃ mallamucchvāsitajagattrayam |
jetuṃ cedasti te śaktistatparākramavānasi
]

`v 25 [
tasminnabhyudite sūrye trailokyakamalākarāḥ |
ime vikāsamāyānti vilīyante'stamāgate
]

`v 26 [
tamevamekayā buddhyā vyāmohaparihīnayā |
yadi jetuṃ samartho'si dhīrastadasi suvrata
]

`v 27 [
tasmiñjite jitā lokā bhaviṣyantyajitā api |
ajite tvajitā ete cirakālajitā api
]

`v 28 [
tasmādanantasiddhyarthaṃ śāśvatāya sukhāya ca |
tajjaye yatnamātiṣṭha kaṣṭayāpi hi ceṣṭayā
]

`v 29 [
sasuradanujanāgayakṣasaṃghaṃ
sanaramahoragakinnaraṃ sametam |
trijagadapi vaśīkṛtaṃ samantā-
datibalinā nanu helayaiva tena
]