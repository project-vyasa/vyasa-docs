`v 1 [
caturthaḥ sargaḥ 4
śrīvālmīkiruvāca |
meghagambhīrayā vācā viśrabdhapadasundaram |
idaṃ daśaratho vākyamuvāca munināyakam
]

`v 2 [
bhagavanhyastanena tvaṃ vākyasaṃdarghajanmanā |
kaccinmukto'si khedena tapaḥkārśyātiśāyinā
]

`v 3 [
hyastanena pūrvedyurbhavena vākyasaṃdarbhoccāraṇajanmanā khedena śrameṇa |
2 |
hyastanokto ya ānandī vivikto vacasāṃ gaṇaḥ |
amṛtāvarṣaṇeneva tenaivāśvāsitā vayam
]

`v 4 [
candrāṃśava ivotsārya tamāṃsyamṛtanirmalāḥ |
antaḥśītalayantyetā mahatāmamalā giraḥ
]

`v 5 [
apūrvāhlādadāyinya uccaistarapadāśrayāḥ |
atimohāpahāriṇyaḥ sūktayo hi mahīyasām
]

`v 6 [
ātmaratnāvalokaikadīpikā sarasātmikā |
yamādyuktilatodeti sa vandyaḥ sujanadrumaḥ
]

`v 7 [
durīhitaṃ durvihitaṃ sarvaṃ sajjanasūktayaḥ |
pramārjayanti śītāṃśostamaḥkāṇḍamivāṅghrayaḥ
]

`v 8 [
tṛṣṇālobhādayo'smākaṃ saṃsāranigaḍā mune |
tavoktyā tanutāṃ yātāḥ śaradīvāsitāmbudāḥ
]

`v 9 [
saṃpravṛttā vayaṃ draṣṭumātmānamapakalmaṣam |
rasāñjanānītadṛśo jātyandhā iva kāñcanam
]

`v 10 [
saṃsāravāsanānāmnī mihikā hṛdayāmbare |
pravṛttā tanutāṃ gantuṃ tvaduktiśaradeva naḥ
]

`v 11 [
mune mandāramañjaryastaraṅgā vāmṛtāmbhasaḥ |
na tathā hlādayantyantaryathodāradhiyāṃ giraḥ
]

`v 12 [
yadyadrāghava saṃyāti mahājanasaparyayā |
dinaṃ tadiha sālokaṃ śeṣāstvandhā dinālayaḥ
]

`v 13 [
rāma rājīvapatrākṣa prakṛtārthamihāvyayam |
munimābodhaya punaḥ prasāde samavasthitam
]

`v 14 [
ityukto bhūbhṛtā tatra rāmābhimukhamāsthitaḥ |
uvācedamudārātmā vasiṣṭho bhagavānmuniḥ
]

`v 15 [
śrīvasiṣṭha uvāca |
rāghava svakulaikendo yanmayoktaṃ mahāmate |
kaccitsmarasi vākyārthaṃ pūrvāparavicāritam
]

`v 16 [
utpattīnāṃ vicitrāṇāṃ sattvādiguṇabhedataḥ |
kaccitsmarasi sarvāsāṃ vibhāgamarimardana
]

`v 17 [
kaścitsarvamasarvaṃ ca sadasacca sadoditam |
rūpaṃ smarasi vetsyeva viviktaṃ paramātmanaḥ
]

`v 18 [
yathedamuditaṃ viśvaṃ viśveśādeva ceśvarāt |
kaccitsmarasi tatsādho sādhuvādaikabhājana
]

`v 19 [
rūpaṃ kaccidavidyāyā balādbhaṅguramātatam |
anantamantavaccaiva samyaksmarasi sanmate
]

`v 20 [
cittameva naro nānyaditi yatpratipāditam |
lakṣaṇādivicāreṇa kaccitsmarasi sādhu tat
]

`v 21 [
vākyārthaścākhilaḥ kaccittvayā rāma vicāritaḥ |
hyastanasya vicārasya rātrau hṛdi niveśitaḥ
]

`v 22 [
bhūyobhūyaḥ parāmṛṣṭaṃ hṛdaye suniyojitam |
prayojanaṃ phalatyuccairna helāhatasaṃsthiteḥ
]

`v 23 [
bhājanaṃ tvaṃ viviktānāṃ vacasāṃ śuddhiśālinām |
viviktahṛdayaḥ kaṇṭhe muktānāmiva rāghava
]

`v 24 [
śrīvālmīkiruvāca |
kamalāsanaputreṇa muninā samahaujasā |
evaṃ vitīrṇāvasaro rāmo vākyamuvāca ha
]

`v 25 [
śrīrāma uvāca |
bhagavansarvadharmajña tavaivaitadvijṛmbhitam |
yadahaṃ paramodāro buddhavānvacanaṃ tava
]

`v 26 [
yadādiśasi tatsarvaṃ tathaiva na tadanyathā |
apāstanidreṇa mayā vākyārtho hṛdi cintitaḥ
]

`v 27 [
bhavāndhakārakṣataye bhavatoktivivasvatā |
hyaḥprasāditamāhlādi vāgraśmipaṭalaṃ prabho
]

`v 28 [
tadatītamadīnātmansarvamantaḥkṛtaṃ mayā |
ramyaṃ puṇyaṃ pavitraṃ ca ratnavṛndamivānvitam
]

`v 29 [
hitānubandhi hṛdyaṃ ca puṇyamānandasādhanam |
śirasā dhriyate kairno sidhaistvadanuśāsanam
]

`v 30 [
pratikṣipantaḥ saṃsāramihikāvaraṇaṃ vayam |
prasannāstvatprasādena varṣānta iva vāsarāḥ
]

`v 31 [
āpātamadhurārambhaṃ madhye saubhāgyavardhanam |
anuttamaphalodarkaṃ puṇyaṃ tvadanuśāsanam
]

`v 32 [
vikāsisitamamlānamāhlāditaśubhāśubham |
tvadvacaḥkusumaṃ nityaṃ śrīmatphaladamastu naḥ
]

`v 33 [
sakalaśāstravicāraviśārada
prasṛtapuṇyajalaikamahāhada |
bhaja bhṛśaṃ vitatavrata saṃprati
prasṛtatāṃ hatakilbiṣa saṃtatim
]