`v 1 [
| trayodaśo divasaḥ |
dvisaptatitamaḥ sargaḥ 72
śrīvasiṣṭha uvāca |
dehe jāte na jāto'si dehe naṣṭe na naśyasi |
tvamātmanyakalaṅkātmā dehastava na kaścana
]

`v 2 [
yaḥ kuṇḍabadaranyāyo yā ghaṭākāśasaṃsthitiḥ |
tatraikasminkṣate kṣīṇe dve iti vyarthakalpanā
]

`v 3 [
vināśini vinaṣṭe'smindehe svāṃ sthitimāgate |
vinaśyāmīti yaḥ khedī taṃ dhigastvandhacetasam
]

`v 4 [
yādṛśo raśmirathayoḥ snehodvegavivarjitaḥ |
saṃbandhastādṛśo dehacittendriyamukhaiściteḥ
]

`v 5 [
gatetaretarāpekṣaḥ saraḥpaṅkāmalāmbhasām |
yathā rāghava saṃbandhastathā dehendriyātmanām
]

`v 6 [
yādṛśo'dhvā gatādhvānāṃ nirāsthāparidevanaḥ |
saṃyogo viprayogaśca tādṛśo dehadehinoḥ
]

`v 7 [
yathā kalpitavetālavikārabhayabhītayaḥ |
mithyaiva kalpitā ete tathā snehasukhādayaḥ
]

`v 8 [
tatkutastatrāha - yatheti | kalpitavetālasya vikārāḥ
karālavadanadaśanavyādānādayastajjanyātprathamabhayātpunaḥ##-
bhūtapañcakasaṃpiṇḍādracitā janatāḥ pṛthak |
ekasmādeva viṭapādvicitrā iva putrikāḥ
]

`v 9 [
kāṣṭhetaratkāṣṭhabhāre kiṃcidanyanna dṛśyate |
bhūtapiṇḍetaraddehe kiṃcidanyanna dṛśyate
]

`v 10 [
bhūtapañcakavikṣobhanāśotpādeṣu he janāḥ |
harṣāmarṣaviṣādānāṃ kiṃ bhavanto vaśaṃ gatāḥ
]

`v 11 [
ko nāmātiśayaḥ puṃsāṃ strīnāmnyaparanāmni ca |
pelave bhūtasaṃghāte prodbhūtajanapātavat
]

`v 12 [
saṃniveśāṃśavaicitryamajñānāmeva tuṣṭaye |
tajjñānāṃ tu yathābhūtabhūtapañcakadarśanam
]

`v 13 [
mithaḥ śilāputrakayoryathaikopalaputrayoḥ |
śliṣṭayorapi no rāgastathā cittaśarīrayoḥ
]

`v 14 [
mṛtpuṃsāṃ yādṛśo'nyonyamāśayaḥ saṃgame bhavet |
buddhindriyātmamanasāṃ saṃgame tādṛśo'stu te
]

`v 15 [
nānyonyasnehasaṃbandhabhājanaṃ śailaputrakāḥ |
dehendriyātmaprāṇāśca kasyātra paridevanā
]

`v 16 [
itaścetaśca jātāni yathā saṃśleṣayantyalam |
taraṅgāstṛṇajālāni tathā bhūtāni dehadṛk
]

`v 17 [
saṃyujyante viyujyante tṛṇānyabdhijale yathā |
muktāntaḥkalanaṃ dehe bhūtānyātmani vai tathā
]

`v 18 [
ātmā cittatayā dehabhūtānyāśleṣayansthitaḥ |
tṛṇānyāvṛttavṛttāntakalanotsiktamabdhivat
]

`v 19 [
prabodhāccetyatāṃ tyaktvā vrajatyātmātmatāṃ svayam |
svaspandavaśato vāri tyaktvācchatvamivācchatāṃ
]

`v 20 [
tato viśliṣṭabhūtaugho dehaṃ saṃprati paśyati |
vāyuskandhagato janturvasudhāmaṇḍalaṃ yathā
]

`v 21 [
pṛthagbhūtagaṇaṃ dṛṣṭvā dehātīto bhavatyajaḥ |
paraṃ prakāśamāyāti sūryakāntirivāhani
]

`v 22 [
jānātyathātmanātmānaṃ mānameyāmayojjhitam |
muktakṣībatayevāntaḥ svāṃ saṃvidamanusmaran
]

`v 23 [
ātmaiva spandate viśvaṃ vastujātairivoditam |
taraṅgakaṇakallolairanantāmbvambudhāviva
]

`v 24 [
evaṃprāyamahābodhā vītarāgā gatainasaḥ |
jīvanmuktāścarantīha mahāsattvapadaṃ gatāḥ
]

`v 25 [
yathā caranti vividhairmaṇiratnairmahormayaḥ |
nirastavāsanāścittavyavahāraistathottamāḥ
]

`v 26 [
na kūlakāṣṭhairjaladhirna rajobhirnabhastalam |
na mlāyati nijairlokavyavahārairihātmavān
]

`v 27 [
gatairabhyāgataiḥ svacchaiścapalairmalinairjaḍaiḥ |
na rāgo nāmbudherdveṣo bhogaiścādhigatātmanaḥ
]

`v 28 [
yanmanomananaṃ kiṃcitsamagraṃ jagati sthitam |
taccetyonmukhacittattvavilāsollasanaṃ viduḥ
]

`v 29 [
yadahaṃ yacca bhūtādi kālatritayabhāvi yat |
dṛśyadarśanasaṃbandhavistāraistadvijṛmbhate
]

`v 30 [
yaddṛśyaṃ tadasatsadvā dṛṣṭimekāmupāśritam |
anyattvalepakaṃ tasmāddharṣaśokadṛśau kutaḥ
]

`v 31 [
iha dṛk dṛśyaṃ ceti dvayamadhye ekāṃ dṛṣṭimupāśritaṃ
tadadhīnasiddhikaṃ yaddṛśyaṃ tadasatsadvetyanirṇītatvāddharṣaśokāyogyam |
anyatsvataḥsiddhaṃ dṛgrūpaṃ tvalepakamasaṅgamutpannābhyāmapi
harṣaśokābhyāṃ na yujyata iti tayorubhayathāpi saṃbhāvanaiva nāstītyarthaḥ | 30
|
asatyamevāsatyaṃ hi satyaṃ satyaṃ sadeva hi |
satyāsatyamasadviddhi tadarthaṃ kiṃ nu muhyasi
]

`v 32 [
asamyagdarśanaṃ tyaktvā samyakpaśya sulocana |
na kvacinmuhyati prauḍhaḥ samyagadarśanavāniha
]

`v 33 [
dṛśyadarśanasaṃbandhavistāraistadvijṛmbhate |
dṛśyadarśanasaṃbandhe yatsukhaṃ pāramātmikam
]

`v 34 [
kiṃca bhogasukhārthaṃ sarvairdṛśyadarśanayorviṣayendriyayoḥ saṃbandha
iṣyate tatrābhivyajyamānaṃ pāramātmikameva svaprakāśatvādanubhūtyabhinnaṃ
vṛttyupādhikṛtabhedatāratamyādinirāsenākhaṇḍaikye brahmaiva tadityāha ##-
anubhūtimayaṃ tasmātsāraṃ brahmeti kathyate |
dṛśyadarśanasaṃbandhe sukhasaṃvidanuttamā
]

`v 35 [
dadātyajñāya saṃsāraṃ jñāya mokṣaṃ sadodayam |
dṛśyadarśanasaṃbandhasukhamātmavapurviduḥ
]

`v 36 [
taddṛśyavalitaṃ bandhastanmuktaṃ muktirucyate |
dṛśyadarśanasaṃbandhasukhasaṃvidanāmayā
]

`v 37 [
kṣayātiśayamuktā cettanmuktiḥ socyate budhaiḥ |
dṛśyadarśanasaṃbandhe yānubhūtiḥ svagocarā
]

`v 38 [
dṛśyadarśananirmuktā tāmālambya bhavābhavaḥ |
sauṣuptī dṛṣṭireṣā hi yātyevaṃ sa.prakāśate
]

`v 39 [
evaṃ ca yāti turyatvamevaṃ muktiriti smṛtā |
dṛśyadarśanamuktāyāṃ yuktāyāṃ parayā dhiyā
]

`v 40 [
dṛśyadarśanasaṃbandhasaṃvidasyāṃ tu rāghava |
nātmā sthūlo na caivāṇurna pratyakṣo na cetaraḥ
]

`v 41 [
na cetano na ca jaḍo na caivāsanna sanmayaḥ |
nāhaṃ nānyo na caivaiko nāneko nāpyanekavān
]

`v 42 [
nābhyāśastho na dūrastho naivāsti na ca nāsti ca |
na prāpyo nāti cāprāpyo na vā sarvo na sarvagaḥ
]

`v 43 [
na padārtho nāpadārtho na pañcātmā na pañca ca |
yadidaṃ dṛśyatāṃ prāptaṃ manaḥśaṣṭhendriyāspadam
]

`v 44 [
tadatītaṃ padaṃ yatsyāttanna kiṃcidiveha tat |
yathābhūtamidaṃ samyagjñasya saṃpaśyato `note[saṃpaśyate iti
mudritapustake pāṭhaḥ] jagat
]

`v 45 [
sarvamātmamayaṃ viśvaṃ nāstyanātmamayaṃ kvacit |
kāṭhinyadravaṇaspandasvāvakāśāvalokanaiḥ
]

`v 46 [
ātmaiva sarvaṃ sarveṣu bhūvāryanilakhāgniṣu |
sattaivāsti na vastūnāṃ yā yā rāma citā vinā |
vyatiriktaṃ tato'smīti viddhi pronmattajalpitam
]

`v 47 [
eko jaganti sakalāni samastakāla-
kalpakramāntaragatāni gatāgatāni |
ātmaiva netarakalākalanāsti kāci-
ditthaṃmatirbhava tayātigato mahātman
]