`v 1 [
dvādaśaḥ sargaḥ 12
śrīvasiṣṭha uvāca |
evaṃ vicārayaṃstatra svarājye janako nṛpaḥ |
cakārākhilakāryāṇi na mumoha ca dhīradhīḥ
]

`v 2 [
na manaḥ prollalāsāsya kvacidānandavṛttiṣu |
kevalaṃ suṣuptasaṃsthaṃ sadaiva vyavatiṣṭhata
]

`v 3 [
tataḥprabhṛtyasau dṛśyaṃ nājahāra na vātyajat |
kevalaṃ vigatāśaṅkaṃ vartamāne vyavasthitaḥ
]

`v 4 [
anāratavivekena tena sadyaḥ sanātanam |
punaḥ kalaṅgaṃ naivāptamambareṇeva rājasam
]

`v 5 [
svavivekānusaṃdhānāditi tasya mahīpateḥ |
samyagjñānamanantābhamalaṃ vimalatāṃ yayau
]

`v 6 [
anāmṛṣṭavikalpāṃśuścidātmā vigatāmayaḥ |
udiyāya hṛdākāśe tasya vyomnīva bhāskaraḥ
]

`v 7 [
sa dadarśākhilānbhāvāṃścicchaktau samavasthitān |
ātmabhūtānanantātmā sarvabhūtātmakovidaḥ
]

`v 8 [
prahṛṣṭo na babhūvāsau kvacinna ca suduḥkhitaḥ |
prakṛtervyavahāratvātsadaiva samamānasaḥ
]

`v 9 [
jīvanmukto babhūvāau tataḥprabhṛti mānadaḥ |
janako jaraṭhajñānī jñātalokaparāvaraḥ
]

`v 10 [
rājyaṃ kurvanvidehānāṃ janako janajīvitam |
naiva harṣaviṣādābhyāṃ so'vaśaḥ paritapyate
]

`v 11 [
nāstameti na codeti guṇadoṣaviceṣṭitaiḥ
]

`v 12 [
arthānarthaiḥ sa rājyotthairna glāyati na hṛṣyati |
kurvannapi karotyeṣa na kiṃcidapi kutracit |
sa tiṣṭhatyeva satataṃ sarvadaivāntare citaḥ
]

`v 13 [
suṣuptāvasthitasyaiva janakasya mahīpateḥ |
bhāvanāḥ sarvabhāvebhyaḥ sarvathaivāstamāgatāḥ
]

`v 14 [
bhaviṣyaṃ nānusaṃdhatte nātītaṃ cintayatyasau |
vartamānanimeṣaṃ tu hasannevānuvartate
]

`v 15 [
svavicāravaśenaiva tena tāmarasekṣaṇa |
prāptaṃ prāpyamaśeṣeṇa rāma netarayecchayā
]

`v 16 [
tāvattāvatsvakenaiva cetasā pravicāryate |
yāvadyāvadvicārāṇāṃ sīmāntaḥ samavāpyate
]

`v 17 [
na tadgurorna śāstrārthānna puṇyātprāpyate padam |
yatsādhusaṅgābhyuditādvicāraviśadāddhṛdaḥ
]

`v 18 [
sundaryā nijayā buddhyā prajñayeva vayasyayā |
padamāsādyate rāma na nāmakriyayānyayā
]

`v 19 [
yasyojjvalati tīkṣṇāgrā pūrvāparavicāriṇī |
prajñādīpaśikhā jātu jāḍyāndhyaṃ taṃ na bādhate
]

`v 20 [
duruttarā yā vipado duḥkhakallolasaṃkulāḥ |
tīryate prajñayā tābhyo nāvāpadbhyo mahāmate
]

`v 21 [
prajñāvirahitaṃ mūḍhamāpadalpāpi bādhate |
pelavācānilakalā sārahīnamivolapam
]

`v 22 [
prajñāvānasahāyo'pi viśāstro'pyarimardana |
uttaratyeva saṃsārasāgarādrāma pelavāt
]

`v 23 [
prajñāvānasahāyo'pi kāryāntamadhigacchati |
duṣprajñaḥ kāryamāsādya pradhānamapi naśyati
]

`v 24 [
śāstrasajjanasaṃsargaiḥ prajñāṃ pūrvaṃ vivardhayet |
sekasaṃrakṣaṇārambhaiḥ phalaprāptau latāmiva
]

`v 25 [
prajñābalabṛhanmūlaḥ kāle satkāryapādapaḥ |
phalaṃ phalatyatisvādu bhāso bimbamivaindavam
]

`v 26 [
ya eva yatnaḥ kriyate bāhyārthopārjane janaiḥ |
sa eva yatnaḥ kartavyaḥ pūrvaṃ prajñāvivardhane
]

`v 27 [
sīmāntaṃ sarvaduḥkhānāmāpadāṃ kośamuttamam |
bījaṃ saṃsāravṛkṣāṇāṃ prajñāmāndyaṃ vināśayet
]

`v 28 [
svargādyadyacca pātālādrājyādyatsamavāpyate |
tatsamāsādyate sarvaṃ prajñākośānmahātmanā
]

`v 29 [
prajñayottīryate bhīmāttasmātsaṃsārasāgarāt |
na dānairna ca vā tīrthaistapasā naca rāghava
]

`v 30 [
yatprāptāḥ saṃpadaṃ daivīmapi bhūmicarā narāḥ |
prajñāpuṇyalatāyāstatphalaṃ svādu samutthitam
]

`v 31 [
prajñayā nakharālūnamattavāraṇayūthapāḥ |
jambukairvijitāḥ siṃhāḥ siṃhairhariṇakā iva
]

`v 32 [
sāmānyairapi bhūpatvaṃ prāptaṃ prajñāvaśānnaraiḥ |
svargāpavargayogyatvaṃ prājñasyaiveha dṛśyate
]

`v 33 [
prajñayā vādinaḥ sarve svavikalpavilāsinaḥ |
jayanti subhaṭaprakyānnarānapyatibhīravaḥ
]

`v 34 [
cintāmaṇiriyaṃ prajñā hṛtkośasthā vivekinaḥ |
phalaṃ kalpalatevaiṣā cintitaṃ saṃprayacchati
]

`v 35 [
bhavyastarati saṃsāraṃ prajñayāpohyate'dhamaḥ |
śikṣitaḥ pāramāpnoti nāvā nāpnotyaśikṣitaḥ
]

`v 36 [
dhīḥ samyagyojitā pāramasamyagyojitā'padam |
naraṃ nayati saṃsāre bhramantī naurivārṇave
]

`v 37 [
vivekinamasaṃmūḍhaṃ prājñamāśāgaṇotthitāḥ |
doṣā na paribādhante sannaddhamiva sāyakāḥ
]

`v 38 [
prajñayeha jagatsarvaṃ samyagevāṅga dṛśyate |
samyagdarśanamāyānti nāpado naca saṃpadaḥ
]

`v 39 [
pidhānaṃ paramārkasya jaḍātmā vitato'sitaḥ |
ahaṃkārāmbudo mattaḥ prajñāvātena bādhyate
]

`v 40 [
padamatulamupaitumicchatoccaiḥ
prathamamiyaṃ matireva lālanīyā |
phalamabhilaṣatā kṛṣīvalena
prathamataraṃ nanu kṛṣyate dharaiva
]