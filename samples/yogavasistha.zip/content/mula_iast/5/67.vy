`v 1 [
saptaṣaṣṭitamaḥ sargaḥ 67
śrīvasiṣṭha uvāca |
evaṃ tau kuśalapraśnaṃ kṛtavantau parasparam |
kālenāsādya vimalaṃ jñānaṃ mokṣaṃ tato gatau
]

`v 2 [
tato vacmi mahābāho yathā jñānetarā gatiḥ |
nāsti saṃsārataraṇe pāśabandhasya cetasaḥ
]

`v 3 [
idaṃ bhavyamaterduḥkhamanantamapi pelavam |
kukhagasyā'taro'mbhodhiḥ sarpārergoṣpadāyate
]

`v 4 [
dehātītā mahātmānaścinmātrasvātmani sthitāḥ |
dūrāddehaṃ samīkṣante prekṣako janatāmiva
]

`v 5 [
dehe duḥkhātisaṃkṣubdhe kā naḥ kṣatirupasthitā |
rathe vidhurite bhagne sāratheḥ keva khaṇḍanā
]

`v 6 [
manasi kṣubdhatāṃ yāte cittvasyāṅga kimāgatam |
taraṅgajalasaṃtāne vaiparītyaṃ kimambudheḥ
]

`v 7 [
ke'bhavanpayasāṃ haṃsāḥ payasāmupalāśca ke |
kāḥ śilāḥ kila dārūṇāṃ ke bhogāḥ paramātmanaḥ
]

`v 8 [
ahaṃtātyāge kasyāpi kvāpi mamatāprasaktireva nāstītyāśayenāha -
ke'bhavannityādinā | nahyacetanānāmasaṅgacito vā mamatāprasaktirastīti bhavaḥ |
7 |
saṃbandhaḥ ka iva śrīman śailāparasamudrayoḥ |
antare girisaṃbādhe kaśca cittattvabandhayoḥ
]

`v 9 [
apyutsaṅgohyamānāni padmāni saridambhasām |
kāni nāma bhavantīha śarīrāṇi tathātmanaḥ
]

`v 10 [
saṃghaṭṭātkāṣṭhapayasoryathottuṅgāḥ kaṇādayaḥ |
dehātmanoḥ samāyogāttathaitāścittavṛttayaḥ
]

`v 11 [
saṃbandhāddārupayasāṃ pratibimbāni dāruṇaḥ |
yathā payasi lakṣyante śarīrāṇi tathātmani
]

`v 12 [
yathā darpaṇavīcyādau pratibimbāni vastutaḥ |
nāsatyāni ca satyāni śarīrāṇi tathātmanaḥ
]

`v 13 [
dāruvāryupalāsphoṭe duḥkhitā na yathā kvacit |
saṃyukteṣu viyukteṣu na tathā pañcasu kṣatiḥ
]

`v 14 [
dārusaṃśleṣitāttoyātkampaśabdādayo yathā |
prajāyante tathaivāsmāddehāccitparibodhitāt
]

`v 15 [
na śuddhajaḍayoretāḥ saṃvidaściccharīrayoḥ |
etā hyajñānamātrasya tasminnaṣṭe cideva naḥ
]

`v 16 [
bhāsamānāḥ sukhaduḥkhādisaṃvidaḥ kasya tarhīti cenna kasyāpītyāha - neti |
15 |
yathā na kasyacidvāridāruśleṣe'nubhūtayaḥ |
tathā na kasyaciddehadehisaṅge'nubhūtayaḥ
]

`v 17 [
anubhūtayaḥ sukhaduḥkhānubhavāḥ | dehadehinordehatadabhimāninoḥ saṅge | 16
|
ajñasyāyaṃ yathā dṛṣṭaḥ saṃsāraḥ satyatāṃ gataḥ |
na jñasyāyaṃ yathābhūtaḥ saṃsāraḥ satyatāṃ gataḥ
]

`v 18 [
antaḥsaṅgavihīnāstu yathā snehā dṛṣajjale |
tathāsaktamanovṛttau bāhyabhogānubhūtayaḥ
]

`v 19 [
antaḥsaṅgena rahito yadvatsalilakāṣṭhayoḥ |
saṃbandhastadvadevāntarasaṅgo dehadehinoḥ
]

`v 20 [
antaḥsaṅgena rahitaḥ saṃbandho jalakāṣṭhayoḥ |
sa dehadehinoścaivaṃ pratibimbāmbhasostathā
]

`v 21 [
sthitā sarvatra saṃvittiḥ śuddhā saṃvedyavarjitā |
dvitvopalāñchitā tvanyā duḥsaṃvittirna vidyate
]

`v 22 [
aduḥkhameti duḥkhitvamantaḥsaṃvedanā sphuṭam |
sphāro bhavati vetālo vetālatvena bhāvitaḥ
]

`v 23 [
asaṃbandho'pi saṃbandho bhavatyantarviniścayāt |
svapnāṅganāsuratavatsthāṇuvetālasaṅgavat
]

`v 24 [
asatprāyo hi saṃbandho yathā salilakāṣṭhayoḥ |
tathaiva mithyāsaṃbandhaḥ śarīraparamātmanoḥ
]

`v 25 [
antaḥsaṅgaṃ vinā nāmbu kāṣṭhapātaiḥ pragṛhyate |
ātmā'ṅgasaṅgarahito dehaduḥkhairna dahyate
]

`v 26 [
dehabhāvanayaivātmā dehaduḥkhavaśe sthitaḥ |
tattyāgena tato mukto bhavatīti vidurbudhāḥ
]

`v 27 [
antaḥsaṅgavihīnatvādduḥkhavantyaṅga no yathā |
patrāmbumaladārūṇi śliṣṭānyapi parasparam
]

`v 28 [
antaḥsaṅgena rahitā yānti nirduḥkhatāṃ parām |
śliṣṭānyapi tathaivātmadehendriyamanāṃsyalam
]

`v 29 [
antaḥsaṅgo hi saṃsāre `note[saṃsāraḥ ityapi pāṭhaḥ] sarveṣāṃ rāma
dehinām |
jarāmaraṇamohānāṃ tarūṇāṃ bījakāraṇam
]

`v 30 [
antaḥsaṃsaṅgavāñjanturmagnaḥ saṃsārasāgare |
antaḥsaṃsaktimuktastu tīrṇaḥ saṃsārasāgarāt
]

`v 31 [
antaḥsaṃsaṅgavaccittaṃ śataśākhamivocyate |
antaḥsaṃsaṅgarahitaṃ vilīnaṃ cittamucyate
]

`v 32 [
bhagnasphaṭikavadviddhi manaḥ saktamapāvanam |
abhagnasphaṭikābhāsamasaktaṃ viddhi me manaḥ
]

`v 33 [
yathā bhagnamantarvidīrṇaṃ sphaṭikaliṅgādi apāvanaṃ pūjādyayogyaṃ tadvat |
32 |
asaktaṃ nirmalaṃ cittaṃ muktaṃ saṃsāryapi sphuṭam |
saktaṃ tu dīrghatapasā yuktamapyatibandhavat
]

`v 34 [
antaḥsaktaṃ mano baddhaṃ muktaṃ saktivivarjitam |
antaḥsaṃsaktirevaikaṃ kāraṇaṃ bandhamokṣayoḥ
]

`v 35 [
antaḥsaṃsaktimuktasya kurvato'pi na kartṛtā |
guṇadoṣavatī toye dāruvāhananauryathā
]

`v 36 [
antaḥsaṃsaktito jantorakarturapi kartṛtā |
sukhaduḥkhavati svapne saṃbhramonmukhatā yathā
]

`v 37 [
citte kartari kartṛtvamadehasyāpi `note[kartṛtvaṃ dehasyāpi hi iti
pāṭhaścintyaḥ] vidyate |
svapnādāviva vikṣubdhasukhaduḥkhadṛśopamam
]

`v 38 [
akartari manasyantarakartṛtvaṃ sphuṭaṃ bhavet |
śūnyacitto hi puruṣaḥ kurvannapi na cetati
]

`v 39 [
cetasā kṛtamāpnoṣi cetasā na kṛtaṃ tu na |
na kvacitkāraṇaṃ deho na ca cittena kartṛtā
]

`v 40 [
asaṃsaktamakarteva kurvadeva mano viduḥ |
na karmaphalabhoktṛtvamasaktaṃ pratipadyate
]

`v 41 [
brahmahatyāśvamedhābhyāmasaṃsakto na lipyate |
dūrasthakāntāsaṃlīnamanāḥ kāryairivāgragaiḥ
]

`v 42 [
antaḥsaṃsaktinirmukto jīvo madhuravṛttimān |
bahiḥkurvannakurvanvā kartā bhoktā na hi kvacit
]

`v 43 [
antaḥsaṃsaktimuktaṃ yanmanaḥ syāttadakartṛkam |
tadvimuktaṃ praśāntaṃ tattadyuktaṃ tadalepakam
]

`v 44 [
tasmātsarvapadārthānāṃ śliṣṭānāṃ niścitaṃ bahiḥ |
sarvaduḥkhakarīṃ krūrāmantaḥsaktiṃ vivarjayet
]

`v 45 [
virahitamalamantaḥsaṅgadoṣeṇa cetaḥ
śamamupagatamādyaṃ vyomavannirmalābham |
sakalamalavimuktenātmanaikatvameti
sthiramaṇinibhamambhovāriṇī vārinīle
]