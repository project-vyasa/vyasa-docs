`v 1 [
aṣṭāviṃśaḥ sargaḥ 28
śrīvasiṣṭha uvāca |
atha te dānavāstatra baleranucarāstadā |
tadgehaṃ sphāṭikaṃ saudhamuccairāruruhuḥ kṣaṇāt
]

`v 2 [
ḍimbhādyā mantriṇo dhīrāḥ sāmantāḥ kumudādayaḥ |
surādyāścaiva rājāno vṛttādyā balahāriṇaḥ
]

`v 3 [
hayagrīvādayaḥ sainyāścākrājādyāśca `note[cakretyapi pāṭhaḥ]
bāndhavāḥ |
laḍukādyāśca suhṛdo ballūkādyāśca lālakāḥ
]

`v 4 [
kuberayamaśakrādyā upāyanakarāḥ surāḥ |
yakṣavidyādharā nāgāḥ sevāvasarakāṅkṣiṇaḥ
]

`v 5 [
rambhātilottamādyāśca cāmariṇyo varāṅganāḥ |
sāgarāḥ saritaḥ śailā diśaśca vidiśastathā
]

`v 6 [
sevārthamāyayustasya taṃ pradeśaṃ tadā baleḥ |
anye ca bahavaḥ siddhāstrailokyaodaravāsinaḥ
]

`v 7 [
dhyānamaunasamādhisthaṃ citrārpitamivācalam |
namatkirīṭāvalayo dadṛśurbalimādṛtāḥ
]

`v 8 [
taṃ dṛṣṭvā kṛtakartavyapraṇāmāste mahāsurāḥ |
viṣādavismayānandabhayamantharatāṃ yayuḥ
]

`v 9 [
mantriṇaḥ pravicāryātra kiṃ prāptamiti dānavāḥ |
bhārgavaṃ cintayāmāsurguruṃ sarvavidāṃvaram
]

`v 10 [
cintanānantaraṃ daityā bhārgavaṃ bhāsvaraṃ vapuḥ |
dadṛśuḥ kalpitaṃ prāptaṃ gandharvanagaraṃ yathā
]

`v 11 [
pūjyamāno'suragaṇairniviṣṭo guruviṣṭare |
dadarśa dhyānamaunasthaṃ bhārgavo dānaveśvaram
]

`v 12 [
viśramya sa kṣaṇamiva premavānavalokya ca |
baliṃ vicārayandṛṣṭvā parikṣīṇabhavabhramam
]

`v 13 [
deharaśmiśatairdattadīptibhiḥ kṣīrasāgaram |
kṣipanniva sabhāmāha hasanvākyamidaṃ guruḥ
]

`v 14 [
atimātramidaṃ daityāḥ svavicāraṇayaiva yat |
saṃprāptavimalāvāsaḥ siddho'yaṃ bhagavānbaliḥ
]

`v 15 [
ayaṃ tadevameveha tiṣṭhandānavasattamāḥ |
svātmani sthitimāpnotu padaṃ paśyatvanāmayam
]

`v 16 [
śrānto viśrāmamāyātaḥ kṣīṇacittabhavabhramaḥ |
śāntasaṃsāranīhāro vācanīyo na dānavāḥ
]

`v 17 [
sva evāloka etena saṃprāpto'jñānasaṃkaṭe |
śānte'tra saṃbhrame sauro dineneva karotkaraḥ
]

`v 18 [
svayameva hi kālena prabodhamayameṣyati |
bījakośātsvasaṃvittyā suptamūrtirivāṅkuraḥ
]

`v 19 [
kurudhvaṃ svāmikāryāṇi sarve dānavanāyakāḥ |
balirvarṣasahasreṇa samādherbodhameṣyati
]

`v 20 [
ityuktā guruṇā tatra harṣāmarṣaviṣādajām |
daityāścintāṃ jahuḥ śuṣkāṃ mañjarīmiva pādapāḥ
]

`v 21 [
vairocanisabhāsaṃsthāṃ vidhāya prāgvyavasthayā |
svavyāpāraparāstasthuḥ sarva evāsurāstataḥ
]

`v 22 [
narā mahī mahipatayo rasātalaṃ
grahā nabhastridaśagaṇāstriviṣṭapam |
diśo'drayo `note[asminpadye chandobhedaḥ] dikpatayaśca kaṃdarā-
nvanecarā gaganacarāśca khaṃ yayuḥ
]