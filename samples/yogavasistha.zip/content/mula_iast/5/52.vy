`v 1 [
dvipañcāśaḥ sargaḥ 52
sa tāṃ viveśa dharmātmā gandhamādanakandarām |
citrabhramaṇasaṃprāptāmaliḥ padmakuṭīmiva
]

`v 2 [
samādhānonmukhatayā praviśansa vyarājata |
sargavyāpāraviratāvātmapuryāmivābjajaḥ
]

`v 3 [
cakārāsanamamlānaiḥ patrairantasvagucchakam |
mṛdumeghavidhirvṛndamambhodamiva tatra saḥ
]

`v 4 [
sa tatprastārayāmāsa pṛṣṭhe cāru mṛgājitam |
nīlaratnataṭe merustārāsāramivāmbaram
]

`v 5 [
sa tatropāviśadvṛttīścetasastanutāṃ nayan |
antaḥśuddhavapuḥ śṛṅge vṛṣya mūka ivāmbudaḥ
]

`v 6 [
buddhavatsudṛḍhaṃ baddhapadmāsana udaṅmukhaḥ |
pārṣṇibhyāṃ vṛṣaṇau dhṛtvā cakāra brāhmamañjalim
]

`v 7 [
vāsanābhyaḥ samāhṛtya manomṛgamupaplutam |
nirvikalpasamādhyarthaṃ cakāremāṃ vicāraṇām
]

`v 8 [
ayi mūrkha manaḥ ko'rthastava saṃsāravṛttibhiḥ |
dhīmanto na niṣevante paryante duḥkhadāṃ kriyām
]

`v 9 [
anudhāvati yo bhogāṃstyaktvā śamarasāyanam |
saṃtyajya mandāravanaṃ sa yāti viṣajaṅgalam
]

`v 10 [
yadi yāsi mahīrandhraṃ brahmalokamathāpi vā |
tanna nirvāṇamāyāsi vinopaśamanāmṛtam
]

`v 11 [
āśāśatāvapūrṇatve tvamevaṃ sarvaduḥkhadam |
tyajya yāhi paraṃ śreyaḥ paramekāntasundaram
]

`v 12 [
tvaṃ bhogāśāśatenāvapūrṇatve sati evaṃ prāguktarītyā sarvaduḥkhadaṃ bhavasi
| ataḥ paraṃ bhogāśāstyajya tyaktvā | lyap chāndasaḥ |
nirduḥkhaniratiśayānandarūpatvādekāntasundaraṃ paraṃ śreyo nirvāṇaṃ yāhi |
11 |
imā vicitrāḥ kalanā bhāvābhāvamayātmikāḥ |
duḥkhāyaiva tavogrāya na sukhāya kadācana
]

`v 13 [
śabdādikābhiretābhiḥ kiṃ mūrkha hatavṛttibhiḥ |
bhramasyavirataṃ vyarthaṃ meghe maṇḍūkikā yathā
]

`v 14 [
manomaṇḍūkike vyarthamiyantaṃ kālamandhayā |
bhramantyā bhuvanaṃ kṣipraṃ kiṃ samāsāditaṃ tvayā
]

`v 15 [
yasmātkiṃcidavāpnoṣi yasminvahasi nirvṛtim |
tasmiṃścetaḥ śame mūrkha nānubadhnāsi kiṃ padam
]

`v 16 [
āgatya śrotratāṃ mūrkha vyarthotthānopabṛṃhitām |
dhiyā śabdānusāriṇyā mṛgavanmā kṣayaṃ vraja
]

`v 17 [
tvaktāmāgatya duḥkhāya sparśonmukhatayā dhiyā |
mūrkha mā baddhatāmehi gajīlubdhagajendravat
]

`v 18 [
rasanābhāvamāgatya garddhenāndha durandhasām |
mā nāśamehi baḍiśapiṇḍīlampaṭamatsyavat
]

`v 19 [
cākṣuṣīṃ vṛttimāśritya prabhārūpacayonmukhīm |
mā gaccha dagdhatāṃ mugdha kāntilubdhapataṅgavat
]

`v 20 [
ghrāṇamārgamupāśritya śarīrāmbhojakoṭare |
gandhonmukhatayā bandhaṃ mā tvaṃ saṃśraya bhṛṅgavat
]

`v 21 [
kuraṅgālipataṅgebhamīnāstvekaikaśo hatāḥ |
sarvairyuktairanarthaistu vyāptasyājña kutaḥ sukham
]

`v 22 [
he citta vāsanājālaṃ bandhāya bhavatohitam |
svātmanaḥ sahajaḥ phenastataḥ kukṛmiṇā yathā
]

`v 23 [
*? dabhravadāgatya śuddhiṃ tyaktabhavāmayām |
yadi śāmyasi nirmūlaṃ tadananto jayastava
]

`v 24 [
kṣayodayadaśādhātrīṃ paryantaparitāpinīm |
jānannapi jagatsṛṣṭiṃ na tyakṣyasi vinaṃkṣyasi
]

`v 25 [
karomyatha kimarthaṃ vā tavaitadanuśāsanam |
vicāraṇavataḥ puṃsaścittamasti hi nānagha
]

`v 26 [
yāvadajñānaghanatā tāvatpraghanacittatā |
yāvatprāvṛḍjaladatā tāvannīhārabhūritā
]

`v 27 [
yāvadajñānatanutā tāvaccittasya tānavam |
prāvṛṭparikṣayo yāvattāvannīhārasaṃkṣayaḥ
]

`v 28 [
yāvattānavamāyātaṃ śuddhaṃ cittaṃ vicārataḥ |
tāvattatkṣīṇamevāhaṃ manye śāradameghavat
]

`v 29 [
anuśāsanametadyadasato naśyato'tha vā |
kriyate tannabhovāripavanāhananaiḥ samam
]

`v 30 [
tasmātsaṃkṣīyamāṇatvāttyajāmi tvāmasanmayam |
maurkhyaṃ paramamevāhuḥ parityājyānuśāsanam
]

`v 31 [
nirvikalpo'smi ciddīpo nirahaṃkāravāsanaḥ |
tvayāhaṃkārabījena na saṃbaddho'smyasanmaya
]

`v 32 [
ātmanastadasaṃbandhadarśanameva tattyāga ityāśayenāha - nirvikalpa iti | 31
|
ayaṃ so'hamiti vyarthaṃ durdṛṣṭiravalambitā |
tvayā mūḍhavināśāya śaṅkāviṣaviṣūcikā
]

`v 33 [
anantasyātmatattvasya tanvīti manasi sthitiḥ |
na saṃbhavati bilvāntarvāsitādantinoryathā
]

`v 34 [
mahāśvabhrīva gambhīrā duḥkhadā vāsanāśritā |
tvayaiṣā bata citteti naināmanusarāmyaham
]

`v 35 [
kaḥ kilāyaṃ mudhā moho bālasyevāvicāriṇaḥ |
ayaṃ so'hamiti bhrāntistvahaṃtāparikalpitā
]

`v 36 [
pādāṅguṣṭhācchiro yāvatkaṇaśaḥ pravicāritam |
na labdho'sāvahaṃ nāma kaḥ syādahamiti sthitaḥ
]

`v 37 [
bharitāśeṣadikkuñjaṃ yatsyāmekaṃ jagattraye |
saṃvedanamasaṃvedyaṃ sarvatravigatātmakam
]

`v 38 [
dṛśyate yasya neyattā na nāma parikalpanā |
naikatā nānyataiveha na mahattā na cāṇutā
]

`v 39 [
veda tattvāṃ svasaṃvedyamātataṃ duḥkhakāraṇam |
vivekajena bodhena tadidaṃ hanyase mayā
]

`v 40 [
idaṃ māṃsamidaṃ raktamimānyasthīni dehake |
ime te śvāsamarutaḥ ko'sāvahamiti sthitaḥ
]

`v 41 [
spando hi vātaśaktīnāmavabodho mahācitaḥ |
jarā mṛtiśca kāye'sminko'sāvahamiti sthitaḥ
]

`v 42 [
māṃsamanyadasṛkvānyadasthīnyanyāni citta he |
bodho'nyaḥ spandanaṃ cānyatkosāvahamiti sthitaḥ
]

`v 43 [
idaṃ ghrāṇamiyaṃ jihvā tvagiyaṃ śravaṇe ime |
idaṃ cakṣurasau sparśaḥ ko'sāvahamiti sthitaḥ
]

`v 44 [
yathābhūtatayā nāhaṃ mano na tvaṃ na vāsanā |
ātmā śuddhacidābhāsaḥ kevalo'yaṃ vijṛmbhate
]

`v 45 [
yathābhūtatayā paramārthatayā vicāre manaḥ ahaṃ na | na tvaṃ cittamahaṃ
vāsanāpi nāham | ātmā tu sarvathā ahaṃtayā na spṛṣṭa ityāha - ātmeti | 44
|
ahameveha sarvatra nāhaṃ kiṃcidapīha vā |
ityeva sanmayī dṛṣṭirnetaro vidyate kramaḥ
]

`v 46 [
ciramajñānadhūrtena pothito'smi tvahaṃtayā |
vṛkeṇa dṛptenāṭavyāṃ labdhena paśupotakaḥ
]

`v 47 [
diṣṭyedānīṃ parijñāto mayaivājñānataskaraḥ |
punarna saṃśrayāmyenaṃ svarūpārthāpahāriṇam
]

`v 48 [
nirduḥkho duḥkhayogyasya nāhaṃ tasya na caiṣa me |
kaścidbhavati śailasya tatstha eva yathāmbudaḥ
]

`v 49 [
bhūtvā tvahamidaṃ vacmi vedmi tiṣṭhāmi yāmi ca |
ātmāvalokanenāhamanahaṃkāratāṃ gataḥ
]

`v 50 [
nūnamevāhamevaite manye jñāścakṣurādayaḥ |
yāntu tiṣṭhantu vā dehe mamaite tu na kiṃcana
]

`v 51 [
kaṣṭaṃ ko'yamahaṃ nāma kathaṃ kenopakalpitaḥ |
jagadbālakavetālastālottālātulākṛtiḥ
]

`v 52 [
etāvantaṃ ciraṃ kālaṃ vyarthamāluṭhito'vaṭe |
ahamatra tṛṇonmukte duradrau hariṇo yathā
]

`v 53 [
svārthamālokane cakṣuryaditūnmukhatāṃ gatam |
tadahaṃ nāma kosau syādyo'sminduḥkhe na mohitaḥ
]

`v 54 [
sparśanāya nije tattve yadi jātā tvagunmukhī |
tatkoyaṃ syādahaṃ nāma kupiśāca ivoditaḥ
]

`v 55 [
raseṣvabhiniṣaṇṇe'sminsvakrame rasanendriye |
ahaṃ mṛṣṭabhugityeṣa kutastyaḥ kutsito bhramaḥ
]

`v 56 [
śabdaśaktiṃ gate śrotre varāke svārthapīḍite |
tadahaṃkāraduḥkhasya nirbījasya ka āgamaḥ
]

`v 57 [
ātmaṃbharitvena nije ghrāṇe svaṃ gandhamāgate |
ahaṃ ghrāteti yo mātā taṃ cauraṃ naiva vedmyaham
]

`v 58 [
mṛgatṛṣṇākrameṇaiṣā bhāvanā vyarthabhāvinī |
bhāvastasyāmasatyāyāṃ yaḥ so'yamiti saṃbhramaḥ
]

`v 59 [
vāsanāhīnamapyetaccakṣurādīndriyaiḥ svataḥ |
pravartate bahiḥ svārthe vāsanā nātra kāraṇam
]

`v 60 [
vāsanārahitaṃ karma kriyate nanu citta he |
kevalaṃ nānubhūyante sukhaduḥkhadṛśo'gragāḥ
]

`v 61 [
yadi pravartate tarhi tatprayuktaṃ duḥkhamapi bhaviṣyatyeveti vāsanātyāgātko
guṇastatrāha - vāsaneti | tātkālikabhogābhāse ahaṃ duḥkhīti nābhimānaḥ
agragāḥ bhāvinyastu sukhaduḥkhadṛśo nānubhūyanta iti tatprayuktā
śokamohabhayaviṣādacintodvegādisarvasaṃtāpaśāntirevāsya guṇa iti bhāvaḥ |
60 |
tasmānmūrkhāṇīndriyāṇi tyaktvāntarvāsanāṃ nijām |
kurudhvaṃ karma he sarvaṃ na duḥkhaṃ samavāpsyatha
]

`v 62 [
idānīmindriyāṇi saṃbodhyāmumarthaṃ vivicyopadiśati - tasmādityādinā | 61
|
bhavadbhireva duḥkhāya vāsanāvāsitā mudhā |
bālaiḥ paṅkakrīḍanakaṃ vināśeneva khinnatā
]

`v 63 [
vāsanādyā dṛśaḥ sarvā vyatiriktāstu nātmanaḥ |
jalādiva taraṅgādyā jñasyaivānyasya nānagha
]

`v 64 [
tṛṣṇayaiva vinaṣṭāḥ stha vyarthamindriyabālakāḥ |
kośakārakukṛmayastantuneva svayaṃbhuvā
]

`v 65 [
tṛṣṇayaiveha luṭhatha jarāmaraṇasaṃkaṭe |
bhramaddṛṣṭyeva śikharipathikāḥ śvabhrabhūmiṣu
]

`v 66 [
vāsanaiveha bhavatāṃ heturekatra bandhane |
rajjuḥ śūnyāśayaprotā muktānāmātatā yathā
]

`v 67 [
kalpanāmātrakalitā satyaiṣā hi na vastutaḥ |
asaṃkalpanamātreṇa dātreṇeva vilūyate
]

`v 68 [
kalpanādbhrāntistanmātreṇa kalitā saṃpāditā | eṣā vāsanā | 67 |
eṣā hi bhavatāmeva vimohāya kṣayāya ca |
vātalekheva dīpānāṃ sphuratāmapi tejasām
]

`v 69 [
he citta sarvendriyakośa tasmā-
tsarvendriyairaikyamupetya nūnam |
ālokya cātmānabhasatsvarūpaṃ
nirvāṇamevāmalabodhamāssva
]

`v 70 [
viṣayaviṣaviṣūcikāmanantāṃ
nipuṇamahaṃsthitivāsanāmapāsya |
abhimataparihāramantrayuktyā
bhava vibhavo bhagavānbhiyāmabhūmiḥ
]