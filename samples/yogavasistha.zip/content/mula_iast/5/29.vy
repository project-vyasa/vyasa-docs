`v 1 [
ekonatriṃśaḥ sargaḥ 29
śrīvasiṣṭha uvāca |
atha varṣasahasreṇa divyenāsurapuṅgavaḥ `note[sattama iti pāṭhaḥ] |
devadundubhinirghoṣairbubudhe bhagavānbaliḥ
]

`v 2 [
balau prabuddhe tadbālaṃ vireje nagaraṃ tadā |
vairiñca iva sūryaugha udite kamalākaraḥ
]

`v 3 [
baliḥ prabuddha evāsau yāvannāyānti dānavāḥ |
tāvatsaṃcintayāmāsa samādhisadane kṣaṇam
]

`v 4 [
aho nu ramyā padavī śītalā pāramārthikī |
ahamasyāṃ kṣaṇaṃ sthitvā parāṃ viśrāntimāgataḥ
]

`v 5 [
tadetāmeva padavīmavalambya karomyaham |
bhavatīhopabhuktābhiḥ kiṃ me bāhyavibhūtibhiḥ
]

`v 6 [
aindaveṣvapi bimbeṣu na tathānandavīcayaḥ |
toṣayanti yathāntarme saṃsiddhibhavabhūtayaḥ
]

`v 7 [
tadevāha - aindaveṣviti | saṃsiddhiḥ samādhiparipākastadbhavā bhūtaya
ānandāḥ | ekasminneva iyattayā aparicchedyatvādbahutvakalpanayā bahuvacanam |
6 |
iti bhūyo'pi viśrāntyai kurvāṇaṃ galitaṃ manaḥ |
balimāvārayāmāsurdaityāścandramivāmbudāḥ
]

`v 8 [
tānālokya punardadhyau tatpraṇāmākulekṣaṇaḥ |
taiḥ kulācalasaṃkāśaiḥ parivītavapustvidam
]

`v 9 [
citaḥ kṣīṇavikalpasya kimupādeyamasti me |
manastadabhipātitvādyāti tadrasatāmalam
]

`v 10 [
mokṣamicchāmyahaṃ kasmādbaddhaḥ kenāsmi vai purā |
abaddho mokṣamicchāmi keyaṃ bālaviḍambanā
]

`v 11 [
na bandhosti na mokṣosti maurkhyaṃ me kṣayamāgatam |
kiṃ me dhyānavilāsena kiṃ vā dhyānena me bhavet
]

`v 12 [
dhyānādhyānabhramau tyaktvā puṃstvaṃ svamavalokayat |
yadāyāti tadāyātu na me vṛddhirna vā kṣayaḥ
]

`v 13 [
na dhyānaṃ nāpi vā'dhyānaṃ na bhogānnāpyabhogitām `note[nātha bhogitā
iti pāṭhaḥ] |
abhivāñchāmi tiṣṭhāmi samameva gatajvaraḥ
]

`v 14 [
na me vāñchā pare tattve na me vāñchā jagatsthitau |
na me dhyānadaśākāryaṃ `note[atra dhyānadṛśā kārya iti sādhu] na
kāryaṃ vibhavena me
]

`v 15 [
nāhaṃ mṛto na jīvāmi na sannāsanna sanmayaḥ |
nedaṃ me naiva cānyanme namo mahyamahaṃ bṛhat
]

`v 16 [
idamastu jagadrājyaṃ tiṣṭhāmyatra tu saṃsthitaḥ |
neha vāstu jagadrājyaṃ tiṣṭhāmyātmani śītalaḥ
]

`v 17 [
kiṃ me dhyānadṛśā kāryaṃ kiṃ rājyavibhavaśriyā |
yadāyāti tadāyātu nāhaṃ kiṃcana me kvacit
]

`v 18 [
na kiṃcidapi kartavyaṃ yadi nāma mayādhunā |
tatkasmānna karomīdaṃ kiṃcitprakṛtakarma vai
]

`v 19 [
iti nirṇīya pūrṇātmā balirjñānavatāṃ varaḥ |
daityānālokayāmāsa padmānīva divākaraḥ
]

`v 20 [
dṛṣṭipātavibhāgena sarveṣāṃ danujanmanām |
śiraḥpraṇāmāñjagrāha puṣpāmodānivānilaḥ
]

`v 21 [
atha vairocanistatra dhyeyatyāgamayātmanā |
manasā sakalānyeva rājakāryāṇi saṃvyaghāt
]

`v 22 [
dvijāndevāngurūṃścaiva pūjayāmāsa pūjayā |
saṃmānayāmāsa suhṛdbandhusāmantasajjanān
]

`v 23 [
pūjā pādyārghyādi ucitadānasaṃbhāvanādisatkāraḥ saṃmānanamiti bhedaḥ | 22
|
arthenāpūrayāmāsa bhūtyānarthigaṇāṃstathā |
lalanā lālayāmāsa vicitravibhavārpaṇaiḥ
]

`v 24 [
ityasau vavṛdhe tasminrājye sakalaśāsane |
yajñaṃ prati babhūvātha matirasya kadācana
]

`v 25 [
tarpitāśeṣabhuvanaṃ devarṣigaṇapūjitam |
saha śukrādibhirmukhyaiḥ sa cakāra mahāmakham
]

`v 26 [
balirbhogabharasyārthī neti nirṇīya mādhavaḥ |
balerīhitasiddhyarthaṃ siddhidastanmakhaṃ yayau
]

`v 27 [
bhogaikakṛpaṇāyedaṃ jagajjaṅgalakhaṇḍakam |
dātuṃ śocyāya śakrāya vayojyeṣṭhāya kāryavit
]

`v 28 [
kramamāṇo balenātra vañcayitvā baliṃ hariḥ |
babandha pātālatale bhūgeha iha vānaram
]

`v 29 [
adyāsau saṃsthito rāma punarindratvahetunā |
jīvanmuktavapuḥ svastho nityaṃ dhyānaviṣaṇṇadhīḥ
]

`v 30 [
pātālakuhare tiṣṭhañjīvanmuktagatirbaliḥ |
āpadaṃ saṃpadaṃ dṛṣṭyā samayaiva sa paśyati
]

`v 31 [
nāstameti na codeti tatprajñā sukhaduḥkhayoḥ |
samā sthirakarā citralekhyā sūryāvaliryathā
]

`v 32 [
āvirbhāvatirobhāvasahasrāṇīha jīvatām |
tanmanāściramālokya bhīmeṣu viratiṃ gatam
]

`v 33 [
daśakoṭīśca varṣāṇāmanuśāsya jagattrayam |
ante viraktatāṃ prāptamupaśāntaṃ balermanaḥ
]

`v 34 [
ūhāpohasahasrāṇi bhāvābhāvaśatāni ca |
balinā paridṛṣṭāni kva samāśvāsametyasau
]

`v 35 [
bhogābhilāṣaṃ saṃtyajya baliḥ saṃpūrṇamānasaḥ |
ātmārāmasthito nityaṃ madhye pātālakoṭare
]

`v 36 [
punaretena balinā jagadindratayākhilam |
anuśāsyamidaṃ rāma bahūnvarṣagaṇāniha
]

`v 37 [
na tasyendrapadaprāptyā tuṣṭiḥ samupajāyate |
na tasya svapadabhraṃśādudvega upajāyate
]

`v 38 [
samaḥ sarveṣu bhāveṣu sarvadaivoditāśayaḥ |
saṃprāptamāharansvastha ākāśa iva tiṣṭhati
]

`v 39 [
balervijñānasaṃprāptireṣā te kathitā mayā |
etāṃ dṛṣṭimavaṣṭabhya tvamapyabhyudito bhava
]

`v 40 [
balivatpravivekena nityo'hamiti niścayāt |
padamāsādayādvaitaṃ pauruṣeṇaiva rāghava
]

`v 41 [
dve cāṣṭau caiva varṣāṇāṃ koṭīrbhuktvā jagattrayam |
ante vairasyamāpanno balirapyasarottamaḥ
]

`v 42 [
tasmādavaśyavairasyaṃ bhogabhāramariṃdama |
saṃtyajya satyamānandamavairasyaṃ padaṃ vraja
]

`v 43 [
imā dṛśyadṛśo rāma nānākāravikāradāḥ |
neha kāntatayā jñeyā dūrācchailaśilā iva
]

`v 44 [
dhāvamānamihāmutra luṭhitaṃ lokavṛttiṣu |
saṃsthāpaya nibaddhyaitacceto hṛdayakoṭare
]

`v 45 [
cidādityo bhavāneva sarvatra jagati sthitaḥ |
kaḥ paraste ka ātmīyaḥ pariskhalasi kiṃ mudhā
]

`v 46 [
tvamananto mahābāho tvamādyaḥ puruṣottamaḥ |
tvaṃ padārthaśatākāraiḥ parisphūrjasi cidvapuḥ
]

`v 47 [
tvayi sarvamidaṃ protaṃ jagatsthāvarajaṃgamam |
bodhe nityodite śuddhe sūtre maṇigaṇā yathā
]

`v 48 [
na jāyase na mriyase tvamajaḥ puruṣo virāṭ |
cicchuddhā janmamaraṇabhrāntayo mā bhavantu te
]

`v 49 [
samastajanmarogāṇāṃ pravicārya balābalam |
tṛṣṇāmutsṛjya bhogānāṃ bhoktaiva bhava kevalam
]

`v 50 [
tvayi sthite jagannāthe cidāditye sadodite |
idamābhāsate sarvaṃ saṃsārasvapnamaṇḍanam
]

`v 51 [
mā viṣādaṃ kṛthā vyarthaṃ sukhaduḥkhaiṣaṇā na te |
śuddhacitto'si sarvātmā sarvavastvavabhāsakaḥ
]

`v 52 [
pūrvamiṣṭamaniṣṭaṃ tvamaniṣṭaṃ ceṣṭamityapi |
parikalpya tadabhyāsāttattato'pi parityaja
]

`v 53 [
iṣṭāniṣṭadṛśostyāge samatodeti śāśvatī |
tayā hṛdayavartinyā punarjanturna jāyate
]

`v 54 [
yeṣu yeṣu pradeśeṣu mano majjati bālavat |
tebhyastebhyaḥ samāhṛtya taddhi tattve niyojayet
]

`v 55 [
evamabhyāgatābhyāsaṃ manomattamataṃgajam |
nibadhya sarvabhāvena paraṃ śreyo'dhigamyate
]

`v 56 [
mā śarīrayathārthajñairmithyādṛṣṭihatāśayaiḥ |
dhūrtaiḥ saṃkalpavikrītairvimūḍhaiḥ samatāṃ vraja
]

`v 57 [
akiṃcanātsvanirṇītau lambamānātparoktiṣu |
na maurkhyādadhiko loke kaścidastīha duḥkhadaḥ
]

`v 58 [
tvametadavivekābbhramuditaṃ hṛdayāmbare |
vivekapavanenāśu dūraṃ naya mahāmate
]

`v 59 [
ātmanaiva prayatnena yāvadātmāvalokane |
na kṛto'nugrahastāvanna vicārodayo bhavet
]

`v 60 [
vedavedāntaśāstrārthatarkadṛṣṭibhirapyayam |
nātmā prakaṭatāmeti yāvanna svamavekṣitam
]

`v 61 [
tvamātmanyātmanā rāma prasāde samavasthitaḥ |
prāpto'si vitataṃ bodhaṃ madvacasyeva budhyase
]

`v 62 [
vikalpāṃśavihīnasya tvayaiṣā cidvivasvataḥ |
gṛhītā vitatā vyāptirmaduktyā paramātmanaḥ
]

`v 63 [
vilīnasarvasaṃkalpaḥ śāntasaṃdehavibhramaḥ |
kṣīṇakautukanīhāro jāto'si vigatajvaraḥ
]

`v 64 [
yadupagacchasi pāsi nihaṃsi vā
pibasi vismayase ca vivardhase |
tadapi tena tadāstu yadā mune
vigatabodhakalaṅkaviśaṅkitaḥ
]