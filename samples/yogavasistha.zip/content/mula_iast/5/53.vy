`v 1 [
tripañcāśaḥ sargaḥ 53
uddālaka uvāca |
apāraparyantavapuḥ paramāṇvaṇureva ca |
cidacetyā tadākrāntau na śaktā vāsanādayaḥ
]

`v 2 [
manaḥ śemuṣyahaṃkārapratibimbairjaḍendriyaiḥ |
vāsanāvitatāḥ śūnyā vetālatrāsanodyatāḥ
]

`v 3 [
tatkṛtebhyo vicārebhyo'nubhūtebhyo'pi bhūriśaḥ |
bhūyo'pyanubhavatyantarahaṃ hi cidalepikā
]

`v 4 [
jāgare bhūriśaḥ kṛtebhyo viṣayavicārebhyo'nubhūtebhyaśca viṣayebhyo
bhūyo'pi svapne'ntarnāḍīcchidrāntarvāsanāmayāneva viṣayāṃstanmanaḥ
anubhavati | naca buddhyahaṃkārakṛtena manonubhūtena vā mama lepaḥ | hi
yasmādalepikā cedevāhaṃ na mana ādisaṃghātātmetyarthaḥ | tathāca śrutiḥ ##-
|
svadurbhāvoparacitāṃ dehaḥ saṃsārasaṃsthitim |
gṛhṇātvatha tyajatu vāpyahaṃ hi cidalepikā
]

`v 5 [
cito na janmamaraṇe sarvagāyāścitaḥ kila |
kiṃ nāma mriyate janturmāryate kena vāpi kim
]

`v 6 [
cito na jīvitenārthaḥ sarvātmā sarvajīvitam |
kiṃ prāpsyati kadātmaiṣā prāyatā yadi jīvitam
]

`v 7 [
jīvyate mriyate ceti kuvikalpakamālinī |
kalanā manasāmeva nātmano vimalātmanaḥ
]

`v 8 [
yo hyahaṃbhāvatāṃ prāpto bhāvābhāvaiḥ sa gṛhyate |
ātmano nāstyahaṃbhāvo bhāvābhāvāḥ kuto'sya te
]

`v 9 [
ahaṃbhāvo mudhā moho manaśca mṛgatṛṣṇikā |
jaḍaḥ padārthasaṃbhāraḥ kasyāhaṃkārabhāvanā
]

`v 10 [
raktamāṃsamayo deho mano naṣṭaṃ vicāraṇāt |
jaḍāścittādayaḥ sarve kuto'haṃbhāvabhāvanā
]

`v 11 [
ātmaṃbharitayā nityamindriyāṇi sthitānyalam |
padārthāśca padārthatve kuto'haṃbhāvabhāvanā
]

`v 12 [
ātmaṃbharitayā svasvaviṣayamātravyāpṛtatālakṣaṇasvodaramātrapūrakatayā
nāhaṃkārapuṣṭilakṣaṇaparopakāritayetyarthaḥ | padārthatve padārthasvarūpe | 11
|
guṇā guṇārthe vartante prakṛtau prakṛtiḥ sthitā |
sadeva sati viśrāntaṃ kuto'haṃbhāvabhāvanā
]

`v 13 [
sarvagaṃ sarvadehasthaṃ sarvakālamayaṃ mahat |
kevalaṃ paramātmānaṃ cidātmaiveha saṃsthitaḥ
]

`v 14 [
evaṃ kimākṛtiḥ ko vā kimādeśaśca kiṃkṛtaḥ |
kiṃrūpaḥ kiṃmayaḥ kohaṃ kiṃ gṛhṇāmi tyajāmi kim
]

`v 15 [
tenāhaṃ nāma nehāsti bhāvābhāvopapattimān |
anahaṃkārarūpasya saṃbandhaḥ kena me katham
]

`v 16 [
asatyalamahaṃkāre saṃbandhaḥ kasya kena kaḥ |
saṃbandhābhāvasaṃsiddhau vilīnā dvitvakalpanā
]

`v 17 [
evaṃ brahmātmakamidaṃ yatkiṃcijjagati sthitam |
sadevāsmi tadevāsmi pariśocāmi kiṃ mudhā
]

`v 18 [
ekasminneva vimale pade sarvagate sthite |
ahaṃkārakalaṅkasya kathaṃ nāmodayaḥ kutaḥ
]

`v 19 [
nāstyeva hi padārthaśrīrātmaivāstīha sarvagaḥ |
padārthalakṣmyāṃ satyāṃ ca saṃbandhosti na kasyacit
]

`v 20 [
indriyairindriyairaṅgairmano manasi valgati |
cidaliptavapuḥ kena saṃbandhaḥ kasya kiṃ katham
]

`v 21 [
upalāyaḥśalākānāṃ saṃbandho na yathā mithaḥ |
tathaikatrāpi dṛṣṭānāṃ dehendriyamanaścitām
]

`v 22 [
asadabhyutthite vyarthamahaṃkāramahābhrame |
mamedamidamasyeti viparyastamidaṃ jagat
]

`v 23 [
atattvālokajāteyamahaṃkāracamatkṛtiḥ |
tāpena himalekheva tattvāloke vilīyate
]

`v 24 [
ātmano vyatirekeṇa na kiṃcidapi vidyate |
sarvaṃ brahmeti me tattvametattadbhāvayāmyaham
]

`v 25 [
ahaṃkārabhramasyāsya jātasyākāśavarṇavat |
apunaḥsmaraṇaṃ manye nūnaṃ vismaraṇaṃ varam
]

`v 26 [
samūlaṃ saṃparityajya cirāyāhaṃkṛtibhramam |
tiṣṭhāmyātmani śāntātmā śaratkhaṃ śaradīva khe
]

`v 27 [
dadātyanarthanicayaṃ vistārayati duṣkṛtam |
vistārayati saṃtāpamahaṃbhāvonusaṃhitaḥ
]

`v 28 [
sphuratyahaṃkāraghane hṛdvyomni salilātmani |
vikasatyabhitaḥ kāyakadambe doṣamañjarī
]

`v 29 [
maraṇaṃ jīvitopāntaṃ jīvitaṃ maraṇāntagam |
bhāvo'bhāvādvyavacchinnaḥ kaṣṭeyaṃ duḥkhavedanā
]

`v 30 [
idaṃ labdhamidaṃ prāpsyāmītyārtirdāhakāriṇī |
na śāmyatyarkaratnānāṃ grīṣme'gniriva durdhiyām
]

`v 31 [
nāstīdamidamastīti cintā dhāvatyahaṃkṛtim |
jaḍāśayā jaḍāmabhramālā śailāvalīmiva
]

`v 32 [
ahaṃbhāve parikṣīṇe śuṣkaḥ saṃsārapādapaḥ |
bhūyaḥ prayacchatyaraso na pāṣāṇavadaṅkuram
]

`v 33 [
svatṛṣṇākṛṣṇabhoginyo dehadrumakṛtālayāḥ |
kvāpi yānti vicārātmanyāgate vinatāsute
]

`v 34 [
asadabhyutthite viśve tajjāte bhramasanmaye |
asanmayaparispande tvahaṃ tvaṃ ceti kaḥ kramaḥ
]

`v 35 [
idaṃ jagadudetyādāvakāraṇamakāraṇāt |
yadakāraṇamudbhūtaṃ `note[kāraṇamucchūnamityapi pāṭhaḥ]
tatsadityucyate katham
]

`v 36 [
aparyantapurākāle mṛdi kumbha ivākṛtiḥ |
deho'bhavadidānīṃ tu tathaivāsti bhaviṣyati
]

`v 37 [
evaṃcotpatteḥ puro dehāderyādṛśī sthitistādṛśyeva sarvadeti siddhamityāha
- aparyanteti | mṛdi kumbharūpā ākṛtiḥ saṃsthānamiva | tuśabdo'pyarthe |
36 |
madhyetarapayomātraṃ kaṃcitkālaṃ calācalam |
ādyantasaumyate tyaktvā vāri vīcitayā yathā
]

`v 38 [
asminkṣaṇaparispande dehe visaraṇonmukhe |
taraṅge ca nibaddhāsthā ye hatāste kubuddhayaḥ
]

`v 39 [
prākpurastācca sarvāṇi santi vastūni nābhitaḥ |
madhye sphuṭatvameteṣāṃ kaivāsthā hatarūpiṇī
]

`v 40 [
cittaṃ pūrvaṃ purastācca ciddeśaṃ śāntamityapi |
sadasadvā svasaṃlīnaṃ madhye'sminkiṃ tavoditam
]

`v 41 [
yathā svapnavikāreṣu yathā saṃbhramadṛṣṭiṣu |
yathā vā madalīlāsu yathā nauyānasaṃbhrame
]

`v 42 [
yathā dhātuvikāreṣu yathā cendriyaviklave |
yathātisaṃbhramānande doṣāveśadaśāsu ca
]

`v 43 [
dṛśyate kṣīyate caiva rūpaṃ sadasatoścalam |
tathaiveyamiha tveṣā kāle nyūnātiriktatā
]

`v 44 [
sā ca tvayā kṛtā nityaṃ citta duḥkhasukhodaye |
yathā viyogayāminyo matayo hanti rāgiṇam
]

`v 45 [
mayaivehāsadabhyāsānmithyā sadiva lakṣyase |
mṛgatṛṣṇeva tenaitattvatkṛtaṃ matkṛtaṃ bhavet
]

`v 46 [
yadidaṃ kiṃcidābhogi tatsarvaṃ dṛśyamaṇḍalam |
avastviti vinirṇīya mano yātyamanaḥpadam
]

`v 47 [
avastvidamiti sphāre rūḍhe manasi niścaye |
hemanta iva mañjaryaḥ kṣīyante bhogavāsanāḥ
]

`v 48 [
cittvāddṛṣṭātmanā nūnaṃ saṃtyaktamananaujasā |
manasā vītarāgeṇa svayaṃ svasthena bhūyate
]

`v 49 [
paramātmānale kṣiptaṃ saṃvṛttyāvayavaṃ svayam |
dagdhvātmānamalaṃ cittaṃ śuddhatāmeti śāśvatīm
]

`v 50 [
dehamanyatayā dṛṣṭvā tyaktvā viṣayavāsanām |
vināśamurarīkṛtya mano jayati vīravat
]

`v 51 [
manaḥ śatruḥ śarīrasya śarīraṃ manaso ripuḥ |
ekābhāvena naśyete ādhārādheyakāryavat
]

`v 52 [
rāgadveṣavatornityamanyonyātiviruddhayoḥ |
etayormūlakāṣeṇa vināśaḥ paramaṃ sukham
]

`v 53 [
etayorekasaṃsthāne mṛtirityeva yā kathā |
sā vyomnyayā striyā bhuktā dhareti kathayā samā
]

`v 54 [
akṛtrimavirodhasthau yatra saṃghaṭitāvubhau |
dhārā iva patantyeva tatrānarthaparamparāḥ
]

`v 55 [
mitho viruddhasaṃsarge ratimetyadhamo hi yaḥ |
tyaktavyaḥ sa patadvārāvagnirāśāvalepane
]

`v 56 [
saṃkalpena manaḥ puṣṭvā śarīraṃ bālayakṣavat |
āyurevāśanānyasmai svaduḥkhāni prayacchati
]

`v 57 [
tarduḥkhaistāpito deho mano hantumathecchati |
putro'pi hanti pitaramātatāyipadaṃ gatam
]

`v 58 [
nāsti śatruḥ prakṛtyaiva na ca mitraṃ kadācana |
sukhadaṃ mitramityuktaṃ duḥkhadāḥ śatravaḥ smṛtāḥ
]

`v 59 [
deho duḥkhānyanubhavansvamano hantumicchati |
dehaṃ manaḥ svaduḥkhānāṃ saṃketaṃ kurute kṣaṇāt
]

`v 60 [
evaṃ mitho duḥkhadayoḥ śliṣṭayoḥ kaḥ sukhāgamaḥ |
etayordehamanasorjātyaivātiviruddhayoḥ
]

`v 61 [
manasyeva parikṣīṇe na deho duḥkhabhājanam |
tatkṣayotkatayā nityaṃ deho'pi paridhāvati
]

`v 62 [
naṣṭānaṣṭamanarthāya śarīraṃ padamāpadām |
alabdhātmavivekena manasā suprajāyate
]

`v 63 [
ete manaḥśarīre hi mithaḥ pīvaratāṃ gate |
jaḍarūpe hi vapuṣā payodasarasī yathā
]

`v 64 [
mitho duḥkhāya saṃpanne ekarūpe dvidhā sthite |
vyavahārapare sārdhaṃ loke vāryanalāviva
]

`v 65 [
citte kṣayiṇi saṃkṣīṇe deho hyāmūlito bhavet |
vardhamāne taruriva śataśākhaḥ pravartate
]

`v 66 [
kṣīyate manasi kṣīṇe dehaḥ prakṣīṇavāsanaḥ |
mano na kṣīyate kṣīṇe dehe tatkṣapayenmanaḥ
]

`v 67 [
saṃkalpapādapaṃ tṛṣṇālataṃ chittvā manovanam |
vitatāṃ bhuvamāsādya viharāmi yathāsukham
]

`v 68 [
prakṣīyamāṇamevedaṃ na mano manasi sthitam |
praśāmyadvāsanājālaṃ prāvṛḍanta ivāmbudaḥ
]

`v 69 [
dhātūnāṃ saṃniveśo'yaṃ dehanāmā ripurmama |
prakṣīyamāṇe manasi galatveṣo'vatiṣṭhatu
]

`v 70 [
yadarthaṃ kila bhogaśrīrvāñchate svakalevaram |
tanme nāpi na tasyāhaṃ ko'rthaḥ sukhalavena me
]

`v 71 [
tiṣṭhati dehe duḥkhamapi kiṃ na syāditi cettatsaṃbandhahetormanaso
nāśātsaṃbandha eva nāsti dūre duḥkhaprasaktirityāśayenāha - yadarthamiti |
70 |
nāhaṃ deha iti tvasminyuktimākarṇaya krame |
sarvāṅgeṣvapi satsveva śavaḥ kasmānna valgati
]

`v 72 [
tasmāddehādatīto'haṃ nityo'nastamitadyutiḥ |
yaḥ saṅgaṃ bhāsvatā prāpya vedmi vyomani bhāskaram
]

`v 73 [
nājño'haṃ naca me duḥkhaṃ nānartho na ca duḥkhitā |
śarīramastu māvāstu sthitosmi vigatajvaraḥ
]

`v 74 [
yatrātmā tatra na mano nendriyāṇina vāsanāḥ |
pāmarāḥ paritiṣṭhanti nikaṭe na mahībhṛtaḥ
]

`v 75 [
padaṃ tadanuyāto'smi kevalosmi jayāmyaham |
nirvāṇosmi niraṃśosmi `note[nirīhosmi niraṃśosmi iti vyutkrameṇa
kvacitpaṭhyate] nirīhosmi nirīpsitaḥ
]

`v 76 [
idānīmasmyasaṃbaddho manodehendriyādibhiḥ |
pṛthakkṛtasya tailasya tilairvigalanairiva
]

`v 77 [
svasmātpadavarādasmāllīlayā calitasya me |
pṛthakkṛtamateḥ kiṃca parivāro hyayaṃ śubhaḥ
]

`v 78 [
svacchatorjitatā sattā hṛdyatā satyatā jñatā |
ānanditopaśamitā sadā ca mṛdubhāṣitā
]

`v 79 [
tasyāṃ līlāyāṃ svacchatādiguṇasaṃpadaḥ svasya hṛdayavallabhāḥ kāntā iti
rūpayati - svacchatetyāditribhiḥ | ūrjitatā pūrṇakāmatā | jñatā viditātmatā |
78 |
pūrṇatodārāa satyā kāntimattaikatānatā |
sarvaikatā nirbhayatā kṣīṇadvitvavikalpatā
]

`v 80 [
nityoditāḥ samāḥ svasthāḥ sundaryaḥ subhagodayāḥ |
mamaikātmamaternityaṃ kāntā hṛdayavallabhāḥ
]

`v 81 [
sarvathā sarvadā sarvaṃ sarvasminsaṃbhavatyataḥ |
sarvaṃ prati mama kṣīṇe vāñchāvāñche sukhāsukhe
]

`v 82 [
vigatamohatayā vimanastayā
gatavikalpanacittatayā sphuṭam |
uparamāmyahamātmani śītale
ghanalavaḥ śaradīva nabhastale
]