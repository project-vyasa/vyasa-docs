`v 1 [
ekādaśo divasaḥ |
saptadaśaḥ sargaḥ 17
śrīvasiṣṭha uvāca |
videhamuktā ye rāma te girāmiha gocare |
naiva tiṣṭhanti tasmāttvaṃ jīvanmuktimimāṃ śṛṇu
]

`v 2 [
prākṛtānyeva karmāṇi `note[kāryāṇīti pāṭhaḥ] yayā
varjitavāñchayā |
kriyante tṛṣṇayemāni tāṃ jīvanmuktatāṃ viduḥ
]

`v 3 [
yā sthitistṛṣṇayā jantorbāhyārthe baddhabhāvayā |
taṃ bandhamāhurācāryāḥ saṃsāranigaḍaṃ dṛḍham
]

`v 4 [
baddha utsāhadṛḍhīkṛto bhāvaḥ saṃsārasatyatābuddhyā bhogotsāho yayā | 3
|
nūnamujjhitasaṃkalpā hṛdi bāhye vihāriṇī |
vāsanā yoditā seha jīvanmuktaśarīriṇī
]

`v 5 [
bāhyārthavyasanocchūnā tṛṣṇā baddheti rāghava |
sarvārthavyasanonmuktā tṛṣṇā mukteti kathyate
]

`v 6 [
pūrvaṃ yasyāstu tṛṣṇāyā vartamāne'pi śāśvatī |
nirduḥkhatā niṣkalatā sā mukteti budhaiḥ smṛtā
]

`v 7 [
idamastu mametyantaryaiṣā rāghava bhāvanā |
tāṃ tṛṣṇāṃ śṛṅkhalāṃ viddhi kalanāṃ ca mahāmate
]

`v 8 [
tāmetāṃ sarvabhāveṣu satsvasatsu ca sarvadā |
saṃtyajya paramodāraḥ parameti mahāmanāḥ
]

`v 9 [
bandhāśāmatha mokṣāśāṃ sukhaduḥkhadaśāmapi |
tyaktvā sadasadāśāṃ ca tiṣṭhākṣubdhamahābdhivat
]

`v 10 [
ajarāmaramātmānaṃ buddhvā buddhimatāṃ vara |
jarāmaraṇaśaṅkābhirmā manaḥ kaluṣaṃ kṛthāḥ
]

`v 11 [
padārtha tattvaṃ nedaṃ te nāyaṃ tvamasi rāghava |
kiṃcittadanyadevedamanya evāsi rāghava
]

`v 12 [
asadabhyudite viśve satīvāsati saṃsthite |
tvayi tattāmatigate tṛṣṇāyāḥ saṃbhavaḥ kutaḥ
]

`v 13 [
anyacca rāma manasi puruṣasya vicāriṇaḥ |
jāyate niścayaḥ sādho sphārākāraścaturvidhaḥ
]

`v 14 [
āpādamastakamahaṃ mātāpitṛvinirmitaḥ |
ityeko niścayo rāma bandhāyāsadvilokanāt
]

`v 15 [
atītaḥ sarvabhāvebhyo vālāgrādapyahaṃ tanuḥ |
iti dvitīyo mokṣāya niścayo jāyate satām
]

`v 16 [
jagajjālapadārthātmā sarvamevāhamakṣayaḥ |
tṛtīyo niścayaścetthaṃ mokṣāyaiva raghūdvaha
]

`v 17 [
ahaṃ jagadvā sakalaṃ śūnyaṃ vyomasamaṃ sadā |
evameṣa caturtho'nyo niścayo mokṣasiddhaye
]

`v 18 [
niścayeṣu caturṣveṣu bandhāya prathamaḥ smṛtaḥ |
trayo mokṣāya kathitāḥ śuddhabhāvanayotthitāḥ
]

`v 19 [
eteṣāṃ prathamaḥ proktastṛṣṇāyā bandhayogyatā |
śuddhatṛṣṇāstrayaḥ svacchā jīvanmuktavilāsinaḥ
]

`v 20 [
sarvamātmāhameveti niścayo yo mahāmate |
tamādāya viṣādāya na bhūyo yāti me matiḥ
]

`v 21 [
tiryagūrdhvamadhastācca vyāpako mahimātmanaḥ |
sarvamātmeti tenāntarniścayena na badhyate
]

`v 22 [
śūnyaṃ tatprakṛtirmāyā brahmavijñānamityapi |
śivaḥ puruṣa īśāno nitya ātmaiva kathyate
]

`v 23 [
sadā sarvaṃ sadevedaṃ neha dvitvānyate kvacit |
vidyete vidyayā vyāptaṃ jagannetarayā dhiyā
]

`v 24 [
āpātalamanantātmā pūrito'mbhodhirambudhiḥ |
ābrahmastambaparyantaṃ jagadāpūrṇamātmanā
]

`v 25 [
ataḥ satyamṛtaṃ nityaṃ nānṛtaṃ vidyate kvacit |
vāryeva sakalāmbhodhirna taraṅgādayaḥ kvacit
]

`v 26 [
pṛthakkaṭakakeyūranūpurādi na kāñcanāt |
bhinnāstarutṛṇākārakoṭayaścaiva nātmanaḥ
]

`v 27 [
dvaitādvaitasamudbhedairjagannirmāṇalīlayā |
paramātmamayī śaktiradvaitaiva vijṛmbhate
]

`v 28 [
ātmīye parakīye ca sarvasminneva sarvadā |
naṣṭe vopacite kārye sukhaduḥkhe gṛhāṇa mā
]

`v 29 [
bhāvādvaitamupāśritya sattādvitamayātmakaḥ |
karmādvaitamanādṛtya dvaitādvaitamayo bhava
]

`v 30 [
bhavabhūmiṣu bhīmāsu bhāvabhāvanavātyayā |
mā patotpātapūrṇāsu darīṣvantaḥ karī yathā
]

`v 31 [
dvaitaṃ na saṃbhavati cittamayaṃ mahātma-
nnātmanyathaikyamapi na dvitayoditātma |
advaitamaikyarahitaṃ satatoditaṃ sa-
tsarvaṃ na kiṃcidapi cāhurataḥ svarūpam
]

`v 32 [
naivāhamasti naca nāma jaganti santi
sarvaṃ ca vidyata idaṃ nanu nirvikāram |
vijñānamātramavabhāsata eva śāntaṃ
nāsanna sajjagadidaṃ ca sadeti viddhi
]

`v 33 [
paramamṛtamanādyaṃ bhāsanaṃ sarvabhāsā-
majaramajamacintyaṃ niṣkalaṃ nirvikāram |
vigatakaraṇajālaṃ jīvanaṃ jīvaśakteḥ
sakalakalanahīnaṃ kāraṇaṃ kāraṇānām
]

`v 34 [
satatamuditamīśaṃ vyātate citprakāśe
sthitamanubhavabījaṃ svātmabhāvopadeśyam |
svadanamanucito'ntarbrahma sarvaṃ sadaiva
tvamahamapi jagaccetyastu te niścayontaḥ
]