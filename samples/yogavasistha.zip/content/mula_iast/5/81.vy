`v 1 [
ekāśītitamaḥ sargaḥ 81
śrīvasiṣṭha uvāca |
evaṃ vicārya buddhvāntaḥ punaritthaṃ vicāryate |
tattvavidbhirmahābāho jñeya ātmā mahātmabhiḥ
]

`v 2 [
ātmaivedaṃ jagaditi satyaṃ cittena mārjitam |
utthitaṃ syātkutaścittamaho cittamavastu yat
]

`v 3 [
avidyatvādacittattvānmāyātvāccāsadeva hi |
dhruvaṃ nāstyeva vā cittaṃ bhramādanyatkhavṛkṣavat
]

`v 4 [
siddhaḥ sthāṇuparispando naugatasya yathā śiśoḥ |
abuddhasya na buddhasya tathā cittamasanmayam
]

`v 5 [
maurkhyamohabhrame śānte cittaṃ nopalabhāmahe |
cakrārohabhramasyānte parvataspandanaṃ yathā
]

`v 6 [
tailekṣvādiyantracakrārohaṇaprayuktabhramasyānte tadavarohaṇottaramityarthaḥ | 5
|
evaṃ hi cittaṃ nāstyeva brahmaivāsti tathātmakam |
padārthabhāvanāścittāttenāsatyā mayojjhitāḥ
]

`v 7 [
jāto'smi śāntasaṃdehaḥ sthito'smi vigatajvaraḥ |
tathā tiṣṭhāmi tiṣṭhāmi tathaiva vigataiṣaṇam
]

`v 8 [
cittābhāve parikṣīṇā bālyatṛṣṇādayo guṇāḥ |
ālokoparame citrā varṇākhyā iva saṃvidaḥ
]

`v 9 [
mṛtaṃ cittaṃ gatā tṛṣṇā prakṣīṇo mohapañjaraḥ |
nirahaṃkāratā jātā jāgratyasminprabuddhavān
]

`v 10 [
ekameva jagacchāntaṃ nānātvaṃ na sadityapi |
kimanyadvimṛśāmyantaḥ kathayaivālametayā
]

`v 11 [
nirābhāsamanādyantaṃ padaṃ pāvanamāgataḥ |
saumyaḥ sarvagataḥ sūkṣmaḥ sthita ātmāsmi śāśvataḥ
]

`v 12 [
yadasti yacca nāstīha cittādyātmādyavastu ca |
tatkhādacchataraṃ śāntamanantāgrāhyamātatam
]

`v 13 [
cittaṃ bhavatu mā vāntarmriyatāṃ sthitimetu vā |
ko vicāraṇayārtho me ciraṃ sāmyoditātmanaḥ
]

`v 14 [
vicārākārako maurkhyādahamāsaṃ mitasthitiḥ |
vicāreṇāmitākāraḥ kva nāmāhaṃ vicārakaḥ
]

`v 15 [
mṛte'pi manasīyaṃ me vikalpaśrīrnirarthikā |
manovetālavṛttyarthaṃ kimarthamupajāyate
]

`v 16 [
tāmimāṃ prajahāmyantaḥ saṃkalpakalanāmiti |
nirṇīyomiti śāntātmā tiṣṭhāmyātmani maunavat
]

`v 17 [
aśnangacchansvapaṃstiṣṭhanniti rāghava cetasā |
sarvatra prajñayā tajjñaḥ pratyahaṃ pravicārayet
]

`v 18 [
pravicārya svasaṃsthena svasthena svena cetasā |
tiṣṭhanti vigatodvegaṃ santaḥ prakṛtakarmasu
]

`v 19 [
vigatamānamadā muditāśayāḥ
śaradupoḍhaśaśāṅkasamatviṣaḥ |
prakṛtasaṃvyavahāravihāriṇa-
stviha sukhaṃ viharanti mahādhiyaḥ
]