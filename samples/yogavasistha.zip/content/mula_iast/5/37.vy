`v 1 [
saptatriṃśaḥ sargaḥ 37
śrīvasiṣṭha uvāca |
iti saṃcintayanneva prahrādaḥ paravīrahā |
nirvikalpaparānandasamādhiṃ samupāyayau
]

`v 2 [
nirvikalpasamādhisthaścitrārpita ivācalaḥ |
śailādiva samutkīrṇo babhau svapadamāsthitaḥ
]

`v 3 [
tathānutiṣṭhatastasya kālo bahutaro yayau |
svagṛhe bhuvanasthasya meroriva suradviṣaḥ
]

`v 4 [
bodhito'pyasurādhīśairnābudhyata mahāmatiḥ |
akāle bahuseko'pi bījakośādivāṅkuraḥ
]

`v 5 [
evaṃ varṣasahasrāṇi pīnātmā'tiṣṭhadekadṛk |
śānta evāsurapure mārtaṇḍa iva copale
]

`v 6 [
parānandadaśaikāntapariṇāmitayā tayā |
nirānandaṃ parābhāsamivābhāsapadaṃ gataḥ
]

`v 7 [
etāvatātha kālena tadrasātalamaṇḍalam |
babhūvārājakaṃ tīkṣṇaṃ mātsyanyāyakadarthitam
]

`v 8 [
hiraṇyakaśipau kṣīṇe samādhau tatsute sthite |
na babhūvāparaḥ kaścidrājā danusutālaye
]

`v 9 [
asureśārthināṃ teṣāṃ dānavānāṃ samādhitaḥ |
pareṇāpi prayatnena prahrādo na vyabudhyata
]

`v 10 [
na prāpurvikasadrūpaṃ patiṃ tamamarārayaḥ |
lasatpatralatājālaṃ niśi padmamivālayaḥ
]

`v 11 [
saṃvidvādo na tasyāntarabodhyata vicetasaḥ |
bhuvaśceṣṭākrama iva pauruṣo gatabhāsvataḥ
]

`v 12 [
athodvigneṣu daityeṣu gateṣvabhimatāṃ diśam |
vicaratsu yathākāmamarājani pure purā
]

`v 13 [
cirāya pātālamabhūdabhūpālatayā tayā |
mātsyanyāyaviparyastamastaṃgataguṇakramam
]

`v 14 [
balimuktābalapuraṃ `note[bhuktābala iti pāṭho'pekṣitaḥ]
maryādākramavarjitam |
sarvārtāśeṣavanitaṃ parasparahṛtāmbaram
]

`v 15 [
pralāpākrandapuruṣaṃ visaṃsthānapurāntaram |
luṭhadudyānanagaraṃ vyarthānarthakadarthitam
]

`v 16 [
cintāparāsuragaṇaṃ nirannaphalabāndhavam |
akāṇḍotpātavivaśaṃ dhvastāśāmukhamaṇḍalam
]

`v 17 [
surārbhakaparābhūtaṃ bhūtairākrāntamantyajaiḥ |
bhūtariktamalakṣmīkamucchinnaprāyakoṭaram
]

`v 18 [
aniyatavanitārthamantrayuddhaṃ
hṛtadhanadāravirāvitaṃ samantāt |
kaliyugasamyodbhaṭotkaṭābhaṃ
tadasuramaṇḍalamākulaṃ babhūva
]