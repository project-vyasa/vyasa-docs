`v 1 [
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
Vasudeva ḻaxmana ṣharma Pansikar
1918
prathamaḥ sargaḥ 1
śrīvasiṣṭha uvāca |
atha sthitiprakaraṇādanantaramidaṃ śṛṇu |
upaśamaprakaraṇaṃ jñātaṃ nirvāṇakāri yat
]

`v 2 [
utpattiprakaraṇe sarvasṛṣṭiśrutitātparyodghāṭanāya manodhīnaiva
sarvaprapañcaracaneti darśitam | sthitiprakaraṇe ca
sarvajagatsthitipratipādakaśrutitātparyapradarśanāya manaḥsthityadhīnaiva
sarvaprapañcasthitiriti darśitam | idānīṃ yathā gārgya marīcayo'rkasyāstaṃ
gacchata etasmiṃstejomaṇḍala ekībhavanti suṣuptikāle sakale vilīne
yatprayantyabhisaṃviśanti yathā nadyaḥ syandamānāḥ samudre'staṃ gacchanti
nāmarūpe vihāya gatāḥ kalāḥ pañcadaśa pratiṣṭhām evamevāsya
paridraṣṭurimāḥ ṣoḍaśakalāḥ puruṣāyaṇāḥ puruṣaṃ prāpyāstaṃ gacchanti
ityādīnāṃ suṣuptipralayasamādhisākṣātkāravidehakaivalyeṣu
prapañcopaśamājjīvasya brahmasvabhāvatāprāptipratipādanena
pratyagbrahmaikarasākhaṇḍavastulakṣakaśrutīnāmapi mana upaśamādeva
sarvaprapañcopaśamena svarūpapratiṣṭhāyāṃ tātparyamiti
rahasyodghāṭanāyopaśamaprakaraṇamārabhamāṇaḥ pūrvottaraprakaraṇayoḥ
saṃgatiṃ darśayan viṣayaprayojane nirdiśya śiṣyamavadhānayanpratijānīte -
atheti | atha
sthitipratipādakaśrutitātparyavarṇanānāntaramupasaṃhārabodhakaśrutitātparyavar
ṇanasyāvasarasaṃgatirityarthaḥ | jñātaṃ nirvāṇakārīti | tathāca
pūrvaprakaraṇaprayojanamevāsyāpītyekakāryakāritāsaṃgatirapi darśitā bodhyā ||
1 ||
śrīvālmīkiruvāca |
śarattārakitākāśastimitāyāṃ susaṃsadi |
kathayatyevamāhlādi vasiṣṭhe pāvanaṃ vacaḥ
]

`v 3 [
śravaṇārthitvamaunasthapārthive saṃsadantare |
nirvāta iva nispandakamale kamalākare
]

`v 4 [
vilāsinīṣu saṃśāntamadamohabalāsu ca |
śamamantaḥ prayāntīṣu cirapravrajitāsviva
]

`v 5 [
karāmbhoruhahaṃseṣu līneṣu śravaṇādiva |
muktaghurghuravādeṣu vāyaseṣu tarāviva
]

`v 6 [
nāsāgrapariviśrāntatarjanyaṅgulikoṭiṣu |
vicārayatsu vijñānakalāṃ tajjñeṣu rājasu
]

`v 7 [
rāme vikāsamāyāte prabhāta iva paṅkaje |
parityaktatamaḥpīṭhe sūryodaya ivāmbare
]

`v 8 [
ākarṇayati vāsiṣṭhīrgiro daśarathe rasāt |
kalāpinīva jīmūtanirhrādānmuktavarṣaṇāt
]

`v 9 [
āhṛtya sarvabhogebhyo mano markaṭacañcalam |
śravaṇaṃ prati yatnena sāreṇa mantriṇi sthite
]

`v 10 [
vasiṣṭhoktyā parijñātasvātmanīndukalāmale |
lakṣmaṇe vilasallakṣye śikṣābalavicakṣaṇe
]

`v 11 [
śatrughne śatrudalane cetasā pūrṇatāṃ gate |
alamānandamāyāte rākācandropame sthite
]

`v 12 [
sumitre mitratāṃ yāte mānase duḥkhaśīlite |
vikāsihṛdaye jāte tatkāla iva paṅkaje
]

`v 13 [
tatrastheṣu tathānyeṣu tadā muniṣu rājasu |
sudhautacittaratneṣu prollasatsviva cetasā
]

`v 14 [
udabhūtpūrayannāśāḥ kalpābhraravamāṃsalaḥ |
atha madhyāhnaśaṅkhānāmabdhighoṣasamaḥ svanaḥ
]

`v 15 [
mahatā tena śabdena tirodhānaṃ munergiraḥ |
yayurjaladanādena kokiladhvanayo yathā
]

`v 16 [
munirantarayāṃcakre svāṃ vācamatha saṃsadi |
jitasāro guṇaḥ kena mahatā samudīryate
]

`v 17 [
muhūrtamātraṃ bibhrabhya śrutvā madhyāhnaniḥsvanam |
ghane kolāhale śānte rāmaṃ muniruvāca ha
]

`v 18 [
rāmādyatanametāvadāhnikaṃ kathitaṃ mayā |
prātaranyattu vakṣyāmo vaktavyamarimardana
]

`v 19 [
idaṃ niyatitaḥ prāptaṃ kartavyaṃ taddvijanmanām |
madhyāhnamupapannaṃ yatkartavyaṃ nāvasīdati
]

`v 20 [
tvamapyuttiṣṭha subhaga samastācārasatkriyām |
ācarācāracaturasnānadānārcanādikām
]

`v 21 [
ityuktvā muniruttasthau samaṃ daśarathaḥ prabhuḥ |
sasadāḥ sendurāditya udayādritaṭādiva
]

`v 22 [
tayoruttiṣṭhatoḥ sarvā sabhotthātumakampata |
mandavātaparāmṛṣṭā nalinīvālilocanā
]

`v 23 [
uttasthau sāvataṃsotthabhṛṅgamaṇḍalamaṇḍitā |
kariseneva sandhayadrāvālolakarapuṣkarā
]

`v 24 [
parasparāṅgasaṃghaṭṭacūrṇitāṅgadamaṇḍalī |
ratnapūrṇāruṇāmbhodasandhyāsamayasūcanī
]

`v 25 [
pataduttaṃsavibhrāntabhṛṅgopahitaghuṃghumā |
mukuṭoddāmavidyotaśakracāpīkṛtāmbarā
]

`v 26 [
kāntālatāhastadalacārucāmaramañjarī |
vanalekheva vikṣubdhavaravāraṇamaṇḍalā
]

`v 27 [
kacatkaṭakabhāraktīkṛtānyonyatatāmbarā |
vātavyādhūtapuṣpeva mandāravanamālikā
]

`v 28 [
karpūrakaṇanīhāraracitāmalavāridā |
śaraddiktaṭamāleva prasṛtāśeṣabhūmikā
]

`v 29 [
lolamaulimaṇiprāntapāṭalāmbarakoṭarā |
saṃdhyevāphullanīlābjā kāryasaṃhārakāriṇī
]

`v 30 [
ratnāṃśusalilāpūramukhapadmanirantarā |
padminīvālivalitā nūpurāravasārasā
]

`v 31 [
saṃtatā sā sabhottasthau bhūbhṛcchatasamākulā |
bhūtasaṃtatisaṃbhrāntā sṛṣṭirnavamivoditā
]

`v 32 [
praṇamyātha nṛpaṃ bhūpā niryayurnṛpamandirāt |
śakracāpīkṛtā ratnairambudheriva vīcayaḥ
]

`v 33 [
sumantro mantriṇaścaiva vasiṣṭhamatha bhūmipam |
praṇamya jagmuḥ snānāya rasavijñānakovidāḥ
]

`v 34 [
vāmadevādayaścānye viśvamitrādayastathā |
vasiṣṭhaṃ purataḥ kṛtvā tasthurāvarnanonmukhāḥ
]

`v 35 [
rājā daśarathastatra pūjayitvā munivrajam |
tadvisṛṣṭo jagāmātha svakāryārthamarindamaḥ
]

`v 36 [
vanaṃ vanāspadā jagmurvyoma vyomanivāsinaḥ |
nagaraṃ nāgarāścaiva prātarāgamanāya te
]

`v 37 [
mahīpativasiṣṭhābhyāṃ praṇayātprārthitaḥ prabhuḥ |
vasiṣṭhasadmani niśāṃ viśvāmitro'tyavāhayat
]

`v 38 [
vasiṣṭhaḥ saha viprendraiḥ pārthivairmunibhistathā |
upāsyamāno rāmādyaiḥ sarvairdaśarathātmajaiḥ
]

`v 39 [
jagāma svāśramaṃ śrīmānsarvalokanamaskṛtaḥ |
anuyātaḥ suraughena brahmalokamivābjajaḥ
]

`v 40 [
tasmātpradeśādrāmādīnpunardaśarathātmajān |
sarvānvisarjayāmāsa pādopānte natānasau
]

`v 41 [
nabhaścarāndharaṇicarānadhaścarā-
nvisṛjya saṃstutaguṇagocarāṃśca tān |
yathākramaṃ svagṛhamudārasattvavāṃ-
ścakāra tāṃ dvijajanavāsarakriyām
]