`v 1 [
aṣṭatriṃśaḥ sargaḥ 38
śrīvasiṣṭha uvāca |
athākhilajagajjālakramapālanadevanaḥ |
kṣīrodanagare śeṣaśayyāsanagato hariḥ
]

`v 2 [
prāvṛṇnidrāvyuparame devārthamarisūdanaḥ |
dhiyā vilokayāmāsa kadācijjāgatīṃ gatim
]

`v 3 [
triviṣṭapaṃ svamanasā pārthivaṃ cāvalokya saḥ |
ācāramājagāmāśu pātālamaripālitam
]

`v 4 [
tatra sthirasamādhāne sthite prahrādadānave |
dṛṣṭvā saṃpadamindrasya pure prauḍhimupāgatām
]

`v 5 [
vyālatalpatalasthasya kṣīrodārṇavaśāyinaḥ |
śaṅkhacakragadāpāṇerdehasyāntaracāriṇaḥ
]

`v 6 [
padmāsanasthasya manaḥ śarīreṇātibhāsvatā |
idaṃ saṃcintayāmāsa trailokyābjamahālinā
]

`v 7 [
prahrāde padaviśrānte pātāle gatanāyake |
kaṣṭaṃ sṛṣṭiriyaṃ prāyo nirdaityatvamupāgatā
]

`v 8 [
daityābhāve suraśreṇī nirjigīṣupadaṃ gatā |
śamameṣyatyadṛṣṭābdapaṭaleṣu saridyathā
]

`v 9 [
mokṣākhyaṃ nirgatadvandvaṃ tato yāsyati tatpadam |
kṣīṇābhimānavirasā lateva praviśuṣkatām
]

`v 10 [
devaughe śāntimāyāte bhuvi yajñatapaḥkriyā |
cidevatvaphalāḥ sarvāḥ śamameṣyantyasaṃśayam
]

`v 11 [
kriyāsvathopaśāntāsu bhūrloko'stamupaiṣyati |
asaṃsāraprasaṅgo'tha tasya nāśe bhaviṣyati
]

`v 12 [
ākalpāntaṃ tribhuvanaṃ yadidaṃ kalpitaṃ mayā |
nāśameṣyatyakālena tāpe himakaṇo yathā
]

`v 13 [
kimevamasminnābhoge vilīya kṣayamāgate |
kṛtaṃ mayeha bhavati svalīlākṣayakāriṇā
]

`v 14 [
tato'hamapi śūnye'sminnaṣṭacandrārkatārake |
vapuḥpraśāntimādhāya sthitimeṣyāmi tatpade
]

`v 15 [
akāṇḍa evamevaṃ hi jagatyupaśamaṃ gate |
neha śreyo na paśyāmi manye jīvantu dānavāḥ
]

`v 16 [
daityodyogena vibudhāstato yajñatapaḥkriyāḥ |
tena saṃsārasaṃsthānaṃ na saṃsārakramo'nyathā
]

`v 17 [
tasmādrasātalaṃ gatvā yathāvatsthāpayāmyaham |
sve krame dānavādhīśamṛtuḥ punariva drumam
]

`v 18 [
vinā prahrādamatha ciditaraṃ dānaveśvaram |
karomi tadasau manye devānāsādayiṣyati
]

`v 19 [
prahrādasya tvayaṃ dehaḥ paścimaḥ pāvano mahān |
ākalpamiha vastavyaṃ dehenānena tena ca
]

`v 20 [
evaṃ hi niyatirdevī niścitā pārameśvarī |
prahrādena yathākalpaṃ sthātavyamiha dehinā
]

`v 21 [
tasmāttameva gatvā tu daityendraṃ bodhayāmyaham |
garjangirinadīsuptaṃ mayūramiva vāridaḥ
]

`v 22 [
jīvanmuktasamādhisthaḥ karotvasuranāthatām |
maṇirmuktamanaskāraḥ pratibimbakriyāmiva
]

`v 23 [
nahi naśyati sargo'yamevaṃ saha surāsuraiḥ |
bhaviṣyati ca taddvandvaṃ tanme krīḍā bhaviṣyati
]

`v 24 [
sargakṣayodayāvetau susamau mama yadyapi |
tathāpīdaṃ yathāsaṃsthaṃ bhavatvanyena kiṃ mama
]

`v 25 [
bhāvābhāveṣu yattulyaṃ tannāśe tatsthitau ca vā |
yaḥ prayatnastvabuddhitvāttadyogagamanaṃ bhavet
]

`v 26 [
tasmātprayāmi pātālaṃ bodhayāmyasureśvaram |
sthairyaṃ yāmi na saṃsāralīlāṃ saṃpādayāmyaham
]

`v 27 [
asurapuramavāpya proddhatācāraghoraṃ
kamalamiva vivasvāndaityamudbodhayāmaḥ |
jagadidamakhilaṃ svasthairyamabhyānayāmo
ghanavidhiriva śaile cañcalaṃ meghajālam
]