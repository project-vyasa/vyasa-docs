`v 1 [
ekonasaptatitamaḥ sargaḥ 69
śrīvasiṣṭha uvāca |
sarvadā sarvasaṃsthena sarveṇa saha tiṣṭhatā |
sarvakarmaratenāpi manaḥ kāryaṃ vijānatā
]

`v 2 [
na saktamiha ceṣṭāsu na cintāsu na vastuṣu |
nākāśe nāpyadho nāgre na dikṣu na latāsu ca
]

`v 3 [
na bahirvipulābhoge na caivendriyavṛttiṣu |
nābhyantare na ca prāṇe na mūrdhani na tāluni
]

`v 4 [
na bhrūmadhye na nāsānte na mukhe na ca tārake |
nāndhakāre na cābhāse na cāsminhṛdayāmbare
]

`v 5 [
na jāgrati na ca svapne na suṣupte na nirmale |
nāsite na ca vā pītaraktādau śabale na ca
]

`v 6 [
na cale na sthire nādau na madhye netaratra ca |
na dūre nāntike nāgre na padārthe na cātmani
]

`v 7 [
na śabdasparśarūpeṣu na mohānandavṛttiṣu |
na gamāgamaceṣṭāsu na kālakalanāsu ca
]

`v 8 [
kevalaṃ citi viśramya kiṃciccetyāvalambini |
sarvatra nīrasamiva tiṣṭhatvātmarasaṃ manaḥ
]

`v 9 [
tatrastho vigatāsaṅgo jīvo'jīvatvamāgataḥ |
vyavahāramimaṃ sarvaṃ mā karotu karotu vā
]

`v 10 [
akurvannapi kurvāṇo jīvaḥ svātmaratiḥ kriyāḥ |
kriyāphalairna saṃbandhamāyāti khamivāmbudaiḥ
]

`v 11 [
athavā tamapi tyaktvā cetyāṃśaṃ śāntaciddhanaḥ |
jīvastiṣṭhatu saṃśānto jvalanmaṇirivātmani
]

`v 12 [
nirvāṇamātmani gataḥ satatoditātmā
jīvo'rucirvyavaharannapi rāmabhadra |
no saṅgameti gatasaṅgatayā phalena
karmodbhavena sahatīva ca dehabhāram
]