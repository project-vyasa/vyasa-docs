`v 1 [
ekonaviṃśaḥ sargaḥ 19
atraivodāharantīmamitihāsaṃ purātanam |
bhrātrostripathagātīre saṃvādaṃ muniputrayoḥ
]

`v 2 [
ayaṃ bandhurayaṃ neti kathāprastāvataḥ smṛtam |
itihāsamimaṃ puṇyamāścaryaṃ śṛṇu rāghava
]

`v 3 [
astyasya jambūdvīpasya kasmiṃścidgirikuñjake |
vanavyūhamahottaṃsaṃ mahendro nāma parvataḥ
]

`v 4 [
kalpadrumavanacchāyāviśrāntamunikinnaraḥ |
śṛṅgairātatamākāśaṃ jitavānyaḥ samunnataiḥ
]

`v 5 [
brahmalokāntaraprāptaśṛṅgakandaracāribhiḥ |
sāmavedapratidhvānaghuṃghumairgāyatīva yaḥ
]

`v 6 [
yaḥ payomedurairmeghairlasitaiḥ śṛṅgakoṭiṣu |
latākusumasaṃprotaiḥ kuntalairiva rājate
]

`v 7 [
yastadoḍḍayanotkānāṃ `note[yastaṭoḍḍayanotkānāṃ iti ṭīkākṛtsaṃmataḥ
pāṭhaḥ] śarabhāṇāṃ vijṛmbhitaiḥ |
visphūrjati guhāvakraiḥ kalpābhrāṇi hasanniva
]

`v 8 [
yena nirjharanirhrādaiḥ kandarāntaracāribhiḥ |
samudrajalakallolavilāso vijito'bhitaḥ
]

`v 9 [
tasyaikadeśe vitate ratnasānau manorame |
munibhiḥ snānapānārthaṃ vyomagaṅgāvatāritā
]

`v 10 [
tasyāstripathagāyāstu tīre vikasitadrume |
ratnādritaṭavidyote kacatkanakapiñjare
]

`v 11 [
āsīdabhyuditajñānastaporāśirudāradhīḥ |
munidīrghatapā nāma tapo mūrtamivāparam
]

`v 12 [
munerbabhūvatustasya putrau dvāvindusundarau |
puṇyapāvananāmānau dvau kacāviva vākpateḥ
]

`v 13 [
sa tābhyāṃ saha putrābhyāṃ bhāryayā ca sahaikayā |
uvāsa saritastīre tasminsaphalapādape
]

`v 14 [
atha kāle tayostasya putrayorjñānavānabhūt |
puṇyo nāma ca yo jyeṣṭho guṇajyeṣṭhaśca rāghava
]

`v 15 [
pāvanordhaprabuddho'bhūtpūrvasaṃdhyāmbujaṃ yathā |
maurkhyādadhigato nāptaḥ pade dolāyitaḥ sthitaḥ
]

`v 16 [
tato vahatyakalite kāle kalitakāraṇe |
saṃvatsaraśate jīrṇadīrghadehalatāyuṣi
]

`v 17 [
asmādbhaṅgurabhūtāḍhyādvṛttāntaśatabhīṣaṇāt |
ratimutsṛjya saṃsārājjarājarjarajīvitaḥ
]

`v 18 [
janmajarāmaraṇasvargapātanarakādivṛttāntaśatairbhīṣaṇātsaṃsārādrati##-
17 |
kalanāpakṣiṇī nīḍaṃ dehaṃ dīrghatapā muniḥ |
jahau giriguhāgehe bhāraṃ vaivadhiko yathā
]

`v 19 [
yathā vaivadhiko vīvadhavāhako gehe vīvadhabhāraṃ jahāti tathetyarthaḥ |
vivadhavīvadhaśabdāvubhayato baddhaśikye skandavāhye kāṣṭhaviśeṣe vartete |
18 |
praśāntakalanārambhaṃ cetyariktacidāspadam |
padaṃ jagāma nīrāgaṃ puṣpagandha ivāmbaram
]

`v 20 [
atha bhāryā munerdehaṃ prāṇāpānavivarjitam |
dṛṣṭvā vilulitaṃ bhūmau vinālamiva paṅkajam
]

`v 21 [
ciramabhyastayā yogayuktyā pativitīrṇayā |
tatyāja tanumamlānāṃ ṣaṭpadī padminīmiva
]

`v 22 [
bhartāramevānuyayau janasyādṛṣṭatāṃ gatā |
prabhāgaganakośasthamastaṃ yātamivoḍupam
]

`v 23 [
mātāpitrostu gatayoraurdhvadehikakarmaṇi |
puṇya eva sthito'vyagraḥ pāvano duḥkhamāyayau
]

`v 24 [
śokopahṛtacitto'sau bhramankānanavīthiṣu |
jyāyāṃsamanavekṣyaiva pāvano vilalāpa ha
]

`v 25 [
athaurdhvadehikaṃ kṛtvā mātāpitrorudāradhīḥ |
āyayau vipine puṇyaḥ pāvanaḥ śokalālasam
]

`v 26 [
puṇya uvāca |
kiṃ putra ghanatāṃ śokaṃ nayasyāndhyaikakāraṇam |
bāṣpadhārādharaṃ ghoraṃ prāvaṭkāla ivāmbujam
]

`v 27 [
pitā tava mahāprājña gataḥ sārdhaṃ tvadambayā |
svāmeva paramātmātmapadavīṃ mokṣanāmikām
]

`v 28 [
tatsthānaṃ sarvajantūnāṃ tadrūpaṃ vijitātmanām |
svabhāvamabhisaṃpanne kiṃ pitaryanuśocasi
]

`v 29 [
īdṛśī tu tvayā baddhā bhāvaneha vimohajā |
saṃsāre yadaśocyo'pi tvayā tātonuśocyate
]

`v 30 [
na saiva bhavato mātā nāsāveva pitā tava |
na bhavāneṣa tanayastayorniḥsaṃkhyaputrayoḥ
]

`v 31 [
mātāpitṛsahasrāṇi samatītāni te suta |
bahūnyambupravāhasya nimnānīva vane vane
]

`v 32 [
asaṃkhyaputrayornaiva bhavāneva sutastayoḥ |
sarittaraṅgavatputra gatāḥ putragaṇā nṛṇām
]

`v 33 [
asmatpitroratītāni putralakṣāṇyanekaśaḥ |
patrakorakavṛntāni latāviṭapayoriva
]

`v 34 [
mitrabāndhavavṛndāni jantorjanmani janmani |
ṛtāvṛtāvatītāni phalānīva mahātaroḥ
]

`v 35 [
śocanīyā yadi snehānmātāpitṛsutāḥ suta |
tadatītā na śocyante kimajasraṃ sahasraśaḥ
]

`v 36 [
prapañco'yaṃ mahābhāga dṛśyate jāgate bhrame |
paramārthena te prājña nāsti mitraṃ na bāndhavāḥ
]

`v 37 [
na nāśa iva hi bhrātaḥ paramārthena vidyate |
mahatyapi cirātapte marāviva payolavāḥ
]

`v 38 [
etā yāḥ prekṣase lakṣmīśchatracāmaracañcalāḥ |
svapna eva mahābuddhe dināni trīṇi pañca vā
]

`v 39 [
dṛṣṭyā tu pāramārthikyā putraṃ satyaṃ vicāraya |
naiva tvaṃ na vayaṃ caiva bhrāntimantaḥ parityaja
]

`v 40 [
ayaṃ gato mṛtaścāyamiti durdṛṣṭayaḥ puraḥ |
svasaṃkalpopatāpotthā dṛśyante natu satyataḥ
]

`v 41 [
svasaṃkalpalakṣaṇo ya upatāpaḥ saṃnipātabhramastadutthāḥ puro dṛśyante | 40
|
ajñānavistīrṇamarau vilolaṃ
śubhāśubhasyandamayaistaraṅgaiḥ |
savāsanānāmamarīcivāri
parisphuratyetadanantarūpam
]