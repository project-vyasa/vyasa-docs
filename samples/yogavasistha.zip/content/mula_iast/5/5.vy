`v 1 [
pañcamaḥ sargaḥ 5
śrīvasiṣṭha uvāca |
idamuttamasiddhāntasundaraṃ sundarākṛte |
upaśāntiprakaraṇaṃ śṛṇuṣvāvahito hitam
]

`v 2 [
dīrghasaṃsāramāyeyaṃ rāma rājasatāmasaiḥ |
dhāryate jantubhirnityaṃ sustambhairiva maṇḍapaḥ
]

`v 3 [
sattvasthajātibhirdhīraistvādṛśairguṇabṛṃhitaiḥ |
helayā tyajyate pakvā `note[tucche iti pāṭhaḥ] māyeyaṃ tvagivoragaiḥ | 3
|
prāguktalakṣaṇaiḥ sattvasthajātibhiḥ rājasasāttvikaiḥ śuddhasāttvikaiśca
]

`v 4 [
ye sattvajātayaḥ prājñāstathā rājasasāttvikāḥ |
vicārayanti te sādho jagatpūrvaparamparām
]

`v 5 [
śāstrasajjanasatkāryasaṅgenopahatainasām |
sārāvalokinī buddhīrjāyate dīpikopamā
]

`v 6 [
svayameva vicāreṇa vicāryātmānamātmanā |
yāvannādhigataṃ jñeyaṃ na tāvadadhigamyate
]

`v 7 [
prajñāvatāṃ nayavatāṃ dhīrāṇāṃ kulaśālinām |
jātyā rājasasattvānāṃ mukhyastvaṃ raghunandana
]

`v 8 [
svayamālokaya prājña saṃsārārambhadṛṣṭiṣu |
kiṃ satyaṃ kimasatyaṃ vā bhava satyaparāyaṇaḥ
]

`v 9 [
ādāvante ca yannāsi kīdṛśī tasya satyatā |
ādāvante ca yannityaṃ tatsatyaṃ nāma netarat
]

`v 10 [
ādyantāsanmaye yasya vastunyāsajjate manaḥ |
tasya mugdhapaśorjantorvivekaḥ kena janyate
]

`v 11 [
jāyate mana eveha mana eva vivardhate |
samyagdarśanadṛṣṭyā tu mana eva hi mucyate
]

`v 12 [
śrīrāma uvāca |
jñātametanmayā brahmanyathāsminbhuvanatraye |
mana eva hi saṃsārijarāmaraṇabhājanam
]

`v 13 [
yastasyottaraṇopāyastanme brūhi suniścitam |
hārdaṃ tamastvayārkeṇa rāghavāṇāṃ vināśyate
]

`v 14 [
śrīvasiṣṭha uvāca |
pūrvaṃ rāghava śāstreṇa vairāgyeṇa pareṇa ca |
tathā sajjanasaṅgena nīyatāṃ puṇyatāṃ manaḥ
]

`v 15 [
saujanyopahitaṃ ceto yadā vairāgyamāgatam |
tadānugamyā guravo vijñānaguravo'pi ye
]

`v 16 [
tatastasyopadiṣṭena kṛtvā dhyānārcanādikam |
krameṇa padamāpnoti tadyatparamapāvanam
]

`v 17 [
vicāreṇāvadātena paśyatyātmānamātmanā |
indunā śītalenāntarviśvaṃ khamiva tejasā
]

`v 18 [
tāvadbhavamahāmbhodhau janastṛṇavaduhyate |
vicārataṭaviśrāntimeti yāvanna cetasā
]

`v 19 [
vicāreṇa parijñātavastuno'sya janasya dhīḥ |
sarvānadhḥkarotyādhīnsaumyāmbha iva vālukāḥ
]

`v 20 [
ādhīn mānasaduḥkhāni | adhaḥkaroti nirasyatīti yāvat | saumyaṃ nimnaprasannam |
19 |
idaṃ rukmamidaṃ bhasma parijñātamiti sphuṭam |
na yathā hemakārasya hemajñānātmanastathā
]

`v 21 [
akṣayo'yaṃ manāgātmā svātmanyavagate ciram |
bhavatīti narasyeha mohasyāvasaraḥ kutaḥ
]

`v 22 [
aparijñātasāre hi mano'ntaryadi muhyate |
jñātasāre tvasaṃdigdhamasatī kila mūḍhatā
]

`v 23 [
he janā aparijñāta ātmā vo duḥkhasiddhaye |
parijñātastvanantāya sukhāyopaśamāya ca
]

`v 24 [
miśrībhūtamivānena dehenopahatātmanā |
vyaktīkṛtya svamātmānaṃ svasthā bhavata mā ciram
]

`v 25 [
dehenāsya na saṃbandho manāgevāmalātmanaḥ |
hemnaḥ paṅkalaveneva tadgatasyāpi mānavāḥ
]

`v 26 [
pṛthagātmā pṛthagdehī jalapadmalavopamau |
ūrdhvavāhurviraumyeṣa na ca kaścicchṛṇoti me
]

`v 27 [
jaḍadharmi mano yāvadgartakacchapavatsthitam |
bhogamārgavadāmūḍhaṃ vismṛtātmavicāraṇam
]

`v 28 [
tāvatsaṃsāratimiraṃ sendunāpi savahninā |
arkadvādaśakenāpi manāgapi na bhidyate
]

`v 29 [
saṃprabuddhe hi manasi svāṃ vivecayati sthitim |
naiśamarkodaya iva tamo hārdaṃ palāyate
]

`v 30 [
nityamuttamabodhāya yogaśayyāgataṃ manaḥ |
bodhayedbhavabhedāya bhavo hyatyantaduḥkhadaḥ
]

`v 31 [
yathā rajobhirgaganaṃ yathā kamalamambubhiḥ |
na lipyate hi saṃśliṣṭairdehairātmā tathaiva ca
]

`v 32 [
kardamādi yathā hemnā śliṣṭimeti pṛthaksthitam |
nāntaḥpariṇatiṃ yāti jaḍo dehastathātmanā
]

`v 33 [
sukhaduḥkhānubhāvitvamātmanītyavabudhyate |
asatyameva gagane bindutāmlānate yathā
]

`v 34 [
sukhaduḥkhe na dehasya sarvātītasya nātmanaḥ |
ete hyajñānakasyaiva tasminnaṣṭe na kasyacit
]

`v 35 [
na kasyacitsukhaṃ kiṃcidduḥkhaṃ ca naca kasyacit |
sarvamātmamayaṃ śāntamanantaṃ paśya rāghava
]

`v 36 [
imā yāḥ paridṛśyante vitatāḥ sṛṣṭidṛṣṭayaḥ |
payasīva taraṅgāste picchaṃ vyomnīva cātmani
]

`v 37 [
yathā maṇirdadātyātmacchāyāḥ svayamakāraṇam |
tejomayīstathaivāyamātmā sṛṣṭīḥ prayacchati
]

`v 38 [
ātmā jagacca sumate naikaṃ na dvaitamapyasat |
ābhāsamātramevedamitthaṃ saṃprati jṛmbhate
]

`v 39 [
samastaṃ khalvidaṃ brahma sarvamātmaivamātatam |
ahamanyadidaṃ cānyaditi bhrāntiṃ tyajānagha
]

`v 40 [
tate brahmaghane nitye saṃbhavanti na kalpanāḥ |
vicchittayaḥ payorāśau yathā rāma na sanmayāḥ
]

`v 41 [
ekasinneva sarvasminparamātmani vastuni |
dvitīyā kalpanā nāsti vahnau himakaṇo yathā
]

`v 42 [
bhāvayannātmanātmānaṃ cidrūpeṇaiva cinmayam |
ṛjūjjvalamaye hyātmā svayamātmani jṛmbhate
]

`v 43 [
na śokosti na mohosti na janmāsti na janmavān |
yadastīha tadevāsti vijvaro bhava rāghava
]

`v 44 [
nirdvandvo nityasattvastho niryogakṣema ātmavān |
advitīyo viśokātmā vijvaro bhava rāghava
]

`v 45 [
samaḥ svasthaḥ sthiramatiḥ śāntaśokamanā muniḥ |
maunī varamaṇisvaccho vijvaro bhava rāghava
]

`v 46 [
viviktaḥ śāntasaṃkalpo dhīradhīrvijitāśayaḥ |
yathāprāptānuvartī ca vijvaro bhava rāghava
]

`v 47 [
vītarāgo nirāyāso vimalo vītakalmaṣaḥ |
nādātā na parityāgī vijvaro bhava rāghava
]

`v 48 [
viśvātītapadaṃ prāptaḥ prāptaprāptavyapūritaḥ |
pūrṇārṇavavadakṣubdho vijvaro bhava rāghava
]

`v 49 [
vikalpajālanirmukto māyāñjanavivarjitaḥ |
ātmanātmani tṛptātmā vijvaro bhava rāghava
]

`v 50 [
anantāpāraparyantavapurātmavidāṃvara |
dharādharaśirodhīro vijvaro bhava rāghava
]

`v 51 [
yathāprāptānubhavanātsarvatrānabhivāñchanāt |
tyāgādānaparityāgādvijvaro bhava rāghava
]

`v 52 [
ātmanyevātmanaudāryaṃ bhaja pūrṇa ivārṇavaḥ |
ātmanyevātmanāhlādaṃ bhaja pūrṇendubimbavat
]

`v 53 [
viśvaprapañcaracaneyamasatyarūpā
nāsatyarūpamanudhāvati rāma tajjñaḥ |
tajjño'si śāntakalano'si nirāmayo'si
nityodito'si bhava sundara śāntaśokaḥ
]

`v 54 [
ekātapatramavanau guruṇopadiṣṭaṃ
samyaksupālaya ciraṃ samayeha dṛṣṭyā |
rājyaṃ samastaguṇarañjitarājaloka-
styāgo na yukta iha karmasu nāpi rāgaḥ
]