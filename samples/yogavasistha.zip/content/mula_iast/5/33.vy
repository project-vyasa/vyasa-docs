`v 1 [
trayastriṃśaḥ sargaḥ 33
śrīvasiṣṭha uvāca |
garjantamatisaṃrabdhaṃ suralokamathārihā |
uvāca mādhavo vākyaṃ śikhivṛndamivāmbudaḥ
]

`v 2 [
śrībhagavānuvāca |
vibudhā mā viṣaṇṇāḥ stha prahrādo bhaktimāniti |
pāścātyaṃ janma tasyedaṃ mokṣārho'sāvariṃdamaḥ
]

`v 3 [
ata uttarametena garbhatā danujanmanā |
na kartavyā pradagdhena bījenevāṅkurakriyā
]

`v 4 [
guṇavānnirguṇo jāta ityanarthakramaṃ viduḥ |
nirguṇo guṇavāñjāta ityāhuḥ siddhidaṃ kramam
]

`v 5 [
devairuktaṃ tasya bhagavadbhaktyanaucityadoṣaṃ pariharati - guṇavāniti |
jātaśceti `note[cediti ityapi pāṭhaḥ] śeṣaḥ | anarthakramaṃ
anarthaparyavasitaṃ puruṣārthavighātakaṃ ca kramaṃ viduḥ āhuśca vidvāṃsaḥ |
4 |
ātmīyāni vicitrāṇi bhuvanānyamarottamāḥ |
prayāta nāsukhāyaiṣā prahrādī guṇiteha vaḥ
]

`v 6 [
śrīvasiṣṭha uvāca |
ityuktvā vibudhāṃstatra kṣīrodārṇavavīciṣu |
antardhānaṃ yayau devastaṭatāpicchagucchavat
]

`v 7 [
so'pi saṃpūjitahariḥ suraugho vrajadambaram |
punarmandaranirdhūtātkaṇajālamivārṇavāt
]

`v 8 [
prahrādaṃ prati gīrvāṇāstataḥ snigdhatvamāyayuḥ |
mahānto yatra nodvignāstatra viśvāsavanmanaḥ
]

`v 9 [
pratyahaṃ pūjayāmāsa devadevaṃ janārdanam |
manasā karmaṇā vācā prahrādo bhaktimāniti
]

`v 10 [
atha pūjāparasyāsya samavardhanta kālataḥ |
vivekānandavairāgyavibhavapramukhā guṇāḥ
]

`v 11 [
nābhyanandadasau bhogapūgaṃ śuṣkamiva drumam |
na cāramata kāntāsu mṛgo lokamahīṣviva
]

`v 12 [
na reme lokacaryāsu śāstrārthakathanādṛte |
na jāyate ratistasya dṛśye sthala ivābjinī
]

`v 13 [
lokacaryāsu aśāstrīyalokavṛtteṣu | dṛśye darśanārhe samājotsavādikautuke |
12 |
na viśaśrāma ceto'sya bhogarogānurañjane |
muktāphalamasaṃśliṣṭhaṃ muktāphala ivāmale
]

`v 14 [
tyaktabhogādikalanaṃ viśrāntimanupāgatam |
cetaḥ kevalamasyāsīddolāyāmiva yojitam
]

`v 15 [
prāhlādīṃ tāṃ sthitiṃ viṣṇurdevaḥ kṣīrodamandirāt |
viveda sarvagatayā dhiyā paramakāntayā
]

`v 16 [
atha pātālamārgeṇa viṣṇurāhlāditāgrataḥ |
pūjādevagṛhaṃ tasya prahrādasya samāyayau
]

`v 17 [
vijñāyābhyāgataṃ devaṃ pūjayā dviguṇeddhayā |
daityendraḥ puṇḍarīkākṣamādarātparyapūjayat
]

`v 18 [
pūjāgṛhagataṃ devaṃ pratyakṣāvasthitaṃ harim |
prahrādaḥ paramaprīto girā tuṣṭāva puṣṭayā
]

`v 19 [
prahrāda uvāca |
tribhuvanabhavanābhirāmakośaṃ
sakalakalaṅkaharaṃ paraṃ prakāśam |
aśaraṇaśaraṇaṃ śaraṇyamīśaṃ
harimajamacyutamīśvaraṃ prapadye
]

`v 20 [
kuvalayadalanīlasaṃnikāśaṃ
śaradamalāmbarakoṭaropamānam |
bhramaratimirakajjalāñjanābhaṃ
sarasijacakragadādharaṃ prapadye
]

`v 21 [
vimalamalikalāpakomalāṅgaṃ
sitadalapaṅkajakuḍmalābhaśaṅkham |
śrutiraṇitavirañcicañcarīkaṃ
svahṛdayapadmadalāśrayaṃ prapadye
]

`v 22 [
sitanakhagaṇatārakāvakīrṇaṃ
smitadhavalānanapīvarendubimbam |
hṛdayamaṇimarīcijālagaṅgaṃ
hariśaradambaramātataṃ prapadye
]

`v 23 [
aviralakṛtasṛṣṭisarvalīnaṃ
satatamajātamavardhanaṃ viśālam |
guṇaśatajaraṭhābhijātadehaṃ
tarudalaśāyinamarbhakaṃ prapadye
]

`v 24 [
navavikasitapadmareṇugauraṃ
sphuṭakamalāvapuṣā vibhūṣitāṅgam |
dinaśamasamayāruṇāṅgarāgaṃ
kanakanibhāmbarasundaraṃ prapadye
]

`v 25 [
ditisutanalinītuṣārapātaṃ
suranalinīsatatoditārkabimbam |
kamalajanalinījalāvapūraṃ
hṛdi nalinīnilayaṃ vibhuṃ prapadye
]

`v 26 [
tribhuvananalinīsitāravindaṃ
timirasamānavimohadīpamagryam |
sphuṭataramajaḍaṃ cidātmatattvaṃ
jagadakhilārtiharaṃ hariṃ prapadye
]

`v 27 [
śrīvasiṣṭha uvāca |
iti guṇabahulābhirvāgbhirabhyarcito'sau
harirasuravināśaḥ śrīniṣaṇṇāṃsadeśaḥ |
jalada iva mayūraṃ prītimānprīyamāṇaṃ
kuvalayadalanīlaḥ pratyuvācāsurendram
]