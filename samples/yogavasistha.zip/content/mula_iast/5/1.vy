`v 1 [
uktvā upadiśya | svaṃ svīyaṃ maunamaṇḍalaṃ munyāvāsadeśam
]

`v 3 [
nāhaṃ merurna me merurjagannāhaṃ na me jagat |
nāhaṃ śailā na me śailā dharā nāhaṃ na me dharā
]

`v 4 [
kirātamaṇḍalaṃ nedaṃ mama nāhaṃ ca maṇḍalam |
nijasaṃketamātreṇa kevalaṃ deśa eva me
]

`v 5 [
tyakto mayaiṣa saṃketo nāhaṃ deśona vaiṣa me |
idānīṃ nagaraṃ śiṣṭameṣa evātra niścayaḥ
]

`v 6 [
patākāvanapaṅktyāḍhyā bhṛtyopavanasaṃkulā |
gajāśvasāmantayutā purī nāhaṃ na me purī
]

`v 7 [
vyarthasaṃketasaṃbandhaṃ saṃketavigame kṣatam |
bhogavṛndaṃ kalatraṃ ca nāhaṃ naitanmamākhilam
]

`v 8 [
evaṃ sabhṛtyaṃ sabalaṃ savāhanapurāntaram |
nāhaṃ rājyaṃ na me rājyaṃ saṃketo hyayamākulaḥ
]

`v 9 [
ākulaḥ kākiṇīkārṣāpaṇasaṃbandhavadandhaparamparāvyavahārasiddha iti yāvat |
8 |
dehamātramahaṃ manye hastapādādisaṃyutam |
tadidaṃ tāvadāśvantaralamālokayāmyaham
]

`v 10 [
tadatra tāvanmāṃsāsthi nāhametadacetanam |
na caitanmama saṃśleṣametyabjasya yathā jalam
]

`v 11 [
māṃsaṃ jaḍaṃ na tadahaṃ naivāhaṃ raktamapyalam |
jaḍānyasthīni naivāhaṃ na caitāni mama kvacit
]

`v 12 [
karmendriyāṇi naivāhaṃ na ca karmendriyāṇi me |
jaḍaṃ yatkila dehe'smiṃstadahaṃ naiva cetanaḥ
]

`v 13 [
nāhaṃ bhogā na me bhogā na me buddhīndriyāṇi ca |
jaḍānyasatsvarūpāṇi na ca buddhīndriyāṇyaham
]

`v 14 [
mūlaṃ saṃsṛtidoṣasya mano nāhaṃ jaḍaṃ hi tat |
atha buddhirahaṃkāra iti dṛṣṭirmanomayī
]

`v 15 [
atha buddhirahaṃkāra iti yā dṛśyata iti dṛṣṭiḥ sāpi nāhaṃ na
mametyanuṣajyate | yataḥ sā manomayī antaḥkaraṇāvasthā | bhedarūpeti yāvat | 14
|
manobuddhīndriyādyanto bhūtakośaścaladvapuḥ |
nāhamevaṃ śarīrādi śiṣṭamālokayāmyaham
]

`v 16 [
śeṣastu cetano jīvaḥ sa ceccetyena cetati |
anyena bodhyamāno'sau nātmatattvavapurbhavet
]

`v 17 [
evaṃ tyajāmi saṃvedyaṃ cetyaṃ nāhaṃ hi tatkila |
śeṣo vikalparahito viśuddhacidahaṃsthitaḥ
]

`v 18 [
citrameṣo'smi labdhātmā jātaḥ kālena kāryavān |
eṣa so'hamanantātmā nāto'sya paramātmanaḥ
]

`v 19 [
brahmaṇīndre yame vāyau sarvabhūtagaṇe tathā |
sa eṣa bhagavānātmā tanturmuktāsviva sthitaḥ
]

`v 20 [
eṣa brahmaiṣa indraḥ ityādiśrutigaṇānanubhavena saṃvādayati - brahmaṇīti |
19 |
cicchaktiramalā saiṣā cetyāmayavivarjitā |
bharitāśeṣadikkuñjā bhairavākāradhāriṇī
]

`v 21 [
sarvabhāvagatā sūkṣmā bhāvābhāvavivarjitā |
ābrahmabhuvanāntaḥsthā sarvaśaktisamudgikā
]

`v 22 [
sarvasaundaryasubhagā sarvaprākāśyadīpikā |
sarvasaṃsāramuktānāṃ tanturātatarūpiṇī
]

`v 23 [
sarvākāravikārāḍhyā sarvākāravivarjitā |
sarvabhūtaughatāṃ yātā sarvadā sarvatāṃ gatā
]

`v 24 [
caturdaśavidhānyeṣā bhūtāni bhuvanodare |
etanmayīyaṃ kalanā jāgatī vedanātmikā
]

`v 25 [
mithyāvabhāsamātraṃ tu sukhaduḥkhadaśāgatiḥ |
nānākāramayābhāsaḥ sarvamātmaiva citparā
]

`v 26 [
so'yamātmā mama vyāpī seyaṃ yadavabodhanam |
seyamākalitāṅgābhā karoti nṛpavibhramam
]

`v 27 [
asyā eva prasādena mano deharathe sthitam |
saṃsārajālalīlāsu yāti valgati nṛtyati
]

`v 28 [
idaṃ manaḥśarīrādi na kiṃcidapi vastutaḥ |
naṣṭe na kiṃcidapyasminparinaśyati pelave
]

`v 29 [
jagajjālamayaṃ nṛttamidaṃ cittanaṭaistatam |
etayaivaikayā buddhyā dṛśyate dīpalekhayā
]

`v 30 [
kaṣṭaṃ mudhaiva me cintā nigrahānugrahasthitau |
babhūva dehaniṣṭheha na kiṃcidapi dehakam
]

`v 31 [
aho tvahaṃ prabuddho'smi gataṃ durdarśanaṃ mama |
dṛṣṭaṃ draṣṭavyamakhilaṃ prāptaṃ prāpyamidaṃ mayā
]

`v 32 [
sarvaṃ kiṃcididaṃ dṛśyaṃ dṛśyate yajjagadgatam |
cinniṣpandāṃśamātrāṃśānnānyatkiṃcana śāśvatam
]

`v 33 [
kva tau kīdṛgvidhau vāpi kiṃniṣṭhau vā kimātmakau |
nigrahānugrahau loke harṣāmarṣakramau tathā
]

`v 34 [
evaṃ jagato mṛṣātve nigrahānugrahakramau tatprayojakaharṣāmarṣakramau ca
nirāśrayau niṣprakārau nirviṣayau niḥsvarūpau ca saṃpannāvityāha - kveti |
33 |
kiṃ sukhaṃ kiṃ nu vā duḥkhaṃ sarvaṃ brahmedamātatam |
ahamāsaṃ mudhā mūḍha diṣṭyā mūḍho'smyahaṃ sthitaḥ
]

`v 35 [
kimasminnevamāloke śocyate kiṃ vimuhyate |
kiṃ prekṣyate kiṃ kriyate sthīyate vātha gamyate
]

`v 36 [
kiṃcidevamidaṃ nāma cidākāśaṃ virājate |
namo namaste nistattva diṣṭyā dṛṣṭo'si sundara
]

`v 37 [
aho nu saṃprabuddho'smi samyagjñātamalaṃ mayā |
namo mahyamanantāya samyagjñānodayāya ca
]

`v 38 [
vigatarañjananirviṣayasthiti-
rgatabhavabhramarañjitavarjite |
sthirasuṣuptakalābhigatastataḥ
samasamaṃ nivasāmyahamātmani
]