`v 1 [
ṣaṭtriṃśaḥ sargaḥ 36
prahrāda uvāca |
ātmā sarvapadātītaścirātsaṃsmṛtimāgataḥ |
diṣṭyā labdho'si bhagavannamastestu mahātmane
]

`v 2 [
abhivandyātha cālokya ciramāliṅgyase mayā |
ko'nyaḥ syāttvadṛte bandhurbhagavanbhuvanatraye
]

`v 3 [
haṃsi pāsi dadāsi tvaṃ stauṣi yāsi vivalgasi |
ayaṃ prāptosi dṛṣṭosi kiṃ karoṣi kva gacchasi
]

`v 4 [
svasattāpūritāśeṣaviśva viśvajanīna bhoḥ |
sarvatra lakṣyase nityamadhunā kva palāyase
]

`v 5 [
āvayorantaraṃ bhūri janmavyavahitāntaram |
adūramadya saṃpannaṃ diṣṭyā dṛṣṭo'si bāndhava
]

`v 6 [
namaste kṛtakṛtyāya kartre bhartre namostu te |
namaḥ saṃsāravṛntāya nityāya vimalātmane
]

`v 7 [
namaścakrābjahastāya namaścandrārdhadhāriṇe |
namo vibudhanāthāya namaste padmajanmane
]

`v 8 [
vācyavācakadṛṣṭyaiva bhedo yo'yamihāvayoḥ |
asatyā kalpanaiveṣā vīcivīcyambhasoriva
]

`v 9 [
tvamevānantayānantavastuvaicitryarūpayā |
bhāvābhāvavilāsinyā nityayaiva vijṛmbhase
]

`v 10 [
namo draṣṭre namaḥ sraṣṭre namo'nantavikāsine |
namaḥ sarvasvabhāvāya namaste sarvagātmane
]

`v 11 [
pratijanma ciraṃ bahvyo dīrghaduḥkhavatā mayā |
tvayā mayopadiṣṭena dagdhenāpahataujasā
]

`v 12 [
ālokitā lokadṛśo dṛṣṭā dṛṣṭāntadṛṣṭayaḥ |
na prāptastattvayā'nena kiṃcidāsāditaṃ bhavet
]

`v 13 [
sarvaṃ mṛtkāṣṭhapāṣāṇavārimātramidaṃ jagat |
nehāsti tvadṛte deva yatprāptau nābhivāñchati
]

`v 14 [
devāyamadya labdho'si dṛṣṭo'syadhigato'si ca |
saṃprapto'si gṛhīto'si namastestu na muhyasi
]

`v 15 [
yo'kṣṇoḥ kanīnikāraśmijālaprotavapuḥ sthitaḥ |
deva darśanarūpeṇa kathaṃ so'tra na dṛśyate
]

`v 16 [
yastvaksparśau spṛśansarvaṃ gandhaṃ tailaṃ tile yathā |
sparśamantaḥkarotyeṣa sa kathaṃ nānubhūyate
]

`v 17 [
yaḥ śabdaśravaṇādantaḥ śabdaśaktiṃ parāmṛśan |
romāñcaṃ janayatyaṅge sa dūrasthaḥ kathaṃ bhavet
]

`v 18 [
jihvāpallavalagnāni svaditasyāgrato'pi ca |
svadante yasya vastūni svadate sa na kasya ca
]

`v 19 [
puṣpagandhānupādāya ghrāṇahastena dehakam |
ya ālokayati prītyā kasyāsau na kare sthitaḥ
]

`v 20 [
vedavedāntasiddhāntatarkapaurāṇagītibhiḥ |
yo gītaḥ sa kathaṃ hyātmā vijñāto yāti vismṛtiṃ
]

`v 21 [
saiveha dehabhogālī subhagāpīyamadya me |
antarna svadate svacche tvayi dṛṣṭe parāvare
]

`v 22 [
tvayā vimaladīpena bhānuḥ prakaṭatāṃ gataḥ |
tvayā śītatuṣāreṇa candraḥ śiśiratāṃ gataḥ
]

`v 23 [
tvayaite guravaḥ śailāstvayaite dyucarā dhṛtāḥ |
tvayaiveyaṃ dharā dhīrā tvayaivāmbaramambaram
]

`v 24 [
diṣṭyā mattāmasi prāpto diṣṭyā tvattāmahaṃ gataḥ |
ahaṃ tvaṃ tvamahaṃ deva diṣṭyā bhedo'sti nāvayoḥ
]

`v 25 [
ahaṃ tvamitiśabdābhyāṃ paryāyābhyāṃ mahātmanaḥ |
tava vā mama vā śākhā saṃyuktābhyāṃ namo namaḥ
]

`v 26 [
namo mahyamanantāya nirahaṃkārarūpiṇe |
namo mahyamarūpāya namaḥ samasamātmane
]

`v 27 [
mayyātmani same svacche sākṣibhūte nirākṛtau |
dikkālādyanavacchinne svātmanyeveha tiṣṭhasi
]

`v 28 [
manaḥ prakṣomamāyāti sphurantīndriyavṛttayaḥ |
śaktirullasati sphārā prāṇāpānapravāhinī
]

`v 29 [
vahanti dehayantrāṇi kṛṣṭānyāśāvaratrayā |
carmamāṃsāsthidigdhāni manaḥsārathimanti ca
]

`v 30 [
ayaṃ saṃvidvapurahaṃ na kācinna kṛtāspadaḥ |
dehaḥ patatu vodetu yathābhimatayecchayā
]

`v 31 [
cirādahamahaṃ jātaḥ svātmalābhaścirādayam |
cirādupaśama yāti kalpasyānte jagadyathā
]

`v 32 [
cirātsaṃsāragāmitvāddīrghe saṃsāravartmani |
viśrānto'smi ciraṃ śrāntaḥ kalpasyānta ivānalaḥ
]

`v 33 [
sarvātītāya sarvāya tubhyaṃ mahyaṃ namo namaḥ |
tebhyo'pi ca namastestu ye māṃ tvāṃ pravadanti ca
]

`v 34 [
akhilānantasaṃbhogā na spṛṣṭā doṣavṛttibhiḥ |
jayatyakṛtasaṃrambhā sākṣitā paramātmanaḥ
]

`v 35 [
ātmanpuṣpa ivāmodo bhastrāpiṇḍa ivānilaḥ |
tile tailamivāsmiṃstvaṃ sarvatra vapuṣi sthitaḥ
]

`v 36 [
haṃsi pāsi dadāsi tvamavasphūrjasi valgasi |
anahaṃkṛtirūpo'pi citreyaṃ tava māyitā
]

`v 37 [
jayāmīśajvaladdīptiḥ sarvamunmīlayañjagat |
jayāmyuparatārambho jagadbhūyo nimīlayan
]

`v 38 [
paramāṇostavaivāntaridaṃ saṃsāramaṇḍalam |
vaṭatvaṃ vaṭadhānāyāṃ babhūvāsti bhaviṣyati
]

`v 39 [
hayadviparathākārairyadvatkhe dṛśyate'mbudaḥ |
tadvadālokyase deva padārthaśatavibhramaiḥ
]

`v 40 [
bhāvānāṃ bhūribhaṅgānāmabhavāya bhavāya ca |
bhava bhāvavimuktātmā bhāvābhāvabahiṣkṛtaḥ
]

`v 41 [
jahi mānaṃ mahākopaṃ kāluṣyaṃ krūratāṃ tathā |
na mahānto nimajjanti prākṛte guṇasaṃkaṭe
]

`v 42 [
prāktanīṃ dīrghadaurātmyadaśāṃ smṛtvā punaḥpunaḥ |
kohaṃ kiṃ tadbabhūveti hasanmuktācchaṭāsitam
]

`v 43 [
te prayātāḥ samārambhā gatāste dagdhavāsarāḥ |
yeṣu cintānalajvālājālākīrṇo bhavānabhūt
]

`v 44 [
adya tvaṃ dehanagare rājā sphāramanorathaḥ |
na duḥkhairgṛhyase nāpi sukhairvyoma karairiva
]

`v 45 [
adyendriyaduraśvāṃśca jitvā jitamanogajaḥ |
bhogārimabhito bhaṅktvā sāmrājyamadhitiṣṭhasi
]

`v 46 [
apārāmbarapānthastvamajasrāstamayodayaḥ |
avabhāsakaro nityaṃ bahirantaśca bhāskaraḥ
]

`v 47 [
sarvadaivāsi saṃsuptaḥ śaktyā saṃbodhyase vibho |
bhogālokanalīlārthaṃ kāminyā kāmuko yathā
]

`v 48 [
dṛkṣudrābhirupānītaṃ dūrādrūpamadhu tvayā |
pīyate svīkṛtaṃ śaktyā netravātāyanasthayā
]

`v 49 [
brahmāṇḍakoṭarādhvāntāḥ prāṇāpānaparaistvayā |
gatāgatairbrahmapure saṃprekṣyante pratikṣaṇam
]

`v 50 [
dehapuṣpe tvamāmodo dehendau tvamṛtāmṛtam |
rasastvaṃ dehaviṭape śaityaṃ dehahime bhavān
]

`v 51 [
tvayyasti vismayasnehaḥ śarīrakṣīrasarpiṣi |
tvamantarasya dehasya dāruṇyagniriva sthitaḥ
]

`v 52 [
tvamevānuttamāsvādaḥ prākāśyaṃ tejasāmapi |
avagantā tvamarthānāṃ tvaṃ bhāsāmavabhāsakaḥ
]

`v 53 [
spandastvaṃ sarvavāyūnāṃ tvaṃ manohastino madaḥ |
prajñānalaśikhāyāstvaṃ prākāśyaṃ taikṣṇyameva ca
]

`v 54 [
tvadvaśādiyamātmīyā vācā saṃpravilīyate |
dīpavatpunaranyatra samudeti kuto'pi sā
]

`v 55 [
tvayi saṃsāravartinyaḥ padārthāvalayastathā |
kaṭakāṅgadakeyūrayuktayaḥ kanake yathā
]

`v 56 [
bhavānayamayaṃ cāhaṃtvaṃśabdairevamādibhiḥ |
svayamevātmanātmānaṃ līlārthaṃ stauṣi vakṣi ca
]

`v 57 [
mandānilavinunno'bdo gajāśvanaradṛṣṭibhiḥ |
yathā saṃlakṣyate vyomni tathā tvaṃ bhūtadṛṣṭibhiḥ
]

`v 58 [
yathā hayagajākārairjvālā lasati vahniṣu |
tathaivāvyatiriktaistvaṃ dṛśyase bhuvi sṛṣṭiṣu
]

`v 59 [
tvaṃ brahmāṇḍakamuktānāmacchinnastanturātataḥ |
kṣetraṃ tvaṃ bhūtasasyānāṃ cidrasāyanasevitam
]

`v 60 [
brahmāṇḍalakṣaṇānāṃ muktānāṃ muktāphalānām | jalateja##-
asattadanabhivyaktaṃ padārthānāṃ prakāśyate |
tvayā tattvaṃ yathā paktyā māṃsānāṃ svādavedanam
]

`v 61 [
vidyamānāpi vastuśrīrna sthitā tvayi na sthite |
vanitārūpalāvaṇyasatteva gatacakṣuṣaḥ
]

`v 62 [
sadapīha na sattayai vastu nāvarjitaṃ tvayā |
tṛptaye na svalāvaṇyaṃ mukurātpratibimbitam
]

`v 63 [
luṭhati tvāṃ vinā dehaḥ kāṣṭhaloṣṭasamaḥ kṣitau |
sannapyasannagocchrāyaḥ śyāmāsviva raviṃ vinā
]

`v 64 [
sukhaduḥkhakramaḥ prāpya bhavantaṃ parinaśyati |
prākāśyamāsādya yathā tamastejo'thavā himam
]

`v 65 [
tvadālokanayaivaite sthitiṃ yānti sukhādayaḥ |
sūryālokanayā prātarvarṇāḥ śuklādayo yathā
]

`v 66 [
labdhātmāno vinaśyanti saṃbandhakṣaṇa eva te |
te tamāṃsīva dīpasya dṛṣṭā eva vrajantyalam
]

`v 67 [
tamastā tamaso dīpāsattāyāṃ sphuṭatāṃ gatā |
dīpasaṃbandhasamaye sā cotpadya vinaśyati
]

`v 68 [
tadevaṃ sukhaduḥkhaśrīrdṛṣtvaiva tvāmanāmayam |
jāyate jātamātraivaṃ sarvanāśena naśyati
]

`v 69 [
bhaṅguratvādiha sthātuṃ kālaṃ nāṇumapi kṣamā |
nimeṣalakṣabhāgākhyā tanvī kālakalā yathā
]

`v 70 [
gāndharvī nagarī tanvī sukhaduḥkhādibhāvanā |
sphurati tvatprasādena tvayi dṛṣṭe vilīyate
]

`v 71 [
tvadālokekṣaṇodbhūtā tvadālokekṣaṇakṣayā |
mṛteva jātā jāteva mṛtā kenopalakṣyate
]

`v 72 [
kṣaṇamapyasthiraṃ vastu kathaṃ kāryakaraṃ bhavet |
taraṅgairutpalākārairmālā kathamavekṣyate
]

`v 73 [
yadā vā jātanirnaṣṭaṃ kriyāṃ vastu kariṣyate |
tadā rameta loko'yaṃ mālāṃ kṛtvā taḍidgaṇaiḥ
]

`v 74 [
imāṃ sukhādikāṃ lakṣmīṃ vivekijanacetasi |
sthitaḥ sanneva gṛhṇāsi na jahāsi samasthitim
]

`v 75 [
avivekiṣu yo'si tvaṃ sahajātmanyadṛcchayā |
tadrūpakathanenālaṃ mamānalpapadāspada
]

`v 76 [
nirīheṇa niraṃśena nirahaṃkṛtinā tvayā |
satā vāpyasatā vāpi kartṛtvamurarīkṛtam
]

`v 77 [
jaya proḍḍāmarākāra jaya śāntiparāyaṇa |
jaya sarvāgamātīta jaya sarvāgamāspada
]

`v 78 [
jaya jāta jayājāta jaya kṣata jayākṣata |
jaya bhāva jayābhāva jaya jeya jayājaya
]

`v 79 [
ullasāmyupaśāmyāmi tiṣṭhāmyadhigato'smi ca |
jayī jayāya jīvāmi namo mahyaṃ namo'stu te
]

`v 80 [
tvayi sthite mayi vigatāmayātmani
svasaṃsthitau vyapagatarāgarañjane |
kva bandhanaṃ kva ca vipadaḥ kva saṃpado
bhavābhavau kva śamamupaimi śāśvatam
]