`v 1 [
ekonāśītitamaḥ sargah 79
śrīrāma uvāca |
yogayuktasya cittasya śama eva nirūpitaḥ |
samyagjñānamidānīṃ me kathayānugrahātprabho
]

`v 2 [
śrīvasiṣṭha uvāca |
anādyantāvabhāsātmā paramātmeha vidyate |
ityeko niścayaḥ sphāraḥ samyagjñānaṃ vidurbudhāḥ
]

`v 3 [
imā ghaṭapaṭākārāḥ padārthaśatapaṅktayaḥ |
ātmaiva nānyadastīti niścayaḥ samyagīkṣaṇam
]

`v 4 [
asamyagvedanājjanma mokṣaḥ samyagavekṣaṇāt |
asamyagvedanādrajjuḥ sarpo no samyagīkṣaṇāt
]

`v 5 [
saṃkalpāṃśavinirmuktā saṃvitsaṃvedyavarjitā |
saṃvittyābhisamākhyātā muktāvastīha netarat
]

`v 6 [
sā śuddharūpā vijñātā paramātmeti kathyate |
śuddhā tvaśuddharūpāntaravidyetyucyate budhaiḥ
]

`v 7 [
saṃvittireva saṃvedyaṃ nānayordvitvakalpanā |
cinotyātmānamātmaiva rāmaivaṃ nānyadasti hi
]

`v 8 [
yathābhūtātmadarśitvametāvadbhuvanatraye |
yadātmaiva jagatsarvamiti niścitya pūrṇatā
]

`v 9 [
sarvamātmaiva kau diṣṭau bhāvābhāvau kva ca sthitau |
kva bandhamokṣakalane kimanyadrāma śocyate
]

`v 10 [
na cetyamanyanno cittaṃ brahmaivedaṃ vijṛmbhate |
sarvamekaṃ paraṃ vyoma ko mokṣaḥ kasya bandhatā
]

`v 11 [
brahmedaṃ bṛṃhitākāraṃ bṛhadvṛhadavasthitam |
jñānādastamitadvitvaṃ bhavātmaiva tvamātmanā
]

`v 12 [
samyagālokite rūpe kāṣṭhapāṣāṇavāsasām |
manāgapi na bhedo'sti kvāsi saṃkalpanonmukhaḥ
]

`v 13 [
ādāvante ca saṃśāntaṃ svarūpamavināśi yat |
vastu nāmātmanaścaiva tanmayo bhava rāghava
]

`v 14 [
paraṃ vyomedamakhilaṃ jagatsthāvarajaṅgamam |
sukhaduḥkhakramaḥ kutra vijvaro bhava rāghava
]

`v 15 [
dvaitādvetasamudbhūtairjarāmaraṇavibhramaiḥ |
sphuratyātmabhirātmaiva citrairambviva vīcibhiḥ
]

`v 16 [
śuddhamātmānamāliṅgya nityamantasthayā dhiyā |
yaḥ sthitastaṃ ka ātmehaṃ bhogā bandhayituṃ kṣamāḥ
]

`v 17 [
kṛtasphāravicārasya manobhogādayo'rayaḥ |
manāgapi na bhindanti śailaṃ mandānilā iva
]

`v 18 [
avicāriṇamajñānaṃ mūḍhamāśāparāyaṇam |
nigirantīha duḥkhāni bakā matsyamivājalam
]

`v 19 [
jagadātmaiva sakalamavidyā nāsti kutracit |
iti dṛṣṭimavaṣṭabhya samyagrūpaḥ sthiro bhava
]

`v 20 [
nānātvamasti kalanāsu na vastuto'nta-
rnānāvidhāsu sarasīṣu jalādi nānyat |
ityekaniścayamayaḥ puruṣo vimukta
ityucyate samavalokitasamyagarthaḥ
]