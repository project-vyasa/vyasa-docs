`v 1 [
pañcāśītitamaḥ sargaḥ 85
śrīrāma uvāca |
atha kiṃ vītahavyaḥ svaṃ sthitaṃ tasmindharodare |
kathamuddhṛtavāndehaṃ sa saṃpannaśca kiṃ katham
]

`v 2 [
śrīvasiṣṭha uvāca |
anantaramanantātma vītahavyābhidhaṃ manaḥ |
svamevātmacamatkāramātraṃ samavabuddhavān
]

`v 3 [
śārvasyāsya gaṇasyābhūtprāgjyotiḥsmaraṇe svayam |
icchā kadācitsakalaprāgjanmālokanonmukhī
]

`v 4 [
aśeṣānsa dadarśātha naṣṭānaṣṭānsvadehakān |
anaṣṭānāṃ tato madhyāttattatkoṭarasaṃsthitam
]

`v 5 [
yadṛcchayaiva proddhartuṃ dehaṃ tasyābhavanmatiḥ |
apaśyattattathā tatra paṅke kīṭamiva sthitam
]

`v 6 [
śarīraṃ vītahavyākhyaṃ dharākoṭarapīḍitam |
prāvṛḍoghopanītaṃ tatpṛṣṭhasthapaṅkamaṇḍalam
]

`v 7 [
tṛṇajālāvakīrṇatvagdehapṛṣṭhamṛdaṃ tathā |
etaddṛṣṭvā mahātejā dharāvivarayantritam
]

`v 8 [
bhūyo'pi cintayāmāsa dhiyā paramabodhayā |
sarvasaṃpīḍitāṅgatvātkāyo me prāṇavāyubhiḥ
]

`v 9 [
muktaścalitumākartuṃ śaknoti na manāgapi |
tajjñātvā praviśāmyāśu dehamevaṃ vivasvataḥ
]

`v 10 [
tadīyaḥ piṅgalo dehamuddhariṣyati me tataḥ |
athavā kiṃ mamaitena śāmyāmyahamavighnataḥ
]

`v 11 [
nirvāmi svaṃ padaṃ yāmi ko'rtho me dehalīlayā |
iti saṃcintya manasā vītahavyo mahāmate
]

`v 12 [
tūṣṇīṃ sthitvā kṣaṇaṃ bhūyaścintayāmāsa bhūtale |
upādeyo hi dehasya na me tyāgo na saṃśrayaḥ
]

`v 13 [
yādṛśo dehasaṃtyāgastādṛśo dehasaṃśrayaḥ |
tadyāvadasti deho'yaṃ na yāvadaṇutāṃ gataḥ
]

`v 14 [
tāvadenamupāruhya kiṃcitpraviharāmyaham |
piṅgalena śarīraṃ svamuddhartuṃ tāpanaṃ vapuḥ
]

`v 15 [
praviśāmi nabhaḥsaṃsthaṃ mukuraṃ pratibimbavat |
ityasau munirādityaṃ viveśānilarūpadhṛk
]

`v 16 [
puryaṣṭakavapurbhūtvā bhastrākhamiva cānalaḥ |
bhagavānmunirapyenaṃ hṛdgataṃ munināyakam
]

`v 17 [
dṛṣṭvāsau cintayankāryaṃ paurvāparyamudāradhīḥ |
vindhyabhudharabhūkośamantarmunikalevaram
]

`v 18 [
tṛṇopalaparicchannaṃ dadarśa gatasaṃvidam |
ṛṣeścikīrṣitaṃ jñātvā bhānurgaganamadhyagaḥ
]

`v 19 [
dharāto munimuddhartumādideśāgragaṃ gaṇam |
vītahavvamuneḥ saṃvitsā puryaṣṭakarūpiṇī
]

`v 20 [
raviṃ vātamayī pūjyaṃ praṇanāmāśu cetasā |
bhānunāpyabhyanujñāto mānapūrvakamagragam
]

`v 21 [
viveśa piṅgalākāraṃ vindhyakandaragāminam |
piṅgalo'sau nabhastyaktvā kuñjakuñjarasundaram
]

`v 22 [
prāpa vindhyavanaṃ prāvṛṇmattābhrāmbarabhāsuram |
uddadhāra dharākośānnakhaniṣkṛṣṭabhūtalaḥ
]

`v 23 [
kalevaraṃ muneḥ paṅkānmṛṇālamiva sārasaḥ |
maunaṃ puryaṣṭakamatha svaṃ viveśa kalevaram
]

`v 24 [
muneḥ saṃbandhi maunaṃ puryaṣṭakaṃ piṅgaladehātsvaṃ kalevaraṃ viveśa | 23
|
nabhastalaparibhrānto vihaṅgama ivālavam |
praṇematurmitho mūrtavītahavyanabhaścarau
]

`v 25 [
babhūvatuḥ svakāryaikatatparau tejasāṃ nidhī |
jagāma piṅgalo vyoma muniśca vimalaṃ saraḥ
]

`v 26 [
tārakākārakumudaṃ sūryāṃśukavadākṛti |
vītahavyo mamajjāśu sarasyudbhinnapaṅkaje
]

`v 27 [
paṅkapalvalalīlānte vane kalabhako yathā |
tatra snātvā japaṃ kṛtvā pūjayitvā divākaram |
manobhūṣitayā tanvā pūrvavatpunarābabhau
]

`v 28 [
maitryā tayā samatayā parayā ca śāntyā
satprajñayā muditayā kṛpayā śriyā ca |
yukto muniḥ sakalasaṅgavimuktacetā
vindhye sarittaṭagato dinameva reme
]