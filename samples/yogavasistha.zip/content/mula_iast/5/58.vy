`v 1 [
aṣṭapañcāśaḥ sargaḥ 58
śrīvasiṣṭha uvāca |
atraivodāharantīmamitihāsaṃ purātanam |
kirāteśasya suraghorvṛttāntaṃ vismayāspadam
]

`v 2 [
uttarasyā diśo medaḥ karpūrapaṭalaṃ bhuvaḥ |
saṃbhūtaṃ hasanaṃ śārvaṃ śuklo vā cāndra ātapaḥ
]

`v 3 [
himādreḥ śṛṅgamastīha kailāso nāma parvataḥ |
śailakuñjaranirmuktakalāpasyeva nāyakaḥ
]

`v 4 [
viṣṇoḥ kṣīrodaka iva svargaḥ surapateriva |
abjajasyeva nābhyabjaṃ gṛhaṃ yaḥ śaśimaulinaḥ
]

`v 5 [
rudrākṣavṛkṣadolābhiḥ sāpsarobhirvibhāti yaḥ |
lolaratnaśalākābhirlaharībhirivārṇavaḥ
]

`v 6 [
gaṇāṅganānāmaniśaṃ mattānāṃ caraṇairhatāḥ |
aśokā iva rājante yatrāśokā vilāsinaḥ
]

`v 7 [
saṃcarañśaṃkaro dikṣu bhṛguṣvindumaṇidravaiḥ |
nivartante pravartante yatrājasraṃ ca nirjharāḥ
]

`v 8 [
yo latāvṛkṣagulmaughavāpīhradanadīnadaiḥ |
mṛgairmṛgagaṇairbhūtairbrahmāṇḍavadivāvṛtaḥ
]

`v 9 [
tasya hemajaṭā nāma kirātāḥ saṃsthitāḥ sthale |
pipīlikā vaṭatarormūlakośagatā iva
]

`v 10 [
kailāsapādāraṇyānāṃ rudrākṣaistarugulmakaiḥ |
vasanti dhūkavatkṣudrāste vai nikaṭajīvinaḥ
]

`v 11 [
āsītteṣāmudārātmā rājā parapuraṃjayaḥ |
jayalakṣmyā bhuja iva yaḥ prajāyāśca dakṣiṇaḥ
]

`v 12 [
jayalakṣmyā bhuja iva parapuraṃjayaḥ prajāyāḥ pālane ca dakṣiṇo rājā
vakṣyamāṇaviśeṣaṇairbrahmavidyādhikāradarśanāccāsau kṣatriya iti gamyate |
11 |
suraghurnāma balavānsuraghorāridarpahā |
arkaḥ parākrama iva mūrtimāniva mārutaḥ
]

`v 13 [
jito vai rājyavibhavairdhanairguhyakanāyakaḥ |
śatakratugururbodhaiḥ kāvyairasuradeśikaḥ
]

`v 14 [
sa cakre rājakāryāṇi nigrahānugrahakramaiḥ |
yathāprāptānyakhinnāṅgo dinānīva divākaraḥ
]

`v 15 [
tajjābhyāṃ sukhaduḥkhābhyāmatha tasyābhyabhūyata |
svagatirvāgurābandhaiḥ śliṣṭāṅgasyeva pakṣiṇaḥ
]

`v 16 [
kimārtaṃ pīḍayāmyenaṃ tilānyantramivaujasā |
sarveṣāmeva bhūtānāṃ mamevārtiḥ prajāyate
]

`v 17 [
dhanamasmai prayacchāmi dhanenānandavāñjanaḥ |
bhavatyahamivāśeṣastadalaṃ me'tinigrahaiḥ
]

`v 18 [
athavā nigrahaṃ prāptaṃ karomyetena vai vinā |
vartate na prajaiveyaṃ vinā vāri saridyathā
]

`v 19 [
hā kaṣṭameva `note[kaṣṭameva ityapi kvacitpāṭhaḥ] nigrāhyo
nityānugrāhya eṣa me |
diṣṭyādya sukhavānasmi kaṣṭamadyāsmi duḥkhavān
]

`v 20 [
iti dolāyitaṃ `note[lolāyitaṃ iti pāṭhaḥ] ceto na viśaśrāma bhūpateḥ |
ekatrāmbumahāvarte ciratṛṣṇamiva bhramat
]

`v 21 [
athaikadā gṛhaṃ tasya māṇḍavyo munirāyayau |
bhrāntāśeṣakakupkuñjo vāsavasyeva nāradaḥ
]

`v 22 [
tamasau pūjayāmāsa papraccha ca mahāmunim |
saṃdehadurdrumastambhaparaśuṃ sarvakovidam
]

`v 23 [
suraghuruvāca |
bhavadāgamanenāsmi mune nirvṛtimāgataḥ |
paramāṃ vasudhāpīṭhaṃ saṃprāpta iva mādhave
]

`v 24 [
adya tiṣṭhāmyahaṃ nātha dhanyānāṃ dhuri dharmataḥ |
vikāsi raviṇevābjaṃ yattvayāsmyavalokitaḥ
]

`v 25 [
bhagavansarvadharmajña ciraṃ viśrāntavānasi |
tadamuṃ saṃśayaṃ chindhi mamārkastimiraṃ yathā
]

`v 26 [
mahatāṃ saṃgamenārtiḥ kasya nāma na naśyati |
saṃdehaṃ tu parāmārtimāhurārtivido janāḥ
]

`v 27 [
mannigrahānugrahajā madbhṛtyavapuṣi sthitāḥ |
kaṣanti māmalaṃ cintā gajaṃ harinakhā iva
]

`v 28 [
tadyathā samatodeti sūryāṃśuriva sarvadā |
matau mama mune nānyā tathā karuṇayā kuru
]

`v 29 [
māṇḍavya uvāca |
svayatnena svasaṃsthena svenopāyena bhūpate |
eṣā manaḥpelavatā himavatpravilīyate
]

`v 30 [
svavicāraṇayaivāśu śāmyatyantarmanojvaraḥ |
śaradāgamamātreṇa mihikā mahatī yathā
]

`v 31 [
svenaiva manasā svāni svaśarīragatāni ca |
vicārayendriyāṇyantaḥ kīdṛśānyatha kāni ca
]

`v 32 [
ko'haṃ kathamidaṃ kiṃvā kathaṃ maraṇajanmanī |
vicārayāntarevaṃ tvaṃ mahattāmalameṣyasi
]

`v 33 [
vicāraṇā parijñātasvabhāvasya satastava |
harṣāmarṣadaśāścetastolayiṣyanti nācalam
]

`v 34 [
manaḥ svarūpamutsṛjya śamameṣyati vijvaram |
bhūtapūrvavapurbhūtvā taraṅgaḥ payasīva te
]

`v 35 [
tiṣṭhadeva manorūpaṃ parityakṣyati te'nagha |
kalaṅkavikalaṃ kālaṃ manvantaragatāviva
]

`v 36 [
anukampyā bhaviṣyanti śrīmantaḥ sarva eva te |
dṛṣṭatattvasya tuṣṭasya janāḥ piturivāvanau
]

`v 37 [
vivekadīpadṛṣṭātmā mervabdhinabhasāmapi |
adho `note[atho iti pāṭhaḥ] kariṣyasi nṛpa mahattāmuttamārthadām | 37
|
yadā ākāśādīnāmapi mahattā tatsattādhīnā tadā tasya niratiśayaṃ mahattvaṃ
kiṃ vācyamityāśayenāha - viveketi | vivekajanyena jñānadīpena dṛṣṭa
ātmā yena
]

`v 38 [
mahattāmāgate cetastava saṃsāravṛttiṣu |
na nimajjati he sādho goṣpadeṣviva vāraṇaḥ
]

`v 39 [
kṛpaṇaṃ tu mano rājanpelave'pi nimajjati |
kārye goṣpadatoye'pi jīrṇāṅgo maśako yathā
]

`v 40 [
cetovāsanayā paṅke kīṭavatparimajjasi |
dṛśyamātrāvalambinyā svayā dīnatayā tayā
]

`v 41 [
tāvattāvanmahābāho svayaṃ saṃtyajyate'khilam |
yāvadyāvatparālokaḥ paramātmaiva śiṣyate
]

`v 42 [
tāvatprakṣālyate dhāturyāvaddhemaiva śiṣyate |
tāvadālokyate sarvaṃ yāvadātmaiva labhyate
]

`v 43 [
sarvaḥ sārvikayā buddhyā sarvaṃ sarvatra sarvadā |
sarvathā saṃparityajya svātmanātmopalabhyate
]

`v 44 [
yāvatsarvaṃ na saṃtyaktaṃ tāvadātmā na labhyate |
sarvāvasthāparityāge śeṣa ātmeti kathyate
]

`v 45 [
yāvadanyanna saṃtyaktaṃ tāvatsāmānyameva hi |
vastu nāsādyate sādho svātmalābhe tu kā kathā
]

`v 46 [
yatra sarvātmanaivātmā lābhāya yatati svayam |
tyaktānyakāryaṃ prāpnoti tannāma nṛpa netarat
]

`v 47 [
svātmāvalokanārthaṃ tu tasmātsarvaṃ parityajet |
sarvaṃ kiṃcitparityajya yaddṛṣṭaṃ tatparaṃ padam
]

`v 48 [
sakalakāraṇakāryaparamparā-
mayajagadgatavastuvijṛmbhitam |
alamapāsya manaḥ svavapustataḥ
parivilāpya yadeti tadeva tat
]