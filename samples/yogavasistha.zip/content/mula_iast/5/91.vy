`v 1 [
ekanavatitamaḥ sargaḥ 91
śrīrāma uvāca |
paramākāśakośādrirūḍhalokāntaradrumam |
tārakāpuṣpaśabalaṃ devasuravihaṃgamam
]

`v 2 [
vidyunmañjaritopāntanīlanīradapallavam |
sarvarturamyacandrārkagaṇaramyakadanturam
]

`v 3 [
saptābdhivāpīvalitaṃ saricchatamanoharam |
caturdaśavidhānantabhūtajātopajīvitam
]

`v 4 [
jagatkānanamākramya sthitāyāḥ kṛtajālakam |
brahmansaṃsṛtimṛdvīkālatāyā vitatākṛteḥ
]

`v 5 [
jarāmaraṇaparvāyāḥ sukhaduḥkhaphalāvaleḥ |
ārūḍhamūlamālāyā `note[prarūḍheti pāṭhaḥ] mohasekajalāñjaleḥ
]

`v 6 [
kiṃ bījamatha bījasya tasya kiṃ bījamucyate |
atha tasyāpi kiṃ bījaṃ bījaṃ tasyāpi kiṃ bhavet
]

`v 7 [
sarvametatsamāsena punarbodhavivṛddhaye |
siddhaye jñānasārasya vada me vadatāṃvara
]

`v 8 [
śrīvasiṣṭha uvāca |
antarlīnaghanārambhaśubhāśubhamahāṅkuram |
saṃsṛtivrataterbījaṃ śarīraṃ viddhi rāghava
]

`v 9 [
śākhāpratānagahanā phalapallavaśālinī |
teneyaṃ bhavati sphītā śaradīva vasundharā
]

`v 10 [
bhāvābhāvadaśākośaṃ duḥkharatnasamudgakam |
bījamasya śarīrasya cittamāśāvaśānugam
]

`v 11 [
cittādidamudetyuccaiḥ sadasaccāṅgajālakam |
tathā caitatsvayaṃ svapnasaṃbhrameṣvanubhūyate
]

`v 12 [
yathā gandharvasaṃkalpātpuramevaṃ hi cetasaḥ |
savātāyanamākārabhāsuraṃ jāyate vapuḥ
]

`v 13 [
yadidaṃ kiṃcidābhogi jāgataṃ dṛśyatāṃ gatam |
rūpaṃ taccetasaḥ sphāraṃ ghaṭāditvaṃ mṛdo yathā
]

`v 14 [
dve bīje cittavṛkṣasya vṛttivratatidhāriṇaḥ |
ekaṃ prāṇaparispando dvitīyaṃ dṛḍhabhāvanā
]

`v 15 [
yadā praspandate prāṇo nāḍīsaṃsparśnodyataḥ |
tadā saṃvedanamayaṃ cittamāśu prajāyate
]

`v 16 [
yadā na spandate prāṇaḥ śirāsaraṇikoṭare |
asaṃvittivaśāttena cittamantarna jāyate
]

`v 17 [
prāṇaspandanamevedaṃ cittadvāreṇa dṛśyate |
jagannāmāgataṃ vyomni nīlatvādivadīdṛśam
]

`v 18 [
prāṇaspandanasuptā ca tacchāntiḥ śāntirucyate |
prāṇasaṃspandanāsaṃvidyāti vīṭeva coditā
]

`v 19 [
saṃvtsphurati deheṣu prāṇaspandaprabodhitā |
cakrāvartairaṅgaṇeṣu vīṭeva karatāḍitā
]

`v 20 [
satī sarvagatā saṃvitprāṇaspandena bodhyate |
sūkṣmātsūkṣmatarākārā gandhalekheva vāyunā
]

`v 21 [
saṃvitsaṃrodhane śreyaḥ paramaṃ viddhi rāghava |
kāraṇākramaṇaṃ yatra kṣobhastatra na vidyate
]

`v 22 [
saṃvitsamuditaivāśu yāti saṃvedyamādarāt |
saṃvedanādanantāni tato duḥkhāni cetasaḥ
]

`v 23 [
saṃsuptāntarabodhāya saṃvitsaṃtiṣṭhate yadā |
labdhaṃ bhavati labdhavyaṃ tadā tadamalaṃ padam
]

`v 24 [
tasmātprāṇaparispandairvāsanācodanaistathā |
no cetsaṃvidamucchūnāṃ karoṣi tadajo bhavān
]

`v 25 [
saṃviducchūnatāṃ cittaṃ viddhi tenedamātatam |
anarthajālamālūnaviśīrṇajanajīvakam
]

`v 26 [
yoginaścittaśāntyarthaṃ kurvanti prāṇarodhanam |
prāṇāyāmaistathā dhyānaiḥ prayogairyuktikalpitaiḥ
]

`v 27 [
cittopaśāntiphaladaṃ paramaṃ sāmyakāraṇam |
subhagaṃ saṃvidaḥ svāsthyaṃ prāṇasaṃrodhanaṃ viduḥ
]

`v 28 [
jñānavadbhiḥ prakaṭitāmanubhūtāṃ ca rāghava |
cittasyotpattimaparāṃ vāsanājīvitāṃ śṛṇu
]

`v 29 [
dṛḍhabhāvanayā tyaktapūrvāparavicāraṇam |
yadādānaṃ padārthasya vāsanā sā prakīrtitā
]

`v 30 [
bhāvitastīvrasaṃvegādātmanā yattadeva saḥ |
bhavatyāśu mahābāho vigatetarasaṃsmṛtiḥ
]

`v 31 [
tādṛgrūpaḥ sa puruṣo vāsanāvivaśīkṛtaḥ |
yatpaśyati tadetattatsadvastviti vimuhyati
]

`v 32 [
vāsanāvegavaivaśyātsvarūpaṃ prajahāti tat |
bhrāntaṃ paśyati durdṛṣṭiḥ sarvaṃ madavaśādiva
]

`v 33 [
asamyagjñānavāneva bhavatyādhipariplutaḥ |
antasthayā vāsanayā viṣeṇeva vaśīkṛtaḥ
]

`v 34 [
asamyagdarśanaṃ yasmādanātmanyātmabhāvanam |
yadavastuni vastutvaṃ taccittaṃ viddhi rāghava
]

`v 35 [
dṛḍhābhyāsapadārthaikavāsanādaticañcalam |
cittaṃ saṃjāyate janmajarāmaraṇakāraṇam
]

`v 36 [
yadā na vāsyate kiṃciddheyopādeyarūpi yat |
sthīyate sakalaṃ tyaktvā tadā cittaṃ na jāyate
]

`v 37 [
avāsanatvātsatataṃ yadā na manute manaḥ |
amanastā tadodeti paramopaśamapradā
]

`v 38 [
yadā kiṃcinna saṃvittau sphuratyabhramivāmbare |
tadā padma ivākāśe cittamantarna jāyate
]

`v 39 [
yadā na bhāvyate bhāvaḥ kvacijjagati vastuni |
tadā hṛdambare śūnye kathaṃ cittaṃ prajāyate
]

`v 40 [
etāvanmātrakaṃ manye rūpaṃ cittasya rāghava |
yadbhāvanaṃ vastuno'ntarvastutvena rasena ca
]

`v 41 [
na kiṃcitkalpanāyogyaṃ dṛśyaṃ bhāvayatastataḥ |
ākāśakośasvacchasya kutaścittodayo bhavet
]

`v 42 [
yadabhāvanamāsthāya yadabhāvasya bhāvanam |
yadyathāvastudarśitvaṃ tadacittatvamucyate
]

`v 43 [
sarvamantaḥ parityajya śītalāśayavarti yat |
vṛttisthamapi taccittamasadrūpamudāhṛtam
]

`v 44 [
vāsanāyā rasādhyānādrāgo yasya na vidyate |
tasya cittamacittatvaṃ gataṃ sattvaṃ taducyate
]

`v 45 [
ghanā na vāsanā yasya punarjananakāriṇī |
jīvanmuktaḥ sa sattvasthaścakrabhramavadāsthitaḥ
]

`v 46 [
bhṛṣṭabījopamā yeṣāṃ punarjananavarjitā |
vāsanārasanirhīnā jīvanmuktā hi te sthitāḥ
]

`v 47 [
sattvarūpapariprāptacittāste jñānapāragāḥ |
acittā iti kathyante dehānte vyomarūpiṇaḥ
]

`v 48 [
dve bīje rāma cittasya prāṇaspandanavāsane |
ekasmiṃśca tayoḥ kṣīṇe kṣipraṃ dve api naśyataḥ
]

`v 49 [
mithaḥ kāraṇamete hi bīje janmani cetasaḥ |
jalāṅgīkaraṇe rāma jalāśayaghaṭāviva
]

`v 50 [
ghanā na vāsanā yasya punarjananakāriṇī |
bījāṅkuravadete hi saṃsthite tilatailavat
]

`v 51 [
ghanā vāsanā ekaiva āyasya balātkṛtya punarjananakāriṇī netyarthaḥ | bījaṃ
tasyāpi kiṃ bhavediti caturthapraśnasyāpyuttaramanavasthāṃ pariharannāha -
bījāṅkuravaditi | ete prāṇaspandanavāsane tileṣu tailavatparasparānta sthe tathā
bījāṅkuranyāyena kālākāṅkṣikrame parasparasya kāraṇe iti pareṇānvayaḥ | 50
|
avinābhāvinī nityaṃ kālākāṅkṣikrame tathā |
sarvamutpādayatyetaccittakaḥ saṃvidātmakaḥ
]

`v 52 [
yathāprāṇendriyānandamānandapavanāvubhau |
cittasyotpādike sārdhaṃ yadaite vāsane tadā
]

`v 53 [
āmodapuṣpavattailatilavacca vyavasthite |
vāsanāvaśataḥ prāṇaspandastena ca vāsanā
]

`v 54 [
jāyate cittabījasya tena bījāṅkurakramaḥ |
vāanotplavamānatvātsaṃvitprakṣobhakarmaṇā
]

`v 55 [
prāṇaspandaṃ bodhayati tena cittaṃ prajāyate |
prāṇaḥ spandanadharmitvātspandate spṛṣṭahṛdguṇaḥ
]

`v 56 [
saṃvidaṃ bodhayaṃstena cittabālaḥ prajāyate |
evaṃ hi vāsanāprāṇaspandau dvau tasya kāraṇam
]

`v 57 [
tayorekakṣaye nāśo dvayościttasya rāghava |
sukhaduḥkhamanaḥspandaṃ śārīrakabṛhatphalam
]

`v 58 [
kāryapallavitākāraṃ kṛtivratativeṣṭitam |
tṛṣṇākṛṣṇāhivalitaṃ rāgarogabkālayam
]

`v 59 [
ajñānamūlaṃ sudṛḍhaṃ līnendriyavihaṃgamam |
vāsanā kṣayamānītā cittavṛkṣaṃ kṣaṇena hi
]

`v 60 [
prapātayati vātaughaḥ kālapakvaphalaṃ yathā |
pāṇḍurīkṛtasarvāśaṃ sthagitākhiladarśanam
]

`v 61 [
vilolajaladākāramajñānāvakarotthitam |
tṛṣṇātṛṇalavavyāptaṃ stambhākṛti śarīrakam
]

`v 62 [
sphurattanu tanukṣubhdaṃ sukhamutplavanaṃ prati |
antaḥsthitamahālokamapaśyatpravilīyate
]

`v 63 [
pavanaspandarodhācca rāma cittarajaḥ kṣaṇāt |
vāsanāprāṇapavanaspandayoranayordvayoḥ
]

`v 64 [
saṃvedyaṃ bījamityuktaṃ sphuratastau yatastataḥ |
hṛdi saṃvedyamāpyaiva prāṇaspando'tha vāsanā
]

`v 65 [
udeti tasmātsaṃvedyaṃ kathitaṃ bījametayoḥ |
saṃvedyasaṃparityāgātprāṇaspandanavāsane
]

`v 66 [
samūlaṃ naśyataḥ kṣipraṃ mūlacchedādiva drumaḥ |
saṃvidaṃ viddhi saṃvedyaṃ bījaṃ dhīratayā vinā
]

`v 67 [
na saṃbhavati saṃvedyaṃ tailahīnastilo yathā |
na bahirnāntare kiṃcitsaṃvedyaṃ vidyate pṛthak
]

`v 68 [
saṃvitsphurantī saṃkalpātsaṃvedyaṃ paśyati svataḥ |
svapne yathātmamaraṇaṃ tathā deśāntarasthitiḥ
]

`v 69 [
svacamatkārayogena saṃvedyaṃ saṃvidastathā |
svavedanaṃ svasaṃkalpātsaṃvido yatra vartate
]

`v 70 [
jagajjālamato bhāti tadidaṃ raghunandana |
yathā bālasya vetālaḥ svasaṃkalpodbhavādbhavet `note[sasaṅkalpodbhavāt iti
pāṭhaḥ]
]

`v 71 [
puruṣatvaṃ yathā sthāṇoḥ saṃvedyaṃ saṃvidastathā |
yathā candrārkaraśmīnāṃ daṇḍatā reṇutā tathā
]

`v 72 [
yathā nausthācalaspandaḥ saṃvedyaṃ saṃvidastathā |
etanmithyā hi durjñānaṃ samyagjñānādvilīyate
]

`v 73 [
rajjvāmiva bhujaṅgatvaṃ dvīndutvaṃ svīkṣitādiva |
śuddhaiva saṃvittrijagatsaṃvedyaṃ nānyadastyalam
]

`v 74 [
ityantarniścayo rūḍhaḥ samyagjñānaṃ vidurbudhāḥ |
pūrvaṃ dṛṣṭamadṛṣṭaṃ vā yadasyāḥ pratibhāsate
]

`v 75 [
saṃvidastatprayatnena mārjanīyaṃ vijānatā |
tadamārjanamātraṃ hi mahāsaṃsārasaṃgatam
]

`v 76 [
tatpramārjanamātraṃ tu mokṣa ityanubhūyate |
saṃvedanamanantāya duḥkhāya jananātmane
]

`v 77 [
asaṃvittirajāḍyasthā sukhāyājananātmane |
ajaḍo galitānandastyaktasaṃvedano bhava |
asaṃvedyaprabuddhātmā yastu sa tvaṃ raghūdvaha
]

`v 78 [
śrīrāma uvāca |
ajaḍaścāpyasaṃvittiḥ kīḍrśo bhavati prabho |
asaṃvittau ca jāḍyaṃ tatkathaṃ vā vinivartate
]

`v 79 [
śrīvasiṣṭha uvāca |
yaḥ sarvatrānavasthāstho viśrāntāstho na kutracit |
jīvo na vindate kiṃcidasaṃvidajaḍo hi saḥ
]

`v 80 [
saṃvidvastudṛśālambaḥ sa yasyeha na vidyate |
so'saṃvidajaḍaḥ proktaḥ kurvankāryaśatānyapi
]

`v 81 [
saṃvedyena hṛdākāśo manāgapi na lipyate |
yasyāsāvajaḍā saṃvijjīvanmuktaśca kathyate
]

`v 82 [
viśrāntāstho na kutracidityasyāpyatītaviṣaye tātparyamudghāṭayaṃstadevāha ##-
yadā na bhāvyate kiṃcinnirvāsanatayātmani |
bālamūkādivijñānamiva ca sthīyate sthiram
]

`v 83 [
tadā jāḍyavinirmuktamacchavedanamātatam |
āśritaṃ bhavati prājño yasmādbhūyo na lipyate
]

`v 84 [
samastavāsanātyāgī nirvikalpasamādhitaḥ |
nīlatvamiva khātsphāra ānandaḥ saṃpravartate
]

`v 85 [
yoginastatra tiṣṭhanti saṃvedanamasaṃvidaḥ |
tanmayatvādanādyantaṃ tadapyantarvilīyate
]

`v 86 [
gacchaṃstiṣṭhanspṛśañjighrannapi tena sa ucyate |
ajaḍo galitānandastyaktasaṃvedanaḥ sukhī
]

`v 87 [
etāṃ dṛṣṭimavaṣṭabhya kaṣṭayā yatnaceṣṭayā |
tara duḥkhāmbudheḥ pāramapāraguṇasāgara
]

`v 88 [
yathā bījādbṛhadvṛkṣo vyoma vyāpnoti kālataḥ |
tathaivedaṃ svasaṃkalpātsaṃvedyamasadutthitam
]

`v 89 [
yadā saṃkalpya saṃkalpya saṃvitsvaṃ vindate vapuḥ |
tadāsya janmajālasya saiva gacchati bījatām
]

`v 90 [
janayitvātmanātmānaṃ mohayitvā punaḥpunaḥ |
svayaṃ mokṣaṃ nayatyantaḥ saṃvitsvaṃ viddhi rāghava
]

`v 91 [
yadeva bhāvayatyeṣā tadeva bhavati kṣaṇāt |
na bhavadbhūmikāmuktā samāyāti cirādvapuḥ
]

`v 92 [
devo nāsau suro rakṣo yakṣaḥ kiṃ kinnaro janaḥ |
ātmaivādyavilāsinyā jagannāṭyaṃ pranṛtyati
]

`v 93 [
baddhvātmānaṃ ruditvā ca kośakārakṛmiryathā |
cirātkevalatāmeti svayaṃ saṃvitsvabhāvataḥ
]

`v 94 [
jagajjaladhijālānāṃ saṃvijjalamalaṃ gatā |
eṣaivāpūrvadikcakraṃ sphuratyadryāditāṃ gatā
]

`v 95 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
ityasyā vīcayaḥ proktāḥ saṃvitsalilasaṃtateḥ
]

`v 96 [
saṃvinmātraṃ jagatsarvaṃ dvitīyā nāsti kalpanā |
ityeva samyagjñānena saṃvidgacchati nānyatām
]

`v 97 [
yadā na vindate kiṃcitspandate na na vepate |
svātmanyeva sthitiṃ yāti saṃvinno lipyate tadā
]

`v 98 [
athāsyāḥ saṃvido rāma sanmātraṃ bījamucyate |
saṃvinmātrādudetyeṣā prākāśyamiva tejasaḥ
]

`v 99 [
dve rūpe tatra sattāyā ekaṃ nānākṛti sthitam |
dvitīyamekarūpaṃ tu vibhāgo'yaṃ tayoḥ śṛṇu
]

`v 100 [
ghaṭatā paṭatā caiva tvattā matteti kathyate |
sattārūpavibhāgena yattannānākṛti sthitam
]

`v 101 [
vibhāgaṃ tu parityajya sattaikātmatayā tatam |
sāmānyenaiva sattāyā rūpamekamudāhṛtam
]

`v 102 [
viśeṣaṃ saṃparityajya sanmātraṃ yadalepakam |
ekarūpaṃ mahārūpaṃ sattāyāstatpadaṃ viduḥ
]

`v 103 [
rūpaṃ nānākṛtitvena sattāyā na kadācana |
asaṃvedyaṃ saṃbhavati tasmādetadavastukam
]

`v 104 [
ekarūpaṃ tu yadrūpaṃ sattāyā vimalātmakam |
na kadācana tadyāti nāśaṃ nāpi ca vismṛtim
]

`v 105 [
kālasattā kalāsattā vastusatteyamityapi |
vibhāgakalanāṃ tyaktvā sanmātraikaparo bhava
]

`v 106 [
kālasattā svasattā ca pronmuktakalanā satī |
yadyapyuttamasadrūpā tathāpyeṣā na vāstavī
]

`v 107 [
vibhāgakalanā yatra vibhinnapadadāyinī |
nānātākāraṇaṃ dṛṣṭvā tatkathaṃ pāvanaṃ bhavet
]

`v 108 [
sattāsāmānyamevaikaṃ bhāvayatsakalaṃ vapuḥ |
paripūrṇaparānandī tiṣṭhābharitadigbharaḥ
]

`v 109 [
sattā sāmānyamātrasya yā koṭiḥ kovideśvara |
saivāsya bījatāṃ yātā tata eva pravartate
]

`v 110 [
sattāsāmānyaparyante yattatkalanayojjhitam |
padamādyamanādyantaṃ tasya bījaṃ na vidyate
]

`v 111 [
sattā layaṃ yāti yatra nirvikāraṃ ca tiṣṭhati |
bhūyo nāvartate duḥkhe tatra labdhapadaḥ pumān
]

`v 112 [
sattā saddharmatāpi yatra dharmadharmivibhāgavilayāllayaṃ yāti tatra labdhapado yo
bhavati sa eva puruṣārthasādhanasamarthatvātpumān | anyastu strīprāya iti bhāvaḥ |
111 |
taddhetuḥ sarvahetūnāṃ tasya heturna vidyate |
saṃsāraḥ sarvasārāṇāṃ tasmātsāraṃ na vidyate
]

`v 113 [
tasmiṃściddarpaṇe sphāre samastā vastudṛṣṭayaḥ |
imāstāḥ pratibimbanti sarasīva taṭadrumāḥ
]

`v 114 [
sarve bhāvā ime tatra svadante sādhuvāridheḥ `note[atra svāduvāridheḥ iti
ṭīkākṛdabhimataḥ pāṭhaḥ sa eva samīcīnaḥ] |
ṣaḍrasā iva jihvāyāḥ prakaṭatvaṃ prayānti ca
]

`v 115 [
tasmādacchatarasyāpi cidākāśasya vai padam |
sarveṣāṃ svādujātīnāmalamāsvādanaṃ ca tat
]

`v 116 [
jāyate vartate caiva vardhate spṛśyate'tha vā |
tiṣṭhanti ca galantīha tatrāṅga jagatāṃ gaṇāḥ
]

`v 117 [
tattadguru gariṣṭhānāṃ tattallaghu laghīyasām |
tattatsthūlaṃ sthaviṣṭhānāmaṇīyastadaṇīyasām
]

`v 118 [
davīyasāṃ daviṣṭhaṃ tadantikānāṃ tadantikam |
kanīyasāṃ kanīyastattajjyeṣṭhaṃ jyāyasāmapi
]

`v 119 [
tejasāmapi tattejastamasāmapi tattamaḥ |
vastūnāmapi tadvastu diśāmapyaṅga dikparā
]

`v 120 [
tanna kiṃcicca kiṃcicca tattadastīva nāsti ca |
tattadṛśyamadṛśyaṃ ca tattadasmi na cāsmi ca
]

`v 121 [
rāma sarvaprayatnena tasminparamapāvane |
pade sthitimupāyāsi yathā kuru tathānagha
]

`v 122 [
tadamalamajaraṃ tadātmatattvaṃ
tadavagatāvupaśāntimeti cetaḥ |
avagatavitataikatatsvarūpo
bhavabhayamuktapado'si taccirāya
]