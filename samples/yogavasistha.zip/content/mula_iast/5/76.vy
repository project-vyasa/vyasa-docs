`v 1 [
ṣaṭsaptatitamaḥ sargaḥ 76
śrīvasiṣṭha uvāca |
brahmaṇaḥ samupāyānti jagantīmāni rāghava |
sthairyaṃ yāntyavivekena śāmyantyeva vivekataḥ
]

`v 2 [
jagajjālajalāvartavṛttayo brahmavāridhau |
saṃkhyātuṃ kena śakyante bhāsāṃ ca trasareṇavaḥ
]

`v 3 [
asamyakprekṣaṇaṃ viddhi kāraṇaṃ jagataḥ sthitau |
saṃsāraśāntaye kānta kāraṇaṃ samyagīkṣaṇam
]

`v 4 [
ayaṃ hi paraduṣpāro ghoraḥ saṃsārasāgaraḥ |
vinā yuktiprayatnābhyāmasmādrāma na tīryate
]

`v 5 [
yasyāyaṃ sāgaraḥ pūrṇo mohāmbubharapūritaḥ |
agādhamaraṇāvartakallolākulakoṭaraḥ
]

`v 6 [
prabhramatpuṇyaḍiṇḍīro jvalannarakavāḍavaḥ |
tṛṣṇāvilolalaharirmanojalamataṅgajaḥ
]

`v 7 [
ālīnajīvitasaridbhogaratnasamudgakaḥ |
kṣubdharogoragākīrṇa indriyagrāhaghargharaḥ
]

`v 8 [
paśyāsminprasṛtā rāma vīcayaścārucañcalāḥ |
imā mugdhāṅganānāmnyaḥ śikharākarṣaṇakṣamāḥ
]

`v 9 [
chadaśrīpadmarāgāḍhyā netranīlotpalākulāḥ |
dantapuṣpaphalākīrṇāḥ smitaphenopaśobhitāḥ
]

`v 10 [
keśendranīlavalayā bhrūvilāsataraṅgitāḥ |
nitambapulinasphītāḥ kaṇṭhakambuvibhūṣitāḥ
]

`v 11 [
lalāṭamaṇipaṭṭāḍhyā vilāsagrāhasaṃkulāḥ |
kaṭākṣalolagahanā varṇakāñcanavālukāḥ
]

`v 12 [
evaṃ vilolalaharībhīmātsaṃsārasāgarāt |
uttiryate cenmagnena tatparaṃ pauruṣaṃ bhavet
]

`v 13 [
satyāṃ prajñāmahānāvi viveke sati nāvike |
saṃsārasāgarādasmādyo na tīrṇo dhigastu tam
]

`v 14 [
apārāvāramākramya prameyīkṛtya sarvataḥ |
saṃsārābdhiṃ gāhate yaḥ sa eva puruṣaḥ smṛtaḥ
]

`v 15 [
vicāryāryaiḥ sahālokya dhiyā saṃsārasāgaram |
etasmiṃstadanu krīḍā śobhate rāma nānyathā
]

`v 16 [
iha bhavyo bhavānsādho vicāraparayā dhiyā |
tvayādhunaiva tenāyaṃ saṃsāraḥ pravicāryate
]

`v 17 [
bhavāniva vicāryādau saṃsāramatikāntayā |
matyā yo gāhate loko nehāsau parimajjati
]

`v 18 [
pūrvaṃ dhiyā vicāryaite bhogā bhogibhayapradāḥ |
bhoktavyāścaramaṃ rāma garuḍeneva pannagāḥ
]

`v 19 [
vicārya tattvamālokya sevyante yā vibhūtayaḥ |
tā udarkodayā jantoḥ śeṣā duḥkhāya kevalam
]

`v 20 [
balaṃ buddhiśca tejaśca dṛṣṭatattvasya vardhate |
savasantasya vṛkṣasya saundaryādyā guṇā iva
]

`v 21 [
ghanarasāyanapūrṇasuśītayā
vimalayā samayā satataṃ śriyā |
śiśiraraśmirivātivirājase
viditavedya sukhaṃ raghunandana
]