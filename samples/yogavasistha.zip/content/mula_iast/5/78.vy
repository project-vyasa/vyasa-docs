`v 1 [
aṣṭasaptatitamaḥ sargaḥ 78
śrīvasiṣṭha uvāca |
yathālātaparispandādagnicakraṃ pradṛśyate |
asadeva sadābhāsaṃ cittaspandāttathā jagat
]

`v 2 [
yathā jalaparispandādvyatirikta ivāmbhasaḥ |
dṛśyate vartulāvartaścittaspandāttathā jagat
]

`v 3 [
yathā vyomnīkṣaṇaspandātpicchamauktikamaṇḍalam |
dṛśyate sadivāsatyaṃ cittaspandāttathā jagat
]

`v 4 [
śrīrāma uvāca |
yena praspandate cittaṃ yena na spandate tathā |
tadbrahmanbruhi me yena cikitseyaṃ tadeva hi
]

`v 5 [
śrīvasiṣṭha uvāca |
yathā śauklyahime rāma tilatailalavau yathā |
yathā kusumasaugandhye tathauṣṇyadahanau yathā
]

`v 6 [
spandasvabhāvaścittātpṛthakkṛtya vaktumaśakya iti dṛṣṭāntaireva taṃ
darśayati - yathetyādinā | tilaśca tailalavaśca tau | yathāśabdaḥ samuccaye | 5
|
tathā rāghava saṃśliṣṭau cittaspandau tathaiva hi |
abhinnau kevalaṃ mithyā bhedaḥ kalpita etayoḥ
]

`v 7 [
cittacittaparispandapakṣayorekasaṃkṣaye |
svayaṃ guṇaguṇī `note[guṇo guṇī iti yuktam] sthitvā naśyato dvau na
saṃśayaḥ
]

`v 8 [
abhedāṃśa eva kalpitaḥ kiṃ na syādityāśaṅkāṃ pariharanyena na spandate
tatheti praśnāṃśasyottaramāha - citteti | yaḥ svayaṃ kāraṇātmā guṇo guṇī
ceti vikalpitastadātmanā sthitvaiva dvāvapi guṇaguṇivikalpau naśyanto na
niranvayenetyarthaḥ | tathācaikakāraṇātmanā sthitvaiva
guṇaguṇibhedanāśadarśanādbhedāṃśa eva kalpito nābhedāṃśa
ityetanmanaḥspandayorekataranāśādhīnātyantikobhayanivṛtyaiva cittaṃ na
spandate natu jīvati manasi tatspando vārayituṃ śakya ityetacca siddhamiti bhāvaḥ |
7 |
dvau kramau cittanāśasya yogo jñānaṃ ca rāghava |
yogastadvṛttirodho hi jñānaṃ samyagavekṣaṇam
]

`v 9 [
śrīrāma uvāca |
kadā kīdṛkkayā yuktyā prāṇāpānanibandhayā |
yoganāmnyā manaḥ śāntimetyanantasukhapradām
]

`v 10 [
śrīvasiṣṭha uvāca |
dehe'smindehanāḍīṣu vātaḥ sphurati yo'bhitaḥ |
spandeṣviva bhuvo vāri sa prāṇa iti kīrtitaḥ
]

`v 11 [
āsargasamāpterasyaiva praśnasyottaraṃ varṇayiṣyaṃścittaspandasya
prāṇaspandādhīnatāṃ vaktuṃ prathamaṃ prāṇasvarūpamāha -
dehesminnityādinā | dehanāḍīṣu dvāsaptatirdvāsaptatiḥ pratiśākhaṃ
nāḍīsahasrāṇi bhavantyāsu vyānaścarati iti śruterityarthaḥ | yathā bhuvaḥ
spandeṣu spandanamārgabhūteṣu vivareṣu vāri jalaṃ sarvato vyāpya sphurati tadvat |
10 |
tasya spandavaśādantaḥ kriyāvaicitryamīyuṣaḥ |
apānādīni nāmāni kalpitāni kṛtātmabhiḥ
]

`v 12 [
āmodasya yathā puṣpaṃ śauklyasya tu hinaṃ yathā |
tathaiva rasa ādhāraścittasyābhinnatāṃ gataḥ
]

`v 13 [
antaḥprāṇaparispandātsaṃkalpakalanonmukhī |
saṃvitsaṃjāyate yaiṣā taccittaṃ viddhi rāghava
]

`v 14 [
prāṇaspandāccitaḥ spandastatspandādeva saṃvidaḥ |
cakrāvartavidhāyinyo jalaspandādivormayaḥ
]

`v 15 [
citaḥ spandaścidābhāsavyāptavṛttibhedaḥ | saṃvidastattadviṣayākāraprathāḥ |
14 |
cittaṃ prāṇaparispandamāddurāgamabhūṣaṇāḥ |
tasminsaṃrodhite nūnamupaśāntaṃ bhavenmanaḥ
]

`v 16 [
manaḥspandopaśāntyāyaṃ saṃsāraḥ pravilīyate |
sūryālokaparispandaśāntau vyavahṛtiryathā
]

`v 17 [
śrīrāma uvāca |
aniśaṃ caratāṃ dehagehe gaganagāminām |
prāṇādīnāṃ parispando vāyūnāṃ rodhyate katham
]

`v 18 [
śrīvasiṣṭha uvāca |
śāstrasajjanasaṃparkavairāgyābhyāsayogataḥ |
anāsthāyāṃ kṛtāsthāyāṃ pūrvasaṃsāravṛttiṣu
]

`v 19 [
yathābhivāñchitadhyānācciramekatayoditāt |
ekatattvaghanābhyāsātprāṇaspando niruddhyate
]

`v 20 [
pūrakādinijāyāmāddṛḍhābhyāsādasvedajāt |
ekāntadhyānasaṃyogātprāṇaspando niruddhyate
]

`v 21 [
oṃkāroccāraṇaprāntaśabdatattvānubhāvanāt |
suṣupte saṃvido jāte prāṇaspando niruddhyate
]

`v 22 [
recake nūnamabhyaste prāṇe sphāre khamāgate |
na spṛśatyaṅgarandhrāṇi prāṇaspando niruddhyate
]

`v 23 [
pūrake nūnamabhyaste pūrādgirighanasthite |
prāṇe praśāntasaṃcāre prāṇaspando niruddhyate
]

`v 24 [
kumbhake kumbhavatkālamanantaṃ paritiṣṭhati |
abhayasātstambhite prāṇe prāṇaspando niruddhyate
]

`v 25 [
tālumūlagatāṃ yatnājjihvayākramya ghaṇṭikām |
ūrdhvarandhragate prāṇe prāṇaspando niruddhyate
]

`v 26 [
samastakalanonmukte na kiṃcinnāmasūkṣmakhe |
dhyānātsaṃvidi līnāyāṃ prāṇaspando niruddhyate
]

`v 27 [
dvādaśāṅgulaparyante nāsāgre vimalāmbare |
saṃviddṛśi praśāmyantyāṃ prāṇaspando niruddhyate
]

`v 28 [
abhyāsādūrdhvarandhreṇa tālūrdhvaṃ dvādaśāntage |
prāṇe galitasaṃvṛtte prāṇaspando niruddhyate
]

`v 29 [
bhrūmadhye tārakālokaśāntāvantamupāgate |
cetane ketane buddhe prāṇaspando niruddhyate
]

`v 30 [
jhaṭityeva yadudbhūtaṃ jñānaṃ tasmindṛḍhāśrite |
asaṃśliṣṭavikalpāṃśe prāṇaspando niruddhyate
]

`v 31 [
ciraṃ kālaṃ hṛte kāntavyomasaṃvedanānmune |
avāsanānmanodhyānātprāṇaspando niruddhyate
]

`v 32 [
śrīrāma uvāca |
brahman jagati bhūtānāṃ hṛdayaṃ tatkimucyate |
idaṃ sarvaṃ mahādarśe yasmiṃstatpratibimbati
]

`v 33 [
śrīvasiṣtha uvāca |
sādho jagati bhūtānāṃ hṛdayaṃ dvividhaṃ smṛtam |
upādeyaṃ ca heyaṃ ca vibhāgo'yaṃ tayoḥ śṛṇu
]

`v 34 [
iyattayā paricchinne dehe yadvakṣaso'ntaram |
heyaṃ taddhṛdayaṃ viddhi tanāvekataṭe sthitam
]

`v 35 [
saṃvinmātraṃ tu hṛdayamupādeyaṃ sthitaṃ smṛtam |
tadantare ca bāhye ca na ca bāhye na cāntare
]

`v 36 [
tattu pradhānaṃ hṛdayaṃ tatredaṃ samavasthitam |
tadādarśaḥ padārthānāṃ tatkośaḥ sarvasaṃpadām
]

`v 37 [
sarveṣāmeva jantūnāṃ saṃviddhṛdayamucyate |
na dehāvayavaikāṃśo jaḍajīrṇopalopamaḥ
]

`v 38 [
tasmātsaṃvinmaye śuddhe hṛdaye hṛtavāsanaḥ |
balānniyojite citte prāṇaspando nirudhyate
]

`v 39 [
ebhiḥ kramaistathānyaiśca nānāsaṃkalpakalpitaiḥ |
nānādeśikavaktrasthaiḥ prāṇaspando nirudhyate
]

`v 40 [
abhyāsena nirābādhametāstā yogayuktayaḥ |
upāyatāmupāyānti bhavyasya bhavabhedane
]

`v 41 [
abhyāsāddṛḍhatāṃ yāto vairāgyaparilāñchitaḥ |
yathāvāsanamāyāmaḥ prāṇānāṃ saphalaḥ smṛtaḥ
]

`v 42 [
bhrūnāsātālusaṃsthāsu dvādaśāṅgulikoṭiṣu |
abhyāsācchāmyati prāṇo dūre girinadī yathā
]

`v 43 [
bhūyobhūyaścirābhyāsājjihvāprāntena tāluni |
ghaṇṭikā spṛśyate prāṇo yenoccairnivahatyalam
]

`v 44 [
vikalpabahulāstvete svābhyāsena samādhayaḥ |
paramopaśamāyāśu saṃprayāntyavikalpatām
]

`v 45 [
ātmārāmo vītaśoko bhavatyantaḥsukhaḥ pumān |
abhyāsādeva nānyasmāttasmādabhyāsavānbhava
]

`v 46 [
abhyāsena parispande prāṇānāṃ kṣayamāgate |
manaḥ praśamamāyāti nirvāṇamavaśiṣyate
]

`v 47 [
vāsanāvalitaṃ janma mokṣaṃ nirvāsanaṃ manaḥ |
prāṇaṃ ca rāma gṛhṇāti yathecchasi tathā kuru
]

`v 48 [
prāṇaspando manorūpaṃ tasmātsaṃsṛtivibhramaḥ |
tasminneva śamaṃ yāte dīyate saṃsṛtijvaraḥ
]

`v 49 [
vikalpāṃśakṣayājjantoḥ padaṃ tadavaśiṣyate |
yato vāco nivartante samastakalanānvitāḥ
]

`v 50 [
yatra sarvaṃ yataḥ sarvaṃ yatsarvaṃ sarvataśca yat |
yatra nedaṃ yato nedaṃ yannedaṃ nedṛśaṃ jagat
]

`v 51 [
idaṃ dṛśyaṃ yatra netyādheyatayā yato netyupādeyatayā yanneti tādātmyena ca
saccidātmasaṃbandhaniṣedhānna kenāpyaṃśena jagadbrahmasadṛśamityarthaḥ |
50 |
vināśitvādvikalpatvādguṇitvānnirguṇātmanaḥ |
yasya no sadṛśo dṛṣṭo dṛṣṭāntaḥ kaścideva hi
]

`v 52 [
svādanī sarvaśālīnāṃ dīpikā sarvatejasām |
kalanā sarvakāmānāmantaściccandrikoditā
]

`v 53 [
yasmātkalpatarobahvyaḥ saṃsāraphalapaṅktayaḥ |
anārataṃ bahurasā jāyante ca patanti ca
]

`v 54 [
tatpadaṃ sarvasīmāntamavalambya mahāmatiḥ |
yaḥ sthitaḥ sthiradhīstajjñaḥ sa jīvanmukta ucyate
]

`v 55 [
vigatasarvasamīhitakautukaḥ
samupaśāntahitāhitakalpanaḥ |
sakalasaṃvyavahārasamāśayo
bhavati muktamanāḥ puruṣottamaḥ
]