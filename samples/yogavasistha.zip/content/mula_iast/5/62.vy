`v 1 [
dviṣaṣṭitamaḥ sargaḥ 62
śrīvasiṣṭha uvāca |
athaivaṃprāyayā tatra viśrambhakathayā ciram |
prāktanasnehagarbhiṇyā sthitvovācāyudhābhidhaḥ
]

`v 2 [
parigha uvāca |
yadyatsaṃsārajāle'sminkriyate karma bhūmipa |
tatsamāhitacittasya sukhāyānyasya nānagha
]

`v 3 [
kaccitsaṃkalparahitaṃ paraṃ viśramaṇāspadam |
paramopaśamaṃ śreyaḥ samādhimanutiṣṭhasi
]

`v 4 [
suraghuruvāca |
etanme brūhi bhagavansarvasaṃkalpavarjitam |
paramopaśamaṃ śreyaḥ samādhirhi kimucyate
]

`v 5 [
yo jño mahātmansatataṃ tiṣṭhanvyavaharaṃśca vā |
asamāhitacitto'sau kadā bhavati kaḥ kila
]

`v 6 [
nityaṃ prabuddhacittāstu kurvanto'pi jagatkriyāḥ |
ātmaikatattvasaṃniṣṭhāḥ sadaiva susamādhayaḥ
]

`v 7 [
baddhapadmāsanasyāpi kṛtabrahmāñjalerapi |
aviśrāntasvabhāvasya kaḥ samādhiḥ kathaṃ ca vā
]

`v 8 [
tattvāvabodho bhagavansarvāśātṛṇapāvakaḥ |
proktaḥ samādhiśabdena natu tūṣṇīmavasthitiḥ
]

`v 9 [
samāhitā nityatṛptā yathābhūtārthadarśinī |
sādho samādhiśabdena parā prajñocyate budhaiḥ
]

`v 10 [
akṣubdhā nirahaṃkāra dvandveṣvananupātinī |
proktā samādhiśabdena meroḥ sthiratarākṛtiḥ
]

`v 11 [
niścintādhigatābhīṣṭā heyopādeyavarjitā |
proktā samādhiśabdena paripūrṇā manogatiḥ
]

`v 12 [
yataḥprabhṛti bodhena yuktamātyantikaṃ manaḥ |
tadārabhya samādhānamavyucchinnaṃ mahātmanaḥ
]

`v 13 [
nahi prabuddhamanaso bhūtvā vicchidyate punaḥ |
samādhirdūramākṛṣṭo bisatantuḥ śiśoriva
]

`v 14 [
samagraṃ dinamālokādviramatyakṣayo yathā |
ājīvitāntaṃ no prajñā tathā tattvāvalokanāt
]

`v 15 [
ajasramambuvahanādyathā nadyā na ruddhyate |
tathā vijñānadṛgbodhātkṣaṇamātraṃ na ruddhyate
]

`v 16 [
na vismaratyavirataṃ yathā kālaḥ kalāgatim |
na vismaratyavirataṃ svātmānaṃ prājñadhīstathā
]

`v 17 [
na vismarati sarvatra yathā satatago gatim |
na vismarati niśceyaṃ cinmātraṃ prājña dhīstathā
]

`v 18 [
gatiṃ kālakalā yadvaccinvānā samavasthitā |
ciccitiścetyarahitā cinvānā gatayastathā
]

`v 19 [
yathā sattāvihīnātmā padārtho nopalabhyate |
tathātmajñānahīnātmā kālo jñasya na labhyate
]

`v 20 [
na saṃbhavati saṃsāre guṇahīno guṇī yathā |
na saṃbhavatyātmasaṃvidvarjito hyātmavāṃstathā
]

`v 21 [
sarvadaivāsmi saṃbuddhaḥ sarvadaivāsmi nirmalaḥ |
sarvadaivāsmi śāntātmā sarvadāsmi samāhitaḥ
]

`v 22 [
bhedaḥ kena samādherme janyate kathameva vā |
ātmano'vyatirekeṇa nityameva sadātmatā
]

`v 23 [
tasmātkadācidapi me nāsamādhimayaṃ manaḥ |
na vā samāhitaṃ nityamātmatattvaikasaṃbhavāt
]

`v 24 [
sarvagaḥ sarvadaivātmā sarvameva ca sarvathā |
asamādhirhi ko'sau syātsamādhirapi kaḥ smṛtaḥ
]

`v 25 [
nityaṃ samāhitadhiyaḥ susamā mahānta-
stiṣṭhanti kāryapariṇāmavibhāgamuktāḥ |
tenāsamāhitasamāhitabhedabhaṅgyā
nityoditaḥ kva nu sa uttamavākprapañcaḥ
]