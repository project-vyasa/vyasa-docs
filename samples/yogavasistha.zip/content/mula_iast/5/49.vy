`v 1 [
ekonapañcāśaḥ sargaḥ 49
śrīvasiṣṭha uvāca |
atha gādhirgate viṣṇau punarbhūtādikaṃ kramāt |
svayaṃ mohavicārārthaṃ babhrāmābhramivāmbare
]

`v 2 [
upalabhya tathaivātmavṛttāntaṃ janatastataḥ |
harimārādhayāmāsa punaradriguhāṃ gataḥ
]

`v 3 [
ājagāmainamalpena kālenātha janārdanaḥ |
sakṛdārādhanenaiva mādhavo yāti bandhutām
]

`v 4 [
uvāca gādhiṃ bhagavānmayūramiva vāridaḥ |
kiṃ tvaṃ prārthayase bhūyastapaseti prasādavān
]

`v 5 [
gādhiruvāca |
bhrānto'smi deva ṣaṇmāsānbhūtakīrajanāspadam |
tatra vyabhicaratyasmadvṛttānto na kathāsvapi
]

`v 6 [
māyayā bhūtabhūrdṛṣṭā tvayetyukto'smi kiṃ prabho |
mohanāśāya mahatāṃ vaco no mohavṛddhaye
]

`v 7 [
śrībhagavānuvāca |
kākatālīyayogena cetasi śvapacasthitiḥ |
sarveṣāṃ bhūtakīrāṇāṃ taveva pratibimbati
]

`v 8 [
tenāṅga tava vṛttāntaṃ yathāvatkathayanti te |
pratibhāso hi nāyāti punarapratibhāsatām
]

`v 9 [
kenacicchvapacenānte grāmasya racitaṃ gṛham |
tattvayā dṛṣṭamāviṣṭamiṣṭakākhaṇḍatāṃ gatam
]

`v 10 [
kadācitpratibhaikaiva bahūnāmapi jāyate |
kākolatālasthitivadvicitrā hi manogatiḥ
]

`v 11 [
pratibhā bhrāntirūpaḥ pratibhāsa ekā ekarūpaiva | kākolo droṇakākākhyaḥ
kākajātibhedastasya tāle pakvatālaphale tālamūle vā sthitirupaveśanaṃ tadvat | 10
|
tathāhi bahavaḥ svapnamekaṃ paśyanti mānavāḥ |
svāpabhramadamaireyamadamantharacittavat
]

`v 12 [
ekasyāmeva līlāyāṃ ramante bahubālakāḥ |
ekasyāmeva nīlāyāṃ vanasthalyāmivaiṇakāḥ
]

`v 13 [
bahavastulyakālaṃ ca pratibhāsena karmaṇām |
janā yatante svaphalapāke'tibahulākṛtau
]

`v 14 [
pratibandhābhyanujñānāṃ kālo dāteti yā śrutiḥ |
vipra saṃkalpamātro'sau kālo hyātmani tiṣṭhati
]

`v 15 [
yadi mānasakalpanaiva jagattarhi hemantādiḥ kālo vrīhyādyaṅkurodayasya
pratibandhako yavādīnāṃ cābhyanujñāteti lokaprasiddherbādhaḥ
syānmānasakalpanāyāṃ bāhyakālasya vyavasthāpakatvāyogādityāśaṅkāṃ
gādheḥ pariharannāha - pratibandheti | śrutirlaukikapravādaśravaṇam | sā na
virudhyata iti śeṣaḥ | yato'sau pratibandhābhyanujñānaheturapi kālaḥ
saṃkalpamātraḥ | digviśeṣāvacchinnāṃ sūryakriyāṃ dṛṣṭvā manasaiva
yathāśāstraṃ māsartvādibhedakalpanāditi bhāvaḥ | kastarhyakalpitaḥ
kālastamāha - kāla iti | yastvakalpito'khaṇḍaḥ kālaḥ paramātmā sa
svātmanyeva tiṣṭhati na kasyacitpratibandhamabhyanujñāṃ vā dadātītyarthaḥ | 14
|
amūrto bhagavānkālo brahmaiva tamajaṃ viduḥ |
na jahāti na cādatte kiṃcitkasya kadeti ca
]

`v 16 [
laukiko yastvayaṃ kālo varṣakalpayugātmakaḥ |
saṃkalpyate padārthaughaiḥ padārthaughaśca tena tu
]

`v 17 [
samānapratibhāsotthasaṃbhramaṃ bhrāntacetasaḥ |
tathā taṃ dṛṣṭavantaste bhūtakīrajanoccayāḥ
]

`v 18 [
svavyāpāraparo bhūtvā dhiyātmānaṃ vicāraya |
sādho gatamanomohamihaivāsva vrajāmyaham
]

`v 19 [
ityuktvā bhagavānviṣṇurjagāmāntardhimīśvaraḥ |
atiṣṭhatkandare gādhirādhipīvarayā dhiyā
]

`v 20 [
tataḥ katipayeṣvadrau māseṣvatigateṣu saḥ |
punarārādhayāmāsa puṇḍarīkakaraṃ dvijaḥ
]

`v 21 [
dadarśa caikadā nāthamāgataṃ praṇanāma tam |
pūjayāmāsa manasā coktenovāca ceśvaram
]

`v 22 [
gādhiruvāca |
bhagavansaṃsmaraṃścaitāmātmanaḥ śvapacasthitam |
imāṃ saṃsāramāyāṃ ca parimuhyāmi cetasā
]

`v 23 [
taduktvāsva yathāvastu mahāmohanivṛttaye |
ekasminneva vimale māṃ niyojaya karmaṇi
]

`v 24 [
śrībhagavānuvāca |
brahman jagadidaṃ māyāmahāśambaraḍambaram |
sarvā āścaryakalanāḥ saṃbhavantīha vismṛteḥ
]

`v 25 [
bhūtakīrapure mohāddṛṣṭavāṃstattathā bhavān |
ityetatsaṃbhavatyeva dṛśyate hi janairbhramaḥ
]

`v 26 [
bhūtāstvamiva kīrāśca dṛṣṭavantastathā bhramam |
mudhaivetyapi satyābhaṃ samakālādisaṃbhavāt
]

`v 27 [
idaṃ tu śṛṇu vakṣyāmi yathābhūtamaninditam |
yathaiti tanutāṃ cintā mārgaśīrṣalateva te
]

`v 28 [
yo'sau kaṭaṃjako nāma śvapaco bhūtamaṇḍale |
tenaiva saṃniveśena sa tathaivābhavatpurā
]

`v 29 [
* *? va vikalatratvaṃ prāpya deśāntaraṃ gataḥ |
babhūva kīranṛpatiḥ praviveśānalaṃ tataḥ
]

`v 30 [
bhavataḥ kevalaṃ citte jalāntarvartinastadā |
pratibhātā tathābhūtā kaṭaṃjācārasaṃsthitiḥ
]

`v 31 [
draṣṭānubhūtamapyarthaṃ kadācidvismaratyalam |
kadācidapyadṛṣṭaṃ tu cetaḥ paśyati dṛṣṭavat
]

`v 32 [
yathā svapnamanorājyadhātusaṃsthitivibhramāḥ |
jāgratyapi tathaivāṅga dṛśyante manasā svayam
]

`v 33 [
bhaviṣyadbhūtakālasthaṃ yathā traikālyadarśinaḥ |
pratibhāmeti gādhe yatkaṭaṃjācaritaṃ tathā
]

`v 34 [
ayaṃ so'hamidaṃ tanma iti majjati nātmavān |
ayaṃ so'hamidaṃ tanma iti majjatyanātmavān
]

`v 35 [
sarvamevāhameveti tattvajño nāvasīdati |
na gṛhṇāti padārtheṣu vibhāgānarthabhāvanam
]

`v 36 [
tenāsau bhramayogeṣu sukhaduḥkhavilāsiṣu |
na nimajjati magno'pi tumbīpātramivāmbhasi
]

`v 37 [
tvaṃ tāvadvāsanājālagrastacitto vicetanaḥ |
kiṃciccheṣamahāvyādhiriva na svasthamāgataḥ
]

`v 38 [
jñānasyāparipūrṇatvānna śaknoṣi manobhramam |
vinivārayituṃ meghasamyagyatnavāniva
]

`v 39 [
yadeva te manomātre sahasā pratibhāsate |
taruruccajaneneva tenaivākramyase kṣaṇāt
]

`v 40 [
cittaṃ nābhiḥ kilāsyeha māyācakrasya sarvataḥ |
sthīyate cettadākramya tanna kiṃcitprabādhate
]

`v 41 [
tvamuttiṣṭha gireḥ kuñje daśavarṣāṇyakhinnadhīḥ |
tapaḥ kuru tato jñānamanantaṃ samavāpsyasi
]

`v 42 [
ityuktvā puṇḍarīkākṣastatraivāntaradhīyata |
vātābhravaddīpakavadyamunotpīḍavatkṣaṇāt
]

`v 43 [
gādhirvivekavaśajaṃ vairāgyapadamāgataḥ |
śaratsamayaparyante vairasyamiva pādapaḥ
]

`v 44 [
vicitraṃ ceṣṭitaṃ dhāturasamañjasamāgatam |
bhramadbhramabharonmuktamatirmandamagarhayat
]

`v 45 [
jagāma karuṇārdrātmā niyamāyottamaśriye |
viśrāntyai ṛṣyamūkaṃ tu payodhara ivācalam
]

`v 46 [
niyamāya cittaniyamanābhyāsāya | ṛṣamūkaṃ mataṅgāśramasthamacalam | 45
|
nirastāśeṣasaṃkalpastapastatra cakāra ha |
daśavarṣāṇi tenāsāvātmajñānamavāpa ha
]

`v 47 [
aramata tadanu svāṃ prāpya sattāṃ mahātmā
hyapagatabhayaśoko bhogabhūvāvanīṣu |
satatamuditajīvanmuktarūpaḥ praśāntaḥ
sakala iva śaśāṅko bhūrṇitāpūrṇacetāḥ
]