`v 1 [
ekonaṣaṣṭitamaḥ sargaḥ 59
śrīvasiṣṭha uvāca |
ityuktvā bhagavānenaṃ suraghuṃ raghunandana |
yayau svameva ruciraṃ māṇḍavyo maunamaṇḍalam
]

`v 2 [
gate varamunau rājā gatvaikāntamaninditam |
dhiyā saṃcintayāmāsa ko nāmāhamiti svayam
]