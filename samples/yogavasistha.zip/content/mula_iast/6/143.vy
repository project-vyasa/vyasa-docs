`v 1 [
tricatvāriṃśadadhikaśatatamaḥ sargaḥ 143
muniruvāca |
sarveṣāmeva dharmāṇāṃ karmaṇāṃ śarmaṇāmapi |
paṇḍitaḥ puṇḍarīkāṇāṃ mārtaṇḍa iva maṇḍanam
]

`v 2 [
ātmajñānavido yānti yāṃ gatiṃ gatikovidāḥ |
paṇḍitāstatra śakraśrīrjarattṛṇalavāyate
]

`v 3 [
pātāle bhūtale svarge sukhamaiśvaryameva vā |
na tatpaśyāmi yannāma pāṇḍityādatiricyate
]

`v 4 [
paṇḍitasya yathābhūtā vastudṛṣṭiḥ prasīdati |
dṛgivendau nirambhode sakalāmalamaṇḍale
]

`v 5 [
idaṃ dṛśyamavidyātma brahma saṃpadyate kṣaṇāt |
budhasya bodhātsragdāma sarpatvamiva śāmyati
]

`v 6 [
yatsthitaṃ brahmaṇi brahma kṛtāstenaiva satyatā |
svabhāvaikātmikāḥ saṃjñā dehasargakṣayādikāḥ
]

`v 7 [
sargo vidyata evāyaṃ na yatra kila kiṃcana |
tasya dharmāṇi karmāṇi na caivākṣaramālikā
]

`v 8 [
kuta evamiti cetpariśiṣṭabrahmaṇo dṛśyakṣayākhyadharmakarmaśūnyatvādityāha ##-
pṛthvyādi saṃbhavati cettatsakāraṇamastu tat |
tadeva yatra nāstyeva tatra kiṃ tasya kāraṇam
]

`v 9 [
brahmaṇaḥ pratibhātaṃ yattadidaṃ jagaducyate |
tenaiva kuta etāni pṛthvyādīni kva kāraṇam
]

`v 10 [
svapnadraṣṭurdṛśyanṛṇāmasti kālpanikaṃ yathā |
na vāstavaṃ pūrvakāmaṃ jāgratsvapne tathā nṛṇām
]

`v 11 [
yathā prākkarma puṃstve ca svapne puṃsāṃ na vidyate |
iha jāgratsvapnanṛṇāṃ bhātānāmapi no tathā
]

`v 12 [
jīvaḥ sarveṣu sargeṣu svapnārthānnikhilānmithaḥ |
prākkarmasatvaṃ mithyātma yathāvāsanameṣu ca
]

`v 13 [
sargādāvatha dehānte bhānti svapnārthavanmithaḥ |
yathāsaṃvedanaṃ jīvāḥ santo'santaśca tena te
]

`v 14 [
yathāsaṃvedanaṃ sarve bhānti bhāvayatastataḥ |
te santyātmanyapi svapne jāgratīvārthadā mithaḥ
]

`v 15 [
saṃkalpasaṃvidagrasthavastuniṣṭhatayā'sphuṭam |
phalaṃ cāpnoti te svapne lokaniṣṭhatayā'sphuṭaḥ
]

`v 16 [
śuddhā saṃvitsvabhāvasthā yatsvayaṃ bhāti bhāsvarā |
tasyā bhānasya tasyāsya jāgratsvapnābhidhāḥ kṛtāḥ
]

`v 17 [
sargādāvatha dehānte bhātaṃ yadvedanaṃ yathā |
tattathā''mokṣamevāste tadidaṃ sarga ucyate
]

`v 18 [
jāgratsvapnārthasārthasya saṃvidaśca na bhinnatā |
astyapratigharūpāyāḥ prakāśālokayoriva
]

`v 19 [
agnyauṣṇyayoriva tathā vātaspandanayoriva |
dravāmbhasorivā''vīci vā śaityānilayoriva
]

`v 20 [
sarvamapratighaṃ śāntaṃ jagajjātamasanmayam |
itthaṃ sanmayamevāsti nāstyarthena ca saṃyutam
]

`v 21 [
brahma prodbhūya mṛtvā ca dṛśyānubhavarūpi ca |
cinmātramajraṃ śāntamekamevāmalaṃ sthitam
]

`v 22 [
kāryakāraṇatārthānāṃ yā yathā hṛdi kalpitā |
brahmaṇā puruṣeṇeva nagaryantastathaiva sā
]

`v 23 [
brahmaṇo hṛdi sargo'yaṃ hṛdi te svapnapūryathā |
kāryakāraṇatā tatra tathāste'bhihitā yathā
]

`v 24 [
saṃvidghanodare sarge kāryakāraṇatā sthitā |
tathā yathohitā tena tvayā vā kalpanāpuram
]

`v 25 [
citā saṃkalparūpiṇyā sarge saṃkalpapattane |
tvayaiva sthāpitā saṃsthā kāryakāraṇarūpiṇī
]

`v 26 [
ākāśa eva kacanaṃ yaccitte svātmarūpiṇī |
niyataṃ saṃniveśatvāttadantaḥ sarga ucyate
]

`v 27 [
yā saṃvidravyavasthāste hṛdi saṃkalpapattane |
saiṣā svabhāvasaṃsiddhiḥ kāryakāraṇatārthajā
]

`v 28 [
prathamaṃ yadyathā bhāti cittvamasti tatheha tat |
tasyaiva niyatiḥ kālo deśādītyabhidhā kṛtā
]

`v 29 [
yā nāmāśu yathā bhāti cetanākāśaśūnyatā |
tayā tathā vastutayā kāryakāraṇatāśritā
]

`v 30 [
ciccamatkāramātre'sminsargābhe bhāvarūpiṇi |
pūrvaṃ bhāvāḥ pravartante paścātsargābhidhā vidaḥ
]

`v 31 [
yaddhi manasā dhyāyati tadvācā vadati iti śrutermanasi prathamaṃ rūpakalpanā
paścānnāmakalpanetyāha - ciccamatkāreti | bhāvo bhāvanā saṃkalpastadrūpiṇi | 30
|
śūnyatāstrijagadrūpāstathā cidvyomani sthitāḥ |
ananyāḥ pavane saumye spandasatā yathā nijāḥ
]

`v 32 [
vyomni sauṣiryanaibiḍyaṃ yathā nīlamiti sthitam |
citi cetananaibiḍyaṃ tathā sarga upasthitam
]

`v 33 [
ābhāta eva bhāte'sminkṛcchrātsarge visargatā |
budhyate rajjubhujage rajjurūpaṃ yathā punaḥ
]

`v 34 [
mṛtaḥ sa svapnavatsarvaḥ saṃpaśyati pṛthagjagat |
taccānyadidamanyacca nityāpratighamambaram
]

`v 35 [
vyādha uvāca |
parataḥ sukhaduḥkhārtha dehaḥ saṃpadyate katham |
kimasya hetuḥ ke vāsya hetavaḥ sahakāriṇaḥ
]

`v 36 [
etaddehapātātparataḥ anyo dehaḥ kathaṃ saṃpadayte | heturupādānam | hetavo nimittāni |
35 |
kurvanti dharmādharmāścettena pratigharūpiṇā |
tadasyāpratighaṃ rūpaṃ kurvantītyasamañjasam
]

`v 37 [
muniruvāca |
dharmādharmau vāsanā ca karmātmā jīva ityapi |
paryāyaśabdabhāro'tra kalpyate na tu vāstavaḥ
]

`v 38 [
cittvātkalpitacittvena svayaṃ cinnabhasātmani |
kṛtāni nāmānyetāni kaścidastīti cetasā
]

`v 39 [
saṃvidātmā svayaṃ cittvāddehaṃ vetti khameva khe |
mṛtvā santaṃ santamiva saṃkalpasvapnayoriva
]

`v 40 [
svayaṃ svapna ivābhāti mṛtasya paralokadhīḥ |
tameva paśyati ciraṃ na tatrāpyasti satyatā
]

`v 41 [
mṛtaṃ nirmāti cedanyaḥ kathaṃ vāsya smṛtirbhavet |
kathaṃ vā syātsa evāsau cetanatvaṃ tameva kham
]

`v 42 [
mṛtau na jāyate tasmāccetasaiva sa kevalam |
ihāyamitthamityeva vetti khe vāsanātmakam
]

`v 43 [
svameva bhāvamabhyastamāste so'nubhavaṃściram |
sphuṭapratyayavāṃstvatra satyamityeva vettyalam
]

`v 44 [
khātmā khameva tatraiva svapnābhaṃ dṛśyamāharan |
punaḥ svamaraṇaṃ vetti punarjanma punarjagat
]

`v 45 [
alīkajālamevaṃ khe paśyanpratyekamāsthitaḥ |
paśyatyācārayatyatti kiṃcitkaścinna kasyacit
]

`v 46 [
ityevaṃ jagatāṃ santi koṭīnāṃ koṭikoṭayaḥ |
parijñātāstu tā brahma kevalaṃ dṛśyamanyathā
]

`v 47 [
tābhirna kasyacitkiṃcidāvṛtaṃ na ca santi tāḥ |
tāsāṃ ca vetti pratyekamidameva jagattviti
]

`v 48 [
bhūtāni tāsāṃ pratyekaṃ tathaivānyonyamāsthite |
satyānyevāsatyadṛṣṭyā satyadṛṣṭyā tvajaṃ padam
]

`v 49 [
sadyadviditavedyasya tadajñasyāsadakṣayam |
asadyatsaṃprabuddhasya tatsadajñasya susphuṭam
]

`v 50 [
citeryadyadyathā bhānaṃ tattatsatyaṃ yathā yataḥ |
sadrūpāṇi samagrāṇi bhūtānīmānyato mithaḥ
]

`v 51 [
nityamanyonyasatyāni tāni tānyeva vāpyataḥ |
kila saṃvidvinirṇeyaṃ rūpamapratighaṃ yataḥ
]

`v 52 [
saṃvinmātravinirṇeyaṃ kānyatā nānyatā kathā |
yathāsa.vedanaṃ bhāte vastvaughe kva dvitaikate
]

`v 53 [
tadevedamidaṃ jñaptestadevedaṃ bhavatyalam |
tadevaitattadeveti bhavejjñapterasatyataḥ
]

`v 54 [
taccedarthastato jñapternāyaṃ tasyāḥ pṛthak sthitaḥ |
sthite jñaptyātmani tvarthe tvajñaptyāyaṃ tato vrajet
]

`v 55 [
jñānaṃ yadeva tajjñeyaṃ jñeyasyāsaṃbhavātpṛthak |
yathā jñānamato jñeyaṃ tanotyātmānamātmanā
]

`v 56 [
paśyanto'pi milanto'pi pṛthaksargā na kiṃcana |
sata evāsato jñasya mūrkhajñātāṃstu vedmi no
]

`v 57 [
ekaṃ prabodhataḥ sarve cinmātraṃ tāvadātmakham |
tadevānekasaṃvittyā sahasraṃ cijjaḍātmanām
]

`v 58 [
ekaṃ tathā ca cinmātraṃ svapne lakṣātma tiṣṭhati |
punarlakṣātma tatsvapnādekamāste suṣuptake
]

`v 59 [
cidvyomni svapnasaṃvittiryā saiva jagaducyate |
suṣuptaṃ pralayaḥ proktastasmānnyāyo'yameva san
]

`v 60 [
ekaiva saṃvinnānatvaṃ nṛlakṣatvaṃ ca gacchati |
śūnyatvaṃ ca tathārthatvaṃ svapnasaṃkalpayoriva
]

`v 61 [
idamapratighaṃ sarveṃ kila vedanamātrakam |
śuddhaṃ tadvadyathā yatra bhāti tatra tathā bhavet
]

`v 62 [
ekaiva saṃvitsargādau bhavatyagnyambukhādikam |
pṛthvyādi tāvatsargārthaṃ svapnasaṃkalpayoriva
]

`v 63 [
saṃvidākāśarūpaiva bhāti pṛthvyādināmikā |
yattadeva khamevedaṃ jagadityeva bhāsate
]

`v 64 [
saṃvitsapratighaṃ bhāti bhāti cāpratighaṃ tathā |
na vastutastu pratighā saṃvitsānte nivartate
]

`v 65 [
sapratighaṃ naśvaraṃ mūrtamiva apratighaṃ nityamamūrtamiva ca | vastutastu pratighā
nāśa eva nāsti | yataḥ sā pratighāpyante nivartate nivṛttā ca saṃvideva pariśiṣyate | 64
|
yāsi pūrvāṃ paścimāṃ ca diśaṃ vetsi ciraṃ vidan |
pratighaṃ nāma te nāsti na ca sapratighā kvacit
]

`v 66 [
dṛṣṭaṃ saṃkalpitaṃ cārthaṃ sahābhyasyati yaściram |
so'vaśyaṃ tadavāpnoti na cecchānto nivartate
]

`v 67 [
yāsi pūrvāṃ paścimāṃ ca diśaṃ veti ciraṃ vidan |
ya āste yātyasau tattāmanyastyaktvā tu netarām
]

`v 68 [
dṛṣṭaḥ saṃkalpitaścārthaḥ syāmityacalasaṃvidaḥ |
dvayaṃ bhaveddvayaṃ naśyatyanyasyācalasaṃvidaḥ
]

`v 69 [
dakṣiṇāduttarāṃ vāśāṃ yāmītyacalasaṃvidaḥ |
dvayaṃ bhaveddvayaṃ naśyatyanyasyācalasaṃvidaḥ
]

`v 70 [
khe puraṃ syāṃ bhuvi mṛgaḥ syāmityacalasaṃvidaḥ |
dvayaṃ bhaveddvayaṃ naśyatyanyadanyattu tajjagat
]

`v 71 [
ekaṃ prabodhataḥ sarvaṃ cinmātraṃ tāvadātmakham |
tadevānekasaṃvittyā sahasraṃ cijjaḍātmanām
]

`v 72 [
śarīramastvapratighamatha sapratighaṃ ca vā |
svapnātmako'yaṃ saṃsāro jīvasyeha paratra ca
]

`v 73 [
etanmlecchādideśeṣu mṛtānāṃ darśanātpunaḥ |
smṛtipūrvaṃ ca kathanātpratyakṣamanubhūyate
]

`v 74 [
ye mṛtā bhasmasājjātā mlecchadeśeṣu te punaḥ |
āgatya kathayitvārthaṃ gacchantyapratighātmakāḥ
]

`v 75 [
eṣa cejjīvato dharmastaddeśāntarage jane |
mṛta ityeva buddhe'rthe kasmānnaiva pravartate
]

`v 76 [
jīvadharmaḥ so'pi saṃścenmṛtadharmo'pi kiṃ na san |
yādṛganubhavastvasminsame nyāyadvaye sthite
]

`v 77 [
svapnavajjagadābhānamityevaṃ satyakhaṇḍitam |
āryānubhavaśāstrāṇāmanenāstyekavākyatā
]

`v 78 [
dṛṣṭijālaṃ janaughānāṃ paśyatāmindumandire |
yādṛgapratighaṃ tādṛgjagatsadasadātmakam
]

`v 79 [
sanmātramātrānuvidhamacchānubhavamātrakam |
cinmātraṃ bhānamātrātma sarvārthātmārthavarjitam
]

`v 80 [
sarvamapratighaṃ śāntaṃ jagadekaṃ cidambare |
aniṅganamanābhāsamātmanyevātmanāsyatām
]

`v 81 [
acalā samvidevāste sthiraṃ kṛtvā yathā yathā |
tathā tathā bhavatyāśu kimasatkiṃ ca vāpi sat
]

`v 82 [
śarīrāṇyatha karmāṇi duḥkhāni ca sukhāni ca |
yathā sthitānyupāyāntu yāntu vā kasya kiṃ grahaḥ
]

`v 83 [
itthamastu sadathānyathāstu vā maiva bhūdbhavatu ko'tra saṃbhramaḥ |
muñca phalguni phale phalāvahaṃn buddhavānasi kṛtaṃ paribhramaiḥ
]