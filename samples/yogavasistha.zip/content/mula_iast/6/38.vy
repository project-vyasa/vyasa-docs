`v 1 [
iti śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśe nirvāṇaprakaraṇe uttarārdhe
dṛśyopadeśayogo nāma saptatriṃśaḥ sargaḥ  37
aṣṭatriṃśaḥ sargaḥ 38
śrīvasiṣṭha uvāca |
citpaśyati jaganmithyā svavedanavibodhitā |
vyomni māyāñjanāsiktā dṛgivācalatāntaram
]

`v 2 [
brahmasargaścittasargo dvāvetau sadṛśau matau |
paramārthasvarūpatvādakṣubdhatvātsadaiva ca
]

`v 3 [
jñānarūpatayābāhyaṃ bāhyaṃ cānubhavāttathā |
satyarūpamataḥ satyāṃ viddhi bāhyārtharūpatām
]

`v 4 [
bāhyārthavādavijñānavādayoraikyameva naḥ |
vedanātmaikarūpatvātsarvadā sadasaṃsthiteḥ
]

`v 5 [
akṣubdhakhānilālokajalabhūśāntiśālinī |
tatā śūnyā mahārambhā brahmasattaiva sarvataḥ
]

`v 6 [
tasmai sarvaṃ tataḥ sarvaṃ tatsarvaṃ sarvataśca tat |
tacca sarvamayaṃ nityaṃ tasmai sarvātmane namaḥ
]

`v 7 [
cinmayatvādyadā cetyameti draṣṭacitaikatām |
tadā dṛśyāṅgayaivaitaccetyate nānyathā citā
]

`v 8 [
yadā cinmātrameveyaṃ draṣṭṭadarśanadṛśyadṛk |
tadānubhavanaṃ tatra sarvasya phalitaṃ sthitam
]

`v 9 [
draṣṭṭadṛśye na yadyekamabhaviṣyaccidātmake |
taddṛśyāsvādamajñaḥ syānnā dṛṣṭvekṣumivopalaḥ
]

`v 10 [
cinmayatvāccitau cetyaṃ jalamapsviva majjati |
tenānubhūtirbhavati nānyathā kāṣṭhayoriva
]

`v 11 [
sajātīyaikatābhāvādyadvatkāṣṭhaṃ na cetate |
dāru tadvadapi draṣṭā dṛśyaṃ nājñāsyadājaḍam
]

`v 12 [
yādṛksattāni kāṣṭhāni tādṛgrūpaṃ tvacetanam |
jānanti netarattasmāddṛśyaṃ ciddṛśyacetanam
]

`v 13 [
mahācidātmanaivāsti jalāniladharāśmatam |
naiteṣu spandabuddhyādi prāṇajīvādyabhāvataḥ
]

`v 14 [
prāṇabuddhyādayaḥ sattāṃ bhāvanāvaśato gatāḥ |
bhāvanā ciccamatkāraḥ sa yathecchamudeti ca
]

`v 15 [
jagattayā śāntatayā brahmasattāvatiṣṭhate |
puṃstayā gata evātmā retovaṭakabījayoḥ
]

`v 16 [
sarvāgrāṇumaye bīje yo'smādagragato'ṇukaḥ |
sa sa tattadbhavatyagraṃ bījaṃ `note[bījaṃ svātmani saṃsthita iti pāṭhaḥ |] ca
svātmani sthitaḥ
]

`v 17 [
brahma sarvaparāṇvātmā yo yasmādarthato'ṇukaḥ |
sa sa tattadbhavedvastu vastubrahmaiva tiṣṭhati
]

`v 18 [
dravyameva yathā dravyaṃ tiryagūrdhvamadhastathā |
sarvameva tathā brahma yena tena yathā tathā
]

`v 19 [
hematvameva nānyatvaṃ hemarūpaśate yathā |
śāntatvameva śāntasya sargāhaṭvagaṇe tathā
]

`v 20 [
pārśvasthasvapnameghaughā yathā tava na kāścana |
sargapralayasaṃrambhāstathā khātmāna eva me
]

`v 21 [
paṅkatā kalpitā vyomno yā putrakapatākinī |
sā yathā śāntatāmātraṃ khamevedaṃ tathā jagat
]

`v 22 [
saṃkalpabhrama evāntaḥ puṣpībhūya jagatsthitam |
jalāvanitalaklinnabījaṃ kalpa iva drumaḥ
]

`v 23 [
anahaṃtātmano jñasya sata ekatvamāsataḥ |
jarattṛṇalavāyante nanu nāmā'ṇimādayaḥ
]

`v 24 [
trailokye tanna paśyāmi sadevāsuramānuṣam |
ekaromāṃśaviśvasya yallobhāya mahātmanaḥ
]

`v 25 [
yathā tathā sthitasyāpi yatra tatra gatasya ca |
dvaitasaṃkalpasaṃdohā na santyadhigatātmanaḥ
]

`v 26 [
viśvameva nabho yasya śūnyaṃ sarvaṃ mahātmanaḥ |
kutaḥ kasya kathaṃ tasya bhavatvicchā nirātmanaḥ
]

`v 27 [
śāntāśeṣaviśeṣasya nireṣaṇaviśeṣataḥ |
sattāmasattāṃ sadṛśau ka ākalayituṃn kṣamaḥ
]

`v 28 [
mārairna kiṃcinmriyate jīvaiḥ kiṃcinna jīvati |
śuddhasaṃvinmayasyāsya samālokasya khasya ca
]

`v 29 [
mithyā lokasya kacato bhrāntyā maraṇajanmanī |
asatyapi bhrāntibhāji mṛgatṛṣṇānadītaṭe
]

`v 30 [
samyakparīkṣitaṃ yāvanna bhrāntirna parīkṣakāḥ |
na nāma janmamaraṇe kevalaṃ śāntamavyayam
]

`v 31 [
dṛśyādyo viratiṃ yāta ātmārāmaḥ śamaṃ gataḥ |
sa sannevāsadābhāsaḥ paritīrṇabhavārṇavaḥ
]

`v 32 [
dīpanirvāṇanirvāṇamastaṃgatamanogatim |
ātmanyeva śamaṃ yātaṃ santamevāmalaṃ viduḥ
]

`v 33 [
ābuddhyādi jagaddṛśyaṃn yasmai na svadate svataḥ |
ākāśasyeva śāntasya tamāhurmuktamuttamāḥ
]

`v 34 [
ahamastyavicāreṇa vicāreṇāhamasti no |
abhāvādahamarthasya kva jagatkva ca saṃsṛtiḥ
]

`v 35 [
saṃvitsaṃvedanādeva buddhyādyākāravatsthitam |
rūpālokamanorūpaṃ jagadvetti cidambaram
]

`v 36 [
sarvārthariktamanasaḥ sataḥ sarvātmanastava |
sarvathā sarvadā sarvaṃ sarvamācaraṇaṃ śivam
]

`v 37 [
yatkaroṣi yadaśnāsi yajjuhoṣi dadāsi yat |
yattapasyasi haṃsyeṣi tatsarvaṃ śivamavyayam
]

`v 38 [
yadahaṃ yattvamāśā yadyatkriyākālakhādayaḥ |
yallokālokagirayastaccidvyoma śivaṃ tatam
]

`v 39 [
yadrūpālokamananaṃn yatkālatritayaṃ jagat |
yajjarāmaraṇārtyādi tanmahācinnabhaḥ śivam
]

`v 40 [
niścikitso nirābhāso niriccho nirmanā `note[nirmama iti pāṭhaḥ |] muniḥ |
bhūtvā nirātmā nirvāṇastiṣṭha saṃtiṣṭhase yathā
]

`v 41 [
gatecchamananaṃ śāntamanantasthamabhāvanam |
vyavahāro'stute mā vā spandāspandairyathānilaḥ
]

`v 42 [
nirvāsanā niṣkalanā śāntā puruṣatāstu te |
śāstreṇa yantravāhena vāhyā dārumayī yathā
]

`v 43 [
bhūtālokastu māśneho mā vā'snehaśca bāhyagaḥ |
anirdeśadharālokaścitradīpavadāsyatām
]

`v 44 [
nirvāsanasya virasasya nireṣaṇasya śāstrādṛte ka iva tattvavinodahetuḥ |
śāstrārthasajjanamato'pyamalasya tasya saṃvedaneṣvanabhisaṃdhimataḥ svarūpam
]