`v 1 [
caturdaśādhikaśatatamaḥ sargaḥ 114
śrīvasiṣṭha uvāca |
atha teṣāṃ tadā tatra tatastāṃstānadarśayan |
pārśvagā vanavṛkṣābdhiśailameghavanecarān
]

`v 2 [
deva paśyāsya śailasya yeyamabhraṃkaṣāgrabhūḥ |
samarunmadhyadeśāderaśmadeśamupeyuṣaḥ
]

`v 3 [
imā bakulapunnāganālikerakulākulāḥ |
vipināvalayo vāntavividhāmodamārutāḥ
]

`v 4 [
lunātyupatyakāṃ vārdhiḥ śailaśāliśilāvalīḥ |
vanālīrlaharīdātrairāpādaphalapallavāḥ
]

`v 5 [
adhityakāsu meghālīrnṛtyatāṃ svāmbubhūbhṛtām |
dhunoti jaladhirbālo gṛhadhūmāvalīmiva
]

`v 6 [
rākābdhipūrasaṃprotaśaṅkhaśākhāstaṭadrumāḥ |
candrabimbaphalāḥ kalpavṛkṣā iva vibhāntyamī
]

`v 7 [
ratnapuṣpabharāpūrṇaraktapallavapāṇayaḥ |
bhavantaṃ pūjayantīva latādārānvitā drumāḥ
]

`v 8 [
protormimakaragrāsairdṛṣaddantairguhāmukhaiḥ |
ṛkṣavānṛkṣavadbhūbhṛddhatte ghuraghurāravam
]

`v 9 [
mahendro mandragarjābhirabhikṣipati garjataḥ |
parjanyānūrjito janyaḥ pratijanyānyathā jaḍaiḥ
]

`v 10 [
candanārūṣitaḥ śrīmāñjetuṃ jaladhivellanāḥ |
samudyata ivocco'sau mallo malayaparvataḥ
]

`v 11 [
sarvataḥ kacito'jasraṃ ratnavīcibhirambudhiḥ |
bhūratnavalayabhrāntyā prekṣyate sūryamārgagaiḥ
]

`v 12 [
saranti ratnamūrdhānaścalakānilapāyinaḥ `note[calakānileti saṃdhirārṣaḥ |] |
vānapūrāḥ parvatakāḥ sarpā iva natonnataiḥ
]

`v 13 [
bhramanto vīciśṛṅgeṣu makarebhāḥ karotkaṭaiḥ |
haranti sīkarāmbhodā meghānudrāvitā iva
]

`v 14 [
āvartavalitākāraḥ sīkarotkarakīrṇadik |
pūrṇatvāttu śiro'śakto mriyate'tyutkaraḥ karī
]

`v 15 [
vividhaprāṇisaṃpūrṇāḥ sajalādrinatonnatāḥ |
yathaivāmbhodhayaḥ sarvāstathaiva dvīpabhūmayaḥ
]

`v 16 [
āvartānātmano'nanyānapyanyāniva bhāsvarān |
gṛhyamāṇānasadrūpāndṛśyamānānapi sphuṭān
]

`v 17 [
taraṅgataralānantarjaḍānapyambudhiścalān |
dhatte brahmajagantīva sāntānapyantavarjitān
]

`v 18 [
yānantarindravadbhānumaṇīndhatte'mbudhirbahūn |
manthāpahṛtasarvasvo devebhyaḥ parirakṣitān
]

`v 19 [
dṛśyamānānmahātejastathā pātālato'pyalam |
pratibimbavibhaṅgyāntarasatyāniva gopitān
]

`v 20 [
teṣāṃ madhyādekamehaṃ pratyahaṃ paścimārṇave |
nikṣepāya kṣipati yaṃ tena manye dinaṃ bhavet
]

`v 21 [
nānadigdeśapayasāmabdhau sādhusamāgamaḥ |
yātrāyāmiva lokānāṃ mithaḥ kalakalānvitaḥ
]

`v 22 [
jalecarāvarā nūnaṃ sāgarārṇavasaṃgame |
anyonyavellanādyuddhaṃ na kadācana śāmyati
]

`v 23 [
tāmyattimitaraṅgāgranartanāvartavibhramam |
valayanvāyurāyāti vāntasīkaramauktikaiḥ
]

`v 24 [
sarinmuktālatāmadhyamadhyasthābdamaṇīśvarāḥ |
dīrghāḥ khaṇakhaṇāyante cañcalāḥ sarvato'mbudheḥ
]

`v 25 [
mahendrādrerguhāgehaparāvṛttārṇavādhvanām |
bhāṃkāriṇyo bhuvaḥ siddhasādhyānāṃ susukhāvahaḥ
]

`v 26 [
mandaraḥ kandarodgīrṇaiḥ prasarairmātariśvanaḥ |
kampākulavanābhogaḥ puṣpameghāṃstanoti khe
]

`v 27 [
cūtanīpakadambāḍhyagandhamādanakandarān |
viśanti meghahariṇāstaḍittaralalocanāḥ
]

`v 28 [
himavatkandarodgīrṇā vallīvalayatāṇḍavam |
tanvāyā vāyavo yānti vibhinnābdābdhivīcayaḥ
]

`v 29 [
vibhinnā abdāḥ abdhivīcayaścayaiḥ | śaityamāndyasaurabhyopapādakāni viśeṣaṇāni |
28 |
tāta cūtakadambāgraparāmarśasugandhayaḥ |
valayantyabdhikallolāngandhamādanavāyavaḥ
]

`v 30 [
jaladānvalayanvāyuralakālakatāṃ gatān |
ita āyāti puṣpābhraṃ racayanvanavīthiṣu
]

`v 31 [
kundamandārasaṃdohamadhurāmodamantharān |
tuṣārasīkaronmiśrānivātra kalayānilān
]

`v 32 [
nālikeralatālāsyalabdhatiktasugandhayaḥ |
patanti pavanāḥ paśya pārasīkapurīḥ purā
]

`v 33 [
dhunvānāḥ puṣpiteśānavanakarpūravāridān |
cālayanto'nilā vānti kailāsakamalākarān
]

`v 34 [
puṣpitaṃ yadīśānasya pramadavanaṃ tatratyakadalīkarpūrasurabhīnvāridāndhunvānāḥ |
33 |
karīndrakumbhaniṣkrāntamadamantharamūrtayaḥ |
ime śukaśukāyante vindhyakandaravāyavaḥ
]

`v 35 [
śabarīṇāṃ śarīreṣu śīrṇaparṇotkare girau |
nārācaiḥ parṇaśabarairvanālī nagarāyate
]

`v 36 [
abdhyadrisaridambhodavanalekhāṅgikā diśaḥ |
tvatpratāpabalairetā hasantīvārkaraśmibhiḥ
]

`v 37 [
atropaśailavanavīthiṣu puṣpaśayyā vidyādharīviracitāḥ parivarṇayanti |
pārśvadvayasthaparivṛttapadātsamudrādvyāvṛttamugdhavanitāpuruṣāyitāni |
37 |
atrāsminpradeśe upaśailavanavīthiṣu ratyartha vidyādharībhirviracitāḥ puṣpaśayyāḥ
parivarṇayanti sūcayanti | kasmālliṅgātkiṃ sūcayanti tadāha - pārśveti | samudrāt
alaktakamudrāsahitātpārśvadvayasthātparivṛttātsamyaṅniṣpannātpadāliṅgāt | puṃsi
ratiśrānte sati adhodeśādvyāvṛttāyāḥ mugdhavanitāyāḥ upari suratalakṣaṇāni
puruṣāyitāni puruṣavadācaraṇāni sūcayantītyarthaḥ
]