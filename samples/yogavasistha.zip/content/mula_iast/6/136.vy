`v 1 [
ṣaṭtriṃśadadhikaśatatamaḥ sargaḥ 136
bhāsa uvāca |
athāhaṃ taṃ mahādevaṃ pāvakaṃ pṛṣṭavānidam |
śukapakṣatikoṇasthaḥ śrūyatāmavanīśvara
]

`v 2 [
bhagavansarvayajñeśa svāhādhipa hutāśana |
kimidaṃ nāma saṃpannaṃ kathyatāṃ kimidaṃ śavam
]

`v 3 [
vahniruvāca |
śrūyatāmakhilaṃ rājanyathāvadvarṇayāmi te |
trailokyabhāsurānantaśavavṛttāntamakṣatam
]

`v 4 [
astyanantamanākāraṃ paramaṃ vyoma cinmayam |
yatremānyapasaṃkhyāni jaganti paramāṇavaḥ
]

`v 5 [
śuddhacinmātranabhasi tasminsarvagate kvacit |
sarvātmanyudabhūtsaṃvitsaṃvedanamayī svayam
]

`v 6 [
sā tejaḥparamāṇutvamapaśyadvedanāvaśāt |
bhāvitārthātmakatayā svapne tvamiva pānthatām
]

`v 7 [
paramāṇurasaṃvittvādapaśyadaṇutāṃ svayam |
bhāsvatīṃ padmajarajastulyāṃ saṃkalpanātmikām
]

`v 8 [
socchūnatāṃ bhāvayantī punarapyabhavatsvayam |
cakṣurādīnīndriyāṇi vapuṣyanvabhavatsvataḥ
]

`v 9 [
apaśyadagre ca jagaccakṣurādi svabhāvataḥ |
ādhārādheyavadbhūtamayaṃn svapnapuraṃ yathā
]

`v 10 [
asuro nāma tatrāsītprāṇī mānī babhūva ha |
asatyapratibhāsātma pitṛmātṛpitāmahaḥ
]

`v 11 [
darpotsiktayā tatra kasyacitsa mahāmuneḥ |
yadā mṛditavānāsīdāśramaṃ śarmabhājanam
]

`v 12 [
muniḥ śāpamadāttasya mahākāratayāśramaḥ |
tvayā yannāśito mṛtvā bhava tvaṃ maśako'dhamaḥ
]

`v 13 [
sa tacchāpahutāśo'tha tasminneva tadā kṣaṇe |
asuraṃ bhasmasāccakre jalamaurva ivānalaḥ
]

`v 14 [
nirākāraṃ nirādhāramākāśabalayopamam |
cittaṃ kiṃcidivācetyamāsīccetanamāsuram
]

`v 15 [
tadekatvaṃ yayau sāmyādbhūtākāśena cetanam |
tadāspadena tatrātha vāyunā caikatāṃ yayau
]

`v 16 [
āsīccetanavātātmā'bhaviṣyatprāṇināmakaḥ `note[cetanavān ityapi pāṭhaḥ |] |
rajasā payasā vyāptastejasā nabhasāṇunā
]

`v 17 [
sa pañcatanmātramayaścinmātralavako'ṇukaḥ |
spandamāpa svabhāvena vyomni vātalavo yathā
]

`v 18 [
atha tasyānilāntasthaṃ cetanaṃ tadvyabudhyata |
kālānilajalairbhūmau bijamaṅkurakṛdyathā
]

`v 19 [
śuddhaśāpavidantasthā maśakatvavidāsya cit |
vedhitā maśakāṅgāni viditvā maśako'bhavat
]

`v 20 [
svedajasyālpadehasya niḥśvāsanipatattanoḥ |
dve tasya maśakasyeha dine bhavati jīvitam
]

`v 21 [
śrīrāma uvāca |
prāṇināmiha sarveṣāṃ yonyantaraja eva kim |
samudbhavaḥ saṃbhavati kimutānyo'pi vā prabho
]

`v 22 [
śrīvasiṣṭha uvāca |
brahmādīnāṃ tṛṇāntānāṃ dvidhā bhavati saṃbhavaḥ |
eko brahmamayo'nyastu bhrāntijastāvimau śṛṇu
]

`v 23 [
pūrvarūḍhajagadbhrāntibhūtatanmātrarañjanāt |
bhūtānāṃ saṃbhavaḥ prokto bhrāntijo dṛśyasaṅgataḥ
]

`v 24 [
abhātāyāṃ jagadbhrāntau bhūtabhāvaḥ svayaṃ bhavan |
yaḥ sa brahmamayaḥ proktaḥ saṃbhavo na sa yonijaḥ
]

`v 25 [
evaṃ sthite sa maśako jagadbhrāntivaśotthitaḥ |
na tu brahmotthitastasya rāma ceṣṭākramaṃ śṛṇu
]

`v 26 [
sa ca ājānasiddhaiḥ kapilasanakādibhirevānubhūyate nājñairmaśakādibhiriti bhrāntija
eva prakṛto maśakasaṃbhava ityāśayenāha - evamiti | bhāsopakrāntakathāśeṣaṃ
vasiṣṭhaḥ svayamevotsāhācchrāvayati - tasyeti | 25 |
kṣamekṣuśaṣpakakṣādipuñjaguñjeṣu guñjatā |
svāyuṣo'rdhaṃ dinaṃ tena sarvaṃ bhuktaṃ vivalgatā
]

`v 27 [
śādvalodaradolāyāṃ dolanaṃ bālalīlayā |
ciramārabdhametena sārdhaṃ maśikayā svayam
]

`v 28 [
dolāśramārtastatrāsau yāvadviśrāmyati kvacit |
tāvaddhariṇapādāgragiripātena cūrṇitaḥ
]

`v 29 [
hariṇānanasaṃdarśatyaktaprāṇatayā tayā |
pūrvakramagṛhītākṣaḥ sa jāto hariṇastataḥ
]

`v 30 [
viharanhariṇo'raṇye vyādhena dhanuṣā hataḥ |
vyādhānanagadṛṣṭitvātsaṃjāto vyādha eva saḥ
]

`v 31 [
vyādho vaneṣu viharansaṃyāto munikānanam |
tatra viśrāntavānsaṅgānmuninā pratibodhitaḥ
]

`v 32 [
bhrāntaḥ kimidamādīrghaduḥkhāya dhanuṣā mṛgān |
haṃsi pāsi na kasmāttvaṃ tantraṃ jagati bhaṅgure
]

`v 33 [
āyurvāyuvighaṭṭitābhrapaṭalīlambāmbuvadbhaṅguraṃ bhogā
meghavitānamadhyavilasatsaudāmanīcañcalāḥ |
lolā yauvanalālanā jalarayaḥ kāyaḥ kṣaṇāpāyavānputra trāsamupetya
saṃsṛtivaśānnirvāṇamanviṣyatāṃ
]