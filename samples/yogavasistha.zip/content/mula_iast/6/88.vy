`v 1 [
aṣṭāśītitamaḥ sargaḥ 88
śrīvasiṣṭha uvāca |
bhūpīṭhena satā tatra mayā tadanu mānava |
anubhūtaṃ nadanadīsvasaṃvedanasaṃsthiteḥ
]

`v 2 [
kvacinmaraṇasākrandanārīkaruṇavedanam |
kvaciduttāṇḍavastraiṇamahotsavamahāsukham
]

`v 3 [
kvaciddurvāradurbhikṣadurākrandaṃ durīhitam |
kvacitsakalasasyaughasaṃpannaghanasauhṛdam
]

`v 4 [
suvṛṣṭyā phalitaiḥ sakalasasyaughaiḥ subhikṣatvātsaṃpannāni ghanasauhṛdāni yatra |
3 |
kvacidagnimahādāhadagdhadehogravedanam |
kvacijjalaplavālūnapurapattanakhaṇḍakam
]

`v 5 [
kvaciccapalasāmantakṛtaluṇṭhanamaṇḍalam |
kvaciduddāmadaurātmyarakṣaḥpaiśācamaṇḍalam
]

`v 6 [
kvacijjalāśayollāsavellanotpulakāgrakam |
kandarodaraniṣkrāntavātavellitavāridam
]

`v 7 [
saṃvidbodhonnamatsvāṅgakeśotthāṅkuralomakam |
vārivāhanavikṣobhanatonnatalasattalam `note[jalaṃ iti pāṭhaḥ |]
]

`v 8 [
saśṛṅngabhairavaśvabhrapurādrivanapattanam |
saṃvinmaṇḍalasaṃcālalekhāṅkamṛdukampanam
]

`v 9 [
kvacitsāmantasaṃkṣubdhasainyasaṃharaṇaṃ raṇe |
kvacitsaumyasukhāsīnasarvasāmantamaṇḍalam
]

`v 10 [
araṇyaṃ kvacidāśūnyamullasadvātajhaṃkṛti |
jaṃgalaṃ kvacidālūnavyuptasaṃpannasasyakam
]

`v 11 [
haṃsakāraṇḍavākīrṇasaraḥ phullāmbujaṃ kvacit |
kvacinmarusthalasthūlastambhanārjunamārutam
]

`v 12 [
kvacinnadanadīvāhahelānikaṣaghargharam |
kvacidaṅkurakāryāṅgasiktabījasya jṛmbhaṇam
]

`v 13 [
kvacidantastu kīṭāsyamṛduspandanavedanam |
māṃ tvamevāśu buddhveha trāyasvetīva bodhanam
]

`v 14 [
śākhāparikarābhogaṃ mṛdbhāgāṅganipīḍanaiḥ |
mūlajālamavaṣṭabhya kvacidviṭapadhāriṇam
]

`v 15 [
anyonyamalamākramya diktaṭāṅganipīḍanaiḥ |
kvacidadryasthinibiḍairarṇavollāsavellitam
]

`v 16 [
śuṣkapallavasaṃkocanibiḍāṅganipīḍanam |
amarṣaṇaiḥ karairārkaiḥ svarasākarṣaṇaṃ kvacit
]

`v 17 [
śṛṅgamandiramātaṅgaprahārāśanibhūruhām |
nibiḍāṅgotkaṭasthairyaparuṣāpatanaṃ kvacit
]

`v 18 [
nimīlitekṣaṇānandatanūnāmasamākramam |
kvacitsūkṣmatarollekhamaṅkurollāsanaṃ navam
]

`v 19 [
makṣikāyaukamaśakanivāsasadṛśaṃ kvacit |
kuḍyaleśakubhṛṅgārihalahelānikarṣaṇam
]

`v 20 [
śītaṃ śītaviśīrṇāṅgajarjaratvagvikīrṇavat |
pāṣāṇībhūtasalilaṃ kvacitparuṣamārutam
]

`v 21 [
uddālībhūtamṛdvaṅgamajjadantaḥkṛmivrajam |
kvacidudbhavadaṅgādimūlaṃ jalanimajjanam
]

`v 22 [
śanairantarnilīnāmbukṛtāhlādaṃ bahiśca rasonnāmāṅkuraromaughaṃ
`note[bahiścaretyārabhya romāghamityantaṃ samastaṃ padam | (atra bahiśca
raso iti padadvaye evārthasvārasyamiti vayam |)] kvacidvarṣavijṛmbhitam |
22 |
kvacidbījeṣu varṣavijṛmbhitamata eva śanairantarniviṣṭairambubhiḥ kṛtāhlādaṃ tato
bahiśca rasonnāmāṅkuraromaugham
]

`v 23 [
tanutarapavanavikampitakomalanalinīdalāstaraṇaiḥ |
viharaṇamiva me vihitaṃ sarobhiraṅgeṣu nirvāṇam
]