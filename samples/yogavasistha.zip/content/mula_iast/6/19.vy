`v 1 [
ekonaviṃśaḥ sargaḥ 19
śrīrāma uvāca |
mune jīvasya yadrūpamākṛtigrahaṇaṃ tathā |
yathā ca paramātmatvaṃ sthānaṃ yaccāsya tadvada
]

`v 2 [
śrīvasiṣṭha uvāca |
svasaṃkalpena cetyoktaṃ cidityaparanāmakam |
anantaṃ cetanākāśaṃ jīvaśabdena kathyate
]

`v 3 [
tatra samaṣṭijīvaṃ mokṣaśāstraprasiddhaṃ śodhane brahmābhedayogyaṃ prathamaṃ
darśayati - sveti | anantaṃ yaccetanākāśaṃ brahma tadeva hantāhamimāstisro devatā
anena jīvenātmanānupraviśya nāmarūpe vyākaravāṇi iti śrutidarśitasvasaṃkalpena
svacetyasūkṣmabhūtopādhipraveśāttadviṣṭambhakaprāṇadhāraṇāt jīva prāṇadhāraṇe
iti dhātvarthānugamāccetyena prāṇenoktaṃ jīva it vyapadiṣṭam | cakṣurādidvārā
cetayatīti cit cetanaḥ ityaparaṃ nāma yasya tathāvidhaṃ rājjīvaśabdena kathyata ityarthaḥ |
2 |
na parāṇurna ca sthūlaṃ na śūnyaṃ na ca kiṃcana |
cinmātraṃn svānubhūtyātma sarvagaṃ jīva ucyate
]

`v 4 [
aṇīyasāmaṇīyāṃsaṃ sthaviṣṭhaṃ ca sthavīyasām |
na kiṃcinmātrakaṃ caiva sarvaṃ jīvaṃ vidurbudhāḥ
]

`v 5 [
yasya yasya padārthasya yo bhāvastena tatra tam |
sthitaṃ viddhi tadābhāsaṃ tadātmaikāntavedanāt
]

`v 6 [
sa cetati yathā yatra yadyadāśu tadeva hi |
tathā tatra tadā rāma bhavatyanubhavātmakam
]

`v 7 [
pavanasya yathā spandaścetyaṃ jīvasya vai tathā |
svasaṃvinmātranirṇeyaṃ nopadeśāma yakṣavat
]

`v 8 [
yathaivāspandanādvātaḥ sannevaitya sadātmatām |
tathaivācetanājjīvo jīvanneti parāṃ gatim
]

`v 9 [
jīvaścidghanarūpatvādahamityeva cetanāt |
deśakālakriyādravyaśaktīrnirmāya tiṣṭhati
]

`v 10 [
deśakālakriyādravyacarcitācarcitāṃ svayam |
asatyāṃn satyavatsphārāṃ tāvanmātraśarīrikām
]

`v 11 [
cetasā hyasadākārāṃ prāleyaparamāṇutām |
paśyatyātmanyathātmatve svapne svamaraṇopamām
]

`v 12 [
svapnasvāvayavānyatvasadṛśīṃ tāṃ vibhāvayan |
vismṛtya cetanāṃ sattāṃ tattāmevāśu gacchati
]

`v 13 [
evaṃrūpo budhyamānaḥ procchūnatvamathātmani |
paśyatyāśu svamātmānaṃ candrabimbamiva drutam
]

`v 14 [
ātmanyathendubimbātmanyasau saṃvittipañcakam |
kākatālīyavadbhinnamuditaṃ cetati svayam
]

`v 15 [
pañcānāṃ saṃvidāṃ pañca bhinnānyaṅgānyasāvatha |
budhyate tāni tadrūparandhrāṇyanubhavatyapi
]

`v 16 [
sa pañcāvayavaḥ paścādrājate puruṣo virāṭ |
anantākārasaṃvittiravyaktātmā nirāmayaḥ
]

`v 17 [
manomayo'sāvuditaḥ parasmātprathamotthitaḥ |
ākāśaviśadaḥ śānto nityānandavibhāmayaḥ
]

`v 18 [
sa cāpyapañcabhūtātmā pañcabhūtātmakopamaḥ |
virāḍātmaikapuruṣaḥ paramaḥ parameśvaraḥ
]

`v 19 [
svayamevāśu bhavati svayameva vilīyate |
svayameva prasarati svayaṃ saṃkocameti ca
]

`v 20 [
svasaṃkalpakṛtenāsau kalpaughena kṣaṇena ca |
yadṛcchayodeti punaḥ punarbhūtvopaśāmyati
]

`v 21 [
manomātraikarūpātmā prakṛterdeha eṣa saḥ |
eṣa puryaṣṭakaṃ proktaḥ sarvasyaivātivāhikaḥ
]

`v 22 [
sūkṣmaḥ sthūlo'mbarātmaiṣa vyakto'vyaktontavarjitaḥ |
sarvasya bahirantaśca na kiṃcitkiṃcideva ca
]

`v 23 [
aṅgāni rāma tasyāṣṭau manaḥṣaṣṭhāni pañca ca |
sāhaṃbhāvānīndriyāṇi bhāvābhāvamayāni ca
]

`v 24 [
tena gītā ime vedāḥ sahaśabdārthakalpanāḥ |
niyatiḥ sthāpitā tena tathādyāpi yathāsthitā
]

`v 25 [
anantamūrdhvaṃ mūrdhāsya tathādhaḥ pādayostalam |
aparākāśamudaramidaṃ brahmāṇḍamaṇḍapam
]

`v 26 [
ūrdhvaṃ dyaurasya mūrdhā śiraḥ | adhaḥ pṛthivī pādayostalam |
aparamāntarālikamudaram | tasya ha vā etasyātmano vaiśvānarasya mūrdhaiva
sutejāścakṣurviśvarūpaḥ prāṇaḥ pṛthagvartmā saṃdeho bahulo bastireva rayiḥ
pṛthivyeva pādau ityādiśruteriti bhāvaḥ | brahmāṇḍamaṇḍapaṃ śarīramiti śeṣaḥ | 25
|
lokāntarāṇyanantāni pārśvakāḥ kṣatajaṃ payaḥ |
māṃsapeśyaḥ kṣitidharāḥ saritaḥ saṃtatāḥ śirāḥ
]

`v 27 [
raktādhārā jaladhayo dvīpānyevāntraveṣṭanam |
bāhavaḥ kakubhaḥ sphārāstārakā romasaṃtatiḥ
]

`v 28 [
pañcāśadanilaskandhā ekonāḥ prāṇavāyavaḥ |
mārtaṇḍamaṇḍalaṃ caṇḍaṃ pittaṃ jaṭharapāvakaḥ
]

`v 29 [
daśāṅkamaṇḍalaṃ jīvaḥ śleṣmā śukraṃ sitaṃ balam |
manaḥ saṃkalpakośātma sārātmā paramāmṛtam
]

`v 30 [
mūlaṃ śarīravṛkṣasya bījaṃ karmadrumasya ca |
prasavātsarvabhāvānāmindurānandakāraṇam
]

`v 31 [
yadindumaṇḍalaṃ nāma sa samrāṭ jīva ucyate |
śarīrakarmamanasāṃ bījaṃ mūlaṃ ca kāraṇam
]

`v 32 [
asmādinduvirāḍjīvātprasaranti jagattraye |
jīvā manāṃsi karmāṇi sukhānyatrāmṛtāni ca
]

`v 33 [
virāja ete saṃkalpā brahmaviṣṇuharādayaḥ |
tasya cittacamatkārāḥ surāsuranabhaścarāḥ
]

`v 34 [
citsvabhāvo budhyamānaḥ prāleyaparamāṇutām |
yadādau bhāvayatyāśu tadā tatraiva tiṣṭhati
]

`v 35 [
tenaitadeva jīvasya sthānaṃn viddhi raghūdvaha |
pañcāvayavametattaccharīramanubhūyate
]

`v 36 [
virāḍjīvāccandramaso jīvabhūtāni dehinām |
prasarantyannajātāni prāleyavisarātmanā
]

`v 37 [
tānyeva dehideheṣu jīvā jīvanti jīviṣu |
mano bhūtvā viceṣṭante karma janmasu kāraṇam
]

`v 38 [
evaṃ virāṭsahasrāṇi mahākalpaśatāni ca |
gatānyatha bhaviṣyanti nānācārāṇi santi ca
]

`v 39 [
sarvato'nubhavarūpayānayā sattayottamapadādabhinnayā |
antavarjitamahāṅgasaṅgayā tiṣṭhatīti puruṣaḥ paro virāṭ
]