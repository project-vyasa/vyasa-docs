`v 1 [
tryaśītyadhikaśatatamaḥ sargaḥ 183
kundadanta uvāca |
tataḥ pṛṣṭo mayā tatra sa gauryāśramatāpasaḥ |
tāpasaṃśuṣkadarbhāgrajarājarjaramūrdhajaḥ
]

`v 2 [
ekaiva saptadvīpāsti vasudhā yatra tatra te |
saptadvīpeśvarā aṣṭau bhavanti kathamuttamāḥ
]

`v 3 [
yasya jīvasya sadanānnāsti nirgamanaṃ bahiḥ |
sa karoti kathaṃ saptadvīpeśatvena digjayam
]

`v 4 [
yairvarā varadairdattāḥ śāpaiste tadviruddhatām |
kathaṃ gacchanti gacchanti kathaṃ chāyā hi tāpatām
]

`v 5 [
mitho'śakyāṃ kathaṃ dharmau sthitimekatra gacchataḥ |
ādhāra evādheyatvaṃ karoti kathamātmani
]

`v 6 [
gauryāśramatāpasa uvāca |
saṃpaśyasi kimeteṣāṃ bho sādho śṛṇvanantaram |
aṣṭame'sminsusaṃprāpte taṃ pradeśaṃ sabāndhavam
]

`v 7 [
ito bhavantau taṃ deśamāsādya sukhasaṃsthitau |
svabandhusukhasaṃsthānau kaṃcitkālaṃ bhaviṣyataḥ
]

`v 8 [
tataste'ṣṭau mariṣyanti bhrātaraḥ kramaśo gṛhe |
bandhavo'tha kariṣyanti teṣāṃ dehāṃstadagnisāt
]

`v 9 [
teṣāṃ te saṃvidākāśāḥ pṛthakpṛthagavasthitāḥ |
muhūrtamātraṃ sthāsyanti suṣuptasthā jaḍā iva
]

`v 10 [
etasminnantare teṣāṃ tāni karmāṇi dharmataḥ |
ekatra saṃghaṭiṣyanti varaśāpātmakāni khe
]

`v 11 [
karmāṇi tānyadhiṣṭhātṛdevarūpāṇi peṭakam |
varaśāpaśarīrāṇi kariṣyanti pṛthak pṛthak
]

`v 12 [
varāste'tra gamiṣyanti subhagāḥ padmapāṇayaḥ |
brahmadaṇḍāyudhāścandradhavalāṅgāścaturbhujāḥ
]

`v 13 [
śāpāstatra bhaviṣyanti trinetrāḥ śūlapāṇayaḥ |
bhīṣaṇāḥ kṛṣṇamedhābhā dvibhujā bhrukuṭīmukhāḥ
]

`v 14 [
varā vadiṣyanti |
sudūraṃ gamyatāṃ śāpāḥ kālo'smākamupāgataḥ |
ṛtūnāmiva tannāma kaḥ samartho'tivartitum
]

`v 15 [
śāpā vadiṣyanti |
gamyatāṃ he varā dūraṃ kālo'smākamupāgataḥ |
ṛtūnāmiva tannāma kaḥ samartho'tivartitum
]

`v 16 [
varā vadiṣyanti |
kṛtā bhavanto muninā vayaṃ dinakṛtā kṛtāḥ |
munīnāṃ cādhiko devo bhagavantaṃ purā yataḥ
]

`v 17 [
pravadatsu vareṣvevaṃ śāpāḥ kruddhadhiyo varān |
vivasvatā kṛtā yūyaṃ vayaṃ rudrāṃśataḥ kṛtāḥ
]

`v 18 [
devānāmadhiko rudro rudrāṃśaprabhavo muniḥ |
ityuktvā prodyatā teṣāṃ cakruḥ śṛṅgāṇyagā iva
]

`v 19 [
śāpeṣūdyataśṛṅgeṣu varā idamarātiṣu |
vihasantaḥ pravakṣyanti prameyīkṛtaniścayam
]

`v 20 [
he śāpāḥ pāpatāṃ tyaktvā kāryasyānto vicāryatām |
yatkāryaṃ kalahasyānte tadevādau vicāryatām
]

`v 21 [
pitāmahapurīṃ gatvā kalahānte vinirṇayaḥ |
kartavyo'smābhiretatkimādau neha vidhīyate
]

`v 22 [
śāpairvaroktamākarṇya bāḍhamityurarīkṛtam |
ko na gṛhṇāti mūḍho'pi vākyaṃ yuktisamanvitam
]

`v 23 [
tataḥ śāpā varaiḥ sārdhaṃ yāsyanti brahmaṇaḥ param |
mahānubhāvā hi gatiḥ sadā saṃdehanāśane
]

`v 24 [
praṇāmapūrvaṃ tatsarvaṃ yathāvṛttaṃ parasparam |
brahmaṇe kathayiṣyanti śrutvā teṣāṃ sa vakṣyati
]

`v 25 [
brahmovāca `note[pūrvaprakramānurodhenottaratra ca brahmā
vadiṣyatītyapekṣitamiti bhāti |] |
varaśāpādhipā bho bho ye'ntaḥsārā jayanti te |
ke'ntaḥsārā iti mitho nūnamanviṣyatāṃ svayam
]

`v 26 [
śāstrānusāradṛḍhābhyāsobhayakṛtaṃ yadākārasaṃviddārḍhyaṃ
`note[yeṣāmākāradārḍhyam |] ye antaḥsārāste jayanti | anviṣyatāṃ paryālocyatām |
25 |
iti śrutvā praviṣṭāste sāratāṃ samavekṣitum |
varāṇāṃ hṛdayaṃ śāpāḥ śāpānāṃ hṛdayaṃ varāḥ
]

`v 27 [
te parasparamanviṣya svayaṃ hṛdayasāratām |
jñātvā ca samavāyena pravakṣyanti pitāmaham
]

`v 28 [
śāpā vakṣyanti |
jitāḥ prajānātha vayaṃ nāntaḥsārā vayaṃ yataḥ |
antaḥsārā varā eva vajrastambhā ivācalāḥ
]

`v 29 [
vayaṃ kileme bhagavanvarāḥ śāpāśca sarvadā |
nanu saṃvinmayā eva deho'nyo'smākamasti no
]

`v 30 [
varadasya hi yā saṃvidvaro datta iti sthitā |
saivārthini mayā labdho varo'yamiti tiṣṭhati
]

`v 31 [
vijñaptimātrakacanaṃ dehaṃ saiva phalaṃ tataḥ |
paśyatyanubhavatyatti deśakālaśatabhramaiḥ
]

`v 32 [
varasya hi phalaṃ sukhabhogāyatanaṃ dehaṃ tacca vijñaptimātrasya kalanātmakaṃ
kacanam | tataḥ saiva vijñaptirdehākārā bhūtvā
deśakālādikalpanāśatabhramaistattadbhogyārthānpaśyati anubhavati tatrādanīyamatti |
31 |
varadātmā gṛhītatvāccitkālāntarasaṃbhṛtā |
yadā tadāntaḥsārāsau durjayā na tu śāpajā
]

`v 33 [
varapradānaṃ varadairvaradānāṃ varārthibhiḥ |
yadā suciramabhyastaṃ varāṇāṃ sāratā tadā
]

`v 34 [
yadeva suciraṃ saṃvidabhyasyati tadeva sā |
sāramevāśu bhavati bhavatyāśu ca tanmayī
]

`v 35 [
śuddhānāmatiśuddhaiva saṃvijjayati saṃvidām |
aśuddhānāṃ tvaśuddhaiva kālātsāmyaṃ na vidyate
]

`v 36 [
kṣaṇāṃśenāpi yo jyeṣṭho nyāyastenāvapūryate |
nārthe nyāyāntaraṃ kiṃcitkartumutsahate madam
]

`v 37 [
samenobhayakoṭisthaṃ miśraṃ vastu bhavetsamam |
varaśāpavilāsena kṣīramiśraṃ yathā payaḥ
]

`v 38 [
samābhyāṃ varaśāpābhyāmathavā ciddvirūpatām |
svayamevānubhavati svapneṣviva purātmikā
]

`v 39 [
śikṣitaṃ tvatta eveti yattadeva tava prabho |
punaḥ pratīpaṃ paṭhitaṃ śīghraṃ yāmo namo'stu te
]

`v 40 [
ityuktvā sa svayaṃśāpaḥ kvāpi śāpagaṇo yayau |
praśānte timire dṛṣṭe vyomni keśoṇḍrakaṃ yathā
]

`v 41 [
athānyo varapūgo'tra gṛhanirgamarodhakaḥ |
sthānisthānamivādeśaḥ samānārtho'bhyapūrayat
]

`v 42 [
śāpasthānakā vadiṣyanti |
saptadvīpeśajīvānāṃ niryāṇaṃ śavasadmanaḥ |
deveśa vidmo na vayamandhakūpādivāmbhasām
]

`v 43 [
saptadvīpeśvarānetānime dvīpeṣu sadmasu |
kārayanti varā varyā vīrā digvijayaṃ raṇe
]

`v 44 [
tadevamanivārye'sminvirodhe vibudheśvara |
yadanuṣṭheyamasmābhistadādiśa śivāya naḥ
]

`v 45 [
brahmovāca |
saptadvīpeśvaravarā gṛharodhavarāśca he |
kāmaḥ saṃpanna eveha bhavatāṃ bhavatāmapi
]

`v 46 [
vrajataitadapekṣatvaṃ yāvanneṣṭāvapi kṣaṇāt |
ciraṃ cirāya sadane saptadvīpeśvarāḥ sthitāḥ
]

`v 47 [
samanantaramevaite dehapātātsvasadmasu |
saptadvīpeśvarāḥ sarve saṃpannāḥ paramaṃ varāḥ
]

`v 48 [
sarve varā vadiṣyanti |
kuto bhūmaṇḍalānyaṣṭau saptadvīpāni bhūtayaḥ |
ekameveha bhūpīṭhaṃ śrutaṃ dṛṣṭaṃ ca netarat
]

`v 49 [
kathaṃ caitāni tiṣṭhanti kasmiṃścidgṛhakośake |
padmākṣakośake sūkṣme kathaṃ bhānti mataṃgajāḥ
]

`v 50 [
brahmovāca |
yuktaṃ yuṣmābhirasmābhiḥ sarvaṃ vyomātmakaṃ jagat |
sthitaṃ citparamāṇvantarantaḥsvapno'nubhūyate
]

`v 51 [
bhāti yatparamasyāṇorantasthasvagṛhodare |
sphuritaṃ tatkimāścaryaṃ kaḥ smayaḥ prakṛteḥ krame
]

`v 52 [
mṛteranantaraṃ bhāti yathāsthitamidaṃ jagat |
śūnyātmaiva ghanākāraṃ tasminneva kṣaṇe citaḥ
]

`v 53 [
aṇāvapi jaganmāti yatra tatra gṛhodare |
saptadvīpā vasumatī kacatīti kimadbhutam
]

`v 54 [
yadbhātīdaṃ ca cittattvaṃ jagattvaṃ na jagatkvacit |
cinmātrameva tadbhāti śūnyatvena yathāmbaram
]

`v 55 [
iti te brahmaṇā proktā varadena varāstataḥ |
tānādhibhautikabhrāntimayānsaṃtyajya dehakān
]

`v 56 [
praṇamyājaṃ samaṃ jagmurātivāhikadehinaḥ |
saptadvīpe ca devānāṃ gṛhakośānkacajjanān
]

`v 57 [
yāvatte tatra saṃpannāḥ saptadvīpādhināyakāḥ |
aṣṭāvapīṣṭāpuṣṭānāṃ dināṣṭakamahībhujām
]

`v 58 [
te parasparamajñātā ajñāścānyonyabandhavaḥ |
anyonyabhūmaṇḍalagā anyonyābhimate hitāḥ
]

`v 59 [
pratyekaṃ bhrātṛsahitatvakalpanādanyonyabandhavaḥ | rājyabhedena
sarveṣāmādhipatyāṃśe tvajñāḥ | ata evānyonyābhimate hitā na tu viruddhaceṣṭāḥ | 58
|
teṣāṃ kaścidgṛhasyāntareva tāruṇyasundaraḥ |
ujjayinyāṃ mahāpuryāṃ rājadhānyāṃ sukhe sthitaḥ
]

`v 60 [
śākadvīpāspadaḥ kaścinnāgalokajigīṣayā |
vicaratyabdhijaṭhare sarvadigvijayodyataḥ
]

`v 61 [
kuśadvīparājadhānyāṃ nirādhiḥ sakalaprajāḥ |
kṛtadigvijayaḥ kaścitsuptaḥ kāntāvalambitaḥ
]

`v 62 [
śālmalidvīpaśailendraśiraḥpuryāḥ sarovare |
jalalīlārataḥ kaścitsahavidyādharīgaṇaiḥ
]

`v 63 [
krauñcadvīpe hemapure saptadvīpavivardhite |
pravṛtto vājimedhena kaścidyaṣṭuṃ dināṣṭakam
]

`v 64 [
udyataḥ śālmalidvīpe kaściddvīpāntacāriṇā |
yoddhumuddhṛtadigdantidantākṛṣṭakulācalaḥ
]

`v 65 [
gomedadvīpakaḥ kaścitpuṣkaradvīparāṭ sutām |
samānetuṃ vaśādyāti kaṣatseno'ṣṭamo'bhavat
]

`v 66 [
puṣkaradvīpakaḥ kaścillokālokādribhūbhujaḥ |
dūtena saha niryāto dhanabhūmididṛkṣayā
]

`v 67 [
pratyekamitthameteṣāṃ dvīpadvīpādhināthatām |
kurvatāṃ svagṛhākāśe dṛṣṭvā svapratibhocitām
]

`v 68 [
tyaktābhimānikākārā dvividhāste varāstataḥ |
tatsaṃvidbhirgṛheṣvantarekatāṃ khāni khairiva
]

`v 69 [
yāsyanti te bhaviṣyanti saṃprāptābhimatāściram |
saptadvīpeśvarāstuṣṭā nanvaṣtāvapi tuṣṭimat
]

`v 70 [
ityete pravikasitoditakriyārthāḥ prāpsyanti pravitatabuddhayastapobhiḥ |
antaryatsphurati vidastadeva bāhye nāptaṃ kaistaducitakarmabhiḥ kileti
]