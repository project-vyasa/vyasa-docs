`v 1 [
ekādhikaśatatamaḥ sargaḥ 101
śrīvasiṣṭha uvāca |
cinmātrameva puruṣastadevetthamavasthitam |
cinmātravyatirekeṇa kimanyadupapadyate
]

`v 2 [
taccāvadātamākāśaṃ tanmaye draṣṭṭa dṛśyate |
tāvanmātraṃ jagadato heyopādeyadhīḥ kutaḥ
]

`v 3 [
na vidyate paro loko bārhaspatyasya yasya tu |
vido'nyattasya kiṃ sāraṃ rāgadveṣāvataḥ kutaḥ
]

`v 4 [
heyopādeyābhāvena rāgadveṣaprasaktiriti vijñānaikaskandhavādino bauddhasyāpi
saṃmataṃ kiṃtu kṣaṇikavijñānamasāramityeva tanmatamupekṣitavyamityāha - na
vidyata iti | bārhaspatyasya bṛhaspatipraṇītabuddhaśāstrānusāriṇo yasya vādinaḥ
kṣaṇikavijñānātparo'nyo lokyata iti loko jaganna vidyate tasya | ato nirviṣayatvādeva
rāgadveṣau kutaḥ na prasajjete evakiṃtu vidaḥ anyat kiṃ sāraṃ nityaṃ puruṣārtharūpaṃ
yatsaṃbhāvanayā vidaḥ śāśvatatvaṃ sa necchatītyarthaḥ | rajiputrāṇāmasurāṇāṃ ca
vimohanāya bṛhaspatināpi buddhaśāstraṃ praṇītamiti matsyapurāṇādau prasiddham | 3
|
iṣṭāniṣṭadṛśo rāgadveṣadoṣāḥ kimātmakāḥ |
saṃvidyomamaye svapne jagadākhye'ṅga kathyatām
]

`v 5 [
idaṃ heyamupādeyaṃ veti saṃvitkhamātmani |
nirmale nirmalaṃ bhāti kevātra tadataddṛśau
]

`v 6 [
saṃvinnaro'maro nāgaḥ saṃvitsthāvarajaṃgamam |
bhāvābhāvādayo'syābdhestaraṅgāvartavṛttayaḥ
]

`v 7 [
sarvasyāvināśisaṃvinmātratve janmamaraṇādayo'pi na saṃbhāvayituṃ śakyā ityāha ##-
saṃvidākāśamevāhaṃ bhavānapi janā api |
mriyāmahe no kadācitsaṃvitkila kadā mṛtā
]

`v 8 [
saṃvido nāsti saṃvedyaṃ svayaṃ saṃvedyatāmitā |
cittvādato biśālākṣa dvitaikatve kva vā sthite
]

`v 9 [
saṃvinmātrādṛte tasmādbhūtaṃ kimiva kathyatām |
kathyatāṃ mriyate taccettadadyeme kuto vayam
]

`v 10 [
vādinaḥ saugatādyā ye ye lokāyatikādayaḥ |
saṃvidākāśamutsṛjya yanmanyante `note[yanmayante yanmayatve iti pāṭhau |]
taducyatām
]

`v 11 [
saṃvidākāśamevaitatkenacidbrahma kathyate |
kenacitprocyate jñānaṃ kenacicchūnyamucyate
]

`v 12 [
kenacinmadaśaktyābhaṃ kenacitpuruṣābhidham |
kenacicca cidākāśaṃ śiva ātmā ca kenacit
]

`v 13 [
cinmātramevamapyuktaṃ yāti na kvacidanyatām |
yasmātsvayaṃn tadevaivamātmānaṃ vetti netarat
]

`v 14 [
cūrṇatāṃ yāntu me'ṅgāni santu merūpamāni ca |
kā kṣatiḥ kā ca vā vṛddhiścidrūpavapuṣo mama
]

`v 15 [
mṛtāḥ pitāmahādyāścinna mṛtā sā mriyeta cet |
tajjanma naiva nāma syādasmākaṃ mṛtasaṃvidām
]

`v 16 [
na jāyate na mriyate saṃvidākāśamakṣayam |
bhavetkathaṃ kathaya kiṃ kilākāśasya saṃkṣayaḥ
]

`v 17 [
jagadrūpaikakacanamavināśi cidambaram |
udayāstamayonmuktaṃ sthitamātmani kevalam
]

`v 18 [
jagadbhānaṃn dadhaddāhaṃn cinnabhaḥsphaṭikācalaḥ |
anādimadhyaparyantaḥ svaccha ātmani tiṣṭhati
]

`v 19 [
yathā yathāndhakāreṇa prekṣyamāṇaṃ praṇaśyati |
kimapyaṅgābhracakrābhaṃ tathedaṃ viśvamātmani
]

`v 20 [
yathāmbudhiḥ svayaṃ yāti toyādyāvartakādikam |
sthito dadhattathaivedaṃ cidākāśo'ṅgamātmani
]

`v 21 [
cinmātrameva puruṣaḥ khavatsa ca na naśyati |
kadācanāpi tadvyarthaṃ yannaśyāmīti śokitā
]

`v 22 [
dehāddehāntaraprāptau nava eva mahotsavaḥ |
maraṇātmani kiṃ mūḍhā harṣasthāne viṣīdatha
]

`v 23 [
mṛtaścenna bhavedbhūyaḥ so'trāpyupacayo mahān |
bhāvābhāvagrahotsargajvaraḥ praśamamāgataḥ
]

`v 24 [
maraṇaṃ jīvitaṃ tasmānna duḥkhaṃ na sukhaṃ yataḥ |
nāstyevaitaccidākāśaḥ kiletthamabhijṛmbhate
]

`v 25 [
mṛtasya dehalābhaścennava eva tadutsavaḥ |
mṛtirnāśo hi dehasya sā mṛtiḥ paramaṃ sukham
]

`v 26 [
mṛtiratyantanāśaścettadbhavāmayasaṃkṣayaḥ |
bhūyaḥ śarīralābhaścennava eva tadutsavaḥ
]

`v 27 [
kukarmabhyo'tha bhītiścetsā sameha paratra ca |
tāni mā kārṣa bhostasmāllokadvitayasiddhaye
]

`v 28 [
mariṣyāmi mariṣyāmi mariṣyāmīti bhāṣase |
bhaviṣyāmi bhaviṣyāmi bhaviṣyāmīti nekṣase
]

`v 29 [
kva nāma janmamaraṇe kva bhavābhavabhūmayaḥ |
saṃvidātmakamevedaṃ vyoma vyomni vivartate
]

`v 30 [
saṃvidākāśamātrātmā piba bhuṃkṣvāsva nirmamaḥ |
ākāśakośakāntasya kuta icchodayastava
]

`v 31 [
svapravāhabalodyuktadeśakālavaśāditān |
bhāvānbhuṅkte'bhayo bhavyaḥ pāvanānpāvanādapi
]

`v 32 [
madhyamadhyagatāndoṣāndeśakālavaśoditān |
anādṛtyāntarevāste suptadhīravahelayan
]

`v 33 [
na duḥkhameti maraṇātsukhameti na jīvitāt |
nābhivāñchati na dveṣṭi sa tadāste vivāsanaḥ
]

`v 34 [
maraṇajīvitajanmajarattṛṇānyavimṛśanvigatecchamavāsanaḥ |
viditavedya ihājña ivodito vasati vītabhayastvacalo yathā
]