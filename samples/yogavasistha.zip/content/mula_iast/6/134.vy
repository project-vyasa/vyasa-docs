`v 1 [
catustriṃśādhikaśatatamaḥ sargaḥ 134
vipaściduvāca |
etasminnantare vyomnaḥ sa patanpuruṣo mayā |
sthagitākhilabhūpīṭha śavarūpo vilokitaḥ
]

`v 2 [
sa yāvadudarābhikhyo dehabhāgo'sya yena bhūḥ |
saptadvīpāpi pihitā'mātuḥ śailopamo mahān
]

`v 3 [
vahninoktamanantaṃ tattadbhujoruśiraśca me |
lokālokātparaṃ pāraṃ prāptaṃ hyaviṣaye nṛṇām
]

`v 4 [
vyomavāsicaye devīmatha stuvati sādaram |
vyomnaḥ prakaṭatāmāgācchuṣkā nu bhavati svayam
]

`v 5 [
pretavṛndairanugatā mātṛmaṇḍalalālitā |
kumbhāṇḍayakṣavetālajālatārakitāmbarā
]

`v 6 [
śirāladīrghadordaṇḍavanīkṛtanabhastalā |
kirantī kīrṇadigdāhairdṛṣṭipātairdivākarān
]

`v 7 [
sphurannānāyudhākārakacajjhaṇajhaṇadhvani |
śatakhaṇḍaṃ khagānīkaṃ kurvāṇā vyomakoṭare
]

`v 8 [
dehajvālekṣaṇoṣmāḍhyaiḥ śarīrāvayavaistviṣaḥ |
dīrghaveṇuvanākārāḥ kirantī koṭiyojanāḥ
]

`v 9 [
dantakāntīnduvidyotadugdhasnapitadiṅmukhā |
kṛśātidīrghavistīrṇaśarīrāpūritāmbarā
]

`v 10 [
nirālambāspadā sāṃdhyā vitatevābhramālikā |
pretāsanasamārūḍhā surūḍhā parame pade
]

`v 11 [
sphurantī prajvaladrūpā saṃdhyā jaladharāruṇā |
dadhānā gaganāmbhodhau vāḍavajvalanaśriyam
]

`v 12 [
śavaiḥ śavāṅgairmusalaiḥ prāsatomaramudgaraiḥ |
vṛsikolūkhalahalaiḥ kirantī cañcalā srajaḥ
]

`v 13 [
prajāṃ kaṭakaṭāṭopairvahantī gaganāṅgaṇe |
dṛṣadāṃ ghargharārāvaiḥ prāvṛḍgiririvācale
]

`v 14 [
devā ūcurayaṃ devi upahārīkṛto'mbike |
sārdhaṃ svaparivāreṇa śīghramāhriyatāmiti
]

`v 15 [
vadatyevaṃ surānīke taṃ śavaṃ prāṇavāyunā |
devī pravavṛte raktasāramākraṣṭumañjasā
]

`v 16 [
prāṇenākṛṣyamāṇaṃ tadraktaṃ bhagavatīmukhe |
aviśatsāṃdhyameghaugha iva merorguhāntaram
]

`v 17 [
tāvadraktaṃ tayā pītaṃ prāṇākṛṣṭaṃ nabhaḥsthayā |
yāvacchuṣkā satī tṛptā pīnā sā caṃḍikā sthitā
]

`v 18 [
tato babhūva sā raktaparipīnaśarīriṇī |
raktā varṣābhramāleva taḍittaralalocanā
]

`v 19 [
lambodarā bhagavatī viṣamāhivibhūṣaṇā |
raktāsavamadakṣībā samastāyudhadhāriṇī
]

`v 20 [
vyomni nartanamārebhe svaśarīrārdhapūrite |
paryantagirimālāgrasthitāmaranirīkṣitā
]

`v 21 [
tataḥ piśācakumbhāṇḍarūpikādimahāgaṇāḥ |
śavamāvārayāṃcakrurmahācalamivāmbudāḥ
]

`v 22 [
śavaśailo gṛhīto'sau kumbhāṇḍaiḥ kaṭibhāgataḥ |
udarādrūpikāvṛndairyakṣaiḥ kuñjaravikṣataiḥ
]

`v 23 [
bhujorukandharādyāste tasyānye'vayavā yataḥ |
brahmāṇḍasya paraṃ pāraṃ prāptāḥ paramavistṛtāḥ
]

`v 24 [
tatastairbhūtasaṃghātaiḥ sthitā dūre digantare |
na prāptā vai hi tatraiva kālena kalitāḥ svayam
]

`v 25 [
nṛtyantyāṃ caṇḍikāyāṃ khe bhūtavṛnde śavākule |
deveṣvadriṣu tiṣṭhatsu babhūva bhuvanaṃ tadā
]

`v 26 [
piṇḍāhāryāmadurgandhiguṇṭhīkṛtakakubgaṇam |
raktagarbhābhranirvyūhaiḥ khādirajvalanojjvalam
]

`v 27 [
māṃsacarvaṇasaṃrambhaprodyacchavaśavasvanam |
latāsthikhaṇḍanoḍḍīnabṛhatkaṭakaṭāravam
]

`v 28 [
bhūtasaṃghaṭṭaviśleṣavaśādbhīṣaṇaniḥsvanam |
himavadvindhyaśailādripramāṇāsthyacalāvṛtam
]

`v 29 [
devīmukhānalajvālāpakvamāṃsāktabhūtalam |
raktasīkaranīhārasindūritakakubgaṇam
]

`v 30 [
sarvataḥ prekṣakairdevaiḥ saprākāradigantaram |
rudhiraikārṇavībhūtasaptadvīpavasundharam
]

`v 31 [
atyantāntarhitāśeṣasamastācalamaṇḍalam |
raktaprabhābhrasaṃbhāravastrāvṛtadigaṅganam
]

`v 32 [
vṛttālolabhujabhrāntaheticchannanabhastalam |
dūrasmṛtipathaprāptapurapattanamaṇḍalam
]

`v 33 [
atyantāsaṃbhavadrūpasarvasthāvarajaṃgamam |
saṃpannānantakumbhāṇḍarūpikādyekasaṃgamam
]

`v 34 [
nṛttalokakarākārakhagāvalanajālakaiḥ |
mānasūtrairiva vidheranyadracayato jagat
]

`v 35 [
bhūmerārkagataṃ nītaiḥ piśācairāntratantubhiḥ |
mimānamiva dikkuñjaistiryagūrdhvamadho jagat
]

`v 36 [
jagadālokya tattādṛgudaktopaplavāplutam |
bhūtapūrvamahīpīṭhasthitiraktārṇavīkṛtam
]

`v 37 [
dvīpasaptakaparyante lokālokādrimūrdhani |
tadaṅgakairanākrānte sthitāḥ khinnatarāḥ surāḥ
]

`v 38 [
śrīrāma uvāca |
brahmāṇḍādapi nirgatya yasya te'vayavā gatāḥ |
lokālokācalastena brahmanna sthagitaḥ katham
]

`v 39 [
śrīvasiṣṭha uvāca |
dvīpasaptakamadhye'sminrāma tasyodaraṃ sthitam |
śiraḥkhurabhujādyaṅgaṃ brahmāṇḍātparataḥ sthitam
]

`v 40 [
pārśvābhyāmūrumadhyācca kaṭipārśvadvayāttathā |
śiroṃsadvayamadhyābhyāṃ lokālokaḥ sa lakṣyate
]

`v 41 [
tatropaviṣṭāste devā lakṣyante śṛṅgamūrdhasu |
suśuddhakāntayastāpādajalā jaladā iva
]

`v 42 [
prasāritāṅgakamadho vaktraṃ tatpatitaṃ śavam |
saṃabhakṣayati bhūtaughe pranṛtyantīṣu mātṛṣu
]

`v 43 [
vahatsvasṛkpravāheṣu medogandhe vijṛmbhite |
duḥkhitāścintayāmāsuḥ pratyekamamarā idam
]

`v 44 [
hā kaṣṭaṃ kva gatā pṛthvī kva gatā jalarāśayaḥ |
kva gatā janasaṃghātāḥ kva gatā dharaṇīdharāḥ
]

`v 45 [
tādṛkcandanamandārakadambavanamaṇḍitaḥ |
maṇḍapaḥ puṣparāśīnāṃ kaṣṭaṃ kva malayo gataḥ
]

`v 46 [
uccāvadātā vipulā himavadbhūmayo'pi tāḥ |
nītāḥ śauklyaruṣevāśu rudhireṇātmapaṅkatām
]

`v 47 [
krauñcadvīpatale krauñce yo'bhūtkalpadrumo mahān |
brahmalokalasacchākhaḥ so'pi cūrṇatvamāgataḥ
]

`v 48 [
hā kṣīrārṇava pārijātakamalācandrāmṛtānāṃ pate hā dadhyarṇava
nāvanītaśikhariprodbhūtavelāvana |
hā madhvarṇava nālikeragirike yogeśvarīsevita kvedānīṃ samupaiṣyatha kva vanitā
digdarpaṇatvaṃ gatāḥ
]

`v 49 [
pārijātānāṃ kamalāyāścandrasyāmṛtasya cotpādakatvātpate svāmin he kṣīrārṇava |
nāvanītā navanītabharitā ye śikhariṇasteṣu prodbhūtaṃ velāvanaṃ yasya tathāvidha he
dadhyarṇava velāsthe nālikerapradhāne anukampye girau girike yogeśvaryā sevita he
madhvarṇava hā bhavatāṃ pratyekaṃ śocyatā ityarthaḥ | idānīṃ kva samupaiṣyatha
sphaṭikādiratnaśilābhirvanitānāṃ devastrīṇāṃ diśāṃ ca darpaṇatvaṃ kva vā gatāḥ |
48 |
hā kalpadrumakāñcanāmalalatāniḥsaṃdhibandhācala
krauñcadvīpaviriñcahaṃsanalinīnīrandhradigjālaka |
yātaḥ kveha kadambakānanadarīviśrāntavidyādharī
krīḍākovidanāgarāmaragṛha tvaṃ puṣkaradvīpaka
]

`v 50 [
svādūdodagratāpāvalakusumamahīpāvanānāṃ vanānāṃ
gomedhadvīpakalpadrumakanakalatāsundarīṇāṃ darīṇām |
śākadvīpācalānāmamarataruvanairdaṃśitānāṃ sitānāṃ smṛtyaivodeti puṇyaṃ
surapadasukhadaṃ mānavānāṃ navānāṃ
]

`v 51 [
mandānilāvalitapallavabālavallīsaṃtānabhāsitasamastadigantarāṇi |
dhvastāni tāni sakalāni vanāni kaṣṭamāśvāsameṣyati kathaṃ janatā na jāne
]

`v 52 [
kadā nu tānīkṣurasābdhitīre vanāni khaṇḍācalabhūmikāsu |
drakṣyema bhūyo guḍamodakāni tathā kumārāṇyapi śarkarāyāḥ
]

`v 53 [
kadambakalpadrumaśītaleṣu tālītamālīsavanācalasya |
kadā nu taccandanasundarīṇāṃ paśyema nṛttaṃ kanakālayeṣu
]

`v 54 [
gatāni kaṣṭaṃ smaraṇīyarūpatāṃ jambūdrumasyāgraphalāni tānyapi |
yeṣāṃ nadīṃ dvīpasamudramekhalā vahatyasau jambumatī rasāmbubhiḥ
]

`v 55 [
śilīndhranīrandhramahīdhrandhrakṣībāmarastrīkṛtagītanṛtyam |
saṃsmṛtya saṃsmṛtya surodatīraṃ prāgabjamurvīva hṛdāvadīrye
]

`v 56 [
paśyāsṛgambhasi navārṇavamūrdhni bhāsā sauvarṇaparvataśatāgraśikhāḥ
kacanti |
saṃdhyāruṇā udayanāstamayāvanīnāṃ stokoditendukalikā iva diṅmukheṣu
]

`v 57 [
tādṛksāgaravārirāśivalayā dvīpāntarālaṃkṛtā
proccādrīndraniviṣṭavāridaghaṭānīlotpalānāṃ sthalī |
srotojaṅgalakānanogranagaragrāmāgrahārāmbarā no jāne tarupallavāṅkuravatī
kaṣṭaṃ kva yātā mahī
]