`v 1 [
aṣṭāviṃśādhikaśatatamaḥ sargaḥ 128
śrīvasiṣṭha uvāca |
asmādāderjanasyaitatpratyakṣaṃ nānumānikam |
śuddhabodhaśarīreṇa nādhibhautikarūpiṇā
]

`v 2 [
etadasmajjagatsvapne nānyeṣu kathitaṃ mayā |
anyeṣvasti jagatsvapneṣvevamanyāpi ca sthitiḥ
]

`v 3 [
jagatsvapneṣu cānyeṣu saṃsthānakathanena kim |
na hyaupayogikādanyā kathā bhavati dhīmatām
]

`v 4 [
sarveṣāmuttare merurlokālokaśca dakṣiṇe |
yeṣāmityanumā'śeṣabhūthaughe tena paṇḍitāḥ
]

`v 5 [
pratyakṣametadanyeṣāṃ yatra te'nye jagadbhramāḥ |
nāsmākaṃ viṣaye te hi tathā saṃsthānaśobhinaḥ
]

`v 6 [
sarveṣāmuttare merurlokālokaśca dakṣiṇe |
saptadvīpanivāsānāṃ nānyeṣāmiti niścayaḥ
]

`v 7 [
prakṛtaṃ śṛṇu he rāma tadbrahmāṇḍakavāṭakam |
yatpramāṇaṃ tato vāri bāhye daśaguṇaṃ sthitam
]

`v 8 [
tadbrahmāṇḍakavāṭaṃ tu tṛṇaṃ tṛṇamaṇiryathā |
dhatte vāri svabhāvena nityaṃ kalpakaratnavat
]

`v 9 [
sarveṣāmeva bhāvānāṃ sthitaḥ kalpakaratnavat |
sarvadā pārthivo bhāgastenātraite patantyalam
]

`v 10 [
jalāddaśaguṇaṃ bāhye sthitaṃ tejo nirindhanam |
ākāśaviśadaṃ śāntastabdhajvālodaropamam
]

`v 11 [
tasmāddaśaguṇo bāhye saṃsthito vāyurāyataḥ |
vāyordaśaguṇaṃ bāhye vyoma tiṣṭhati nirmalam
]

`v 12 [
tataḥ parataraṃ śāntaṃ brahmākāśamanantakam |
na prakāśaṃ na ca tamo mahācidghanamavyayam
]

`v 13 [
brahmākāśamavidyāśabalabrahmākāśam | cidghanaṃ prajñānaghanaṃ suṣuptikalpam |
12 |
anādimadhyaparyante tasminbrahmamahāmbare |
mahācinnāmni sarvātmanyayonirvāṇarūpiṇi
]

`v 14 [
brahmāṇḍānāṃ tādṛśānāṃ dūre dūre punaḥ punaḥ |
mitholakṣāṇi lakṣāṇi kacantyuparamanti ca
]

`v 15 [
na kiṃcitkacayatyatra same kacanarūpiṇi |
tādṛṅmayaṃ tathārūpaṃ tadātmanyeva saṃsthitam
]

`v 16 [
eṣa te kathitaḥ sarvo dṛśyānubhavanakramaḥ |
adhunā śṛṇu kiṃvṛttaṃ lokāloke vipaścitaḥ
]

`v 17 [
svabhyastapūrvasaṃskāro vilasanniścayeritaḥ |
lokālokagirermūrdhnastamaḥśvabhraṃ papāta saḥ
]

`v 18 [
dadarśa tatra śikharapratimairvihagairvapuḥ |
vikartitaṃ manodehaṃ prasṛtaṃ ca svacintite
]

`v 19 [
tatra ca nijaṃ svaṃ devavapuḥ
parvataśikharapratimairmahattarairvihagairgṛdhrādibhirvikartitaṃ vicchidya bhakṣitaṃ
dadarśa | tadanantaraṃ ca khacintite digantadarśane manodehameva pravṛttaṃ dadarśa |
18 |
deśasya tasya puṇyatvāddehaṃ taccātivāhikam |
ādhibhautikatābodhaṃ nānayannirmalāśayaḥ
]

`v 20 [
tāvanmātraprabodho'sau nādhikaṃ bodhamāgataḥ |
cintayitvā'sitaṃ kāryaṃn babhūva prakṛterhitaḥ
]

`v 21 [
śrīrāma uvāca |
adehaṃ prasaratyetaccittaṃ kārye kathaṃ mune |
ātivāhikasaṃvitterbodhaḥ syātkīdṛśo'dhikaḥ
]

`v 22 [
śrīvasiṣṭha uvāca |
saṃkalpapathikatvena yathāntaḥpuravāsinaḥ |
idaṃ manaḥ prasarati tathāsya prasṛtaṃ manaḥ
]

`v 23 [
bhrame svapne manorājye mithyājñāne kathāśrutau |
yathā manaḥ prasarati tathā tatprasṛtaṃ manaḥ
]

`v 24 [
patanti tu śarīraṃ tadātivāhikamucyate |
ādhibhautikadhīrbhāti vismṛtyātraiva kālataḥ
]

`v 25 [
ate tadāntardhimāyāte sarparajjubhramopame |
ādhibhautikadehe'smiñchiṣyate tvātivāhikaḥ
]

`v 26 [
ātivāhika eṣo'ṅga nipuṇaṃ pravicāryatām |
cinmātravyatirekeṇa yāvadatrānyadasti no
]

`v 27 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
cinmātrasyāsya tadrūpamanantasyaikarūpiṇaḥ
]

`v 28 [
nirviṣayacinmātrā prasiddhistu prāgbahuśo vāritaivetyāśayena prāgbahuśaḥ
paṭhitameva ślokārdha punaḥ paṭhati - deśāditi | tadrūpaṃ prasiddhameveti śeṣaḥ |
27 |
kva dvaitaṃ kva ca vā dveṣaḥ kva rāgādi tu kathyatām |
sarvaṃ śivamanādyantaṃ paro bodha iti smṛtaḥ
]

`v 29 [
nirmanomananaṃ śāntamāsitaṃ bodha uttamaḥ |
ātivāhikadehastho na taṃ bodhamupāgataḥ
]

`v 30 [
vipaścittadvibodho'sau dadarśa visaranmanaḥ |
ātivāhikabodhena garbhavāsopamaṃ tamaḥ
]

`v 31 [
tamaso'nte viriñcāṇḍakavāṭacchedabhūtalam |
vajrasāraṃ hemamayaṃ koṭiyojanavistṛtam
]

`v 32 [
tadante prāpa salilaṃ tasmādaṣṭaguṇaṃ tataḥ |
kapāṭabhūmyaiva samaṃ sthitamarṇavapṛṣṭhavat
]

`v 33 [
tamatītya tataḥ prāpa tejo'rkagaṇabhīṣaṇam |
pralayāgnighanajvālāpiṇḍakoṭarabhāsvaram
]

`v 34 [
dāhaśokādimuktena vapuṣā mānasena tat |
tatra gacchansa bubudhe vahanaṃ pūrvavāsitam
]

`v 35 [
uhyamāno vivedāsāvātmānaṃ tvātivāhikam |
cittamātrātmanaḥ svasya kimivohyata ityapi
]

`v 36 [
iti bodhena dhīrātmā taṃ tatārā'nilārṇavam |
prāpa tadvitataṃ vyoma tasmāddaśaguṇaṃ sthitam
]

`v 37 [
tadatikramya sa prāpa brahmākāśamanantakam |
yatra sarvaṃ yataḥ sarvaṃ yanna kiṃcicca kiṃcana
]

`v 38 [
manasā prabhramaṃstatra dūrāddūrataraṃ yayau |
tena dṛṣṭaṃ ca pṛthvyāpastejo vāyustathā jagat
]

`v 39 [
punaḥ saṃsāraracanāḥ punaḥ sargāḥ punardiśaḥ |
punarmahīdharā vyoma punardevāḥ punarnarāḥ
]

`v 40 [
punaḥ pañcamahābhūtaparyante brahma nirghanam |
punastatra jagantyuccaiḥ punaḥ sargāḥ punardiśaḥ
]

`v 41 [
brahmākāśastataḥ sargāḥ punaranye tvaniṣṭhitāḥ |
ityasau viharandīrghakālamadyāpi saṃsthitaḥ
]

`v 42 [
svaniścayāccirābhyastānnāsau viratimeti hi |
anto naivāstyavidyāyāḥ sā hi brahmaiva satyatā
]

`v 43 [
niścayājjagatsatyatāniścayāt | satyatā satyasvabhāvaḥ paryālocitaścetsā brahmaiva | 42
|
vastuto nāstyavidyeha brahmaṇyavikalātmani |
idaṃ dṛśyamavidyeyamityātmaiṣa vikāsitaḥ
]

`v 44 [
yadyathā jāgrati svapne dṛṣṭaṃ drakṣyasi paśyasi |
tattathā brahma sacchāntamāsīdasti bhaviṣyati
]

`v 45 [
vanatamaḥpravilokanacakrakaṃ kramajagatpratibhānamidaṃ mahat |
paratayā pratibhātmatayānayā na ca sadaṅga na vāpyasadākṛti
]

`v 46 [
teṣveva teṣviva ca teṣu tanūtareṣu brahmodareṣu ciradūrataraṃ jagatsu |
so'dyāpyasaṃviditatattvatayā tayoccaiḥ khaṇḍeṣu raṅkuriva rāghava baṃbhramīti |
46 |
he rāghava sa vipaścit adyāpi asaṃviditatattvatayā teṣu pūrvadṛṣṭeṣveva teṣviva
tatsadṛśeṣvanyeṣu ca vāsanāmātratvāttanūtareṣu brahmaṇāṃ virājāmudareṣu
prasiddheṣu jagatsu vanakhaṇḍeṣu raṅkurmṛgaviśeṣa iva uccaiḥ svavāsanaunnatyena
baṃbhramīti punaḥpunarbhramati | bhrameryaṅluki abhyāsasya nuk
]