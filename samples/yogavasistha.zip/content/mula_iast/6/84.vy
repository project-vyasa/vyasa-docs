`v 1 [
caturaśītitamaḥ sargaḥ 84
śrīrāma uvāca |
anantaraṃ mune brūhi kālī kimiva nṛtyati |
kiṃ śūrpaphalakuddālamusalādisrajā''vṛtā
]

`v 2 [
śrīvasiṣṭha uvāca |
sa bhairavaścidākāśaḥ śiva ityabhidhīyate |
ananyāṃ tasya tāṃ viddhi spandaśaktiṃ manomayīm
]

`v 3 [
yathaikaṃ pavanaspandamekamauṣṇyānalau yathā |
cinmātraṃ spandaśaktiśca tathaivaikātma sarvadā
]

`v 4 [
spandena lakṣyate vāyurvahnirauṣṇyena lakṣyate |
cinmātramamalaṃ śāntaṃ śiva ityabhidhīyate
]

`v 5 [
tatspandamāyāśaktyaiva lakṣyate nānyathā kila |
śivaṃ brahma viduḥ śāntamavācyaṃ vāgvidāmapi
]

`v 6 [
spandaśaktistadicchedaṃ dṛśyābhāsaṃ tanoti sā |
sākārasya narasyecchā yathā vai kalpanāpuram
]

`v 7 [
karotyeva śivasyecchā karotīdamanākṛteḥ |
saiṣā citiriti proktā jīvanājjīvitaiṣiṇām `note[asyāgre - cetyonmukhatayoditā |
saiṣoktā vāsanānāmnī vāsanā dṛśyasaṃvidaḥ | saiṣā jīvakalā proktā ityapi
kvaciddṛśyate |]
]

`v 8 [
prakṛtitvena sargasya svayaṃ prakṛtitāṃ gatā |
dṛśyābhāsānubhūtānāṃ karaṇātsocyate kriyā
]

`v 9 [
vaḍavāgniśikhākārācchoṣyācchuṣketi kathyate |
caṇḍitvāccaṇḍikā proktā sotpalotpalavarṇataḥ
]

`v 10 [
jayā jayaikaniṣṭhatvātsiddhā siddhisamāśrayāt |
jayantī ca jayā proktā vijayā vijayāśrayāt
]

`v 11 [
proktā parājitā vīryāddurgā durgraharūpataḥ |
oṃkārasāraśaktitvādumeti parikīrtitā
]

`v 12 [
umeti parikīrtitā oṃkāraghaṭakānāmakārokāramakārāṇāṃ u ma a iti vyatyāsena
ghaṭane ṭāpi umāśabdaniṣpatteriti bhāvaḥ | sameti parikīrtiteti pāṭhe tu
oṃkāralakṣyaturīyasvarūpasthūlasūkṣmādisarvaprapañcasāracicchaktitvāt##-
gāyatrī gāyanātmatvātsāvitrī prasavasthiteḥ |
saraṇātsarvadṛṣṭīnāṃ kathitaiṣā sarasvatī
]

`v 13 [
gaurī gaurāṅgadehatvādbhavadehānuṣaṅgiṇī |
suptānāmatha buddhānāmamātroccāraṇāddhṛdi
]

`v 14 [
nityaṃ trailokyabhūtānāmumetīndukalocyate |
śivayorvyomarūpatvādasitaṃ lakṣyate vapuḥ
]

`v 15 [
nabho hi māṃsametābhyāṃ dṛṣṭidṛṣṭaṃ vilokyate |
asti nabho nabhasyeva tau nabhonabhasi sthitau
]

`v 16 [
nabhonibhāvabhūtāṅgāvacchau vyomna ivāgrajau |
hastapādāsyamūrdhno yadbahutvālpatvabhedataḥ
]

`v 17 [
nānātvaṃ halaśūrpādisragdharatvaṃ ca tacchṛṇu |
sā hi kriyā bhagavatī parispandaikarūpiṇī
]

`v 18 [
dadyātsnāyācca juhuyādityādyagraśarīriṇī |
citiśaktiranādyantā tathā bhātātmanātmani
]

`v 19 [
sākāśarūpiṇī kāntā dṛśyaśrīḥ spandadharmiṇī |
devyāstasyā hi yāḥ kālyā nānābhinayanartanāḥ
]

`v 20 [
tā imā brahmaṇaḥ sargajarāmaraṇarītayaḥ |
kriyāsau grāmanagaradvīpamaṇḍalamālikāḥ
]

`v 21 [
spandānkaroti dhatte'ntaḥ kalpitāvayavātmikā |
kālī kamalinī kālī kriyā brahmāṇḍakālikā
]

`v 22 [
dhatte svāvayavībhūtāṃ dṛśyalakṣmīmimāṃ hṛdi |
na kadācana ciddevī nirdeśyāvayavā kvacit
]

`v 23 [
śivatvāvyatirekeṇa śivataivaṃ vidṛśyatām |
yathāṅga śūnyatā vyomnaḥ spandanaṃ mātariśvanaḥ
]

`v 24 [
jyotsnāyāścetyamevaṃ hi dṛśyamaṅgaṃ citeḥ kriyā |
śivaṃ śāntamanāyāsamavyayaṃ viddhi nirmalam
]

`v 25 [
na manāgapi tatrāsti staimityaṃ spandadharmatā |
sā kriyaiva tathārūpā satī bodhavaśādyadā
]

`v 26 [
vyāvṛttyaiva tathaivāste śiva ityucyate tadā |
citiśakteḥ kriyā devyāḥ pratisthānaṃ yadātmani
]

`v 27 [
yathābhūtasthitereva tadeva śiva ucyate |
devyāḥ kriyāyāścicchakteḥ svarūpiṇyā mahākṛteḥ
]

`v 28 [
kalpitākāradhāriṇyā ananyāvayavā ime |
sargāḥ sajjanatāvargā lokā ālokabhāsvarāḥ
]

`v 29 [
sadvīpasāgarāḥ pṛthvyaḥ savanāvanayo'drayaḥ |
sāṅgopāṅgāstrayo vedāḥ savidyāsthānagītayaḥ
]

`v 30 [
savidhipratiṣedhārthāḥ saśubhāśubhakalpanāḥ |
sadakṣiṇāgnayo yajñāḥ puroḍāśādyaśaṃsinaḥ
]

`v 31 [
bhūpālolūkhalabṛsīśūrpayūpādisaṃyutāḥ |
saṃgrāmāḥ sāyudhagrāmāḥ saśūlaśaraśaktayaḥ
]

`v 32 [
sabhuśuṇḍīgadāprāsahayebhabhaṭabhāsurāḥ |
jñātayo bhūtasaṃghānāṃ caturdaśa surādikāḥ |
caturdaśābdhidvīporvyastathā lokāścaturdaśa
]

`v 33 [
śrīrāma uvāca |
citeḥ kalpāḥ śarīriṇyāḥ sargā ye'ṅge sthitāstathā |
te kimātmani tiṣṭhanti utāsatyā vadeti bho
]

`v 34 [
śrīvasiṣṭha uvāca |
rāmāsau kila cicchaktistayā yaccoditaṃ tathā |
tatpracetitamevātaḥ satyaṃ cedamivākhilam
]

`v 35 [
tatpratibimbitaṃ bāhyānmukurapratibimbavat |
satyaṃ tadantarevāsti citernāsatyamarthataḥ
]

`v 36 [
cidrūpasya tathāpyantaḥ satsaṃkalpapuraṃ bhavet |
dṛḍhadhyānādviśuddhāyāaściterbhavatu sā katham
]

`v 37 [
ādarśeṣvathavā svapne sargaḥ saṃkalpane'stu vā |
sa ātmanyarthakāritvātsatya ityeva me matiḥ
]

`v 38 [
mama nārthāya sa iti vakṣi cettatkathaṃ bhavet |
deśāntaragatāḥ sarve bhavantyarthāya saṃprati
]

`v 39 [
yathā deśāntaragrāmastadgatasyārthakṛdbhavet |
sarve tathaiva tadbhāvaṃ gatasyārthaviniścayāt
]

`v 40 [
yadyathābhūtasarvārthakriyākāri pradṛśyate |
tatsatyamātmano'nyasya naivātattāmupeyuṣaḥ
]

`v 41 [
tasmācchicchaktikośasthāḥ sarvāḥ sargaparamparāḥ |
satya ātmeti tadbhāvaṃ gatasyānyasya nākhilāḥ
]

`v 42 [
bhūtabhavyabhaviṣyasthāḥ saṃkalpasvapnapūrgaṇāḥ |
sarve satyāḥ paraṃ tattvaṃ sarvātmā kathamanyathā
]

`v 43 [
prāpyante yogasiddhena tadbhāvaṃ tu gatena te |
anyena parvatā grāmā gatyā deśāntare yathā
]

`v 44 [
cālitasya yathā gāḍhanidrasya svapnapattanam |
na luṭhatyeva luṭhitamityapyanumataṃ sphuṭam
]

`v 45 [
tathā calantyā luṭhitaṃ tasyā dehagataṃ jagat |
na luṭhatyeva mukurapratibimbamiva sthitam
]

`v 46 [
sa trailokyamahārambhaḥ satyo'pi bhrāntimātrakam |
bhrāntimātrasya ke nāma luṭhanāluṭhane vada
]

`v 47 [
kadā svapnapuraṃ satyaṃ kadā svapnapuraṃ mudhā |
kadā svapnapuraṃ bhagnaṃ kadā svapnapuraṃ sthitam
]

`v 48 [
bhrāntitvaṃ kevalaṃ saiva dṛśyaśrīryāvadagragā |
tvaṃ viddhīmāmapi bhrāntiṃ jagallakṣmīmavāstavīm
]

`v 49 [
saṃkalpane manorājye svapne saṃkathane bhrame |
yathāpurānubhavaṃ trailokyānubhavaṃ tathā
]

`v 50 [
ahamiti jagaditi nāntarbhrāntiriyaṃ prakacatīva citaḥ |
paramākāśakṛśākhyā śāmyati nipuṇaṃ parijñātā
]