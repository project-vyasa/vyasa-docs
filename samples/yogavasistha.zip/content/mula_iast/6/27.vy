`v 1 [
saptaviṃśaḥ sargaḥ 27
śrīvasiṣṭha uvāca |
nirvāṇo bhava śāntātmā yathāprāptānuvṛttimān |
sannevāsatsamaḥ saumya sphaṭikādiva nirmitaḥ
]

`v 2 [
cittaspande citaḥ spandabhramādviśvavibhūtayaḥ |
cittaśāntyaiva tacchāntyā svarūpasthitirīryate |
sphaṭikānnirmitaḥ pratimāpuruṣo yathā sannāpi
dṛṣṭiprasarānirodhitvādasatsamastadvatsvātmādvaitadṛṣṭiprasarānirodhitvāda##-
ekasminneva sarvasminsaṃsthite vitatātmani |
naikasminna ca sarvasminnānātākalanā kutaḥ
]

`v 3 [
ādyantarahitaṃ sarvaṃ vyoma cittattvanirbharam |
śarīrotpattināśeṣu kā cittattvasya khaṇḍanā
]

`v 4 [
sphuranti hi jaḍakrīḍāściccamatkāracāpalāt |
acāpalātpratīyante taraṅgā iva vāriṇi
]

`v 5 [
yathā śubhrāmbude vastraśaṅkā na phalabhāginī |
deho'yamahamityeṣā tathā śaṅkā na vāstavī
]

`v 6 [
mā'vastuni nimagnastvaṃ bhava bhūribhavaprade |
vastvanantasukhāyādyaṃ bhavyaṃn bhāvaya bhūtaye
]

`v 7 [
cidvyomānantamevāsminneyattāsti samātmanaḥ |
ityeva paramaṃ vastu vastu tatparamastu te
]

`v 8 [
evaṃ niścayavānnāma tvamevāsi nirañjanaḥ |
dhyātā dhyeyaṃ tathā dhyānaṃ satyaṃ cāpi na kiṃcana
]

`v 9 [
draṣṭā dṛśyaṃ darśanaṃ ca cita eva vibhūtayaḥ |
atattatsaṃvido nānyadadhyānaṃ dhyeyamasti ca
]

`v 10 [
udyati pratipaccandre vahati pralayānile |
ātmatattvaṃ samaṃ saumyaṃ na kṣubhyati na śamyati
]

`v 11 [
yathā nauyāyinaḥ sthāṇutaruśailādivepanam |
yathā śuktau rajatadhīstathā dehādi cetasaḥ
]

`v 12 [
yathā dehādi cittasya tathā dehasya cittakam |
tathaiva jīvaḥ parame pade dvaitamataḥ kutaḥ
]

`v 13 [
sarvamekamidaṃ śāntaṃ brahma bṛṃhitavedanāt |
na kiṃcijjagadādyasti bhrāntiranyā na vidyate
]

`v 14 [
na vidyate yathā vyomni vanaṃ snehaśca saikate |
vidyucchaśāṅkabimbe ca tathā dehādi cetasi
]

`v 15 [
avidyamāna evāsminmā bibhīhi jagadbhrame |
etadeva paraṃ satyaṃ viddhi satyavidāṃ vara
]

`v 16 [
jagadasti na satteti yāsīdbhrāntistavādya sā |
śāntā madupadeśena kimanyadbandhakāraṇam
]

`v 17 [
sthālyudañcanakumbhādi yathā mṛnmātrakaṃ tathā |
cittamātraṃ jagadidaṃ kṣīṇaṃ tacca vicāraṇāt
]

`v 18 [
āpatsu saṃpatsu bhavābhaveṣu śāntaiṣaṇāharṣaviṣādasaṃvit |
saumyādahaṃbhāvavidā vimukto yathāsthitaṃ tiṣṭha vilīya māsva
]

`v 19 [
yathāsthitaṃ vastvadhigamya rāma sthito'si cedvāsvakulāmbarendo |
taddharṣaśokaiṣaṇadūṣaṇādi vimucya vā tiṣṭha yathecchamāsva
]