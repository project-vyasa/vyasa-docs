`v 1 [
pañcapañcāśadadhikaśatatamaḥ sargaḥ 155
agniruvāca |
ityākarṇyātha sa vyādhastadā tasminvanāntare |
āsīccitrakṛtākāra iva vismayamantharaḥ
]

`v 2 [
na viśaśrāma ceto'sya svābhyāsena vinā pade |
āsīdudbhrānta iva sa prohyamāna ivārṇave
]

`v 3 [
ārūḍha iva vā cakre cakreṇa tapasā hṛtaḥ |
nakreṇeva samākrāntaḥ parākrama vivarjitaḥ
]

`v 4 [
kimetatsyādutānyatsyānnirvāṇamiti saṃśayāt |
nādhyagacchadasau śāntiṃ mūrkho yauvanavāniva
]

`v 5 [
avidyākṛtamevedaṃ dṛśyamityeva cintayan |
avidyā jagadityeṣā nāyāti nipuṇaṃ hṛdi
]

`v 6 [
kiyadantamidaṃ dṛśyaṃ syātpaśyāmyetadāditaḥ |
dūratordhvapramāṇena tapolabdhaśarīrakaḥ
]

`v 7 [
bhāvābhāvātmano nityamasyānte sthīyate sukham |
tasmādākāśamapyasti yatra no tatra yāmyaham
]

`v 8 [
iti nirṇīya hṛdaye mūrkha eva babhūva saḥ |
gataṃ tādṛśamapyuktaṃ vinābhyāsena bhasmani
]

`v 9 [
tatastataḥ prabhṛtyeva tenaiva munibhiḥ saha |
lubdhakatvaṃ parityajya tapaścaritumudyataḥ
]

`v 10 [
tasmiñjagati tairbhāvaistaiḥ samaṃ nivasansadā |
bahūnyabdasahasrāṇi cakāra sumahattapaḥ
]

`v 11 [
tapaḥ kurvankadācitsa punaḥ papraccha taṃ munim |
kadā syādātmaviśrāntirmametyāha munistataḥ
]

`v 12 [
muniruvāca |
jñānaṃ tadupadiṣṭaṃ te jīrṇadārvalpakāgnivat |
saṃsthitaṃ hṛdaye kiṃtu dāhyamākramya nocitam
]

`v 13 [
nābhyāsena vinā jñāne śive viśrāntavānasi |
abhyāsena tu kālena bhṛśaṃ viśrāntimeṣyasi
]

`v 14 [
bhaviṣyadidamātmīyamathākarṇaya nirṇayam |
mama varṇayataḥ karṇabhūṣaṇaṃ bhūtalādbhutam
]

`v 15 [
saṃstutānavabuddhātmā jñānasāratayānayā |
dolāyamānasaṃvittvaṃ na mūrkho na ca paṇḍitaḥ
]

`v 16 [
avidyārūpamābhogi kiṃpramāṇamidaṃ jagat |
syādityātmavikalpena tapastvaṃ kartumudyataḥ
]

`v 17 [
itthaṃ tapastvayā ghoraṃ kāryaṃ yugaśataṃ pṛthu |
parameṣṭhī tatastuṣṭastvāmupaiṣyati sāmaraḥ
]

`v 18 [
mārgayiṣyasi tasya tvaṃ varadasya varaṃ vara `note[svajātisiddhahiṃsādiparityāgena
tapaḥpravṛttatvāllubdhakasyaiva vareti saṃbodhanaṃ |] |
idamuddāmadaurātmyānnijaṃ `note[napuṃsakatvamārṣaṃ idamiti vā pāṭhaḥ |]
saṃdehasaṃśayam `note[saṃdehasya avidyārūpamityādinānupadoktasya samyak
śayaḥ śayanaṃ nivṛttiriti yāvat | sa yasminniti saṃdehasaṃśayastathāvidhamiti
varaviśeṣaṇam |]
]

`v 19 [
devāyaṃ dṛśyarūpe'smindṛṣṭe'vidyābhrame sati |
kvacidādarśavannāsti pratibimbamalojjhitaḥ
]

`v 20 [
cidvyomadarpaṇasyāsya paramāṇvākṛterapi |
antasthasyaiva vā yatra tatredaṃ pratibimbati
]

`v 21 [
tasmātkiyadanantaṃ syādidaṃ dṛśyamanarthakṛt |
tasya pāre kiyadvā syādākāśaṃ dṛśyameva tat
]

`v 22 [
evamarthamahaṃ jñātumimaṃ saṃprārthaye varam |
śṛṇu deveśvarāvighnaṃ taccaivāśu prayaccha me
]

`v 23 [
iyaṃ svacchandamṛtyurme nīrogā'stu tanuściram |
gāruḍena ca vegena saṃyutā vyomagāminī
]

`v 24 [
pratināḍīkameṣā tu vṛddhiṃ gacchatu yojanam |
krameṇa jagato bāhye bhavatvākāśarūpiṇī
]

`v 25 [
sākāśasyāsya dṛśyasya labheya parameśvara |
antamitthamanantasya paramo'stviti me varaḥ
]

`v 26 [
iti sādho tvayā prokte devadevo varaṃ prabhuḥ |
evamastu tavetyuktvā yāsyatyantardhimīśvaraḥ
]

`v 27 [
gate tasminmahādeve devaiḥ saha divaspatau |
tapasā te kṛśo dehaścandrakāntirbhaviṣyati
]

`v 28 [
māmāpṛcchannamaskṛtya tasminneva kṣaṇe tataḥ |
plutimeṣyati sa vyomni cittasthārthadidṛkṣayā
]

`v 29 [
dvitīya iva śītāṃśurdivtīya iva bhāskaraḥ |
dvitīya iva vaurvāgniścandrārkaspardhayotthitaḥ
]

`v 30 [
tato garuḍavegena dṛśyasya nabhasastathā |
antaṃ prāptuṃ vahanvegājjagataḥ saritāmiva
]

`v 31 [
jagatonte tato'jasraṃ tato vardhiṣyate vapuḥ |
kalpāntamattārṇavavanniṣpārāmbarapūraṇam
]

`v 32 [
drakṣyasyatha mahāvyomni vardhamāno bṛhadvapuḥ |
sargānnirargalādhāranirantagaganakramāt
]

`v 33 [
nirargalamapratibandhamevādhārabhūtaṃ yadanantaṃ gaganaṃ tasya kramādākramaṇāt |
32 |
paramārthamahākāśaśūnyatāvātacakrakān |
svabhāvadravatoddeśāccidarṇavataraṅgakān
]

`v 34 [
saṃvidghane yathā svapne purādyā bhānti khātmakāḥ |
tathā tadā tavaiṣyanti sargavargā nirargalāḥ
]

`v 35 [
visphuranti mahāvyomni parṇaughāḥ kṣubhitānilaiḥ |
tathā sargānanantāṃstvaṃ drakṣyasyakṣīṇaniścayaḥ
]

`v 36 [
sabhāsatyekṣaṇarucāṃ yathā jālaṃ sadapyasat |
jagadātma tathākāśasaṃvidāṃ khe sadapyasat
]

`v 37 [
sarvorvījanadṛṣṭānāṃ lagnānāmindumaṇḍale |
yādṛgjālaṃ jagattādṛksthite'nanyatvamātmanaḥ
]

`v 38 [
punaḥ sargaḥ punarvyoma punaḥ sargaḥ punarnabhaḥ |
ityevaṃ paśyataste'tra dīrghakālaḥ prayāsyati
]

`v 39 [
atha dīrgheṇa kālena prasphuransargaparṇake |
udvegameṣyasi vyomni mahāmahimani svayam
]

`v 40 [
udvegameṣyasi tatastapaso'nubhavatphalam |
nirdekṣyasi tadā dehamanantāmbarapūrakam
]

`v 41 [
kimidaṃ kuśarīraṃ me bhārabhūtamiva sthitam |
mervādibhūbhṛtāṃ lakṣamapi yasmiṃstṛṇāyate
]

`v 42 [
deho mamāpramāṇo'yaṃ vyāptaṃ vyoma mayākhilam |
pūrayāmi khamadyāpi bhāvi naivopagamyate
]

`v 43 [
avidyā bata ghoreyamanantā ca pramīyate |
mīyate na ca kenāpi brahmajñānaṃ samaṃ vinā
]

`v 44 [
iyaṃ dṛśyarūpā | pramīyate anubhūyate | mīyate iyattayā paricchidyate hiṃsyate vā | 43
|
tamimaṃ saṃtyajāmyeva dehamāvivṛtāntaram |
nānena kiṃcidāpnomi sādhusacchāstrasaṃgamam
]

`v 45 [
anantāpāraparyantaṃ nirālambāmbarāspadam |
kiṃ nāmedaṃ śarīraṃ me suduṣprāpārthasaṃgamam
]

`v 46 [
iti saṃcintya taṃ dehaṃ dhāraṇāṃ prāṇarecanīm |
kṛtvā tyakṣyasi saṃbhuktātphalācchuṣkaṃ yathā khagaḥ
]

`v 47 [
kṛtvā dehaparityāgaṃ jīvaḥ prāṇasamanvitaḥ |
vyomni sthāsyati te tasminvātātsūkṣmo'pi vātavat
]

`v 48 [
chinnapakṣo mahāmeruriva dehaḥ patiṣyati |
tatra bhūlokaśailādi sarvaṃ cūrṇīkariṣyati
]

`v 49 [
śuṣkā bhagavatī dehaṃ tattadā bhakṣayiṣyati |
samātṛmaṇḍalā tena nirdoṣā bhūrbhaviṣyati
]

`v 50 [
ityātmodantamakhilaṃ śrutavānasi suvrata |
tapastālīvane kṛtvā yathecchasi tathā kuru
]

`v 51 [
vyādha uvāca |
aho nu bhagavanduḥkhaṃ paribhoktavyamakṣayam |
mayā vyarthamanarthāya yadarthena durarthitam
]

`v 52 [
vidyate kiṃ vibho kācidyuktiḥ saiṣā sthitirvara |
anyathā bhavitavyo'rtho yadi nāsti taducyatām
]

`v 53 [
muniruvāca |
avaśyaṃbhavitavyo'rtho na kadācana kenacit |
vidhātumanyathā śakyastanna kṣarati yatnataḥ
]

`v 54 [
vāmāvāmaśiraḥpādaviparyayavidhau yathā |
puṃso na vidyate śaktistathā bhāvyanyathāsthitau
]

`v 55 [
jyotiḥśāstrārthavijñānairiha bhāvyarthavedanam |
bhavatyanyadapūrvaṃ tu na kiṃcana kadācana
]

`v 56 [
jayanti karmāṇi hi vedanāni yaiḥ prākṛtairadyatanānyupetya |
śarīradāhairapi nirvikārasaṃvinnayairbrahmatayaiva suptam
]