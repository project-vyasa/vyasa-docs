`v 1 [
aṣṭacatvāriṃśaḥ sargaḥ 48
śrīvasiṣṭha uvāca |
rūḍhe saṃsāranirvede sthite sādhusamāgame |
śāstrārthe bhāvite buddhyā bhogavaitṛṣṇya āgate
]

`v 2 [
jāte viṣayavairasye sajjanatve tathodite |
prakāśe sonmukhībhūte hṛdaye kalitodaye
]

`v 3 [
dhanāni nābhivāñchyante tamāṃsīva vivekinā |
tyajyante vidyamānāni saṃśuṣkāmedhyaparṇavat
]

`v 4 [
saṃśuṣkāṇyamedhyānyapavitrāṇyucchiṣṭādiparṇāni yathā gṛhānnirasyante tadvat |
3 |
bhārāya pānthadṛṣṭyeva dṛśyante dārabandhavaḥ |
yathāśakti yathākālamupacaryanta eva ca
]

`v 5 [
indriyeṣvapi saṃlagnā indriyārthāḥ punaḥpunaḥ |
na bhogā anubhūyante nūnaṃ śāntamanastayā
]

`v 6 [
ekānteṣu diganteṣu saraḥsu vipineṣu ca |
udyāne puṇyadeśeṣu nijeṣveva gṛheṣu vā
]

`v 7 [
suhṛtkelivilāseṣu śubhodyānāśanādiṣu |
śāstratarkavicāreṣu na tathā sthīyate ciram `note[sthiraṃ iti pāṭhaḥ |]
]

`v 8 [
upaśāntena dāntena svātmārāmeṇa mauninā |
jñātaivānviṣyate jñena vijñānaikāntavādinā
]

`v 9 [
evamabhyāsavaśataḥ pare viśramyate pade |
nimnevāmbhasi śāntena svayameva vivekinā
]

`v 10 [
sabāhyābhyantaraṃ śāntā jñataivārthatayoditā |
na saṃbhavati bhinno'rtha ityeva paramaṃ padam
]

`v 11 [
nārthopalabdhirno śūnyamasti bodhātmatāṃ vinā |
ityantaranubhūtisthamāhustatparamaṃ padam
]

`v 12 [
ekabodhātisaṃbandhapariṇāmānna bodhatā |
na śūnyatā nārthateti viddhi tatparamaṃ padam
]

`v 13 [
svasaṃvinmātraviśrāmavatāmamanasāṃ satām |
na svadante hi viṣayāḥ payāṃsi dṛṣadāmiva
]

`v 14 [
nirodhapadamāpanno nirmanā maunamantharaḥ |
svabhāve sthita evāste citre kṛta ivātmavān
]

`v 15 [
sarvārthamartharahitaṃ mahadeva parāṇuvat |
aśūnyameva śūnyātma hṛdayaṃ vedyavedinaḥ
]

`v 16 [
ahaṃtvaṃ jagadīhādi dikkālakalanādi ca |
jñasya jñānādi śūnyādi sthitameva na vidyate
]

`v 17 [
jñenāmalapadasthena dīpeneva nirasyate |
tamo hārdaṃ tathā bāhyaṃ rāgadveṣabhayādi ca
]

`v 18 [
rajorahitasarvāśaṃ sattvātpāramupāgatam |
asaṃbhavattamorūpaṃ praṇamettaṃ nṛbhāskaram
]

`v 19 [
bhedapravilaye jāte citte cādṛśyatāṃ gate |
yā sthitiḥ prāptabodhasya na vāggocarameti sā
]

`v 20 [
dadātyetanmahābuddhe nirvāṇaṃ parameśvaraḥ |
aharniśaṃ paramayā ciraṃ bhaktyā prasāditaḥ
]

`v 21 [
śrīrāma uvāca |
īśvaraḥ ko muniśreṣṭha kathaṃ bhaktyā prasādyate |
etanme tattvato brūhi sarvatattvavidāṃ vara
]

`v 22 [
śrīvasiṣṭha uvāca |
īśvaro na mahābuddhe dūre na ca sudurlabhaḥ |
mahābodhamayaikātmā svātmaiva parameśvaraḥ
]

`v 23 [
tasmai sarvaṃ tataḥ sarvaṃ sa sarvaṃ sarvataśca saḥ |
so'ntaḥ sarvamayo nityaṃ tasmai sarvātmane namaḥ
]

`v 24 [
tasmādimāḥ prasūyante sargapralayavikriyāḥ |
akāraṇaṃ kāraṇato gatayaḥ pavanādiva
]

`v 25 [
aniśaṃ pūjayantyetāḥ sarvāḥ sthāvarajaṅgamāḥ |
yathābhimatadānena sarve `note[sarve te iti na sādhu sarvāstā iti suvacam |] te
bhūtajātayaḥ
]

`v 26 [
subahūnyeṣa janmāni yathābhimatayecchayā |
yadā saṃpūjitastena prasādamadhigacchati
]

`v 27 [
prasannaḥ sa mahādevaḥ svayamātmā maheśvaraḥ |
bodhāya prerayatyāśu dūtaṃ pūtaṃ śubhehitaiḥ
]

`v 28 [
śrīrāma uvāca |
ātmanā parameśena ko dūtaḥ preryate mune |
sa dūto bodhanaṃ vāpi karoti vada me katham
]

`v 29 [
śrīvasiṣṭha uvāca |
ātmasaṃprerito dūto viveko nāma nāmataḥ |
hṛdguhāyāṃ sadānandastiṣṭhatīndurivāmbare
]

`v 30 [
sa eṣa vāsanātmānaṃ jantuṃn bodhayati kramāt |
saṃsārasāgarādasmāttārayatyavivekinam
]

`v 31 [
bodhātmaiṣo'ntarātmaiva paramaḥ parameśvaraḥ |
asyaiva vācako nāma praṇavo vedasaṃmataḥ
]

`v 32 [
japahomatapodānapāṭhayajñakriyākramaiḥ |
eṣa prasādyate nityaṃ naranāgasurāsuraiḥ
]

`v 33 [
dyaurmūrdhā pṛthivī pādau tārakā romarājayaḥ |
bhūtānyasthīni hṛdayaṃ vyomāsya parameśvaraḥ
]

`v 34 [
sarvatraiṣa cidātmatvādyāti jāgarti paśyati |
tenaiṣa sarvatolakṣyakarakarṇākṣipādabhṛt
]

`v 35 [
vivekadūtamudbodhya hatvā cittapiśācakam |
ātmanaḥ padavīṃ sphārāṃ jīvaḥ kāmapi nīyate
]

`v 36 [
tyaktvā sarvavikalpaughānvikārānarthasaṃkarān `note[grāhagahane iti pāṭhaḥ |
] |
pauruṣeṇātmanaivātmā svayameva prasādyatām
]

`v 37 [
bhramanmanaḥpiśāce'sminkallolajaladākule |
saṃsārarātritimire svātmaivāpūrṇacandramāḥ
]

`v 38 [
agādhamaraṇāvartakallolākulakoṭare |
tṛṣṇātaraṅgatarale svamanaścaṇḍamārute
]

`v 39 [
mahājaḍalavādhāre saṃsāraviṣamārṇave |
indriyagrāmagahane `note[grāhagahane iti pāṭhaḥ |] vivekaḥ potako mahān
]

`v 40 [
pūrvaṃ yathābhimatapūjanasuprasanno datvā vivekamiha pāvanadūtamātmā |
jīvaṃ padaṃ nayati nirmalamekamādyaṃ
satsaṅgaśāstraparamārthaparāvabodhaiḥ
]