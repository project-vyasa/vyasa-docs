`v 1 [
navādhikaśatatamaḥ sargaḥ 109
śrīvasiṣṭha uvāca |
etasminnantare sarve mantriṇo nṛpamāyayuḥ |
munayo vāsavamiva daityākrāntanabhobhuvam
]

`v 2 [
mantriṇa ūcuḥ |
deva nirṇītamasmābhiryāvanna viṣayo'rayaḥ |
trayāṇāmapyupāyānāṃ daṇḍasteṣu vidhīyatām
]

`v 3 [
praṇayo'nupraveśo vā na kadācana yaḥ kṛtaḥ |
adhunā teṣu taṃ deva kuryātteṣu kathaiva kā
]

`v 4 [
pāpā mlecchā dhanāḍhyāśca nānādeśyāḥ susaṃhatāḥ |
bahavo labdharandhrāśca sāmādernāspadaṃ dviṣaḥ
]

`v 5 [
kiṃcidviśvāsārheṣu anāḍhyeṣu sāmadānopāyapravṛttirete tu na tādṛśā ityāha ##-
tatsusāhasamevedaṃ varjayitvā pratikriyā |
nānyāsti śīghramevāto raṇodyogo vidhīyatām
]

`v 6 [
vīrāṇāṃ dīyatāmājñā pūjyantāmiṣṭadevatāḥ |
āhūyantāṃ ca sāmantā hanyatāṃ raṇadundubhiḥ
]

`v 7 [
sannahyantāmaśeṣeṇa nirgacchantu raṇe bhaṭāḥ |
kriyantāṃ kālakampābhramedurā rājitā diśaḥ
]

`v 8 [
āsphālyantāṃ dhanūṃṣyuccaiḥ kvaṇantu guṇapaṅktayaḥ |
bhavantu jaladaśyāmāḥ kakubhaḥ khaṇḍamaṇḍalaiḥ
]

`v 9 [
guṇapaṅktayo maurvīśreṇayaḥ | khaṇḍamaṇḍalairardhamaṇḍalasadṛśairdhanurbhiḥ |
8 |
sphurajjyāvidyutaḥ śūravāridā ghanagarjitāḥ |
nārācadhārā muñcantu kacatkodaṇḍakuṇḍalāḥ
]

`v 10 [
rājovāca |
gamyatāṃ saṅgarāyāśu saṃvidhānaṃ vidhīyatām |
snātvāhaṃ pūjayitvāgniṃ nirgacchāmi raṇājiram
]

`v 11 [
ityuktvā nṛpatiḥ snāto mahārambho'pi sa kṣaṇāt |
prāvṛṣīva navodyānaṃ gaṅgājaladharairghaṭaiḥ
]

`v 12 [
atha praviṣṭo'gnigṛhaṃ pūjayitvā hutāśanam |
ādareṇa yathāśāstraṃ cintayāmāsa bhūmipaḥ
]

`v 13 [
nītamāyuranāyāsavilāsavibhavaśriyā |
prajābhyo dattamabhayamāsamudrasamudritam
]

`v 14 [
ākrāntavasudhāpīṭhāḥ pādapīṭhe kṛtā dviṣaḥ |
latāḥ phalabhareṇeva namitāḥ kakubho daśa
]

`v 15 [
prajācittendubimbeṣu likhitaṃ dhavalaṃ yaśaḥ |
bhūmāvāropitā kīrtilatā tripathagāminī
]

`v 16 [
kośavadbharitā ratnaiḥ suhṛnmitrāryabandhavaḥ |
nipīto'rṇavatīreṣu nālikerarasāsavaḥ
]

`v 17 [
āryāḥ pūjyā brāhmaṇāḥ | arṇavatīreṣvityuktyā catuḥsamudrāntaṃ digvijayo gamyate |
16 |
dviṣāmākampitā bhekagalāṅgatvagivāsavaḥ |
macchāsanāṅkitā jātā dvīpāntarakulācalāḥ
]

`v 18 [
vihṛtaṃ siddhasenāsu digantanavabhūmiṣu |
bhūmyantabhūbhṛtāṃ mūrdhni viśrāntaṃ meghalīlayā
]

`v 19 [
dhiyevoccaiḥpade jñānapūrṇayaikāntaśīlayā |
vilabdhānyavinaṣṭāni rāṣṭrānīṣṭārthakāriṇā
]

`v 20 [
rakṣāṃsyapyavinītāni baddhāni nigaḍairghanaiḥ |
dharmārthakāmairanyonyaṃ cayāpacayavarjitaiḥ
]

`v 21 [
akhaṇḍitairmayā nītaṃ pītātiyaśasā vayaḥ |
idānīṃ śaṣpaviśrāntaprāleyabharabhāsuram
]

`v 22 [
āgataṃ vārdhakaṃ sarvabhogasaṃrambhamārjanam |
tasyoparyarayo raudrā balavanto raṇaiṣiṇaḥ
]

`v 23 [
saṃbhūya sarvataḥ prāptāḥ saṃdigdho vartate jayaḥ |
tadihaivānalāyāsmai devāya jayadāyine
]

`v 24 [
mastakāhutimevemāṃ samudyamya dadāmi vai |
rājovāca |
kṛśāno deva mūrdhā'yaṃ tubhyamāhutitāṃ gataḥ
]

`v 25 [
mayā pūrvaṃ puroḍāśa iva deveśa dīyate |
yadi tuṣṭo'si bhagavaṃstadanena kṛtena me
]

`v 26 [
catvāro bhavataḥ kuṇḍātsvadehāḥ prodbhavantu me |
balavantaḥ śriyā dīptā nārāyaṇabhujā iva
]

`v 27 [
taiścaturdikkamevārīnvadhyāmahamavighnataḥ |
tvayā ca darśanaṃ deyaṃ mahyaṃ matimate vibho
]

`v 28 [
vadhyāṃ vadhyāsam | salopaśchāndasaḥ | matimate tvaddarśanecchayā tvatsmṛtimate |
27 |
śrīvasiṣṭha uvāca |
ityuktvā sa mahīpālaḥ khaḍgamādāya cicchide |
śiraḥ kamalamālolaṃ līlayevāśu bālakaḥ
]

`v 29 [
chinnameṣa śiro yāvajjuhotyasitavartmane |
tāvaccharīreṇa saha papātāgnau sa pārthivaḥ
]

`v 30 [
bhuktvātha vahnistaṃ dehaṃ dadāvasmai caturguṇam |
mahatāmupayuktaṃ hi sadya evābhivardhate
]

`v 31 [
caturmūrtirathottasthau pāvakādvasudhādhipaḥ |
prajvalaṃstejasāṃ puñjairnārāyaṇa ivārṇavāt
]

`v 32 [
te dehāstasya catvāro virejurbhāsvaratviṣaḥ |
sahajātottamottaṃsabhūṣaṇāyudhavāsasaḥ
]

`v 33 [
sakaṃkaṭaśirastrāṇāḥ samaulikaṭakāṅgadāḥ |
sahārakuṇḍalābhogāḥ sarvāḥ sarve mahāśayāḥ
]

`v 34 [
sarva eva samākārāḥ sadṛśāvayavānvitāḥ |
cañcaloccaiḥśravaḥprakhyaṃ hayaratnamavasthitāḥ
]

`v 35 [
sasuvarṇaśarāpūrṇatūṇīrāḥ sumahāśayāḥ |
samānaguṇakodaṇḍāḥ samānavapuṣaḥ śubhāḥ
]

`v 36 [
samārohanti te yasminpuṃsi nāge rathe haye |
sarveṣāmaridoṣāṇāṃ naiva gamyo bhavatyasau
]

`v 37 [
pītvā dhṛtvā ciraṃ kālaṃ garbhe puruṣatāpitāḥ |
vedyāmiva hitāstatra sāgarā vaḍavārciṣā
]

`v 38 [
ratnāśvadehakusumotkarapūrṇadehāścatvāra induhasitairavabhāsayantaḥ |
sanmūrtayo haraya eva yathābdhayo vā vedā ivāhutihutādanalātprasasruḥ
]