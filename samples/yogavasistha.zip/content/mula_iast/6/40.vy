`v 1 [
catvāriṃśah sargaḥ 40
śrīvasiṣṭha uvāca |
rūpālokamanaskārabuddhyādīndriyavedanam |
svarūpaṃ viduramlānamasvabhāvasya vastunaḥ
]

`v 2 [
asvabhāvatanutvena svabhāvasthitirātatā |
yadodeti tadā sargo bhramābhaḥ pratibhāsate
]

`v 3 [
yadā svabhāvaviśrāntiḥ sthitimeti śamātmikā |
jagaddṛśyaṃ tadā svapnaḥ suṣupta iva śāmyati
]

`v 4 [
bhogā bhavamahārogā bandhavo dṛḍhabandhanam |
anarthāyārthasaṃpattirātmanātmani śāmyatām
]

`v 5 [
asvabhāvātmatā sargaḥ svabhāvaikātmatā śivaḥ |
bhūyatāṃ paramavyomnā śāmyatāṃ meha tāmyatām
]

`v 6 [
nātmānamavagacchāmi na dṛśyaṃ ca jagadbhramam |
brahma śāntaṃ praviṣṭo'smi brahmaivāsmi nirāmayaḥ
]

`v 7 [
tvameva paśyasi tvantvaṃ sattvaṃ śabdārthajṛmbhitam
`note[śabdārthabṛṃhitaṃ iti pāṭhaḥ sādhurvyākhyānuguṇyāt |] |
paśyāmi śāntamevāhaṃ kevalaṃ paramaṃ nabhaḥ
]

`v 8 [
brahmaṇyeva parākāśe rūpālokamanomayāḥ |
vibhramāstava saṃjātakalpāḥ spandā ivānile
]

`v 9 [
brahmātmā vetti no sargaṃ sargātmā brahma vetti no |
suṣupto vetti no svapnaṃ svapnastho na suṣuptakam
]

`v 10 [
prabuddho brahmajagatorjāgratsvapnadṛśoriva |
rūpaṃ jānāti bhārūpaṃ jīvanmuktaḥ praśāntadhīḥ
]

`v 11 [
yathābhūtamidaṃ sarvaṃ parijānāti bodhavān |
saṃśāmyati ca śuddhātmā śaradīva payodharaḥ
]

`v 12 [
smṛtisthaḥ kalpanastho vā yathākhyātaśca saṃgaraḥ |
sadasadbhrāntatāmātrastathāhaṃtvajagadbhramaḥ
]

`v 13 [
ātmanyapi nāsti hi yā draṣṭā yasyā na vidyate kaścit |
na ca śūnyaṃ nāśūnyaṃn bhrāntiriyaṃ bhāsate seti
]