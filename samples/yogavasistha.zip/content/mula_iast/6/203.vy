`v 1 [
tryadhikadviśatatamaḥ sargaḥ 203
śrīvālmīkiruvāca |
itthaṃ vicāraparayormunirāghavayostayoḥ |
bhāskaraḥ śravaṇāyeva vyomamadhyamupāyayau
]

`v 2 [
tīkṣṇatāmājagāmāśu sarvadikkamathātapaḥ |
padārthaughavikāsārthaṃ rāmasyeva mahāmatiḥ
]

`v 3 [
utphullahṛdayāmbhojasphārākāratayā tadā |
līlāpadmākarā rejustatrasthāḥ pārthivā iva
]

`v 4 [
jālaṃ muktākalāpānantaramākrāntabhāskaram |
nanarteva taradvyoma vijñānaśravaṇādiva
]

`v 5 [
pusphuruḥ padmarāgeṣu lagnārkataruṇatviṣaḥ |
bhāso vyomataloḍḍīnā dhiyo jñānakalā iva
]

`v 6 [
evaṃ nirvṛtimāyāte rāme svakulakairave |
munīndravadanālokātsavikāsamiva sthite
]

`v 7 [
ravāvaurvopame vyoma mahābdhernābhitāṃ gate |
tejaḥpuñjalasajjvāle samagrarasapāyini
]

`v 8 [
nabhonīlotpale nīle galadrajasi rājati |
gharmāṃśukarṇikākānte sphuratkiraṇakesare
]

`v 9 [
avataṃse jagallakṣmyāstrilokīkarṇakuṇḍale |
antarlīnasphurattārāratnarājivirājite
]

`v 10 [
digvadhūbhirbṛhacchṛṅgapāṇibhirmukureṣviva |
dhṛteṣu tāpabhinneṣu mahābhreṣu nirambuṣu
]

`v 11 [
sūryakāntavarotthena vahnineva samedhite |
dviguṇaṃ prajvalatyarkaśūnye gaganadhāmani
]

`v 12 [
vinedurmeduroddāmamukhamārutapūritāḥ |
madhyāhnaśaṅkāḥ kalpāntavātapūrṇā ivārṇavāḥ
]

`v 13 [
prāleyaśrīrivābjeṣu gharmaśrīrvadaneṣviva |
cakāra padamākīrṇaśuddhamuktāphalopamā
]

`v 14 [
gṛhabhittiparāvṛttā sattvasaṃrambhamāṃsalā |
śabdaśrīḥ pūrayāmāsa karṇamarṇa ivārṇavam
]

`v 15 [
purandhrībhirnidāghaughaśāntaye samudīritā |
ullalāsa navā pāṇḍukarpūrajaladāvaliḥ
]

`v 16 [
sa rājā sahasāmantaḥ sabhūpaḥ saparicchadaḥ |
savasiṣṭhaḥ samuttasthau saharāmaḥ sa saṃsadaḥ
]

`v 17 [
rājāno rājaputrāśca mantriṇo munayastathā |
anyonyaṃ pūjitā jagmurmuditāḥ svaṃ niveśanam
]

`v 18 [
antaḥpuragṛhāgreṣu tālavṛntānilāhṛtaiḥ |
karpūradhūlibhirabhūnnavaivāmbudamālikā
]

`v 19 [
atha madhyāhnatūryāṇāṃ rave sphūrjati bhittiṣu |
uvāca vacanaṃ vākyakovido munināyakaḥ
]

`v 20 [
sarvameva śrutaṃ śrāvyaṃ jñeyaṃ jñātamaśeṣataḥ |
tvayā rāghava bho nāsti jñātavyamaparaṃ varam
]

`v 21 [
yathā mayopadiṣṭo'si yathā paśyasi śāstrataḥ |
yathānubhavasi śreṣṭhamekavākyaṃ tathā kuru
]

`v 22 [
uttiṣṭha tāvatkāryāya vayaṃ snātuṃ mahāmate |
madhyāhnasamayo'smākamayamaṅgātivartate
]

`v 23 [
aparaṃ yattvayā bhadra svākāṅkṣāvinivṛttaye |
praṣṭavyaṃ tacchubhaṃ prātaḥ praṣṭavyaṃ bhavatā punaḥ
]

`v 24 [
praṣṭavyaṃ praśnārhamasti cettatprātaravaśyaṃ praṣṭavyaṃ nopekṣitavyamityarthaḥ |
23 |
śrīvālmīkiruvāca |
ityukte munināthena rājā daśarathaḥ svayam |
pūjayāmāsa tānsabhyānsarvānsādhūnsaparyayā
]

`v 25 [
saha rāmeṇa dharmātmā muniviprānnṛpāṃśca saḥ |
vasiṣṭhādyupadiṣṭena krameṇa vyomagāṃstathā
]

`v 26 [
maṇimuktāgaṇārthena divyena kusumena ca |
maṇiratnapradānena muktāhārārpaṇena ca
]

`v 27 [
praṇayena praṇāmena pradānenārthaśālinā |
vastrāsanānnapānena kanakena tathā bhuvā
]

`v 28 [
dhūpena gandhamālyābhyāṃ yathoditamaninditaḥ |
pūrvānsaṃpūjayāmāsa sarvāneva mahīpatiḥ
]

`v 29 [
athottasthau sabhāmadhyātsabhayā saha mānadaḥ |
savasiṣṭhādidevarṣiḥ sāyamindurivāmbarāt
]

`v 30 [
sasabhotthānasamayaḥ sasaṃrambho vyarājata |
jānudaghnasuronmuktapuṣpasaṃjātakardamaḥ
]

`v 31 [
saṃghaṭṭāghaṭṭakeyūraratnacūrṇāruṇāvaniḥ |
chinnahārasphuranmuktātārājitaniśāmbaraḥ
]

`v 32 [
devarṣimuniviprendrapārthivaspandasaṃkulaḥ |
vyagrabhṛtyāṅganāhastakeśacañcalacāmaraḥ
]

`v 33 [
jñānaprameyīkaraṇaspandamāno na dāruṇaḥ |
śiraḥkaratrinayanajihveṣveva virājitaḥ
]

`v 34 [
tarhi kiṃ sarvajanānāṃ svārthapravṛttitvarayā durbalaparopamardāddāruṇo netyāha ##-
prameyīkaraṇārthameva spandamāno nānyasvārthatvarayeti hetorna dāruṇaḥ | kiṃ ca
kadācidīṣadaṅgaghaṭṭanepi parasparakṣamāpaṇārthaṃ śiraḥkarāḥ śirasi
baddhāñjalayo ye purataḥ pārśvayośceti triṣu bhāgeṣu avalokanāya kṣamāpaṇāya ca
pravṛttaṃ nayanajihvaṃ yeṣāṃ tathāvidhāsteṣveva sarvajaneṣu virājito na
pramattaniṣṭhurajanavisaṃṣṭhula iti na tatra parapīḍādidoṣaleśasyāpi prasaktirityarthaḥ |
33 |
parasparamathāpṛcchya pūjitāḥ peśaloktayaḥ |
rājāno munayaścaiva sarve daśarathādayaḥ
]

`v 35 [
svāśramānsādhavo jagmustuṣṭasnigdhāśayā mithaḥ |
lokasaptakavāstavyā devāḥ śakrapurādiva
]

`v 36 [
anyonyaṃ praṇayātsarve pūjayitvā yathākramam |
tadvisṛṣṭāḥ svamāgatya gṛhaṃ cakrurdinakriyām
]

`v 37 [
atha sarve vasiṣṭhādyāstathā daśarathādayaḥ |
cakrurdivasakāryāṇi rājāno munayastathā
]

`v 38 [
yathāprāptaṃ kriyāṃ teṣu kṛtavatsvatha daivasīm |
krameṇākāśapathiko bhāskaro'stamupāyayau
]

`v 39 [
tayaiva kathayā teṣāṃ rāmasya ca mahāmateḥ |
prabodhavaśataḥ śīghraṃ sā vyatīyāya śarvarī
]

`v 40 [
utsāritatamaḥpāṃsutārākusumanirbharam |
bhuvanaṃ bhavanīkurvannājagāma divākaraḥ
]

`v 41 [
karavīrakusumbhābhaiḥ karairaruṇayan diśaḥ |
viveśa gaganāmbhodhimatha bāladivākaraḥ
]

`v 42 [
rājāno rājaputrāśca mantriṇo munayastathā |
vasiṣṭhādyāḥ samājagmuḥ punardāśarathīṃ sabhām
]

`v 43 [
yathākramaṃ yathāsaṃsthaṃ yathādeśaṃ yathāsanam |
sā viveśa sabhā tatra dhiṣṇyaśrīrambare yathā
]

`v 44 [
tato daśarathādyeṣu sumantrādiṣu vāpyalam |
vasiṣṭhaṃ saṃpraśaṃsatsu munimāsanasaṃsthitam
]

`v 45 [
vasiṣṭhasya pituścāgre rājīvadalalocanaḥ |
uvāca rāghavo dhīmānmṛduvarṇamidaṃ vacaḥ
]

`v 46 [
śrīrāma uvāca |
bhagavansarvadharmajña sarvajñānamahārṇava |
sarvasaṃdehaparaśo paraśokabhayāpaha
]

`v 47 [
śrotavyamaparaṃ kiṃ me vidyate vedyameva vā |
śrotavyaṃ vidyate yadvā tatsarvaṃ vaktumarhasi
]

`v 48 [
śrīvasiṣṭha uvāca |
rāma saṃprāptabuddhistvaṃ śrotavyaṃ te na vidyate |
kṛtakṛtyā tavaiṣā dhīḥ prāptaprāpyā sthitātmani
]

`v 49 [
tvameva tāvatkathaya pravicārya dhiyātmanā |
kīdṛśo'dya bhavānantaḥ kiṃ śeṣaṃ śrāvyamasti te
]

`v 50 [
śrīrāma uvāca |
brahmannevamahaṃ manye yathāhaṃ kṛtakṛtyadhīḥ |
nirvāṇosmi praśāntosmi nākāṅkṣā mama vidyate
]

`v 51 [
vaktavyamuktaṃ bhavatā jñātaṃ jñeyaṃ mayākhilam |
tava viśrāntimāyātu kṛtakṛtyā sarasvatī
]

`v 52 [
adhigatamadhigamyaṃ jñeyamāptuṃ mayedaṃ vigatamakhilamaikyaṃ dvaitamastaṃ
prayātam |
parigalitamaśeṣaṃ dṛśyabhedāvabhānaṃ nanu
nipuṇamapāstāśeṣasaṃsāritāsthā
]