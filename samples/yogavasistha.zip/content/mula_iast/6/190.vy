`v 1 [
navatyadhikaśatatamaḥ sargaḥ 190
śrīvasiṣṭha uvāca |
jñānasya jñeyatāpattirbandha ityabidhīyate |
tasyaiva jñeyatāśāntirmokṣa ityabhidhīyate
]

`v 2 [
śrīrāma uvāca |
jñānasya jñeyatāśāntiḥ kathaṃ brahmanpravartate |
sā rūḍhā bandhatābuddhiḥ kathaṃ vātra nivartate
]

`v 3 [
atra rāmaḥ sarveṣāmupakārāya prāksamāhitā api śaṅkāḥ
praśnottaramālikākramenodghāṭya samādhānakramaprakhyāpanakāmastadupāyaṃ
prathamaṃ pṛcchati - jñānasyeti | rūḍhā dṛḍhābhyastā | kathaṃ kenopāyena | 2
|
śrīvasiṣṭha uvāca |
samyagjñānena `note[samyajñānaprabodhena iti ṭīkākṛdabhimataḥ pāṭhaḥ |
] bodhena mandabuddhirnivartate |
nirākārā nijā śāntā muktirevaṃ pravartate
]

`v 4 [
śrīrāma uvāca |
bodhaḥ kevalatārūpaḥ samyagjñānaṃ kimucyate |
yena bandhādayaṃ janturaśeṣeṇa vimucyate
]

`v 5 [
śrīvasiṣṭha uvāca |
jñānasya jñeyatā nāsti kevalaṃ jñānamavyayam |
avācyamiti bodhontaḥ samyagjñānamiti smṛtam
]

`v 6 [
śrīrāma uvāca |
jñānasya jñeyatā bhinnā tvantaḥ keti mune vada |
utpādyo jñānaśabdaśca bhāve vā karaṇe'tha kim
]

`v 7 [
śrīvasiṣṭha uvāca |
bodhamātraṃ bhavejjñānaṃ bhāvasādhanamātrakam |
na jñānajñeyayorbhedaḥ pavanaspandayoriva
]

`v 8 [
śrīrāma uvāca |
evaṃ cettatkathamayaṃ jñānajñeyādivibhramaḥ |
siddhaḥ śaśaviṣāṇābho bhaviṣyadbhūtabhavyaśaḥ
]

`v 9 [
evaṃ cettattarhi sa vikalpaḥ śaśaviṣāṇakalpaḥ kathaṃ
pratyakṣādibhirbhūtabhavyabhaviṣyadvibhāgairvyavahārakṣamo bhāsate iti praśnārthaḥ |
8 |
śrīvasiṣṭha uvāca |
bāhyārthabhrāntito jñeyā bhramabuddhirihoditā |
bāhyaścābhyantaraścāryo na saṃbhavati kaścana
]

`v 10 [
śrīrāma uvāca |
yo'yaṃ pratyakṣadṛśyo'rtho mune tvamahamādikaḥ |
bhūtādiranubhūtātmā sa kathaṃ nāsti me vada
]

`v 11 [
śrīvasiṣṭha uvāca |
ādisargavidhāveva virāḍātmādiko'nagha |
jāto na kaścidevārtho jñeyasyāto na saṃbhavaḥ
]

`v 12 [
śrīrāma uvāca |
bhaviṣyadbhūtabhavyasthā jagaddṛṣṭiriyaṃ mune |
nityānubhūyamānāpi na jāteti kimucyate
]

`v 13 [
śrīvasiṣṭha uvāca |
svapnārthamṛgatṛṣṇāmbudvīndusaṃkalpitārthavat |
mithyā jagadahaṃtvaṃ ca bhāti keśoṇḍrakaṃ yathā
]

`v 14 [
śrīrāma uvāca |
ahaṃ tvamayamityādijagajjaṭharamapyalam |
kathaṃ na jātaṃ bhagavansargādāvanubhūtimat
]

`v 15 [
śrīvasiṣṭha uvāca |
kāraṇājjāyate kāryaṃ nānyathetyeva niścayaḥ |
sarvopaśāntau jagatāmutpattau nāsti kāraṇam
]

`v 16 [
śrīrāma uvāca |
mahāpralayasaṃpattau śiṣṭaṃ yadajamavyayam |
tatkathaṃ nāma sargasya na bhavetkāraṇaṃ mune
]

`v 17 [
śrīvasiṣṭha uvāca |
yadasti kāraṇe kāryaṃ tattasmātsaṃpravartate |
na tvasajjāyate rāma na ghaṭājjāyate paṭaḥ
]

`v 18 [
śrīrāma uvāca |
jagatsūkṣmeṇa rūpeṇa mahāpralaya āgate |
āste brahmaṇi tattasmātpunareva pravartate
]

`v 19 [
tarhi sāṃkhyābhimataguṇeṣviva brahmaṇi sūkṣmarūpeṇa tadā jagadastu iti praśnārthaḥ |
18 |
śrīvasiṣṭha uvāca |
mahāpralayaparyante kena sargāstitānagha |
anubhūtā mahābuddhe tatrasthā sā ca kīdṛśī
]

`v 20 [
śrīrāma uvāca |
jñaptyātmikā śrīstatrasthā tādṛśeranubhūyate |
vyomātmikā tu na bhavenna sattāmasadeti hi
]

`v 21 [
śrīvasiṣṭha uvāca |
evaṃ cettanmahābāho jñaptireva jagattrayam |
viśuddhajñānadehasya kuto maraṇajanmanī
]

`v 22 [
śrīrāma uvāca |
tadevamādito nāsti sargastadiyamāgatā |
kutaḥ kathamiva bhrāntiriti me bhagavanvada
]

`v 23 [
śrīvasiṣṭha uvāca |
kāryakāraṇatābhāvādbhāvābhāvau sta eva no |
idaṃ ca cetyate yadyatsvātmā cetati cetitam
]

`v 24 [
śrīrāma uvāca |
cetitā cetati yantraṃ draṣṭā dṛśyatvamīśvaraḥ |
kathameti kathaṃ vahniṃ dahetkāṣṭhaṃ kadā kila
]

`v 25 [
śrīvasiṣṭha uvāca |
draṣṭā na yāti dṛśyatvaṃ dṛśyasyāsaṃbhavādataḥ |
draṣṭaiva kevalo bhāti sarvātmaikaghanākṛtiḥ
]

`v 26 [
śrīrāma uvāca |
cinmātraṃ tadanādyantaṃ cetyaṃ cetayate tadā |
tadidaṃ jagadābhānaṃ kutaḥ syāccetyasaṃbhavaḥ
]

`v 27 [
śrīvasiṣṭha uvāca |
cetyaṃ hi kāraṇābhāvānna saṃbhavati kiṃcana |
cetyābhāvāccetanasya muktatā'vācyatā sadā
]

`v 28 [
śrīrāma uvāca |
evaṃ cettadahantādi cetyaṃ kathamidaṃ kutaḥ |
kathaṃ jagadvedanaṃ ca kathaṃ spandādivedanam
]

`v 29 [
śrīvasiṣṭha uvāca |
kāraṇāsaṃbhavādādāvevotpannaṃ na kiṃcana |
kutaścetyamataḥ śāntaṃ sarvaṃ sargastu vibhramaḥ
]

`v 30 [
śrīrāma uvāca |
atra me vigatollekhe niścetyacalanādike |
sakṛdvibhāte vimale vibhramaḥ kasya kīdṛśaḥ
]

`v 31 [
śrīvasiṣṭha uvāca |
kāraṇābhāvato rāma nāstyeva khalu vibhramaḥ |
sarvaṃ tvamahamityādi śāntamekamanāmayam
]

`v 32 [
śrīrāma uvāca |
brahmanbhramamivāpannaḥ praṣṭuṃ jānāmi nādhikam |
nātyantaṃ ca prabuddho'smi pṛcchāmi kimihādhunā
]

`v 33 [
śrīvasiṣṭha uvāca |
kāraṇasyaiva nikaṣaṃ pṛccha mā''kāraṇakṣayāt |
pare svabhāve'nirvācyai svayaṃ viśrāntimaiṣyasi
]

`v 34 [
śrīrāma uvāca |
manye'haṃ kāraṇābhāvātpūrvameva na sargatā |
uditā tena kasyāyaṃ cetyacetanavibhramaḥ
]

`v 35 [
śrīvasiṣṭha uvāca |
akāraṇatvātsarvatra śāntatvādbhrāntirasti no |
anabhyāsavaśādeva na viśrāmyati kevalam
]

`v 36 [
śrīrāma uvāca |
kuto bhavedanabhyāso bhavedabhyasanaṃ kutaḥ |
kuto'bhyāsātmikā bhrāntireṣā punarupasthitā
]

`v 37 [
śrīvasiṣṭha uvāca |
anantatvādanantasya bhrāntirnāsti ca saṃprati |
abhyāsabhrāntirakhilaṃ mahācidghanamakṣatam
]

`v 38 [
māstu kāpi bhrāntistathāpi jīvanmuktānāṃ cidghanātmakasarvavastubhirvyavahāra##-
śrīrāma uvāca |
upadeśyopadeśādāvanayā śabdasaṃpadā |
kimanyadvada me brahmansarvasmiñchāntatāṃ gate
]

`v 39 [
śrīvasiṣṭha uvāca |
upadeśyopadeśātma brahma brahmaṇi saṃsthitam |
bodhātmani na mokṣo'sti na bandho'stīti niścayaḥ
]

`v 40 [
śrīrāma uvāca |
deśakālakriyādravyabhedavedanacetasām |
sarvasyāsaṃbhave sarvasattā kathamupasthitā
]

`v 41 [
śrīvasiṣṭha uvāca |
deśakālakriyādravyabhedavedanacetasām |
ajñānamātrāditarā sattā nānyāsti no purā
]

`v 42 [
ajñānahetunaivetyuttaram | yato jīvanmukteḥ purā anyā tadanubhavasiddhā jagatsattā no |
41 |
śrīrāma uvāca |
bodhyabodhakatāpatterabhāvādbodhatā katham |
dvaitaikyāsaṃbhave brahmankāraṇāsaṃbhave sati
]

`v 43 [
śrīvasiṣṭha uvāca |
bodhena bodhatāmeti bodhaśabdastu bodhyatām |
bhavadviṣayamevāyamucito nāsmadādiṣu
]

`v 44 [
śrīrāma uvāca |
bodha eva yadāhaṃtvameti bodhānyatā tadā |
kuta eṣā pare'nante nāsāvatijale'male
]

`v 45 [
śrīvasiṣṭha uvāca |
yattadbodhasya bodhatvaṃ tadevāhaṃtvamucyate |
dvitvamatrānilaspandadṛśoriva nigadyate
]

`v 46 [
śrīrāma uvāca |
saumyābdhyantastaraṅgādiryathādatte yathāsthitam |
tathā svarūpamātrātma bodhyaṃ bodho'vabuddhavān
]

`v 47 [
śrīvasiṣṭha uvāca |
evaṃ cettatkathaṃ kaḥ syāddoṣo dvitvādidoṣataḥ |
anante sthita ekasmiñchānte pūrṇe pare pade
]

`v 48 [
śrīrāma uvāca |
ko'tra kalpayitāhaṃtvaṃ bhuṅkte bhoktā ca kaśca vā |
yanmūlaṃ yajjagadbhrāntiranantā pravijṛmbhate
]

`v 49 [
śrīvasiṣṭha uvāca |
jñeyasattāvabodhe hi bandhanaṃ sacca nāstyalam |
jñapteḥ sarvārtharūpatvādbandhamokṣāvataḥ kutaḥ
]

`v 50 [
śrīrāma uvāca |
jñapterbāhyārthatā dīpānnīlādīva pravartate |
bāhyastvartho'sti sadrūpo nanu dṛṣṭopalambhanaḥ
]

`v 51 [
śrīvasiṣṭha uvāca |
akāraṇasya kāryasya bāhyasyārthasya satyatā |
yeyaṃ sā bhrāntimātrātmarūpiṇī netarāṅgikā
]

`v 52 [
śrīrāma uvāca |
svapnaḥ satyo'stvasatyo vā duḥkhaṃ tāvatprayacchati |
tathaiveyaṃ jagadbhrāntiḥ ka upāyo'tra kathyatām
]

`v 53 [
śrīvasiṣṭha uvāca |
evaṃ tāvadyathā svapnastatheyaṃ cejjagatsthitiḥ |
tatpiṇḍagrahatārthānāṃ sarvaiva bhrāntitoditā
]

`v 54 [
śrīrāma uvāca |
kimetāvati saṃpanne saṃpannaṃ bhavati priyam |
kathaṃ ca śāmyatyarthānāṃ svapnādau piṇḍarūpatā
]

`v 55 [
śrīvasiṣṭha uvāca \/
pūrvāparaparāmarśātpiṇḍatārtheṣu śāmyati |
svapne'pyevaṃ sthite sthūlā bhāvanā vinivartate
]

`v 56 [
śrīrāma uvāca |
bhāvanā tanutāṃ yātā yasyāsau kiṃ prapaśyati |
kathaṃ śāmyati tasyāyaṃ saṃsārakuharabhramaḥ
]

`v 57 [
śrīvasiṣṭha uvāca |
uddhvastamasadābhāsamutpannanagaropamam |
varṣapronmṛṣṭacitrābhaṃ jagatpaśyatyavāsanaḥ
]

`v 58 [
śrīrāma uvāca |
tataḥ kiṃ tasya bhavati vāsanātānave sthite |
piṇḍagrahe gate'rthānāṃ svapnopamajagatsthiteḥ
]

`v 59 [
śrīvasiṣṭha uvāca |
saṃkalparūpajagataḥ kramātsāpi vilīyate |
vāsanā tasya tenāśu sa nirvāti vivāsanaḥ
]

`v 60 [
śrīrāma uvāca |
anekajanmasaṃrūḍhā śākhā prasavaśālinī |
bhavabandhakarī ghorā kathaṃ śāmyati vāsanā
]

`v 61 [
śrīvasiṣṭha uvāca |
yathābhūtārthavijñānādbhrāntimātrātmani sthite |
piṇḍagrahaviyukte'smindṛśyacakre kramātkṣayaḥ
]

`v 62 [
śrīrāma uvāca |
piṇḍagrahavimukte'smindṛśyacakre kramānmune |
saṃpadyate kimaparaṃ kathaṃ śāntiḥ prajāyate
]

`v 63 [
śrīvasiṣṭha uvāca |
piṇḍagrahabhrame śānte cittamātrātmatāṃ gate |
nirodhagauravonmukte jagatyāsthopaśāmyati
]

`v 64 [
śrīrāma uvāca |
bālasaṃkalparūpe'sminsthite jagati bhāsure |
kathamāsthopaśamanaṃ tādṛgduḥkhāya kiṃ naraḥ
]

`v 65 [
śrīvasiṣṭha uvāca |
saṃkalpamātrasaṃpanne naṣṭe duḥkhaṃ kathaṃ bhavet |
saṃkalpacittamātraṃ yattattāvatpravicāryatām
]

`v 66 [
śrīrāma uvāca |
kīdṛśaṃ bhagavaṃścittaṃ kathaṃ tatpravicāryate |
kiṃ ca saṃpadyate brūhi tasminsamyagvicārite
]

`v 67 [
śrīvasiṣṭha uvāca |
citaścetyonmukhatvaṃ yattaccittamiti kathyate |
vicāra eṣa evāsya vāsanānena śāmyati
]

`v 68 [
eṣaḥ sāṃprataṃ tvayā māṃ puraskṛtya kriyāmāṇo mahārāmāyaṇaśravaṇarūpa eva |
67 |
śrīrāma uvāca |
kiyannāma bhavedbrahmanna cetyonmukhatā citeḥ |
cittasyācittatodeti kathaṃ nirvāṇakāriṇī
]

`v 69 [
śrīvasiṣṭha uvāca |
cetyaṃ na saṃbhavatyeva citkiṃ cetayate kutaḥ |
cetyāsaṃbhavataścittasattā nāsti tataściram
]

`v 70 [
śrīrāma uvāca |
kathaṃ na saṃbhavatyetaccetyaṃ yadanubhūyate |
apahnavaścānubhave kriyate kathamīdṛśaḥ
]

`v 71 [
śrīvasiṣṭha uvāca |
yādṛksyādajñaviṣayaṃ jagattasya na satyatā |
yādṛkca tajjñaviṣayaṃ tadanākhyaṃ yadadvayam
]

`v 72 [
śrīrāma uvāca |
trijagatkīdṛgajñānāṃ kathaṃ tasya na satyatā |
tajjñānāṃ tu jagadyādṛktadvaktuṃ kiṃ na yujyate
]

`v 73 [
śrīvasiṣṭha uvāca |
ādyantadvaitamajñānāṃ tajjñānāṃ tanna vidyate |
jagacca no saṃbhavati nityānutpannamāditaḥ
]

`v 74 [
śrīrāma uvāca |
ādito yadanutpannaṃ na saṃbhavati karhicit |
asadrūpamanābhāsaṃ kathaṃ tadanubhūyate
]

`v 75 [
śrīvasiṣṭha uvāca |
asadeva sadābhāsamanutpannamakāraṇam |
jāgratsvapnavadudbhūtamarthakṛccānubhūyate
]

`v 76 [
śrīrāma uvāca |
svapnādau kalpanādau ca yaddṛśyamanubhūyate |
tajjāgradrūpasaṃskārādanuṣṭhānānubhūtitaḥ
]

`v 77 [
śrīvasiṣṭha uvāca |
kiṃ jāgradrūpamāhosvidanyatsvapne'nubhūyate |
saṃkalpe ca manorājye iti me vada rāghava
]

`v 78 [
śrīrāma uvāca |
svapneṣu kalpanādyeṣu jāgradevāvabhāsate |
saṃskārātmatayā nityaṃ manorājyabhrameṣu ca
]

`v 79 [
śrīvasiṣṭha uvāca |
tadeva jāgratsaṃskārātsvapnaścedavabhāsate |
tatsvapne luṭhitaṃ gehaṃ kathaṃ prātaravāpyate
]

`v 80 [
śrīrāma uvāca |
na jāgradājate svapne tadbrahmānyattadeva hi |
buddhametatkathaṃ tvanyadapūrvamiva bhāsate
]

`v 81 [
śrīvasiṣṭha uvāca |
nānubhūto'nubhūtaśca cetasyartho'vabhāsate |
sargādyantādimadhyeṣu svabhyastastviti bhāsate
]

`v 82 [
śrīrāma uvāca |
evaṃ svapnātmakaṃ bhāti jagadityeva buddhavān |
grahavatsvapnayakṣo'yaṃ kathaṃ brahmaṃścikitsyate
]

`v 83 [
śrīvasiṣṭha uvāca |
yo'yaṃ saṃsaraṇasvapnaḥ sa kiṃkāraṇako bhavet |
kāryānna kāraṇaṃ bhinnamiti dṛṣṭaṃ vicāraya
]

`v 84 [
śrīrāma uvāca |
cittaṃ svapnopalambhānāṃ hetustasmāttadeva te |
viśvaṃ cādyantarahitamanāsāramanāmayam
]

`v 85 [
śrīvasiṣṭha uvāca |
evaṃ cittaṃ mahābuddhe mahācidghanameva tat |
tathāsthitaṃ na svapnādi kiṃcanāstītarātmakam
]

`v 86 [
śrīrāma uvāca |
avayavāvayavinoryathā bhinnastathā sa hi |
tatrānavayave brahmaṇyekatā jagadādinā
]

`v 87 [
śrīvasiṣṭha uvāca |
evaṃ na saṃbhavatyeva nityānutpannamāditaḥ |
jagattenājaraṃ śāntamajaṃ sarvamavedhitam
]

`v 88 [
śrīrāma uvāca |
kākatālīyavanmanye sargādyāntādayo bhramāḥ |
bhrāntidraṣṭṭatvabhoktṛtvasahitāḥ parame pade
]

`v 89 [
śrīvasiṣṭha uvāca |
yā vyāpāravatī rasādrasavidāṃ kācitkavīnāṃ navā dṛṣṭiryā
pariniṣṭhitārthaviṣayonmeṣā ca vaipaścitī |
te dve apyavalambya viśvamakhilaṃ nirvarṇitaṃ nirvṛtaṃ yāvaddṛṣṭidṛśo
na santi kalitā no śūnyatā no bhramaḥ
]