`v 1 [
ekasaptatyadhikaśatatamaḥ sargaḥ 171
śrīvasiṣṭha uvāca |
saṃvidākāśakacanamidaṃ bhāti jagattayā |
vastuto na jagannābhā na śūnyaṃ na ca saṃvidaḥ
]

`v 2 [
yadidaṃ bhāti cidvyoma jagadākhyaṃ na tattataḥ |
ākāśādiva śūnyatvamanyadanyadapi sthitam
]

`v 3 [
deśāddeśāntaraprāptau madhye yatsaṃvido vapuḥ |
taddṛśyamiti bhātīdaṃ dṛśyamanyanna vidyate
]

`v 4 [
mahāpralayasaṃpattāvādisargaḥ punaḥ kila |
parasmātkāraṇābhāve kuto dṛśyasya saṃbhavaḥ
]

`v 5 [
tadāṇumātramapi hi dṛśyabījaṃ na vidyate |
kila yasmādidaṃ cakraṃ punarmūrtaṃ pravartate
]

`v 6 [
utpannameva naivāto mūrtaṃ dṛśyamidaṃ jagat |
vandhyāputra ivātyantamato'styeva na dṛśyadhīḥ
]

`v 7 [
yaccedaṃ kiṃcidābhāti dṛśyamityabhitaḥ sthitam |
taccinmātraṃ khamevācchaṃ parameva padaṃ viduḥ
]

`v 8 [
yathā suṣuptātsvapnatvaṃ gacchadyātyanavasthitim |
cinmātramajahatsvacchaṃ nijaṃ rūpamanāmayam
]

`v 9 [
sargasyādau tathaivedamātmaiva svātmanātmani |
vyomātmaiva cidābhāsaṃ dṛśyamityavabhāsate
]

`v 10 [
suṣuptātsvapnagamanavatpralayātsargagamanamapi tathā bodhyamityāha - sargasyeti | 9
|
yathā puratayā bhāti manaḥ saṃkalpamantharam |
tathā dṛśyamivābhāti sargādau cinnabhaḥ param
]

`v 11 [
yathātmanyanilaḥ spandaścakrāvartavadīhate |
sargādau cinnabhaḥ sthitvā dṛśyamityeva tiṣṭhati
]

`v 12 [
ato jñātamanābhātameva dṛśyaṃ jagattrayam |
brahmaivedaṃ paraṃ bhāti svātmanītthamavasthitam
]

`v 13 [
nāstyeva mūrtaṃ pṛthvyādi kiṃcanāpi kadācana |
astu mūrtamamūrtaṃ vā brahmaivedaṃ virājate
]

`v 14 [
prabodhakāle svapnādriryathā vyomaiva nirvapuḥ |
tathedaṃ śāntacinmātraṃ khaṃ prabodhe jagattrayam
]

`v 15 [
prabuddhānāṃ paraṃ brahma nirvibhāgamidaṃ jagat |
dhīmanto'pi na tadvidmo yadidaṃ tvaprabodhanam
]

`v 16 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
svasvabhāvo hi bhūtānāṃ tatpadaṃ paramātmakam
]

`v 17 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
etattatparamākāśamatra sarvaṃ pratiṣṭhitam
]

`v 18 [
yādṛgetatpadaṃ tādṛgidaṃ sadasadātmakam |
yenārthapañcakādanyatkiṃcanāpi na vidyate
]

`v 19 [
rūpālokamanaskārā etadeva padaṃ viduḥ |
ete te dravatāvartāḥ padasyāsya mahāmbhasaḥ
]

`v 20 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
etasyāvyatirekeṇa jagattā nāsti kācana
]

`v 21 [
rāgadveṣādayo bhāvā bhāvābhāvadṛśastathā |
etadrūpamamuñcanta etasyāvayavāḥ sthitāḥ
]

`v 22 [
tyaktvā pūrvāpare koṭyau madhye yatsaṃvido vapuḥ |
sa svabhāvaḥ paro jñeyo jagatpayasi saṃjñitaḥ
]

`v 23 [
deśāddeśāntaraprāptau viddhi madhyamasaṃvidaḥ |
jagadityaparaṃ nāma svrūpādacyutātmanaḥ
]

`v 24 [
ādisargātprabhṛtyeva dṛśyamutpannameva no |
yannāma tadihāstīti māyāśambaraḍambaraḥ
]

`v 25 [
kaṣṭaṃ nāstyeva yaddṛśyaṃ tadapyastīti saṃsthitam |
yadapyasti paraṃ brahma kaṣṭaṃ nāstīti tatsthitam
]

`v 26 [
abrahmaṇyaṃ kva gacchāmi viparītamato jagat |
asaddṛśyaṃ sadityuktaṃ brahmaivaṃ nāvagamyate
]

`v 27 [
na cotpannaṃ na cābhāti dṛśyaṃ kiṃcana kutracit |
yadidaṃ bhāti tadbrahma vyomaiva kacati svayam
]

`v 28 [
yathā maṇiḥ prakacati svabhāsā'vyatiriktayā |
ātmano'nanyayā `note[svātmanaḥ iti ṭīkānuguṇaḥ pāṭhaḥ |] sṛṣṭyā
cidvyoma kacitaṃ tathā
]

`v 29 [
tasminneva pade śānte tapatyeṣa divākaraḥ |
tasyaivāvayavaścaiva na nāmānyo'sti bhāskaraḥ
]

`v 30 [
sthito'pi tatra na tapatyarko na ca niśākaraḥ |
prakāśayati devo'sāvarkaṃ nārkastamīśvaram
]

`v 31 [
tasya bhāsā vibhātīdaṃ tadaho dṛśyamaṇḍalam |
sarvacandrārkavahnīnāṃ padārthānāṃ sa dīpakaḥ
]

`v 32 [
sa sākāro nirākāra iti śabdārthakalpanā |
khapuṣpavadasadrūpā na saṃbhavati tadvidām
]

`v 33 [
sāṅgabhūto yathaiko'ṇurbhāti jīvārkatejasi |
na bhānti bhānti vā tatra tathā sūryādayo'ṇavaḥ
]

`v 34 [
cinmātrākāśaratnasya sṛṣṭayo'rkādisaṃyutāḥ |
yā bhāsastāḥ kathaṃ tasmādvyatiriktāḥ syurucyatām
]

`v 35 [
cinmātreṇāpi rahitaṃ śūnyatvenāpi varjitam |
padaṃ sarvātmariktaṃ tatsarvārthaiśca samanvitam
]

`v 36 [
pṛthvyādīnyapi santyeva tatra santi na kānicit |
jīvanto'pi na vidyante jīvāstatra ca kecana
]

`v 37 [
atyajanto dvayasthaulyaṃ tatraite paramāṇavaḥ |
svarūpamatyajaddvaitamaikyaṃ vātra na kiṃcana
]

`v 38 [
kiṃcidatra na kiṃcidvai na kiṃcicca na kiṃcana |
kiṃcinna kiṃcidityeṣā kalanātrātidūragā
]

`v 39 [
ekā nirantarānantā nityamatyātatātmanā |
cinmātravyomasattaiva jagannāmnātmani sthitā
]

`v 40 [
ekaṃ cetyaṃ tyaktavatyā aprāptāyāścito'param |
yadrūpaṃ jagato rūpamasya nānātmano'pi tat
]

`v 41 [
nānevedamanānaiva cidvyomaivedamātatam |
bhūtapañcakarūpeṇa svapne citiriva sthitam
]

`v 42 [
suṣuptādviśataḥ svapnaṃ suṣuptasthaiva cidyathā |
yathā sthitaiva svapnatvametyevaṃ sargatāmimām
]

`v 43 [
yādṛksuṣuptaṃ svapnatu tādṛgeva tathaiva ca |
jāgratturyaṃ tathaivedamato vyomasamaṃ jagat
]

`v 44 [
jāgratsvapnaḥ suṣuptaṃ ca turyamevākhilaṃ sthitam |
tattvavidgotramūḍhastu yadvai vetti na vedmi tat
]

`v 45 [
jaḍānāmajaḍānāṃ yaḥ sarvārthānāmanāratam |
durlakṣyapariṇāmo'ntarmanobuddhyādivarjitaḥ
]

`v 46 [
suśuddhāyāścito rūpaṃ padārthāstanmayāśca te |
te vasanti na sadrūpāstadeva hi tathā sthitam
]

`v 47 [
pariṇāmādiśabdārthadṛśāmata ihānagha |
upadeśārthamuktīnāṃ gandho'pyevaṃ na vidyate
]

`v 48 [
ādisargātprabhṛtyeva mahāsattātmanātmani |
cinmātraparamākāśaṃ sthitamekaṃ mahātmanaḥ
]

`v 49 [
prapūrṇaikātmani prakhyā sā sarvavyāpinī citiḥ |
sthitā tayātmanyevāntarjagadityabhidhāḥ kṛtāḥ
]

`v 50 [
parijñāte yathā svapne svāṅgīkārātsukhaṃ sukham |
anaṅgīkārato duḥkhaṃ saduḥkhaṃ bhavati kṣaṇāt
]

`v 51 [
gacchatastiṣṭhataścaiva jāgrataḥ svapatastathā |
nityamekaṃ samādhānaṃ sthitaṃ śāntasya tadvidaḥ
]

`v 52 [
bhede'pyabhedaniṣṭhasya duḥkhe'pi hi sukhasthiteḥ |
sato'pyevāsato jñasya kimanyadavaśiṣyate
]

`v 53 [
na saṃtyajati nādatte kiṃcidvyavaharannapi |
hṛdayena bahiḥkārye'kārya evāvatiṣṭhate
]

`v 54 [
yathā himasya śītatvaṃ vahnerauṣṇyaṃ tathedṛśaḥ |
svabhāvo'sya bhavennityaṃ na tvāhāryo guṇo'sya saḥ
]

`v 55 [
yasya tveṣa svabhāvaḥ syānna nāma na sa tattvavit |
etadevājñatācihnaṃ yadicchā prakṛtetarā
]

`v 56 [
āśvastāntaḥkaraṇaḥ kṣīṇavikalpaḥ svarūpasāramayaḥ |
paramaśamāmṛtatṛptastiṣṭhati vidvānnirāvaraṇaḥ
]