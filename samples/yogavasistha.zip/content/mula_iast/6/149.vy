`v 1 [
ekonapañcāśadadhikaśatatamaḥ sargaḥ 149
vyādha uvāca |
anantaraṃ mune brūhi tattattvaṃ jāgatasya te |
kiṃ vṛttamuruvṛttāntaśatanirvāṇasaṃsṛteḥ
]

`v 2 [
muniruvāca |
tataḥ śṛṇu tadā sādho tasmiṃstaddhṛdayaujasi |
apūrva eva vṛttāntaḥ ko vṛtto vṛttasaspṛha
]

`v 3 [
tathā mama ca tatrasthavismṛtātmacamatkṛteḥ |
abhyavartata vai kālo ṛtusaṃvatsarātmakaḥ
]

`v 4 [
kalatrarañjitamatermama varṣāṇi ṣoḍaśa |
tatra tāni vyatītāni gṛhasthāśramato'mateḥ
]

`v 5 [
kadāciccājagāmātha gṛhamugratapā mama |
munirmānyo mahābodho budho'tithitayā tathā
]

`v 6 [
so'tra saṃpūjitastuṣṭaḥ suptavānmuktavāṃstataḥ |
idamaṅga mayā pṛṣṭo vimṛśya janatākramam
]

`v 7 [
bhagavanbhūribodho'si jānāsi jagato gatīḥ |
yasmādadṛṣṭakrodho'si sukhe gṛhṇāsi no ratim
]

`v 8 [
sukhaduḥkhānyupāyānti karmabhiḥ karmaśālinām |
śubhāśubhaiḥ śaratkāle sasyānīva phalārthinām
]

`v 9 [
samamevāśubhaṃ karma kimimāḥ sakalāḥ prajāḥ |
kurvantyāsāṃ yadā yānti doṣāḥ sarvādayaḥ samam
]

`v 10 [
durbhikṣāvagrahotpātaṃ sarvādi samameva kim |
janajālasya phalati samānā kasya duṣkriyā
]

`v 11 [
ityākarṇya samālokya smayamāna ivonmanāḥ |
sa uvāca vaco vandyamamṛtasyandasundaram
]

`v 12 [
anyamuniruvāca |
sādho sādhu viviktāntaḥkaraṇe yattu kāraṇam |
sadvāsadvāsya dṛśyasya kasmājjānāsi kathyatām
]

`v 13 [
saṃsmarātmānamakhilaṃ kastvaṃ kveha sthito'si ca |
kvāhaṃ vā kimidaṃ dṛśyaṃ kiṃ sāraṃ kiṃcideva ca
]

`v 14 [
tatra vivekāsāmarthyāttūṣṇīṃbhūtaṃ māṃ nirīkṣya saḥ prāktanasarvavṛttāntaiḥ saha
tatsākṣiṇamātmānaṃ smaretyāha - saṃsmareti | kiṃcittucchamasārameva ca kim | 13
|
svapnamātramidaṃ bhāti kila kasmānna vetsi bho |
ahaṃ svapnanaro yatte tvaṃ svapnapuruṣopamaḥ `note[mameti pāṭhaḥ |]
]

`v 15 [
anākāramanākhyeyamanādyamapakalpanam |
idaṃ cinmātrakācasya kācakacyaṃ jagatsthitam
]

`v 16 [
rūpamīdṛśamevāsya cinmātrasyāstyakṛtrimam |
sarvagasya yadetadyadyatra vetyasti tatra tat
]

`v 17 [
sakāraṇatvakalanātsarvamasya sakāraṇam |
akāraṇatvakalanādasya sarvamakāraṇam
]

`v 18 [
āsāṃ prajānāṃ tvasmākaṃ virāḍātmā sa ātataḥ |
vayaṃ hṛdi sthitā yasya sa cāsmaccidvaśāditaḥ
]

`v 19 [
bhaviṣyatyaparo'nyāsāṃ virāḍātmā sa eva ca |
kāraṇaṃ sukhaduḥkhānāṃ bhāvābhāvātmakarmaṇām
]

`v 20 [
virāḍdhātuvikāreṇa viṣamaspandanādinā |
tadaṅgāvayavasyāsya janajālasya vai samam
]

`v 21 [
durbhikṣāvagrahātītamāyāti śamameti vā |
yasmādvirājo yā sattā sā sargasyāsya sargatā
]

`v 22 [
kākatālīyavatsādho keṣucidduṣṭakarmasu |
samaṃ patati duḥkhādi pādapeṣvaśaniryathā
]

`v 23 [
karmakalpanayā saṃvit svakarmaphalabhāginī |
karmakalpanayonmuktā na karmaphalabhāginī
]

`v 24 [
yā yā yatra yathodeti kalpanālpāthavādhikā |
sā sā tatra tathaivāste sahetukamahetukam
]

`v 25 [
nāstyeva svapnamaye kāraṇasahakāri kāraṇādipure |
tasmāttadanādi śivaṃ cetanamajaraṃ paraṃ brahma
]

`v 26 [
eṣa svapnabhramo nāma bhāti kaścidakāraṇam |
kaścitsakāraṇo bhāti śūnyaḥ sadasadātmakaḥ
]

`v 27 [
kākatālīyavadbhānti svapnāḥ sakalasaṃvidaḥ |
tābhyastulyopalambhatvānnānyajjagadidaṃ tatam
]

`v 28 [
sakāraṇatayā rūḍhamiha yattatsakāraṇam |
akāraṇatayā rūḍhamiha yattadakāraṇam
]

`v 29 [
kāryakāraṇamayakramoditaṃ svapna eṣa citibhānamātrakam |
jāgradākhyamahataḥ svabhāvakaṃ tena śāntamakhilaṃ paraṃ viduḥ
]

`v 30 [
satyakāraṇakā bhāvāḥ ke te śṛṇu mahāmate |
kāraṇaṃ kiṃ svabhāvānāṃ kimihākāśakāraṇam
]

`v 31 [
nanu sarvabhāvānāṃ satyaṃ brahmaiva kāraṇamastu | satyakāraṇakatvācca te'pi satyāḥ
santu | tathā ca kathaṃ sarva brahmaiva kathaṃ vā satyādvaitaṃ tatrāha -
satyakāraṇakā iti | he mahāmate asyāṃ śaṅkāyāmuttaraṃ te'haṃ vadāmi | tvaṃ
śṛṇu | ke te bhāvā āyuṣmataḥ satyakāraṇakā abhimatāḥ | kiṃ svabhāvānāṃ satyaṃ
kāraṇam | kiṃ satyasvabhāvānāṃ satyaṃ kāraṇamuta mithyāsvabhāvānām | kiṃ
sajātīyānāmuta vijātīyānām | ādyayorbrahmaṇo brahmaivotpadyeta na jagat | dvitīyayorna
brahmajasya satyatāsiddhirityakāraṇatvameva phalata iti kiṃ tvayā sādhitaṃ syāt | kiṃ ca
sarveṣu kalpeṣu pṛcchāmaḥ | kimihākāśasya kāraṇam |
ādyakalpayorākāśapadavācyatāvacchedakavailakṣaṇyāsiddhirdvitīyayostatsatyatvā##-
pṛthvyāderghanapiṇḍatvasargādeḥ kiṃ ca kāraṇam |
kiṃ kāraṇamavidyāyāḥ kāraṇaṃ kiṃ svayaṃbhuvaḥ
]

`v 32 [
sargādau kāraṇaṃ kiṃ syādvāyūnāṃ tejasāṃ ca kim |
kimapāṃ vedanāmātrarūpāṇāṃ gaganātmakam
]

`v 33 [
piṇḍagrahe dehalābhe mṛtānāṃ kiṃ ca kāraṇam |
evameva pravartante sargāḥ prathamato'khilāḥ
]

`v 34 [
evameva pravartante jagatyāvalayanti ca |
cakrakāṇīva nabhasi cirasaṃprekṣaṇādṛśā
]

`v 35 [
evameva pravṛttena sargeṇa brahmarūpiṇā |
paścātyasvasyaiva rūpasya saṃjñāḥ pṛthvyādikāḥ kṛtāḥ
]

`v 36 [
vātaspandavadābhānti sargāḥ pūrvaṃ cidambare |
svayameva ca kurvanti dehakāraṇakalpanāḥ
]

`v 37 [
yadyathā kalpyate dhatte tattathā niyatirvapuḥ |
kalpitāyāściteryasmādevametannijaṃ vapuḥ
]

`v 38 [
yadyadbhānātmakaṃ rūpaṃ prathamaṃ cetitaṃ citā |
svato'hameva cityeva tadadyāpi tathā sthitam
]

`v 39 [
punaranyena yatnena tadutkṛṣṭena saiva cit |
śaktā tadanyathākartuṃ yatnena mahatā punaḥ
]

`v 40 [
kalpyate kāraṇaṃ yatra tatra kāraṇasāratā |
na kalpyate vidā yatra kāraṇaṃ tadakāraṇam
]

`v 41 [
vātyāvartavadābhātamidaṃ prathamamātatam |
asadeva yathā bhātaṃ tathaivādyāpi saṃsthitam
]

`v 42 [
saṃbhūya kecana śubhāśubhamātmakarma kurvanti tasya sadṛśaṃ
phalamāpnuvanti |
saṃprāpnuvanti ca śilāśanivacca kecidduḥkhaṃ tvakāraṇakameva
sahasrasaṃkhyāḥ
]