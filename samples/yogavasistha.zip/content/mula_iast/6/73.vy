`v 1 [
trisaptatitamaḥ sargaḥ 73
śrīrāma uvāca |
bandhamokṣajagadbuddhirna śūnyā nāpi sanmayī |
nāstameti na codeti kimapyādyamasau kila
]

`v 2 [
upadiṣṭamidaṃ brahmaṃstvayā budhamalaṃ mayā |
bhūyaḥ kathaya tṛptirhi śṛṇvato nāsti me'mṛtam
]

`v 3 [
sargādisaṃbhramadṛśaḥ śūnyatādidṛśastathā |
na kāścana vibho satyā asatyāśca na kāścana
]

`v 4 [
satyā abādhitārthāḥ asatyā bādhitārthā api na | tattadvyavahartṛdṛśā brahmaṇa eva
tathāsthiterarthakriyā'visaṃvādādasatkāryapakṣānabhyupagamātsarvaśaktimati brahmaṇi
sarvaśūnyatāpādanaśakterapi saṃbhavānmāyayā sarvavirodhaparihārācceti bhāvaḥ | 3
|
evaṃsthite tu yatsatyaṃn tatsarvaṃ buddhavānaham |
tathāpi bhūyobodhāya sargānubhava ucyatām
]

`v 5 [
śrīvasiṣṭha uvāca |
yadidaṃ dṛśyate kiṃcijjagatsthāvarajaṅgamam |
sarvaṃ sarvaprakārāḍhyaṃ deśakālakriyādimat
]

`v 6 [
tasya nāśe mahānāśe mahāpralayanāmani |
brahmopendramarudrudramahendrapariṇāmini
]

`v 7 [
śiṣyate śāntamatyacchaṃ kimapyajamanādi sat |
yato vāco nivartante kimanyadavagamyate
]

`v 8 [
sarṣapāpekṣayā meruryathātivitatākṛtiḥ |
tathākāśamapi sthūlaṃ śūnyaṃ sadyadapekṣayā
]

`v 9 [
śailendrāpekṣayā sūkṣmā yatheme trasareṇavaḥ |
tathā sūkṣmataraṃ sthūlaṃ brahmāṇḍaṃ yadapekṣayā
]

`v 10 [
amānakalite saumye kāle pariṇate ciram |
śānte tasminpare vyomanyādye hyanubhavātmani
]

`v 11 [
asaṃkalpo mahāśānto dikkālairabhitākṛtiḥ |
antarmahāṃścidākāśo vettīva paramāṇutām
]

`v 12 [
asatyāmeva tāmantarbhāvayansvapnavatsvataḥ |
tataḥ sa brahmaśabdārthaṃ vetti cidrūpatāṃ tatām
]

`v 13 [
cidbhāvo'nubhavatyantaścittvāccidaṇutāṃ nijām |
tāmeva paśyatīvātha `note[paśyatīvāntariti pāṭhaḥ |] tato draṣṭeva tiṣṭhati |
13 |
tadgocaratālakṣaṇe tadvedane citsvabhāvātirikto heturdurnirūpa ityāha - cidbhāva iti |
tenaiva draṣṭṭatāsaṃpattiṃ darśayati - tāmeveti
]

`v 14 [
yathā svapne mṛtaṃ paśyatyeka evātmanātmani |
mṛta eva mṛterdraṣṭā tathā cidaṇurātmani
]

`v 15 [
tatścidbhāva eṣo'ntareka eva dvitāmiva |
paśyansvarūpa evāste draṣṭṭadṛśyamiva sthitaḥ
]

`v 16 [
cidbhāvaśūnya evātinirākāro'pyaṇuṃ tanum |
paśyandṛśyamivodeti draṣṭeva ca tadā dvitām
]

`v 17 [
prakāśamaṇumātmānaṃ paśyaṃstadanubhāvataḥ |
ucchūnatāṃ cetayate bījamaṅkuratāmiva
]

`v 18 [
deśakālakriyādravyadraṣṭṭadarśanadṛgdṛśaḥ |
arthāntarasvabhāvena tiṣṭhantyanuditābhidhāḥ
]

`v 19 [
cidaṇuryatra bhāto'sau deśo mitimupāgataḥ |
yadā bhātastadā kālo yadbhānaṃ tatkriyā smṛtā
]

`v 20 [
upalabdhaṃ vidurdravyaṃ draṣṭṭatāpyupalabdhatā |
ālokanaṃ darśanatā dṛgālokanakāraṇam
]

`v 21 [
evamucchūnatā bhāti mitānantātha vā kramāt |
asatyaiva nabhasyeva nabhorūpaiva niṣkramā
]

`v 22 [
cidaṇorbhāsanaṃ bhātaṃ tatpradeśena dehagam |
yena paśyati taccakṣuḥ saṃgraho'kṣadṛśāmiti
]

`v 23 [
tatra rūpāditripuṭīsiddhau cakṣurādikaraṇavibhāgakalpanādi nantarīyakī bhavatīti
saṃkṣepeṇa darśayati - cidaṇoriti | cidaṇorjīvasya bhātaṃ bhāsanaṃ saurādyālokaṃ
yena golakapradeśena cchidreṇa yena cātīndriyeṇa karaṇena paśyati tadubhayaṃ cakṣuḥ |
sarvāsāṃ śrotrādyakṣadṛṣṭīnāmapyayaṃ nyāyaḥ sama iti saṃgrahaḥ saṃkṣepaḥ | 22
|
cidaṇupratibhāse'ntaḥ prathamaṃ nāmavarjitam |
tanmātraśabdameteṣāmetadākāśarūpi tat
]

`v 24 [
cidaṇupratibhakāśapiṇḍa eva ghanasthitiḥ |
anusaṃdhānavivaśaścetatīndriyapañcakam
]

`v 25 [
evaṃ cidaṇusaṃdhānaṃ dṛśyapoṣamupaityalam |
tadeva jñānamityuktaṃ buddhirityabhidhīyate
]

`v 26 [
tato manastadārūḍhamahaṃkārapadaṃ gatam |
deśakālapariccheda ityaṅgīkṛta ātmanā
]

`v 27 [
cidaṇorasya bhāvasya pratyagraṃ yatra vedanam |
sa tatrottarakālena pūrvābhikhyāṃ kariṣyati
]

`v 28 [
anyasminnekadeśe sā ūrdhvābhikhyāṃ kariṣyati |
evaṃ digabhidhanādi kalpayiṣyati sa kramāt
]

`v 29 [
deśakālakriyādravyaśabdānāmarthavedanam |
bhaviṣyati svayamasāvākāśaviśado'pi san
]

`v 30 [
itthaṃ svānubhavenaiṣa vyomnaiva vyomarūpabhṛt |
ātivāhikanāmāntardehaḥ saṃpadyate citeḥ
]

`v 31 [
eṣa eva ciraṃ kālaṃ tatra bhāvanayā tayā |
gṛhṇāti niścayaṃ pūrṇamādhibhautikamātmanaḥ
]

`v 32 [
vyomnā vyomnyeva racito nirmaleneti vibhramaḥ |
asatā satsamāstīrṇastāpanadyā jalaṃ yathā
]

`v 33 [
saṃkalpanāmupādatte svadehe gaganākṛtiḥ |
śiraḥśabdārthadāṃ kāṃcitpādaśabdārthadāṃ kvacit
]

`v 34 [
uraḥpārśvādiśabdārthamayīṃ kvacidanāvilām |
bhāvābhāvagrahotsargaśabdādyarthamayīmapi
]

`v 35 [
niyatākārakalanāṃ deśakālādiyantritām |
viṣayonmukhatāṃ yātāmindriyavrātavedhitām
]

`v 36 [
soṇuḥ paśyatyathākāramātmanaḥ svātmakalpitam |
hastapādādikalitaṃ cittādikalanānvitam
]

`v 37 [
evaṃ saṃpadyate brahmā tathā saṃpadyate hariḥ |
evaṃ saṃpadyate rudra evaṃ saṃpadyate kṛmiḥ
]

`v 38 [
na ca kiṃcana saṃpannaṃ yathāsthitamavasthitam |
śūnyaṃ śūnye vilasitaṃ jñaptirjñaptau vijṛmbhitā
]

`v 39 [
pratikandaḥ śarīrāṇāṃ bījaṃ trailokyavīrudhām |
sargārgalaprado mukteḥ saṃsārāsāravāridaḥ
]

`v 40 [
kāraṇaṃ sarvakāryāṇāṃ netā kālakriyādiṣu |
sarvādyaḥ puruṣaḥ svairamityanutthita utthitaḥ
]

`v 41 [
nāsya bhūtamayo deho nāsyāsthīni śarīrake |
avaṣṭabdhumasau muṣṭyā śakyate na tu kenacit
]

`v 42 [
tenābdhimeghasaṃgrāmasiṃhagarjorjitātmanā |
api suptanareṇeva nūnaṃ maunavatā sthitam
]

`v 43 [
jāgrataḥ svapnasaṃdṛṣṭayodghrārabhaṭivedanam |
yathā smṛtigataṃ nāsanna sattadvadasau sthitaḥ
]

`v 44 [
bahuyojanalakṣaughapramāṇo'pi bṛhadvapuḥ |
paramāṇvantare bhāti lomāntasthajagattrayaḥ
]

`v 45 [
kulaśailaguṇaighātmā jagadvṛndātmako'pi san |
kulāyaṃ dhānakāmātramapi no pūrayatyajaḥ
]

`v 46 [
jagatkoṭiśatābhogavistīrṇo'pyaṇumātrakam |
vastuto vyāptavāneṣa na deśaṃ svapnaśailavat
]

`v 47 [
svayaṃbhūreṣa kathito virāḍeṣa sa ucyate |
brahmāṇḍātmā jagaddeho vastutastu nabhomayaḥ
]

`v 48 [
sanātana iti prokto rudra ityapi saṃjñitaḥ |
indropendramarunmeghaśailajālādidehakaḥ
]

`v 49 [
tejoṇumātraṃ prathitaṃ cetitvātprathamaṃ vapuḥ |
krameṇa sphārasaṃvittirmahānahamiti sthitaḥ
]

`v 50 [
spandasaṃvedanāttena spanda ityanubhūyate |
yaḥ sa evānilābhikhyo vātaskandhātmanā sthitaḥ
]

`v 51 [
prāṇāpānaparispando vedanādanubhūyate |
tena yaḥ so'yamākāśe vātaskandha udāhṛtaḥ
]

`v 52 [
cittādye kalpitāstena bāleneva piśācikāḥ |
tejaḥkaṇā asanto'pi ta etedhiṣṇyatāṃ gatāḥ
]

`v 53 [
prāṇāpānaparāvartadolā tadudaroditā |
vātaskandhābhidhāṃ dhatte jagattaddhṛdayaṃ mahat
]

`v 54 [
praticchandaśarīrāṇāṃ prathamaṃ bījameṣa saḥ |
jagadgatānāṃ sarveṣāmakalpavyavahāriṇām
]

`v 55 [
praticchandyādyadetasmādutthitā jagadātmanā |
dehāstadā yathā bāhyamantareṣāṃ tathā sthitam
]

`v 56 [
citistasyādyabījasya pūrvameva yathoditā |
tathaivādyapi jīve'ntastathodeti tadīhitā
]

`v 57 [
śleṣmapittānilāstasya candrārkapavanāstrayaḥ |
grahā ṛkṣagaṇāstasya prāṇāṣṭhīvanasīkarāḥ
]

`v 58 [
tasyāsthīnyadrijālāni medaso jātikā ghanāḥ |
śiraḥ pādau tvacaṃ dehānpaśyāmastasya no vayam
]

`v 59 [
vapurvirājo jagadaṅga viddhi saṃkalparūpasya hi kalpanātma |
ākāśaśailāvanisāgarādi sarvaṃ cidākāśamataḥ praśāntam
]