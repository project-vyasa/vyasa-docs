`v 1 [
catuścatvāriṃśaḥ sargaḥ 44
śrīrāma uvāca |
kramātsamādhānatarorājīvaphalaśālinīm |
salatākusumāṃ brūhi sattāṃ viśrāntidāṃ mune
]

`v 2 [
śrīvasiṣṭha uvāca |
ājīvamudyadutsedhaṃn vivekijanakānane |
patrapuṣpaphalopetaṃ samādhānataruṃ śṛṇu
]

`v 3 [
yathākathaṃciduditaṃ duḥkhena svayameva ca |
saṃsāravananirvedaṃ bījamasya vidurbudhāḥ
]

`v 4 [
śubhajālahalākṛṣṭaṃ rasāsiktamaharniśam |
pravahacchvasanākulyaṃ kṣetramasya vidurbudhāḥ `note[mano viduḥ iti pāṭho
yuktaḥ |]
]

`v 5 [
samādhibījaṃ saṃsāranirvedaḥ patati svayam |
cittabhūmau viviktāyāṃn vivekijanakānane
]

`v 6 [
svacittabhūmau patitaṃ dhyānabījaṃ mahādhiyā |
sekairamībhiryatnena saṃsektavyamakhedinā
]

`v 7 [
śuddhaiḥ snigdhaiḥ pavitraiśca madhurairātmanohitaiḥ |
satsaṃgamanavakṣīrairaindavairamṛtairiva
]

`v 8 [
tatra prathamaṃ satsaṃgamalakṣaṇairnavaiḥ kṣīraiḥ
paścāttanmukhāvagataśāstrāmṛtaiḥ sektavyamityāha - śuddhairiti dvābhyām | 7
|
antaḥśūnyapradaiḥ pūrṇaiḥ svacchairamṛtaśītalaiḥ |
visṛtairamṛtākulyāśāstrārthavaravāribhiḥ
]

`v 9 [
netinetīti sarvadvaitaniṣedhādantaḥsarvasaṃsāraśūnyātmapradaiḥ ata eva pūrṇaiḥ
sarvatāpopaśamanādamṛtavatsvāduśītalaiḥ | guruhṛdayasthasya brahmasaraso
vyākhyādvāra prasṛtaiḥ |
amṛtapravāhasyāsamantātkulyāvaddvārabhūtaśravaṇamananādiśāstrārtha##-
svacittabhūmau patitaṃ parijñāya mahādhiyā |
bījaṃ saṃsāranirvedo rakṣyaṃ dhyānasya yatnataḥ
]

`v 10 [
tapaḥprakāradānena padārthaghaṭaneśitaiḥ |
tīrthāyatanaviśrāntivṛtivistārakalpanaiḥ
]

`v 11 [
kartavyo'ṅkuritasyāsya rakṣitā śikṣitāśayaḥ |
saṃtoṣanāmā priyayā nityaṃ muditayānvitaḥ
]

`v 12 [
paścātsthitāśāvihagānparapraṇayapakṣiṇaḥ |
asmādāpatataḥ kāmagarvagṛdhrānnivārayet
]

`v 13 [
mṛdubhiḥ satkriyākuntairvivekārkātapairapi |
acintyālokadairasmānmārjitavyaṃ rajastamaḥ
]

`v 14 [
saṃpadaḥ pramadāścaiva taraṅgā bhogabhaṅgurāḥ |
patantyaśanayastasminduṣkṛtābhrasamīritāḥ
]

`v 15 [
dhairyaudāryadayāmantrairjapasnānatapodamaiḥ |
vinivārayitavyāstāḥ praṇavārthatriśūlinā
]

`v 16 [
praṇavamātrābhirvirāḍādibhiḥ sthūlasūkṣmaprapañcavilāpanena | tadbodheneti yāvat |
15 |
iti saṃrakṣitādasmāddhyānabījātpravartate |
ābhijātyonnataḥ śrīmānvivekākhyo navāṅkuraḥ
]

`v 17 [
tena sā cittabhūrbhāti saprakāśā vikāsinī |
bhavatyālokaramyā ca khaṃ yathābhinavendunā
]

`v 18 [
tasmādaṅkurataḥ patre ubhau vikasataḥ svayam |
ekaṃ śāstrābhigamanaṃ dvitīyaṃ sādhusaṃgamaḥ
]

`v 19 [
stambhameṣa nibadhnāti sthairyaṃ nāma samunnatim |
saṃtoṣatvagvivalitaṃ vairāgyarasarañjitam
]

`v 20 [
vairāgyarasapuṣṭātmā śāstrārthaprāvṛṣānvitaḥ |
svalpenaiva svakālena parāmeti samunnatim
]

`v 21 [
śāstrārthasādhusaṃparkavairāgyarasapīvaḥ |
rāgadveṣakapikṣobhairna manāgapi kampate
]

`v 22 [
atha tasmātprajāyante vijñānālaṃkṛtākṛteḥ |
latā rasavilāsinyaimā vitatadeśagāḥ
]

`v 23 [
sphuṭatā satyatā sattā dhīratā nirvikalpatā |
samatā śāntatā maitrī karuṇā kīrtirāryatā
]

`v 24 [
latābhirguṇapatrābhiḥ sa dhyānatarurūrjitaḥ |
yaśaḥpuṣpābhiretābhiḥ pārijātāyate yateḥ
]

`v 25 [
ityasau jñānaviṭapī latāpallavapuṣpavān |
bhaviṣyajjñānaphalado dinānudinamuttamaḥ
]

`v 26 [
yaśaḥkusumagucchāḍhyo guṇapallavalāsavān |
vairāgyarasavistārī prajñāmañjaritākṛtiḥ
]

`v 27 [
sarvāḥ śītalayatyāśāḥ prāvṛṣīva payodharaḥ |
sargātapaṃ śamayati sūryatāpamivoḍupaḥ
]

`v 28 [
pratanoti śamacchāyāṃ chāyāmiva ghanāgamaḥ |
nirodhamāsphārayati śamo'nila ivāmbudam
]

`v 29 [
nibadhnātyātmanā pīṭhaṃ kulācala iva sthitam |
phalasya racayatyūrdhvaṃ ghaṭikāṃ maṅgalāditām
]

`v 30 [
vivekakalpavṛkṣe tu vardhamāne dine dine |
chāyāvitānavalite puṃso hṛdayakānane
]

`v 31 [
pravartate śītalatā talatāpāpahāriṇī |
abhyullasanmatilatā tuṣārodarasundarī
]

`v 32 [
yasyāmavāntaraśrānto viśrāmyati manomṛgaḥ |
ājanmajīrṇapathikaḥ pathi kolāhalākulaḥ
]

`v 33 [
sattāmātrātmaśārīracarmārthaṃ prekṣito'ribhiḥ |
nānātāsārasākāragopayajjarjaronmukhaḥ
]

`v 34 [
saṃsārāraṇyavisaradvāsanāpavaneritaḥ |
ahaṃtātāpasaritā sarvadā vipradāradī
]

`v 35 [
dīrghādarī dūracitasārasaṃcārajarjaraḥ |
putrapautraparāmarśapratāpātpatito'vaṭe
]

`v 36 [
lakṣmīlatāviluṭhanātsaṃkaṭaiḥ kuṇṭhitāṅgakaḥ |
tṛṣṇāśrīsaritaṃ gṛhṇankallolairdūramāhataḥ
]

`v 37 [
lakṣmīḥ saṃpattallakṣaṇāsu latāsu pādaveṣṭanena
viluṭhanācchatrucorarājādiprayuktairbandhanatāḍanadaṇḍanādisaṃkaṭaiḥ
kuṇṭhitāṅgakaḥ | kallolaiḥ aśanāyāpipāsāśokamohajarāmṛtyulakṣaṇairūrmibhiḥ |
36 |
vyādhidurvyādhavaidhuryapalāyanaparāyaṇaḥ |
aśaṅkitavidhirvyādhapātādiva kṛtākṛtiḥ
]

`v 38 [
jñeyāspadasamāyātaduḥkhasāyakaśaṅkitaḥ |
vairividravaṇavyagro dṛṣadāharaṇāṅkitaḥ
]

`v 39 [
unnatānatasaṃpātanipātenātighūrṇitaḥ |
vikāropalanirghātaiḥ pāramparyeṇa cūrṇitaḥ
]

`v 40 [
tṛṣṇācārulatājālapraveśavaśavikṣataḥ |
svaprajñāracitācāraḥ paramāyāsvaśikṣitaḥ
]

`v 41 [
indriyagrāmamāgatya prapalāyanatatparaḥ |
sudurgrahagajendrogravisphūrjanavimarditaḥ
]

`v 42 [
viṣayājagarodāraviṣaphūtkāramūrcchitaḥ |
kāmukaḥ kāminībhūmau rasātprāyo vipothitaḥ
]

`v 43 [
kopadāvānalapluṣṭapṛṣṭhavisphoṭadāhavān |
sadā gatāgatānekadīrghaduḥkhapradāhavān
]

`v 44 [
svātmalagnābhilāṣāṃśadaṃśadoṣairupadrutaḥ |
bhogalobhalasanmodaśṛgālaciravidrutaḥ
]

`v 45 [
svakarmakartṛtodbhrāntadāridryadvīpyanudrutaḥ |
vyāmohamihikāndhatvakūṭāvaṭaluṭhattanuḥ
]

`v 46 [
mānasiṃhasamullāsahṛdayotkampanāturaḥ |
maraṇena raṇe yena vṛkapuṣpamivekṣitaḥ
]

`v 47 [
garveṇa giraṇāyāśu dūratojanasevitaḥ |
kāmaiḥ samantato dantavitānitayavāṅkuraḥ
]

`v 48 [
tāruṇyanārīsuhṛdā kṣaṇamāliṅgya varjitaḥ |
duḥsaṃcāreṣu `note[duḥsaṃcāreṣūpavanaiḥ iti mudritapāṭhaḥ
ṭīkākartrasaṃmataḥ svārasyavikalaśca |] pavanaiḥ kupitairiva varjitaḥ
]

`v 49 [
kadācinnirvṛtiṃ yāti saśamaṃ ca tarau kvacit |
manohariṇako rājannājīvamiva bhāsvati
]

`v 50 [
tālītamālabakulādikavṛkṣagulmaviśrāntiṣu pracurapuṣpavilāsahāsaiḥ |
nāmāpi yasya na vidanti sukhasya mūḍhāḥ prāpnoti tacchamataroḥ svamanomṛgo
vaḥ
]