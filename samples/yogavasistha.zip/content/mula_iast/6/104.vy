`v 1 [
caturadhikaśatatamaḥ sargaḥ 104
śrīvasiṣṭha uvāca |
ākāśaḥ śabdatanmātraṃ sparśatanmātrako'nilaḥ |
tatsaṅgotkarṣajaṃ tejastacchāntiścetyapāṃ sthitiḥ
]

`v 2 [
bhūreṣāṃ saṅghaḥ svapnābhe jagadbhāne kramastviti |
kathaṃ nāma kilāmūrtādvyomno mūrtiḥ pravartate
]

`v 3 [
gatvā sudūramapyetajjñapteścetparikalpyate |
tadādāveva satyarthe doṣo'sminka ivāmale
]

`v 4 [
jñaptirevātivimalā svarūpātmani bhāti yat |
tadeva jagadityuktaṃ satyamityeva satyataḥ
]

`v 5 [
na kvacitsanti bhūtāni pañca kuṭyādayo na vā |
asantyapyanubhūtāni nanu svapnadaśāsviva
]

`v 6 [
svabhāva eva vimalo yathā svapne purādivat |
kacatyevaṃ jāgratīdaṃ jagadvadvastutastu `note[vastu tatsukham iti
mudritapāṭhaścintyaḥ |] kham
]

`v 7 [
cetanākāśa evāhaṃ tadevedaṃ jagatsthitam |
ityahaṃ jagadityekaṃ khamevaikaṃ śilāghanam
]

`v 8 [
yadādisargajananaṃ yatkalpāntavivartanam |
yadvā bhuvanasaṃsthānaṃ taddhi vyoma nirākṛti
]

`v 9 [
sati vā'sati vā dehe nirduḥkhasukhatvamakṣayaṃ mokṣaḥ |
buddhe'male svabhāve nirbharaviśrāntirastu sarveha
]