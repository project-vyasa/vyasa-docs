`v 1 [
aṣṭaṣaṣṭitamaḥ sargaḥ 68
vidyādharyuvāca |
tataḥ prācīnamabhyāsaṃ bodhadhāraṇayāmale |
kurvaḥ prakaṭatāṃ tena jagadeṣyati śailagam
]

`v 2 [
śrīvasiṣṭha uvāca |
yuktiyukte tayetyukte vidyādharyā dharorasi |
baddhapadmāsano'thāhaṃ samādhābudito'bhavam
]

`v 3 [
sarvārthabhāvanātyāge cinmātraikāntabhāvitaḥ |
atyajaṃ tamahaṃ pūrvakathārthakalanāmalam
]

`v 4 [
atha cidvyomatāṃ prāptaḥ parāṃ dṛṣṭimahaṃ gataḥ |
śaratsamayasaṃprāptau vyoma nirmalatāmiva
]

`v 5 [
tataḥ satyāvadhānaikaghanābhyāsena dehake |
mamādhibhautikabhrāntirnūnamastamupāgatā
]

`v 6 [
udayāstamayonmuktā satatodayamayyapi |
mahācidvyomatāsvacchā proditeva tadābhavat
]

`v 7 [
atha paśyāmyahaṃ yāvatsvasyaivāmalatejasā |
vastutastu na cākāśaṃ nopalaḥ parameva tat
]

`v 8 [
paramārthaghanaṃ svacchaṃ tattathā bhāti tādṛśam |
tathābhāvanayā hyātmā madīyo dṛṣṭavāṃstathā
]

`v 9 [
yathā svapne sumahatī dṛṣṭā gehagatā śilā |
vyomaiva kevalaṃ tadvatsuśuddhaṃ cinnabhaḥśilā
]

`v 10 [
svayaṃ svapnānvito'nyasya svapnapuṃstvaṃ gato naraḥ |
svapne'jñānaprabuddhasya yādṛktādṛksvarūpataḥ
]

`v 11 [
svapnasthānāṃ śiraśchinnaṃ yeṣāṃ te saṃsṛtau sthitāḥ |
kālena jñānalābhena vinā kurvantu kiṃ kila
]

`v 12 [
bodhaḥ kālena bhavati mahāmohavatāmapi |
yasmānna kiṃcanāpyasti brahmatattvādṛte'kṣayam
]

`v 13 [
atastaccidghanaṃ svacchaṃ brahmākāśaṃ śilākṛti |
dṛṣṭaṃ mayā tathā tatra na tu pṛthvyādi satkvacit
]

`v 14 [
bhūtānāmādisarge yacchuddhaṃ yatpāramārthikam |
vapustadeva hyeteṣāṃ dhyānalabhyamavasthitam
]

`v 15 [
bhūtānāmādisarge yacchuddhaṃ yatpurātanam |
tadevādya manorājyaṃ saṃkalpa iti kathyate
]

`v 16 [
sattātivāhiko dehastatparaṃ paramārthataḥ |
pratyakṣaṃ paramaṃ yattattadādyaṃ kacanaṃ citaḥ
]

`v 17 [
udyatprathamamadhyakṣaṃ jīvasya prathamaṃ vapuḥ |
manaḥ pratyakṣamityuktaṃ tattenādyaiva durdhiyā
]

`v 18 [
yogipratyakṣamityuktaṃ manaḥpratyakṣamityapi |
tatsvameva cito rūpaṃ gatamevānyatāṃ mudhā
]

`v 19 [
idamadyatanaṃ nāma pratyakṣamasadutthitam |
asatpratyakṣameveti viddhi pratyakṣamaṅga tat
]

`v 20 [
aho nu citrā māyeyaṃ prākpratyakṣe parokṣatā |
nirṇītāsmiṃstvanadhyakṣe pratyakṣakalanāgatā
]

`v 21 [
ātivāhikadehatvaṃ pratyakṣaṃ prathamoditam |
satyaṃ sarvagataṃ viddhi māyaiva tvādhibhautikam
]

`v 22 [
prathamoditamiti sūkṣmapūrvakatvātsthaulyādhyāsasyetyarthaḥ | yadagne rohitaṃ rūpaṃ
tejasastadrūpaṃ yacchuklaṃ tadapāṃ yatkṛṣṇaṃn tadannasyāpāgādagneragnitvaṃ trīṇi
rūpāṇītyeva satyam iti śruteḥ | satyaṃ samaṣṭibhāvātsarvagataṃ māyaivānṛtameva |
21 |
anubhūtāpi nāstyeva hemnaḥ kaṭakatā yathā |
tathātivāhikasyādhibhautikatvaṃ na vidyate
]

`v 23 [
bhramamabhramatāṃ yātamabhramaṃ bhramatāṃ gatam |
vetti jīvo vicāreṇa vināho nu vimūḍhatā
]

`v 24 [
ādhibhautikadeho'yaṃ vicāreṇa na labhyate |
ātivāhikadehastu kila lokadvaye'kṣayaḥ
]

`v 25 [
ādhibhautikacidrūḍhā hyātivāhikadehake |
marau marīcikāsveva yathā mithyaiva vāridhīḥ
]

`v 26 [
jātādhibhautikī saṃvidātivāhikacitkrame |
dehadṛṣṭivaśātprauḍhā sthāṇau puruṣadhīriva
]

`v 27 [
śuktau rajatatā tāpe jalatendau yathā dvitā |
ādhibhautikatā tadvanmāyayaivātivāhike
]

`v 28 [
yadasattatkṛtaṃ satyaṃ yatsatyaṃ tadasatkṛtam |
aho nu mohamāhātmyaṃ jīvasyāsyāvicārajam
]

`v 29 [
yogipratyakṣamevāsti kiṃcidasti tu mānasam |
yasmāllokadvayācārastābhyāmeva prasidhyati
]

`v 30 [
ādyaṃn pratyakṣamutsṛjya yaḥ satye'sminkṛtasthitiḥ |
pratyakṣe mṛgatṛṣṇāmbu pītvā sa sukhamāsthitaḥ
]

`v 31 [
tathā ca sarvasādhāraṇapratyakṣamātre sarvamanyadvihāya yogena sthiratā kāryā na
pāmarajanamātraprasiddhe aihikamātre sthūlādipratyakṣe ityāśayenāha - ādyamiti |
30 |
yatsukhaṃ duḥkhamevāhuḥ kṣaṇanāśānubhūtibhiḥ |
akṛtrimamanādyantaṃn yatsukhaṃ tatsukhaṃ viduḥ
]

`v 32 [
pratyakṣeṇaivamadhyakṣaṃ pratyakṣaṃ pravicāryatām |
yadādyaṃn tatsadadhyakṣaṃ tatpratyakṣeṇa dṛśyatām
]

`v 33 [
lokatrayānubhavadaṃ tyaktvā pratyakṣamaihikam |
māyātmakaṃ yo gṛhṇāti nāsti mūḍhatamastataḥ
]

`v 34 [
ātivāhikamevaiṣāṃ bhūtānāṃ vidyate vapuḥ |
atrādhibhautikavyāptirasatyaiva piśācikā
]

`v 35 [
ajātasaṃkalpamayaṃ pratyakṣaṃ satkathaṃ bhavet |
svayameva na yatsatyaṃ tatsyātkāryakaraṃ katham
]

`v 36 [
yatra pratyakṣamevāsadanyatkiṃ tatra sadbhavet |
kva tatsatyaṃ `note[kva tatsiddhaṃ bhavet iti pāṭhaḥ |] bhavedvastu yadasiddhena
sādhyate
]

`v 37 [
pratyakṣa eva bhāvatve naṣṭe kvevānumādayaḥ |
uhyante vāraṇā yatra tatrorṇāyuṣu kā kathā
]

`v 38 [
ataḥ pramāṇasaṃsiddhaṃ dṛśyaṃ nāstyeva kutracit |
ananyadidamastīva tattadbrahmaghanaṃ ghanam
]

`v 39 [
svapne draṣṭuḥ khamevādrirgṛhe nānyasya vai yathā |
tathā tadbhāvanavatorātrayoḥ sā śilaiva cit
]

`v 40 [
ayaṃ śaila idaṃ vyoma jagadetadidaṃ tvaham |
iti cinmaya ātmāntaḥ khaṃ camatkurute svayam
]

`v 41 [
paśyatyetatprabuddhātmā nāprabuddhaḥ kadācana |
śrotuḥ kathārthasaṃvittirnāśroturbhavati kvacit
]

`v 42 [
aprabuddhamiti bhrāntireveyaṃn satyatāṃ gatā |
kṣīvasya susthirā eva nṛtyanti taruparvatāḥ
]

`v 43 [
sarvatrā pratihatamekarūpabodhaṃ pratyakṣaṃ śivamanubudhya citsvarūpam |
pratyakṣāntaramiha pelavaṃ śrayante ye mūḍhāstṛṇatanubhiḥ śaṭhairalaṃ taiḥ
]