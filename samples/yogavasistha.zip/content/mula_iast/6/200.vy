`v 1 [
dviśatatamaḥ sargaḥ 200
śrīvālmīkiruvāca |
nirvāṇavākyasaṃdarbhasamāptau munināyake |
pāścātyavākyaviratiṃ kurvati kramapālitām
]

`v 2 [
nirvikalpasamādhānasamatāṃ samupāgate |
śāntasvacchamanovṛttau sarvasmiṃśca sabhājane
]

`v 3 [
sarvasminsabhāgate jane cānnabhogatadevādijane ca
munivākyaśravaṇānnirvikalpasamādhānena samatāṃ brahmaikarasatāṃ samāgate sati | 2
|
sattvakoṭimupārūḍhe parāṃ pāvanatāṃ gate |
saṃvittattve samagrasya janasya śrutaśālinaḥ
]

`v 4 [
jhaṭityevāmbarahṛtā pūrvamuktadhiyāṃ mukhāt |
siddhānāṃ sādhuvādena vyomakoṭaravāsinām
]

`v 5 [
tathā sabhāsthitānāṃ ca munīnāṃ bhāvitātmanām |
gādheyapramukhānāṃ ca sādhuvādagiroccayā
]

`v 6 [
kolāhalaḥ samudabhūdbhūripūritadiṅmukhaḥ |
madhuraḥ pavanāttānāṃ kīcakānāmivāravaḥ
]

`v 7 [
pavane āttānāṃ vyāptānāṃ pūrṇarandhrāṇāṃ kīcakānāṃ veṇumedānāmārava iva | 6
|
siddhānāṃ sādhuvādena saha vai sahasā tataḥ |
devadundubhayo neduḥ pratiśrutpūritācalāḥ
]

`v 8 [
devadundubhibhiḥ sārdhaṃ tuṣārāsārasundarī |
digbhyaḥ sthagitadikcakrā puṣpavṛṣṭiḥ papāta ha
]

`v 9 [
puṣpaughapūritasthānaḥ śabdāpūritakandaraḥ |
rajaḥsaṃrañjitākāśo gandharañjitamārutaḥ
]

`v 10 [
sa sādhuvādaśabdasya devatūryaravasya ca |
kusumāsāraghoṣasya samavāyo rarāja ha
]

`v 11 [
unmukhākhilasabhyākṣiraśmiśyāmalitāntaraḥ |
utkarṇamṛgamātaṅgahayapakṣipaśuśrutaḥ
]

`v 12 [
savismayabhayonnetrabālakāntājanekṣitaḥ |
vismayasmeravadanarājalokāvalokitaḥ
]

`v 13 [
kusumāsārasāreṇa śabdaśobhātiśāyinā |
saṃrambheṇa jagāmāśu rodorandhramapūrvatām
]

`v 14 [
puṣpavarṣasudhādhautaṃ raṭadbhūtasughuṃghumam |
samatāṃ sadanenāgāt dhmātaśaṅkhaśatena kham
]

`v 15 [
bhuvanaṃ bhūribhāṃkārabhāsuraṃ suracāraṇaiḥ |
vṛtaṃ mattotsavaṃ reje samaṃ kusumamaṇḍitam
]

`v 16 [
śanairdundubhisiddhaughavākyapuṣpabharaḥ samam |
prayayau rodasīrandhre velācalamivāmbudhau
]

`v 17 [
tasminvibudhasaṃrambhe kṣaṇena samaye gate |
vākyānīmāni siddhānāmabhivyaktimupāyayuḥ
]

`v 18 [
siddhā ūcuḥ |
ākalpaṃ siddhasaṅgheṣu mokṣopāyāḥ sahasraśaḥ |
vyākhyātāśca śrutāścālamīdṛśāstu na kecana
]

`v 19 [
tiryañco vanitā bālā vyālāścānena nirvṛtim |
munervākyavilāsena yānti nāstyatra saṃśayaḥ
]

`v 20 [
dṛṣṭāntairhetubhiryuktyā yathā rāmo'vabodhitaḥ |
tathā cārundhatī sākṣātsaṃbodhayati vā na vā
]

`v 21 [
anena mokṣopāyena tiryañco'pi gatāmayāḥ |
sthitā muktā bhaviṣyanti ke nāma bhuvi no narāḥ
]

`v 22 [
śravaṇāñjalibhiḥ pītvā jñānāmṛtamidaṃ vayam |
parāṃ pūrṇanavībhūtasiddhayaḥ śriyamāgatāḥ
]

`v 23 [
iti śṛṇvansabhāṃ loko vismayotphullalocanaḥ |
kusumāsārasaṃpūrṇāṃ rājīvānāṃ dadarśa tām
]

`v 24 [
mandārādimahāpuṣpacchannacchādanasaṃcayām `note[ghanacchādaneti pāṭhaḥ |
] |
pāribhadralatāgucchanīrandhrājirabhūmikām
]

`v 25 [
pārijātaprasūnāḍhyamahītalavirājitām |
saṃtānakamahāmbhodavyāptasabhyaśiraḥkarām
]

`v 26 [
mauliratnaviṭaṃkāgraviśrāntaharicandanām |
vāripūrapralambābhravadālambivitānakām
]

`v 27 [
iti paśyansabhāṃ lokaḥ sādhuvādena bhūriṇā |
tatkālocitavākyena tena tena tathodyataḥ
]

`v 28 [
vasiṣṭhaṃ pūjayāmāsa sarvendriyagaṇānataḥ |
kusumāñjalimiśreṇa praṇāmasahitena ca
]

`v 29 [
nṛpapraṇāmamālāsu kiṃcicchāntāsu tāsvatha |
munimāpūjayannāha sārdhyapātrakaro nṛpaḥ
]

`v 30 [
daśaratha uvāca |
kṣayātiśayamuktena parameṇātmavastunā |
parāntaḥ pūrṇatotpannā bodhenārundhatīpate
]

`v 31 [
na tadasti mahīpīṭhe divi deveṣu vāpi ca |
mahatkiṃcidyadaprāptaṃ tava pūjyasya pūjanam
]

`v 32 [
tathāpyātmakramaṃ brahmannimaṃ netumavandhyatām |
ahaṃ vacmi yathāprāptaṃ na kopaṃ kartumarhasi
]

`v 33 [
ātmanā sakalatreṇa lokadvayaśubhena ca |
rājyenākhilabhṛtyena bhavantaṃ pūjayāmyaham
]

`v 34 [
etatsarvaṃ tava vibho svāyattaṃ sva ivāśramaḥ |
niyojaya yathādeśaṃ yathābhimatayecchayā
]

`v 35 [
mayā tubhyaṃ dattametatsarvaṃ tava svāyattam | tvaṃ niyojaya svāmī bhūtvā ājñāpaya |
34 |
śrīvasiṣṭha uvāca |
praṇāmamātrasaṃtuṣṭā brāhmaṇā bhūpate vayam |
praṇāmenaiva tuṣyāmaḥ sa eva bhavatā kṛtaḥ
]

`v 36 [
pātuṃ tvameva jānāsi rājyaṃ bhāti tavaiva ca |
bhavatvetattavaiveha brāhmaṇāḥ kva mahībhṛtaḥ
]

`v 37 [
daśaratha uvāca |
kiyanmātraṃ tu rājyaṃ syāditi lajjāmahe mune |
prakarṣeṇātra teneśa yathā jānāsi tatkuru
]

`v 38 [
śrīvālmīkiruvāca |
ityuktavati bhūpāle rāmaḥ puṣpāñjaliṃ dadat |
uvāca praṇato vākyaṃ purastasya mahāguroḥ
]

`v 39 [
niruttarīkṛtamahārāja brahmanpraṇaumi te |
praṇāmamātrasāro'haṃ rāmaḥ pādāvimau prabho
]

`v 40 [
ityuktvā pādayostasya śirovandanapūrvakam |
tatyājāñjalipuṣpāṇi himānīva vanaṃ gireḥ
]

`v 41 [
ānandabāṣpasaṃpūrṇanayano nayakovidaḥ |
guruṃ paramayā bhaktyā praṇanāma punaḥpunaḥ
]

`v 42 [
śatrughno lakṣmaṇaścaiva tathānye tatsamāśca ye |
nikaṭasthāstathaivāśu te praṇemurmunīśvaram
]

`v 43 [
dūrapraṇāmairdūrasthāḥ puṣpāñjalisamīraṇaiḥ |
rājāno rājaputrāśca praṇemurmunayaśca tam
]

`v 44 [
asminnavasare tatra kusumāñjalivarṣaṇaiḥ |
himairiva himādrīndro munirantardhimāyayau
]

`v 45 [
atha śānte sabhākṣome praṇāmanivahe tathā |
saṃsmarañchāsanaṃ kiṃcitsatye kṛṣṇasitāśayam
]

`v 46 [
muniḥ kusumarāśiṃ taṃ bāhubhyāṃ pravicālya saḥ |
mukhaṃ saṃdarśayāmāsa sitābhrādiva candramāḥ
]

`v 47 [
śānte siddhavacorāśau tathā dundubhiniḥsvane |
nabhaḥkusumavarṣe ca sabhākalakale tathā
]

`v 48 [
praṇāmānantaraṃ tasminrāmādyaiḥ svasabhājane |
śāntavāta ivāmbhode jane saumyatvamāgate
]

`v 49 [
ākarṇayansādhuvādaṃ viśvāmitraṃ mṛdusvanam |
uvācedamanindyātmā vasiṣṭho munināyakaḥ
]

`v 50 [
mune gādhikulāmbhoja vāmadeva nime krato |
bharadvāja pulastyātre ghṛṣṭe nārada śāṇḍile
]

`v 51 [
he bhāsabhṛgubhāraṇḍavatsavātsyāyanādayaḥ |
munayastucchametannu bhavadbhirmadvacaḥ śrutam
]

`v 52 [
yadatrānucitaṃ kiṃcittadanugrahato'dhunā |
durarthaṃ vigatārthaṃ vā bhavantaḥ kathayantu me
]

`v 53 [
sabhyā ūcuḥ |
vasiṣṭhavacane brahmanparamārthaikaśālini |
durartho bhavatītyadya navaiva khalu gīḥ śrutā
]

`v 54 [
yatsaṃbhṛtamanantena janmadoṣeṇa no malam |
tatpramṛṣṭaṃ tvayehādya hemnāmiva havirbhujā
]

`v 55 [
brahmabṛṃhitayā vācā vibho vikasitā vayam |
kumudānīndudīptyeva paramāmṛtaśītayā
]

`v 56 [
brahmaṇi bṛṃhitayā vistāritayā | indudīptipakṣe brahmasadṛśe ākāśe vistāritayā |
55 |
sarvasattvamahābodhadāyinaṃ munināyakam |
bhavantamekāntaguruṃ praṇamāma ime vayam
]

`v 57 [
śrīvālmīkiruvāca |
ityuktvā munināthāya namasta iti te punaḥ |
vadanta ekaśabdena tāreṇābdaravaujasā
]

`v 58 [
arvākyapuṣpāñjalivrātaiḥ khātsiddhaiḥ samamujjhitaiḥ |
vasiṣṭhaṃ pūrayāmāsurhimairabdā ivācalam
]

`v 59 [
itthaṃ daśarathaṃ bhūpaṃ śaśaṃsuścātha rāghavam |
mādhavaṃ caturātmānaṃ rāghavodantakovidāḥ
]

`v 60 [
siddhā ūcuḥ |
namāma caturātmānaṃ nārāyaṇamivāparam |
rāmaṃ sabhrātaraṃ jīvanmuktaṃ rājakumārakam
]

`v 61 [
caturabdhinikhātāntadharāvalayapālakam |
trikālasthamahīpālacihnaṃ daśarathaṃ nṛpam
]

`v 62 [
munisenādhipaṃ bhūpaṃ bhāskaraṃ bhūritejasam |
vasiṣṭhaṃ supravādāḍhyaṃ viśvāmitraṃ taponidhim
]

`v 63 [
eṣāmeva prabhāvena jñānayuktiṃ parāmimām |
śrutavanto vayaṃ sarve bhrāntisaṃrambhanāśinīm
]

`v 64 [
śrīvālmīkiruvāca |
ityuktvā gaganātsiddhā bhūyaḥ puṣpāṇi cikṣipuḥ |
sabhāyāmatha tūṣṇīṃ ca tasthurmuditacetasaḥ
]

`v 65 [
tathaiva vyomagāḥ siddhāḥ śaśaṃsustaṃ janaṃ punaḥ |
tathaiva sabhyāstāṃstatra samānarcurghanastavam
]

`v 66 [
nabhaścarā dharaṇicarā munīśvarā maharṣayo vibudhagaṇā dvijā nṛpāḥ |
apūjayanniti janamojasaiva te giroccayā saha kusumārghyadānayā
]