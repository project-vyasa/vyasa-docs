`v 1 [
navanavatitamaḥ sargaḥ 99
śrīrāma uvāca |
santi duḥkhakṣaye'smākaṃ śāstrasatsaṅgayuktayaḥ |
mantrauṣadhitapodānatīrthapuṇyāśramāśrayāḥ
]

`v 2 [
kṛmikīṭapataṅgādyāstiryaksthāvarajātayaḥ |
kathaṃ sthitāḥ kimārambhāsteṣāṃ duḥkhakṣayaḥ katham
]

`v 3 [
śrīvasiṣṭha uvāca |
sarvāṇyeveha bhūtāni sthāvarāṇi carāṇi ca |
ātmocitāyāṃ sattāyāṃ viśrāntāni sthitānyalam
]

`v 4 [
bhūtānāmaṇumātrāṇāmapyasmākamivaiṣaṇāḥ |
kiṃtvalpāsthā vayaṃ vighnāsteṣāṃ tvacalasaṃnibhāḥ
]

`v 5 [
yathā virāṭ prayatate vālakhilyāstathaiva khe |
bālamuṣṭyalpakāye'pi paśyāhaṃkṛtijṛmbhitam
]

`v 6 [
jāyante ca mriyante ca nirādhāre'mbare khagāḥ |
śūnyaikaviṣayāsteṣāṃ svāsthyaṃ na bhavati kṣaṇam
]

`v 7 [
pipīlikāyāśceṣṭābhirgrāsāvāsātmabandhubhiḥ |
asmaddivasakalpo'pi na paryāptaḥ kṣaṇo yathā
]

`v 8 [
trasareṇupramāṇātmā kṛmyaṇustimināmakaḥ |
gamane vyagratā tasya garuḍasyeva laṣyate
]

`v 9 [
ayaṃ sohamidaṃ tanma ityākalpitakalpanam |
jagadyathā nṛṇāṃ sphāraṃ tathaivoccairguṇaiḥ kṛmeḥ
]

`v 10 [
deśakālakriyādravyavyagrayā jarjarīkṛtam |
kṣīyate vraṇakīṭānāmasmākamiva jīvitam
]

`v 11 [
pādapāḥ kiṃcidunnidrā ghananidrāḥ khalūpalāḥ |
kṛmikīṭādayaḥ kārye naravatsvapnabodhinaḥ
]

`v 12 [
śarīranāśa evaiṣāṃ sukhaṃ saṃprati duḥkhakṛt |
asmākamiva teṣāṃ tajjīvitaṃ tu sukhāyate
]

`v 13 [
jano dvīpāntaraṃ yādṛgvikrītaḥ paripaśyati |
padārthajālaṃ paśyanti tādṛkpaśumṛgādayaḥ
]

`v 14 [
asmākamiva saṃsārastiraścāṃ sukhaduḥkhadaḥ |
padārthapravibhāgena kevalaṃ te vivarjitāḥ
]

`v 15 [
hṛdayātsukhaduḥkhābhyāṃ nāsāto raśanāguṇaiḥ |
paśavaḥ parikṛṣyante vikrītāḥ pāmarā api
]

`v 16 [
suptānāṃ yādṛgasmākaṃ vedanaṃ spaṣṭasutvacām |
vṛkṣagulmāṅkurādīnāṃ tādṛguddāmavedanam
]

`v 17 [
yādṛgasmākamītyarthakramasaṃsārapātinām |
padārthavedanaṃn tādṛktiraścāṃ bhrāntamabhramam
]

`v 18 [
āhlādamātre saumyatvaṃ sukhataścendrakīṭayoḥ |
samaṃ vikalpavinmuktaṃ vikalpastvanatikramaḥ
]

`v 19 [
rāgadveṣabhayāhāramaithunotthaṃ sukhāsukham |
tiraścāṃ janmamṛtyādikhedaḥ kaścinna bhidyate
]

`v 20 [
ṛte padārthabhūtārthabhaviṣyadvastubodhataḥ |
śeṣaṃ babhrvahigomāyugajādīnāṃ nṛbhiḥ samam
]

`v 21 [
nidrāmayānāṃ vṛkṣāṇāṃ svasattāmacalādayaḥ |
sthitā anubhavanto'nye cidākāśamakhaṇḍitam
]

`v 22 [
āpīnanidrā vṛkṣādyāḥ svasattāsthāstathādrayaḥ |
jaṅgamāni cidākāśaṃ nāma kiṃcitkadācana
]

`v 23 [
akhaṇḍacittā śailādisattā nidrā ca bhūruhām |
dvaitopalambhamuktatvātkhamevaikamato jagat
]

`v 24 [
parijñātaṃ jagadyāvadaparijñānasaṃyutam |
na tvaṃ nāhaṃ na caivāstināstī na ca bhaviṣyati
]

`v 25 [
yathāsthitaṃ sadaivedaṃ maunameva śilāghanam |
anādyantamavicchidramanidraṃ ca sanidrakam
]

`v 26 [
pūrvaṃ sargādyathaivāsīttathaivaikaṃ samasthitam |
bhaviṣyatyadhunānantakālamevaṃ tathaiva ca
]

`v 27 [
naivātmatā na paratā na jagattā na śūnyatā |
na maunatā na maunitvaṃ kiṃcinnehopapadyate
]

`v 28 [
tvaṃ yathāsthitamevāsva yathāsthitamahaṃ sthitaḥ |
sukhāsukhe parākāśe śānte nehāsti kiṃcana
]

`v 29 [
paramākāśatāṃ muktvā kiṃ svapnanagare vada |
vidyate kila tacchāntaṃ cidvyomācchamanāmayam
]

`v 30 [
aparijñaptirevaikā tatra saṃbhramakāriṇī |
parijñātamidaṃ yāvadvidyate sāpi na kvacit
]

`v 31 [
parijñāte jagatsvapne yāvatsatyaṃ na kiṃcana |
grahastadenaṃn prati kiṃ sneho vandhyāsute tu kaḥ
]

`v 32 [
svapnakāle parijñāte jagatsvapnamaṇāvaṇau |
kimupādeyatā kāsthā prabodhe'sau na kiṃcana
]

`v 33 [
yanna kiṃcitprabodho'sti nāprabodho'sti tatkvacit |
yastūpalambhastatkāle pūrvāvasthaiva sā tathā
]

`v 34 [
vidyate vartamānatvaṃ bhaviṣyadbhūtatā tathā |
bodhābodhaśca no satyaṃ vastu śāntaṃ kilākhilam
]

`v 35 [
yathormiṇormau nihate na kācitpayasāṃ kṣatiḥ |
tathā dehena nihate dehe nāsti citeḥ kṣatiḥ
]

`v 36 [
citāvākāśa evāhaṃ deha ityupajāyate |
saṃvideva tato dehe naṣṭe kiṃ nāma naśyati
]

`v 37 [
prabuddhasyaiva cidvyomnaḥ svapno jagaditi sthitam |
pṛthvyādirahitaṃ yasmāttasmātsvapnātmakaṃ jagat
]

`v 38 [
sargādau pūrvacitsvapnājjātā pṛthvyādivastudhīḥ |
svapnārthe satyatābhrāntiḥ kalpanāmātrarūpiṇī
]

`v 39 [
pūrvātpūrvatarasyāsya svapnasyāvayavasthitau |
satyevāsatyarūpāyāṃ pṛthvyādikalanā kṛtā
]

`v 40 [
sā ca bhrāntistathā rūḍhā yathāsatyaiva satyatām |
paramāmāgatā tattu satyamatyantanirmalam
]

`v 41 [
vastutastu yathābhūtaṃ cidbrahmaivātataṃ sthitam |
na ca tatsaṃsthitaṃ kiṃcitsmartā'smartā kimātmakaḥ
]

`v 42 [
evaṃ mātrāparijñānamevātra pratibodhakam |
atraiva tu parijñānaṃ kavāṭapravighāṭanam
]

`v 43 [
pāriśeṣyānna pṛthvyādi kiṃcitsaṃbhavati kvacit |
yo draṣṭā yacca vā dṛśyaṃ vimalaṃ śivameva tat
]

`v 44 [
mukure'ntaryathā bimbādbimbaṃ bhāti jagattathā |
cidvyomani svato bhātamabimbādeva bimbitam
]

`v 45 [
mukure'ntaryathā bimbaṃ na dṛṣṭamapi kiṃcana |
tathā cidvyomagaṃ viśvaṃ na dṛṣṭamapi kiṃcana
]

`v 46 [
labhyate yadvicāreṇa yatsakāraṇakaṃ sthitam |
tatsaccheṣaṃ tu bhāmātramabhūtaṃ satkathaṃ bhavet
]

`v 47 [
bhavedbhramātmakamapi kiṃcidarthakriyākaram |
svapnāṅganāpi kurute satyāmarthakriyāṃ nṛṇām
]

`v 48 [
yattadbhānaṃ tu sā cidbhā paramaṃ taccidambaram |
iti kvāhaṃ kva viśvaśrīḥ kva tvaṃ dṛśyadṛśaśca kāḥ
]

`v 49 [
mṛtvā punarbhavanamasti kimaṅga naṣṭaṃ mṛtvā na cedbhavanamasti tathāpi
śāntiḥ |
vijñānadṛṣṭivaśato'styatha cedvimokṣastanneha kiṃcidapi
duḥkhamudārabuddheḥ
]

`v 50 [
mūrkhasya yādṛśamidaṃ tu tadajña eva jānātyasau na hi vayaṃ kila tatra
tajjñāḥ |
matsyo hi yo mṛganadīsalile sa eva jānāti taccapalavīcivivartanāni
]

`v 51 [
mūrkhasya tarhi kathaṃ maraṇajanmanorduḥkhaprasaktiriti cettāṃ sa eva jānātītyāha -
mūrkhasyeti | yo mṛganadīsalile matsyo'hamiti matsyabhāvamanubhavati sa eva
tasyāścapalavīcivivartanāni jānāti na tu mṛganadībhrāntiśūnyaḥ kaścidityarthaḥ | 50
|
antarbahistvamahamityapi caivamādi sarvātmakaṃ tapati cinnabha ekameva |
śākhāśikhāviṭapapatraphalaikadehaḥ saṃkalpavṛkṣa iva bodhakhamātrasāraḥ
]