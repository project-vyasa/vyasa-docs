`v 1 [
pañcāśadadhikaśatatamaḥ sargaḥ 150
muniruvāca |
evaṃprakārayā yuktyā tenāyaṃ muninā tadā |
tathāhaṃ bodhito yena gato viditavedyatām
]

`v 2 [
tato'sau na mayā tyaktaściraprārthanayā tayā |
avasattena tatrāsau mṛtasyāpi tathaiva ca
]

`v 3 [
yenaitanmuninā proktamindūdayaśubhaṃ vacaḥ |
so'yaṃ paśya muniśreṣṭhastava pārśve vyavasthitaḥ
]

`v 4 [
anenoktamanuktena mamaitanmohaghātinā |
dṛśyapūrvāparajñena yajñenevāttamūrtinā
]

`v 5 [
agniruvāca |
tadākarṇya vacastasya munervyādho'bhavattadā |
pratyakṣaḥ svapnasargaḥ kimiti khinna iva smayāt
]

`v 6 [
vyādha uvāca |
aho mahaccitramidaṃ mune manasi duḥsaham |
kathitaṃ me'dya bhavatā bhavatāpāpahāriṇā
]

`v 7 [
yatsvapnakathitasyeyaṃ jāgratpratyakṣatocyate |
labhyate'pi ca tannāma veda citramidaṃ mune
]

`v 8 [
kathameṣa mahānsvapnapuruṣaḥ sa munīśvara |
jāgratyapi sthirībhūto bhūto bālamateriva
]

`v 9 [
evamāścryamākhyānamucyatāṃ me yathākramam |
kutaḥ kasya kimetadvā paramo hi sa vismayaḥ
]

`v 10 [
muniruvāca |
tataḥ śṛṇu mahābhāga vṛttaṃ citraṃ kimatra me |
kathayāmi samāsena sahasā māṃ kuru tvarām
]

`v 11 [
anenaitattadā tatra varṇitaṃ bodhanāya me |
budho'hamabhavaṃ cāśu mahato'sya tayā girā
]

`v 12 [
tata etadgirā pūrvaṃ svasvabhāvaḥ smṛto mayā |
avadāto'vadātena nabhaseva tapātyaye
]

`v 13 [
aho nu so'hamabhavaṃ munirityuditāśayam |
ahamāsaṃ hṛdā sphītātsnāto'vasthitavismayāt
]

`v 14 [
imāṃ bhogāsthayāvasthāṃ prāpto'smyajña ivādhvagaḥ |
dhāvañchramārtirambvarthī vyarthayā mṛgatṛṣṇayā
]

`v 15 [
kaṣṭaṃ dṛśyopalambhena bhrāntimātrātmanā satā |
bālo vetālakeneva prājño'pi cchalito hyaho
]

`v 16 [
aho nu citrametena mithyā~jānena valgatā |
nītaḥ sarvārthaśūnyena padavīṃ kāmimāmaham
]

`v 17 [
athavā yaḥ so'hamapi bhrāntimātraṃ na sanmayaḥ |
tathāpi citraśatatā yannāmāsadviḍambyate
]

`v 18 [
nāhamasmi `note[nāyamasmītyapi pāṭhaḥ |] na caiveyamidaṃ nāyamapi bhramaḥ
|
citraṃ sarvamidaṃ mithyā sarvaṃ ca sadiva sthitam
]

`v 19 [
kimidānīṃ mayā kāryamiha bandhabhidāntaraḥ |
vidyate me'ṅkuraśchedyaṃ tattāvatsaṃtyajāmyaham
]

`v 20 [
āstāmetadavidyaiṣā vyartharūpā kimetayā |
bhrāntyā bhrāntirasadrūpā tyaktaivaiṣā mayādhunā
]

`v 21 [
upadeṣṭā munirayameṣo'tra bhrāntimātrakam |
brahmaivāhamivābhāti rūpametaddivābhravat
]

`v 22 [
tadevaṃ tāvaduditajñānaṃ vakṣye mahāmunim |
iti saṃcintya sa munistatra prokta idaṃ mayā
]

`v 23 [
munināyaka gacchāmi gaccharīramidaṃ nijam |
draṣṭuṃ yacca pravṛtto'smi śarīraṃ tadapīkṣitum
]

`v 24 [
ityākarṇya sa māmāha hasanmunivarastadā |
kutastau bhavato dehau tau sudūrataraṃ gatau
]

`v 25 [
tau dehau kuto bhavataḥ staḥ | yatastau dāhena bhasmībhāvātsudūrataraṃ gatāviti bhāvaḥ |
24 |
gacchātmanaiva vā paśya vṛttāntaṃ vṛttakovida |
paśya tāvadyathāvṛttaṃ dṛṣṭāntaṃ jñāsyasi svayam
]

`v 26 [
iti saṃcintya taṃ dehaṃ vidaṃ bhūsattayāśmikam |
tyaktvā cidātmā tatprāṇātpavane yojito mayā
]

`v 27 [
prāktanaṃ dehamālokya yāvadāyāmyahaṃ mune |
ihaiva tāvatsthātavyamityuktvāhaṃ gato'nilam
]

`v 28 [
muniṃ prati kimuktvā tvamanilaṃ praviṣṭastadāha - prāktanamiti | gataḥ praviṣṭaḥ |
27 |
atha vātarathārūḍho gaganaṃ bhrāntavānaham |
puṣpāmoda ivānantaṃ gatvā ca tvarayā ciram
]

`v 29 [
tataściramapi bhrāntvā yadā galabilaṃ calan |
ahaṃ na prāptavāṃstasya kiṃcidasyāśayasthitaḥ
]

`v 30 [
tadā khedamupāyātaḥ paramaṃ punarāgataḥ |
idameva jagajjālamahamālānamātmanaḥ
]

`v 31 [
ihemaṃ labdhavānagre tato munimanuttamam |
pṛṣṭavānahamekāgrastata evamidaṃ gṛhe
]

`v 32 [
kimetadbhagavanbrūhi pūrvāparavidāṃvara |
tvaṃ paśyasi yathāvṛttamuttamajñānacakṣuṣā
]

`v 33 [
yasya dehaṃ praviṣṭo'haṃ sa ca madvapureva ca |
kva tāvubhau gatau dehau na labdhau kena hetunā
]

`v 34 [
mayāticiramābhogi bhrāntaṃ saṃsāramanḍalam |
sthāvarādā''tmanaḥ kasmātprāptaṃ galabilaṃ na tat
]

`v 35 [
gatveti pṛṣṭaḥ sa muniḥ samuvāca mahāśayaḥ |
jānāsi tatsvayaṃ kasmāditi tāmarasekṣaṇa
]

`v 36 [
etadālokayasi cetsvayaṃ yogaikasaṃvidā |
tatpaśyasyeva niḥśeṣaṃ yathā karatalāmbujam
]

`v 37 [
tathāpi yadi śuśrūṣā tavāsti vacasā mama |
tadidaṃ śṛṇu vakṣyāmi yathāvṛttamakhaṇḍitam
]

`v 38 [
tapastāmarasoṣṇāṃśuḥ kalyāṇakamalākaraḥ |
jñānābjasya harernābhirnāsti tāvadayaṃ bhavān
]

`v 39 [
sa tvaṃ kadācittapasi sthitaḥ svapnadidṛkṣayā |
kasyaciddhṛdayaṃ jantoḥ praviṣṭaḥ puṣṭasaṃvidā
]

`v 40 [
yattvaṃ praviṣṭo hṛdayaṃ tatredaṃ bhuvanatrayam |
dṛṣṭavānasi vistīrṇaṃ rodasī vipulodaram
]

`v 41 [
iti tvayi ciraṃ vyagre dehastasya tathāpi ca |
sa saṃsuptākṛtiryatra sthitastatra mahāvane
]

`v 42 [
lagno'gnirdhūmadhūmrābhrasāmbarāmbaraḍambaraḥ |
valadbalacalālātacakrasūryendumaṇḍalaḥ `note[sphuradbala iti pāṭho
vyākhyānukūlaḥ |]
]

`v 43 [
dagdhābhrabhasmasaṃpūrṇadhūmābhrāsitakambalaiḥ |
ānīlākāśadalapairiva saṃchāditāmbaraḥ
]

`v 44 [
darīgṛhaviniṣkrāntasiṃhanirhrādatarjitaiḥ |
sphuṭaiścaṭacaṭāsphoṭairjaḍīkṛtadigantaraḥ
]

`v 45 [
tālītamālamālānāṃ gatānāmagnivṛkṣatām |
pātairutpātavahnyabhrakavatkarakarairghanaḥ
]

`v 46 [
dūradeśagatairdṛṣṭasthirasaudāmanīdhiyā |
dravatkanakaniṣpandakuṭṭimaṃ vyoma darśayan
]

`v 47 [
kaṇaistārāgaṇaṃ kāntairvyomni dviguṇatāṃ nayan |
vakṣaḥsthabālavanitānayanānandanandanaḥ
]

`v 48 [
jvālādhamadhamāśabdapradhmātagaganodaraḥ |
darīgṛhaviniṣkrāntabhrāntonnidravanecaraḥ
]

`v 49 [
ardhadagdhadravatsiṃhamṛgavyādhavihaṃgamaḥ |
kvathatsaraḥsaritsrotorandhitogravanecaraḥ
]

`v 50 [
valajjvālājvaladbālacamarīcārucañcuraḥ |
dahyamānavanaprāṇimedogandhāvṛtāmbudaḥ
]

`v 51 [
ena kalpāgnikalpena valgatā vanavahninā |
sayuṣmadāśramo dagdhaḥ sarpeṇeva prasarpatā
]

`v 52 [
vyādha uvāca |
tatra tasyāgnidāhasya hetuḥ kaḥ prākṛto mune |
tadvanaṃ te baṭuvarāḥ sarvaṃ naṣṭaṃ kathaṃ saha
]

`v 53 [
muniruvāca |
saṃkalpakamanaspandaḥ saṃkalpādikṣayodaye |
yathā heturnirāspando'cirāddhi trijagattathā
]

`v 54 [
hṛdaye ca vanānte ca kṣobhākṣobheṣu kāraṇam |
yathā spando'cirātspandastathā trijagatāmiha
]

`v 55 [
dhātuḥ saṃkalpanagaraṃ jagattatspandanaṃ tviha |
prajodayakṣayakṣobhavarṣāvarṣādikāraṇam
]

`v 56 [
brahmādimānaso'pyasya so'pyanyatra cidambare |
ityaparyavasāneyaṃ śāntaikā cinnabhogatiḥ
]

`v 57 [
citinabhasi cinnabhaḥśrīḥ kacatīti nirāmayā viduṣām |
mūrkhāṇāṃ tu yathaiṣā yādṛgvā tanmayīha na sat
]