`v 1 [
navanavatyadhikaśatatamaḥ sargaḥ 199
śrīrāma uvāca |
nityaṃ jñānaikaniṣṭhatvādātmārāmatayā tathā |
muktaiḥ karmaparityāgaḥ kasmānna kriyate mune
]

`v 2 [
śrīvasiṣṭha uvāca |
heyopādeyadṛṣṭī dve yasya kṣīṇe hi tasya vai |
kriyātyāgena ko'rthaḥ syātkriyāsaṃśrayaṇena vā
]

`v 3 [
na tadastīha yattyājyaṃ jñasyodvegakaraṃ bhavet |
na vāsti yadupādeyaṃ tajjñasaṃśreyatāṃ gatam
]

`v 4 [
jñasya nārthaḥ karmatyāgairnārthaḥ karmasamāśrayaiḥ |
tena sthitaṃ yathā yadyattattathaiva karotyasau
]

`v 5 [
yāvadāyuriyaṃ rāma niścitaṃ spandate tanuḥ |
tadyathāprāptamavyagraṃ spandatāmapareṇa kim
]

`v 6 [
anyathānyatra cetkāryā kriyā tyaktvā nijaṃ kramam |
samāne hi kriyāspande ko doṣaḥ satkrame kila
]

`v 7 [
samayā svacchayā buddhyā satataṃ nirvikārayā |
yathā yatkriyate rāma tadadoṣāya sarvadā
]

`v 8 [
iha mahyāṃ mahābāho bahavo bahudṛṣṭayaḥ |
bahudhā bahudoṣeṣu viharanti vicakṣaṇāḥ
]

`v 9 [
gatasaṅgatayā buddhyā viharanti yathāsthiteḥ |
gṛhasthārambhiṇaḥ kecijjīvanmuktāḥ sthitā bhuvi
]

`v 10 [
tajjñā rājarṣayaścānye vītarāgā bhavādṛśāḥ |
asaṃsaktadhiyo rājyaṃ kurvanti vigatajvarāḥ
]

`v 11 [
kecitprakṛtavedārthavyavahārānusāriṇaḥ |
yajñaśiṣṭāśino nityamagnihotre vyavasthitāḥ
]

`v 12 [
keciccaturṣu varṇeṣu dhyānadevārcanādikām |
svakriyāmanutiṣṭhantaḥ sthitā vividhayehayā
]

`v 13 [
kecitsarvaparityāgamantaḥ kṛtvā mahāśayāḥ |
sarvakarmaparā nityaṃ tajjñā evājñavatsthitāḥ
]

`v 14 [
svapne'pyadṛṣṭalokāsu mugdhamugdhamṛgāsu ca |
vanāvanīṣu śūnyāsu keciddhyānaparāyaṇāḥ
]

`v 15 [
puṇyavadbhiḥ sadā juṣṭe puṇyopacayakāriṇi |
śamaśālisamācāre kecidāyatane sthitāḥ
]

`v 16 [
rāgadveṣaprahāṇārthaṃ tyaktvā deśaṃ samāśayāḥ |
kecidanyatra deśe ca padamālambya saṃsthitāḥ
]

`v 17 [
vanādvanaṃ purādgrāmaṃ sthānātsthānaṃ girergirim |
bhramantaḥ saṃsthitāḥ kecitsaṃsārocchittaye budhāḥ
]

`v 18 [
vārāṇasyāṃ mahāpuryāṃ prayāge caiva pāvane |
śrīparvate siddhapure badaryāśramake tathā
]

`v 19 [
śālagrāme mahāpuṇye kalāpagrāmakoṭare |
mathurāyāṃ ca puṇyāyāṃ tathā kālañjare girau
]

`v 20 [
mahendravanagulmeṣu gandhamādanasānuṣu |
dardurācalavapreṣu sahyakācalabhūmiṣu
]

`v 21 [
vindhyaśailasya kaccheṣu malayasyodareṣu ca |
kailāsavanajāleṣu ṛkṣavatkuhareṣu ca
]

`v 22 [
eteṣvanyeṣu cānyeṣu vaneṣvāyataneṣu ca |
tapasvinastathā rāma bahavo bahudṛṣṭayaḥ
]

`v 23 [
kecittyaktanijācārāḥ kecicca kramasaṃsthitāḥ |
kecitprabuddhamatayo nityamunmattaceṣṭitāḥ
]

`v 24 [
saṃnyāsavidhinā tyaktanijācārāḥ | kramā brahmacaryādyāśramadharmāstatsaṃsthitāḥ |
23 |
kecitsvadeśarahitāḥ kecittyaktanijāspadāḥ |
ekasthānaratāḥ kecidbhramantaḥ kecidāsthitāḥ
]

`v 25 [
ekasthāne svagṛha eva ratāḥ prītimantaḥ sarvajanānukūlyena vikṣepaśūnyā iti yāvat |
24 |
eteṣāṃ mahatāṃ madhye nabhastalanivāsinām |
pātālaniratānāṃ ca daityādīnāṃ mahāmate
]

`v 26 [
vijñātalokaparyāyāḥ samyagdarśananirmalāḥ |
kecitprabuddhamatayo dṛṣṭadṛśyaparāvarāḥ
]

`v 27 [
aprabuddhadhiyaḥ keciddolāndolitacetasaḥ |
nivṛttāḥ pāpakācārātsujanānugatāḥ sthitāḥ
]

`v 28 [
ardhaprabuddhamatayaḥ kecijjñānāvalepataḥ |
parityaktakriyācārā ubhayabhraṣṭatā gatāḥ
]

`v 29 [
itthamasmiñjanānīke janmasaṃtaraṇārthinaḥ |
bahavaḥ saṃsthitā rāma bahudhā bahudṛṣṭayaḥ
]

`v 30 [
saṃsārottaraṇe tatra na heturvanavāsitā |
nāpi svadeśavāsitvaṃ na ca kaṣṭatapaḥkriyāḥ
]

`v 31 [
na kriyāyāḥ parityāgo na kriyāyāḥ samāśrayaḥ |
nācāreṣu samārambhavicitraphalapālayaḥ
]

`v 32 [
svabhāvaḥ kāraṇaṃ nāma saṃsārottaraṇaṃ prati |
asaṃsaktaṃ mano yasya sa tīrṇo bhavasāgarāt
]

`v 33 [
śubhāśubhāḥ kriyā nityaṃ kurvanpariharannapi |
punareti na saṃsāramasaṃsaktamanā muniḥ
]

`v 34 [
śubhāśubhāḥ kriyā nityamakurvannapi durmatiḥ |
nimajjatyeva saṃsāre parityaktamanāḥ śaṭhaḥ
]

`v 35 [
makṣikevāntaḥsārajñā duḥkhāduḥkhapradāyinī |
na nivārayituṃ śakyā na ca mārayituṃ matiḥ
]

`v 36 [
kākatālīyayogena kadācitsvasya cetasaḥ |
pravṛttirjāyate siddhyai svayamātmāvalokane
]

`v 37 [
avalokanato labdhvā tattvaṃ nairmalyamāgatam |
ceto bhavati nirdvandvamasaṃsaktamanāmayam
]

`v 38 [
acittatvaṃ prayātena sattvarūpeṇa cetasā |
samo bhūtvā sukhaṃ tiṣṭha parākāśāṃśarūpabhṛt
]

`v 39 [
adhigataparamārthastyaktarāgādidoṣaḥ samamatiruditātmā tvaṃ mahātmā
mahātman |
raghutanaya viśokastiṣṭha niḥśaṅkameko jananamaraṇamuktaṃ pāvanaṃ
tatpadaṃ tvam
]

`v 40 [
prakṛtimalavikāropādhibodhādirūpaṃ jagati vimalarūpe nāsti kiṃcitkvacicca |
sphuṭamakṛtakamasti brahma ciddhāma tacca svayamahamiti matvā tiṣṭha
niḥśaṅkamekaḥ
]

`v 41 [
adhikavacnagamyaṃ nānyadastyaṅga kiṃcittava śubhamupadeśyaṃ
jñānasaṃbodhanāya |
uditamakhilamādyaṃ jñānasāraṃ samagraṃ viditasakalavedyo rāghava tvaṃ hi
jātaḥ
]

`v 42 [
śrīvālmīkiruvāca |
ityuktvā munināyako vyapagatāśeṣaiṣaṇe rāghave sarvasmiṃśca sabhājane
sthitavati dhyānaikatānopame |
prāpte brahmapadaṃ dhiyā dhavalayā tūṣṇīmabhūtṣaṭpadaḥ kṛtvevāraṇitaṃ
sarojapaṭale pātuṃ pravṛtto rasam
]