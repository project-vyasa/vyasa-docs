`v 1 [
saptanavatitamaḥ sargaḥ 97
śrīvasiṣṭha uvāca |
saṃvinmayatvājjagataḥ svapnasya paramātmanaḥ |
brahmākāśatayā sarvaṃ brahmaivetyanubhūyate
]

`v 2 [
bhramasya cātidṛśyatvādadṛśyatvānmahāciteḥ |
madaśaktivadātmeti satyatāsyāpi yujyate
]

`v 3 [
asattvāddṛśyaviśrānteralabhyatvānmahāciteḥ |
upalabdhurabhāvācca śūnyanāmnīva satyapi
]

`v 4 [
cinmātraṃ puruṣo'kartā sametyavyaktato jagat |
evaṃdṛṣṭeḥ satyametadevamarthānubhūtitaḥ
]

`v 5 [
vivarto brahmaṇo dṛśyamityevaṃvādino'pi sat |
matamevaṃsvarūpāṇāmarthānāmanubhūtitaḥ
]

`v 6 [
paramāṇusamūhātma jagadityapi satyataḥ |
saṃvedyate yathā yadyattattathaivānubhūtitaḥ
]

`v 7 [
yathā dṛṣṭaṃ tathaivedamiha loke paratra ca |
nāsanna saditi prauḍhā satyamādhyātmikī gatiḥ
]

`v 8 [
bāhyamevāsti nāstyanyadityanye satyavādinaḥ |
svātmanyakṣagaṇātītaṃ prāpnuvanti na te yataḥ
]

`v 9 [
anārataviparyāsadarśanātkṣaṇabhaṅgadhīḥ |
yuktaiva tadvidāmādyaṃ sarvaśakti hi tatpadam
]

`v 10 [
kalaviṅkaghaṭanyāyo dharma ityapi tadvidām |
tathātmasiddhermlecchānāṃ taddeśeṣu na duṣyati
]

`v 11 [
samāḥ santaśca viprāgniviṣāmṛtamṛtiṣvapi |
bhāntyevaṃ tadvidāṃ sarvamidaṃ sarvātmakaṃ yataḥ
]

`v 12 [
svabhāvasiddhamevedaṃ yuktamityeva tadvidām |
anviṣṭā yāti no prāptiṃ buddhimatsarvakartṛtā
]

`v 13 [
ekaḥ sarvatra karteti satyaṃ tanmayacetasām |
so'yaṃ niścayavānso'tra tadāpnotītyabādhitam
]

`v 14 [
ayaṃ lokaḥ paraścāsti snānāgnyādi ca netarat |
etadetādṛśaṃ satyaṃ viddhi bhāvitabhāvanam
]

`v 15 [
aśeṣaṃ śūnyameveti bauddhānāmetadeva sat |
labhyate tadvicāreṇa yatra kiṃcana naiva hi
]

`v 16 [
citiścintāmaṇiriva kalpadruma ivepsitam |
āśu saṃpādayatyantarātmanātmani khātmikā
]

`v 17 [
nedaṃ śūnyaṃ na cāśūnyamityavastu na tadvidām |
sarvaśaktirhi sā śaktirna tadvidyata eva tat
]

`v 18 [
tasmātsvaniścaye yasminyaḥ sthitaḥ sa tathā tataḥ |
avaśyaṃ phalamāpnoti na cedbālyānnivartate
]

`v 19 [
vicārya paṇḍitaiḥ sārdhaṃ śreṣṭhavastuni dhīmatā |
sa rūḍho niścayo grāhyo netaratra yathā tathā
]

`v 20 [
saṃbhavatyuttamaprajñaḥ śāstrato vyavahārataḥ |
yo yatra nāma tatrāsau paṇḍitastaṃ samāśrayet
]

`v 21 [
satāṃ vivadamānānāṃ sacchāstravyavahāriṇām |
yaḥ samāhlādako'nindyaḥ sa śreṣṭhastaṃ samāśrayet
]

`v 22 [
sarva evāniśaṃ śreyo dhāvanti prāṇino balāt |
parinimnaṃ payāṃsīva tadvicārya samāśrayet
]

`v 23 [
kallolairuhyamānānāṃ nṛṇāṃ saṃsārasāgare |
ajñātā divasā yānti tṛṇānāmiva bindavaḥ
]

`v 24 [
śrīrāma uvāca |
jagatpūrvaṃ letavāpi viśrāntā vitate pade |
pūrvāparavicāreṇa ke parābhāvadarśinaḥ
]

`v 25 [
śrīvasiṣṭha uvāca |
jātau jātau katipaye vyapadeśyā bhavanti te |
yeṣāṃ yānti prakāśena divasā bhāsvatāmiva
]

`v 26 [
adhaścordhvaṃ ca dhāvantaścakrāvartavivartanaiḥ |
sarve tṛṇavaduhyante mūḍhā mohabhavāmbudhau
]

`v 27 [
naṣṭātmasthitayo bhogavahniṣu prajvalantyalam |
devā divi davenādrau dahyamānā drumā iva
]

`v 28 [
pātitā madasaṃpannā dānavā dānavāribhiḥ |
gajā iva nirālānā ghore nārāyaṇāvaṭe
]

`v 29 [
na gandhamapi gandharvā darśayanti vivekajam |
gītapītaparāmarśāḥ saranti hariṇā iva
]

`v 30 [
gandhaṃ leśamapi | gītalakṣaṇaṃ yatpītaṃ madirā tadvaśātparairariṣaḍvargaiḥ |
parāmṛśyanta iti parāmarśā hariṇā iva mṛtyuvyādhasaṃnidhiṃ saranti gacchanti |
29 |
vidyādharāśca vidyānāmādhāratvena mohitāḥ |
sphuritānāmudārāṇāmapi kurvanti nādaram
]

`v 31 [
yakṣā vikṣobhitabhuvo dakṣatāmakṣatā iva |
darśayantyasahāyeṣu bālavṛddhātureṣu ca
]

`v 32 [
dantināmiva mattānāṃ raṃhasā hariṇāriṇā |
kṛtaḥ kariṣyasi tvaṃ ca rākṣasānāṃ parikṣayam
]

`v 33 [
bhṛśaṃ piśācāḥ paśyanti bhūtabhojanacintayā |
dhūmāndhakārānilayā jvālayāhutayo yathā
]

`v 34 [
nāgajālamṛṇālāni magnāni dharaṇītale |
nagānāmiva mūlāni jaḍānīva sthitānyalam
]

`v 35 [
vivaraṃ śaraṇaṃ yeṣāṃ kīṭānāmiva bhūtale |
teṣāmasurabālānāṃ vivekeṣu kathaiva kā
]

`v 36 [
alpamātrakaṇārthena saṃcaranti divāniśam |
pipīlikāsadharmāṇaḥ prāyeṇa puruṣā api
]

`v 37 [
sarvāsāṃ bhūtajātīnāṃ vyagrāṇāṃ vyarthadīrghayā |
kṣībāṇāmiva gacchanti divasāni durīhayā
]

`v 38 [
na kaṃcitsaṃspṛśatyantarviveko vimalo janam |
jale'gādhe nipatitaṃ nimajjantaṃ rajo yathā
]

`v 39 [
nīyante niyamādhūtā mānavā mānavāyubhiḥ |
kāmpikaiḥ sphuṭatāpūtāḥ kirārunikarā iva
]

`v 40 [
pānabhojanajambāle gahane yoginīgaṇāḥ |
durgandhapalvalodgāre patitāḥ pāmarā iva
]

`v 41 [
surārudhirapānamāṃsādibhojanalakṣaṇo jambālaḥ paṅko yasmiṃstathāvidhe
tāmasadharmaphalabhogāsaktilakṣaṇadurgandhapalvalodgāre patitāḥ | avivekenetyarthaḥ |
40 |
kevalaṃ yamacandrendrarudrārkavaruṇānilāḥ |
jīvanmuktā haribrahmaguruśukrānalādayaḥ
]

`v 42 [
prajāpatīnāṃ saptarṣidakṣādyāḥ kaśyapādayaḥ |
nāradādyāḥ kumārādyāḥ sanakādyāḥ surātmajāḥ
]

`v 43 [
dānavānāṃ hiraṇyākṣabaliprahrādaśambarāḥ |
mayavṛtrāndhanamucikeśiputramurādayaḥ
]

`v 44 [
vibhīṣaṇādyā rakṣassu prahastendrajidādayaḥ |
śeṣatakṣakakarkoṭamahāpadmādayo'hiṣu
]

`v 45 [
brahmaviṣṇvindralokeṣu vāstavyā muktadehinaḥ |
muktasvabhāvāstuṣitāḥ siddhāḥ sādhyāśca kecana
]

`v 46 [
mānuṣeṣu ca rājāno munayo brāhmaṇottamāḥ |
jīvanmuktāḥ saṃbhavanti viralāstu raghūdvaha
]

`v 47 [
bhūtāni santi sakalāni bahūni dikṣu bodhānvitāni viralāni bhavanti kiṃtu |
vṛkṣā bhavanti phalapallavajālayuktāḥ kalpadrumāstu viralāḥ khalu saṃbhavanti
]