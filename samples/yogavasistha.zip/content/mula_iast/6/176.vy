`v 1 [
ṣaṭsaptatyadhikaśatatamaḥ sargaḥ 176
śrīrāma uvāca |
jaganti santyasaṃkhyāni bhaviṣyanti gatāni ca |
tatkathābhiḥ kathaṃ brahmanprabodhayasi māmimam
]

`v 2 [
śrīvasiṣṭha uvāca |
jagatsvapneṣu śabdārthasaṃbandho'vagatastvayā |
na nāma na ca lokena vyarthaṃ tatkathanaṃ tataḥ
]

`v 3 [
yā kathāvagatātmabhyāṃ śabdārthābhyāṃ nigadyate |
budhyate setarā nāntaḥ saiveha vyavahāriṇī
]

`v 4 [
yadā viditavedyaḥ saṃstrikālāmaladarśanaḥ |
bhaviṣyasi tadā tāni pratyakṣeṇaiva bhotsyase
]

`v 5 [
svapne cinmātramevādyaṃ svayaṃ bhāti jagattayā |
yathā tathaiva sargādau nātrānyadupapadyate
]

`v 6 [
aṇāvaṇāvasaṃkhyāni tena santi jaganti khe |
teṣāṃ tānvyavahāraughānsaṃkhyātuṃ ka iva kṣamaḥ
]

`v 7 [
atraiva me purā proktaṃ matpitrā padmajanmanā |
padmareṇumatākhyānaṃ śṛṇu tatkathayāmi te
]

`v 8 [
purā pṛṣṭo mayā brahmā jagajjālamidaṃ kiyat |
kva vā bhātīti vada me brahmovāca tataḥ sa mām
]

`v 9 [
śrībrahmovāca |
brahmaivedaṃ mune sarvaṃ jagadityavabhāsate |
satāmanantaṃ sattvena jagattvenāsatāmapi
]

`v 10 [
śubhaṃ mamedamākhyānaṃ śṛṇu śravaṇabhūṣaṇam |
brahmāṇḍapiṇḍa ityuktaṃ brahmāṇḍākhyānameva ca
]

`v 11 [
asti khe khādananyātmā cidvyomaparamāṇukaḥ |
śūnyarūpamivākāśe śuddhaḥ spanda ivānile
]

`v 12 [
so'paśyadātmanā svapna iva jīvatvamātmani |
śūnyarūpamivākāśaṃ pavanaḥ spandanaṃ yathā
]

`v 13 [
ākāśarūpamajahadeva jīvastataḥ svayam |
apaśyadahamityeva rūpamākāśarūpakam
]

`v 14 [
ahaṃkārastvahaṃbuddhirityevāpaśyadātmani |
ekaniścayanirmāṇamayī māyānurūpiṇī
]

`v 15 [
buddhirmanohamityevaṃ svapne paśyadasanmayam |
namayantyātmanātmānamavikalpaṃ vikalpanaiḥ
]

`v 16 [
apaśyattanmanaḥ svapne dehe pañcendriyaṃ tataḥ |
anākāraṃ ghanākāraṃ svapnādritvamivājñadhīḥ
]

`v 17 [
dadarśa sa manodeho vapustribhuvanātmakam |
khātmā khātmaiva nirbhitti bhittibhāsuramātatam
]

`v 18 [
anekabhūtakalitaṃ nānāsthāvarajaṅgamam |
kalanākālakalitaṃ kalpitānyonyasaṃgamam
]

`v 19 [
svapne pratyekamevātra paśyatyādarśabimbitam |
iva trailokyanagaraṃ navaraṅgamanoharam
]

`v 20 [
atha pratyekamatrāpi navaraṅgamanoharam |
trijagadvetti hṛdaye svādarśa iva bimbitam
]

`v 21 [
paramāṇoḥ paramāṇoriti santi tanūdare |
atanūni jagantyuccairghanānīva ca tānyapi
]

`v 22 [
avidyeyamananteyamavidyātvena cetitā |
brahmatvena parijñātā bhavati brahma nirmalam
]

`v 23 [
evaṃ draṣṭāpi yaḥ svapnajālaṃ dṛṣṭe na kiṃcana |
ko'tra draṣṭā kuto dṛśyaṃ kva dvaitaṃ kva ca kāraṇam
]

`v 24 [
sarvaṃ niḥśāntamābhātaṃ khātma nirbhitti kevalam |
brahmātmani sthitaṃ svacchamādyantaparivarjitam
]

`v 25 [
brahmāṇḍalakṣanicayāḥ paramātmanīti nityaṃ sthitā nipuṇamanyavadapyananye |
vāriṇyavāritavisāritaraṅgavegāllolaṃ sthitāmbuparamāṇucayā yathaite
]