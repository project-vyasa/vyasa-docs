`v 1 [
ṣaḍviṃśādhikaśatatamaḥ sargaḥ 126
śrīrāma uvāca |
anantaraṃ muniśreṣṭha kurvantaḥ kiṃ vipaścitaḥ |
āsaṃsteṣu diganteṣu sadvīpābdhivanādriṣu
]

`v 2 [
śrīvasiṣṭha uvāca |
śṛṇu kiṃvṛttameteṣāṃ tāta tatra vipaścitām |
tālītamālamālāḍhyadvīpādrivanacāriṇām
]

`v 3 [
krauñcadvīpagirereko vipaścitpaścime taṭe |
kaṭenādritaṭe piṣṭaḥ kariṇā kamalaṃ yathā
]

`v 4 [
teṣāṃ madhye eko vipaścit krauṃcadvīpe prasiddhasya varṣasīmagireḥ paścime taṭe
bhāge kariṇā adritaṭe vapraśilāyāṃ kaṭena gaṇḍena dantābhyāṃ piṣṭaḥ saṃcūrṇito
mṛta ityarthaḥ | varaprārthanakāle āsiddhagamyamadhvānaṃ mṛtyurasmākamastu mā
ityavadhikaraṇāttaduttaraṃ siddhāgamyo'dhvetyanuktamapi gamyate | evamagre'pi bodhyam |
3 |
dvitīyo nabhasā nīto rakṣasā vikṣatāṅgakaḥ |
nikṣipto vāḍave vahnau tatra bhasmatvamāgataḥ
]

`v 5 [
tṛtīyastraidaśaṃ deśaṃ nīto vidyādhareṇa vai |
gato'praṇāmakupitaśakraśāpena bhasmatām
]

`v 6 [
caturthaścaturaṃ gacchankuśadvīpagirestaṭe |
durvāreṇa nadīkacche makareṇāṣṭadhākṛtaḥ
]

`v 7 [
iti te pañcatāṃ prāptā diṅmukheṣvākulāśayāḥ |
kṣaye caturṣu catvāro bhūpālā lokapālavat
]

`v 8 [
atha teṣāṃ dadarśāsau vyomnyeva vyomarūpiṇām |
saṃvitprāktanasaṃskārādvyomātmāvanimaṇḍalam
]

`v 9 [
saptadvīpābdhivalayaṃ purapattanabhūṣaṇam |
suraśailaśiraḥpīṭhaṃ brahmalokaśiromaṇim
]

`v 10 [
candrārkabimbanayanaṃ tārāmuktākalāpakam |
vilolameghavasanaṃ nānāvanatanūruham
]

`v 11 [
dehānvipaścitāṃ saṃviddadarśa caturo'pi sā |
prāgvatkalpaparāvṛttau dyaurdigantānivātatān
]

`v 12 [
ātivāhikasaṃvitteste'vyomni vyomatātmakāḥ |
ādhibhautikadehatvabhāvāndadṛśuragrataḥ
]

`v 13 [
asyātmakatve'vidyeyaṃ kiyatī syāditīkṣitum |
catvāro'pi pravṛttāste saṃskāravaśataḥ puraḥ
]

`v 14 [
dṛśyadarśanayorurvīmaṇḍalānubhavākṛteḥ |
niṣṭhāṃn draṣṭumavidyāyā bhremurdvīpāntarāṇi te
]

`v 15 [
dvīpasaptakamullaṅghya samahārṇavasaptakam |
vipaścitpaścimaḥ prāpa ghanabhūmau janārdanam
]

`v 16 [
tasmādanupamaṃ jñānaṃn samāsādya digantare |
tasminneva samādhāne so'tiṣṭhadvarṣapañcakam
]

`v 17 [
tato dehaṃ parityajya citte sattāmupāgate |
sa tatprāṇa evākāśaṃ paraṃ nirvāṇamāyayau
]

`v 18 [
pūrvaḥ parvaṇi śītaṃśubimbapārśve sthitaṃ vapuḥ |
cintayaṃściramunnaṣṭadehaścandrapure sthitaḥ
]

`v 19 [
dakṣiṇaḥ śālmalidvīpe rājyamutsannaśātravaḥ |
karotyadyāpi na sato vismṛtānyaviniścayaḥ
]

`v 20 [
uttarastaralāsphālakallole saptamāmbudhau |
sahasramekaṃ varṣāṇāmuvāsa makarodare
]

`v 21 [
makarodaramāṃsāśī mṛte makaranāyake |
makarodarato'bdheśca nirgato makaro yathā
]

`v 22 [
tato'śītisahasrāṇi yojanānāṃ ghanāvanim |
himakalpajalāmbhodherullaṅghya sughanodarīm
]

`v 23 [
prāpto daśasahasrāṇi yojanānāṃ mahāmahīm |
sauvarṇīṃ surasaṃcārasaraṇiṃ mṛtavānasau
]

`v 24 [
tasyāṃ bhūmau ca madhye ca vipaścinnākitāmagāt |
uttamāmagnimadhyasthaṃ kṣaṇātkāṣṭhamivāgnitām
]

`v 25 [
pradhānadevo bhūtvāsau lokālokagiriṃ gataḥ |
asya bhūmaṇḍalatarorālavālamiva sthitam
]

`v 26 [
sa pañcāśatsahasrāṇi yojanānāṃ samunnataḥ |
ālokalokācārāḍhyo bhāga eko'sya netaraḥ
]

`v 27 [
lokālokaśiraḥ prāptaṃ tārakāmārgasaṃsthitam |
adhaḥsthitā apaśyaṃstamuccanakṣatraśaṅkayā
]

`v 28 [
tasmātpradeśāttatpāre tamastasya mahāgireḥ |
caturdikkaṃ mahākhātaṃ nabhaḥ śūnyamanantakam
]

`v 29 [
tato bhūgolako'yaṃ hi samāpto vartulākṛtiḥ |
nabhaḥśūnyaṃ mahākhātaṃ tatastimirapūritam
]

`v 30 [
tatrālikajjalatamālanabhontarālanīlaṃ tamo na ca mahī na ca jaṃgamādi |
nālambanaṃ na ca manāgapi vastujātaṃ kiṃcitkadācidapi saṃbhavatīti viddhi
]