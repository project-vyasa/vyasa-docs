`v 1 [
aṣṭanavatyadhikaśatatamaḥ sargaḥ 198
śrīvasiṣṭha uvāca |
bhūyo nipuṇabodhāya śṛṇu kiṃcidraghūdvaha |
punaḥpunaryatkathitaṃ tadajñe'pyavatiṣṭhate
]

`v 2 [
rāghava prathamaṃ proktaṃ sthitiprakaraṇaṃ mayā |
yenedamitthamutpannamiti vijñāyate jagat
]

`v 3 [
tato jagati jātena paropaśamaśālinā |
bhavitavyamiti proktaṃ mayopaśmayuktibhiḥ
]

`v 4 [
upaśāntiprakaraṇe proktairupaśamakramaiḥ |
paramopaśamaṃ gatvā vastavyamiha vijvaram
]

`v 5 [
prāptaprāpyena tajjñena yathā saṃsāradṛṣṭiṣu |
vihartavyaṃ hi naḥ kiṃcitsvalpaṃ śrotavyamasti te
]

`v 6 [
janma saṃprāpya jagati bālya eva jagatsthitim |
yathābhūtāmimāṃ buddhvā vastavyamiha vijvaram
]

`v 7 [
sarvasauhārdajananīṃ sarvasyāśvāsakāriṇīm |
samatāmalamāśritya vihartavyamihānagha
]

`v 8 [
sarvasaṃpattisubhagaṃ sarvasaubhāgyavardhanam |
samatāsulatāyāstu phalaṃ bhavati pāvanam
]

`v 9 [
samatāsubhagehānāṃ kurvatāṃ prakṛtaṃ kramam |
sarvaiveyaṃ jagallakṣmīrbhṛtyatāmeti rāghava
]

`v 10 [
na tadāsādyate rājyānna kāntājanasaṃgamāt |
anapāyi sukhaṃ sāraṃ samatvādyadavāpyate
]

`v 11 [
dvandvopaśamasīmāntaṃ saṃrambhajvaranāśanam |
sarvaduḥkhātapāmbhodaṃ samatvaṃ viddhi rāghava
]

`v 12 [
mitrībhūtākhilaripuryathābhūtārthadarśanaḥ |
durlabho jagatāṃ madhye sāmyāmṛtamayo janaḥ
]

`v 13 [
prabuddhasya svacittendorniṣyandamamṛtādhikam |
sāmyamāsvādya jīvanti sarve vai janakādayaḥ
]

`v 14 [
sāmyamabhyasyato jantoḥ svadoṣo'pi guṇāyate |
duḥkhaṃ sukhāyate nityaṃ maraṇaṃ jīvitāyate
]

`v 15 [
sāmyasaundaryasubhagaṃ vanitā muditādikāḥ |
āliṅganti mahātmānaṃ nityaṃ vyasanitā iva
]

`v 16 [
samaḥ samudito nityaṃ samo'nuditadhīḥ sadā |
na kāścidiha tāḥ santi yāḥ samasya hi nardhayaḥ
]

`v 17 [
sarvakāryasamaṃ sādhuṃ prakṛtavyavahāriṇam |
cintāmaṇimivodāraṃ pravāñchanti narāmarāḥ
]

`v 18 [
samyakkāriṇamuddāmamuditaṃ samacetasam |
na dahantyagnayo rāma nāpaḥ siñcanti mānavam
]

`v 19 [
yadyathā tattathā yena kriyate dṛśyate tathā |
ānandodvegamuktena kastaṃ tolayituṃ kṣamaḥ
]

`v 20 [
mitrāṇi bandhuripavo rājāno vyavahāriṇaḥ |
samyakkāriṇi tattvajñe viśvasanti mahādhiyaḥ
]

`v 21 [
nāniṣṭātprapalāyante neṣṭādāyānti tuṣṭatām |
prakṛtakramasaṃprāptāstattvajñāḥ samadarśinaḥ
]

`v 22 [
tyaktvā sarvānupādeyānrāma bhāvānaninditān |
samatāyāmaduḥkhāyāṃ dadhānā vṛttimuttamām
]

`v 23 [
vihasanti jagajjālaṃ jīvayanti nirāmayāḥ |
pūjyante vibudhaiḥ sarvaiḥ samatāmuditāśayāḥ
]

`v 24 [
prakṛtakramasaṃprāptaṃ mukhendau kopameva yaḥ |
samāśayo dhārayati syātsaumyāmṛtavajjanaḥ
]

`v 25 [
yatkaroti yadaśnāti yadākrāmati nindati |
samadṛṣṭistadasyeyaṃ stauti nityaṃ janāvaliḥ
]

`v 26 [
yacchubhaṃ vāśubhaṃ yacca yaccireṇa yadadya vā |
samadṛṣṭikṛtaṃ samyagabhinandati tajjanaḥ
]

`v 27 [
sukhaduḥkheṣu bhīmeṣu saṃtateṣu mahatsvapi |
manāgapi na vairasyaṃ prayānti samadṛṣṭayaḥ
]

`v 28 [
śibhirbhūpaḥ kapotāya māṃsamaṅgavikartanam |
dadau muditayā buddhyā samadṛṣṭitayānayā
]

`v 29 [
prāṇebhyo'pi priyatamāṃ kāntāmagre vikālitām |
dṛṣṭvāpyaṅga mahīpālo na mumoha samāśayaḥ
]

`v 30 [
manorathaśataprāptaṃ tanayaṃ samayā dhiyā |
rākṣasāya trigarteśo dadau svapaṇahāritam
]

`v 31 [
nagaryāṃ dahyamānāyāṃ bhūṣitāyāṃ tathotsave |
sama eva mahīpālo janako bhūbhṛtāṃ varaḥ
]

`v 32 [
nyāyataḥ parivikrītaṃ sālvarāṭ samadarśanaḥ |
svameva vicakartāśu śiraḥ padmadalaṃ yathā
]

`v 33 [
kundaprakaranirbhāsaṃ yajñe pāṇḍumivācalam |
jahau jarattṛṇamiva sauvīraḥ samayā dhiyā
]

`v 34 [
samayaiva dhiyā nityaṃ nijamabhyāharan kramam |
mātaṅgaḥ kuṇḍapo nāma prāpa vaimānikasthitim
]

`v 35 [
sarvabhūtakṣayakarīṃ sāmyābhyāsena bhūriṇā |
tatyāja rākṣasīṃ vṛttiṃ kadambavanarākṣasaḥ
]

`v 36 [
bālacandrābhijāto'pi samabuddhitayā jaḍaḥ |
guḍamodakavannyāyaprāptamagnimabhakṣayat
]

`v 37 [
samabudditayā krūravyavahāraparo'pi san |
dharmavyādhastanuṃ tyaktvā jagāma paramaṃ padam
]

`v 38 [
nandanodyānasaṃstho'pi puruṣo'pi kapardanaḥ |
lulubhe na surastrīṣu nūnaṃ praṇayinīṣvapi
]

`v 39 [
samacittatayā'spandaḥ karañjagahaneṣvapi |
vindhyakāntārakaccheṣu rājyaṃ tyaktvāvasacciram
]

`v 40 [
ṛṣayo munayaścaiva ye siddhāḥ surapūjitāḥ |
samadṛṣṭitayodvignā na te tāsu vratarddhiṣu
]

`v 41 [
rājānaḥ prākṛtāścaiva dharmavyādhādayo'pare |
samadṛṣṭipadābhyāsānmahatāṃ pūjyatāṃ gatāḥ
]

`v 42 [
ihāmutra ca siddhyarthaṃ puruṣārthapravṛttaye |
samadṛṣṭitayā nityaṃ vicaranti subuddhayaḥ
]

`v 43 [
abhivāñchenna maraṇamabhivāñchenna jīvitam |
yathāprāptasamācāro vicaredavihiṃsakaḥ
]

`v 44 [
samakalitaguṇāguṇaikabhāvaḥ samasukhaduḥkhaparāvaro vilāsī |
pravicarati samāvamānamānaḥ prakṛtavaravyavahārapūtamūrtiḥ
]