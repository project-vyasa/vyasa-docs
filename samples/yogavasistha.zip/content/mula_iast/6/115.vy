`v 1 [
pañcadaśādhikaśatatamaḥ sargaḥ 115
pārśvagā ūcuḥ |
atrottamāśaya latāvalayālayeṣu līlāvilolalalanāḥ kalayanti gītam |
uddāmabhāvarasavismṛtavāsarehā viśramya kiṃnaragaṇāḥ kalakākalīkam
]

`v 2 [
ete himādrimalayācalavindhyasahyakrauñcā mahendramadhumandaradardurādyāḥ |
dūrasthitā dṛśi sitābhrapaṭā vahanti saṃśuṣkaparṇalavalāñchitaloṣṭalīlām | 2
|
atyunnatā api girayo dūrāddṛśyamānā alpavadbhāntītyāha - ete | ete
himādrimalayādyāḥ sitābhrapaṭāḥ śailā dūrasthitāḥ santo dṛśi prekṣakadṛṣṭau
saṃśuṣkaparṇalavalāñchitānāṃ loṣṭānāṃ līlāṃ sāmyaṃ vahanti paśya
]

`v 3 [
amī dūrālokavyavahitamahāvartmanicayāḥ puraḥprākārāṇāṃ kulaśikhariṇo
bibhrati vapuḥ |
viśantīrambhodhiṃ kalaya lulitā bhānti saritaḥ paṭasyāntaḥ saktāḥ
pratanusitasūtrā iva daśāḥ
]

`v 4 [
kiṃcāmī kulaśikhariṇo dūrādālokanamālokastasmin apāre pareṣāṃ vyavahitā
antarāladeśavartmanicayā yeṣāṃ tathāvidhā santaḥ parasparasaṃlagnatayā parito
dṛśyamānāḥ puraḥprākārāṇāṃ vapurbibhrati | tathā ambhodhi viśantīḥ
praveśatvarayā ca lulitāḥ saritaḥ paṭasyāntaḥ saktāḥ pratanusitasūtrā daśā iva bhānti |
3 |
daśāśāḥ śailānāmupari paritaḥ prāvṛtaghanā ghanaśyāmākārāḥ
khagakalakalālāpalapitāḥ |
latāmuktaiḥ puṣpairlalitavanalekhābhujalatā hasantyaste rājanbhavanavanitā bhānti
purataḥ
]

`v 5 [
tālītamālabakulākulatuṅgaśṛṅgamekīkṛtākṛti vanaṃ taralaṃ vibhāti |
abhyāhataṃ jalanidhestaralaistaraṅgaistīrāntalagnaghanaśaivalajālakalpam
]

`v 6 [
itaḥ svapiti keśavaḥ kulamitastadīyadviṣāmito'pi śaraṇārthinaḥ śikharipatriṇaḥ
śerate |
ito'pi vaḍavānalaḥ saha samastasaṃvartakairaho vitatamūrjitaṃ bharasahaṃ ca
sindhorvapuḥ
]

`v 7 [
ete jambunadītaṭā ravikarairābhānti
hemākhilagrāmāraṇyapurasthalīgiritarusthāṇvagrahāroccayāḥ |
jvālālīvalitāṃbarāṃtaraliho muñcanti bhāsobhitassarvā bhūmipa
bhūrihaivamamarāsevyāsti no mānuṣaiḥ
]

`v 8 [
ete kadambavanakambalamambudābhamābhānti bhāskarapathānugatā vahantaḥ |
asyācalasya vasudheva taṭaṃ tavāstu mā sūryarodhakanabhasthaghanaughaśaṅkā |
8 |
asyācalasya ambudābhaṃ kadambavanakambalaṃ vahanto bhāskarapathānugatā ete
adhityakāpradeśā ābhānti | ataḥ eṣu pradeśeṣu tava vasudheva idamapi taṭamiti
buddhirastu | sūryarodhakā nabhasthā ghanaughā ete iti śaṅkā māstvityarthaḥ
]

`v 9 [
eṣo'sau malayo layogralavalīvallīlasaccandanasphītāmodamadādrasena taravo vaktre
kriyante tribhiḥ |
sajvālodahanākṣasaṃsthitakapoloṣmodayottāṇḍave
aṅguṣṭhāṅgulibhiryathoṣṇakakaṇāstaptā yathā yoṣitām
]

`v 10 [
eṣo'bdhidhautakaladhautataṭādhirūḍhabhogīndrabhogapariveṣṭitacandano'gaḥ |
vidyādharīvadanapaṅkajadīptipuñjahemīkṛtākhilaśilo malayābhidhānaḥ
]

`v 11 [
kūjatkuñjakaṭhoragahvaranadīkvatkāravatkīcakastambhāḍambara##-
etasminprabalākināṃ pracalatāmudvejitāḥ kūjitairudvellanti
purāṇarohaṇatarustambheṣu kumbhīnasāḥ
]

`v 12 [
komalakanakalatālayavilasitalalanāvilolavalayakṛtam |
śravaṇarasāyanapānaṃ vitatamihākarṇayāsya taṭe
]

`v 13 [
karikaraṭagalitamadajalavalitaścalavīcicañcarīkacayaiḥ |
carvita eṣa kadarthita iva kaṇanikaro virauti vārinidhau
]

`v 14 [
paśyāmalendurāmṛtanavanītaśarīrasundarīvalitaḥ |
piturutsaṅge kurute jalalīlāṃ kṣīravārinidhau
]

`v 15 [
abdheścala pratibimbacandraṃ darśayannutprekṣate - paśyeti | he rājan amalenduḥ
āmṛtaṃ amṛtamathanajaṃ yannavanītaṃ
tādṛśaśarīrastādṛśaśarīrābhirnakṣatrasundarībhirvalitaḥ san kṣīravārinidhau
pratibimbitaḥ piturutsaṅge jalalīlāṃ jalakrīḍāṃ kurute | paśyedaṃ kautukamityarthaḥ | 14
|
nṛtyanti mattakalakokilakākalīkāḥ paśyāmale malayasānuni bālavallyaḥ |
lolālijālanayanāruṇapatrapāṇipuṣpā `note[lokālīti viśeṣaṇobhayapadaḥ
karmadhārayo'yam |] madhūtsavavilāsaviśeṣavatyaḥ
]

`v 16 [
vaṃśānāṃ hṛdi parvateṣu jaladhau toyārthinīnāṃ tu ye śuktīnāṃ hṛdaye
viśanti samaye varṣāṃbhasāṃ bindavaḥ |
te muktāphalatāṃ vrajanti kariṇāṃ kumbheṣu vānyadbhavet śuddhau
mauktikavatsyuruttamaguṇā etāstridhā jātayaḥ
]

`v 17 [
śaile'bdhau puruṣe'vanau jaladhare bheke śilāyāṃ gaje nānākāradharā bhavanti
maṇayaḥ karmāṇi teṣāṃ vibho |
hlādoccāṭanamāraṇajvarabhayabhrāntiprakāśāndhatākhedottāpanabhūna##-
evaṃ ratnānāmapyākarabhedenotpattiṃ guṇakriyāvaicitryaṃ ca ratnaśāstre
prasiddhamityāha - śaile iti | teṣāṃ yathāyogaṃ karmāṇi śṛṇu |
hlādastāpaśāntiḥ śatrūṇāmuccāṭanaṃ māraṇam | jvaraḥ bhayaṃ bhrāntiḥ andhatā
khedaḥ uttāpanaṃ ceti | ratnasvāmino vyavahitaviprakṛṣṭārthaprakāśo
bhūgatirdūragamanaśaktirbhūmau nimajjya gamanaśaktirvā nabhogatiḥ prasiddhā
atītānāgatadarśanaṃ vyādhidurbhikṣādināśaḥ paraprayuktaviṣakṛtyā
yantrādipratividhānaṃ cetyarthaḥ | cārthe tathāśabdaḥ
]

`v 18 [
vātāyanodaragavākṣakavāṭakakṣādvārānanairiha purāṇyudite paṭhanti |
śvabhrābhrakandaradarīvanaveṇurandhravargeṇa mandara ivāmṛtasindhumindum
]

`v 19 [
etacchṛṅgaṃ harati pavanaḥ
kiṃsvidityunmukhībhirdṛṣṭotsāhaścakitacakitaṃ mugdhasiddhāṅganābhiḥ |
prāleyādreḥ pratitaṭavanaṃ protpatatyabhramūrdhvaṃ vajrastambho
gaganasutalottolanāyeva bhūmeḥ
]

`v 20 [
gaṅgātaraṅgahimasīkaraśītalāni vidyādharādhyuṣitacāruśilātalāni |
puṣpābhrasaṃvalitapuṣpitakānanāni rājanvilokaya mahendragirestaṭāni
]

`v 21 [
deśāntareṣu vitatāni vanāntarāṇi puṣpasthalānyupavanānyatha pattanāni |
tīrtheṣu pūtabhuvanāni jalāni dṛṣṭvā daurbhāgyabhītirapayāti javānuviddhā | 21
|
puṇyatamadeśavanatīrthādidarśanasya daurbhāgyanivṛttirmahāphalamastītyāha -
deśāntareṣviti | javenānuviddhā ghaṭitā drutamapayātīti yāvat
]

`v 22 [
śṛṅgāṇi pūritadigantaramaṇḍalāni śvabhrābhrakandaranikuñjakulākulāni |
vyomopamānyapi ca vāridhikuṇḍalāni dṛṣṭvā galanti kukṛtāni bṛhattarāṇi |
22 |
śrīśailādi śṛṅgāṇi | sādhujanapūritāni digantarāṇi | tīrthakūpavāpyādiśvabhrāṇi |
himavadādīnāmabhrayuktāni kandarāṇi campakāraṇyādīni | nikuñjakulairākulāni |
vyomopamāni nirmalāni vāridhikuṇḍalāni setubandhāditīrthāni dṛṣṭvā prāṇināṃ
kukṛtāni pāpāni bṛhattarāṇi brahmahatyādīnyapi galanti naśyanti
]

`v 23 [
ramyāścandanavīthayo hi malaye vindhye madāndhā gajāḥ kailāse nṛpa pādajāti
kanakaṃ candraṃ mahendrācale |
divyāścauṣadhayastuṣāraśikhare sarvatra ratnāni vai santyandhākhuvadeṣa
jīrṇasadane vyarthaṃn jano jīryate
]

`v 24 [
sonnataṃ jagadivorutaṭākaṃ vāriṇā vivalitaṃ timireṇa |
prasphuranti ca yugānta ivaitā vidyutaḥ śapharikā iva lolāḥ
]

`v 25 [
sāvaśyāyāśyānanīhāradhārā dhārodgārānvāridānmādayantaḥ |
śītānītoddāmaromāñcacarcāḥ prodyacchabdaṃ vāntyaho varṣavātāḥ
]

`v 26 [
hā vāti nīlajaladaprasarānusārī vātaḥ kiranviṭapipallavapuṣpagucchān |
dhīrotkaradrumavanāntaracāracārurāsārasīkarakadambakasārasāraḥ
]

`v 27 [
mārutāḥ suratakrāntakāntāniḥśvasitairime |
vahanti vṛddhiṃ gandhaṃ ca lavaṃ svargādiva cyutāḥ
]

`v 28 [
kuvalayakuvalayavikacanakusumalatāvidalanodyatā mṛdavaḥ |
ghanapaṭapāṭanapaṭavo vidhutopavanā vahantyamī pavanāḥ
]

`v 29 [
saṃdhyābhraleśānupayanti vātā nabhastale komalakampanena |
nṛpāṅgaṇe puṣpavicitralekhānuvāsite bhṛtyavarā ivaite
]

`v 30 [
kvacitkusumagandhayaḥ kamalavargagandhāḥ kvacitkvacitkusumavarṣiṇo
lalitakesarāsāriṇaḥ |
kvacicca himapāṇḍavo haritapītalaśyāmalā vahanti śikharānilāḥ
suratamandagharmacchidaḥ
]

`v 31 [
kusumānāmiva gandho yeṣām | upamānapūrvapadatvādit | kvacitkamalavargāṇāṃ gandha
iva gandho yeṣām | himaiḥ pāṇḍavaḥ haritapītalaśyāmalairgiridhātubhistadvarṇāḥ
śikharasaṃbandhino'nilāḥ surate mandānāṃ śrāntānāṃ dharmāmbucchido vahanti | 30
|
kvaciddhuṃkārakāṃkārairaṅgāranikarānkaraiḥ |
kiṃkarairvikiratyarko mūrkhasaṃsargavāniva
]

`v 32 [
nararasāyanatṛptivimuktayā pramadayā madayāpitalajjayā |
upagate vapuṣā na viṣahyate viṣavimūrcchanayeva samāyatā
]

`v 33 [
valitatāmarasā mṛduśīkarāḥ śaśikarotkaravīcivibhedinaḥ |
sadahanā iva tāpamayāḥ puro virahiṇīṣu vanāvanivāyavaḥ
]

`v 34 [
iha hi pūrvapayodhitaṭāvaṭe vikaṭapatrapaṭāḥ kaṭakītaṭāḥ |
navamadāsavayauvanasaṃśrayāḥ kalaya yānti kathaṃ śavarastriyaḥ
]

`v 35 [
navarasāsavasāraniśāgamakṣayabhayāturacittatayāṅganā |
tyajati kāntamiyaṃ na manāgapi drutamito valiteva puro'hibhiḥ
]

`v 36 [
prabhātatūryamukharairdivasairiva tarjitā |
hṛdyeva sphuṭā nārī nilīnā dayitorasi
]

`v 37 [
protphullakiṃśukaiṣā dakṣiṇajaladhestaṭe'tra vanarājī |
jvaliteva jalataraṅgaiḥ paunaḥpunyena sicyate'mbudhinā
]

`v 38 [
asyā niryāntyanilairdhūmā iva kṛṣṇakesarāmbudharāḥ |
aṅgākā iva kusumānyupaśāntāṅgāravacca khagabhṛṅgāḥ
]

`v 39 [
īdṛśyeva vilokaya vanarājī satyavahninā jvalitā |
giriśirasi tūttarasyāṃ diśi dūre dhūyate ca khe pavanaiḥ
]

`v 40 [
krauñcācalasya bhuvi mantharameghacakragambhīratāraravanartitabarhiṇīyam |
paśyotthitaṃ tumulamākulavarṣavātavyādhūtapuṣpaphalapallavakānanīyam
]

`v 41 [
astācale vikaṭakāñcanakūṭakoṭisaṃghaṭṭanasphuṭitajarjaracārusaṃdhiḥ |
kharvaṃ rathaḥ patati sa sma raveḥ sacakracītkāratāratarakūbararāsa eṣaḥ
]

`v 42 [
bhuvanabhavanaprākāre'drau niśākarabherukaṃ parivikasitaṃ mītaṃ bhāsā
malālirupāśritaḥ |
tadiha jagatāṃ vastu śreṣṭhaṃ na kiṃcana vidyate vidhirupahataḥ kuryānno
yatkṣaṇena kalaṅkitam
]

`v 43 [
tribhuvanaharāṭṭahāso bhuvanamahābhavana eṣa maṅkolaḥ |
kṣīrasalilāvapūro gaganābdheścāndra ālokaḥ
]

`v 44 [
spṛṣṭapradoṣamayamandaramathyamānacandrārṇavollasitadugdhataraṅga##-
paśya prabhāpaṭalakaiḥ paripūritāṅgīḥ pūrairivograsaritaḥ prasaradbhirāśāḥ |
44 |
saṃdhyādhāturāgaiḥ spṛṣṭena pradoṣamayena mandareṇa mathyamāno
yaśrandralakṣaṇaḥ kṣīrārṇavastadullasitairdugdhataraṅgabhaṅgaprāyaiḥ prasaradbhiḥ
prabhāpaṭalakaiḥ ugraḥ śivastadvisṛṣṭāyā gaṅgāsaritaḥ prasaradbhiḥ pūrairiva
paripūritāṅgīḥ āśā diśaḥ paśya
]

`v 45 [
ete patantyatula tālakarālalolavetālabālavalitā niśi guhyakaughāḥ |
hūṇeśvarasya nagarāṇi nirastaśānti svastiśravādivikalāni balena bhoktum
]

`v 46 [
tāvadvibhāti gagane paripūrṇacandro yāvadvadhūvadanameti na sadma bāhyam |
abhyudgate'ṅgaṇanabhasyabalānanendāvindoḥ sitābhraśakalasya ca ko viśeṣaḥ |
46 |
sadmano bāhyamanāvaraṇamaṅgaṇadeśaṃ vadhūvadanaṃ na eti | bāhyāṅgaṇanabhasi
abalānanendau nirgamanenābhyudyate sati tatsaundaryanirastaśobhasyendoḥ
sitābhraśakalasya ca ko viśeṣaḥ | na kaściditi kāmukoktiḥ
]

`v 47 [
vṛddhāni candrāṃśunavāmbarāṇi gaṅgaughanirdhūtaśilānyamūni |
himātatānyugralatājaṭāni tuṣāraśaileśvaramastakāni
]

`v 48 [
sa eṣa mandāravanāvataṃso dolāpsarogeyavisārivātaḥ |
kvacinmaṇidyotavicitracitraḥ saṃdṛśyate vyomani mandarādriḥ | 48 |
dolāḥ preṅkhāstadārūḍhānāmapsarasāṃ gītāni visārayati tacchīlo vāto yasya |
atyunnatatvādvyomani saṃdṛśyate
]

`v 49 [
pronnidranīrandhraśilīndhrasāndrapuṣpārghyapātradhramahāmahīdhrāḥ |
sāndrābhranirhrādagabhīrakukṣau sarkṣāntarikṣaśriyamudvahanti
]

`v 50 [
itaḥ sa kailāsagirirgarīyasā prabhāpravāheṇa mitena yasya kham |
śaṃbhorivābhāti sutasya kuṭṭimaṃ candro'pi ca kṣīrasamudrago yathā
]

`v 51 [
sthāṇūnāṃ chinnaśākhānāṃ mṛnmayānāṃ ca vāsavaḥ |
saṃdhatte paśya dūrāṇāṃ vātairmuktaśikhā iva
]

`v 52 [
ete kadambakulakundasugandhivātā limpanti māṃsalatayā makarandavṛṣṭeḥ |
ghrāṇaṃ ghanaiḥ parimalairalijālanīlā vyāloḍya meghapaṭalaiḥ
khamivābhrakāyāḥ
]

`v 53 [
unnidrakuḍmaladalāsu vanasthalīṣu sacchāyaśādvalaghaneṣu ca jaṅgaleṣu |
grāmeṣu saṃtataphaladrumasaṃkuleṣu lakṣmīḥ svayaṃ nivasatīva nivāsahetoḥ
]

`v 54 [
vātāyanāgatalatāvṛtasaudhakośakośātakīkusumakesaramāharadbhiḥ |
āgulphakīrṇamukulājira eṣa vātairgrāmo vibhāti nagaraṃ vanadevatānām
]

`v 55 [
unnidrāmalacampakadrumalatādolāvilolāṅganāḥ kūjannirjharavārayaḥ
parisarapronnidratāladrumāḥ |
utphullojjvalamañjarīsitalatāgehollasadbarhiṇaḥ paryantonnatasālalambajaladā
ramyā girigrāmakāḥ
]

`v 56 [
vātālolavicitrapatralatikāsaṃpūrṇanīlasthalāḥ
kūjallāvakakokakukkuṭaghaṭāgāyatpulindāṅganāḥ |
bālāvyākulatarṇakā dadhimadhukṣīrājyapānojjvalāḥ kasyevāmṛtamaṇḍapā
viracitā ramyā girigrāmakāḥ
]