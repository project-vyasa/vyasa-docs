`v 1 [
ekādhikadviśatatamaḥ sargaḥ 201
śrīvālmīkiruvāca |
athārvāksādhuvādeṣu praśānteṣu śanaiḥśanaiḥ |
jñānopadeśamāsādya prollasatsviva rājasu
]

`v 2 [
praśāntasaṃsṛtibhrāntau jane caritamātmanaḥ |
svayaṃ hasati cittena satyaṃ samanudhāvatā
]

`v 3 [
valaccittakalaṃ jñānasamāsvādanatatpare |
vivekini sabhāloke śānte dhyānamivāsthite
]

`v 4 [
baddhapadmāsane rāme sabhrātari guroḥ puraḥ |
sthite kṛtāñjalau dīptaguruvaktragatekṣaṇe
]

`v 5 [
pārthive kimapi dhyānamivāsvādayati sthitim |
jīvanmuktātmikāmantarādimadhyāntapāvanīm
]

`v 6 [
grahītumarcāṃ bhaktānāṃ mānitārthajano muniḥ |
tūṣṇīṃ kṣaṇamiva sthitvā provācānākulākṣaram
]

`v 7 [
svakulākāśaśītāṃśo rāma rājīvalocana |
kimanyadicchasi śrotuṃ kathayābhimatecchayā
]

`v 8 [
sthitiṃ ca kīdṛśīmenāmadyānubhavasi svayam |
kiṃrūpamidamābhāsaṃ jāgataṃ vada paśyasi
]

`v 9 [
ityukte muninā tena prāha rājakumārakaḥ |
avihvalaṃ mṛdu spaṣṭaṃ gurorālokayanmukham
]

`v 10 [
śrīrāma uvāca |
tvatprasādena yāto'smi parāṃ nirmalatāṃ prabho |
śāntāśeṣakalaṅkāṅkaṃ nabhastalam
]

`v 11 [
sarvā evopaśāntā me bhrāntayo bhavabhaṅgadāḥ |
svarūpeṇāvadātena tiṣṭhāmyacchamivāmbaram
]

`v 12 [
sthito'haṃ galitagranthiḥ śāntāśeṣaviśeṣaṇaḥ |
sphaṭikālayamadhyasthasphaṭikāmaladhīraham
]

`v 13 [
anyacchrotumathāhartuṃ śāntaṃ necchati me manaḥ |
parāṃ tṛptimupāyāntaṃ suṣuptamiva saṃsthitam
]

`v 14 [
śāntāśeṣaparāmarśaṃ vigatāśeṣakautukam |
saṃtyaktāśeṣasaṃkalpaṃ śāntaṃ mama mune manaḥ
]

`v 15 [
parinirvāmi śāmyāmi jāgradeva jagatsthitau |
asvapnamapunarbodhaṃ svapimīva nirāmayam
]

`v 16 [
āśāvidhuritāmātmasaṃsthitiṃ prāktanīṃ tanau |
pravihasya sphuratsūktaiḥ svasthastiṣṭhāmyasaṃśayam
]

`v 17 [
nopadeśena nārthena na śāstrairna ca bandhubhiḥ |
tyāgena ca na caiteṣāmadhunā mama kāraṇam
]

`v 18 [
sāmrājyasyāthavā vyomni yā sthitiḥ kṣobhavarjitā |
tāmevānubhavāmyatra maccittāmanapāyinīm
]

`v 19 [
khādapyatitarāmacchaṃ cidākāśāṃśamātrakam |
jagadityeva paśyāmi locanādyaṅgatāṃ `note[yathākāmaṃ yathārambhaṃ
yathāprāptaṃ yathāsthitam ityevaṃrūpe] gataḥ
]

`v 20 [
ākāśamātramevedaṃ jagadityekaniścayaḥ |
dṛśyanāmni nabhasyasminkṣaye jāgarmi cākṣayaḥ
]

`v 21 [
yathākāmaṃ yathāprāptaṃ yathāsthitamiva sthitam |
yadvakti tadavighnena karomyapagataiṣaṇam
]

`v 22 [
na tuṣyāmi na hṛṣyāmi na puṣyāmi na rodimi |
kāryaṃ kāryaṃ karomyeko bhrāntirdūraṃ gatā mama
]

`v 23 [
anyatāmetu sargo'yaṃ vātu vā pralayānilaḥ |
saumyo bhavatu vā deśaḥ svastho'haṃ svātmani sthitaḥ
]

`v 24 [
viśrāntosmi vilakṣyosmi durlakṣyosmi nirāmayaḥ |
nāśābhirbandhamāpnomi mune khamiva muṣṭibhiḥ
]

`v 25 [
yathā tarugatātpuṣpādgandhaḥ prāpya nabhaḥpadam |
tiṣṭhatyevamahaṃ dehādatītaḥ saṃsthitaḥ samaḥ
]

`v 26 [
yathaiva sarve rājāno viharanti yathāsukham |
aprabuddhāḥ prabuddhāśca rājyeṣu bahukarmasu
]

`v 27 [
śāntaharṣaviṣādāśaḥ sthiraikasamadarśanaḥ |
sthita ātmani niḥśaṅkaṃ tathaiva viharāmyaham
]

`v 28 [
sarvasyoparyapi sukhī sukhaṃ nehāmi me prabho |
janasāmyena tiṣṭhāmi yathecchaṃ māṃ niyojaya
]

`v 29 [
bālo līlāmiva tyaktaśaṅkaṃ saṃsārasaṃsthitim |
yāvaddehamimāṃ sādho pālayāmyamalaikadṛk
]

`v 30 [
bhuñje pibāmi tiṣṭhāmi pālayāmi nijakriyām |
jāto'haṃ vigatāśaṅkastvatprasādānmunīśvara
]

`v 31 [
śrīrāma uvāca |
aho bata mahāpuṇyaṃ padamāsāditaṃ tvayā |
anādimadhyaparyantamidaṃ yatra na śocyate
]

`v 32 [
samyaksamasamābhoge śītale svātmani svayam |
nabhasīva nabhaḥ śānte viśrāntimasi labdhavān
]

`v 33 [
diṣṭyā jāto viśokastvaṃ diṣṭyā samyagavasthitaḥ |
diṣṭyā lokadvaye'narthaśaṅkā te śamamāgatā
]

`v 34 [
diṣṭyā raghūṇāṃ tanaya saṃjñaḥ pāvitavānasi |
bhūtabhavyabhaviṣyasthāṃ bodhena kulasaṃtatim
]

`v 35 [
adhunā munināthasya viśvāmitrasya rāghava |
pūrayitvārthitāṃ bhuktvā `note[tiṣṭheti śeṣaḥ |] pitrā saha mahīmimām
]

`v 36 [
tvayānvitāḥ satanayabhṛtyabādhavāḥ padātayaḥ sarathagajāśvamaṇḍalāḥ |
nirāmayā vigatabhayāḥ sthiraśriyaḥ sadodayāḥ subhaga bhavantu rāghavāḥ
`note[raghukulasaṃbandhino bhṛtyādayaḥ |]
]