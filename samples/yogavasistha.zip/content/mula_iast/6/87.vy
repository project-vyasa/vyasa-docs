`v 1 [
saptāśītitamaḥ sargaḥ 87
śrīvasiṣṭha uvāca |
tataścidākāśavapurvyāpyananto nirāmayaḥ |
dattāvadhāno vapuṣi tadā paśyāmyahaṃ kvacit
]

`v 2 [
yāvadantargataḥ sargaḥ saṃsthito'ṅkuritopamaḥ |
kusūlasyeva bījasya siktasyevāṅkuro hṛdi
]

`v 3 [
ūrdhvamucchūna evāntaḥsekādbīje yathāṅkuraḥ |
ākāravatyanākāre cittvācittve tathā jagat
]

`v 4 [
yathonmiṣati dṛśyaśrīḥ suṣuptādbodhameyuṣaḥ |
jāgradvā vigate svapne cinmātrasya svacetanāt
]

`v 5 [
tathaivātmani sargādāvanubhūtasvarūpiṇi |
hṛdi sargodayo nānyarūpa ākāśarūpataḥ
]

`v 6 [
śrīrāma uvāca |
ākāśarūpa ākāśe paramākāśa kathyatām |
bhūyo nipuṇabodhāya kathaṃ sargaḥ pravartate
]

`v 7 [
śrīvasiṣṭha uvāca |
śṛṇu rāma yathāpūrvaṃ svayaṃbhūtvaṃ mayā tadā |
anubhūtamasatsadvadidaṃ svapnapuropamam
]

`v 8 [
tamālokya mahākalpasaṃbhramaṃ vyomarūpiṇā |
bhāge'nyatra śarīrasya saṃvidunmeṣitā mayā
]

`v 9 [
yadaiva sāmalā saṃvitkiṃcidunmeṣitā sthitā |
tadaivāhaṃ kvacittatra paśyāmyākāśatāmiva
]

`v 10 [
gataṃ svabhāvaṃ cidvyoma yathā tvaṃ rāma nidrayā |
jāgradvā svapnalokaṃ vā viśanvetsi samaṃ ghanam
]

`v 11 [
diṅmātrākāśamevādau tato'smītyeva vedanam |
tadghanaṃ kathyate buddhiḥ sā ghanā mana ucyate
]

`v 12 [
tadvetī śabdatanmātraṃ tanmātrāṇītarāṇyatha |
pañcendriyāṇi tatsthaulyāditīndriyagaṇodayaḥ
]

`v 13 [
suṣuptādviśataḥ svapnaṃ jagaddṛśyaghanodayam |
yathā tathaiva sargādau duḥkhaṃ bhāti nimeṣataḥ
]

`v 14 [
tulyakālamanante'smindṛśyajālāvabhāsane |
kathayanti kramaṃ kecitkecinna kathayanti ca
]

`v 15 [
paramāṇukaṇe kānte saṃpannamanubhūtavān |
ahaṃ cetanamātmānaṃ vastuto'malameva kham
]

`v 16 [
yathā svabhāvato vyomni calatyevāniśaṃ marut |
tathā svabhāvātsarvatra paśyatyeva vapustviti
]

`v 17 [
yādṛśaṃ cetitaṃ rūpaṃ śaktyā paramayā tayā |
tacchaknotyanyathākartuṃ naiṣā yatnena bhūyasā
]

`v 18 [
tataḥ paśyāmyahaṃ yāvatsaṃpanno'pyaṇurūpakaḥ |
cittvāccetastadevāśu tathābhūto'smi saṃsthitaḥ
]

`v 19 [
tato'haṃ buddhavānrūpaṃ tanu tejaḥkaṇākṛti |
tadeva bhāvayanpaścādgato'haṃ sthūlatāmiva
]

`v 20 [
prekṣe tāvadahaṃ kiṃciditi bodhāllaghostataḥ |
manāgālokanāyaiva saṃpravṛtto'nubhūtavān
]

`v 21 [
yannāma tatra tatkiṃcittasyehādya raghūdvaha |
śṛṇu nāmāni mukhyāni kalpitāni bhavādṛśaiḥ
]

`v 22 [
draṣṭuṃ pravṛtto randhreṇa yena taccakṣurucyate |
yacca paśyāmi taddṛśyaṃ darśanaṃ tu phalaṃ tataḥ
]

`v 23 [
yadā paśyāmi kālo'sau yathā paśyāmi sa kramaḥ |
prauḍhā niyatirityasya yatra paśyāmi tannabhaḥ
]

`v 24 [
sthito'smi yatra deśo'sāvityadayiṣā prakalpanā |
tadā tvahaṃ cidunmeṣamātrāttanmātrakāraṇam
]

`v 25 [
paśyāmīti tatastatra manāgbodho mamodabhūt |
tato randhradvayenāhamapaśyaṃ yattadapyakham
]

`v 26 [
yābhyāmapaśyaṃn randhrābhyāṃ ta ime locane sthite |
tataḥ kiṃcicchṛṇomīti saṃvidityuditā mama
]

`v 27 [
tataḥ kiṃcinmanāṅmātraṃ jhaṃkāraṃ śrutavānaham |
pradhmātasyeva śaṅkhasya śabdaṃ vyomnaḥ svabhāvajam
]

`v 28 [
yābhyāmahamathāśrauṣaṃ ta ime śravaṇavraṇe |
pradeśābhyāṃ vicaratā marutā vitatasvanam
]

`v 29 [
sparśasaṃvedanaṃ kiṃcidahamatrānubhūtavān |
yena nāma pradeśena tena sā tvakca kathyate
]

`v 30 [
yena spṛṣṭamivāṅgaṃ tattadāhamanubhūtavān |
satsaṃvedanamātrātmā so'yaṃ vāyuriti smṛtaḥ
]

`v 31 [
sparśanendriyatanmātramiti vedini saṃsthitam |
āsvādasaṃvidyābhūnme tadāsvādyarasendriyam
]

`v 32 [
prāṇānme ghrāṇatanmātramuditaṃ vyomarūpiṇaḥ |
itthaṃ na kiṃcitsaṃpannaṃ sarvaṃ saṃpannamatra me
]

`v 33 [
evamindriyatanmātrajālaṃ cettatra saṃsthitaḥ |
yāvattāvadvidaḥ pañca balādeva mamoditāḥ
]

`v 34 [
śabdarūparasasparśagandhamātraśarīrikāḥ |
anākārāstathā bhātasvarūpiṇyo bhramātmikāḥ
]

`v 35 [
evaṃrūpamahaṃ jālaṃ bhāvayanyattadāsthitaḥ |
tadahaṃkāra ityadya kathyate tvādṛśairjanaiḥ
]

`v 36 [
eṣa eva ghanībhūto buddhirityabhidhīyate |
sātha buddhirghanībhūtā mana ityabhidhīyate
]

`v 37 [
antaḥkaraṇarūpatvamevamatrāhamāsthitaḥ |
ātivāhikadehātmā cinmayavyomarūpavān
]

`v 38 [
pavanādyapyahaṃ śūnyaḥ kevalākāśamātrakaḥ |
sarveṣāmeva bhāvānāṃ śūnyākṛtirarodhakaḥ
]

`v 39 [
athaivaṃbhāvanāccāhaṃ yadā tatra ciraṃ sthitaḥ |
tadāhaṃ dehavāndṛṣṭa iti me pratyayo'bhavat
]

`v 40 [
tenāhaṃpratyayenātha śabdaṃ kartuṃ pravṛttavān |
śūnya eva yathā suptaḥ svapnoḍḍīnanaro ravam
]

`v 41 [
atha pūrvaṃ kṛtaḥ śabdo bāleneva tadomite |
tataḥ sa eṣa oṃkāra iti nītaḥ punaḥ prathām
]

`v 42 [
tataḥ svapnanareṇeva yatkiṃcidgaditaṃ mayā |
tadetadviddhi vācaṃ tvaṃ paścānnītāṃ prathāmiha
]

`v 43 [
brahmaiva so'smi saṃpannaḥ sṛṣṭeḥ kartā jagadguruḥ |
tato manomayenaiva kalpitāḥ sṛṣṭayo mayā
]

`v 44 [
evamasmi samutpanno na tu jāto'smi kiṃcana |
dṛṣṭavānasmi brahmāṇḍaṃ brahmāṇḍāntaṃ na kiṃcana
]

`v 45 [
evaṃ jagati saṃpanne mamaitasminmanomaye |
na kiṃcittatra saṃpannaṃ tacchūnyaṃ vyoma kevalam
]

`v 46 [
itthaṃ saṃśūnyamevedaṃ sarvaṃ vedanamātrakam |
manāgapi na santyete bhāvāḥ pṛthvyādayaḥ kila
]

`v 47 [
jaganmṛgatṛḍambūni bhānti saṃvidi saṃvidaḥ |
na bāhyamasti no bāhye khe tadvyoma tathā sthitam
]

`v 48 [
marau nāstyeva salilaṃ saṃvitpaśyati tattathā |
nirmūlamantaḥsaṃtaptā svasaṃbhramavatī bhramam
]

`v 49 [
nāstyeva brahmaṇi jagat saṃvitpaśyati tattathā |
nirmūlameva saṃvittvādevaṃ bhrānteśca saṃbhramam
]

`v 50 [
asadevedamābhāti hṛdyeva jagadātatam |
saṃkalpanamanorājyaṃ yathā svapnapurādivat
]

`v 51 [
pārśvasuptajanasvapnastaccittāveśanaṃ vinā |
yathā na kiṃcittaccittāveśanādanubhūyate
]

`v 52 [
tathā jagattaddṛṣadaṃ saṃpraviśyānubhūyate |
ādarśabimbitākāraṃ dṛṣṭamapyanyathāpyasat
]

`v 53 [
ādhibhautikabhāvena netreṇa yadi lakṣyate |
tattanna dṛśyate kiṃcidgirireva pradṛśyate
]

`v 54 [
ātivāhikadehena paraṃ bodhadṛśā yadi |
prekṣyate dṛśyate sargaḥ paramātmaiva cāmalaḥ
]

`v 55 [
sarvatra sarganirvāṇaṃ prajñālokena lakṣyate |
brahmātmaivānyathā cettanna kiṃcidabhilakṣyate
]

`v 56 [
yatpaśyatyavadātā dhīḥ sopapattivicāraṇā |
na tannetraistribhiḥ śarvo nendro netraśatairapi
]

`v 57 [
yathā khamāvṛtaṃ sargaistathā bhūriti buddhavān |
tadāhamabhavaṃ dhyātā dharādhāraṇayānvitaḥ
]

`v 58 [
tayā dharādhāraṇayā dharārūpadharo'bhavam |
atyajanneva cidvyomavapuḥ samrāḍivācirāt
]

`v 59 [
dharādhāraṇayā caiva dharādhātūdaraṃ gataḥ |
dvīpādritṛṇavṛkṣādideho'hamanubhūtavān
]

`v 60 [
saṃpanno'smyatha bhūpīṭhaṃ nānāvanatanūruham |
nānāratnāvalīvyāptaṃ nānānagarabhūṣaṇam
]

`v 61 [
grāmagahvaraparvāḍhyaṃ pātālasuṣirodaram |
kulācalabhujāśliṣṭadvīpābdhivalayānvitam
]

`v 62 [
tṛṇaughatanuromāḍhyaṃn girikhaṇḍakagulmakam |
digvāraṇakaṭavyūhadhṛtaṃ śeṣaśiraḥśataiḥ
]

`v 63 [
hriyamāṇaṃ mahīpālaiḥ śobhamānebhatantubhiḥ |
prāṇibhirbhujyamānāṅgaṃ vardhamānaṃ vyavasthayā
]

`v 64 [
himavadvindhyasuskandhaṃ sumerūdārakandharam |
gaṅgādisaridāpūramuktāhāraraṇattanum
]

`v 65 [
guhāgahanakacchādi sāgarādarśamaṇḍalam |
marūṣarasthalaśvetasuvarāmbarasundaram
]

`v 66 [
bhūtapūrvaiḥ parāpūrṇaṃ paripūtaṃ mahārṇavaiḥ |
alaṃkṛtaṃ puṣpavanaiḥ samārabdhaṃ `note[samāra(la)bdhaṃ iti
mūlaṭīkayoḥ pāṭhavaiṣamyaṃ sarvādarśeṣu dṛśyate |] rajoghanaiḥ
]

`v 67 [
nityaṃ kṛṣīvalaiḥ kṛṣṭaṃ vījitaṃ śiśirānilaiḥ |
tāpitaṃ tapanaistaptairukṣitaṃ prāvṛḍambubhiḥ
]

`v 68 [
vipulāgrasthaloraskaṃ padmākarakṛtekṣaṇam |
sitāsitaghanoṣṇīṣaṃ daśāśodaramandiram
]

`v 69 [
lokālokamahākhātavalayogrāsyabhīṣaṇam |
anantabhūtasaṃghātaparispandaikacetanam
]

`v 70 [
vyāptamantarbahiścaiva nānābhūtagaṇaiḥ pṛthak |
devadānavagandharvairbahirantastu kīṭakaiḥ
]

`v 71 [
pātālendriyarandhreṣu nāgāsurakṛmivrajaiḥ |
saptasvarṇavakośeṣu nānājātijalecaraiḥ
]

`v 72 [
vyāptaṃ nadīvanasamudradigantaśailadvīpākhyajantuviṣayasthalajaṅgalaughaiḥ |
nānāvalīvalitamaṇḍalakośakhaṇḍaṃ vallīsaraḥsaridarātigaṇābjakhaṇḍaiḥ
]