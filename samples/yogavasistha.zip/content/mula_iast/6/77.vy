`v 1 [
saptasaptatitamaḥ sargaḥ 77
śrīvasiṣṭha uvāca |
athāvanipayastejaḥpavanānāṃ yugakṣaye |
jāte paramasaṃkṣobhe babhūvāsmiñjagattrayam
]

`v 2 [
tāpicchavipinoḍḍītinibhabhasmābhrabhāsuram |
mahārṇavamahāvartavṛtti dhūmavivartanam
]

`v 3 [
nīlajvālālavollāsahelāṭimiṭimāraṭi |
kṛtabhasmābhrasaṃbhārapūrṇalokāntarāntaram
]

`v 4 [
ucchaladdīrgharutkāraiśchamacchamamayātmakaiḥ |
tūryamunnabhadāsāravisārijayaghoṣaṇam
]

`v 5 [
bhramadbhasmābhradhūmrābhraṃ bṛhatkalpābhrasaṃbhramam |
bāṣpābhravibhramodbhrāntasīkarogrābhravṛndavat
]

`v 6 [
brahmāṇḍabhittibhāṃkārabhīṣaṇairmātariśvanaḥ |
prasarairambaroḍḍīnadagdhendrādipurotkaram
]

`v 7 [
jalānalānilollāsasphuṭatkoṭigatāśmanām |
pravighaṭṭanaṭaṃkārairjaḍībhūtākṣakaśruti
]

`v 8 [
nabhaḥstambhanibhābandhadhārānīrandhravarṣaṇaiḥ |
karṣaṇaiḥ kalpavahnīnāṃ chamacchamaghanadhvani
]

`v 9 [
gaṅgā taraṅgikā yeṣāṃ tādṛśaiḥ saritāṃ gaṇaiḥ |
abhrairiva nabhobhīmaiḥ pūryamāṇākhilārṇavam
]

`v 10 [
tāpicchapatravṛndasthapuṣpagucchasamopamaiḥ |
tapadbhirarkairālīḍhapīṭhakalpābhramaṇḍalam
]

`v 11 [
vahadgirisaridvyūhaśikharidvīpapattanam |
kalpānilaghanakṣobhakṛtaparvatakuṭṭanam
]

`v 12 [
grahatārāgaṇairugrairvyagrairvigrahadurgrahaiḥ |
patadbhirdviguṇālātalatāmāvartapātibhiḥ
]

`v 13 [
āvahotthajalādrīndrasaṃghaṭṭāsphoṭaghaṭṭitam |
mahāpralayaparyastaparvataprāntakuṭṭimam
]

`v 14 [
ghanasīkṛtabāṣpābhraiḥ kalpābhrairapi meduraiḥ |
andhīkṛtārkajālāṃśutamonibiḍamantharam
]

`v 15 [
viśīrṇavasudhāpīṭhakhaṇḍakhaṇḍairgalattaṭaiḥ |
uhyamānairluṭhacchailapatanaiḥ saṃkaṭārṇavam
]

`v 16 [
ūrmyudyadupalacchinnaghanairghasmaramārutaiḥ |
samudraghoṣairnirghātagambhīrairbhagnadiktaṭam
]

`v 17 [
brahmāṇḍakuḍyakroḍāgrakuṭṭakaiḥ kaṭuṭāṃkṛtaiḥ |
kalpābhraviṭapāsphoṭairghaṭṭitaikārṇavāraṭi
]

`v 18 [
svargapātālabhūrlokakhaṇḍakhaṇḍairvimiśritaiḥ |
yathāsvabhāvaṃ tiṣṭhadbhirmarubudhnairvṛtāmbaram
]

`v 19 [
mṛtārdhamṛtadagdhārdhadagdhāṅgairdevadānavaiḥ |
anyonyadarśanādvātavellitairbhrāmitāyudham
]

`v 20 [
kapāntapavanodbhrāntairlokāntarajarattṛṇaiḥ |
ārabdhārjunavātākhyāstambhamudbhūtabhasmabhiḥ
]

`v 21 [
uhyamānaśilājālaprahāraviluṭhattaṭaiḥ |
patallokāntaraiḥ sphāraduṣkālakaṭuṭāṃkṛtam
]

`v 22 [
vātodvyūhagirivrātaguhābhāṃkārabhāsuram |
patadbhirvihitāvartalokapālapurīpuraiḥ
]

`v 23 [
kṛtakarkaśanirhrādairasurairiva mārutaiḥ |
uhyamānavanavyūhaprotavātāyanairvṛtam
]

`v 24 [
puramaṇḍaladaityāgnisuranāgavivasvatām |
nikurambaṃ dadhadvyomni maśakānāmivoccayam
]

`v 25 [
naśyannagavarābhogairbhāgairbhagnasurālayaiḥ |
āvartaghargharārāvairjalamūrdhvamadhonalam
]

`v 26 [
kurvajjalādriniṣpeṣairdikpālapurakuṭṭanam |
nipataddevadaityendrasiddhagandharvapattanam
]

`v 27 [
kuṭṭanaṃ parvatādīnāṃ praśāntāṅgārarūpiṇām |
vātaiḥ kurvatpadārthānāmasāraṃ rajasāmiva
]

`v 28 [
purāṇyamaradaityānāṃ bhramadbhittīni śātayat |
ratnaiḥ khaṇakhaṇāyanti payāṃsīva payasvatām
]

`v 29 [
pūrṇāmbaraṃ patallokalokasaptakamandiraiḥ |
cakrāvṛttyā bhramadrūpairamaraiḥ sāgarairiva
]

`v 30 [
ḍīnoḍḍīnaiḥ parivṛtaṃ vicaladvātvellitaiḥ |
dagdhādagdhaiḥ padārthaiḥ khe śīrṇaparṇagaṇairiva
]

`v 31 [
hemasphaṭikavaidūryasusāramaṇimandiraiḥ |
divaḥ patadbhirākīrṇamudyajjhaṇajhaṇasvanaiḥ
]

`v 32 [
utpeturdhūmabhasmābdhāḥ peturvārā purotkarāḥ |
unmamajjustaraṅghaughā mamajjurbhūtalādrayaḥ
]

`v 33 [
āvartaghargharārāvā mitho vidalanodyatāḥ |
jughūrṇararṇavākīrṇaparṇavatprauḍhaparvatāḥ
]

`v 34 [
krandacchiṣṭāmaragaṇaṃ calatsajjīvabhūtakam |
bhramatketuśatotpātaṃ duṣprekṣyamabhavajjagat
]

`v 35 [
mṛtārdhamṛtayā bhūtasaṃtatyānilalolayā |
abhūnnīrandhramākāśaṃ jīrṇaparṇasavarṇayā
]

`v 36 [
jagadāsītpatacchṛṅgasthūladhāraughanirbharam |
vahadvahadgiripuravātapūrṇasaricchatam
]

`v 37 [
śāmyacchamaśamāśabdaśataśākhahutāśanam |
calābdhivalanāndolalolaśailalasattaṭam
]

`v 38 [
tṛṇarāśisarinnyāyamiśradvīpārṇavotkaṭam |
atyantadūracidvyomakṣaṇajvālāsahāvanam
]

`v 39 [
varṣaśāmyaddhutāśotthabhasmāmodapatatsuram |
bhūtapūrvajagadbhūtaṃ parivismṛtasargakam
]

`v 40 [
nirargalollasannādaṃ sargalopaśamakramam |
sargalopollasaccheṣaṃ sargalopavivarjitam
]

`v 41 [
anārataviparyāsakārimārutanirvṛtam |
bījarāśirivājasraṃ pūryamāṇaṃ punaḥpunaḥ
]

`v 42 [
ulmukānyonyaniṣpeṣavahnicūrṇasuvarṇajaiḥ |
rajobhirvivṛtairhemakuṭṭimākāśakoṭaram
]

`v 43 [
bhūmaṇḍalabṛhatkhaṇḍairbhraṣṭaiḥ sadvīpasāgaraiḥ |
pūrṇasaptamapātālaṃ luṭhatpātālamaṇḍalaiḥ
]

`v 44 [
āsaptamasutālāntamāmahītalaparvatam |
āvyomaikārṇavībhūtaṃ pūrṇaṃ pralayavāyubhiḥ
]

`v 45 [
ekārṇavo'tha vavṛdhe śanaiḥ śīghraṃ saricchataiḥ |
bhuvane jalakallolaiḥ kopo mūrkhāśaye yathā
]

`v 46 [
musalopamayā pūrvaṃ tataḥ stambhanibhāṅgayā |
tatastāladrumākāradhārayāsārasārayā
]

`v 47 [
tato nadīpravāhograjalapātaikapātayā |
saptadvīpamahīpīṭhasamamedurameghayā
]

`v 48 [
vahnirvidāhakṛdvṛṣṭyā śamamabhyāyayau tathā |
śāstrasajjanasaṃgatyā gāḍhamāpatpadaṃ yathā
]

`v 49 [
ūrdhvādharasthaparivṛttapadārthajātamantaḥkaṇaiḥ khaṇkhaṇāyitaśailamajjam
|
brahmāṇḍakoṭaramabhūdvidhuraṃ kubālalīlāvilolamiva bilvaphalaṃ viśuddham |
49 |
kutsitābhirbālasya visphoṭanalīlābhirvilolaṃ bilvaphalamiva vidhuraṃ
vinaṣṭamabhūdityarthaḥ
]