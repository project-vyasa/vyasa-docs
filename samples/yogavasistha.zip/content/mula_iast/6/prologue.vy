`v 1 [
yogavāsiṣṭhaḥ
the
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
VāṣūḍEVā ḻāXṃāṇā ṣḥāṛṃā PāṇṣīKāṛ
dvitīyo bhāgaḥ
antimaṣaṣṭhanirvāṇaprakaraṇapūrvārdhottarārdhayutaḥ
Pāṛṭ īī
containing nirvāna-pūrvarārdha and uttarārdha
śrīḥ
yogavāsiṣṭhaḥ |
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsaṃvalitaḥ |
nirvāṇaprakaraṇasya pūrvārdham 6 |
prathamaḥ sargaḥ 1
śrīvālmīkiruvāca |
upaśamaprakaraṇādanantaramidaṃ śṛṇu |
tvaṃ nirvāṇaprakaraṇaṃ jñātaṃ nirvāṇadāyi yat
]

`v 2 [
kathayatyevamuddāmavacane munināyake |
śravaṇaikarase maunasthite rājakumārake
]

`v 3 [
munivāgarthanikṣiptamanasyastatapaḥkriye |
rājaloke gataspande citrārpita eva sthite
]

`v 4 [
astā tyaktā tapo mānasaṃ bāhyārthālocanaṃ kriyā śarīraceṣṭā ca yena | tadevāha##-
vasiṣṭhavacasāmarthaṃ vicārayati sādaram |
lasadaṅgulibhaṅgena munisārthaṃ sphuradbhruvi
]

`v 5 [
vismayālokanollāsaprotphullanayanālini |
purandhrivarge gambhīratarumañjaritāṃ gate
]

`v 6 [
khe vāsaracaturbhāgadeśe dinakare sthite |
kiṃcijjñānodayātsaumye kiṃcicchamamupeyuṣi
]

`v 7 [
śravaṇayiva saṃśānte vitānaspandamālite |
maunaṃ maruti mandāramadhurāmodadāyini
]

`v 8 [
puṣpadāmasuṣuptāsu mahābhramarapaṅktiṣu |
jñātajñeyatayā nūnaṃ samyagdhyānavatīṣviva
]

`v 9 [
muktājālakalāpāntargatāsvantarabhūmiṣu |
kacatyapagataspandaṃ toye śrotumivāsthite
]

`v 10 [
gṛhāntaraṃ praviṣṭeṣu gavākṣe dūramaṃśuṣu |
viśrāmārthamivādīrghaṃ nabhaḥpāntheṣu śītalam
]

`v 11 [
muktājālaprabhājālabhasmanoddhūlitātmani |
śaṃsatīva śamaṃ śāmyaddinadehe divātape
]

`v 12 [
kare līlāsarojeṣu śekhareṣu ca bhūbhṛtām |
śrutvā surasamāmodādavṛttiṣu manassviva
]

`v 13 [
bālakeṣvajñalokeṣu līlāpakṣiṣu sādaram |
bhojanārthaṃ vadhūlokamuparundhatsvanāratam
]

`v 14 [
bhramadbhramarapakṣotthavātadhūtarajasyalam |
kaumude pariviśrānte cāmareṣvakṣipakṣmasū
]

`v 15 [
raśmiṣvagaguhonmuktacchāyājālabhayādiva |
gavākṣādiṣvivoḍḍīya praviṣṭeṣu gṛhāntaram
]

`v 16 [
āsīddinacaturbhāgasattāvedanatatparaḥ |
bherīpaṭhahaśaṅkhānāṃ diṅmukhāpūrako dhvaniḥ
]

`v 17 [
tena tattāramapyāśu vaco'ntardhānamāyayau |
maunaṃ jaladanādena māyūra iva nikhanaḥ
]

`v 18 [
ākṣubdhā kṣubdhapakṣāliḥ pañjarasthā khagāvalī |
bhūkampe tarasā''tālīpallaveva vanāvalī
]

`v 19 [
āyayurbhayavitrastā bālā dhātrīkucāntaram |
sāravaṃ prāvṛṣīvābdhāḥ pronnataṃ śṛṅgakoṭaram
]

`v 20 [
uttasthuravataṃsebhyo bhūbhṛtāṃ bhramarasrajaḥ |
īṣatkarālavāhābhyaḥ saridbhyo'mbukaṇā iva
]

`v 21 [
evaṃ prakṣubhite tasmingṛhe dāśarathe tadā |
prāpte vāsaravṛddhatve śāntaśaṅkhasvane śanaiḥ
]

`v 22 [
saṃharanprastutaṃ vastu vaco madhuravṛttimat |
uvāca muniśārdūlaḥ sabhāmadhye raghūdvaham
]

`v 23 [
rāghavānagha vāgjālaṃ mayaitatpravisāritam |
tena cittakhagaṃ baddhvā kroḍīkṛtyātmatāṃ naya
]

`v 24 [
kaccidgṛhīto bhavatā madgirāmartha īdṛśaḥ |
tyaktvā durbodhamakṣīṇo haṃsenevāmbhasaḥ payaḥ
]

`v 25 [
vicāryaitadaśeṣeṇa svadhiyaivaṃ punaḥ punaḥ |
anenaiva pathā sādho gantavyaṃ bhavatādhunā
]

`v 26 [
anayaiva dhiyā rāma viharannaiva badhyase |
anyathādhaḥ patasyāśu vindhyakhāte yathā gajaḥ
]

`v 27 [
sugṛhītaṃ dhiyā rāma madvaco na karoṣi cet |
tatpatasyavaṭe tyaktadīpo vāndho niśāsviva
]

`v 28 [
asaṅgena yathāprāpto vyavahāro'sya siddhaye |
ityeva śāstrasiddhāntamādāyodāravānbhava
]

`v 29 [
he sabhyā he mahārāja rāmalakṣmaṇabhūmipāḥ |
sarva eva bhavanto'dya tāvadvyāpāramāhnikam
]

`v 30 [
kurvantvayaṃ hi divasaḥ prāyaḥ pariṇatākṛtiḥ |
śeṣaṃ vicārayiṣyāmo vicāryaṃ prātarāgatāḥ
]

`v 31 [
prātaḥ śvaḥ samāyāmāgatāḥ santaḥ | dhāturāṃbandhe pratyayāḥ iti bhaviṣyati ktaḥ ||
30 ||
śrīvālmīkiruvāca |
ityuktā muninā tena sā sarvaiva tadā sabhā |
prottasthau padmavadanā savikāseva padminī
]

`v 32 [
rājānaḥ stutarājānaḥ kṛtarāghavavandanāḥ |
pariṣṭute vasiṣṭhe te jagmurātmaniveśanam
]

`v 33 [
viśvāmitreṇa sahito vasiṣṭho mantumāśramam |
uttasthāvāsanācchrīmānnamaskṛtanabhaścaraḥ
]

`v 34 [
daśarathaprabhṛtayo rājāno gunayastathā |
yathānurūpaṃ vaktāramanugamya muniṃ ciram
]

`v 35 [
āpṛcchya kecidgaganaṃ yayuḥ kecidvanāntaram |
kecidrājagṛhaṃ santo bhṛṅgāḥ padmotthitā iva
]

`v 36 [
vasiṣṭhapādayostyaktvā puṣpāñjalimanāvilam |
dārairanugato rājā praviveśa gṛhāntaram
]

`v 37 [
rāmalakṣmaṇaśatrughnāḥ prāptasya svāśramaṃ guroḥ |
abhyarcya caraṇau bhaktyā tvājagmurnṛpamandiram
]

`v 38 [
sadanāni samāsādya śrotāraḥ sarva eva te |
samurānarcurabhyeyurdevānviprānpitṝṃstathā
]

`v 39 [
yathākramaṃ svabhṛtyāntairviprādyaiśca paricchadaiḥ |
samaṃ bubhujire bhojyaṃ varṇadharmakramoditam
]

`v 40 [
astaṃ gate dinakare samaṃ divasakarmabhiḥ |
abhyāgate rātrikare samaṃ rajanikarmabhiḥ
]

`v 41 [
sthitvā talpeṣu kauśeyaśayaneṣvāsaneṣu ca |
bhūcarā munirājāno rājaputrā maharṣayaḥ
]

`v 42 [
saṃsārottaraṇopāyaṃ vasiṣṭhavadaneritam |
yathāvadekāgradhiyaścintayāmāsurādṛtāḥ
]

`v 43 [
tataḥ praharamātreṇa nidrāmāmudritānanāḥ |
utsvapnasundarīmīyuḥ padmā iva dinārthinaḥ
]

`v 44 [
rāmalakṣmaṇaśatrughnāḥ praharatrayameva tat |
vāsiṣṭhamupadeśaṃ te cintayāmāsurakṣatam
]

`v 45 [
praharasyārdhamātraṃ te tata āmudritekṣaṇāḥ |
utsvapnamāyayurnidrāṃ kṣaṇādvidrāvitaśramām
]

`v 46 [
iti śubhamanasāṃ vivekabhājāmadhigatasāratayoditāśayānām |
abhajata viratiṃ tadā viyāmā malinaniśākaravaktratāṃ jagāma
]