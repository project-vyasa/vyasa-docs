`v 1 [
pañcapañcāśaḥ sargaḥ 55
śrīvasiṣṭha uvāca |
bhāvābhāvagrahotsargasthūlasūkṣmacarācarāḥ |
ādāveva hi notpannāḥ sargādau kāraṇaṃ vinā
]

`v 2 [
na tvamūrto hi ciddhātuḥ kāraṇaṃ bhavituṃ kvacit |
svātmā śaktaḥ sa mūrtānāṃ bījamurvīruhāmiva
]

`v 3 [
svabhāvameva satataṃ bhāvayanbhāvanātmakam |
ātmanyeva hi ciddhātuḥ sarvo'nubhavavānsthitaḥ
]

`v 4 [
āsvādayati yaṃ bhāvaṃ ciddhāturgaganātmakaḥ |
labdhaḥ sargaḥ pralāpena kṣībaḥ kṣubdhatayā yathā
]

`v 5 [
yadā sarvamanutpannaṃ nāstyevāpi ca dṛśyate |
tadā brahmaiva viddhīdaṃ samaṃ śāntamasatsamam
]

`v 6 [
cinnabhaścinnabhasyeva payasīva payodravaḥ |
cittvātkacati yattena tadevedaṃ jagatkṛtam
]

`v 7 [
svapne tadevajagadityudeti vimalā yathā |
kācakasyeva kacati tathetthaṃ sādi sargakhe
]

`v 8 [
citkācakasya kacanaṃ yathā svapne jagadbhavet |
tathaiva jāgradavidhaṃ tatkhamātramidaṃ sthitam
]

`v 9 [
ādisarge hi citsvapno jāgradityabhiśabdyate |
adya rātrau citeḥ svapnaḥ svapna ityapi śabdyate
]

`v 10 [
pūrvapravṛttā saritāṃ rūḍhādyāpi yathāsthitā |
taraṅgalekhā dṛṣṭīnāṃ padārtharacanā tathā
]

`v 11 [
yathā vāritaraṅgaśrīḥ saritāṃ racanā mitā |
tathā cidvyomni cidbījasattāntaḥsṛṣṭitāmitā
]

`v 12 [
mṛtasyātyantanāśaścettannidrāsukhameva tat |
bhūyaścodeti saṃsārastatsukhaṃ navameva tat
]

`v 13 [
kukarmabhyastu cedbhītiḥ sā sameha paratra ca |
tasmādete samasukhe sarveṣāṃ mṛtijanmanī
]

`v 14 [
maraṇaṃ jīvitaṃ vāstu sahaje vāsane tayoḥ |
iti viśrāntacitto yaḥ so'ntaḥśītala ucyate
]

`v 15 [
sarvasaṃvittivigame saṃvidrohati yādṛśī |
bhūyate tanmayenaiva tenāsau mukta ucyate
]

`v 16 [
atyantābhāvasaṃvittyā sarvadṛśyasya vedanam |
udetyapāstasaṃvedyaṃ sati vā'sati sargake
]

`v 17 [
yanna cetyaṃ na cidrūpaṃ yacciterapyacetitam |
tadbhāvaikyaṃ gatāstajjñāḥ śāntā vyavahṛtau sthitāḥ
]

`v 18 [
citkācakācakacyaṃ yajjagannāmnā taducyate |
atyacche paramākāśe bandhamokṣadṛśaḥ kutaḥ
]

`v 19 [
cinnabhaḥspandamātrātma saṃkalpātmatayā jagat |
sadbhūtamayamevedaṃ na pṛthvyādimayaṃ kvacit
]

`v 20 [
neha deśo na kālo'sti na dravyaṃn na kriyā na kham |
sadivākhilamucchūnaṃ vāpyanucchūnamapyasat
]

`v 21 [
bhāti kevalamevetthaṃ paramārthaghanaṃ ghanam |
yanna śūnyaṃ na vā'śūnyamatyacchaṃ gaganādapi
]

`v 22 [
sākāramapyanākāramasadevātibhāsvaram |
atiśuddhaikacinmātrasphāraṃ svapnapuraṃ yathā
]

`v 23 [
nirvāṇamevamidamātatamitthamantaścidvyomna āvilamanāvilarūpameva |
nāneva na kvacidapi prasṛtaṃ na nānā śūnyatvamambara ivāmbunidhau
dravatvam
]