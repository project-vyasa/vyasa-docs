`v 1 [
ṣaṭtriṃśaḥ sargaḥ 36
śrīvasiṣṭha uvāca |
camatkurvantyathānarthā āvartā iva vāriṇi |
ekasvabhāvāḥ sakalā yathā vāritaraṅgakāḥ
]

`v 2 [
sarvasyaivāsya viśvasya nirjñeyajñeyarūpiṇī |
paramākāśatārūpaṃ paropaśamasaṃśrayā
]

`v 3 [
bālacintā purovyomni na kiṃcidapi me yathā |
tathedaṃ tattvato viśvaṃ satyaṃ tu śiśucetasi
]

`v 4 [
arūpālokamananaṃ śilāputrakasainyavat |
rūpālokamanaskārā bhānti kevātra viśvatā
]

`v 5 [
rūpālokamanaskārasāraścinmātratāṃ vinā |
na labhyate'sāvaparaṃ vyomevātra kva viśvatā
]

`v 6 [
vido vittvaṃ jagadbhrāntiravittvaṃ tu na vibhramaḥ |
vittvāvittve tvadāyatte cittācitte yathā tava
]

`v 7 [
paramākāśarūpatvāccidvyomno vitatākṛteḥ |
na svabhāvaviparyāsaḥ kaścitsaṃbhavati kvacit
]

`v 8 [
tanmayasyāsya viśvasya na svabhāvavikāritā |
vidyate prekṣyamāṇāpi kimu sāmya bhaviṣyati
]

`v 9 [
sarvaṃ cidvyoma caivedaṃ na sattvamahamityapi |
vikārādyasti na jñaptāvajñaptiṃ na labhetkvacit
]

`v 10 [
sarvaṃ śāntaṃ śivaṃ śuddhaṃ tvamahaṃtādivibhramam |
na kiṃcidapi paśyāmi vyomajaṃ kānanaṃ yathā
]

`v 11 [
saṃvidākāśaśūnyatvaṃ yattadviddhi vaco mama |
idaṃ tvatsaṃvidākāśe svayamātmani tiṣṭhati
]

`v 12 [
padamāhuḥ paraṃ sadyadanicchodayamāsitam |
pāṣāṇapuruṣasyeva citrasthasyeva cāsanam
]

`v 13 [
sa viśrāntamanā maunī yasya prakṛtakarmasu |
spando dārunarasyeva vigatecchamanākulam
]

`v 14 [
antaḥśūnyaṃ bahiḥśūnyaṃ virasaṃ gatavāsanam |
jagadveṇoriva jñasya jīvato bhāti jīvanam
]

`v 15 [
yasya na svadate dṛśyamadṛśyaṃ svadate hṛdi |
sabāhyābhyantaraṃ śāntaḥ sa vitīrṇo bhavārṇavāt
]

`v 16 [
ucyantāṃ śabdajālāni vaṃśavadgatavāsanam |
rasenānaṅgalagnena prakṛtānanyacodanaiḥ
]

`v 17 [
spṛśyantāṃ sparśanīyāni yathāprāptānyavāsanam |
kūṭāgāravadakṣubdhamanicchamamanodayam `note[manodayamityārṣam |] | 17
|
evaṃ tvagindriyeṇa tvayā naṭabhaṭaveśyādikūṭanivāsagṛheṇevānicchamamanodayaṃ
ca sparśanīyāni srakcandanādīni spṛśyantām
]

`v 18 [
svādyantāṃ rasajālāni vigatecchābhayaiṣaṇam |
aparāgābhilaṣaṇaṃ yathāprāptāni darvivat
]

`v 19 [
dṛśyantāṃ rūpajālāni punaḥ prāptānyavāsanam |
arasaṃ nirmanomānamagarvaṃ citranetravat
]

`v 20 [
jighryantāṃn gandhapuṣpāṇi vigatecchamavāsanam |
spandabandhopalagnāni tyāgāya vanavātavat
]

`v 21 [
jighryantāṃ ghrāyantām | aśiti jighrādeśaśchāndasaḥ | jighnantāṃ iti pāṭhe
vikaraṇavyatyayaḥ | apānopanītaṃ `note[apānopanītamiti ūrdhvaṃ prāṇa unnayatyapānaḥ
pratyagasyatīti kaṭhavallīśrutyanurodheneti jñeyam |] gandhaṃ spandena
badhnātyasaṅgapāpmaneti spandabandho ghrāṇaṃ tadupalagnāni | tyāgāya na tu rāgāya |
20 |
iti cedvirasatvena bodhayitvā cikitsitāḥ |
na bhogarogāstadvacca śāntyai nāsti kathaiva ca
]

`v 22 [
yaḥ svādayanbhogaviṣaṃ ratimeti dine dine |
so'gnau svamūrti jvalite kakṣamakṣayamujjhati
]

`v 23 [
niricchatvaṃ samādhānamāhurāgamabhūṣaṇāḥ |
yathā śāmyenmano'nicchaṃ nopadeśaśataistathā
]

`v 24 [
icchodayo yathā duḥkhamicchāśāntiryathā sukham |
tathā na narake nāpi brahmaloke'nubhūyate
]

`v 25 [
icchāmātraṃ viduścittaṃ tacchāntirmokṣa ucyate |
etāvantyeva śāstrāṇi tapāṃsi niyamā yamāḥ
]

`v 26 [
yāvatī yāvatī jantoricchodeti yathā yathā |
tāvatī tāvatī duḥkhabījamuṣṭiḥ prarohati
]

`v 27 [
yathā yathecchā tanutāṃ yāti jantorvivekataḥ |
tathā tathopaśāmyanti duḥkhacintāviṣūcikāḥ
]

`v 28 [
yathā yathecchā ghanatāṃ yāti lokasya rāgataḥ |
tathā tathā vivardhante duḥkhacintāviṣormayaḥ
]

`v 29 [
icchā cikitsyate vyādhirna svayatnauṣadhena cet |
tadatra balavanmanye vidyate nauṣadhāntaram
]

`v 30 [
icchopaśamanaṃ kartuṃ yadi kṛtsnaṃ na śakyate |
svalpamapyanugantavyaṃn mārgastho nāvasīdati
]

`v 31 [
yastvicchātānave yatnaṃ na karoti narādhamaḥ |
so'ndhakūpe svamātmānaṃ dinānudinamujjhati
]

`v 32 [
duḥkhaprasavaśālinyā bījamicchaiva saṃsṛteḥ |
samyagjñānāgnidagdhā sā na bhūyaḥ parirohati
]

`v 33 [
icchāmātraṃ hi saṃsāro nirvāṇaṃ tadavedanam |
icchānutpādane yatnaḥ  kriyatāṃ kiṃ vṛthābhramaiḥ `note[vṛthāśramaiḥ
ityubhayatra pāṭhaḥ |]
]

`v 34 [
śāstropadeśaguravaḥ prekṣyante kimanarthakam |
kimicchānanusaṃdhānasamādhirnādhigamyate
]

`v 35 [
yasyecchānanusaṃdhānamātre duḥsādhyatā mateḥ |
gurūpadeśaśāstrādi tasya nūnaṃ nirarthakam
]

`v 36 [
icchāviṣavikāriṇyāmanta eva nṛṇāmalam |
duḥkhaprasarakāriṇyā hariṇyā janma jaṅgale
]

`v 37 [
na vālīkriyate tvīṣadātmajñānāya cedasau |
icchopaśāntiḥ kriyatāṃ tayālaṃ tadavāpyate
]

`v 38 [
niricchataiva nirvāṇaṃ secchataiva hi bandhanam |
yathāśakti jayedicchāṃ kimetāvati duṣkaram
]

`v 39 [
jarāmaraṇajanmādi karañjakhadirāvaleḥ |
bījamicchā sadaivāntardahyatāṃ śamavahninā
]

`v 40 [
yato yato niricchatvaṃ muktataiva tatastataḥ |
yāvadgati yathāprāṇaṃ hanyādicchāṃ samutthitām
]

`v 41 [
yato yataśca secchatvaṃ bandhapāśāstatastataḥ |
puṇyapāpamayā duḥkharāśayo vitatārtayaḥ
]

`v 42 [
icchānirāsarahite gate sādhoḥ kṣaṇe'pi ca |
dasyubhirmuṣitasyeva yuktamākrandituṃ ciram
]

`v 43 [
yathā yathāsya puṃso'ntaricchā samupaśāmyati |
tathā tathāsya kalyāṇaṃ mokṣāya parivardhate
]

`v 44 [
ātmano nirvivekasya yadicchāparipūraṇam |
saṃsāraviṣavṛkṣasya tadeva pariṣecanam
]

`v 45 [
hṛdvṛkṣajāḥ svasukhaduḥkhakubījakośau
vairādivāśrayakṛtādaśubhācchubhācca |
āsādya duṣkṛtakṛśānuśikhāḥ śitāntā icchāśchamacchamiti
puṃspaśumādahanti
]