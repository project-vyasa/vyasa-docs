`v 1 [
ekonacatvāriṃśadadhikaśatatamaḥ sargaḥ 139
śrīvasiṣṭha uvāca |
cittameva jagatkartṛ saṃkalpayati yadyathā |
asatsatsadasaccaiva tattathā tasya tiṣṭhati
]

`v 2 [
tena saṃkalpitaḥ prāṇaḥ prāṇo me gatirityapi |
na bhavāmi vinānena tena tattatparāyaṇam
]

`v 3 [
ahaṃ katipayaṃ kālaṃ nanu prāṇavinākṛtaḥ |
na bhavāmi punarnūnaṃ bhavāmyeveti kalpitam
]

`v 4 [
yatra tenāṅga tatraitatprāṇenāśu kṣaṇādvapuḥ |
uditaṃ paśyati mano māyāpuramivātatam
]

`v 5 [
na bhavāmyeva bhūyo'haṃ prāṇadehavinākṛtaḥ |
dṛḍhaniścayabhāgitthaṃ cito bhavati no punaḥ
]

`v 6 [
dolāyitaṃ tu saṃdehādduḥkhamāste kuniścayam |
vikalpenaivamasyaitajjñānānnālpena yāsyati
]

`v 7 [
yasyāyamahamityasti tasya tannopaśāmyati |
varjayitvātmavijñānaṃn kenacinnāma hetunā
]

`v 8 [
nānyatra prathate jñānaṃn mokṣopāyavicāraṇāt |
ṛte tasmātprayatenan mokṣopāyo vicāryatām
]

`v 9 [
kilāhamidamityeva nāvidyā vidyate kvacit |
mokṣopāyādṛte naitatkutaścidayate'nyataḥ
]

`v 10 [
evaṃ yanmanasābhyastamupalabdhaṃ tathaiva tat |
tena me jīvitaṃ prāṇā iti prāṇe manaḥ sthitam
]

`v 11 [
dehe saumye sthite prāṇe mano mananavadbhavet |
kṣubdhe prāṇagataṃ kṣobhaṃ paśyannānyatprapaśyati
]

`v 12 [
yadā svakarmaṇi spande vyagraḥ prāṇo bhṛśaṃ bhavet |
tadā tadīhitavyagraḥ prāṇo nātmodyamī bhavet
]

`v 13 [
ete hi prāṇamanasī tvanyonyaṃ rathasārathī |
ke nāma nānuvartante rathasārathinau mithaḥ
]

`v 14 [
ityādisarge svātmaiva cetitaḥ paramātmanā |
tenaiṣādyāpi niyatirnābudhānāṃ nivartate
]

`v 15 [
deśakālakriyādravyairmanaḥprāṇaśarīriṇām |
prayāntyadhigatā deheṣvarūḍhānāṃ pare pade
]

`v 16 [
svaṃ prāṇamanasī sāmyātkurvatī karma tiṣṭhataḥ |
vaiṣamyādviṣamaṃ caikaṃ śānte śāntā suṣuptatā
]

`v 17 [
yadāhārādiruddhāsu nāḍīṣu kvāpi piṇḍitaḥ |
śāntamāste jaḍaḥ prāṇastadodeti suṣuptatā
]

`v 18 [
nāḍīṣvannāvapūrṇāsu tathā kṣīṇāsu vā klamāt |
niḥspandastiṣṭhati prāṇastadodeti suṣuptatā
]

`v 19 [
nāḍīnāṃ mṛdurūpatvātpūrṇatvādvā vraṇodare |
kvāpi prāṇe sthite līne niḥspandāste suṣuptatā
]

`v 20 [
tāpasa uvāca |
atha yasya praviṣṭo'haṃ hṛdaye so'bhavanniśi |
suṣuptaghananidrālurāhāraparitṛptimān
]

`v 21 [
tena sārdhamahaṃ tatra taccittenaikatāṃ gataḥ |
suṣuptanidrāṃ sughanāṃ guṇībhūto'nubhūtavān
]

`v 22 [
tato'ndhasyasya jīrṇe'ntarnāḍīmārge sphuṭe sthite |
prākṛte spandite prāṇe suṣuptaṃ tanutāṃ yayau
]

`v 23 [
tataḥ asya prāṇina udarasthe andhasi anne jīrṇe jāte sati prākṛte naisargike nāḍīmārge
prāṇe spandite spandamāne sati | gatyarthākarmaka - iti kartari ktaḥ | tanutāmalpatām |
22 |
suṣupte tanutāṃ yāte hṛdayādiva nirgatam |
apaśyamahamatraiva bhuvanaṃ bhāskarādimat
]

`v 24 [
tacca kṣubdhārṇavotthena pūryamāṇaṃ mahāmbhasā |
vimukteneva kalpābhrairabhraṃkaṣataraṃgiṇā
]

`v 25 [
prohyatparvatapūreṇa mahāvartavirāviṇā |
vahadvanālītṛṇyāḍhyairvyāptenonmūlitāgayā
]

`v 26 [
pūrvamevāvadagdhāyāstrilokyāḥ khaṇḍakhaṇḍakaiḥ |
pūrṇena paritaḥ prauḍhaiḥ khapurādrimahīmayaiḥ
]

`v 27 [
ahaṃ tatraiva paśyāmi yāvatkasmiṃścidāspade |
kasyāṃcitpuri kasmiṃścidgṛhe vadhvā pure sthitaḥ
]

`v 28 [
sadāraḥ sahabhṛtyo'haṃ saputraḥ sahabāndhavaḥ |
sahabhāṇḍopaskaraṇaḥ sagṛho'pahṛto'mbhasā
]

`v 29 [
uhyamānaṃ kṣayāmbhobhistadgṛhaṃ tacca pattanam |
laṅghyamānaṃ drumākāraiḥ pūryamāṇaṃ ca vāribhiḥ
]

`v 30 [
bṛhatkalakalārāvaṃ jetumabdhimivodyatam |
atikṣubhitavāstavyamanapekṣitaputrakam
]

`v 31 [
āvartataralāḍhyābhirvṛttibhirvyūḍhamākulam |
sākrandorastāḍanotkajanajambālabhīṣaṇam
]

`v 32 [
sphuṭatkuḍyatruṭatkāṣṭharaṭacchaṅkukṛtodraṭam |
prapatacchādanacchatragavākṣasthāṅganāmukham
]

`v 33 [
iti yāvatkṣaṇaṃ paśyannahaṃ tadbhāvamāgataḥ |
parirodimi dīnātmā tāvattatsakalaṃ gṛham
]

`v 34 [
caturdhā bhittibhedena vṛddhabālāṅganānvitam |
jagāma śatadhā vīcyāṃ śilāyāmiva nirjharaḥ
]

`v 35 [
uhyamāno'hamabhavaṃ tataḥ pralayavāriṇi |
tyaktasarvakalatrādicittaḥ prāṇaparāyaṇaḥ
]

`v 36 [
kṣiptastaraṅgajālena yojanādyojanavraje |
uhyamānadrumaśikhājvālāntaritajarjaraḥ
]

`v 37 [
kāṣṭhakuḍyataṭīpīṭhakaṭusaṃghaṭṭaghaṭṭitaḥ |
āvartanṛtyapātālatale gatvotthitaścirāt
]

`v 38 [
calācalāgamāpāyavaladgulugulārave |
jale bahulakallole magnonmagnaḥ punaḥ punaḥ
]

`v 39 [
saṃghaṭṭabhagnaśailendrapaṅkile salile kṣaṇam |
palvale vāraṇa iva magnaḥ satpayasoddhṛtaḥ
]

`v 40 [
yāvadāśvasimi kṣipraṃ ḍiṇḍīre cādrikhaṇḍake |
tāvadetya hato vegādvairiṇevātivāriṇā
]

`v 41 [
nānāvalanakallolajalajālajuṣā tadā |
na tadasti na yaddṛṣṭaṃ duḥkhaṃ duḥkhātmanā mayā
]

`v 42 [
etasminnantare tatra tadā tattāmasekṣaṇa `note[tāpasasya vyādhaṃ prati
saṃbodhanam |] |
yāvajjīvacirābhyāsādviṣāditvātsacetasaḥ
]

`v 43 [
prāktanaṃ saṃsmṛtaṃ rūpaṃ svaṃ samādhimayaṃ mayā |
ā aho nu jagatyanyarūpe'haṃ tāpasaḥ sthitaḥ
]

`v 44 [
ahaṃ kasyacidanyasya svapnadṛṣṭididṛkṣayā |
praviṣṭo'hamayaṃ svapne paśyāmīmaṃ bhramaṃ tviti
]

`v 45 [
vartamānadṛḍhābhyāsamithyājñānamayātmani |
kallolairuhyamāno'pi tato'haṃ sukhitaḥ sthitaḥ
]

`v 46 [
idaṃ vāritayāpaśyaṃ pralayābdhivivartanāḥ |
uhyamānādrinagaragrāmorvīkhaṇḍapādapāḥ
]

`v 47 [
uhyamānāmarāhīndranārīnaranabhaścarāḥ |
uhyamānamahārambhalokapālapurālayāḥ
]

`v 48 [
athāhamadrimiśrāmbukallolādrivighaṭṭanāḥ |
muhuḥ paśyañjagannāśamanantaramacintayam
]

`v 49 [
citrameṣa trinetro'pi jīrṇaṃ tṛṇamivārṇave |
uhyate hā hatavidhernā'kāryaṃ nāma vidyate
]

`v 50 [
caturdhā bhittibhedena prakaṭāśayatāmaham |
padmānīva gṛhāṇyapsu darśayanti raveḥ prabhāḥ
]

`v 51 [
citraṃ taraṅgavalanāsu samullasanti gandharvakiṃnaranarāmaranāganāryaḥ |
bhūribhramairbhramarahāramiva hradinyaḥ padminya eva
sakalāmalajaṅgamākhyāḥ
]

`v 52 [
vidyādharībhujalatāvalitendukāntakakṣyāvibhāgamaṇijālagavākṣalakṣmyaḥ |
devāsuroragamahāgṛhabhittibhāgāḥ sauvarṇanaugaṇavadambubhare bhramanti |
52 |
vidyādharīṇāṃ bhujalatāvaliteṣu indukānteṣu kakṣyāvibhāgā iva bhāsamānā
maṇijālagavākṣalakṣmyo yeṣu tathāvidhā devāsuroragamahāgṛhāṇāṃ bhittibhāgāḥ
pralayāmbubhare sauvarṇanaukāgaṇavadbhramanti
]

`v 53 [
mattebhakumbhapariṇāhini kuṅkumāṅke śacyāḥ payodharabhare
ratikhedakhinnaḥ |
lagnaḥ sukhādiva karoti taraṅgadolāḥ saṃśīryamāṇamaṇigehagato'tra śakraḥ |
53 |
saṃśīryamāṇamaṇigehagataḥ śakraḥ atrāsminpralayāmbubhare lagnaḥ san
kuṅkumāṅke mattebhakumbhavatpariṇāhini viśāle śacyāḥ paulomyāḥ payodharabhare
ratiprayuktena khedena khinnaḥ śrāntaḥ saṃstadapanayanāya jalakrīḍāsukhāt | lyablope
pañcamī | jalakrīḍāsukhamuddiśyeva taraṅgadolāḥ karoti
]

`v 54 [
hā vānti vārivalanāvalitāntarikṣamṛkṣāvadhūtakusumaprakarānkirantaḥ |
vātāḥ patadvibudhamandiraratnasānāvudyānakoṭaragatā iva sākṣatena
]

`v 55 [
yantrotthahemadṛṣadā sadṛśāmburūpaṃ kṣubdhādribhīmajalavīciśikheritaṃ
khe |
vyāvartate divi dalāvṛtakarṇikāsthadhyānaikaniṣṭhaparameṣṭhisarojametat
]

`v 56 [
meghā ivātighanaghuṃghumaghoṣabhīmā vīcīcayāḥ kanakapattanavidyuto'mī |
vyomni bhramanti gajavājimṛgendranāgavṛkṣādrikānanamahītalatulyadehāḥ |
56 |
gajavājyāditulyadehāḥ | atighanaghuṃghumaghoṣairbhīmāḥ
kanakamayadevāsurapattanānyeva vidyuto yeṣu tathāvidhā amī vīcīcayā meghā iva vyomni
bhramanti
]

`v 57 [
uhyamānodabhūvīcyāmatasīkusumaśriyām |
yamo'pyayaṃ yameneva vāripūreṇa nīyate
]

`v 58 [
ete bruḍanti salile'khilalokapālā nāgā nagaiśca nagaraiḥ saha lakṣasaṃkhyāḥ |
lakṣmyākarodaraguhāgatavāripūravyāvartanāguḍaguḍairabhilakṣyapūrāḥ
]

`v 59 [
durvāravārivalanāparipūriteṣu pātālabhūtalanabhastaladiktaṭeṣu |
matsyā ivendrayamayakṣasurāsuraughāḥ sagrāmapattanavimānanagā bhramanti | 59
|
spaṣṭam
]

`v 60 [
uhyamānasya kṛṣṇasya tanurevāmburūpiṇī |
mātṛjaṅgheva vatsasya kaṣṭaṃ bandhanatāṃ gatā
]

`v 61 [
anyonyamāvalayatāmaho buḍabuḍāravaḥ |
śrūyate devadaityānāṃ svastrīhalahalākulaḥ
]

`v 62 [
kolāhalākulapurottamavegapātavikṣubdhavāripaṭalīvalitāmbarāsu |
dikṣu bhramajjaladajālaghanāsvivaiṣa saṃlakṣyate jalāmayaḥ sphuṭakuḍyabandhaḥ
]

`v 63 [
hā kaṣṭameṣa tarasā payasāpanīta āvartavṛttiparivartanayā svadhastāt |
ete kuberayamanāradavāsavādyāḥ prāṇānpayobhrapaṭalairvidhurāstyajanti
]

`v 64 [
prājñāḥ praśāntajaḍadehamihohyamānaṃ mānojjhitāḥ śavatayaiva ca tadvahanti
|
brahmendraviṣṇupurakhaṇḍakasaṃkaṭāmbusaṃghaṭṭanena kaṭukuṭṭanadṛkṣu
tena
]

`v 65 [
strīṇāṃ gaṇo'rdhaparipiṣṭa ihaiti kaṣṭaṃ kastrātumenamaparaḥ kujaḍaṃ
samarthaḥ |
na hyantakasya daśanairabhicarvyamāṇā trātuṃ parasparamiyaṃ janatā samarthā |
65 |
kujaḍaṃ kau pṛthvyāṃ jaḍamatimūrkhatvena prasiddhamenaṃ strīgaṇaṃ trātuṃ kaḥ
samarthaḥ | janatā janasamūhaḥ
]

`v 66 [
parvatapratighasarpasarpaṇāḥ saṃsaranti vipulā jaloccayāḥ |
teṣu nāva iva devapattanānyunnamayya vapurāśu yāntyadhaḥ
]

`v 67 [
dvvpādrīndrasurāsuroraganarairnāgāpsaraścāraṇairvyāptaṃ vārivilolitaiḥ
sarasijairālūnamūlairiva |
ekāmbhodhisaraḥ sthitaṃ tribhuvanaṃ kālena nirmūlitaṃ kaṣṭaṃ te kva gatā
maharddhivibhavā devā jagannāyakāḥ
]