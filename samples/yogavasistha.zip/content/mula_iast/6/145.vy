`v 1 [
pañcacatvāriṃśadadhikaśatatamaḥ sargaḥ 145
muniruvāca |
bahiṣṭhairbāhyamevāntarantasthaiḥsvapnamindriyaiḥ |
jīvo vetti dvayasthātitīvrasaṃvegibhirdvayam
]

`v 2 [
yadendriyāṇi tiṣṭhanti bāhyataśca samākulam |
tadā mlānānubhavanaḥ saṃkalpārtho'nubhūyate
]

`v 3 [
yadā tvantarmukhānyeva santyakṣāṇi tadā jagat |
aṇumātraṃ svavapuṣi jīvastenātivetti tat
]

`v 4 [
jagatsapratighaṃ nāsti kiṃcideva kadācana |
jīvekṣaṇānāmakṣāṇāṃ dṛṣṭirapratighā jagat
]

`v 5 [
jīvanetrāṇīndriyāṇi yadā bāhyamayānyalam |
tadā bāhyātmakaṃ vetti citi jīvo jagadvapuḥ
]

`v 6 [
śrotaṃ tvagīkṣaṇaṃ ghrāṇaṃ jihvā cetīhitātmakaḥ |
saṃghātaḥ procyate jīvaścidrūpo'nilamūrtimān
]

`v 7 [
sarvatra sarvadā jīvaḥ sarvendriyamayaḥ sthitaḥ |
ciccidvyomāvyayastena sarvaṃ sarvatra paśyati
]

`v 8 [
śleṣmātmanā rasenāntarjīva āpūryate yadā |
te'kṣāṇuke'ṇurūpātmā tadā tatraiva vindati
]

`v 9 [
kṣīrārṇava ivoḍḍīno nabhaścandrodayānvitam |
sarāṃsi phullapadmāni kahlāravalitāni ca
]

`v 10 [
puṣpābhrapratidhānāni parigītāni ṣaṭpadaiḥ |
vasantāntaḥpurāṇyantarudyānānyuditāni khe
]

`v 11 [
utsavānmaṅgalākīrṇāṃllīlālolāṅganāgaṇān |
bhakṣyabhojyānnapānaśrīparipūrṇagṛhājirān
]

`v 12 [
sapuṣpāḥ phenahasanāstaralātaralekṣaṇāḥ |
vilāsenāmbudhiṃ yānti sarito mattayauvanāḥ
]

`v 13 [
himavacchubhraśṛṅgāṇi saudhāni śiśirāṇyalam |
sudhāvadhautabhittīni kṛtānīndutalairiva
]

`v 14 [
śiśirāsārahemantaprāvṛṇmeghavṛtāni ca |
sthalāni nīlanalinīlatāśādvalavanti ca
]

`v 15 [
puṣpaprakarasaṃchannā viśrāntahariṇādhvagāḥ |
snigdhapatratarucchāyāḥ puroṃpavanabhūmikāḥ
]

`v 16 [
kadambakundamandāramakarandendukāntibhiḥ |
bhāsamānāsanasthānasaṃsthānāḥ kusumasthalīḥ
]

`v 17 [
nalinījālinīrnīlāḥ puṣpakasthaladhāriṇīḥ |
vanāvalīrvilīnābhranirmalākāśakomalāḥ
]

`v 18 [
kadalīkandalīkundakadambakṛtaśekharāḥ |
girimālāścalaccārulīlāpallavapelavāḥ
]

`v 19 [
helāvalitadhammillamuktamālatikālatāḥ |
iva bālāṅganā nṛtyaṃ tanvānāstanugātrikāḥ
]

`v 20 [
utphullaśvetanalinīnibhā narapateḥ sabhāḥ |
cārucāmarabhṛṅgāravitānakaśatāvṛtāḥ
]

`v 21 [
vallīvalayavinyāsavilāsavalitāṅgikāḥ |
vanamālā vilolāmbupraṇālīkākalīkalāḥ
]

`v 22 [
dharābharakarālāṅgadhārādharadharādharāḥ |
diśaḥ sīkaranīhārahārodaradharā daśa
]

`v 23 [
pittātmanā rasenāntarjīva āpūryate yadā |
ojontaraṇumātrātmā tadā tatraiva vindati
]

`v 24 [
pavanaspandasaṃśuṣkakiṃśukadrumaśobhanāḥ |
jvālālīrujjvalāmbhojadalapallavapelavāḥ
]

`v 25 [
saṃtaptasikatāsekasanīhārasaricchirāḥ |
dāvānalaśikhāśyāmadhūmaśyāmaladiṅmukhāḥ
]

`v 26 [
kṛśānukarkaśānarkāṃścakradhārāśitatviṣaḥ |
dāvadāhaviṣāveśaviparītarasākarān
]

`v 27 [
svedamuṣṇīkṛtābdhiṃ vā svinnaṃ trailokyamaṇḍalam |
kṣaratkṣārāṇyaraṇyāni pratardagahanānyapi
]

`v 28 [
prataranmṛgatṛṣṇāmbusaratsārasarūpi ca |
sthalānyadṛṣṭapūrvāṇi bhūtapūrvatarūṇi ca
]

`v 29 [
adhvagaṃ saṃbhramavaśāttaptadhūlividhūsaram |
dūrādamṛtavaddṛṣṭaṃ snigdhacchāyādhvapādapam
]

`v 30 [
jvarajvālitamākāraṃ bhuvanaṃ taptamagnivat |
pāṃsūpahatadeśāni diṅmukhāni ca khāni ca
]

`v 31 [
grahagrāmārṇavādryabdhivanavyomāgnikā diśaḥ |
tuhināhārahānantāsaṃkhyāmbudaghaṭodbhaṭān
]

`v 32 [
śaradgrīṣmavasantāṃśca tāpānātapadāyinaḥ |
tṛṇapatralataughābhrarāśyūṣmapihitāvanīḥ
]

`v 33 [
sauvarṇamambaratalaṃ bhūtalaṃ diktaṭāni ca |
taptānyadabhrasarasīhimaśailasthalāni ca
]

`v 34 [
rasānurikte vātena jīva āpūryate yadā |
ojontaraṇumātrātmā tadā tatraiva vindate
]

`v 35 [
vātavikṣubdhasamvittvādapūrvaṃ vasudhātalam |
apūrvā nagaragrāmaśailābdhivanamaṇḍalīḥ
]

`v 36 [
uḍḍīyamānamātmānaṃ śilāḥ śailasthalāniva |
ghanaghuṃghumasārāvānacakrabhramaṇādi ca
]

`v 37 [
hayoṣṭragaruḍāmbhodahaṃsayānāvarohaṇam |
yakṣavidyādharādīnāṃ gatyāgamanasaṃcaram
]

`v 38 [
sādridyūrvīnadīśānāṃ vanabhūgrāmapūrdiśām |
kampaṃ bhayonmukhāṅgānāṃ budbudānāmivārṇave
]

`v 39 [
andhakūpe nipatitaṃ vipule saṃkaṭe'thavā |
athavā rūḍhamātmānaṃ khamābhaṃ pādapaṃ girim
]

`v 40 [
khaṃ minoti paricchinattyābhā saṃsthānaśobhā yasya tathāvidhaṃ pādapaṃ giriṃ ca |
39 |
vātapittaśleṣmayukto jīva āpūryate yadā |
bhāgairvātavaśaṃ prāptairārto'sau vindate tadā
]

`v 41 [
patantīṃ pārvatīṃ vṛṣṭiṃ suśilāvṛṣṭisaṃkaṭam |
sphuṭāṭṭakaṭakārāvabhramatpādapamaṇḍalam
]

`v 42 [
bhramadbhirvanavinyāsaiḥ saṃdigdhāmbhodharotkaṭam |
siṃhavāraṇavarṣābhranirantaradigantaram
]

`v 43 [
tālītamālahiṃtālamālājvalanasaṃkulam |
guhāghuṃghumanirhrādabhāṃkāraghanaghargharam
]

`v 44 [
mandramandaramanthānaśabdasaṃdarbhasundarīm |
darīṃ dalanadurvāramithaḥsaṃghaṭṭaghaṭṭitām
]

`v 45 [
śṛṅgasaṃghaṭṭasadṛśāḥ kreṃkārotkarakarkaśāḥ |
nadīrmuktālatāpātasasnagdāmanabhastalāḥ
]

`v 46 [
śilāśakalapūrṇārṇapūrṇāmbaramahārṇavam |
vahadvanaghanodghātaghaṭṭitabrahmamaṇḍalam
]

`v 47 [
parasparavinirmṛṣṭadaśadarśanadanturam |
caṭatkaṭakaṭārāvasphuṭatkaṭakaṭaṅkitam
]

`v 48 [
khapātapavanādhūtavanavātalatodayam |
raṇadātmadṛṣaccūrṇakarburāmbujadhāriṇam
]

`v 49 [
prāgbhaṭodbhaṭabhedotthairmandrairmaramarāravaiḥ |
krūrākrandairivābhāti virājitajagattrayam
]

`v 50 [
iti taiḥ kāṣṭhapāṣāṇamṛdyugvātabhaṭairvṛtaḥ |
paripīḍita evāste yadā jīvo jaḍīkṛtaḥ
]

`v 51 [
mṛdantaḥkīṭakaṇavacchilāntargatabhekavat |
garbhasthāpakvaśiśuvatphalāntargatabījavat
]

`v 52 [
bījodarasthāṅkuravaddravyapiṇḍodarāṇuvat |
aśrāntastambakośasthadāruputrakadehavat
]

`v 53 [
sauṣiryāsaṃbhavātprāṇapavanaspandavarjitaḥ |
pronnamatparśupūreṇa śilāpūreṇa tarjitaḥ
]

`v 54 [
suṣuptaṃ tarhi kadā kena nimittenānubhavati tadāha - sauṣiryeti | yadāyaṃ jīvaḥ
purītati nāḍīpañjare sarvapārśvāsthyagraghaṭitahṛdayāsthigranthyupalakṣite praviṣṭo
bhavati tadā agre saṃcārārthaṃ sauṣiryāsaṃbhavādyasminpradeśe
prāṇapavanaprayuktena spandena varjitaḥ sanpronnamatāṃ parśūnāṃ pārśvāsthīnāṃ
pūreṇa granthinā śilāpūreṇa bile niruddha iva tarjito vyāpārāsamarthaḥ kuto bhavati tadā
prāguktanibiḍataraujaḥśabditatejontareva śailakośaḥ śilājaṭharaṃ
tadābhamajñānagāḍhatvādandhakūpodaropamaṃ suṣuptamanubhavatīti dvayoranvayaḥ |
53 |
tadā nibiḍatejontarevānubhavati svayam |
suṣuptaṃ śailakośābhamandhakūpodaropamam
]

`v 55 [
yadā pariṇataṃ yatnaṃ punaḥ sauṣiryamāgatam |
punarvetti tadā jīvaḥ svapnaṃ prāṇāvabodhitaḥ
]

`v 56 [
yadā tasminpradeśe'ntarbhāgabhāgānpatanti te |
dehe pariṇamanto'ntastadevātyadrivarṣaṇam
]

`v 57 [
bahveva vahnibahunā svalpenālpaṃ prapaśyati |
vātapittādiyogena bahirantaśca saṃbhramam
]

`v 58 [
paśyatyetadyathaivāntareṣa jīvo vaśīkṛtaḥ |
vātapittādivalito bahirvettyevameti vā
]

`v 59 [
kṣubdhairantarbahiścaiva svalpaḥ svalpaṃ prapaśyati |
samaiḥ samamidaṃ dṛśyaṃ vātapittakaphādinā
]

`v 60 [
bahiḥ paśyatyayaṃ jīvaḥ kupitairebhirāvṛtaḥ |
spandaṃ bhūmyadrinabhasāṃ jvalanaṃ vānaloccayaiḥ
]

`v 61 [
ākāśagamanaṃ caiva candrodayahimācalān |
gahanaṃ vṛkṣaśailānāṃ nabhaḥplavanamarṇasām
]

`v 62 [
majjanonmajjanaṃ vābdhau surataṃ surasadmasu |
śailopavanaśubhrābhrapīṭhaviśramaṇoccayam
]

`v 63 [
bṛhatkrakacaniṣpeṣaṃ narakānubhavabhramam |
tālītamālahiṃtālamālāvalanamambare
]

`v 64 [
cakravṛttaiśca patanaṃ jhagityutpatanaṃ divi |
śūnye'pi janatāvṛndaṃ sthale'pyabdhinimajjanam
]

`v 65 [
vicitraṃ viparītaṃ ca vyavahāraṃ mahāniśi |
ahnīva bhāskarālokaṃ durbhedyaṃ cāhni vā tamaḥ
]

`v 66 [
sādribhūtalamākāśe kuḍyabandhe ghane sthalam |
kuḍyabandhāṃśca gagane mitrabhāvaṃ ca vidviṣi
]

`v 67 [
svajane paratābuddhiṃ sujanatvaṃ ca durjane |
susamasthalatāṃ śvabhre śvabhratvaṃ susame sthale
]

`v 68 [
udgītālāpamasṛṇānsudhādhautānsucitritān |
udrīñchvetamayānvāpi navanītamayāṃśca vā
]

`v 69 [
kadambanīpajambīrapatrastabakasadmasu |
sukhaviśramaṇaṃ strībhiḥ nākaṃ padmeṣvivālinaḥ
]

`v 70 [
antarnimīlitā hyetāḥ paśyantyunmīlitā bahiḥ |
dhātūnāmiti vaiṣamyādbhrāntimindriyavṛttayaḥ
]

`v 71 [
evaṃvidhānyanekāni paśyantyanubhavanti ca |
bahireva yathā svapne vastunyasamadhātavaḥ
]

`v 72 [
bahiścāntaśca dṛśyante viparītānyanekaśaḥ |
kāryāṇyatikarālāni jīvairasamadhātubhiḥ
]

`v 73 [
sameṣu dhātuṣveṣo'ntarjīvo'nubhavati svayam |
tejontargata evemāṃ vyavahārasthitiṃ samām
]

`v 74 [
yathāsthitāṃ puragrāmapattanāraṇyasaṃtatim |
saumyavāritarucchāyādeśādhvagagamāgamam
]

`v 75 [
sukhātapamayendvarkatārāhorātramaṇḍitam |
evametadasadbhūtaṃ sadbhūtamiva bhāsate
]

`v 76 [
dṛśyopalambhaṃ cittattve spandanaṃn pavane yathā |
asadeva sadābhāsamabhinnaṃ bhinnavatsthitam
]

`v 77 [
śāntādudeti sakalaṃ jagadambarātma śāntaṃ na kiṃcana na nāma sadityudeti |
tadvyomanīdṛśamanantaciteḥ śarīre bhāmātramātatamanantavapurvibhāti
]