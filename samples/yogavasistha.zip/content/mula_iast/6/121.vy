`v 1 [
ekaviṃśatyadhikaśatatamaḥ sargaḥ 121
śrīvasiṣṭha uvāca |
atha teṣvarṇavataṭeṣvete bhūmau vipaścitaḥ |
upaviśyaitadakhilaṃ cakrū rājyaprayojanam
]

`v 2 [
tadā tatraiva te vāsabhūmiṃ kṛtvā yathākramam |
tasthurmaṇḍalamaryādāṃ sthāpayāmāsurakṣatām
]

`v 3 [
atha varṇayituṃ śrīmāṃstatpratāpamivāgamat |
saṃpraviśya samudrāntaranyalokāntaraṃ raviḥ
]

`v 4 [
āyayau yāminīśyāmā meghalekheva tānavam |
saṃpāditāharvyāpārāstasthuḥ svaśayaneṣu te
]

`v 5 [
āsamudraṃ nadīvāhā iva dūrādupāgatāḥ |
idaṃ saṃpādayāmāsurvismayākulacetasaḥ
]

`v 6 [
aho nu dūramadhvānaṃ prāptā vayamayatnataḥ |
prabhāvoddevadevasya vahnerdivyaiḥ svavāhanaiḥ
]

`v 7 [
kiyatī syātpravistīrṇā dṛśyaśrīriyamātatā |
itaḥ samudrastadanu dvīpabhūrambudhiḥ prabhuḥ
]

`v 8 [
ito dvīpaṃ tato'mbhodhiḥ kimante syāttato'pi ca |
kiyatī kīdṛśī vā syānmāyeyaṃ cetyarūpiṇī
]

`v 9 [
tatprārthayāmahe devaṃ hutāśaṃ tadvarādimāḥ |
prekṣāmahe diśaḥ sarvā āparyantamakhedinaḥ
]

`v 10 [
iti saṃcintya te sarve yathāsthānamavasthitāḥ |
samamevāhvayāmāsurbhagavantaṃ hutāśanam
]

`v 11 [
babhūva bhagavāneṣāmatha dṛśyo hutāśanaḥ |
ākāravānvaraṃ putrāḥ pragṛhṇītetyuvāca ha
]

`v 12 [
vipaścita ūcuḥ |
pañcabhūtātmakasyāsya dṛśyasyāntaṃ sureśvara |
dehena mantradehena tadante manasāpi ca
]

`v 13 [
yāvatsaṃvedanaṃ yāvatsaṃbhavaṃ yāvadātmakam |
paśyema iti no deva dīyatāmuttamo varaḥ
]

`v 14 [
āsiddhagamyamadhvānaṃ paśyema vapuṣā vayam |
tadante manasaivātha dṛśyaṃ paśyema bho prabho
]

`v 15 [
āsiddhagamyamadhvānaṃ mṛtyurasmākamastu mā |
adhvanyasaṃbhavaddehe mana eva prayātu naḥ
]

`v 16 [
śrīvasiṣṭha uvāca |
athaivamastviti procya pāvakaḥ sahasāgamat |
kṣaṇādaurvatayā yātuṃ samudra iva satvaraḥ
]

`v 17 [
atha tadvaraprārthanānantaram | aurvatayā vaḍavāgnibhāvena samudre yātuṃ satvara iva |
16 |
agnirjagāmātha samājagāma niśā vilambyātha jagāma sāpi |
samājagāmāpi ravirjagāma teṣāṃ ca dhīrārṇavalaṅghanehā
]