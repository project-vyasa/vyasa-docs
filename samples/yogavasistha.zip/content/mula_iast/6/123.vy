`v 1 [
trayoviṃśādhikaśatatamaḥ sargaḥ 123
śrīvasiṣṭha uvāca |
ityete dṛśyarūpāyā avidyāyā vicāraṇe |
pravṛttāḥ pādacāreṇa samudradvīpagāminaḥ
]

`v 2 [
abdherdvīpaṃ punardvīpādabdhiṃ dvīpaṃ giriṃ vanam |
lāghavāllaṅghayāmāsuśchedabhedavivarjitāḥ
]

`v 3 [
pīto vipaścitpāścātyo mīnenāmaramāninā |
viṣṇumīnakulotthena vitastāvāhanaujasā
]

`v 4 [
kṣīrodaṃ prāpya matsyena tenodgīrṇaḥ sudurjaraḥ |
tena kṣīrodamullaṅghya gato dūraṃ digantaram |
sudurjaro jarayitumaśakyaḥ
]

`v 5 [
dakṣiṇo yakṣanagare saṃprekṣyekṣurasārṇave |
śikṣādakṣiṇayākṣipya yakṣiṇyā kāmukīkṛtaḥ
]

`v 6 [
pūrvo makaramākramya yadā gaṅgāṃ nikṛttavān |
gaṅgayā sa tadānīya kānyakubje samujjhitaḥ
]

`v 7 [
uttarastūttarakurūnārādhya prāptavāñśriyam |
taṃ tayainaṃ na bādhante digante mṛtabhītayaḥ
]

`v 8 [
tayā makaramātaṅganigīrṇordgīrṇamūrtimān |
aticakrāma subahūndvīpāntarakulācalān
]

`v 9 [
paścimaḥ pṛṣṭhamāropya hemacūḍena pakṣiṇā |
kuśadvīpe kuśāṅgaśrīstarasā tārato'rṇavān
]

`v 10 [
krauñcadvīpācale pūrvo nigīrṇo rakṣasā vane |
tadrakṣaḥ pāṭitaṃ tena hṛdaye'ntravikartanaiḥ
]

`v 11 [
dakṣiṇo dakṣaśāpena yakṣatāmāgataḥ kṣaṇāt |
śākadvīpe śatenāsau varṣāṇāṃ mokṣamāgataḥ
]

`v 12 [
uttarastarasottīrṇatārāvarataraṅgiṇaḥ |
mahārṇavasuvarnorvyāṃ siddhaśāpācchilāṃ gataḥ
]

`v 13 [
tato varṣaśatenāsau prasādājjātavedasaḥ |
tenaivonmocitastatra siddhena ratimāptavān
]

`v 14 [
varṣāṇyaṣṭāvabhūdrājā nālikeranivāsinām |
pūrvaḥ paramadharmiṣṭhaḥ prāptavānprāksmṛtiṃ tataḥ
]

`v 15 [
kalpavṛkṣavane meroruttare'psarasā saha |
uvāsa daśavarṣāṇi nālikeraphalāśnaḥ
]

`v 16 [
vihagāśvāsatattvajñaḥ śālmalidvīpaśālmalau |
paścimaḥ pakṣiṇīnīḍe krīḍayā nyavasatsamāḥ
]

`v 17 [
mandarādrau mṛdutale mandāratarumandire |
kinnarī mandarīnāmnī dinamekamasevata
]

`v 18 [
kṣīrodavelāvanakalpavṛkṣavanāvalīnandanadevatābhiḥ |
sārdhaṃ samāḥ saptatimapsarobhirnināya kāmākulito'tha pūrvaḥ
]