`v 1 [
tricatvāriṃśaḥ sargaḥ 43
śrīvasiṣṭha uvāca |
ahaṃtādijagaccedaṃ parijñānādasatyatām |
yāti sānubhavo mohātsatyamevānyathādhiyām
]

`v 2 [
ajñānajvaramuktasya bodhaśītalitātmanaḥ |
etadeva bhaveccihnaṃ yadbhogāmbu na rocate
]

`v 3 [
alamanyaiḥ parijñānairvācyavācakavibhramaiḥ |
anahaṃvedanāmātraṃ nirvāṇaṃ tadvibhāvyatām
]

`v 4 [
parijñātā yathā svapne padārthā rasayanti no |
na ca santi tathaivāsminnahaṃ jagadidaṃbhrame
]

`v 5 [
yathā svabhāvanādyakṣastarau sasvajanaṃ puram |
paśyatyasatyamevaivaṃ jīvaḥ paśyati saṃsṛtim
]

`v 6 [
vibhramātmā yathā yakṣo yakṣalokaśca te mithaḥ |
sadrūpau susthitau mithyā tathāhaṃtvajagadbhramau
]

`v 7 [
anāvaraṇato'raṇye yakṣā vibhramarūpiṇaḥ |
yathā sphuranti bhūtāni tathemāni caturdaśa
]

`v 8 [
bhramamātramahaṃ mithyaiveti buddhvā vibhāvayan |
yakṣo'yakṣatvamāyāti cittaṃ cittattvatāmidam
]

`v 9 [
nirastakalanāśaṅkaṃ tyāgagrahaṇavarjitam |
avisārisamastecchaṃ śāntamāsva yathāsthitam
]

`v 10 [
asattāsaṃbhavaṃn dṛśyaṃ draṣṭrātmakamidaṃ tatam |
athavā naiva draṣṭrātma sadavācyaṃ kimāsyate
]

`v 11 [
vasantarasapūrasya yathā viṭapagulmatā |
svarūpamātrabharitasaṃvidaḥ sargatā tathā
]

`v 12 [
yadidaṃ jagadābhāsaṃ śuddhaṃ cinmātravedanam |
kātraikatā dvitā kā vā nirvāṇamalamāsyatām
]

`v 13 [
bhūyatāṃ cinmayavyomnā pīyatāṃ paramo rasaḥ |
sthīyatāṃ vigatāśaṅkaṃ nirvāṇānandanandane
]

`v 14 [
kimetāsvatiśūnyāsu saṃsārāraṇyabhūmiṣu |
mānavā vātahariṇā bhramatho bhrāntabuddhayaḥ
]

`v 15 [
jagattrayamarīcyambu vipralabdhāndhabuddhayaḥ |
mā dhāvata gatavyagramāśayopahatāśayāḥ
]

`v 16 [
rūpālokamanaskāramṛgatṛṣṇāmbupāyinaḥ |
vyarthamāyāsamāyūṃṣi mā mā kṣapayataiṇakāḥ
]

`v 17 [
jagadgandharvanagaragurugarveṇa naśyatha |
sukharūpāṇi duḥkhāni nāśanāyaiva paśyatha
]

`v 18 [
jagatkeśoṇḍrakabhrāntyai mā mahāmbaramadhyagam |
avalokayatābhrānte svarūpe pariṇamyatām
]

`v 19 [
mānavā vātaloloccapatraprāptāmbubhaṅgura |
mānavāsu na cāsvandhagarbhaśayyāsu supyatām
]

`v 20 [
avirāmamanādyante svabhāve śāntamāsyatām |
draṣṭṭadṛśyadaśādoṣādasvabhāvādvinaśyatām
]

`v 21 [
ajñāvabuddhaḥ saṃsāraḥ sa hi nāsti manāgapi |
avaśiṣṭaṃ ca yatsatyaṃ tasya nāma na vidyate
]

`v 22 [
troṭayitvā tu tṛṣṇāyaḥśṛṅkhalāvalitaṃ balāt |
saṃsārapañjaraṃ tiṣṭha sarvasyordhvaṃ mṛgendravat
]

`v 23 [
ātmātmīyagrahabhrāntiśāntimātrā vimuktatā |
yathā tathā sthitasyāpi sā svasattaiva yoginaḥ
]

`v 24 [
ātmātmīyagrahaḥ ahaṃmametyabhimānastallakṣaṇabhrāntiśāntimātrā
tāvanmātrasvarūpā vimuktatā nānyā kācidasti | sā ca yoginaḥ svātmasattaivetyarthaḥ | 23
|
nirvāṇatā'vāsanatā parā'patāpatājñatā |
saṃsārādhvani khinnasya śāntā viśrāmabhūmayaḥ
]

`v 25 [
tajjñajñāto na mūrkhāṇāṃ mūrkhajñāto na tadvidām |
vidyate jagadartho'sāvavācyārthamayo mithaḥ
]

`v 26 [
viśvatā bhrāntisaṃśāntau saṃsthitaiva na labhyate |
mahārṇavāmbuvalitā putrikeva payomayī
]

`v 27 [
bhrāntiśāntau prabuddhasya vinirvāṇasya viśvatā |
yathāsthitaiva galitā vidyate ca yathāsthitam
]

`v 28 [
nirdagdhatṛṇabhasmālī kvāpi yāti yathānilaiḥ |
satāṃ svabhāvaviśrāmaiḥ kvāpi yāti tathā jagat
]

`v 29 [
jagadbrahmapadārthasya saṃniveśaḥ sa tūttamaḥ |
brahmaśabdārtharūpātmā na jagacchabdakāryabhāk
]

`v 30 [
avijñātasya bālasya padārthā yādṛśā ime |
viduṣastādṛśā eva tiṣṭhataḥ kṣīṇavāsanam
]

`v 31 [
yā niśā sarvabhūtānāṃ tasyāṃ jāgarti saṃyamī |
yasyāṃ jāgrati bhūtāni sā niśā paśyato muneḥ
]

`v 32 [
sthitamevā'virāmī yajjāgradasya suṣuptavat |
citrāvalokita iva jāgratyo'sya rasaiṣaṇāḥ
]

`v 33 [
jātyandharūpānubhavasamaṃ bhuvanavedanam |
bhrāntaprāyamasadrūpaṃ jñasya bhāti na bhāti ca
]

`v 34 [
vimūḍhaduḥkhaṃ trijagadvimūḍhaviṣayaṃ na sat |
svapne svapnatayā jñāte rūpālokamanaḥkriyāḥ
]

`v 35 [
na svandante yathā tadvajjāgratsvapne sphurantu mā |
nirvibhāgaḥ samāśvasto'virodhaṃ paramagataḥ
]

`v 36 [
āśītalāntaḥkaraṇo nirvāṇo jño'vatiṣṭhate |
tajjñasyākṛṣṭamuktasya samaṃ dhyānaṃ vinā sthitiḥ
]

`v 37 [
nimnaṃ vinaiva toyasya na saṃbhavati kācana |
artha eva manaskāro mana evārtharañjanam
]

`v 38 [
eṣa evaiṣa ābhāsaḥ sabāhyābhyantarātmakaḥ |
āsamudraṃ nadīvāhaśatasaṃghamayātmakam
]

`v 39 [
yathaikaśleṣapiṇḍātma vahatyambu taraṅgiṇām |
sabāhyābhyantarākāramarthānarthamayātmakam
]

`v 40 [
mana eva sphuratyarthanirbhāsaṃ vyātataṃ tathā |
nāstyarthamanasordvitvaṃ yathā jalataraṅgayoḥ
]

`v 41 [
ekābhāve dvayoḥ śāntiḥ pavanaspandayoriva |
nūnamekopaśāntyaiva niḥsāre paramārthataḥ
]

`v 42 [
ekatvādarthamanasī samamevāśu śāmyataḥ |
arthaḥ saṃkalparūpātmā nehitavyo vijānatā
]

`v 43 [
manaśca samyagjñānena śāntirevaṃ bhavettayoḥ |
anaṣṭe naśyataścaite jñasyārthamanasī svataḥ
]

`v 44 [
mṛnmaye dviṣati jñānāddviṣadbhāvabhaye yathā |
yathāsaṃsthaṃ sthite eva jñasyārthamanasī sadā
]

`v 45 [
kimapyapūrvamevānyatsaṃpanne bhāvarūpiṇi |
saṃhitārthajagatkālo'pyajño'jñaviṣayo'pyasat
]

`v 46 [
pārśvasuptanarasvapna iva klībāgrayakṣavat |
jñasya sājñaṃ jagannāsti vīrasyeva piśācadhīḥ
]

`v 47 [
jñamajño bhāvayatyajñaṃ ciraṃ vandhyāpi vardhate |
vinaiva jñātaśabdārthamarthabhāvamivāgatam
]

`v 48 [
sthitaṃ bodhamanādyantaṃ svabhāvaṃ sargagaṃ `note[sarvagaṃ iti pāṭhaḥ |]
viduḥ |
manaḥ śabdārtharahitaṃ vibhāgāntavivarjitam
]

`v 49 [
bodhavārimanobuddhitaraṅgamiva nirmalam |
kva saṃbhavata evāntaḥ ke vārthamanasī kila
]

`v 50 [
nirarthikaiva vibhrāntiḥ svabhāvamayamāsyatām |
śuddhabodhasvabhāvasthairākāśamiva śāradaiḥ
]

`v 51 [
jāgratsvapnasuṣuptāntairmanastvaṃ nānubhūyate |
vidhūyānantanānātvamasadbhāvamanāmaye
]

`v 52 [
jñeyaṃ rajjurivāśeṣaṃ svabhāve tiṣṭha cidghane |
jñaptirevāntaraṃ bāhyaṃ cārthatvamadhitiṣṭhati
]

`v 53 [
bījaṃ śākhāphalānīva kvāto'rthamanasī vada |
jñeyāsaṃbhavato jñaptirapyanākhyaṃ padaṃ gatā
]

`v 54 [
śāntāśeṣaviśeṣātmā tena śeṣo'sti satsvabhāḥ |
artha eva manaskāraḥ sa cābhāvātmako bhramaḥ
]

`v 55 [
mana evārthasaṃskāraḥ sa cābhāvātmako bhramaḥ |
sarvātmatvādajasyaitadapyakāraṇakaṃ manaḥ
]

`v 56 [
bhramānubhavato'rthaśca mithyaivāstīva bhāsate |
akāraṇakamevārthanirbhāsaṃ bhāsate manaḥ
]

`v 57 [
vidyudvilasitākāramasthiraṃ taralāyate |
tvaṃ manaskāramātrātmā saṃsṛtau vibhramāyase
]

`v 58 [
svabhāvaikaparijñānānnāsi nāpi bhramāyase |
manasaiva hi saṃsāra ātmabodhena śāmyati
]

`v 59 [
śuktirūpyabhramākāro jano mithyaiva tāmyati |
abhāvabhāvastu paraṃ bodharūpamasaṃsṛtiḥ
]

`v 60 [
nirvāṇāditarā sattā duḥkhāyāhamiti bhramaḥ |
mṛgatṛṣṇāmburūpo'hamasacchūnyasvarūpakaḥ
]

`v 61 [
ityevātmaparijñānādahamityeva śāmyati |
jñātvā jñānamayo bhūtvā sabāhyābhyantarārthatām
]

`v 62 [
gataṃ svamatyajadrūpaṃ taraṅgatvaṃ yathā payaḥ |
mūlaśākhāgraparyantā sattā viṭapino yathā
]

`v 63 [
nirvikāramalaṃ jñapterjñeyāntaikaiva bhāsate |
yathā yojanalakṣābhamekamevāmalaṃ nabhaḥ
]

`v 64 [
ekameva tathā jñānaṃ jñeyāntaṃ bhātyakhaṇḍitam |
śūnyatvādekamamalaṃ yathā sarvagameva kham
]

`v 65 [
tathaikamamalaṃ jñātvā jñānajñeyadaśāsvapi |
ghṛtenātmā ghanībhūya pāṣāṇīkriyate yathā
]

`v 66 [
citā cetyatayātmaiva svacittīkriyate tathā |
deśakālaṃ vinaivātmā bodhābodhena cittatām
]

`v 67 [
abuddho nīyate nyāyairekamevaiṣa susthitaḥ |
atra yadyapyabodhādeḥ saṃbhavo nāsti kaścana |
tathāpi kalpyate'traiva bodhanāya parasparam
]

`v 68 [
mahānubhāvā vigatābhimānā vimūḍhabhāvopaśame galanti |
nirbhrāntayo'nantatayaiva śāntā nityaṃ samādhānamayā bhavanti
]