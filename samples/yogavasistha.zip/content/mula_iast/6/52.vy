`v 1 [
dvipañcāśaḥ sargaḥ 52
śrīrāma uvāca |
bodho jagadivābhāti mune yena krameṇa ha |
taṃ krameṇa kramaṃ brūhi bhūyo bhedanivṛttaye
]

`v 2 [
śrīvasiṣṭha uvāca |
vṛkṣasyeva vimūḍhasya yaddṛṣṭau tatsvacetasi |
yanna dṛṣṭau na taccitte bhavatyalpatarasmṛte
]

`v 3 [
bhavyaḥ paśyati śāstrārthameva pūrvāparānvitam |
na dṛṣṭiviṣayaṃ vastu yatpaśyati karoti tat
]

`v 4 [
bhāvānuṣṭhānaniṣṭhaḥ san śāstrārthaikamanā muniḥ |
bhūtvopadeśaṃ tvamimaṃ śṛṇu śravaṇabhūṣaṇam
]

`v 5 [
iyaṃ dṛśyabharabhrāntirnanvavidyeti cocyate |
vastuto vidyate naiṣā tāpanadyāṃ yathā payaḥ
]

`v 6 [
upadeśyopadeśārthamenāṃ maduparodhataḥ |
satyāmiva kṣaṇaṃ tāvadāśritya śrūyatāmidam
]

`v 7 [
kuta eṣā kathaṃ ceti vikalpānanudāharan |
nedameṣāṃ na cāstīti svayaṃn jñāsyasi bodhataḥ
]

`v 8 [
upadeśaphalasiddhikāle tviyaṃ bhrāntirniḥśeṣaṃ nivartate tato'pi tathetyāśayenāha ##-
yadidaṃ dṛśyate kiṃcijjagatsthāvarajaṃgamam |
sarvaṃ sarvaprakārāḍhyaṃ kalpānte tadvinaśyati
]

`v 9 [
asya bhāgavibhāgātmā nāśo'vaśyamavāritaḥ |
bindunā bindunā bodhe uddhṛtasyāsti hi kṣayaḥ
]

`v 10 [
evaṃ sthite dravyanāśe brahmaṇastanmayatvataḥ |
nānantatvaṃ na cāstitvaṃ na ca vai saṃbhavatyalam
]

`v 11 [
madaśaktiriva jñānamiti nāsmāsu sidhyati |
deho vijñānato'smākaṃ svapnavanna tu tattvataḥ
]

`v 12 [
naśyatyeva ca dṛśyaśrīḥ saiva nānyaiva naiva ca |
itthaṃ bhavetsamucitaṃ kṛtaṃ śāstraṃ ca nānyathā
]

`v 13 [
saivaitītyasamullekhaṃ kathaṃ naṣṭasya saṃbhavaḥ |
tadrūpānyeti yuktaṃ syādanubhūtānugā vayam
]

`v 14 [
saiva vyomatayaivāsīdityasatsaiva sā katham |
tathaiva vyomasaṃsthā cennāśaṃ tarhi na sā gatā
]

`v 15 [
anubhavānārohameva sphuṭayati - saiveti | sā mūrtataiva pralaye vyomatayā
amūrtabhāvenāsīdityasat | yataḥ sā mūrtataivāmūrtatā katham | vyomasaṃsthāpi sā tathā
pūrvāvasthāpannaiva cetpralaye nāśaṃ na gataiveti pralayavādocchedaḥ syādityarthaḥ |
14 |
kāryakāraṇayorekarūpataivaṃ yadā tadā |
kāryakāraṇatābhāvādaikyamevāsmadāgamaḥ
]

`v 16 [
śūnyatvamupalambhatvaṃ yadgataṃ naṣṭameva tat |
anyastarhi bhavennāśaḥ kīdṛśaḥ kila kathyatām
]

`v 17 [
naṣṭaṃ bhūyastadutpannamiti yatpratyayeti kaḥ |
naśyatyavaśyaṃ tenedaṃ punaranyatpravartate
]

`v 18 [
madhye madhye yadutsedhaphalādyavayavaikikā |
ādehaṃ bījasattāsti kāryakāraṇatā kutaḥ
]

`v 19 [
deśakālakriyātmaikaṃ yathādṛṣṭamiha sthitam |
bījamevaikakarmāto na ghaṭaḥ paṭakāryakṛt
]

`v 20 [
sarvadarśanasiddhānte nāsti bhedo na vastuni |
paramārthamaye tena vivādena kimatra naḥ
]

`v 21 [
idaṃ śāntamanādyantaṃn tadrūpatvādvicārataḥ |
vyomābhaṃ bodhatāmātramanubhūtipramāṇataḥ
]

`v 22 [
yathaitannānubhūtaṃ sadyathaitadanubhūyate |
yathaitatsiddhimāpnoti tadidaṃ kathyate kramāt
]

`v 23 [
mahākalpānta unnaṣṭe sarvasmindṛśyamaṇḍale |
āmahādevaparyantaṃn samanobuddhikarmaṇi
]

`v 24 [
vyomanyapi śamaṃ yāte kāle'pyakalitasthitau |
vāyāvapi tvapagate tejasyatyantamasthite
]

`v 25 [
tejasyapi gate dhvaṃsaṃ vāryādau suciraṃ kṣate |
alamantamanuprāpte sarvaśabdārthasaṃcaye
]

`v 26 [
śiṣyate śāntabodhātma sadacchaṃ bādhyavarjitam |
anādinidhanaṃ saumyaṃ kimapyamalamavyayam
]

`v 27 [
avācyamanabhivyaktamatīndriyamanāmakam |
sarvabhūtātmakaṃ śūnyaṃ sadasacca paraṃ padam
]

`v 28 [
tanna vāyurna cākāśaṃ na buddhyādi na śūnyakam |
na kiṃcidapi sarvātma kimapyanyatparaṃ nabhaḥ
]

`v 29 [
tadvidā tatpadasthena tanmuktenānubhūyate |
anyaiḥ kevalamāmnātairāgamaireva varṇyate
]

`v 30 [
na kālo na mano nātmā na sannāsanna deśadik |
na madhyametayornāntaṃ na bodho nāpyabodhitam
]

`v 31 [
kimapyeva tadatyacchaṃ budhyate bodhapāragaiḥ |
śāntasaṃsāravisaraiḥ parāṃ bhūmimupāgataiḥ
]

`v 32 [
tadyadātmavido viduḥityāgamaṃ ca tathodāharati - kimapīti | caturthyādeḥ parām | 31
|
pratiṣiddhā mayaite tu ye'rthāḥ sarvatra te sthitāḥ |
asmadbuddhyā paricchedyāḥ saumyāmbhodherivormayaḥ
]

`v 33 [
mayāpi te'rthāḥ śrutyanusāryanubhavamāśritya muhuḥ pratiṣiddhā ityāha -
pratiṣiddhā iti | sarvatra śrutiṣu pratiṣedhyatayā sthitā ye'rthāsta eva mayā pratiṣiddhāḥ |
32 |
yathāsthitaṃ sthitāḥ sarve bhāvāstatra yathā tathā |
anutkīrṇā mahāstambhe vividhāḥ śālabhañjikāḥ
]

`v 34 [
evaṃ tatra sthitāḥ sarve bhāvā evaṃ ca na sthitāḥ |
asarvātmaiva sarvātma tadeva na tadeva ca
]

`v 35 [
padaṃ yathaitatsarvātma sarvārthaparivarjitam |
yathā tatra ca paśyanti tatraikapariṇāminaḥ
]

`v 36 [
sarvaṃ sarvātmakaṃ caiva sarvārtharahitaṃ padam |
sarvārthaparipūrṇaṃ ca tadādyaṃ paridṛśyate
]

`v 37 [
tavaitāvanmahābuddhe sarvārthopaśamātmakam |
na samyagdānamutpannaṃ saṃśayo'tra nidarśanam
]

`v 38 [
yaḥ prabuddho nirābhāsaṃ paramābhāsamāgataḥ |
svacchāntaḥkaraṇaḥ śāntastaṃ svabhāvaṃ sa paśyati
]

`v 39 [
ayaṃn tvamahamityāditrikālagajagadbhramaḥ |
tatrāsti hemapiṇḍāntariva rūpakajālakam
]

`v 40 [
hemapiṇḍādyathā bhāṇḍajālaṃ nānopalabhyate |
tathā na labhyate bhinnaṃ paramārthaghanājjagat
]

`v 41 [
sarvadaiva hi bhinnātmā svāṅgabhūtopalambhadṛk |
sa jagaddvaitamevedaṃ hemevāṅgadarūpakam
]

`v 42 [
riktaṃ deśādiśabdārthairdeśakālakriyātmakam |
yathāsthitamidaṃ tatra sarvamasti na vāsti ca
]

`v 43 [
yathormyādi same toye citraṃ citrakṛdīhate |
bhāṇḍavṛndaṃ mṛdaḥ piṇḍe tathedaṃ brahmaṇi sthitam
]

`v 44 [
tathaitadatra no bhinnaṃ nābhinnaṃ nāsti cāsti ca |
nityaṃ tanmayamevācchaṃ śānte śāntamidaṃ tathā
]

`v 45 [
anikhātaiva bhātīyaṃ trijagacchālabhañjikā |
svarasasyeva dṛśyatvamitā brahmaṇi dāruṇi
]

`v 46 [
nikhātā dṛśyatāṃ yānti stambhasthāḥ śālabhañjikāḥ |
asminnakṣobhya evāntastaraṅgāḥ sṛṣṭidṛṣṭayaḥ
]

`v 47 [
sarasyatirase bhānti cidghanāmṛtavṛṣṭayaḥ |
avibhāge vibhāgasthā akṣobhe kṣubhitā iva |
avibhātā vibhāntīva cidghane sṛṣṭidṛṣṭayaḥ
]

`v 48 [
paramāṇau paramāṇāvatra saṃsāramaṇḍalam |
vibhāti bhāsurārambhaṃ na vibhāti ca kiṃcana
]

`v 49 [
ākāśakālapavanādipadārthajātamasyāṅgamaṅgarahitasya tadapyanaṅgam |
sarvātmakaṃ sakalabhāvavikāraśūnyamapyetadāhurajaraṃ paramārthatattvam | 49
|
varṇitaṃ kūṭasthasya jagadbhāvaṃ saṃgṛhyopasaṃharati - ākāśeti |
aṅgarahitasya niravayavasyāsya yadākāśakālapavanādipadārthajātarūpamaṅgaṃ
varṇitaṃ tadapi mithyātvādadhiṣṭhānamātrapariśeṣāccānaṅgaṃ niravayavameva |
evaṃ sakalabhāvavikāraśūnyamapyetadajaramātmatattvaṃ sarvādhyāropeṇa
sarvātmakaṃ śrutaya āhurityarthaḥ
]