`v 1 [
catuḥsaptatyadhikaśatatamaḥ sargaḥ 174
śrīvasiṣṭha uvāca |
sargādau svapnasaṃvittyā cidevābhāti kevalā |
jagadityavabhāseva brahmaivāto jagattrayam
]

`v 2 [
sargāstaraṅgā brahmābdhesteṣu saṃvedanaṃ dravaḥ |
sargāntaraṃ sukhādyātma dvaitaikyādītaratkutaḥ
]

`v 3 [
yathā svapnasuṣuptātma nidrārūpakameva kham |
dṛśyādṛśyāṃśamekātmarūpaṃ cinnabhasastathā
]

`v 4 [
jāgrati svapnanagaraṃ yādṛktādṛgidaṃ jagat |
parijñātaṃ bhavedatra kathamāsthā vivekinaḥ
]

`v 5 [
sargādau sargasaṃvitteryathābhūtārthavedanāt |
jāgrati svāpnanagaraṃ yādṛśaṃ tādṛśaṃ jagat
]

`v 6 [
jāgrati svapnanagaravāsanā vididhā yathā |
satyā api na satyāstā jāgratyo vāsanāstathā
]

`v 7 [
anyathopaprapadyeha kalpyate yadi kāraṇam |
tatkiṃ nedīyasī nātra bhrāntatā kalpyate tathā
]

`v 8 [
nanu jagato bhrāntimātratve tattvabodhena tanmūlājñānocchedādbādhaḥ syāt |
pradhānaparamāṇvādikāraṇāntarairanyathopapattyā bhrāntitvākalpane tu na
bādhaprasaktiriti tato duḥkhaṃ syādevetyāśaṅkyāha - anyatheti | upaprapadya
upapādya | svāpne jagati prasiddhataratvāllāghavāt vācārambhaṇaṃ vikāro nāmadheyam
tasya tatra āvasathāstrayaḥ svapnāḥ māyāṃ tu prakṛtiṃ vindyāt bhūyaścānte
viśvamāyānivṛttiḥ ityādiśrutibodhitatvācca kalpanāntarebhyo nedīyasī
śīghropasthitikatvena saṃnihitatarā bhrāntimātrataiva jagataḥ kiṃ na kalpyata ityarthaḥ | 7
|
svānubhūyata eveyaṃ bhrāntiḥ svapnajagatsviva |
kāraṇaṃ tvanumāsādhyaṃ kvānumā'nubhavādhikā
]

`v 9 [
dṛṣṭamapyasti yanneśe na cātmani vicāritam |
anyathānupapattyāntarbhrāntyātma svapnaśailavat
]

`v 10 [
nirvikalpaṃ paraṃ jāḍyaṃ savikalpaṃ tu saṃsṛtiḥ |
dhyānaṃ tena samādhānaṃ na saṃbhavati kiṃcana
]

`v 11 [
sacetyaṃ saṃsṛtirdhyānamacetyaṃ tūpalasthiti |
mokṣo nopalavadbhānaṃ na vikalpātmakaṃ tataḥ
]

`v 12 [
na ca nāmopalābhena nirvikalpasamādhinā |
anyadāsādyate kiṃcillabhyate kiṃ svanidrayā
]

`v 13 [
tasmātsamyakparijñānādbhrāntimātraṃ vivekinaḥ |
sargātyantāsaṃbhavato yo jīvanmuktatodayaḥ
]

`v 14 [
nirvikalpaṃ samādhānaṃ tadanantamihocyate |
yathāsthitamavikṣubdhamāsanaṃ sarvabhāsanam
]

`v 15 [
tadanantasuṣuptākhyaṃ tatturīyamiti smṛtam |
tannirvāṇamiti proktaṃ tanmokṣa iti śabditam
]

`v 16 [
samyagbodhaikaghanatā yāsau dhyānamiti smṛtam |
dṛśyātyantāsaṃbhavātma bodhamāhuḥ paraṃ padam
]

`v 17 [
tacca nopalavajjāḍyaṃ na suṣuptopamaṃ bhavet |
na nirvikalpaṃ na ca vā savikalpaṃ na vā'pyasat
]

`v 18 [
dṛśyātyantāsaṃbhavātma tadevādyaṃ `note[tadevācchamiti pāṭhaḥ |] hi
vedanam |
tatsarvaṃ tanna kiṃcicca tadvadevāṅga vetti tat
]

`v 19 [
samyakprabodhānnirvāṇaṃ paraṃ tatsamudāhṛtam |
yathāsthitamidaṃ viśvaṃ tatrālaṃ pralayaṃ gatam
]

`v 20 [
na tatra nānā'nānā na na ca kiṃcinna kiṃcana |
samastasadasadbhāvasīmāntaḥ sa udāhṛtaḥ
]

`v 21 [
atyantāsaṃbhavaṃ dṛśyaṃ yadvai nirvāṇamāsitam |
śuddhabodhodayaṃ śāntaṃ tadviddhi paramaṃ padam
]

`v 22 [
sa ca saṃprāpyate śuddho bodho dhyānamanuttamam |
śāstrātpadapadārthajñabodhinotpannabuddhinā `note[bodhe na iti
pāṭhaṣṭīkānukūlaḥ syāt |]
]

`v 23 [
mokṣopāyābhidhaṃ śāstramidaṃ vācayatāniśam |
buddhyupāyena śuddhena puṃsā nānyena kenacit
]

`v 24 [
na tīrthena na dānena na snānena na vidyayā |
na dhyānena na yogena na tapobhirna cādhvaraiḥ
]

`v 25 [
bhrāntimātraṃ kiledaṃ sadasatsadiva lakṣyate |
vyomaiva jagadākāraṃ svapno'nidre cidambare
]

`v 26 [
na śāmyati tapastīrthairbhrāntirnāma kadācana |
tapastīrthādinā svargāḥ prāpyante na tu muktatā
]

`v 27 [
bhrāṃtiḥ śāmyati śāstrārthātsamyagbuddhyāvalokitāt |
ātmajñānamayānmokṣopāyādeveha nānyataḥ
]

`v 28 [
ālokakāriṇātyarthaṃ śāstrārthenaiva śāmyati |
amalenākhilā bhrāntiḥ prakāśenaiva tāmasī
]

`v 29 [
sargasaṃhārasaṃsthānāṃ bhāso bhānti cidambare |
spandanānīva maruti dravatvānīva vāriṇi
]

`v 30 [
dravyasya hṛdyev camatkṛtirnijā nabhasvataḥ spanda ivāniśaṃ yathā |
yathā sthitā sṛṣṭiriyaṃ tathāstitā layaṃ nabhasyantarananyarūpiṇī
]