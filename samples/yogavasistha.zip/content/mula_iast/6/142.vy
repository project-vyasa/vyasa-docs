`v 1 [
dvicatvāriṃśadadhikaśatamaḥ sargaḥ 142
muniruvāca |
vartamāne tadā tasminkaṣṭe saṃbhrāntasaṃbhrame |
uhyamāno'hamatyantaṃ khedamabhyāgato'bhavam
]

`v 2 [
acintayaṃ tatsvapno'yaṃ parasya hṛdaye mama |
tadataḥ parinirvāmi duḥkhaṃ paśyāmi kiṃ mudhā
]

`v 3 [
vyādha uvāca |
kiṃsvitsyātsvapna ityeva kila saṃdehaśāntaye |
praviṣṭo hṛdayaṃ tasya kiṃ taṃ nirṇītavānasi
]

`v 4 [
kimetadbhavatāṃ dṛṣṭaṃ hṛdaye kva mahārṇavaḥ |
jaṭhare kalpavātaḥ kiṃ hṛdi kalpānalaḥ katham
]

`v 5 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
kathaṃ hṛdi jagannāma kathayeti yathāsthitam
]

`v 6 [
muniruvāca |
akāraṇatvātsargādāvevānutpādataḥ sphuṭāt |
ajñātau sargaśabdārthāveva na sto manāgapi
]

`v 7 [
taccaitau sarvaśabdārthau tvajñātau paramātmani |
yatastatpadamajñānajñānātmakamanāmayam
]

`v 8 [
kathaṃ tarhi loke sargaśabdārthau prasiddhau tatrāha - taccaitāviti | etau
sargaśabdārthau paramātmani tattvato jñātāveva prasiddhau | tadajñātaṃ
paramātmarūpaṃ hyetau | nanvajñātau cedaprasiddhāveveti syānna tu prasiddhāviti tatrāha
- yata iti | bhavedetadevaṃ yadyajñānamātraṃ jagatsyāt | yatastu
tadajñātamātmapadaṃ śabalatvādajñānajñānātmakam |
tatrājñānāṃśamādāyājñātau jñānāṃśamādāya prasiddhau ca suvacāvityarthaḥ | 7
|
ataḥ subhaga siddhānte tvatpakṣe bodhamāgate |
maurkhyaśāntāvanādyante pade paramapāvane
]

`v 9 [
vacmīdaṃ mūḍhasaṃvittau yadidaṃ tanna vedmyaham |
vastvavastujamābhātaṃ bodhamātramidaṃ tatam
]

`v 10 [
kva śarīraṃ kva hṛdayaṃ kva svapnaḥ kva jalādi ca |
kva bodho bodhavicchittiḥ kva janmamaraṇādi ca
]

`v 11 [
svacchaṃ cinmātramastīha tannāma yadapekṣayā |
sthūlameva khamapyadriraṇūnāṃ nikaṭe yathā
]

`v 12 [
svabhāvātsa cidākāśaḥ kiṃciccetati cintayā `note[cintaya iti pāṭhaḥ |] |
khameva vapurākāśaṃ yattadvetti jagattayā
]

`v 13 [
yathā svapne puratayā cidevābhāti kevalā |
na tu kiṃcitpurādyevaṃ jagaccinmātrameva khe
]

`v 14 [
idaṃ śāntamanābhātamananyannaitadātmani |
citi dṛśau tamasi khe cakrakādīva bhāti te
]

`v 15 [
vyādhadṛśā tarhi kathaṃ bhāti tadāha - citīti | citi cidrūpāyāṃ dṛśau cakṣuṣi
tamasi ajñānalakṣaṇatimiraroge sati khe cakrakādi yathā bhāsate tadvatte bhātītyarthaḥ |
14 |
asmākaṃ tu na cābhānaṃ na cāsanna ca sanna kham |
anākāramanādyantamekaṃ cidvyoma kevalam
]

`v 16 [
bhātyakāraṇakaṃ svapne śuddho draṣṭaiva kevalaḥ |
tenātra kāraṇābhāvo na draṣṭāsti na darśanam
]

`v 17 [
śuddhaṃ kimapi tadbhāti svānubhūtamapi sphuṭam |
yadavācyamanādyantamekaṃ dvaitaikyavarjitam
]

`v 18 [
ekaḥ kālo yathā kalpaḥ prakāśaścobhayātmakaḥ |
bījaṃ vā phalapuṣpāntaṃ brahma sarvātmakaṃ tathā
]

`v 19 [
yadanyasya mahatkuḍyaṃ tadanyasyāmalaṃ nabhaḥ |
dṛṣṭametatsthirasvapnasaṃkalpabhramabhūmiṣu
]

`v 20 [
svacchaṃ tadā tadātmaikaṃ bhāti cinmātrakhaṃ yathā |
svapne jāgṛtivattadvajjāgratsvapne'p nānyathā
]

`v 21 [
adṛśye pavane yadvadadṛśyaṃ saurabhaṃ sthitam |
cinmātre'pratighe tadvajjagadapratighaṃ sthitam
]

`v 22 [
samastamananatyāge yo'si so'si nirāmayaḥ |
bahirantaranantātmā susthito'pi nirantaram
]

`v 23 [
vyādha uvāca |
bhagavanprāktanaṃ karma keṣāmiha hi vidyate |
keṣāṃ na vidyate tadvadvināpi bhavataḥ katham
]

`v 24 [
muniruvāca |
sargādiṣu svayaṃ bhānti brahmādyā ye svayaṃbhuvaḥ |
vijñaptimātradehāste na teṣāṃ janmakarmaṇī
]

`v 25 [
teṣāmasti na saṃsāro na dvaitaṃ na ca kalpanāḥ |
viśuddhajñānadehāste sarvātmānaḥ sadā sthitāḥ
]

`v 26 [
sargādau prāktanaṃ karma vidyate neha kasyacit |
sargādau sargarūpeṇa brahmaivetthaṃ vijṛmbhate
]

`v 27 [
yathā brahmādayo bhānti sargādau brahmarūpiṇaḥ |
bhānti jīvāstathānye'pi śataśo'tha sahasraśaḥ
]

`v 28 [
kiṃtu ye brahmaṇo'nyatvaṃ budhyante sāttvikodbhavāḥ |
abodhā ye tvacidākhyaṃ buddhvā dvaitamidaṃ svayam
]

`v 29 [
keṣāṃ dṛśā tarhi karma vidyate tānāha - kiṃtviti | ye tu abodhā ajñānāvṛtāḥ
santaḥ svasya brahmatvaṃ na budhyante kiṃtu nāhaṃ brahmeti brahmaṇo'nyatvaṃ
budhyante
asāttvikātkevalasattvapariṇāmavilakṣaṇarajastamomiśrasattvapariṇāmādudbhavo yeṣāṃ
tathāvidhā jīvāste acidākhyamidaṃ dvaitaṃ satyamiti buddhvā tadvāsanāvāsitā eva
pāṅmṛtāsteṣāṃ karmabhiḥ sahitaṃ janma uttarakālaṃ dṛśyata iti pareṇānvayaḥ |
28 |
teṣāmuttarakālaṃ tatkarmabhirjanma dṛśyate |
svayameva tathā bhūtaistairavastutvamāśritam
]

`v 30 [
yaistu na brahmaṇo'nyatvaṃ buddhaṃ bodhamahātmani |
niravadyāsta ete'tra brahmaviṣṇuharādayaḥ
]

`v 31 [
sarvātma saṃvido'cchatvaṃ brahmātmanyeva saṃsthitam |
tatkvacijjīvavadbhānaṃ svayamātmani paśyati
]

`v 32 [
yatra vetti tu jīvatvaṃ tatrāvidyeti tiṣṭhati |
tatra saṃsṛtināmnātmā dhatte rūpaṃ tathāsthitam
]

`v 33 [
svayameva hi kālena buddhvā svaṃ rūpamātmanaḥ |
svayameva svarūpasthaṃ brahmaiva bhavati svayam
]

`v 34 [
yathā dravatvādambvantareti cāvartatāmiva |
brahma cittvāttathaitīva sargatāmasya sargakam
]

`v 35 [
brahmabhānamayaṃ sargo na svapno na ca jāgaraḥ |
kasya kānyatra karmāṇi kīdṛśāni kiyanti vā
]

`v 36 [
vastutaḥ karma nāstyeva nāvidyāsti na sargadhīḥ |
svasaṃvedanataḥ sarvamasadeva pravartate
]

`v 37 [
brahmaiva sargo bhūtātmā karma janmeti kalpanāḥ |
svayaṃ kurvadidaṃ bhāti vibhutvātkalpitārthabhāk
]

`v 38 [
na saṃbhavati jīvasya sargādau karma kasyacit |
paścātsvakarma nirmāya buṅkte kalpanayā sa cit
]

`v 39 [
jalāvartasya ko dehaḥ kāni karmāṇi cocyatām |
yathāmbumātramāvarto brahmamātraṃ tathā jagat
]

`v 40 [
yathā svapneṣu dṛṣṭānāṃ na prākkarma nṛṇāṃ bhavet |
ādisargeṣu jīvānāṃ tathā cinmātrarūpiṇām
]

`v 41 [
sarge sargatayā rūḍhe bhavetprākkarmakalpanā |
paścājjīvā bhramantīme karmapāśavaśīkṛtāḥ
]

`v 42 [
sarga eva na sargo'yaṃ brahmetthaṃ kila tiṣṭhati |
yatra tatra kva karmāṇi kāni vā kasya tāni vā
]

`v 43 [
aparijñāmamātraṃ yatsvayaṃ vai paramātmanaḥ |
tadetatkarma bandhāya tattajjñasyopaśāmyati
]

`v 44 [
yāvadyāvatparijñānaṃ paṇḍitasya pravartate |
tāvattāvattadaivāsya karma śāmyati bandhanam
]

`v 45 [
yannāma kila nāstyeva tacchāntau kā kadarthanā |
paramārthādṛte bandhaḥ kiṃcinnāma na vidyate
]

`v 46 [
nanu jñānamātrātkathaṃ vastunāśa ityāśaṅkya vastutvameva karmaṇo nāstītyāha ##-
tāvanmāyā bhavabhayakarī paṇḍitatvaṃ na yāvattatpāṇḍityaṃ patasi na punaryena
saṃsāracakre |
yatnaṃ kuryādaviratamataḥ paṇḍitatve'malātmajñānodāre bhayamitarathā naiva
vaḥ śāntimeti
]