`v 1 [
ṣaṭpañcāśaḥ sargaḥ 56
śrīvasiṣṭha uvāca |
sarvatra sarvathā sarvaṃ sarvadā vyomni cinmaye |
sādhu saṃbhavati svacchaṃ śūnyatvaṃ kha ivākhile
]

`v 2 [
yatra cittatra sargaśrīravyomni vyomni vāsti cit |
cinmayatvātpadārthānāṃ sarveṣāṃ nāstyacitkvacit
]

`v 3 [
padārthajātaṃ śailādi yathā svapne purādi ca |
cidevaikaṃ paraṃ vyoma tathā jāgratpadārthabhūḥ
]

`v 4 [
pāṣāṇākhyānamatredaṃ śṛṇu rāma rasāyanam |
pūrva mayaiva yaddṛṣṭaṃ citra prakṛtameva ca
]

`v 5 [
ahaṃ viditavedyatvātkadācitpūrṇamānasaḥ |
tyaktumicchurimaṃ lokavyavahāraṃ ghanabhramam
]

`v 6 [
dhyānaikatānatāmetya śanairviśrāntaye ciram |
tyaktājavaṃ javībhāva ekāntārthī śamaṃ vrajan
]

`v 7 [
idaṃ cintitavānasmi kasmiṃścidamarālaye |
saṃsthito vividhāḥ paśyanbhaṅgurā jāgatīrgatīḥ
]

`v 8 [
virasā khalviyaṃ lokasthitirāpātasundarī |
na jātu sukhadā manye kasyacitkenacitkvacit
]

`v 9 [
udvegaṃ janayatyantastīvrasaṃvegakhedataḥ |
imā dṛśyadṛśo draṣṭuriṣṭāniṣṭaphalapradāḥ
]

`v 10 [
kimidaṃ dṛśyate kiṃ vā prekṣate ko'hameva vā |
sarva śāntamajaṃ vyoma cinmātrātmani riṅgakam
]

`v 11 [
tasmātsamastasiddhendradevadaityādidurgamam |
supradeśamito gatvā saṃgopyātmānamātmanā
]

`v 12 [
adṛśyaḥ sarvabhūtānāṃ nirvikalpasamādhigaḥ |
same svacche pade śānte āse vigatavedanam
]

`v 13 [
tasmātko nu pradeśaḥ syādatyantaṃ śūnyatāṃ gataḥ |
yatraitā nānubhūyante pañca bāhyārthavedanāḥ
]

`v 14 [
śabdakānanavāryabdabhūtaughābhisamākulāḥ |
kṣobhayantyatha saṃkṣubdhāstasmānme girayo'rayaḥ
]

`v 15 [
nānāvidhā nagendrāṇāmantarāvalitā janaiḥ |
deśā viṣamayā eva niḥśeṣā viṣayāhibhiḥ
]

`v 16 [
janairjalacarairvyāptāḥ sāgarā nīrakukṣayaḥ |
vividhārambhasaṃkṣubdhairnagarāṇīva nāgaraiḥ
]

`v 17 [
taṭānyadryamburāśīnāṃ lokapālapurāṇi ca |
bhūtākulāni śṛṅgāṇi pātālakuharāṇi ca
]

`v 18 [
gāyantyanilabhāṃkārairnṛtyanti latikāḥ karaiḥ |
puṣpairhasantyagendrāṇāṃ guhā gahanakoṭarāḥ
]

`v 19 [
maunimīnamunisparśakampinālacalāmbujāḥ |
sarasyo virasā eva vāryāvartavirāvitāḥ
]

`v 20 [
pavanasparśasaṃkṣubdhatṛṇapāṃsupatākinī |
raṭatyanilabhāṃkārairnirjharorvyapyasaṃyatā
]

`v 21 [
tasmādākāśamāśūnyaṃ kasmiṃściddūrakoṇake |
atra tiṣṭhāmyavaṣṭabhya yogayuktimaninditām
]

`v 22 [
pariśeṣādākāśa eva sarvavikṣepahetuvarjanāccharaṇamityāśayenāha - tasmāditi |
21 |
kasmiṃścidekakoṇe'tra kṛtvā kalpanayā kuṭīm |
vajrodaradṛḍhaṃ tasyāmantastiṣṭhāmyavādanam
]

`v 23 [
iti saṃcintya yāto'hamākāśamasi nirmalam |
yāvattadapi paśyāmi sakalaṃ vitatāntaram
]

`v 24 [
kvacidbhramatsiddhagaṇaṃ kvacidudgarjadambudam |
kvacidvidyādharādhāraṃ yakṣotkṣiptakṣayaṃ kvacit
]

`v 25 [
kvacidbhramatpuravaraṃ prārabdhasamaraṃ kvacit |
kvaciddravajjaladharaṃ kvacidudvṛttayogini
]

`v 26 [
kvaciddaityapuroḍḍīnasagandharvapuraṃ kvacit |
kvacidbhramadgrahagaṇaṃ tārakākulitaṃ kvacit
]

`v 27 [
kvacitkhe khagasaṃghṛṣṭaṃ kvacitkruddhamahānilam |
kvacidutpātavalitaṃ kvacinmaṇḍalamaṇḍitam
]

`v 28 [
kvacidapūrvabhūtaughaṃ nāgarāvalitaṃ kvacit |
kvacidarkarathākrāntaṃ kvacidanyarathoddhuram
]

`v 29 [
kvacidādityadāhāntaṃ śaśiśaityānvitaṃ kvacit |
kvacitkṣudrajanāsahyaṃ kvacidagnyauṣṇyadurgamam
]

`v 30 [
kvaciduttālavetālaṃ garuḍoḍḍāmaraṃ kvacit |
kvacitsapralayāmbhodaṃ kvacitsapralayānilam
]

`v 31 [
tato bhūtagaṇāṃstyaktvā dūrāddūrataraṃ gataḥ |
prāptavānahamekāntaṃ śūnyamatyantavistṛtam
]

`v 32 [
atyantamandapavanaṃ svapne'pyaprāpyabhūtakam |
maṅgalotpātarahitamagamyaṃ viddhi saṃsṛteḥ
]

`v 33 [
kalpitātha mayā tatra kuṭī prakaṭakoṭarā |
nīrandhrakuḍyanibiḍā padmakuḍmalasundarī
]

`v 34 [
ghuṇakṣuṇṇāṅgapūrṇendubimbodaramanoharā |
kahlārakundamandārapuṣpaśrīkośaśobhitā
]

`v 35 [
samastabhūtāgamyatvaṃ tatra saṃkalpya cetasā |
agamye sarvabhūtānāmahamāsaṃ tadā tataḥ
]

`v 36 [
baddhapadmāsanaḥ śāntamanāḥ paramamaunavān |
saṃvatsaraśatāntena nirṇīyotthānamātmanaḥ
]

`v 37 [
nirvikalpasamādhistho nidrāmudrāmivāgataḥ |
samaḥ saumyanabhaḥsvasthaḥ samutkīrṇa ivāmbarāt
]

`v 38 [
ciraṃ yadanusaṃdhatte cetaḥ paśyati tatkṣaṇāt |
cireṇa cāśāpavanavyaktivadvitataṃ yadā
]

`v 39 [
tadā varṣaśatenātra bodhabījaṃ vṛtāntaram |
āsīnme hṛdayakṣetre kālamekaṃ vikāsataḥ
]

`v 40 [
saṃprabuddho'bhavanme'tha jīvaḥ saṃbuddhavedanaḥ |
śiśirakṣīṇagātrasya madhāviva rasastaroḥ
]

`v 41 [
tacchataṃ tatra varṣāṇāṃ nimeṣamiva me gatam |
bahvyo'pi kālagatayo bhavantyekadhiyo manāk
]

`v 42 [
vikāsamāgato bāhyaṃ gato buddhīndriyakramaḥ |
vāsantaḥ puṣparūpeṇa madasyeva raso mama
]

`v 43 [
māṃ prāṇapūritamupāgatasaṃvidaṃśamabhyāgataṃ tvahamiti prasṛtaḥ
piśācaḥ |
icchāṅganāvivalito'tha kuto'pi sadyaḥ pronnāmasannamanavāyurivogravṛkṣam |
43 |
tataḥ kimāsīttadāha - māmiti | ayaṃ prāṇaiḥ pañcavṛttivāyubhirindriyaiśca
pūritaṃ tadvaśādeva upāgata āvirbhūto jīvasaṃvidaṃśo yasya tathāvidhaṃ dehaṃ
sadyaḥ abhyāgataṃ tu māmabhilakṣya icchālakṣaṇayā aṅganayā piśācyā vivalitaḥ
pariṣvaktaḥ ahamiti prasiddho'haṃkārapiśācaḥ kuto'pyatarkitātpradeśātprasṛtaḥ
prāptaḥ | yathā ugraṃ śālmalyādivṛkṣaṃ pronnāmānāṃ tarūṇāṃ sannamano
vāyuścaṇḍapavanaḥ prasarati tadvadityarthaḥ
]