`v 1 [
ekonāṣaṣṭyadhikaśatatamaḥ sargaḥ 159
agniruvāca |
vipaścicchreṣṭha bho sādho tvaṃ gacchābhimatāṃ diśam |
sthiraṃ bhūmaṇḍalaṃ bhūyaḥ prakṛtavyavahāravat
]

`v 2 [
yajñaṃ yaṣṭuṃ prajaughasya śakraḥ śatatamaṃ divi |
tatrāhūto'smi mantreṇa gacchāmi gatikovida
]

`v 3 [
bhāsa uvāca |
ityuktvā bhagavānagnistatraivāntaradhīyata |
gagane nirmale yāti analo vaidyuto yathā
]

`v 4 [
tathāhamapi cittena prāktanāṃśca svayaṃ vahan |
punaḥ svakarma nirṇetuṃ bhramanvyomani saṃsthitaḥ
]

`v 5 [
bhūyo'pi dṛṣṭavānasmi jagantyagaṇitāni khe |
nānācāravicārāṇi nānāsaṃsthānavanti ca
]

`v 6 [
kvacicchatramayāṅgāni ekībhūtāni bhūpate |
bhānti cetanti copanti hṛdayāni haranti ca
]

`v 7 [
kvacinmṛnmayadehāni sarvabhūtāni rāghava |
bhānti cetanti copanti parvatapratimāni ca
]

`v 8 [
kvaciddārumayāṅgāni bhānti bhūtāni kutracit |
kvacitpāṣāṇadehāni santi bhūtāni bhūriśaḥ
]

`v 9 [
kvacidājīvamekatra sthitānyupaladehavat |
vāṅmātravyavahārāṇi bhūtānyālokitāni khe
]

`v 10 [
ityahaṃ suciraṃ kālaṃ paśyannaśyanmanastayā |
avidyāntamapaśyaṃśca tatrodvigno'bhavaṃ dṛśām
]

`v 11 [
tapaḥ kartuṃ samudyuktaḥ kasmiṃścinmokṣasiddhaye |
prāhendro mama caivedaṃ mṛgayonyantaraṃ hi khe
]

`v 12 [
pravṛttaḥ svargasaṃmohe pūrvābhyāsavaśīkṛtaḥ |
mandārakānane tatra bhramato vai mamāmbare
]

`v 13 [
tenetyukte mayā proktaṃ deva khinno'smi saṃsṛteḥ |
mucyeyaṃ śīghramityuktaṃ śrutvovāca tato mama
]

`v 14 [
viśuddhātmā tvarūpo'hamiti caiva hutāśanāt |
varaṃ gṛhāṇetyukte sa tato'nyaṃ yācito mayā
]

`v 15 [
indra uvāca |
taveyaṃ mṛgayonyantaściraṃ saṃsarate citiḥ |
avaśyaṃ bhavitavyo'rtha iti dṛṣṭo mayā tava
]

`v 16 [
mṛgo bhūtvā mahāpuṇyāṃ tāṃ sabhāṃ samavāptavān |
yasyāṃ tadahataṃ jñānaṃ maduktaṃ bodhameṣyati
]

`v 17 [
tadevaṃ tatra hariṇo bhavārtastvaṃ bhavāvanau |
ātmodantamidaṃ vandhyaṃ sakalaṃ saṃsmariṣyasi
]

`v 18 [
svapnabhramamivāśeṣasaṃkalparacitopamam |
pralokānubhūtārthakathāyātārthasaṃnibham
]

`v 19 [
yadā tu mṛgatonmuktaḥ puruṣastvaṃ bhaviṣyasi |
jñānāgnidagdhadehānte tadā hṛtsthaṃ sphuriṣyati
]

`v 20 [
tena tāṃ tvamavidyākhyāṃ bhrāntiṃ tyaktvā ciraṃ sthitām |
bhaviṣyasi vinirvāṇo gataspanda ivānilaḥ
]

`v 21 [
ityukte tena devena tadaiva pratibhodabhūt |
mamāyaṃ hariṇo'smīti vane'sminniti niścitā
]

`v 22 [
tataḥ prabhṛti saṃpannastatraivāntarakoṇake |
hariṇo'haṃ girivare tṛṇadūrvāṅkurāśanaḥ
]

`v 23 [
tataḥ sīmāntasāmantamāgataṃ mṛgayārthinam |
dṛṣṭvāhamekadā bhītaḥ palāyanaparo'bhavam
]

`v 24 [
tatastena samākramya gṛhaṃ nītvā dinatrayam |
saṃsthāpya tava līlārthamihānīto raghūdvaha
]

`v 25 [
eṣa te kathitaḥ sarva ātmodanto mayānagha |
saṃsāramāyāpratimo nānāścaryarasānvitaḥ
]

`v 26 [
avidyaivamananteyaṃ śākhāprasaraśālinī |
ātmajñānādṛte naiva kenacinnāma śāmyati
]

`v 27 [
śrīvālmīkiruvāca |
yadā vipaścidityuktvā tatra tūṣṇīṃ sthitaḥ kṣaṇāt |
samavocattadā rāmastamanindyamatistvidam
]

`v 28 [
śrīrāma uvāca |
evaṃ paśyatyasaṃkalpo yo'nyasaṃkalpa ātmani |
mṛgaśceddṛśyatāṃ yātaḥ kathaṃ sarge vada prabho
]

`v 29 [
vipaściduvāca |
mahāśavaṃ yatpatitaṃ yasmiñjagati bhūtale |
tāṃ bhuvaṃ pūrvamindreṇa yajñagarveṇa gacchatā
]

`v 30 [
pādenābhihato vyomni durvāsā dhyānasaṃsthitaḥ |
gatāsurityavijñānāttenāsau kupito'śapat
]

`v 31 [
śakra śakrāvanitalaṃ brahmāṇḍapratimaṃ śavam |
acireṇa mahāghoraṃ tava cūrṇīkariṣyati
]

`v 32 [
māmimaṃ śavabuddhyā tvaṃ yadatikrāntavānataḥ |
śāpena mamatāṃ pṛthvīṃ śīghramāsādayiṣyasi
]

`v 33 [
mṛgārthaṃ tena muninā tathā deveti sadyathā |
tattayā kathayā''yātaṃ sadaiva viṣayaṃ dṛśām
]

`v 34 [
vastutastu na caikaṃ sanna dvitīyaṃ na cāpyasat |
sā tathā pratibhodeti kiṃ satkimathavāpyasat
]

`v 35 [
anyacca rāghave māṃ tāṃ yuktiṃ tvamaparāṃ śṛṇu |
etasminnayasaṃdarbhe susphuṭapratipattaye
]

`v 36 [
yasminsarvaṃ yataḥ sarvaṃ yatsarvaṃ sarvataśca yat |
brahma tasminmahābhāga kiṃ na saṃbhavatīha hi
]

`v 37 [
saṃkalpajātaṃ nānyonyaṃ milatītyupapadyate |
saṃkalpajātamanyonyaṃ milatītyupapadyate
]

`v 38 [
saṃkalpajātamanyonyaṃ milatītyavagamyate |
sarvātmani hi yatraiva cchāyā tatraiva cātapaḥ
]

`v 39 [
āvagamyate pratyakṣaṃ mṛgadarśanādau | upapattiścātrāstītyāha - sarvātmanīti |
38 |
na saṃbhavati cettattatkathaṃ sarvātmatāmiyāt |
kasmātsaṃkalpanagaraṃ na mithaḥ śliṣyatīti sat
]

`v 40 [
mithaśca śliṣyatītyevamapi satsarvarūpiṇi |
na tadasti na yatsatyaṃ na tadasti na yanmṛṣā
]

`v 41 [
sarvatra sarvathā sarvaṃ sarvadā sarvarūpiṇi |
aho nu viṣamā māyā manomohavidhāyinī
]

`v 42 [
māyāyāaghaṭitaghaṭanāsamarthatvenātyāścaryarūpatvādapi sarvaṃ ghaṭata ityāha ##-
vidhayaḥ pratiṣedhāśca yadekatra sthitiṃ gatāḥ |
īdṛśī brahmasattaiṣā yadevātmānamātmanā
]

`v 43 [
tayā anādiḥ sādiścetyavidyetyanubhūyate |
na jñaptimātrakacanaṃ yadi syādbhuvanatrayam
]

`v 44 [
tanmahākalpanaṣṭānāṃ sṛṣṭiḥ syātkathamañjasā |
kathamagneḥ kathaṃ vāyoḥ sattā bhūmeḥ kathaṃ bhavet
]

`v 45 [
tasmātsvabhāvakacanamātrānnānyadṛte jagat |
śāstrāṇyanubhavo lokā āmahākalpavādinām
]

`v 46 [
yeṣāṃ pramāṇaṃ no sarvaṃ praśastaistairalaṃ satām |
jñaptidṛṣṭyānayā sarvaṃ pramāṇībhavati kṣaṇāt
]

`v 47 [
nānyayā tanu tenaivameva sāraṃ vidurbudhāḥ |
śuddhā jñaptirbrahmasattā tvavidyāsmīti cetanāt
]

`v 48 [
anyayā dṛṣṭyā tuna pramāṇībhavati kiṃtu tanu phalgu bhavati | tena hetunā budhā
evameva jñānadṛṣṭisiddhameva sāraṃ viduḥ | kathaṃ vidustadāha - śuddheti | 47
|
sphuratīyaṃ jagadrūpā vātaśrīḥ spandanādiva |
na kaścaneha mriyate jāyate na ca kaścana
]

`v 49 [
mṛto'hamidamastītipratimaiva cidātmikā |
mṛtiratyantanāśaścettatsā nidrā sukhopamā
]

`v 50 [
punardṛśyopalambhaścennanu jīvitameva tat |
tasmānnehāsti maraṇaṃ tannaivehāsti jīvitam
]

`v 51 [
kasmiṃścinmātrakacane dvayaṃ vāpyasti naiva vā |
cetitaṃ dvayamapyasti nāsti dvayamacetitam
]

`v 52 [
cetitaṃ caikamevāsti svastyanantamataścitaḥ |
cinmātravyatirekeṇa kiṃ nāma vada jīvanam
]

`v 53 [
aduḥkhamakṣayatvāttadato duḥkhaṃ kva kasyacit |
vācyaṃ savācakaṃ sarvaṃ yatra cidvyomamātrakam
]

`v 54 [
tadanyattadananyacca ke te tatraikatādvite |
āvartādi yathā toye śarīrādi tathā pare
]

`v 55 [
tatsattāsaṃniveśātma kāraṇānanyakhātma ca |
cidbhānamātramavyagraṃ khamevāpratighaṃ jagat
]

`v 56 [
āścaryaṃ sughanaṃ vyagraṃ dravyaṃ sapratighaṃ sthitam |
tathete bhūtibhūrnāsti vartamānānubhūtibhūḥ
]

`v 57 [
tatra bhrāntyā piśāco'yaṃ bhāti khātmeti budhyatām |
yathaitatkhaṃ tathaitatkhametatkhamiti khaṃ sthitam
]

`v 58 [
tatheto bhūrito bhūtamito'nyaditi khaṃ param |
yaiva cidbhā jagatsaiva naikatātra na ca dvitā
]

`v 59 [
na ca pratighatā kācinna cāpratigharūpatā |
sarvamapratighaṃ dṛśyaṃ yathā bhūtārthadarśinaḥ
]

`v 60 [
tajjñatātajjñate cehana satī nāpyasatsthitī |
satye sadasatī caikaṃ kāṣṭhamaunamato'khilam
]

`v 61 [
yaddṛśyaṃ brahmatānantaṃ tadeva paramaṃ padam |
idaṃ sarvaṃ paraṃ brahmamātramityeva saṃsthitam
]

`v 62 [
evaṃ nāmaiṣa ciddhātuḥ kacatyevaṃ yadātmani |
yasyedaṃ kacanaṃ vyomno rūpamapratighaṃn jagat
]

`v 63 [
sargādyā mṛtajīvānāṃ sarvatraivāṅguleṅgule |
asaṃkhyāḥ santyasaṃkhyānāmadṛśyāpratighāmithaḥ
]

`v 64 [
anyonyaṃ siddhalokāste svaṃ yatra prāpya saṃgatāḥ |
parasparaṃ na paśyanti mithaḥ protā api sthitāḥ
]

`v 65 [
bhavatyākāśa evaiṣā dṛśyaśrīrgaganātmikā |
ananyadṛṣṭā cidrūpā svapnavatsvātmadraṣṭṭakā
]

`v 66 [
eṣā hi saṃparijñātā tiṣṭhatyapi yathāsthitam |
bhāmātrarūpanirvāṇā niśāntā'pratibhākṛtiḥ
]

`v 67 [
śāntāśeṣaviśeṣātma yathāsthitamavasthitam |
sadasadvā jagajjālaṃ parijñānena śāmyati
]

`v 68 [
yathābdhijalabindūnāṃ kṣaṇaviśleṣasaṃgamam `note[samāhāradvandvaḥ |] |
cidaṇūnāṃ tathā brahma vāridhau sphuratāṃ mithaḥ
]

`v 69 [
svapnavadbhāti sargaśrīḥ sargādau cinnabhomayī |
ataḥ sarvamidaṃ brahma śāntamityupapadyate
]

`v 70 [
dṛṣṭānyanantavibhavāni mayā jaganti bhuktāni kāryapariṇāmavijṛmbhitāni |
bhrāntā diśo daśa bahūni yugāni yāvajjñānādṛte kṣayamupaiti na
dṛśyadoṣaḥ
]