`v 1 [
ṣaḍaśītitamaḥ sargaḥ 86
śrīvasiṣṭha uvāca |
śṛṇu rāma kathaṃ tatra mahākāśe tathā sthitaḥ |
dehe bhrāntiṃ tu tāṃ tyaktvā sa rudro'pyupaśāmyati
]

`v 2 [
sa rudrastau jagatkhaṇḍau tadā citra ivārpitāḥ |
nispandā eva tatrāsanprekṣamāṇe sthite mayi
]

`v 3 [
tato muhūrtamātreṇa sa rudrastau nabhontare |
khaṇḍau vilokayāmāsa dṛśārkeṇeva rodasī
]

`v 4 [
tato nimeṣamātreṇa ghoṇāśvāsena khaṇḍakau |
tau samānīya cikṣepa pātālāntarivānane
]

`v 5 [
atiṣṭhadeka evāsāvekaṃ khe khamivākhile |
bhuktabrahmāṇḍakhaṇḍogramaṇḍamaṇḍakamaṇḍalaḥ
]

`v 6 [
tato muhūrtamātreṇa laghuḥ so'bhramivābhavat |
tato'bhavadyaṣṭisamastataḥ prādeśamātrakaḥ
]

`v 7 [
tataḥ kācakaṇākāro mayā dṛṣṭaḥ sa tādṛśaḥ |
tataḥ so'ṇūbhavandṛṣṭo mayā khāddivyadṛṣṭinā
]

`v 8 [
paramāṇuratho bhūtvā tatastvantarddhimāyayau |
ityasau śamamāyātaḥ śaradambudakhaṇḍavat
]

`v 9 [
tādṛśo'pi mahārambhaḥ puraḥ paśyata eva me |
iti sāvaraṇe tena te brahmāṇḍakavāṭake
]

`v 10 [
vinigīrṇe kṣudhārtena hariṇeneva parṇake |
athābhūnnirmalaṃ vyoma śāntaṃ brahmaiva kevalam
]

`v 11 [
anādimadhyaparyantaṃ saṃvidākāśamātrakam |
ityahaṃ dṛṣṭavāṃstatra kalpāntamuruvibhramam
]

`v 12 [
darpaṇapratibimbābhaṃ śilāśakalakoṭare |
atha tāmaṅganāṃ smṛtvā tāṃ śilāṃ tacca `note[śilāntargataṃ
brahmavṛttaṃ layaparyantaṃ tadvilāsaṃ cetyarthaḥ |] vibhramam
]

`v 13 [
rājadvāragato grāmya ivāhaṃ vismayaṃ gataḥ |
tāmālokitavānbhūyaḥ kaladhautaśilāmaham
]

`v 14 [
yāvatsarvatra santyatra sargāḥ kālyā ivāṅgake |
buddhinetreṇa dṛśyante divyākṣṇā vā na te yathā
]

`v 15 [
sarvatra sarvadā sarvaṃ yadastyeva tadā tayā |
dūravatprekṣyate māṃsadṛśā yadyeva sā śilā
]

`v 16 [
dṛśyate tacchilaivaikā na tu sargādi kiṃcana |
sāvasthitā śilaivaikarūpā nibiḍamaṇḍalā
]

`v 17 [
kaladhautamayī sphārā saṃdhyājaladasundarī |
tato'haṃ vismayāviṣṭaḥ pravicāritavānpunaḥ
]

`v 18 [
śilāyāmaparaṃ bhāgaṃ tathaiva parayā dṛśā |
yāvattamapi paśyāmi jagadārambhamantharam
]

`v 19 [
tathaiva suṣirākāra iva nānārthasundaram |
punaranyaṃ tathaivāhaṃ pradeśaṃ paridṛṣṭavān
]

`v 20 [
sargasaṃrambhavalitaṃ yāvattamapi tādṛśam |
yaṃ yaṃ pradeśaṃ paśyāmi śilāyāstatra tatra vai
]

`v 21 [
jagatpaśyāmi vimalamādarśa iva bimbitam |
mayātikautukenātha sarvāstasya gireḥ śilāḥ
]

`v 22 [
anviṣṭā bhūtibhāgāśca tṛṇagulmādayastathā |
yāvatsarvatra tattādṛgjagadasti yathāsthitam
]

`v 23 [
buddhyaiva dṛśyate nākṣṇā parayā vividhākṛti |
kvacitprathamasargātma jāyamānaprajāpati
]

`v 24 [
kalpyamānarkṣacandrārkadinarātryṛtuvatsaram |
kvacitkvacinmahīpīṭhasaṃpannajanamaṇḍalam
]

`v 25 [
kvacitkiṃcidasvātogracatuḥsāgarakhātakam |
kvacitkiṃcidasaṃjātasurasaṃjātadānavam
]

`v 26 [
kvacitkiṃcitkṛtayugācārasajjanabhūtakam |
kvacitkiṃcitkaliyugācāradurjanabhūtakam
]

`v 27 [
kvacitkiṃcitpuravyūhadaityasaṃgaradustaram
]

`v 28 [
kvacitkiṃcinmahāśailajālanirvivarāvani |
kvacitkiṃcidasaṃpannasargamekāmbujodbhavam
]

`v 29 [
kvacitkiṃcijjarāmṛtyūnmuktabhūtalamānavam |
kvacitkiṃcidasaṃjātacandraśūnyaśiraḥśivam
]

`v 30 [
anirmathitadugdhābdhimṛtyumatsurapūritam |
asaṃjātāmṛtāśvebhavaidyagokamalāviṣam
]

`v 31 [
śukrāmaramahāvidyānāśanotkasuravrajam |
kvacitkiṃcicca garbhāṅgakartanotkasureśvaram
]

`v 32 [
aparimlānadharmatvātsvaprakāśākhilavrajam |
kvacitkiṃcicca pūrvānyasaṃniveśakramasthiti
]

`v 33 [
apūrvavedaśāstrārthasamācāravicāraṇam |
kvacitkiṃcinna kalpāntasaṃkṣobhamiva saṃsthitam
]

`v 34 [
kvacitkiṃcicca daityaughaviluṇṭhitasurālayam |
kvacitkiṃcitsurodyānagāyadgandharvakinnaram
]

`v 35 [
kvacitkiṃcitsamārabdhagīrvāṇāsurasauhṛdam |
bhūtabhavyabhaviṣyatsthajagadāḍambaraṃ mayā
]

`v 36 [
tadānubhūtaṃ vapuṣi mahāviśvagaṇātmani |
ekatra kalpavikṣubdhapuṣkarāvartamantharam
]

`v 37 [
ekatra saumyasakalabhūtasaṃtatisaṃsthitam |
ekatra samanukṣubdhasurāsuranareśvaram
]

`v 38 [
ekatrāsaṃbhavadbhānunityābhinnatamoghanam |
ekatrāsaṃbhavaddhvāntaṃ kāntaṃ jvālodaropamam
]

`v 39 [
ekatra nalinīnālanilīnamadhukaiṭabham |
ekatra padmamañjūṣāsuptabālanavābjajam
]

`v 40 [
ekatraikārṇavodagravṛkṣaviśrāntamādhavam |
ekatra kalparajanīniḥśūnyatimirākulam
]

`v 41 [
śilājaṭharanispandaṃ vyomaiva vitatākṛti |
suṣuptajaṭharākāramaprajñātamalakṣaṇam
]

`v 42 [
apratarkyamavijñeyaṃn suṣuptamiva sarvataḥ |
ekatra pakṣavikṣubdhaśailakākākulāmbaram
]

`v 43 [
ekatra vajraniṣpeṣadravadbhūdharabhāsuram |
ekatrodvṛttamattābdhihriyamāṇadharācalam
]

`v 44 [
ekatra puravṛtrāndhabalisaṃgarasaṃkulam |
ekatra mattapātālagajakampivasundharam
]

`v 45 [
ekatra śeṣaśirasaḥ kalpāntaluṭhitāvani |
kvacidalpena rāmeṇa hatarāvaṇarākṣasam
]

`v 46 [
rakṣasā rāvaṇenaiva kvacidvihatarāghavam |
bhūsthapādena devādriśirasthaśirasā param
]

`v 47 [
paśyāmyambaramākrāntaṃ kvacidvai kālaneminā |
kvaciccāpasurairnityaṃ dānavaireva pālitam
]

`v 48 [
kvacicca bhraṣṭadanujairamaraireva pālitam |
jiṣṇuyuktena guptena viṣṇupāṇḍavakauravaiḥ
]

`v 49 [
kvacidbhāratayuddhena nihatākṣauhiṇīgaṇam |
śrīrāma uvāca |
kimahaṃ bhagavanpūrvamabhavaṃ kathayeti me
]

`v 50 [
abhavaṃ cedanenaiva saṃniveśena tatkatham |
śrīvasiṣṭha uvāca |
sarva eva vivartante rāma bhāvāḥ punaḥpunaḥ
]

`v 51 [
pūryamāṇā yathā māṣāḥ krameṇānyena tena vā |
sarvakramasamāḥ kecittayaivānyena vā mithaḥ
]

`v 52 [
sphurantyarthasamā bhāvāḥ kecidabdhitaraṅgavat |
punastvaṃ punarevāhaṃ punaḥ punarime janāḥ
]

`v 53 [
na kadācana naivānye saṃbhavantyakhilaṃ pare |
ta evānye'thavāmbhodhau taraṅgā iva nirṇayaḥ
]

`v 54 [
yadvanna jāyate tadvadbhūtānāṃ bhramatāṃ bhavet |
āyānti yāntyanantāni bhūtānīha bhavadbhramaiḥ
]

`v 55 [
tānyevānyāni cānyāni samāni viṣamāṇi ca |
āvṛttimanti tānyeva tathaivānyāni cābhitaḥ
]

`v 56 [
viddhi sīkarajālāni bhūtāni jagadambudheḥ |
vittabandhuvayaḥkarmavidyāvijñānaceṣṭitaiḥ
]

`v 57 [
idaṃ ca prāṅmumukṣuvyavahāraprakaraṇe uktameveti smārayaṃstadevāha - dhitteti |
56 |
taireva kecijjāyante bhūyobhūyaḥ śarīriṇaḥ |
ardhaistaiḥ sadṛśāḥ kecitkecitpādena taiḥ samāḥ
]

`v 58 [
tajjīvāstairvisadṛśā bhavantyanyaśarīriṇaḥ |
sarvairebhiḥ samāḥ kecitkālenaiva vilakṣaṇāḥ |
kālena sadṛśāḥ kecidanena ca vilakṣaṇāḥ
]

`v 59 [
kālenākulaceṣṭayānya iva te gacchantyadhordhvaṃ
punardehālekhanakheditānyagaṇitānyanyāni cānyānyalam bhūtāmbūni vahanti
saṃsṛtimaye tānyambudhau cañcale cakrāvṛttimayāni saṃkalayituṃ śaknoti
kastānyalam
]