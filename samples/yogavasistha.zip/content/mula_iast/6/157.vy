`v 1 [
saptapañcāśadadhikaśatatamaḥ sargaḥ 157
atha sindhurvadiṣyati |
āryānāryavapuḥ ko'hamabhavaṃ vimatiḥ purā |
yadvaśānme kusaṃskāraḥ prāktano'sti bhavapradaḥ
]

`v 2 [
mantrī vadiṣyati |
rahasyaṃ śṛṇu bho rājansāvadhānaparaḥ kṣaṇam |
coditaḥ saṃdadhāsīdamadya māndyavināśanam
]

`v 3 [
kimapyādyantarahitamastīha sadanāmayam |
sthitaṃ tvamahamityādirūpeṇa brahmaśabditam
]

`v 4 [
tadbrahma svayamevāhaṃ ciccetāmīti saṃvidam |
jīvatāmiva gatvāste cittībhūyātyajadvapuḥ
]

`v 5 [
cittaṃ tu gaganācchātma vapurviddhyātivāhikam |
tadeva vāsti nehānyadādhibhautikatādikam
]

`v 6 [
cittametadanākāramapi sākāravatsthitam |
saṃkalpaiḥ paralokādyaiḥ svapnādyairetadeva sat
]

`v 7 [
anākāramapi sphāraṃ cittaṃ jagadidaṃ viduḥ |
ya eva pavano nāma sa eva spandanaṃ yathā
]

`v 8 [
yathā gaganaśūnyatve jagaccitte tathaikakam |
atrāpratigharūpe'sti na manāgapi bhinnatā
]

`v 9 [
hṛdayasthaṃ jagajjālaṃ na kiṃcitkiṃcidāsthitam |
jagadviddhi nirākāraṃ cittameva na vāstavam
]

`v 10 [
sattvameva vapuḥ pūrvamuditaṃ brahmaṇaḥ padāt |
ayameva sa saṃpanno yo'dyata tāmasatāmasaḥ
]

`v 11 [
pūrvaṃ prāthamikasarge sāttvikadevatāghaṭitarūpatvātsattvameva hairaṇyagarbhākhyaṃ
samaṣṭivapurbrahmaṇaḥ padāduditam | ayaṃ samaṣṭireva vyaṣṭibhāve
tāmasaviṣayāsaṅgenotpattiprakaraṇoktarītyā
rājasasāttvikāditrayodaśadhāvibhāgakrameṇa sa te jīvo'dya tāmasatāmasaḥ saṃpannaḥ |
10 |
sindhurvakṣyati |
kimucyate mahābhāga vada tāmasatāmasaḥ |
kriyante pūrvamevaitāḥ kena saṃjñāḥ pare pade
]

`v 12 [
mantrī vadiṣyati |
jantoḥ sāvayavasyeha hastādyavayavā yathā |
tathānavayavasyaivamātivāhikatātmanaḥ
]

`v 13 [
paścādātmani saivātmā nānāsaṃjñāḥ kariṣyati |
ādhibhautikatānāmni pṛthvyādyā ātivāhike
]

`v 14 [
svapnābhe'smiñjagadbhāne saṃkalpenātmarūpiṇā |
saṃjñātmanātmarūpeṇa svayaṃ vyavahariṣyati
]

`v 15 [
tvāmātivāhikākārā yattatsphuritavānnavam |
jātirmahātamasko'yamiti tatrābhidhā kṛtā
]

`v 16 [
brahmaṇe nirvikārasya vikāriṇa iva prabho |
jātayo jīvatāpattau kalitā vividhābhidhāḥ
]

`v 17 [
prāthamyenaiva yadbrahma jīvatāmiva gacchati |
tadaiva buddhyā bhoktā tajjātiḥ sāttvikasāttvikī
]

`v 18 [
vartamāne bhave bhavyaguṇairyuktā tu mānada |
kevalā sāttvikī proktā jātirjātividāṃ varaiḥ
]

`v 19 [
navā bhavaiścedbahubhirbhogamokṣaikabhāginī |
jātistatprocyate tajjñaiḥ sadbhī rājasarājasī
]

`v 20 [
vartamāne bhave bhavyaguṇairmuktā tu mānada |
kevalā rājasī proktā jātiḥ svalpabhave bhavet
]

`v 21 [
prathamātyantabahubhirbhavaiścenmokṣagāminī |
jātistatprocyate tajjñaiḥ sadbhistāmasatāmasī
]

`v 22 [
sāmānyenaiva bahubhirjanmabhirmokṣabhāginī |
kevalā tāmasī proktā jātirjātiviśāradaiḥ
]

`v 23 [
krameṇānena jātīnāṃ vividhā bhedakalpanā |
tāsāṃ tāmasatāmasyāṃ jātau jāto'si mānada
]

`v 24 [
bahūni tava janmāni samatītāni tānyaham |
vividhāni vicitrāṇi vīra jānāmi no bhavān
]

`v 25 [
viśeṣeṇa tvanenaiṣa vyarthaṃ kālo'tivāhitaḥ |
mahāśavaśarīreṇa tvayānantakhagāminā
]

`v 26 [
evaṃ tāmasatāmasyā jātyāsi janito yadā |
tadā durlabhamokṣastvaṃ saṃsārakuharāditi
]

`v 27 [
sindhurvadiṣyati |
āryodāhara kenaiṣā prāgjātirjīyate'dhamā |
yāvattathaiva tiṣṭhāmi syāccettadvada pāvanam
]

`v 28 [
mantrī vadiṣyati |
na kiṃcana mahābuddhe tadastīha jagattraye |
yadanudveginā nāma pauruṣeṇa na labhyate
]

`v 29 [
hyastanī duṣkriyābhyeti śobhāṃ satkriyayā yathā |
adyaiva prāktanīṃ tasmādyatnātsatkāryavān bhava
]

`v 30 [
yo yamarthaṃ prārthayate tadarthaṃ yatate tathā |
so'vaśyaṃ tadavāpnoti na cecchrānto nivartate
]

`v 31 [
nā yathā yatate nityaṃ yadbhāvayati yanmayaḥ |
yādṛgicchecca bhavituṃ tādṛgbhavati nānyathā
]

`v 32 [
muniruvāca |
evamuktaḥ sa tenātha sindhuruddhurayā dhiyā |
tadā tatra tathā nāma rāṣṭraṃ tyakṣyatyaśeṣataḥ
]

`v 33 [
gamiṣyati vanaṃ dūraṃ prārthito'pi hi mantribhiḥ |
nāśrayiṣyati tadbhūyo rājyamucchinnaśātravam
]

`v 34 [
tiṣṭhataḥ sādhumadhye'sya tadvivekakathāvaśāt |
puṣpāsaṅgādivāmodo vivekaḥ samudeṣyati
]

`v 35 [
tataḥ kathamidaṃ janma kutaḥ saṃsāra āgataḥ |
itthaṃ vicārasāṃtatyātsa yāsyati vimuktatām
]

`v 36 [
nityaṃ vicāraṇaparo'tha bhavansa sindhuḥ satsaṅgamena padamāpsyati pāvanaṃ
saḥ |
tadyatra patramiva vātavidhūyamānaṃ no vastutāṃ vrajati kācana nāma lakṣmīḥ |
36 |
sa sindhuḥ rājā satsaṃgamena nityaṃ vicāraṇaparaḥ san atha pāvanaṃ tattādṛśaṃ
mokṣākhyaṃ padameṣyati | yatra mokṣapade kācana hiraṇyagarbhaiśvaryaparyantāpi
lakṣmīrvātavidhūyamānaṃ śuṣkapatramiva vastutāmupādeyatāṃ no vrajati kiṃtu
tucchaiva bhavatītyarthaḥ
]