`v 1 [
ekādaśādhikadviśatatamaḥ sargaḥ 211
śrīvasiṣṭha uvāca |
iti tatropaviśyāhaṃ pūjitastena bhūbhujā |
prayojanaṃ svaṃ saṃpādya svargantuṃ gaganaṃ plutaḥ
]

`v 2 [
adyaitadbhavatā proktaṃ mayā matimatāṃ vara |
anayā sudṛśā śāntamanāḥ khātmā bhaviṣyasi
]

`v 3 [
brahmaiva tadidaṃ sarvaṃ nirnāmaivāmalaṃ nabhaḥ |
kimapyevājamāśāntamādimadhyāntavarjitam
]

`v 4 [
cidbhānamātramityuktaṃ brahmeti kalitābhidham |
parātparamiti proktaṃ tattu nirnāmakaṃ padam
]

`v 5 [
śrīrāma uvāca |
siddhasādhyayamabrahmavidyādharadivaukasām |
brahmankathaya dṛśyante lokā lokadharāḥ katham
]

`v 6 [
śrīvasiṣṭha uvāca |
siddhasādhyayamabrahmavidyādharadivaukasām |
anyeṣāmapi bhūtānāmapūrvāṇāṃ mahātmanām
]

`v 7 [
pratirātraṃ pratidinaṃ puraḥ paścāduparyadhaḥ |
paśyasyālokayaṁllokānapaśyaṃśca na paśyasi
]

`v 8 [
ete lokāḥ kilaiteṣāṃ nābhyāsaḥ sthānadūragāḥ |
ete saṃkalpalokākhyā vyāptamebhiḥ kilākhilam
]

`v 9 [
yathaite kalpanālokā ayaṃ lokastathaiva naḥ |
yathā kālpaniko vāto lokālokāstathaiva te
]

`v 10 [
saṃkalpasvapnalokā ye tava bhānti divāniśam |
ta eva tādṛśāścānye saṃkalpena sthirīkṛtāḥ
]

`v 11 [
dhyānena tvamapītāṃścetsthiratāṃ susthirātmanā |
nayasyāśu tadevaite sthiratāṃ yāntyavighnataḥ
]

`v 12 [
yathābhimatavistārā yathābhimatasaṃpadaḥ |
saṃkalpabhāvavalito janah. paśyati siddhavat
]

`v 13 [
kiṃtu te sthiratāṃ nītāḥ siddhaiḥ svaryānasaṃpadā |
asthirairdhyānaviśrāntau tairduḥkhaistadamī kṛtāḥ
]

`v 14 [
jagadapratighaṃ sarvaṃ śāntacidvyoma sarvadā |
yathā dṛḍhaṃ saṃviditaṃ tathaivābhāti nānyathā
]

`v 15 [
na bhātyevāsaṃviditamasti nāsti na codyatā |
śūnyaṃ hyapratighaṃ caitatparākāśamarodhakam
]

`v 16 [
citsvabhāvatayā bhātaṃ bhārūpamiva dṛśyate |
asmiṃścidabhimānaśca vidyate na svabhāvataḥ
]

`v 17 [
kāryakāraṇabhāvāccetkathaivātra na vidyate |
vyomno'nantasya siddhasya kiṃ kathaṃ kila jāyate
]

`v 18 [
yacca jātamivābhāti vyomni vyomaiva tattathā |
tatraikadvitvakalanā kīdṛśī syādarūpiṇī
]

`v 19 [
taddhi yādṛśamevāsīttādṛgevāvatiṣṭhate |
nirvikāraṃ yathā svapne vyomaivācalavadbhavet
]

`v 20 [
saṃkalpe cittamākāraṃ yathodetyadrilīlayā |
na ca so'drirna tadvyoma tathā brahma jagatsthitiḥ
]

`v 21 [
kāṣṭhavanmaunamāsthāya raṭanto'pi mahādhiyaḥ |
iha vyavaharantyete budhā dārunarā iva
]

`v 22 [
yathā vāriṇi vartante taraṅgāvartavṛttayaḥ |
ananyāḥ parivartante tathā brahmaṇi sṛṣṭayaḥ
]

`v 23 [
yathā vāyau parispandā yathā vyomani śūnyatā |
ananyāścāpyamūrtāśca tathā brahmaṇi sṛṣṭayaḥ
]

`v 24 [
yathā saṃkalpanagaraṃ śūnyameva puraṃ sthitam |
sākāramapyanākāraṃ brahmaṇīdaṃ tathā jagat
]

`v 25 [
cirānubhūtamapyarthakāryapīdaṃ jagattrayam |
śūnyameva nirākāraṃ saṃkalpanagaraṃ yathā
]

`v 26 [
yadeva cittasaṃkalpastadeva nagaraṃ yathā |
tadā tathāyaṃ brahmācchaṃ tadeva jagaducyate
]

`v 27 [
ciraṃ nityānubhūto'pi jagadartho na kiṃcana |
vidyate puruṣasyena svapne svamaraṇaṃ yathā
]

`v 28 [
svapne puṃsā mṛtenāpi svadāho dṛśyate yathā |
asadeva sadābhāsaṃ jagaddṛṣṭaṃ pare tathā
]

`v 29 [
jagattā cājagattā ca parasyaivāmalaṃ vapuḥ |
parābhidhānaṃ ca paraṃ na ca satparamārthataḥ
]

`v 30 [
itthamastu yadi vānyathāstu vā maiva bhūdbhavatu ko'tra saṃbhramaḥ |
muñc phalguni phale phalagrahaṃ buddhavānasi kṛtaṃ pariśramaiḥ
]