`v 1 [
dvāviṃśaḥ sargaḥ 22
śrīvasiṣṭha uvāca |
jñānena jñeyaniṣṭhatvādyo'cittaṃ cittameva ca |
na budhyate karmaphalaṃ sa jñānītyabhidhīyate
]

`v 2 [
jñātvā samyaganujñānaṃ dṛśyate yena karmasu |
nirvāsanātmakaṃ jñasya sa jñānītyabhidhīyate
]

`v 3 [
antaḥśītalatehāsu prājñairyasyāvalokyate |
akṛtrimaikaśāntasya sa jñānītyabhidhīyate
]

`v 4 [
apunarjanmane yaḥ syādbodhaḥ sa jñānaśabdabhāk |
vasanāśanadā śeṣā vyavasthā śilpajīvikā
]

`v 5 [
pravāhapatite kārye kāmasaṃkalpavarjitaḥ |
tiṣṭhatyākāśahṛdayo yaḥ sa paṇḍita ucyate
]

`v 6 [
akāraṇaṃ pravartanta iva bhāvā akāraṇāt |
avidyamānā apyete'vidyamānā iva sthitāḥ
]

`v 7 [
āvirbhāvatirobhāvairbhāvābhāvabhavābhavaiḥ |
paścātkāraṇatāṃ yānti mithaḥ kāraṇakarmabhiḥ
]

`v 8 [
asataḥ śaśaśṛṅgādermṛgatṛṣṇāmbhaso yathā |
ālokanādalabhyasya kīdṛk syātkila kāraṇam
]

`v 9 [
asataḥ śaśaśṛṅgādeḥ kāraṇaṃ mārgayanti ye |
vandhyāputrasya pautrasya skandhamāsādayanti te
]

`v 10 [
asatyapratibhāsānāmetadevāśu kāraṇam |
yadanālokanaṃ nāma samālokakṣaṇakṣayam
]

`v 11 [
paramātmāyate jīvo budhyamānastvacetanam |
cetanaṃ budhyamānastu jīva evāvatiṣṭhate
]

`v 12 [
paramātmaiva jīvo'yaṃn budhyamānastvacetanam |
āmra eva rasāpatteḥ prayāti sahakāratām
]

`v 13 [
cetanaṃ cetanaṃ budhyamānastu jīva evāvatiṣṭhate |
jīvo jīvitajīrṇeṣu jātijanmasu jarjaraḥ
]

`v 14 [
ye parāṃ dṛṣṭimāyātā vidhi teṣāmapāmiva |
arūpālokamananaṃ spandamaspandanaṃ sadā
]

`v 15 [
ye parāṃ dṛṣṭimāyātā dṛśyaśrīpāradarśinaḥ |
na vidyamānamapyasti teṣāṃ vedanamātatam
]

`v 16 [
ye parāṃ dṛṣṭimāyātā viddhi teṣāmapāmiva |
spandamaspandanaṃ sarvamavedanavaśādiha
]

`v 17 [
arūpālokamananaveṣṭitā muktadāmavat |
budhāḥ karmasu ceṣṭante vṛkṣapatreṣvivānilaḥ
]

`v 18 [
ye parāṃ dṛṣṭimāyātāḥ saṃsṛteḥ pāradarśinaḥ |
na te karma praśaṃsanti kūpaṃ nadyāṃn vasanniva
]

`v 19 [
ye baddhavāsanā mūḍhāḥ karma śaṃsanti te'nagha |
śrutismṛtyucitaṃ tena vinābodhaṃ prayānti te
]

`v 20 [
indriyāṇi patantyarthaṃ bhraṣṭaṃ gṛdhra ivāmiṣam |
tāni saṃyamya manasā yukta āsīta tatparaḥ
]

`v 21 [
nāsanniveśaṃ hemāsti nāsargaṃ brahma vidyate |
kiṃtu sargādiśabdārthamuktaṃ yuktamateḥ śivam
]

`v 22 [
ekāndhakāre saṃpanne vyavahāro yugakṣaye |
nirvibhāgo nirābhāso yathā brahmaghane tathā
]

`v 23 [
abhrodare bhramāṅgānāṃ spandāspandamayī yathā |
svasaṃvidātmikā sattā bhūtānāmīśvarī tathā
]

`v 24 [
jalasyāntarjalāṃśānāṃ dvaitādvaitamayo yathā |
svasaṃvidātmā suspandastathā brahmaṇi bhūtadṛk
]

`v 25 [
yathāmbare'mbarāṃśānāṃ dvaitādvaitakṛtātmani |
ananyā sṛṣṭirābhāti tathānavayave śive
]

`v 26 [
jagato'ntarahaṃrūpamahaṃrūpāntare jagat |
sthitamanyonyavalitaṃ kadalīdalapīṭhavat
]

`v 27 [
rūpālokamanaskārai randhrairbahiriva `note[andhairbahiriva sthitam iti pāṭhaḥ |]
sthitam |
sṛṣṭiṃ paśyati jīvo'ntaḥ sarasīmiva parvataḥ
]

`v 28 [
jīvo jagattayātmānaṃ paśyatyayamakāraṇam |
hemeva kaṭakāditvaṃ tadapaśyanna paśyati
]

`v 29 [
jīvanto'pi na jīvanti mriyante na mṛtā api |
santopi ca na santīva pārāvāravidaḥ śubhāḥ
]

`v 30 [
prabuddhaḥ sarvakarmāṇi kurvannapi na paśyati |
gṛhakarmāṇi gehastho goṣṭhabhāṇḍamanā iva
]

`v 31 [
virāḍ hṛdi yathā candraḥ pratidehaṃ yathā sthitaḥ |
jīvo himakaṇākāraḥ sthūle sthūlo laghau laghuḥ
]

`v 32 [
ahamātmā trikoṇatvamupagacchati kalpanam |
asadeva sadābhāsaṃ manyate cetanādvapuḥ
]

`v 33 [
karmakośe trikoṇe ca śukrasāre'vatiṣṭhate |
dehe jīvohamityātmā svāmodaḥ kusume yathā
]

`v 34 [
ahamityeva śukrasthā saṃvidāpādamastakam |
visaratyakhile jyotsnā yathā brahmāṇḍamaṇḍape
]

`v 35 [
akṣarandhrapraṇālena visṛtaṃ vedanodakam |
vyāpnoti trijagaddhūmo viyanmeghatayā yathā
]

`v 36 [
dehe yadyapyaśeṣe'sminbahirantaśca vedanam |
vidyate tattathāpyatra śukre'sti ghanavāsanā
]

`v 37 [
jīvaḥ saṃkalpamātrātmā yatsaṃkalpo'vatiṣṭhate |
hṛdi bhūtvā sa evāśu bahiḥ prasarati sphuṭam
]

`v 38 [
yathāsthitāṃ ca niścittāṃ varjayitvā sthiropamām |
na kayācidapi sthityā śāmyatyahamiti bhramaḥ
]

`v 39 [
cintānucintyamānāpi bhāvanīyāmbaropamā |
ahaṃbhāvopaśamane śamanena krameṇa te
]

`v 40 [
tajjñā vyavaharantīha bhāvyabhāvanavarjitam |
arūpālokamananaṃ maunaṃ dārunarā iva
]

`v 41 [
akiṃcidbhāvano yaḥ syātsa mukta iti kathyate |
jīvannākāśaviśado bandhaśūnya iva sphuṭam
]

`v 42 [
ahamityeva śukrasthā saṃvidāpādamastakam |
visaratyakhile dehe brahmāṇḍe'rkaprabhā yathā |
]

`v 43 [
dṛṅnetraṃ svadanaṃ jihvā śrutiḥ śrotraṃ bhavatyasau |
ityādyā vāsanāḥ pañca baddhvā tāsu nimajjati
]

`v 44 [
cakṣurādīndriyabhāvena tattatsthānasaṃbandho'pi śukrātmabhūtasyaiva jīvasyetyāha ##-
stryādidarśanasparśanaśravaṇādau sarvendriyairapi kāmoddīpanānnimajjatītyarthaḥ | 43
|
cidbhāvo'kṣatayodeti mano bhūtvaikadeśataḥ |
sarvago'pi raso bhūmau yathāṅkuratayā madhau
]

`v 45 [
yo bhāvayati bhāveṣu neha rūḍheṣvabhāvatām |
tasyāyatnavato duḥkhamanantaṃ nopaśāmyati
]

`v 46 [
yena kenacidācchanno yena kenacidāśitaḥ |
yatra kvacanaśāyīha sa samrāḍiva rājate
]

`v 47 [
vāsanābhirupeto'pi samagrābhiravāsanaḥ |
antaḥśūnyo'pyaśūnyātmā khamiva śvasanānvitaḥ
]

`v 48 [
vāsanābhirbrahmākāravāsanābhirdagdhapaṭatantvākārasadṛśajagaddvāsanābhirvā |
47 |
āsane śayane yāne sthito yatnairna bodhyate |
nidrāluriva nirvāṇamanomanananirvṛtaḥ
]

`v 49 [
saṃvinmātraṃ hi puruṣaḥ sarvago'pi sa tiṣṭhati |
sphuṭasāre śarīrasya yathā gandho'bjakesare
]

`v 50 [
saṃvinmātraṃ vidurjantuṃn tasya prasaraṇaṃ jagat |
ātmaniṣṭhatvamajagatparametyupadeśabhūḥ
]

`v 51 [
nīraso bhava bhāveṣu sarveṣu vibhavādiṣu |
pāṣāṇaṃ hṛdayaṃ kṛtvā yathā bhavasi bhūtaye
]

`v 52 [
sādho hṛdayasauṣiryamasauṣiryamivāstu te |
acittvavapuṣo'cittvādupalasyeva rāghava
]

`v 53 [
pāṣāṇaṃ hṛdayaṃ kṛtvā ityuktestātparyaṃn viśadayati - sādho iti | yathā
acittvavapuṣa upalasya hṛdayasauṣiryamacittvādeva cinniveśānavakāśamasauṣiryaṃ
prasiddhaṃ tathā cinmātravapuṣastava daharākāśarūpaṃ hṛdayasauṣiryaṃ
cittvādevācinniveśaniravakāśaṃ cinnibiḍitamasauṣiryamivāstviti tadāśaya ityarthaḥ |
athavā iyantaṃ kālamacidātmābhimānādacittvavapuṣastava
acittvādajñānātsphaṭikopalasyāntaḥkalpitamākāśamiva bhogasāmagrī
dhanādilābhakoṭibhirapyapūryamāṇaṃ kāmalakṣaṇaṃ hṛdayasauṣiryaṃ
manaśchidraṃ sāṃprataṃ nityaniratiśayānandapūrṇātmalābhātpūrṇakāmatvena
bādhitaṃ vāstavaṃ sphaṭikopalāsauṣiryamivānandaikaghanamastviti tadāśaya ityarthaḥ |
52 |
tajjñājñayoraśeṣeṣu bhāvābhāveṣu karmasu |
ṛte nirvāsanatvāttu na viśeṣo'sti kaścana
]

`v 54 [
sattaivaiṣā vido yatsā bhavatyunmiṣitā jagat |
paraṃ tattvaṃ nimiṣatā dṛgivānāmakaṃ tatam
]

`v 55 [
dṛśyaṃn vinaśyatyakhilaṃ vinaṣṭaṃ jāyate punaḥ |
yanna naṣṭaṃ na cotpannaṃ tatsadbhavati tadbhavān
]

`v 56 [
bhāvajñaptirhi nirmūlā bhāvitāpi na vidyate |
salilaṃ mṛgatṛṣṇeva na dadāti bhavāṅkuram
]

`v 57 [
yathābhūtārthasaṃdarśacchinnā'hamiti bhāvanā |
dṛṣṭāpi na karotyantardagdhaṃ bījamivāṅkuram
]

`v 58 [
karma kurvannakurvanvā vītarāgo nirāmayaḥ |
nirmanā nityanirvāṇaḥ pumānātmani tiṣṭhati
]

`v 59 [
cittopaśāntau saṃśāntāḥ śāntāye bhogabandhavaḥ |
na svabhāvaparikṣīṇāścittameṣāṃ kilākaraḥ
]

`v 60 [
aghanaḥ kevalāloko budho jīvaḥ parāyate |
sa evānyo'pyananyo'ntaraparāhṇa ivātapaḥ
]

`v 61 [
ekadeśasthitātpuṃso dūrāyātasya cetasaḥ |
yadrūpaṃ sakalaṃ madhye tadrūpaṃ paramātmanaḥ
]

`v 62 [
cārucidvyomakarpūraṃn yaccamatkurute svayam |
anantamantaravyaktaṃ jagadityeva vetti tat
]

`v 63 [
nirviṣayacita evāyaṃ māyācamatkāro jagadityāha - cārviti | avyaktamanabhivyaktam |
62 |
gatabhavabhramabhāsuramakṣayaṃ śamamupetamupekṣitadīpavat |
sthitamapīha janaṃ jagadīśvarādanugataṃ nanu bhāti mudā ca khe
]