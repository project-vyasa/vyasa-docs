`v 1 [
pañcatriṃśadadhikaśatatamaḥ sargaḥ 135
śrīvasiṣṭha `note[bhāsa uvāca ityubhayatra pāṭhaḥ |] uvāca |
mattena bhūtavṛndena kiṃciccheṣīkṛte śave |
idamūcuḥ punardikṣu girau devāḥ savāsavāḥ
]

`v 2 [
vidyādharāmaravihāravimānabhūmāvapyāstṛtānyaśiśirīkaraṇāya bhūtaiḥ |
medomayāni pavanaprasṛtāmalābhrakhaṇḍāñcitāmbarasamānyurujālakāni
]

`v 3 [
dvīpeṣu saptasvapi paśya medojalāni bhūtaiḥ pravisāritāni |
bhuktaṃ ca māṃsaṃ rudhiraṃ ca pītaṃ kiṃcidgatā saṃprati dṛśyatāṃ bhūḥ | 3
|
dṛśyatāṃ darśanayogyatām
]

`v 4 [
medaḥpaṭairāvalitākhilāṅgīkaṣṭaṃ sthitā saṃprati modanā bhūḥ |
medomayaiḥ śāradameghajālaiḥ sakambalānīva vanāni bhānti
]

`v 5 [
paśyaitāni tadasthīni saṃpannāni mahādrayaḥ |
himādriśikharāṇīva sthitānyāvārya diktaṭam
]

`v 6 [
śrīvasiṣṭha `note[bhāsa uvāca ityubhayatra pāṭhaḥ |] uvāca |
deveṣu kathayatsvevaṃ kṛtvemāṃ medinīṃ dharām |
medojālaiḥ sa bhūtaugho matto vyomni nanarta ha
]

`v 7 [
nṛtyatsu bhūtavṛndeṣu śiṣṭaṃ raktaṃ surairbhuvaḥ |
ekapravāheṇaikasminnikṣiptaṃ makarālaye
]

`v 8 [
ekapravāheṇa saṃkalpakṛtena saptānāṃ madhye ekasminmakarālaye samudre nikṣiptam |
7 |
surārṇavaṃ tamevainaṃ saṃkalpaṃ vidadhuḥ surāḥ |
tataḥprabhṛti so'dyāpi saṃpanno madirārṇavaḥ
]

`v 9 [
bhūtāni nṛttamākāśe tāni kṛtvā pibanti tām |
madirāṃ punarākāśe nṛtyantyānandamandire
]

`v 10 [
pibantyadyāpi tānīva madirāṃ madirārṇavāt |
khe nṛtyanti ca bhūtāni saha yogeśvarīgaṇaiḥ
]

`v 11 [
teṣāṃ tānyatha bhūtānāṃ medojālāni bhūtale |
vistṛtānyavaśuṣkāṇi sthitāto medinī mahī
]

`v 12 [
iti kramācchāntimupāgate śive punaḥ pravṛtte dinayāminīkrame |
prajāḥ sasarjātha navāḥ prajāpatiḥ punaḥ sa sargo'bhavadatra pūrvavat
]