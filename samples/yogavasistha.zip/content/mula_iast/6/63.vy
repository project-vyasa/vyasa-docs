`v 1 [
triṣaṣṭitamaḥ sargaḥ 63
śrīrāma uvāca |
tava striyā'svarūpeṇa dehenābhūttayā katham |
kathamuccāritāstatra varṇāḥ kacaṭatādayaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
varṇeṣu svaśarīrāṇāṃ varṇāḥ kacaṭatādayaḥ |
kadācanāpi nodyanti śavānāmiva kena ca
]

`v 3 [
varṇoccāro'bhaviṣyaccetprakaṭārthastataḥ kvacit |
svapneṣvanvabhaviṣyattaṃ vinidraḥ pārśvago janaḥ
]

`v 4 [
tasmānna kiṃcitsvapneṣu tatsatyaṃ bhrāntireva sā |
cinmātrākāśakacanaṃ tattathā khe svabhāvajam
]

`v 5 [
tadendukārṣṇyakhatanuśilāgeyāditāṃ gatāḥ |
ivābhānti cidākāśāstathā deharavādayaḥ
]

`v 6 [
taccidākāśakacanaṃ yannāma svapnavedane |
ākāśameva nabhasaḥ kacanaṃ viddhi netarat
]

`v 7 [
yathā svapnastathaivedaṃ jāgradagre vyavasthitam |
ākāśamapyanākāśaṃ yathaivedaṃ tathaiva tat
]

`v 8 [
yathā kacati taccāru cetanaṃ caturaṃ tathā |
yathā sthitaṃ tadevedaṃ satyaṃ sthiramiva sphurat
]

`v 9 [
śrīrāma uvāca |
bhagavansvapna evedaṃ kathaṃ jāgradavasthitam |
asatyameva satyatvamiva yātaṃ kathaṃ bhavet
]

`v 10 [
śrīvasiṣṭha uvāca |
śṛṇu svapnamayānyeva kathaṃ santi jagantyalam |
nānyāni na ca satyāni na sthirāṇi sthitāni ca
]

`v 11 [
anubhūtāni bījāni bījarāśāvivāmbare |
anyānyanyāni tānyeva samāni na samāni ca
]

`v 12 [
pratyekamantaranyāni tathaivābhyuditāni ca |
parasparamadṛṣṭāni bahūni vividhāni ca
]

`v 13 [
anyonyaṃ tāni sarvāṇi na paśyantyeva kiṃcana |
jaḍānīvaikarāśīni bījānīva galantyapi
]

`v 14 [
vyomātmatvānna gaganaṃ na vidanti parasparam |
api cetanarūpāṇi suptānīva nirantaram
]

`v 15 [
suptāḥ svapnajagajjālamahani vyavahāriṇaḥ |
asurā nihatā devaiste svapnajagati sthitāḥ
]

`v 16 [
ajñānānna gatā muktiṃ na jāḍyājjaḍatāmitāḥ |
na dehavantaḥ kiṃ santu vinā svapnajagatsthiteḥ
]

`v 17 [
suptāḥ svapnajagajjāle svācāravyavahāriṇaḥ |
puruṣā nihatāḥ puṃbhiste tathaiva vyavasthitāḥ
]

`v 18 [
nirmokṣā niḥśarīrāste cetanāvāsanānvitāḥ |
dṛṣṭaṃ svapnajagajjālaṃ vinā ca kva vasantu te
]

`v 19 [
suptāḥ svapnajagajjālavyavasthācāracāriṇaḥ |
ye hatā rākṣasā devaiste yathaiva vyavasthitāḥ
]

`v 20 [
evaṃ ye nihatā rāma kiṃ te kurvanti kathyatām |
ajñatvānna gatā muktiṃ cetanānna dṛṣatsthitāḥ
]

`v 21 [
sādryabdhyurvījanaṃ dṛśyamidaṃ sarvaṃ yathāsthitam |
cirāyānubhavantyete yatheme vayamādṛtāḥ
]

`v 22 [
teṣāṃ svasvapnaścirānuvṛttyā asmadanubhavasāmyājjāgradavasthaiva bhavatītyāha ##-
teṣāṃ kalpajagatsaṃsthā yathāsmākaṃ tathaiva tāḥ |
asmākaṃ jagatīsaṃsthā yathā teṣāṃ tathaiva ca
]

`v 23 [
eteṣāṃ svapnapuruṣāsta eveme vayaṃ sthitāḥ |
ye ca te nāma saṃsārāstebhya ekamimaṃ viduḥ
]

`v 24 [
te svapnapuruṣāsteṣāṃ satyā evānubhūtitaḥ |
ātmano'pi parasyāpi sarvagatvāccidātmanaḥ
]

`v 25 [
yathā te svapnapuruṣāḥ satyamātmanyathā'pare |
tathāpi svapnapuruṣāḥ satyameva tathaiva te
]

`v 26 [
svasvapnapurapaurā ye tvayā dṛṣṭāstathaiva te |
sthitāstatra tahādyāpi brahma sarvātmakaṃ yataḥ
]

`v 27 [
prabodhe'pi hi bhidyante svapnabhāvā yathā sthitāḥ |
tathā sthityānubhūyante parabrahmatayāthavā
]

`v 28 [
sarvaṃ sarvātma sarvatra sarvadāsti tathā pare |
yathā na kiṃcinnākāśaṃ na kvacinna ca hanyate
]

`v 29 [
tathā ca prāk pratijñātaṃ phalitamityāha - sarvamiti | yathā sarvaṃ
jagadākāśakāryatvādākāśameveti tadrūpeṇa na kvacitkiṃcidapi hanyate tathā
prathamaṃ vinodaye utpattiśūnye madhye nirantare agre ca nirante paramākāśe brahmaṇi
tatra nirante asaṃkhye cittasaṃghāte teṣu cāsaṃkhye jagatāṃ gaṇe tatrāpi pratyākāśaṃ
tatrāpi pratisaṃsāramaṇḍalaṃ tatrāpi pratibhūrādilokaṃ tatrāpi pratidvīpaṃ tatrāpi
pratigiri tatrāpi pratimaṇḍalavistāraṃ tatrāpi pratigrāmaṃ pratipuraṃ tatrāpi pratigṛhaṃ
tatrāpi pratijantu pratiyugādikālaṃ ca yāvanto ye jīvā mṛtā mokṣavivarjitāḥ
sthitāstāvantaḥ saṃsārāḥ pṛthakpṛthagakṣayā eva sthitā iti pañcānāmekānvayaḥ |
28 |
nirantare parākāśe nirante ca vinodaye |
nirante cittasaṃghāte nirante jagatāṃ gaṇe
]

`v 30 [
pratyākāśakalākośaṃ pratisaṃsāramaṇḍalam |
pratilokāntarākāraṃ pratidvīpaṃ giriṃ prati
]

`v 31 [
pratimaṇḍalavistāraṃ pratigrāmaṃ puraṃ prati |
pratijantu pratigṛhaṃ prativarṣaṃ yugaṃ prati
]

`v 32 [
yāvanto ye mṛtāḥ kecijjīvā mokṣavivarjitāḥ |
sthitāste tatra tāvantaḥ saṃsārāḥ pṛthagakṣayāḥ
]

`v 33 [
teṣāmantarjanāḥ santi janaṃ prati punarmanaḥ |
punarmanaḥ prati jagajjagatprati punarjanaḥ
]

`v 34 [
itthamādyantarahita eṣa dṛśyamayo bhramaḥ |
brahmaiva brahmavitpakṣe nātreyattāsti kācana
]

`v 35 [
kuḍye nabhasyupalake salile sthale'ntaścinmātramasti hi yatastadaśeṣaviśvam |
tadyatra tatra jagadasti kuto'tra saṃkhyā tajjñeṣu tatparamathājñamanaḥsu
dṛśyam
]