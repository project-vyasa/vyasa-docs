`v 1 [
caturviṃśaḥ sargaḥ 24
śrīvasiṣṭha uvāca |
mametyuktavato maṅkirvinipatya sa pādayoḥ |
uvācānandapūrṇākṣamidaṃ mārge vahanvacaḥ
]

`v 2 [
maṅkiruvāca |
bhagavanbhūriśo bhrāntā diśo daśa dṛśo yathā |
mayā na tu punaḥ sādhurlabdhaḥ saṃśayanāśakṛt
]

`v 3 [
samastadehasārāṇāṃ sārasyādya phalaṃ mayā |
khinnosmi bhagavanpaśyandaśāḥ saṃsāradoṣadāḥ
]

`v 4 [
punarjātaṃ punarnaṣṭaṃ sukhaduḥkhabhramaḥ sadā |
avaśyaṃbhāviparyantaduḥkhatvātsakalānyapi
]

`v 5 [
sukhānyevātiduḥkhāni varaṃ duḥkhānyato mune |
dṛḍhaduḥkhavadantatvādduḥkhayanti sukhāni mām
]

`v 6 [
tathā rāma yathā duḥkhameva me sukhatāṃ gatam |
vayodaśanalomāntraiḥ saha jarjaratāṃ gatam
]

`v 7 [
uccaiḥpade pātaparā buddhirnādhyavasāyinī |
supravālaṃ kusaṃkalpādgahanaṃ na prakāśate
]

`v 8 [
manaḥ pippalapalyūlairiva kugrāmakoṭaram |
vāsanāṅgavahairgṛdhrairnityaṃ pāpīyasī sthitiḥ
]

`v 9 [
kaṇṭakadrumavallīva karālakuṭilā matiḥ |
āyurāyāsaśālinyā yāminyeva tamondhayā
]

`v 10 [
akṣīvānāgatālokaṃ kṣīṇaṃ saṃtatacintayā |
na kiṃcidrasamādatte naṣṭaivāpi na naśyati
]

`v 11 [
na puṣpitā na phalitā tṛṣṇā śuṣkalateva naḥ |
karma karmaṇi nirmagnaṃ vāsanākhyamakarmaṇe
]

`v 12 [
jīvitaṃ ca jane jīrṇaṃ naivottīrṇo bhavārṇavaḥ |
dinānudinamucchūnā bhogāśā bhayadāyinī
]

`v 13 [
pūrṇāpūrṇātmani kṣīṇāḥ śvabhrakaṇṭakavṛkṣavat |
cintājvaravikāriṇyo lakṣmyāḥ khalu mahāpadaḥ
]

`v 14 [
saṃpannamakṣataṃ sāpi vipralambhena jṛmbhate |
antaḥ sphuritaratnehaṃn bhāsvaraṃ vāndhakoṭaram
]

`v 15 [
kallolakalilaṃ śūnyaṃ cetaḥ śuṣkābdhidurbhagam |
māmindriyārthaikaparaṃ na spṛśanti vivekinaḥ
]

`v 16 [
sakaṇṭakamamedhyasthaṃn śleṣmātakamiva drumam |
asadeva mahārambhaṃ caladarjunavātavat
]

`v 17 [
mano maraṇamaprāptaṃ śūnyaṃn duḥkhāya valgati |
śāstrasajjanasaṃparkacandratārakadhāriṇī
]

`v 18 [
ahaṃbhāvollasadyakṣā kṣīṇā nājñānayāminī |
ajñānadhvāntamattebhasiṃhaḥ karmatṛṇānalaḥ
]

`v 19 [
udito na vikārārko vāsanārajanīkṣayaḥ |
avastu vastuvadbuddhaṃ mattaścittamataṃgajaḥ
]

`v 20 [
indriyāṇi nikṛntanti na jāne kiṃ bhaviṣyati |
śāstradṛṣṭirapi prājñairnāśritā taraṇāya yā
]

`v 21 [
sāpyadṛṣṭirivāndhyāya vāsanāveśakāriṇī |
tadevamatisaṃmohe yatkāryamiha dāruṇe |
udarkaśreyase tāta tanme kathaya pṛcchate
]

`v 22 [
śāmyanti mohamihikāḥ śaradīva sādhau prāpte bhavanti vimalāśca
tathākhilāśāḥ |
satyeti vāgbhavatu sādhujanopagītā madbodhanena bhavatā bhavaśāntidena
]