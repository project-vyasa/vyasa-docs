`v 1 [
saptaviṃśādhikaśatatamaḥ sargaḥ 127
śrīrāma uvāca |
bhagavankathayaitanme kathaṃ bhūgolakaṃ sthitam |
kathamṛkṣagaṇo yāti lokālokaḥ kathaṃ giriḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
yathā saṃkalparacitā śiśorvyomani tiṣṭhati |
vīṭā cinmātrabālena kalpitā bhūstathāmbare
]

`v 3 [
yathā timirikākṣāṇāṃ keśacandrādidarśanam |
cidākāśasya sargādau tathā pṛthvyādidarśanam
]

`v 4 [
yathā saṃkalpanagaraṃ dhāryamāṇaṃ na dṛśyate |
dhāryate dhāryate mā ca tathorvyanubhavaściteḥ
]

`v 5 [
yadyathā yāvadābhāti citi cittvātsvabhāvataḥ |
tattathā tāvadābhāti tatra tatra tadātmakam
]

`v 6 [
timirākrāntanetrasya keśoṇḍrakamivāmbare |
cinmātrasya mahīgolo yo bhātaḥ sa tathā sthitaḥ
]

`v 7 [
ūrdhvaṃ vahantyaḥ saritastadadhastāddhutāśanaḥ |
citi cetsvapnavadbhāti tattathā tatsthitaṃ bhavet
]

`v 8 [
tasmātpatantī bhūrbhātā patatyevāniśaṃ jagat |
utpatantī tu cidbhātā tathā nānātmikā bhavet
]

`v 9 [
stabdhabhātā sthitā stabdhā sālokā tu prakāśinī |
nirālokā nirālokalokānāmātmani sthitā
]

`v 10 [
cidbhānaikānusāreṇa tārācakraṃ tathā mahī |
asadeva sadaivedaṃ bhātīdamavikhaṇḍitam
]

`v 11 [
ālokālokamevātha nabhaḥkhātaṃ tato mahat |
tama ekārṇavākāraṃ sthitaṃ tatra kvacitkvacit
]

`v 12 [
dūratvādṛkṣacakrasya karālatvānmahāgireḥ |
kvacittamaḥ kvacittejastatraivācatvare'pi ca
]

`v 13 [
lokālokagireḥ pāre sthitādākāśamaṇḍalāt |
daśadikkaṃ sudūreṇa ṛkṣacakraṃ vivartate
]

`v 14 [
āpātāladivo naddhamṛkṣacakraṃ tadambare |
daśadikkaṃ prasarati patadūrdhvādṛte'bhitaḥ
]

`v 15 [
bhūlokameva pātālayutaṃ nakṣatramaṇḍalam |
paryeti lokālokānte nānyaccitkalpanācca tat
]

`v 16 [
salokālokabhūlokadviguṇātkhādanantaram |
pakavākṣoṭasya bhisseva sthitaṃ nakṣatramaṇḍalam
]

`v 17 [
dviguṇā nabhasastasmādṛkṣacakrasya puṣṭatā |
daśadikkaṃ visarato bilvatvaksadṛśasthiteḥ
]

`v 18 [
tasmādbhūlokadviguṇānnabhasaḥ ṛkṣacakrasya dviguṇā puṣṭatā antardalavistāraḥ | 17
|
saṃvidghanasya kacanaṃ yādṛśaṃ kalpanātmakam |
yaditthaṃ saṃniveśena nanviyaṃ jāgatī sthitiḥ
]

`v 19 [
nakṣatracakrāddviguṇaṃ tato'nyadvidyate nabhaḥ |
tacca kvacitprakāśāḍhyaṃ kvacitsāndratamomayam
]

`v 20 [
paryante tasya nabhasaḥ sthitaṃ brahmāṇḍakharparam |
ekamūrdhve paramadho gaganaṃ madhyametayoḥ
]

`v 21 [
yojanānāṃ koṭiśataṃ puṣṭaṃ vajradṛḍhaṃ ca tat |
sthitaṃ saṃvedamayaṃ vyomni vyomamayātmakam
]

`v 22 [
sarvadikkaṃ mahāgole nabhasi svarkatārakam `note[svargatārakaṃ iti mūle
vyākhyāyāṃ ca pāṭhaḥ |] |
kimatrordhvamadhaḥ kiṃ syātsarvamūrdhvamadhaśca vā
]

`v 23 [
patanamutpatanaṃ gamanaṃ sthitaṃ cita iti sphuritaṃ na tu vastu tat |
patanamasti na cotpatanaṃ na vā gamanamāgamanaṃ sthitamityapi
]