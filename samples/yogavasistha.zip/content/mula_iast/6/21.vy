`v 1 [
ekaviṃśaḥ sargaḥ 21
śrīvasiṣṭha uvāca |
jñāninaiva sadā bhāvyaṃ rāma na jñānabandhunā |
ajñātāraṃ varaṃ manye na punarjñānabandhutām
]

`v 2 [
śrīrāma uvāca |
kimucyate jñānabandhurjñānī caiva kimucyate |
kiṃ phalaṃ jñānabandhutve jñānitve'pi ca kiṃ phalam
]

`v 3 [
śrīvasiṣṭha uvāca |
vyācaṣṭe yaḥ paṭhati ca śāstraṃ bhogāya śilpivat |
yatate na tvanuṣṭhāne jñānabandhuḥ sa ucyate
]

`v 4 [
karmaspandeṣu no bodhaḥ phalito yasya dṛśyate |
bodhaśilpopajīvitvājjñānabandhuḥ sa ucyate
]

`v 5 [
vasanāśanamātreṇa tuṣṭāḥ śāstraphalāni ye |
jānanti jñānabandhūṃstānvidyācchāstrārthaśilpinaḥ
]

`v 6 [
pravṛttilakṣaṇe dharme vartate yaḥ śrutocite |
adūravartijñānatvājjñānabandhuḥ sa ucyate
]

`v 7 [
ātmajñānaṃ vidurjñānaṃ jñānānyanyāni yāni tu |
tāni jñānāvabhāsāni sārasyā'navabodhanāt
]

`v 8 [
ātmajñānamanāsādya jñānāntaralavena ye |
saṃtuṣṭāḥ kaṣṭaceṣṭaṃ te te smṛtā jñānabandhavaḥ
]

`v 9 [
jñānāditajjñeyavikāśaśāntyā vinā na saṃtuṣṭadhiyeha bhāvyam |
tvaṃ jñānabandhutvamupetya rāma ramasva mā bhogabhavāmayeṣu
]

`v 10 [
atrāhārārthaṃ karma kuryādanindyaṃ kuryādāhāraṃ prāṇasaṃdhāraṇārtham |
prāṇāḥ saṃdhāryāstattvajijñāsanārthaṃ tattvaṃ jijñāsyaṃyena bhūyo na
duḥkham
]