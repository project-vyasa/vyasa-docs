`v 1 [
saptaṣaṣṭitamaḥ sargaḥ 67
vidyādharyuvāca |
yāvattaṃ sargamāgaccha prasādaḥ kriyatāṃ mune |
āścaryeṣūpapanneṣu mahānto hyatikautukāḥ
]

`v 2 [
tathetyukte `note[śrīvasiṣṭha uvācetyapekṣitanatra |] mayā sārdhaṃ
gantumārabdhamambare |
vātyayā saurabheṇeva śūnye śūnyena śūnyayā
]

`v 3 [
athāhaṃ dūramadhvānaṃ śūnyamullaṅghya nābhasam |
nabhaḥsthaṃ bhūtasaṃghātaṃ tayā sārdhamavāptavān
]

`v 4 [
tamullaṅghya cireṇātra bhūtasaṃcāramambare |
lokālokaśirovyoma prāpto'smi dhavalāmbudam
]

`v 5 [
uttarāṃśenduśubhrābhrapīṭhānnirgatya tāṃ śilām |
ānītosmi tayottuṅgāṃ taptakāñcanakalpitām
]

`v 6 [
yāvatpaśyāmvahaṃ śubhrāṃ śilāṃ tāṃ na ca tajjagat |
kaladhautamayīmuccairagnilokataṭīmiva
]

`v 7 [
tadā mayoktā sā kāntā kva bhavatsargabhūriti |
kva rudrārkāgnitārādi kva lokāntarasaptakam
]

`v 8 [
kvārṇavākāśakakubhaḥ kvonmajjananimajjane |
kva mahāmbhodasaṃbhāraḥ kva tārāmbaraḍambaram
]

`v 9 [
kva śailaśikharaśreṇyaḥ kva mahārṇavalekhikāḥ |
kva dvīpavalayāḥ sapta kva taptakanakāvaniḥ
]

`v 10 [
kva kāryakālakalanāḥ kva bhūtabhuvanabhramaḥ |
kva vidyādharagandharvāḥ kva narāmaradānavāḥ
]

`v 11 [
kvarṣibhūpālamunayaḥ kva nayāpanayakramaḥ |
kva pañcayāmayāminyaḥ kva svarganarakabhramaḥ
]

`v 12 [
kva puṇyapāpakalanā kva kalākālakelayaḥ |
kva surāsuravairāṇi kva dveṣasneharītayaḥ
]

`v 13 [
vadatyevaṃ mayi vacaḥ sovāca varavarṇinī |
vismayākulamālokya śilāmalivilocanā
]

`v 14 [
vidyādharyuvāca |
paśyāmyakhila `note[akhila iti saṃbodhanam |] nātmīyamahaṃ sarvamihopale |
mukurapratibimbasthapurānyapuravajjanam
]

`v 15 [
nityānubhava evātra darśane kāraṇaṃ mama |
tadabhāvo mune manye te kāraṇamadarśane
]

`v 16 [
anyacca cirakālaikadvaitasaṃkathayānayā |
śuddhātivāhikaikātmadehatā vismṛtāvayoḥ
]

`v 17 [
mamātisucirābhyastamapi vyoma latāmiva |
gataṃ nijaṃ jagadidaṃ yataḥ paśyāmi na sphuṭam
]

`v 18 [
abhūdyatsvajagatpūrvamatiprakaṭameva me |
tatpaśyāmīdamādarśa iva bimbitamasphuṭam
]

`v 19 [
ciravyarthotthayā nātha saṃkathāvyathayā mithaḥ |
svāsthyaṃ vismṛtamātmīyamavadātatamaṃ tatam
]

`v 20 [
yo'bhyāsaḥ prakacatyantaḥ śuddhacinnabhaso rasāt |
bhavettanmayamevāntarābālamiva lakṣyate
]

`v 21 [
na sacchāstreṇa sā viddhi na sannyāyena sā kalā |
asti nāstyamitodyogādyadabhyāsānna siddhyati
]

`v 22 [
svajagatsaṃtatābhyāsavaśato māṃ kathābhramaḥ |
nūnamākrāntavāneṣa dvayorhi balavāñjayī
]

`v 23 [
iṣṭavastvarthināṃ tajjñasūpadiṣṭena karmaṇā |
paunaḥpunyena karaṇānnetaraccharaṇaṃ mune
]

`v 24 [
ayamitthamihājñānabhramaḥ prauḍho'hamātmakaḥ |
śāmyati jñānacarcābhiḥ paśyābhyāsavijṛmbhitam
]

`v 25 [
ahaṃ śiṣyābalā bālā paśyāmi tvaṃ na paśyasi |
sarvajño'pi śilāsargaṃ paśyābhyāsavijṛmbhitam
]

`v 26 [
ajño'pi tajjñatāmeti śanaiḥ śailopi cūrṇyate |
bāṇopyeti mahālakṣyaṃ paśyābhyāsavijṛmbhitam
]

`v 27 [
itthaṃ nāma pariprauḍhā mithyājñānaviṣūcikā |
śāmyatyeva vicāreṇa paśyābhyāsavijṛmbhitam
]

`v 28 [
abhyāsena kaṭudravyaṃ bhavatyabhimataṃ mune |
anyasmai rocate nimbastvanyasmai madhu rocate
]

`v 29 [
abandhurbandhutāmeti naikaṭyābhyāsayogataḥ |
yātyanabhyāsato dūrātsneho bandhuṣu tānavam
]

`v 30 [
ātivāhikadeho'yaṃ śuddhacidvyoma kevalam |
ādhibhautikatāmeti bhāvanābhyāsayogataḥ
]

`v 31 [
ādhibhautikadeho'sau dhāraṇābhyāsabhāvanāt |
vihaṃgavatkhamabhyeti paśyābhyāsavijṛmbhitam
]

`v 32 [
puṇyāni yānti vaiphalyaṃ vaiphalyaṃ yānti mātaraḥ |
bhāgyāni yānti vaiphalyaṃ nābhyāsastu kadācana
]

`v 33 [
kīrtanādyalpāparādhenāpi mahāntyapi puṇyāni vaiphalyaṃ yānti | bhāgyāni dhanāni | 32
|
duḥsādhyāḥ siddhimāyānti ripavo yānti mitratām |
viṣāṇyamṛtatāṃ yānti saṃtatābhyāsayogataḥ
]

`v 34 [
yenābhyāsaḥ parityakta iṣṭe vastuni so'dhamaḥ |
kadācinna tadāpnoti vandhyā svatanayaṃ yathā
]

`v 35 [
yadapyabhimataṃ vastu svabhyāsena tadarjanāt |
tadyuktipūrvakaṃ tyājyamāmṛtyorjīvitaṃ yathā
]

`v 36 [
iṣṭe vastuni nābhyāsaṃ yaḥ karoti narādhamaḥ |
so'niṣṭe'niṣṭamāpnoti narakānnarakāntaram
]

`v 37 [
taranti saritaṃ sphītāṃ saṃsārāsārasevinaḥ |
ta evātmavicārākhyamabhyāsaṃ na tyajanti ye
]

`v 38 [
abhyāsabhāso'bhimataṃ vastu prakaṭayantyalam |
prāpayanti ca nirvighnaṃ ghaṭaṃ dīpaprabhā yathā
]

`v 39 [
yathā kalpadrumalatāḥ saccintāmaṇayo yathā |
phalanti śaradaścaitāstathaivābhyāsabhūmayaḥ
]

`v 40 [
iṣṭavastu cirābhyāsabhāsvānbhāsayati prajāḥ |
tathendriyākhyāṃ dehorvyāṃ rātriṃ paśyanti no yathā
]

`v 41 [
sarvasya jantujātasya sarvavastvavabhāsane |
sarvadaivaika evoccairjayatyabhyāsabhāskaraḥ
]

`v 42 [
caturdaśavidhāyāstu bhūtajāterna kasyacit |
sidhyatyabhimataṃ vastu vinābhyāsamakṛtrimam
]

`v 43 [
paunaḥpunyena karaṇamabhyāsa iti kathyate |
puruṣārthaḥ sa eveha tenāsti na vinā gatiḥ
]

`v 44 [
dṛḍhābhyāsābhidhānena yatnanāmnā svakarmaṇā |
nijavedanajenaiva siddhirbhavati nānyathā
]

`v 45 [
abhyāsabhāsvati tapatyavanau vane ca vīrasya sidhyati na yanna tadasti kiṃcit |
abhyāsato bhuvi bhayānyabhayībhavanti sarvāsu parvataguhāsvapi nirjanāsu
]