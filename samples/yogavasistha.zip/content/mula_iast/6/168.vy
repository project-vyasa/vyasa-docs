`v 1 [
aṣṭaṣaṣṭyadhikaśatatamaḥ sargaḥ 168
śrīvasiṣṭha uvāca |
abuddhipūrvamevāgo yathā śākhāvicitratām |
karotyevamajaścitrāḥ sargābhāsaḥ kha eva kham
]

`v 2 [
abuddhipūrvakaḥ sargasyādhyāropo'tra varṇyate |
cinmātrātmā ca sa cito'vikāritvādapodyate |
mithyātvasiddhaye sargasyābuddhipūrvakatvaṃ dṛṣṭāntaiḥ samarthayati -
abuddhipūrvamityādinā | ago vṛkṣo yathā abuddhipūrvaṃ ahaṃ śākhāvaicitryaṃ
karomīti buddhipūrvakatāṃ vinā | ajo janmādivikriyāśūnyaḥ paramātmā khe
ākāśakalpe svātmani khaṃ śūnyātmikāścitrā vicitrāḥ sargābhāsaḥ
prapañcādhyāsānkaroti | nanu sa aikṣata lokānnu sṛjā iti so'kāmayata bahu syāṃ
prajāyeyeti sa tapo'tapyata satapastaptvā idaṃ sarvamasṛjata tapasā cīyate brahma
tato'nnamupajāyate ityādiśrutiṣu buddhipūrvaka eva sarga udghoṣyate
tatkathamatrābuddhipūrvakaḥ sarga iti pratyakṣaśrutiviruddhamucyata iti cet śṛṇu |
bhavedetadevaṃ yadi śruteḥ sargādipratipādane tātparyaṃ syāt | na tu tadasti |
prayojanābhāvāt | na hi sargādijñānena kiṃcitprayojanaṃ śrutam |
advitīyabrahmātmatājñānaṃ hi prayojanavadupakrāntaṃ sarvaśrutiṣu | tasya phalavataḥ
saṃnidhau śrutamaphalaṃ sargādikaimarthakyākāṅkṣāyāṃ tadaṅgatāṃ pratipadyate |
sā cāsya śāṇḍilyavidyāṅgaśamavidhipare sarvaṃ khalvidaṃ brahma tajjalāniti śānta
upāsīta iti vākye yata idaṃ sarvaṃ jagattasmājjāyata iti tajjam | tasmin līyata iti tallam |
tenāniti prāṇiti jīvatīti tadan utpattisthitipralayeṣu tadadhīnasattākamataḥ sarvaṃ khalvidaṃ
tadbrahmaiveti brahmādvaitavyutpādanopāyatayā sargāderjñānāṅgabhāvasya śrutyaiva
siddhavatkīrtanātprakārāntareṇa tadghaṭanāyogāt
tadananyatvamārambhaṇaśabdādibhyaḥ ityādisūtrabhāṣyādivyutpāditayuktisahasrebhyaḥ
smṛtipurāṇādyupabṛṃhaṇasahasrebhyaścādhyāropāpavādābhyāṃ
niṣprapañcabrahmātmatattvavyutpādane sargaśrutīnāṃ tātparye niścite
rajjusarpaśuktirajatamarumarīcikāsvapnādyadhyāropeṣvabuddhipūrvakatvameva dṛṣṭaṃ
na kvacidārope buddhipūrvakatā loke dṛśyata iti bhagavatā
vasiṣṭhenātrānāropitatvaśaṅkā kasyacitsarge mā bhūdityabuddhipūrvakatā prasādhyate
| śrutiṣu īkṣaṇādipūrvakatvakīrtanaṃ tu brahmaṇaḥ sarvajñatvacidekarasatvādilābhena
sāṃkhyādyabhimatā cetanapradhānādyupādānakatvanirāse paryavasyati |
īkṣaternāśabdam ityādisūtraistathaiva śrutitātparyavarṇāt | tasya traya āvasathāstrayaḥ
svapnāh yathā sataḥ puruṣātkeśalomāni tathākṣarātsaṃbhavatīha viśvam
ityādiśrutidṛṣṭāntānuguṇyāt | bhagavadīkṣaṇakāmasaṃkalpādīnāṃ
buddhitattvotpatteḥ pūrvabhāvināṃ māyāvṛttimātratvena tatpūrvakatve'pi
kāmasaṃkalpādidharmibuddhipūrvakatvābhāvopapatteḥ | adhyāropasya
tvaṃpadārthaniṣṭhasyaiva cāpavādena nirāsasya tanmuktiphalatvopapattestatpadārthe
jagadadhyāropapratipādane prayojanābhāvātprapañcasya svaniṣṭhāvidyākāryatve
svavidyayā nirāsopapatteḥ
svasmiṃścābuddhipūrvakasyaivāvasthātrayādhyāropasyānu##-
yathā karotyabuddhyādirāvartādi payonidhiḥ |
tathā karoti khe khātmā sarveśaḥ sarvavedanāḥ
]

`v 3 [
tāsāṃ svasaṃvidāmeva tataḥ sa kurute svayam |
mano buddhirahaṃkāra ityādyā vividhābhidhāḥ
]

`v 4 [
abuddhipūrvamārambho dṛśyarūpaḥ svataściteḥ |
saṃkalpyamāno buddhyādistaraṅgādiryathāmbudheḥ
]

`v 5 [
cinmātrātsaṃpravartante manobuddhyādayastathā |
āvartakaṇakallolavīcayo vāridheryathā
]

`v 6 [
bhittimātraṃ yathā citrajagadālokamātrakam |
citi cidvyomamātrātma tathaivābhāsamātrakam
]

`v 7 [
abuddhipūrvamārambo niyatyā saṃniveśavān |
yathā saṃpadyate vṛtte tathā sargātmakaściti
]

`v 8 [
tarau gulucchakādīnāṃ yathānyaḥ kurute'bhidhāḥ |
tathā cidvṛkṣapuṣpādipṛthvyādivihitābhidham
]

`v 9 [
ananyatpuṣpapatrādi yathā nāma mahātaroḥ |
tathaivānanyadevedaṃ cidvyomnaḥ paramātmanaḥ
]

`v 10 [
tarāvavayaveṣvanyaḥ karoti vividhābhidhāḥ |
cidvyomātmani sarveṣu bhūtvānya iva khātmasu
]

`v 11 [
cittaroḥ pallavāḥ sargāścittvādeva na santyalam |
kāryakāraṇavadbhāti sa eva svapnavatsvayam
]

`v 12 [
vakṣi cetkathametasmādvyarthaṃ tadanubhūyate |
sargādyamutra svapnādiṣveṣu ko'pahnavaṃ bhajet
]

`v 13 [
tarāvākāravatyeṣā kalpanā racitā yathā |
citerākāśamātrāyāstathaiṣā kalpanā kṛtā
]

`v 14 [
yathā gandhādayaḥ puṣpe gagane śūnyatādayaḥ |
yathā spandādayo vāyau tathā buddhyādayaḥ pare
]

`v 15 [
yathā gandhādayaḥ puṣpe gagane śūnyatādayaḥ |
yathā spandādayo vāyau tathemāḥ sṛṣṭayaściti
]

`v 16 [
yathā khānilapuṣpāṇāṃ śūnyatāspandagandhadṛk |
śūnyarūpānubhūtā ca tathā sargasthitiściti
]

`v 17 [
na pṛthak śūnyatā vyomno na pṛthagdravatāmbhasaḥ |
na pṛthak kusumādgandho nānilātspandanaṃ pṛthak
]

`v 18 [
agnerna pṛthaguṣṇatvaṃ pṛthak śaityaṃ ca no himāt |
cidvyomaikātmanaḥ svacchānna jagatpṛthagīśvarāt
]

`v 19 [
sargādāveva yadvyomni svapnāddhṛdi ca dṛśyate |
akāraṇaṃ taccidvyomnaḥ kathamanyadbhavetkila
]

`v 20 [
svapna evātra dṛṣṭānto nityadṛṣṭo vicāryatām |
cinmātravyatirekeṇa sāraṃ kiṃ tatra kathyatām
]

`v 21 [
tadidaṃ buddhisaṃskāradṛ"ṣyamityādikā smṛtiḥ |
na saṃbhavati yattattvaṃ kathayedaṃ kathaṃ bhavet
]

`v 22 [
yattatra dṛṣṭaṃ tadiha smṛtikāle bhavedyadi |
nānubhūyeta tattatra kaivaikasya dvidhā sthitiḥ
]

`v 23 [
tasmādāvartavṛttyedaṃ kākatālīyavajjagat |
citi yadbhāti tatraiṣā paścātsvapnādikalpanā
]

`v 24 [
tasmātsvāpnabodhasyānubhavatvānapahnavāddṛṣṭānto'styeveti svoktaṃ
siddhamityupasaṃharati - tasmāditi | paścājjāgratsvapnānubhavasiddhyanantaram | 23
|
abuddhipūrvaṃ saṃpanne sarge vīcyādayo yathā |
saṃniveśaḥ sthitiḥ paścātsvayaṃ saṃpadyate tathā
]

`v 25 [
jātameva na tajjātaṃ jātaṃ yatkāraṇaṃ vinā |
yato'jātaṃ tadevādyaṃ tatsamaṃ saṃsthitaṃ tathā
]

`v 26 [
abuddhipūrvaṃ saṃjātā ratnādīnāṃ yathārciṣaḥ |
sattaiva saṃniveśena tathaivāsāṃ jagaddṛśām
]

`v 27 [
yathākathaṃcidevedamāṃdau saṃpadyate jagat |
paścādgṛhṇāti niyatimāvarto'bdhāvivātmani
]

`v 28 [
cidvyomni svapnajālāni cijjagantyapakāraṇam |
pravartante nivartante śūnyaśūnyātmakānyapi
]

`v 29 [
yāvatsarvamathānyonyaṃ yāti kāraṇatāṃ ciram |
teṣāṃ śūnyātmakā eva padārthā īśvarādayaḥ
]

`v 30 [
jāyate śūnyamevedaṃ śūnyameva ca vardhate |
nanu śūnyatayātyantaṃ śūnyameva vinaśyati
]

`v 31 [
śūnyaṃ kacatyaśūnyābhaṃ dṛṣṭāntaṃ svapnamatra yaḥ |
apahnute'nubhūtaṃ sa paśubhartṛkukaṃ kudhīḥ
]

`v 32 [
asadevedamābhāti bhrāntimātraṃ sukṛtrimam |
ciccamatkāramātrātma jñe sanmātramakṛtrimam
]

`v 33 [
ayaṃ cirasthasaṃkalpaḥ sargapralayavibhramaḥ |
jñānaṃ svabhāvakacanamajñānaṃ bhrāntijṛmbhaṇam
]

`v 34 [
jhaṭityudeti brahmātma dṛśyaṃ dṛṣṭamakāraṇam |
khe suṣuptādiva svapnaḥ paścānniyatimṛcchati
]

`v 35 [
kākatālīyavaccittvācciti dṛśyaṃ prakāśate |
svayameva svabhāvasthamāvartādi yathāmbudhau
]

`v 36 [
īdṛśo nāma ciddhāturayamākāśamātrakaḥ |
yaditthaṃ nāma kacati jagadrūpeṇa cidvapuḥ
]

`v 37 [
tena cidrūpiṇā paścāddṛśyenātmani kalpitāḥ |
saṃjñāḥ smṛtyādipṛthvyādibuddhyādikalanātmikāḥ
]

`v 38 [
śrīrāma uvāca |
evaṃ sthite he bhagavanbuddhisaṃskārataḥ smṛtiḥ |
iti kiṃ prāpyate brūhi saṃbuddhā yadi na smṛtiḥ
]

`v 39 [
śrīvasiṣṭha uvāca |
śṛṇu rāma bhinadbhyenaṃ praśnaṃ siṃha ivebhakam |
abhedaṃ sthāpayāmyekamālokamiva bhāskaraḥ
]

`v 40 [
vidyate jagadātmedaṃ dṛśyaṃ cinmātrakoṭare |
anutkīrṇā yathā vṛkṣe vanasthā śālabhañjikā
]

`v 41 [
uddharedvṛkṣatastakṣā kadācicchālabhañjikām |
advitīyāccitistambhādutkīrṇāṃ kaḥ karoti tām
]

`v 42 [
uddharettadāvarakakāṣṭhāvayavanirasanena yathā prakaṭayettathā
advitīyātkartrādikārakaśūnyāccitistambhāttāṃ jagacchālabhañjikāṃ samyagutkīrṇāṃ
kaḥ tadanyaḥ karotītyakārakatantratvāddārupratimāvattadabhivyaktirna bhavatītyarthaḥ | 41
|
stambhe jaḍena sā vyaktimanutkīrṇeha gacchati |
citi tvantargatā cittvādevātmanyeva bhātyalam
]

`v 43 [
bhāsamānā tvanutkīrṇadehaivāpi ca khātmikā |
svarūpādacyutā caiva cinmātrādātmani sthitā
]

`v 44 [
sargādau sargakalanāḥ karoti kalanāvatī |
sā citsvabhāvataḥ svapne khātmanyadyoditāmiva
]

`v 45 [
ākāśa eva hṛdaye paramākāśarūpiṇī |
saṃkalpayati cicchālabhañjikāḥ svātmanātmani
]

`v 46 [
iyaṃ brahmakalā seha cinmātrakalanā tviyam |
iyaṃ citiriyaṃ jīvastvahaṃkārastvasāviti
]

`v 47 [
iyaṃ buddhiriyaṃ cittamayaṃ kāla idaṃ nabhaḥ |
ayaṃ so'haṃ kriyā ceyamidaṃ tanmātrapañcakam
]

`v 48 [
indriyāṇāmidaṃ vṛndaṃ puryaṣṭakamidaṃ smṛtam |
ihātivāhiko dehastathāyaṃ cādhibhautikaḥ
]

`v 49 [
brahmāhaṃ śaṃkaraścāhamupendro'hamahaṃ raviḥ |
idaṃ bāhyamidaṃ cāntarayaṃ sarga idaṃ jagat
]

`v 50 [
ityādikalanājālaṃ cidvyomaivātinirmalam |
tasmātkvaite padārthaughāḥ kva smṛtiḥ kva dvayaikate
]

`v 51 [
akāraṇakameveti jagadābhogikhaṇḍakaḥ |
sargādau svapnavadbhāti khe khātmaiva vikārivat
]

`v 52 [
vyomnyeva kacati vyoma cinmaye cinmayaṃ hi yat |
buddhaṃ tadeva tenaiva jagadbodhātkva tajjagat
]

`v 53 [
kva smṛtiḥ kva ca vā svapnaḥ kva kālāḥ kalanāśca kāḥ |
cidābhānamidaṃ bhāti śāntaṃ śūnyamivāmbare
]

`v 54 [
yadaikameva cidvyoma tadā prapañcitavibhāgā na santyeveti phalitamityāha - kveti |
53 |
yadantaścidghanasyāsti tadvahirbhūtatāṃ gatam |
vastutastu na tadbāhyaṃ nāntaḥ sanmātrakādṛte
]

`v 55 [
nirastāvayavācchāntādanākhyādyatpravartate |
akāraṇaṃ bhavedbhūtaṃ tadandhāḥ kathamanyathā
]

`v 56 [
tasmādyādṛkparaṃ brahma tādṛgdṛśyamidaṃ param |
yadeva cinnabhaḥ svapne tadeva svapnapattanam
]

`v 57 [
na kiṃcitkiṃcanāpīdaṃ dṛśyamasti manāgapi |
kva rajaḥ pūrṇajaladhau kva dṛśyaṃ paramāmbare
]

`v 58 [
taccedaṃ bhāti vā kiṃcittaccinmātramacetyakam |
akacattveva saṃśāntamātmanītthamavasthitam
]

`v 59 [
pūrṇādvai brahmaṇaḥ pūrṇamapyanuddhṛtamuddhṛtam |
ivedaṃ bhāti bhārūpamābhānaṃ paramātmakam
]

`v 60 [
itthaṃ mayi prakathayatyanubhūyamānamapyuccakairbata janasya vimūḍhatāntaḥ |
svapne jagadvapuṣi jāgraditi pratītiṃ nādyāpi yattyajati nāma vidannapi drāk
]