`v 1 [
ekonāśītyadhikaśatatamaḥ sargaḥ 179
śrīvasiṣṭha uvāca |
evaṃ cinmātramevaikaṃ śuddhaṃ sattvaṃ jagattrayam |
saṃbhavantīha bhūtāni nājñabuddhāni kānicit
]

`v 2 [
tasmātkutaḥ śarīrādi vastu sapratighaṃ kutaḥ |
yadidaṃ dṛśyate kiṃcittadapratighamātatam
]

`v 3 [
sthitaṃ cidvyoma cidvyomni śānte śāntaṃ samaṃ sthitam |
sthitamākāśamākāśe jñaptirjñaptau vijṛmbhate
]

`v 4 [
sarvaṃ saṃvinmayaṃ śāntaṃ satsvapna iva jāgrati |
sthitamapratighākāraṃ kvāsau sapratighā sthitiḥ
]

`v 5 [
kva dehāvayavāḥ kvāntraveṣṭanī kvāsthipañjaram |
vyomevāpratighaṃ viddhi dehaṃ sapratighopamam
]

`v 6 [
saṃvitkarau śiraḥ saṃvitsaṃvidindriyavṛndakam |
śāntamapratighaṃ sarvaṃ na sapratighamasti hi
]

`v 7 [
brahmavyomnaḥ svapnarūpasvabhāvatvājjagatsthiteḥ |
idaṃ sarvaṃ saṃbhavati sahetukamahetukam
]

`v 8 [
na kāraṇaṃ vinā kāryaṃ bhavatītyupapadyate |
yadyathā yena nirṇītaṃ tattathā tena lakṣyate
]

`v 9 [
kāraṇena vinā kāryaṃ sadvadityupapadyate |
yathābhāvitamevārthaṃ saṃvidāpnotyasaṃśayam
]

`v 10 [
yathā saṃbhavati svapne sarvaṃ sarvatra sarvathā |
cinmayatvāttathā jāgratyasti sarvātmarūpatā
]

`v 11 [
sarvātmani brahmapade nānānānātmani sthitā |
astyakāraṇakāryāṇāṃ sattā kāraṇajāpi ca
]

`v 12 [
ekaḥ sahasraṃ bhavati yathā hyete kilaindavāḥ |
prayātā bhūtalakṣatvaṃ saṃkalpajagatāṃ gaṇaiḥ
]

`v 13 [
sahasramekaṃ bhavati saṃvidāṃ ca tathā hi yat |
sāyujye cakrapāṇyādeḥ sargairekaṃ bhavedvapuḥ
]

`v 14 [
eka eva bhavatyabdhiḥ sravantīnāṃ śatairapi |
eka eva bhavetkāla ṛtusaṃvatsarotkaraiḥ
]

`v 15 [
saṃvidākāśa evāyaṃ dehaḥ svapna ivoditaḥ |
svapnādrivannirākāraḥ svānubhūtisphuṭo'pi ca
]

`v 16 [
saṃvittirevānubhavātsaivānanubhavātmikā |
draṣṭṭadṛśyadṛśā bhāti cidvyomaikamato jagat
]

`v 17 [
vedanāvedanātmaikaṃ nidrāsvapnasuṣuptavat |
vātaspandāvivābhinnau cidvyomaikamato jagat
]

`v 18 [
draṣṭā dṛśyaṃ darśanaṃ ca cidbhānaṃ paramārthakham |
śūnyasvapna ivābhāti cidvyomaikamato jagat
]

`v 19 [
jagattvamasadeveśe bhrāntyā prathamasargataḥ |
svapne bhayamivāśeṣaṃ parijñātaṃ praśāmyati
]

`v 20 [
ekasyāḥ saṃvidaḥ svapne yathā bhānamanekadhā |
nānāpadārtharūpeṇa sargādau gagane tathā
]

`v 21 [
bahudīpe gṛhe cchāyā bahvyo bhāntyekavadyathā |
sarvaśaktestathaivaikā bhāti śaktiranekadhā
]

`v 22 [
yatsīkarasphuraṇamambunidhau śivākhye vyomnīva vṛkṣanikarasphuraṇaṃ sa
sargaḥ |
vyomnyeṣa vṛkṣanikaro vyatiriktarūpo brahmāmbudhau na tu manāgapi
sargabinduḥ
]