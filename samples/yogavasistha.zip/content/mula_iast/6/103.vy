`v 1 [
tryadhikaśatatamaḥ sargaḥ 103
śrīvasiṣṭha uvāca |
bhāmātraṃ bhānamātraṃ vā śāntaṃ bhāsata eva ca |
cinmātraṃ yadanādyantaṃ tasya nāśaḥ kathaṃ kadā
]

`v 2 [
tāvanmātraṃ ca puruṣaḥ kadācitsa na naśyati |
nadi naśyati cinmātraṃ bhūyo jāyeta kiṃ katham
]

`v 3 [
na cānyadanyaccinmātraṃ kvacitkiṃcana kasyacit |
sarvānubhavasādṛśye kīdṛśī nāma sānyatā
]

`v 4 [
sarvasyaiva himaṃ śītamuṣṇo'gnirmadhuraṃ payaḥ |
cinmātrasyāvadātasya kīdṛganyatvamatra tu
]

`v 5 [
śarīranāśe nāśaśceccinmātrasya taducyatām |
harṣasthāne viṣādaḥ kiṃ maraṇe saṃsṛtikṣaye
]

`v 6 [
na ca nāma śarīrasya nāśe naśyati cinnabhaḥ |
dehe naṣṭe'pi bandhūnāṃ mlecchairdṛṣṭā piśācatā
]

`v 7 [
yāvaccharīrasattā ceccetanasya taducyatām |
śavaḥ kasmānna calati satyakhaṇḍe śarīrake
]

`v 8 [
piśācānubhavo jīvadharmaścettatsa sarvadā |
kiṃ na paśyati kiṃ bandhau mṛte paśyati tattathā
]

`v 9 [
jīvadharmo viśiṣṭaścettādṛśastaṃ `note[tādṛśatvaṃ iti pāṭhaḥ |] naraḥ
katham |
mithyā deśāntaramṛte piśācatvaṃ na paśyati
]

`v 10 [
tasmātsarvātmakatve taccinmātraṃ na niyantritam |
yadyadyatra yathā vetti tattattatrāvagacchati
]

`v 11 [
abādhitaivaikaghanā saṃvidbhavati yādṛśī |
tādṛśyevānubhūtirhi tatsvabhāvo'tra kāraṇam
]

`v 12 [
anyanna saṃbhavatyatra sargādāveva kāraṇam |
yannāma tadidānīṃ syātkathyatāṃ kīdṛśaṃ katham
]

`v 13 [
satyasaṃkalpabrahmasaṃvido'nyatpradhānaparamāṇvādikaṃ sargādau kāraṇaṃ na
saṃbhavatyeva yatkāraṇaṃ brahmātiriktaṃ syāttatkīdṛśaṃ kathaṃ ca tatkāraṇaṃ
idānīṃ matpurato vādibhiḥ kathyatāṃ śrutiyuktibhyāṃ sadya eva nirasiṣyāmītyarthaḥ |
12 |
sargādāveva notpannā na caivādyāvabhāsate |
vikalpaśrīrjagadbhāsā kevalaṃ bhāticinnabhaḥ
]

`v 14 [
ābhāsamātramevedaṃ dṛśyamityavabudhyate |
dṛśyamityavabodhena tadṛte syātkva dṛśyatā
]

`v 15 [
svacamatkāracāturyaṃ cāru cinnabhasā rasāt |
bodhena budhyate dṛśyamityabodhānna budhyate
]

`v 16 [
bodho'bodhaśca tadrūpamevameva nirāmayam |
bhedo'tra vāci na tvarthe tasmānnāstyeva dṛśyatā
]

`v 17 [
yā cāsīddṛśyataiṣāṃ tāṃ viddhi tvamavicāraṇām |
sā cedānīṃ vicāreṇa vinaṣṭātaḥ kva dṛśyate
]

`v 18 [
asminneva dhiyo yatna ātmajñānavicāraṇe |
yatnena paramo'bhyāsaḥ sa lokadvayasiddhidaḥ
]

`v 19 [
avidyopaśamastveṣa jāto'pi bhavatāmiha |
abhyāsena vinā sādho na siddhimupagacchati
]

`v 20 [
nrodvegaṃ saṃparityajya gṛhītvānudinaṃ kṣaṇam |
lokadvayahitaṃ pathyamidaṃ śāstraṃ vicāryatām
]

`v 21 [
vijñātamapyavijñātamātmajñānamidaṃ bhavet |
bhavatāṃ bhūribhāgānāṃ saṃbhūyābhyasanaṃ vinā
]

`v 22 [
yo'yamarthaṃ prārthayate tadarthaṃ yatate tathā |
so'vaśyaṃ tamavāpnoti na cecchānto nivartate
]

`v 23 [
tasmādasmānnivartadhvamasacchāstravicāraṇāt |
śāntiṃ prāpsyatha sacchāstrājjayalakṣmīṃ yathā raṇāt
]

`v 24 [
viveke cāviveke ca vahatyeṣā manonadī |
yatraiva bāhyate yatnāttatraiva sthitimṛcchati
]

`v 25 [
asmācchāstrādṛte śreyo na bhūtaṃ na bhaviṣyati |
tataḥ paramabodhārthamidameva vicāryatām
]

`v 26 [
svayameva vicāryedaṃ paro bodho'nubhūyate |
saṃsārādhvaśramaharo na tvetadvaraśāpavat
]

`v 27 [
yanna pitrā na vā mātrā na cāpi sukṛtaiḥ kṛtam |
śreyastadvaḥ parijñātamidamāśu kariṣyati
]

`v 28 [
bhavabandhamayī sādho viṣameyaṃ viṣūcikā |
ātmajñānādṛte dīrghā na kadācana śāmyati
]

`v 29 [
mahāmohamayī māyā mithyaivāhamiti sthitā |
śāstrārthabhāvanenāśu mucyatāṃ paraśocyatā
]

`v 30 [
ahamiti mithyaiva sthitā mahāmohamayī māyā tatprayuktā parā śocyatā ca mucyatām | 29
|
yāta mā''pātamadhuraṃ vyoma vyomaikarūpiṇīm |
śūnyaṃ vāyuṃ lihanto'ntarlelihānā ivāhayaḥ
]

`v 31 [
āpātamadhuraṃ vyoma śūnyaṃ viṣayajātaṃ lihantaḥ santo vyomaikarūpiṇīmanantāṃ
saṃsṛtiṃ mā yāta lelihānāḥ kṣudhitā rasaśūnyaṃ vāyuṃ lihantaḥ ahayaḥ sarpā iva |
30 |
yānti vo divasāḥ kaṣṭamavijñātagamāgamāḥ |
vyavahāre hi taireva pratipālayatāṃ mṛtim
]

`v 32 [
tāvadāśvāsanaiṣāsti bhavatāṃ bhayabhāginām |
dināni katicidyāvannāyāti maraṇāvadhiḥ
]

`v 33 [
āgacchantyāṃ mṛtau kaṣṭaṃ paritāpamavāpsyatha |
taṃ yatrāṅgāṅgavicchedaḥ śītacandanalepanam
]

`v 34 [
krīṇanti prāṇapaṇyena dhanaṃ mānaṃ ghanabhramāḥ |
yathāśāstraiḥ kathaṃ buddhyā na krīṇantyajaraṃ padam
]

`v 35 [
padaṃ paramayatnena kriyate yaiścidambare |
kathaṃ taiḥ sahyate'jñānaśatrupādaḥ svamūrdhani
]

`v 36 [
nirmānamohamāpannā gatiṃ gacchata mādhamām |
kriyate svātmabodhena mūlakāṣo mahāpadām
]

`v 37 [
pralapantamahorātraṃ yuṣmadarthena māmimam |
yaṃ pradṛśyedamākarṇya svātmanaivātmatārpyatām
]

`v 38 [
adyaiva na cikitsāṃ yaḥ karoti maraṇāpadaḥ |
saṃprāptāyāṃ mṛtau mūḍhaḥ kariṣyati kimāturaḥ
]

`v 39 [
kimadyaivātmajñānena agre kadācitkariṣyāma iti manvānānpratyāha - adyaiveti | 38
|
asmādgranthādṛte grantho nānyaḥ svātmāvabodhane |
nūnamarthakaro grāhyastilastailārthināmiva
]

`v 40 [
ātmajñānamidaṃ śāstraṃ prakāśayati dīpavat |
piteva bodhayatyāśu kānteva ramayatyalam
]

`v 41 [
vidyamānamapi jñānaṃ jñātaṃ śāstragaṇānna yat |
durbodhaṃ madhuraṃ tattu jñāsyantīto na saṃśayaḥ
]

`v 42 [
idamuttamamākhyānaṃ mukhyānāṃ śāstradṛṣṭiṣu |
sukhena bodhadaṃ hṛdyamapūrvaṃ na tu kiṃcana
]

`v 43 [
nānākhyānakathācitraṃ vinodena vicārayet |
idaṃ śāstraṃ paraṃ yāti pumānnāstyatra saṃśayaḥ
]

`v 44 [
yo hyadyāpi na saṃprāptaḥ paṇḍitairavikhaṇḍitaiḥ |
sa itaḥ prāpyate bodhaḥ suvarṇamiva saikatāt
]

`v 45 [
śāstrakartari maṅktavyaṃ na kadācana kutracit |
śāstrārtha eva tannityaṃ yuktiyuktānubhūtide
]

`v 46 [
ajñānānmatsarānmohādavicāribhirekatā |
avahelitaśāstrārthaiḥ kartavyā nātmahantṛbhiḥ
]

`v 47 [
jānāmyeva yathaivemā yadahaṃ tvaṃ yathā dhiyaḥ |
tathā bodhitakāruṇyātsvabhāvo hi mamedṛśaḥ
]

`v 48 [
yuṣmatsaṃvillavaḥ śuddha evaṃ vaktumiha sthitaḥ |
ahaṃ naro na gandharvo nāmaro na ca rākṣasaḥ
]

`v 49 [
saṃvinmātrā bhavanto hi tadbhāvo'styatinirmalaḥ |
sthito'smīti bhavatpuṇyairnanu nāsmi na cāparaḥ
]

`v 50 [
śyāmāyamānā nāyānti yāvanmaraṇavāsarāḥ |
sāraḥ saṃhriyatāṃ tāvadvairasyaṃ vastudṛṣṭiṣu
]

`v 51 [
ihaiva narakavyādheścikitsāṃ na karoti yaḥ |
gatvā nirauṣadhaṃ sthānaṃ sarujaḥ kiṃ kariṣyati
]

`v 52 [
sarvabhāveṣu vairasyaṃ na yāvatsamupāgatam |
bhāvānāṃ bhāvanā tāvattānavaṃ nopagacchati
]

`v 53 [
ātmānamalamuddhartuṃ vāsanātānavādṛte |
nāstyupāyo mahābuddhe kaścanāpi kadācana
]

`v 54 [
bhāvāstu yadi vidyante taddhite vastubhāvanā |
kiṃ tvete naiva santīha śaśaśṛṅgādayo yathā
]

`v 55 [
sarva eva jagadbhāvā avicāritacāravaḥ |
avidyamānasadbhāvā vicārādviśarāravaḥ
]

`v 56 [
prāmāṇikavicāreṣu na vidyante kṛteṣu ye |
kathaṃ santi jagadbhāvāste ke santi sadaiva vā
]

`v 57 [
sarva eva jagadbhāvāḥ kāraṇābhāvato bhṛśam |
sargādāveva notpannā yaccedaṃ bhāti tatparam
]

`v 58 [
pade sarvendriyātīte manaḥṣaṣṭhendriyātmanām |
bhāvānāṃ kāraṇaṃ nāsti manaḥṣaṣṭhendriyātmakam
]

`v 59 [
bhāvānāṃ vividhākhyānāmanākhyaṃ kāraṇaṃ kutaḥ |
kuto vastunyavastutvaṃn vyomanyavyomatā kutaḥ
]

`v 60 [
sākārasya hi sākāraṃ vaṭadhānādivadbhavet |
bījaṃn tadvastu sākāraṃ jāyate'nyatkuto'nyathā
]

`v 61 [
na kiṃcidapi yatrāsti bījamākṛtimanmanāk |
tata ākṛtimadviśvaṃ bhavatīti viḍambanam
]

`v 62 [
kāryakāraṇabhāvādi tasminnahi pare pade |
vācālatvena yannāma kalpyate maurkhyameva tat
]

`v 63 [
sahakārinimittānāmabhāve hi na kāraṇāt |
kāryaṃ bhavedanyadeti bālairapyanubhūyate
]

`v 64 [
tanmātravedanaṃn bhūyaḥ pṛthvyādīnāṃ ca kāraṇam |
kimasti kathyatāṃ chāyā kathamāste vadātape
]

`v 65 [
paramāṇusamūhā ye jagadityapyavāstavam |
śaśaśṛṅgaṃn dhanuḥprakhyamajñānādabhidhīyate
]

`v 66 [
paramāṇusamūhaścetsaṃbhūya kurute jagat |
yadṛcchayaiva tamasi śīryate ca yadṛcchayā
]

`v 67 [
tadaṅgamiṅgate nityaṃ deśe deśe gṛhe g.ehe |
apūrvātma rajaḥ śṛṅgaṃ khātaṃ `note[khyātaṃ it pāṭhaścintyaḥ |] vā
syāddine
dine
]

`v 68 [
na ca taddṛśyate kiṃcitkasya tatkarma tādṛśam |
bhavedvyarthamabhavyasya jaḍāstu paramāṇavaḥ
]

`v 69 [
nābuddhipūrvaṃ tatkarma saṃbhavatyaṅga kasyacit |
buddhipūrvaṃ tu yadvyarthaṃ kuryādunmattako hi kaḥ
]

`v 70 [
jaḍasya buddhi pūrvehā maruto nāsti tāṃ vinā |
na saṃbhavatyaṇucayo nānyatkartopapadyate
]

`v 71 [
vayamātmāna eveme khātmānaḥ khātmakā janāḥ |
tathā sthitā yathā svapne bhavatāṃ svapnamānavāḥ
]

`v 72 [
tasmānna jāyate kiṃcidviśvaṃ nāpi ca vidyate |
itthaṃ cinnabha evācchaṃ prakacatyātmanātmani
]

`v 73 [
viśvākāśaṃ cidākāśe viṣvagviśrāntimāgatam |
spando dravatvaṃ śūnyatvamanile'mbhasi khe yathā
]

`v 74 [
deśāddeśāntaraprāptau nimeṣeṇātidūrataḥ |
saṃvido yadvapurmadhye cidvyomno viddhi tadvapuḥ
]

`v 75 [
sa svabhāvo hi sarveṣāmarthānāṃ te ca tanmayāḥ |
tādṛśāstannabhorūpāstena viśvamato nabhaḥ
]

`v 76 [
svabhāvasya parā vṛttirmanāgevāśu tasya sā |
svabhāvādavibhinnaiva sedaṃ jagaditi sthitā
]

`v 77 [
jagaccinnabhasostasmānna kadācana bhinnatā |
ekameva dvayo rūpaṃ pavanaspandayoriva
]

`v 78 [
deśāddeśāntaraprāptau vido madhye hi yadvapuḥ |
śāntāśeṣaviśeṣātma tanmukhyaṃn netaradviduḥ
]

`v 79 [
sa svabhāvo'ṅga bhūtānāṃ tatra tiṣṭhanti paṇḍitāḥ |
tasmānna vicalantyete nityadhyānāddharādayaḥ
]

`v 80 [
ābhāsākāśamevedaṃ bhāmātramavabhāsanam |
viśvamākārarahitaṃ svabhāvaṃ viduravyayam
]

`v 81 [
na jāyate na mriyate na bhūtvā bhāvi kutracit |
ananyadeva cidvyomnaḥ śūnyatvamiva khājjagat
]

`v 82 [
na viśvamasti naivāsīnna ca nāma bhaviṣyati |
idamābhāsate śāntaṃ cidvyoma paramātmani
]

`v 83 [
cinmātrameva kacati svapne puratayā yathā |
tathaiva jāgradākhye'sminsa svapne kacati svayam
]

`v 84 [
sargādāveva bhāvānāmasattetyasti dehakaḥ |
kutastasmāccharīratvaṃ svapna eva nabhaściteḥ
]

`v 85 [
svayaṃbhvākhyaṃ śarīraṃ svaṃ pūrvaḥ svapno mahāciteḥ |
ita utthānāstadanu svapnātsvapnāntaraṃ vayam
]

`v 86 [
gaṇḍasyopari jātānāṃ sphoṭānāmata eva naḥ |
parameṇa prayatnena na mano nāma yāsyati
]

`v 87 [
brahmaivāsatyapuruṣaḥ satyavaccānubhūyate |
sthitaṃ tataḥprabhṛtyeva na tvalīkamidaṃ tatam
]

`v 88 [
ābrahmastambaparyantamalīkaṃ jāyate jagat |
yathā svapne tathālīkamevamāśu vinaśyati
]

`v 89 [
cidvyomaivaitya viśvatvaṃ yathā svapne vinaśyati |
anuditvaiva viśvatvaṃ jāgradākhye tathaiva ca
]

`v 90 [
anubhūtamalīkaṃ cāpyalīkaṃ satyavatsthitam |
saṃvideva yathā svapne nagarāditayoditā
]

`v 91 [
sākāreva nirākārā sthitā tadvajjagattayā |
saṃvidākāśamākāśādaṇu meroraṇuryathā
]

`v 92 [
kilayattasya nāma syādākāśādaṇutā kutaḥ |
kāraṇābhāvato'nyasya nākāra upapadyate
]

`v 93 [
sargādāveva yo'jāto jāto'yaṃ jagataḥ kutaḥ |
yadeva vedanākāśe puraṃ svapne tadeva naḥ
]

`v 94 [
bhedaḥ svapnādricidvyomnorna śūnyāmbarayoriva |
yadeva cinnabho nāma tadeva svapnapattanam
]

`v 95 [
yadeva spandanaṃ nāma sa eva pavano yathā |
spandāspandaikarūpātmā vāyurvyomopamo yathā
]

`v 96 [
tasmāccinnabha evedaṃ jagadākṛti lakṣyate |
sarvaṃ śūnyaṃ nirālambaṃ bhāsanaṃ cidbivasvataḥ
]

`v 97 [
śāntamevedamakhilaṃ nirastāstamayodayam |
sakṛdvibhātamamalaṃ dṛṣanmaunamanāmayam
]

`v 98 [
tasmādvada kathaṃ bhāvāḥ kuto bhāvāḥ kva bhāvadhīḥ |
kva dvaitaṃ kvaikatā kvāhaṃ kva bhāvāḥ kva ca bhāvanāḥ
]