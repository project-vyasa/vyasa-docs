`v 1 [
caturnavatyadhikaśatatamaḥ sargaḥ 194
śrīrāma uvāca |
sarvātmasarvabhāveṣu yena yena yadā yadā |
yathā bhāti svayaṃbodhastathānubhavati svayam
]

`v 2 [
svabhāva eva tiṣṭhanti sargāḥ saṃmilitā api |
atrāpi svīkṛtā eva nānāratnāṃśavo yathā
]

`v 3 [
atra dṛṣṭamadṛṣṭaṃ ca mitho viśati gacchati |
jagadraśmighanaṃ ratnaṃ nānāratnaghanaṃ yathā
]

`v 4 [
dīpānāmiva sargāṇāṃ bahūnāṃ jvalatāṃ param |
keṣāṃcidastyanubhavo mithaḥ keṣāṃcideva no
]

`v 5 [
apsvapsviva raso'mbhodhāvāvartaramaṇāvanau |
sarge'sti pratyaṇuṃ tasminnāpi sargāstathā kramaḥ
]

`v 6 [
sarvatra sarvato nityaṃ cidghanasyāmbuvedanam |
saṃkhyātuṃ kena śakyante sargādhāraparamparāḥ
]

`v 7 [
yathāvayavitā bhinnā naivāvayavinaḥ kvacit |
śabdabhedādṛte bhinnā na tathā sargatā pare
]

`v 8 [
ekasyānantarūpasya kāraṇābhāvataḥ svayam |
nodeti na ca yātyastaṃ jagadādiḥ svabhāvataḥ
]

`v 9 [
tapantī jñaptireveyamakhaṇḍajñeyatāmimām |
karotyakartṛrūpaiva samālokamivārkabhāḥ
]

`v 10 [
vaitṛṣṇyātsarvabhāvānāṃ samāptyaivākṣayaṃ svayam |
saṃpadyate samādhānaṃ yattannirvāṇamucyate
]

`v 11 [
na buddhyā buddhyate bodho bodhābuddherna bodhyate |
na buddhyate vā tenāpi bodhyo bodhaḥ kathaṃ bhavet
]

`v 12 [
prabuddha eva suptābhaḥ svayaṃbodho vibudhyate |
deśakālādyabhāve'pi madhyāhne'rkātapo yathā
]

`v 13 [
sarvakarmavitṛṣṇānāṃ śāntecchānāṃ prabodhataḥ |
satāmanicchatāmeva nirvāṇaṃ saṃpravartate
]

`v 14 [
prabuddhabodho dhyānasthaḥ svabhāve kevale sthitaḥ |
na kiṃcidapi gṛhṇāti na kiṃcidapi cojjhati
]

`v 15 [
yo yathāsthita evāste paśyandīpa ivākriyaḥ |
amanomānamanano manomananavānapi
]

`v 16 [
vyutthānakāle sa tarhi kathamāste tadāha - ya iti | manomananavānapi
viṣayeṣvāsaṅgābhāvādamanomānamananaḥ ata eva dīpavatprakāśayannapi akriyaḥ | 15
|
vyutthāne viśvarūpākhyamanyatra brahmasaṃjñitam |
sargāsargātma cinmātraṃ satyaṃ sarvatra bhāsate
]

`v 17 [
abhinnabodhasadrūpasvarūpānubhave sthitaḥ |
vyutthitaḥ sanniruddhaśca yaḥ paśyati sa śāmyati
]

`v 18 [
jagatpadārthasārthānāṃ bodhamātraikaniṣṭhatām |
vinā nāstyaparā sattā vyomnaḥ śūnyetarā yathā
]

`v 19 [
śiṣyate sphītabodhānāṃ kevalānantabodhatā |
sāpi svapariṇāmena pareṇāyātyavācyatām
]

`v 20 [
tadviśrāntau parā sattā śiṣyate vā na śiṣyate |
yā kāpyatyantaśāntāṃ na vāggocarameti sā
]

`v 21 [
yā samasya parākāṣṭhā saiva bodhasya sanmayī |
sargastanmaya evātaḥ sakalaṃ śāntamavyayam
]

`v 22 [
nirvāṇāya vitṛṣṇāya svacchaśītalasaṃvide |
spṛhayanti sadā sattāṃ brahmaviṣṇuharā api
]

`v 23 [
sarvārthātmaiva sarvatra sarvadā sarvathoditam |
cetanaṃ śuddhamevāsti nāśo nāsyopapadyate
]

`v 24 [
atyantataptaḥ saṃsāro nirvāṇamatiśītalam |
atiśītalamevāsti taptastveva na vidyate
]

`v 25 [
saṃcetanti śilāntasthā yathālaṃ śālabhañjikāḥ |
anutkīrṇāstathā brahma cetatīdamakhaṇḍitam
]

`v 26 [
yathā cetati saumyāmbukośasthaṃ vīcimaṇḍalam |
tathā cetati kośasthaṃ mahāciccetyamavyayam
]

`v 27 [
avibhakto vibhāgasthairiva śāntairanantakaiḥ |
paramārthāmbarābhogaistvabodhātmatvamantharaiḥ
]

`v 28 [
yairyairyathāsva ātmāntarbhāvitaścetitaściram |
bhogamokṣaprabhedeṣu teṣāṃ teṣāṃ tathoditaḥ
]

`v 29 [
mṛte vāpyamṛte bandhau svapne svapnavibodhinaḥ |
na yathodeti satyākhyā tathā dṛśyeṣu tadvidaḥ
]

`v 30 [
yadidaṃ kila dṛśyādi tacchāntamakhilaṃ śivam |
bhāvite'vagate'pyantariti bhrānteḥ ka udbhavaḥ
]

`v 31 [
sarvathā dehasaṃkhyeṣu vaitṛṣṇyamupajāyate |
samyagbodhe sati svapna ivāpi svārthakādiṣu
]

`v 32 [
vaitṛṣṇyādvardhate bodho bodhādvaitṛṣṇyavardhanam |
paraspareṇa prakaṭe ete kuḍyaprakāśavat
]

`v 33 [
yena bodhena vaitṛṣṇyaṃ dhanadārasutādi vā |
svanūnamapi saṃpannaṃ jāḍyaṃ tatsaṃsthitaṃ tathā
]

`v 34 [
etāvadeva bodhasya bodhatvaṃ yadvitṛṣṇatā |
pāṇḍityaṃ nāma tanmaurkhyaṃ yatra nāsti vitṛṣṇatā
]

`v 35 [
na tu vaitṛṣṇyabodhāḍhyau na parasparavardhitau |
asatyāveva tau nāna naṣṭau citrahutāśavat
]

`v 36 [
paramā bodhavaitṛṣṇyasaṃpattirmokṣa ucyate |
tatrānante pade śānte vasatā ca na śocyate
]

`v 37 [
gataṃ gamyaṃ kṛtaṃ kāryaṃ dṛṣṭaṃ dṛśyamaśeṣataḥ |
yāvatsarvaṃ śivaṃ śāntamekamādyamanāmayam
]

`v 38 [
ātmārāmasya śāntasya vaitṛṣṇyasyānahaṃkṛteḥ `note[vaitṛṣṇyasyeti svārthe
ṣyañi vitṛṣṇasyetyathaḥ | tathaiva pāṭhaḥ kalpanīyo vā |] |
asaṃkalpaiva bhavati sthitiḥ khasyeva nirmalā
]

`v 39 [
sahasrebhyaḥ sahasrebhyaḥ kaścidutthāya vīryavān |
bhinatti vāsanājālaṃ pañjaraṃ kesarī yathā
]

`v 40 [
prāptajyotirbodhaśuddhiḥ paramantaḥprakāśavān |
nīhāraḥ śaradīvāśu svayamevopaśāmyati
]

`v 41 [
jñātajñeyastvasaṃkalpaḥ saṃkalpātiśayāśayaḥ |
avāsano vyavahṛtau vātavatspandate na vā
]

`v 42 [
āsīddhīrānmanaskārairbhrāntimātraikaniścayāt |
yaḥ sarvatra khavadbhāvastadavāsanamāsitam
]

`v 43 [
nirvāsane bhāva udārasattve brahmakhilaṃ dṛśyamiti prabuddhe |
sthiraikanirvāṇamatāvananto mokṣābhidhānaḥ praśamo'bhyudeti
]