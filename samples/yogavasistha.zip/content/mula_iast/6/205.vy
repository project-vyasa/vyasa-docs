`v 1 [
pañcādhikadviśatatamaḥ sargaḥ 205
śrīrāma uvāca |
evaṃ yathaitadbhagavansvapne dṛśyaṃ paraṃ nabhaḥ |
tathaiva jāgratītyatra na cetsaṃdehajālikā
]

`v 2 [
idaṃ me bhagavanbrūhi mahāpraśnamanuttamam |
kathaṃ bhavatyadehā cijjāgratsvapne svadehavat
]

`v 3 [
śrīvasiṣṭha uvāca |
dṛśyaṃ jāgratyatha svapne khādhāraṃ khātmakaṃ khajam |
khaṃ ca nānyatparaṃ jātu saṃdeho'styupapattitaḥ
]

`v 4 [
samastakāraṇākārapratyastamayarūpiṇi |
sargādāveva bhūtāni saṃbhavanti na kānicit
]

`v 5 [
pṛthvyādiniyatastena deho'yaṃ nāsti kiṃcana |
bhūtānyeva kilaitāni dehastāni na santyalam
]

`v 6 [
tena svapnavadābhāsamidaṃ paśyati cinnabhaḥ |
svarūpamātrakacanamākāravadivākulam
]

`v 7 [
bhānamābhānamātratvamidaṃ yattaccidātmanā |
nabhasā svapnaśabdena kathyate jagadākṛtiḥ
]

`v 8 [
yadetadvedanaṃ nāma cidvyomno vyomanirmalam |
etadantaścito rūpaṃ svapno jagaditi sthitam
]

`v 9 [
etasminneva tenātha svabhāvakacane tate |
cidrūpeṇa kṛtāḥ saṃjñāḥ pṛthakpṛthvyādikā imāḥ
]

`v 10 [
cidbhānameva tatsvapnajagacchabdaiḥ prakathyate |
bhānaṃ cāsyāḥ svabhāvaḥ khaṃ tatkadācinna śāmyati
]

`v 11 [
bahvyaḥ sargadṛśo bhinnā brahmaiva brahmakhe ca tāḥ |
śūnyatānabhasī vātastiṣṭhanti ca viśanti ca
]

`v 12 [
śrīrāma uvāca |
sargāṇāṃ koṭayaḥ proktā bhagavanbhavatā kila |
kāścidbrahmāṇḍakośasthāḥ kāścidaṇḍavivarjitāḥ
]

`v 13 [
kāścinmahīkośagatāḥ kāścidākāśasaṃsthitā |
tejaḥkośagatāḥ kāścitkāścitpavanakośagāḥ
]

`v 14 [
kāścidvyomasthabhūpīṭhā ūrdhvādhasthaviniścayāḥ |
budhnākāśādūrdhvakhurā lambamānavanācalāḥ
]

`v 15 [
kāścidvātātmabhūtaughāḥ kāścinnityaṃ tamodharāḥ |
vyomasaṃsthānakāḥ kāścitkāścitkrimikulākulāḥ
]

`v 16 [
kāścidākāśakośasthāḥ kāściccopalakośagāḥ |
kāścitsakuṇḍakośasthāḥ kāścitkhe khagavatsthitāḥ
]

`v 17 [
tāsāṃ madhye yathā hīdaṃ brahmāṇḍaṃ yādṛśaṃ sthitam |
asmākaṃ bhagavaṃstanme brūhi tattvavidāṃ vara
]

`v 18 [
śrīvasiṣṭha uvāca |
yadapūrvamadṛṣṭaṃ vā nānubhūtaṃ na vā śrutam |
tadvarṇyate sudṛṣṭāntairgṛhyate ca tadūhyate
]

`v 19 [
idaṃ tu rāma brahmāṇḍamāgamairmunibhiḥ suraiḥ |
śataśo varṇitaṃ tacca jñātametattvayā'khilam
]

`v 20 [
yathedaṃ bhavatā jñātamāgamairvarṇitaṃ yathā |
sthitaṃ tadetadakhilaṃ kimanyadiha varṇyate
]

`v 21 [
tvajjñātaprakārasyaiva tvāṃ prati varṇanaṃ nāpūrvamiti na yuktamityāha - yatheti |
20 |
śrīrāma uvāca |
kathametadvada brahmansaṃpannaṃ cinmahānabhaḥ |
kiyatpramāṇametadvā kiyatkālaṃ ca vā sthitam
]

`v 22 [
śrīvasiṣṭha uvāca |
anādinidhanaṃ brahma nityamastyetadavyayam |
ādimadhyāntatā nāsti nākārāḥ paramāmbare
]

`v 23 [
brahmākāśamanādyantametadavyayamātatam |
etanmayamidaṃ viśvaṃ viṣvagādyantavarjitam
]

`v 24 [
paramasyāsya cidvyomnaḥ svayaṃ yadbhānamātmani |
tadetadviśvamityuktaṃ svayaṃ tenaiva tanmṛṣā
]

`v 25 [
puruṣasya yathā svapnapurasaṃdarśanaṃ tathā |
tattasya bhānaṃ puravattadidaṃ viśvamucyate
]

`v 26 [
kaṭhinā neha girayo na dravāṇi jalāni ca |
na śūnyametadākāśaṃ kālona kalanātmakaḥ
]

`v 27 [
yadyathā `note[yadyathātmaghanaṃ yatra ityapi pāṭhaḥ |] cāvyayaṃ yatra svataḥ
saṃcetitaṃ citā |
tattathā tatra cittattve alaṃ śailādivatsthitam
]

`v 28 [
aśilaiva śilā svapne nabha evānabho yathā |
bhavettatheha sargādi svapne dṛśyasthitiścitau
]

`v 29 [
anākāraiva cicchāntā svapnavadyatsvacetanam |
vetti tajjagadityuktaṃ taccānākārameva sat
]

`v 30 [
vāyoḥ spando yathāntastho vāta eva nirantaraḥ |
tathedaṃ brahmaṇi brahma na codeti na śāmyati
]

`v 31 [
dravatvamambhasi yathā śūnyatvaṃ nabhaso yathā |
yathā vastuni vastutvaṃ brahmaṇīdaṃ jagattathā
]

`v 32 [
na prayātaṃ na vā''yātamakāraṇamakāraṇāt |
na ca nāsti na vāstīdaṃ bhinnaṃ brahmapade jagat
]

`v 33 [
na cānādi nirābhāsaṃ nirākāraṃ cidambaram |
dṛśaḥ kāraṇamanyasyāḥ kvacidbhavitumarhati
]

`v 34 [
brahma tu kāraṇatvādiyogyaṃ na bhavatyevetyāha - na ceti | anyasyāḥ sargadṛśaḥ |
33 |
tasmādyathāvayavino'vayavāḥ svātmamātrakāḥ |
tathānavayave brahmavyomni vyoma jagatsthitam
]

`v 35 [
sarvaṃ śāntaṃ nirālambaṃ jñaptimātramanāmayam |
neha sattā na vāsattā na ca nānāsti kiṃcana
]

`v 36 [
saṃkalpasvapnanagaranṛttavatsarvamātatam |
sthitameva samaṃ śāntamākāśamajamavyayam
]

`v 37 [
paramacidambarahṛdayaṃ cittvādyatkacati kāntamamalamalam |
tadidaṃ jagaditi kalitaṃ tenaiva tadātmarūpamākalpam
]