`v 1 [
ekonanavatyadhikaśatatamaḥ sargaḥ 189
śrīvasiṣṭha uvāca |
ātivāhikadeho'sau tasyādyasya prajāpateḥ |
kākatālīyavaccittvādyadyathetyādi cetati
]

`v 2 [
tattathā sthitimāyāti ciraṃ saṃvitsvabhāvataḥ |
bata viśvamidaṃ bhātamatrāsatye kutaḥ smayaḥ
]

`v 3 [
draṣṭā'satyamasatyaṃ dṛgasatyaṃ darśanaṃ tatam |
satyamevāthavā sarvaṃ brahmaivātmatayā tayā
]

`v 4 [
śrīrāma uvāca |
ityātivāhikālokaḥ sa tasyādyaprajāpateḥ |
kaṭhinatvaṃ kathaṃ yātaḥ kathaṃ svapnasya satyatā
]

`v 5 [
śrīvasiṣṭha uvāca |
ātivāhika ālokaḥ svata evānubhūyate |
sadānavarataṃ tena sa evābhāti puṣṭavat
]

`v 6 [
yathā svapnasya puṣṭatvaṃ cirānubhavanocitam |
atisatyamivābhāti svātivāhikatā tathā
]

`v 7 [
ātivāhikadehasya cirasvānubhavodaye |
ādhibhautikatābuddhirudeti mṛgavārivat
]

`v 8 [
jagatsvapnabhramābhāsaṃ mṛgatṛṣṇāmbuvatsthitam |
asadevedamābhāti satyapratyayakāryapi
]

`v 9 [
ātivāhikarūpāṇāmādhibhautikatā svayam |
asatī satyavaddūramarvāgdarśibhirarthitā
]

`v 10 [
ayaṃ sohamidaṃ tanma imā girinabhodiśaḥ |
iti mithyābhramo bhāti bhāsvarasvapnaśailavat
]

`v 11 [
ātivāhikadeho'sau sraṣṭurādyasya bhāvitaḥ |
ādhibhautikatāṃ caitatpiṇḍākāraṃ prapaśyati
]

`v 12 [
cinnabhaścetanaṃ tyaktvā brahmāhamiti paśyati |
ayaṃ deho'yamādhāra iti badhnāti bhāvanām
]

`v 13 [
asatye satyabuddhyaiva baddho bhavati bhāvanāt |
bahuśo bhāvayatyantarnānātvamanudhāvati
]

`v 14 [
śabdānkaroti saṃketaṃ saṃjñāśca spandanāni ca |
omityukte tato vedāñchabdarāśīnpragāyati
]

`v 15 [
taireva kalpayatyāśu vyavahāramitastataḥ |
mano hyasau kalpayati yaccetati tadeva hi
]

`v 16 [
yo hi yanmaya evāsau sa na paśyati tatkatham |
asatyaiva jagadbhrāntirevaṃ prauḍhimupāgatā
]

`v 17 [
ābrahmaṇo mudhā bhāti cirasvapnendrajālavat |
ityātivāhikasyeyamādhibhautikatocitā
]

`v 18 [
ādhibhautikatā nāsti kācitkiṃcidapi kvacit |
ātivāhikataivaināmabhyāsādyāti bhāvanām
]

`v 19 [
mūlādevaivamāyāto mithyānubhavanātmakaḥ |
moho brahmaṇa evāyamityastyeṣa mahātmanām
]

`v 20 [
evamitthaṃ daśā rāma piṇḍabandhaḥ kva vidyate |
bhrāntirevedamakhilaṃ brahmaivābhātameva vā
]

`v 21 [
na śāśvatādanyadihāsti kāraṇānna kāraṇaṃ tatkhalu kāryatāṃ vinā |
na kāryatākāraṇatādisaṃbhavo'styanāmaye tatkimapīdamātatam
]