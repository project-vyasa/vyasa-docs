`v 1 [
ekatriṃśaḥ sargaḥ 31
śrīvasiṣṭha uvāca |
sarvātmani cidābhāse tadevāśvanubhūyate |
saṃvedyate yadevāntarasatyaṃn vastvavastu vā
]

`v 2 [
tadevābhyāsataḥ pūrvaṃ bāhyārthānubhavātmanā |
sphuratīva bahiṣṭvena svasvapno'tra nidarśanam
]

`v 3 [
cidrūpaṃ sarvametacca cidacchā gaganādapi |
ciccinoti cidevāto naitatkiṃcana kutracit
]

`v 4 [
na nāśo nāsti nānartho na janmamaraṇe na kham |
na śūnyatā na nānāsti sarvaṃ brahmaiva naiva ca
]

`v 5 [
nāśe jagadahaṃtvāderna kiṃcidapi naśyati |
asataḥ kila nāśo'pi svapnādeḥ kiṃ na naśyati
]

`v 6 [
mithyāvabhāse saṃkalpanagare kaiva naṣṭatā |
tathā jagadahaṃtvādau nāśo nāsati vidyate
]

`v 7 [
kuto jagadupālambha iti cettadavastuni |
na nirṇayaḥ saṃbhavati khapuṣpāṇāṃ kimucyate
]

`v 8 [
nirṇaya eṣa evātra yadaśeṣamabhāvayan |
yathāśitaṃ yadācāraṃ pāṣāṇa iva tiṣṭhati
]

`v 9 [
jagatsaṃkalpamātrātma tatra te'rthayutaṃ kṣaṇāt |
śāmyatyaśeṣeṇetyeva nirṇayaḥ sargavibhrame
]

`v 10 [
sarge'nargala evāyaṃ brahmātmakatayākṣayaḥ |
anyathā tu na sargo'yamasti nāsti ca santi vā
]

`v 11 [
yeṣāṃ ca vidyate sargaḥ svapnapuṃsāmivāsatām |
sa sargaḥ puruṣāste ca mṛgatṛṣṇāmbuvīcivat
]

`v 12 [
asatāmeva sadbhāvamiva yeṣāmupeyuṣām |
na vayaṃ nirṇayaṃn vidmo vandhyāputragirāmiva
]

`v 13 [
ata eva jīvajagadrūpāṇāmanirṇeyatvādanirvacanīyatvamuktamityāha - asatāmeveti |
12 |
paripūrṇārṇavaprakhyā kāpyapūrvaiva pūrṇatā |
tajjñānāṃ draṣṭṭadṛśyāṃśadṛṣṭau na hi patanti te
]

`v 14 [
acalā iva nirvātā dīpā iva samatviṣaḥ |
sācārā vā nirācārāstiṣṭhanti svasthameva te
]

`v 15 [
āpūrṇaikārṇavaprakhyā kāpyantaḥ pūrṇatoditā |
antaḥśītalatā jñaptirjñasyāpūrvaiva lakṣyate
]

`v 16 [
vāsanaiveha puruṣaḥ prekṣitā sā na vidyate |
tāṃ ca na prekṣate kaścittataḥ saṃsāra āgataḥ
]

`v 17 [
anālokanasiddhaṃ yattadālokānna vidyate |
kṛṣṇādyanupalambho'tra dṛṣṭāntaḥ spaṣṭaceṣṭitaḥ
]

`v 18 [
bhūtāni dehamāṃsādi taccāsadvibhramo jaḍaḥ |
buddhyahaṃkāracetāṃsi tanmayānyeva netarat
]

`v 19 [
bhūtādimayatāṃ tyaktvā buddhyahaṃkāracetasām |
atyantaṃ sthitirabhyeti yadi tanmuktatoditā
]

`v 20 [
cicchliṣṭā cetyaniṣṭhatvāttādṛśyevātra kāstitā |
tasmātkeva kutaḥ kutra vāsanā kiṃsvrūpiṇī
]

`v 21 [
yasya yaiṣa bhramaḥ so'sanprekṣayāsanna lakṣyate |
mṛgatṛṣṇāmbuvattena saṃsāraḥ kasya kaḥ kutaḥ
]

`v 22 [
tadevaṃ tarhi tasya syāditi cittodayo hi yaḥ |
punaḥ sa eva saṃsāravibhramaḥ saṃpravartate
]

`v 23 [
tasmātsarvamanāśritya vyomavatsamupāsyatām |
apunaḥsmaraṇaṃ śreya iha vismaraṇaṃ param
]

`v 24 [
neha draṣṭā na bhoktāsti nā'stitā na ca nāstitā |
yathāsthitamidaṃ śāntamekaṃ spandi sadābdhivat
]

`v 25 [
sarvaṃ dṛśyaṃ jagadbrahma sadityavagate sphuṭam |
jalaśoṣādivodeti bimbabimbikṣaye śivam
]

`v 26 [
śāntatāvyavahāro vā rāgadveṣavivarjitaḥ |
viśrāntasya pare tattve dṛśyate samadarśinaḥ
]

`v 27 [
athavā śāntataivāsya nirvāṇasyāvaśiṣyate |
nirvāsanaḥ kila muniḥ kathaṃ vyavaharatvasau
]

`v 28 [
yāvattvasya na nirvāṇaṃ paripoṣamupāgatam |
tāvadvyavaharatyastarāgadveṣabhayodayaḥ
]

`v 29 [
vītarāgabhayakrodho nirvāṇaḥ śāntamānasaḥ |
śilevāpyaśilībhūto munistiṣṭhati nityaśaḥ
]

`v 30 [
kośe'sti padmabījasya yathā sarvābjinī tathā |
ananyā svapnavibhrāntirātmanyasti na bāhyatā
]

`v 31 [
bāhyatābhāvanādbāhyamātmaivātmatvabhāvanāt |
bhavatīdaṃ pare tattve bhāvanaṃn tattadeva hi
]

`v 32 [
yāntaḥ svapnādivibhrāntiḥ saiveyaṃ bāhyatoditā |
manāgapyanyatā nātra dvibhāṇḍapayasoriva
]

`v 33 [
sthairyāsthairye tathaivātra bhrāntimātramey tate |
ādhārādheyate te dve yathā jalataraṅgate
]

`v 34 [
svapnādāvātmano'nyatvajñānādanyatvavedanam |
ananyatāvabodhe tu tadananyanna codayi
]

`v 35 [
kalanārahitaṃ śāntaṃ yadrūpaṃ paramātmanaḥ |
bhavatyasau tattadbhāvādatadbhāvānna tadbhavet
]

`v 36 [
svapnādijñānasaṃśāntau yadrūpaṃ śuddhamaiśvaram |
na tadasti na tannāsti na vāggocarameva tat
]

`v 37 [
ātyantikabhrāntilaye yukta evāvagacchati |
svarūpaṃ nopadeśasya viṣayo viduṣo hi tat
]