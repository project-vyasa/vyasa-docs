`v 1 [
ekonaṣaṣṭitamaḥ sargaḥ 59
śrīrāma uvāca |
anantaraṃ nabhaḥkośakuṭīkoṭarato mune |
tava dhyānātprabuddhasya vṛttaṃ varṣaśatena kim
]

`v 2 [
śrīvasiṣṭha uvāca |
tato dhyānātprabuddho'haṃ śrutavāṃstatra niḥsvanam |
mṛdu vyaktapadaṃ hṛdyaṃ na ca vācyanugo yataḥ
]

`v 3 [
strīsvabhāvādiva mṛdu madhuraṃ vā ninādi vā |
svalpāṅgatvādanirhrādi mayā tadvākyamūhitam
]

`v 4 [
indindirarutākāraṃ tantrīraṇitarañjanam |
na rodanaṃ ca paṭhanaṃ visakośasamasvanam
]

`v 5 [
tadākarṇyāśu tatredamahaṃ cintitavānatha |
śābdikānvīkṣaṇātpaśyandiśo daśa savismayaḥ
]

`v 6 [
vyomno'yaṃ siddhasaṃcaramārgaśūnyānyanantaram |
bhāgo yojanalakṣāṇi samatikramya saṃsthitaḥ
]

`v 7 [
tadihedṛgvidhasya syātkutaḥ śabdasya saṃbhavaḥ |
śābdikaṃ na ca paśyāmi yatnenāpi vilokayan
]

`v 8 [
anantamidamāśūnyaṃ puro me nirmalaṃ nabhaḥ |
iha bhūtaṃ prayatnena prekṣyamāṇaṃ na dṛśyate
]

`v 9 [
yadeti cintayitvāhaṃ bhūyobhūyo vilokayan |
śabdeśvaraṃ na paśyāmi tadā cintitavānidam
]

`v 10 [
śabdeśvaraṃ śabdoccāraṇasamarthaṃ yadā na paśyāmi tadā | idaṃ vakṣyamāṇam | 9
|
ākāśa eva bhūtvāhamākāśenaikatāṃ gataḥ |
ākāśaguṇaśabdārthānkaromyākāśakośake
]

`v 11 [
ahaṃ prathamamupādhityāgena cidākāśa eva bhūtvā
tadadhyastāvyākṛtākāśenaikatāṃ gataḥ saṃstatkāryabhūtākāśaguṇaṃn śabdaṃ
tadarthāṃśca tasminnākāśakośake vidyamānānsākṣātkaromi | anubhaviṣyāmīti yāvat |
10 |
dehākāśamiha sthāpya dhyāneneha yathāsthitam |
cidākāśavapurvyomnā yāmyaikyaṃ vārivāmbunā
]

`v 12 [
cintayitvetyahaṃ tyaktuṃ dehaṃ padmāsanasthitaḥ |
āsaṃ samādhimādhātuṃ punarāmīlitekṣaṇaḥ
]

`v 13 [
tyaktvā bāhyārthasaṃsparśānaindriyānāntarānapi |
cittākāśo'hamabhavaṃ saṃvitspandamayātmakaḥ
]

`v 14 [
kramāttadapi saṃtyajya buddhitattvapadaṃ gataḥ |
saṃpanno'haṃ cidākāśe jagajjālaikadarpaṇaḥ
]

`v 15 [
tatastena svabhāvena bhūtavyomaikatāmaham |
saṃprayāto'mbunaivāmbu saurabhaṃ saurabheṇa vā
]

`v 16 [
saṃpanno'tha mahākāśaṃ vyāpyānanto'tha sarvagaḥ |
anākāro'pyanādhāraḥ sarvārthādhāratāṃ gataḥ
]

`v 17 [
ahaṃ trailokyavṛndāni saṃsārāṇāṃ śatāni ca |
tatra brahmāṇḍalakṣāṇi paśyāmyagaṇitānyapi
]

`v 18 [
parasparamadṛṣṭāni mithaḥ khānyamalāni ca |
nānācāravicārāṇi śūnyānyeva parasparam
]

`v 19 [
svapnarūpāṇi suptānāṃ tulyakālaṃ nṛṇāmiva |
mahārambhānumṛṣṭāni śūnyāni ca parasparam
]

`v 20 [
tatra dṛṣṭāntamāha - svapneti | tulyakālaṃ suptānāṃ janānāṃ svapnarūpāṇīva |
ekadṛśā mahārambhāṇyaparadṛśā anumṛṣṭāni | ata eva śūnyānyaśūnyāni ca |
19 |
jāyamānāni naśyanti vardhamānāni bhūriśaḥ |
vartamānānyatītāni bhaviṣyanti ca sarvaśaḥ
]

`v 21 [
anekacitrajālāni mahābhittīni khāni ca |
manasevograrājyāni kṛtāni vividhairjanaiḥ
]

`v 22 [
nirāvaraṇarūpāṇi tathaikāvaraṇāni ca |
pañcāvaraṇayuktāni ṣaḍekāvaraṇāni ca
]

`v 23 [
daśāvaraṇacitrāṇi ṣoḍaśāvaraṇāni ca |
caturviṃśatyāvṛtīni ṣaṭtriṃśatkhāvṛtāni ca
]

`v 24 [
śūnyāni bhūtapūrṇāni pañcabhūtamayānyapi |
ekapṛthvyādibhūtāni catuḥpṛthvyādikāni ca
]

`v 25 [
triḥpṛthvyādīni cānyāni dviḥpṛthvyādīnyathāpi ca |
tathā saptamahābhūtānyekajātimayāni ca
]

`v 26 [
tvādṛśānubhavābhogaviruddhātidaśāni tu |
tathā nityāndhakārāṇi sūryādirahitāni ca
]

`v 27 [
tathā mīlitasargāṇi ekanāthāvṛtāni ca |
vilakṣaṇaprajeśāṃśavicitrāravanti ca
]

`v 28 [
tathā nirvedaśāstrāṇi niḥśāstrāṇi tathaiva ca |
kṛmikramasamārambhadevādiprāṇimanti ca
]

`v 29 [
jātyā tu pāramparyeṇa saṃketācāravanti ca |
tathā nityaprakāśāni jvalitāgnimayāni ca
]

`v 30 [
tathā jalaikapūrṇāni pavanaikamayāni ca |
stabdhāni paramākāśe vahanti ca tathāniśam
]

`v 31 [
jāyamānāni puṣyanti paripuṣṭāni cābhitaḥ |
tiryaggacchanti cānyāni pūrṇasarvamayānyapi
]

`v 32 [
devamātraikasargāṇi naramātramayāni ca |
daityavṛndamayānyeva kṛminirvivarāṇi ca
]

`v 33 [
antarantastadantaśca svakośe'pyaṇukaṃ prati |
jātāni jāyamānāni kadalīdalapīṭhavat
]

`v 34 [
aṇukaṃ paramāṇumapi prati antarantastadantaśca kalpite svakośe'pi jātānītyādyanvayaḥ |
33 |
parasparamadṛṣṭāni nānubhūtāni vai mithaḥ |
sainikasvapnajālāni jātānīva mahāntyapi
]

`v 35 [
vividhānyapyanantāni svacchākāśātmakānyalam |
anyonyamanyavṛttīni na mitho'nyasthitīni ca
]

`v 36 [
mithaścānyānyaśāstrāṇi mitho'nantāni yāni ca |
anyonyasanniveśāni mitho'nyonyāni yāni ca
]

`v 37 [
yāni mithaḥ anantāni aparicchedyabrahmasvabhāvāni | dharmānantyādvā anantāni |
bhede'pyanyonyasyeva saṃniveśo yeṣāṃ tāni | pratyabhijñāyāmanyonyātmakāni ca | 36
|
anyonyaṃn paralokāni mithaḥ siddhapurāṇi ca |
anyādṛśamahābhūtānyanyādṛgdiggirīṇi ca
]

`v 38 [
tvādṛśānubhavehānāmagamyābhyāgatāni ca |
asamañjasarūpāṇi kathyamānāni mādṛśaiḥ
]

`v 39 [
aṇuvatseṣyamāṇāni cidādityāṃśumaṇḍale |
paramārthaśriyo vyomni raśmijālāni kuṇḍale
]

`v 40 [
kānicittāni tānyeva bhūtvā bhūtvā bhavatyalam |
kānicittādṛśānyeva jātāni vanaparṇavat
]

`v 41 [
anyonyatvācca sadṛśānyanyāni sadṛśānyapi |
kaṃcitkālaṃ susadṛśānyanyānyeva ca kānicit
]

`v 42 [
phalāni tānyanantāni paramārthamahātaroḥ |
ananyānyeva cānyāni tanmayānyeva vai tataḥ
]

`v 43 [
kānicitsvalpakalpāni dīrghakalpāni kānicit |
anyānyaniyataṃ bhūri niyataṃ bhūri kānicit
]

`v 44 [
anyānyajñātakālāni yadṛcchāvaśataḥ svayam |
jāyamānāni puṣṭāni susthirāṇi sthitāni ca
]

`v 45 [
tāni śūnyatvajālāni paramākāśakośake |
aparijñātakālāni rūḍhānyajñātadoṣake
]

`v 46 [
abdhyarkākāśamevādi śatairāvalitānyalam |
ciccamatkārakhe svapnajālānyābhānti cāvilam
]

`v 47 [
anubhūterbhramātmatvātkāraṇānāmabhāvataḥ |
pṛthvyādīnāmahetūnāmatyantaṃ santyasanti ca
]

`v 48 [
mṛgatṛṣṇāmbubharavaddvicandravyomavarṇavat |
saṃpannāni na satyāni satyānyapyanubhūtitaḥ
]

`v 49 [
citsaṃkalpanabhasyeva bhāsamānāni bhūriśaḥ |
vāsanāvātanunnāni viluṭhantyātmaceṣṭitaiḥ
]

`v 50 [
surāsurādimaśakā bahuśodumbaradrume `note[bahuśodumbara ityārṣaḥ saṃdhiḥ |
] |
phalāni rasapūrṇāni ghūrṇamānāni mārutaiḥ
]

`v 51 [
abhijātasvabhāvasya sargārambhakarasya ca |
śuddhacittattvabālasya saṃkalpanagarāṇi khe
]

`v 52 [
tvamahaṃn sa idaṃ ceti dhiyā baladṛḍhānyalam |
saṃpannānyarkadīptyeva paṅkakrīḍanakāni ca
]

`v 53 [
vṛttāni rasaśālinyā niyatyā nityatṛptayā |
vanānyugraphalānīva vasantarasalekhayā
]

`v 54 [
mahākartṝṇyakartṝṇi na kṛtānyeva khāni vā |
svayaṃn saṃpannarūpāṇi cidvyomnyeva kṛtāni vā
]

`v 55 [
paramārthamayānyeva tadanyadvoditānyapi |
alabdhānyeva labdhāni sadā'santyeva santi ca
]

`v 56 [
caturdaśadaśaikādividhabhūtagaṇāni ca |
punastānyeva tānyantaranyānyanyānyatho bahiḥ
]

`v 57 [
narakasvargapātālabandhumitramayānyapi |
mahārambhamayānyeva śūnyāni paramārthataḥ
]

`v 58 [
kṣīrāmbudherjalānīva snehasārāṇi sarvataḥ |
taraṅgabhaṅgurāṇyantarbahiścāvṛttimanti ca
]

`v 59 [
ābhāsamātrarūpāṇi tejasyātmavivasvataḥ |
jātānīva svatastāni spandanāni nabhasvataḥ
]

`v 60 [
vṛkṣarūpāṇi patrāṇāṃ buddhyahaṃkāracetasām |
asatāmapyasantyeva svapne nyastanṛṇāmiva
]

`v 61 [
purāṇavedasiddhāntakalpanātalpapāliṣu |
ghaninidrāṇi suptāni bibhranti śavatāmiva
]

`v 62 [
paramārthamahāraṇye cidgandharvakṛtāni vai |
sūryadīpakadīptāni gṛhāṇi gahanātmani
]

`v 63 [
prajāyamānāni nabhasyanante viśīryamāṇāni ca nirnimittam |
tadā tvahaṃ vai timirākṣadṛṣṭakeśoṇḍrakānīva jagantyapaśyam
]