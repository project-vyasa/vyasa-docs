`v 1 [
ekonatriṃśaḥ sargaḥ 29
śrīvasiṣṭha uvāca |
nityamantarmukhastiṣṭha vītarāgo vivāsanaḥ |
cinmātramamalaṃ śāntaṃ karma sarvatra bhāvayan
]

`v 2 [
ākāśaviśadaḥ prājñaścinmātraikaghanasthitiḥ |
samaḥ saumyaḥ samānandaḥ sa brahmā''bṛṃhitāśayaḥ
]

`v 3 [
śokeṣvāpatsu ghoreṣu saṃkaṭeṣvavaṭeṣu ca |
yathāprāpteṣu sarveṣu kharveṣūnnatimatsu ca
]

`v 4 [
yathākramaṃ yathādeśaṃ kuru duḥkhamaduḥkhitaḥ |
bāṣpakrandādiparyantaṃ dvandvayuktasukhāni ca
]

`v 5 [
samāgameṣu kāntānāmutsaveṣūdayeṣu ca |
ānandaṃ bhaja saumyātmā vāsanākrāntamūḍhavat
]

`v 6 [
bhūtāni mṛtyukāryeṣu saṃgrāmādiṣu nirdaha |
dāvānalastṛṇānīva vāsanākrāntamūḍhavat
]

`v 7 [
kramāgateṣvakhinno'rthaṃ bakavaccintayārjaya |
arthopārjanakāryeṣu vāsanākrāntamūḍhavat
]

`v 8 [
balādvidalayāśeṣānarīnariniṣūdana |
vāto riktānivāmbhodān vāsanākrāntamūḍhavat
]

`v 9 [
janeṣu karuṇārheṣu dhairyaṃ kuru mahātmasu |
ātmārāmamanā maunī vāsanākrāntamūḍhavat
]

`v 10 [
mudito bhava harṣeṣu duḥkheṣu bhava duḥkhitaḥ |
karuṇāṃ kuru dīneṣu bhava vīreṣu vīryavān
]

`v 11 [
antarmukhaḥ sadānandaḥ svātmārāmatayānvitaḥ |
yaḥ karoti śamodārastatra kartāsi nānagha
]

`v 12 [
ātmabhāvanayā sādho nityamantarmukhasthiteḥ |
vajradhārāpi te rāma patitā yāti kuṇṭhatām
]

`v 13 [
saṃkalpakalanonmukte svasaṃvinmātrakoṭare |
yastiṣṭhatyātmani svairamātmārāmo maheśvaraḥ
]

`v 14 [
na taṃ bhindanti śastrāṇi na dahanti hutāśanāḥ |
na kledayanti vārīṇi śoṣayanti na mārutāḥ
]

`v 15 [
sustambhamajamāliṅgya svātmānamajarāmaram |
tiṣṭhāvaṣṭabhya dhīrātmā sustambhamiva mandiram
]

`v 16 [
jagadvṛkṣapadārthaughapuṣpāmodaśriyaṃ parām |
saṃvidaṃ saṃvidaḥ svasthāmāsvāntarmukhamacyutam
]

`v 17 [
antarmukhatayā nityaṃ kāryamāharatāṃ bahiḥ |
jīvatāmapi nodeti vāsanā dṛṣadāmiva
]

`v 18 [
punaḥ prasaraṇonmuktamantaḥsuptaṃ manaḥ kuru |
kurvansarvāṇi karmāṇi kūrmāṅgavadavṛttimān
]

`v 19 [
antarvṛttivihīnena bahirvṛttimateva ca |
suptaprabuddhaprāyeṇa kāryamācara cetasā
]

`v 20 [
bālamūkādivijñānavadantastyaktavāsanam |
bhavataḥ kurvataḥ kāryaṃ khavaccittaṃ na lipyate
]

`v 21 [
vṛttityāgavilīnena kiṃcitprasaratā bahiḥ |
antaratyantasuptena cetasā tiṣṭha vijvaraḥ
]

`v 22 [
asaṃkalpakalaṅkāyāṃ jñānāccittakṣayodaye |
śuddhāyāṃ saṃvidi sthitvā kuru mā kuru vānagha
]

`v 23 [
suṣuptasamayā vṛttyā jāgradvyavaharanvrajan |
gṛhāṇa mā kiṃcidapi mā vā kiṃcitparityaja
]

`v 24 [
jāgratyapi suṣuptaścejjāgarṣi ca suṣuptake |
jāgratsuṣuptayoraikyāttadastyasi nirāmayaḥ
]

`v 25 [
evamādyantarahitamabhyāsena śanaiḥ śanaiḥ |
padamāsādayādvandvamatītaṃ sarvavastutaḥ
]

`v 26 [
na ca dvaitaṃ na caivaikyaṃ jagadityeva niścayī |
paramāmehi viśrāntimākāśaviśadāśayaḥ
]

`v 27 [
śrīrāma uvāca |
yadyevaṃ muniśārdūla tadahaṃpratyayātmakaḥ |
bhavāneveha kiṃ tāvadvasiṣṭhākhyaḥ sthito vada
]

`v 28 [
śrīvālmīkiruvāca |
rāghave gadati tvevaṃ vasiṣṭho vadatāṃ varaḥ |
tūṣṇīmeva muhūrtārdhamatiṣṭhatspaṣṭaceṣṭitaḥ
]

`v 29 [
tasmiṃstūṣṇīṃ sthite kiṃ syāditi sabhye mahājane |
patite saṃśayāmbhodhau rāmaḥ punaruvāca ha
]

`v 30 [
kimarthaṃ bhagavaṃstūṣṇīṃ bhavānahamiva sthitaḥ |
na so'sti jagatāṃ nyāyaḥ satāṃ yo nottarakṣamaḥ
]

`v 31 [
śrīvasiṣṭha uvāca |
na me vaktumaśaktatvādyuktikṣaya upasthitaḥ |
kiṃtu praśnasya koṭyāsya tūṣṇīmevānaghottaram
]

`v 32 [
dvividho bhavati praṣṭā tattvajño'jño'thavāpi ca |
ajñasyājñatayā deyo jñasya tu jñatayottaraḥ
]

`v 33 [
etāvantamabhūtkālaṃ bhavānajñātatatpadaḥ |
bhājanaṃ savikalpānāmuttarāṇāṃ mahāmate
]

`v 34 [
tattvajñastvadhunā jāto viśrāntaḥ parame pade |
yogyo na savikalpānāmuttarāṇāmasi sphuṭam
]

`v 35 [
yāvānkaścitkilollekho vāṅmayo vadatāṃ vara |
sūkṣmārthaḥ paramārtho vā bahuralpataro'pi vā
]

`v 36 [
pratiyogivyavacchedasaṃkhyātītādivibhramaiḥ `note[atītādibhirbhramaiḥ iti
mudritapāṭhaṣṭīkākartrasaṃmataḥ |] |
sa ca sarvo'nvitaḥ sādho bhā iva trasareṇubhiḥ
]

`v 37 [
uttaraṃ sakalaṅkaṃ ca tajjño nārhati sundara |
nākalaṅkā ca vāgasti tvaṃ ca tajjñataraḥ sthitaḥ
]

`v 38 [
yathābhūtaṃ ca vaktavyaṃ jñasyāntevāsino mayā |
yathābhūtaṃ viduḥ kāṣṭhamaunamantavivarjitam
]

`v 39 [
avicārātsasaṃkalpaṃ maunamāhuḥ paraṃ padam |
tadeva tava tajjñasya dattaḥ sundara uttaraḥ
]

`v 40 [
yanmayo hi bhavatyaṅga puruṣo vakti tādṛśam |
jñeyamātramayaścāhaṃ vāgatīte pade sthitaḥ
]

`v 41 [
vāgatītapadastho hi kathaṃ gṛhṇāti vāṅmalam |
avācyaṃ vacmi no tena vāgdhi saṃkalpanāṅkitā
]

`v 42 [
śrīrāma uvāca |
vāci ye ye pravartante tānanādṛtya doṣakān |
pratiyogivyavacchedipūrvakānvada ko bhavān
]

`v 43 [
śrīvasiṣṭha uvāca |
evaṃ sthite rāghava he yathābhūtamidaṃ śṛṇu |
kastvaṃ ko'haṃ jagadvā kimiti tattvavidāṃ vara
]

`v 44 [
ahaṃ tāvadayaṃ tāta cidākāśo nirāmayaḥ |
cetyasaṃvedyarahitaḥ sarvasaṃkalpanātigaḥ
]

`v 45 [
svacchaṃ cidākāśamahaṃ bhavānākāśameva ca |
jagaccākāśamakhilaṃ sarvamākāśamātrakam
]

`v 46 [
śuddhajñānaikarūpātmā śuddhajñānamayātmani |
anyasaṃviddṛśonmuktaḥ svānyadvaktuṃ na vedmyaham
]

`v 47 [
svapakṣodbhāvanaparā ahaṃtātmaikavardhanam |
mokṣārthamapyudyamino nayanti śataśākhatām
]

`v 48 [
jīvato'pyupaśāntasya vyavahāravato'pi ca |
śavavadyadavasthānaṃ tadāhuḥ paramaṃ padam
]

`v 49 [
abahiḥsādhanaṃ śāntamanantaḥsādhanaṃ samam |
na sukhaṃ nāsukhaṃ nāhaṃ nānyadityādi taṃ śivam
]

`v 50 [
muktatāyā ahaṃteyamabhāvo bhāvanaṃ kva ca |
tayaivānviṣyate seti jātyandhaścitramīkṣate
]

`v 51 [
spandane'spandane caiva yatpāṣāṇavadāsitam |
ajaḍasyaiva tadviddhi nirvāṇamajaraṃ padam
]

`v 52 [
tacca nānyo vijānāti svayamevānubhūyate |
lokaiṣaṇāviraktena jñena jñatvamivātmani
]

`v 53 [
ataḥ svaprakāśatvameva pariśeṣātsiddhamityāha - tacceti | laukikātmani prasiddhaṃ
jñatvaṃ ghaṭādisphūrtiphalamiva na hi tajjñānāntaravedyamanavasthāpātāditi bhāvaḥ |
52 |
tatrāhaṃtā na ca tvatta nānahaṃtā na cānyatā |
kevalaṃ kevalībhāvo nirvāṇamamalaṃ śivam
]

`v 54 [
cetyonmukhatvamevāhuścetanasyāsya cetanam |
eṣa eva ca saṃsāro bandhaḥ kleśāya bhūyase
]

`v 55 [
cetanasyācetanatvamacetyonmukhatātmakam |
mokṣaṃ viddhi paraṃ śāntaṃ padamavyayameva ca
]

`v 56 [
dikkālādyanavacchinne śānte śāntātmani sthite |
cetyaṃ na saṃbhavatyeva kaḥ kiṃ cetayate katham
]

`v 57 [
saṃkalpaḥ svapnadṛśye'ntaḥ saṃvinmātrātmatāṃ vinā |
yathānyavadbhavedbhūpāstathaivāsminbahirgate
]

`v 58 [
manobuddhyādayaścaite saṃvinmātrānurūpiṇaḥ |
manobuddhyādiśabdārthabhāvitāstu jaḍātmakāḥ
]

`v 59 [
saṃvinmātre same svacche sabāhyābhyantare tate |
abhinne bhedabuddhirvā kimanarthāya jṛmbhate
]

`v 60 [
saṃvinmātrasya śuddhasya śūnyasya ca kimantaram |
yaccāntaraṃ tadvibudhā vidantyeti na vāggatim
]

`v 61 [
sadasadrūpa ābhāso yathā kimapi lakṣyate |
tamasīkṣitayatnena brahmaṇīdaṃ tathā jagat
]

`v 62 [
ayamākāśamevāhaṃ yadi śāmyāmyavāsanam |
vāsanāṃ tu na badhnāsi sthita evāsi cinnabhaḥ
]

`v 63 [
iti niścayavānantastajjño'jña iva saṃjñayā |
cidvapurvidyamāno'pi śāmyatyasadiva svayam
]

`v 64 [
jīvānāṃ jñaptiguptena jvalannajñānavāyunā |
avidyāgniḥ prabuddhānāṃ punastenaiva śāmyati
]

`v 65 [
ajaḍānāṃ yadajñānaṃ sthāṇūnāmiva śāmyatām |
tamāddurmokṣamakṣubdhamāsitaṃ padamakṣayam
]

`v 66 [
jñatvena jñatvamāsādya munirbhavati mānavaḥ |
ajñatvādajñatāmetya prayāti paśuvṛkṣatām
]

`v 67 [
ahaṃ brahma jagaccedamityavidyāmayo bhramaḥ |
asatyaḥ prekṣyā dhvāntaṃ dīpeneva na labhyate
]

`v 68 [
samagrakaraṇagrāmo'pyasaṃkalpo vivedanaḥ |
na kiṃcidapyanubhavatyantarbāhye ca śāntadhīḥ
]

`v 69 [
tarhi jīvanmuktānāṃ cakṣurādikaraṇairbāhyajñānadarśanānmuktatā na syāttatrāha ##-
suṣuptatva iva svapnaḥ samādhau pravilīyate |
dṛśyaṃ sarvaṃ jñabodhe'ntaḥ punaḥ svātmaiva lakṣyate
]

`v 70 [
nīlatvaṃ ca yathā vyomni tathā pṛthvyāditā śive |
bhrāntimātrādṛte nānyadyathā vyoma tathā śivaḥ
]

`v 71 [
vāsanābhirupeto'pi samastābhiravāsanaḥ |
bhavatyasāvasatsarvamidamityeva yasya dhīḥ
]

`v 72 [
saṃkalpeṣvadbhutaṃ bhavya svapnamāyendrajālakam |
yadvatsaṃsṛtayastadvaddṛṣṭe'pyāsthā kimatra vai
]

`v 73 [
na duḥkhamasti na sukhaṃ na puṇyaṃ na ca pātakam |
na kiṃcitkasyacinnaṣṭaṃ karturbhokturasaṃbhavāt
]

`v 74 [
sarvaṃ śūnyaṃ nirālambaṃ mamatāpratyayo'pyayam |
dvicandrasvapnapuravadyasyāsau so'pi nāsti naḥ
]

`v 75 [
kevalo vyavahārasthaḥ kāṣṭhamaunagato'tha vā |
kāṣṭhapāṣāṇavattiṣṭhanbrahmatāmadhigacchati
]

`v 76 [
śāntatve cittatve nānānānātmanīha śive |
avayavino'vayavitve tviha yuktirvidyate nānyā
]

`v 77 [
arthāgatasvabhāvasya ca naiva ca saṃbhavādamale |
etasminsarvagate brahmaṇi nāsti svabhāvoktiḥ
]

`v 78 [
na ca nāstikopalambhātsaṃvitterastitā ca naivāje |
grāhyagrāhakadṛṣṭerasaṃbhavādasti kiṃcidapi
]

`v 79 [
nanvevaṃ sārvajanīnasyāpi jagadvaicitryasya yuktyasahatvādapalāpe
tatsaṃvitterapyapalāpaḥ kiṃ na syāt | na hi saṃvedyamantareṇa saṃvitprasiddheti
śūnyavādaḥ prasakta iti cettatrāha - na ceti | saṃvedyāpalāpe saṃvitterapyastitā
nāstīti na ca vaktuṃ śakyam | saṃvidapalāpino nāstikātmana
evopalambhādapalapitumaśakyatvāt | sa hi svātirikte eva saṃvitsaṃvedye apalapenna tu
svātmānam | yadā sarvāpi saṃvittadātmaiva tadā tatra saṃvedyamapalapan saṃvidaṃ
pariśeṣayatyeva | kiṃ ca nirādhāraniṣedhāyogādgrāhyagrāhakayoragrāhyagrāhakātmani
svayaṃprakāśe ādhāre pratiṣedho vācyaḥ | sa eva tasyātmeti tenā'je svātmanyeva
grāhyagrāhakadṛṣṭyorasaṃbhavapratipādanaparyavasānāt##-
78 |
śamamamalamahāryamāryajuṣṭaṃ śivamajamakṣayamāsitaṃ samaṃ yat |
tadavitathapadaṃ tadāsva śāntaṃ piba lala bhuṅkṣva bhavānayaṃ hi nāsti
]