`v 1 [
ekādaśaḥ sargaḥ 11
bhuśuṇḍa uvāca |
śastrāṇi dayitāṅgāni lagnānyaṅge nirambare |
yo buddhyamānaḥ susamaḥ sa parasminpade sthitaḥ
]

`v 2 [
tāvatpuruṣayatnena dhairyeṇābhyāsamāharet |
yāvatsuṣuptatodeti padārthodayanaṃ prati
]

`v 3 [
yathā bhūtārthatattvajñamādhayo'gragatā api |
na manāgapi limpanti payāṃsīva saroruham
]

`v 4 [
śastrāṅganānabhāṃsyaṅgalagnānyalamasaṃvidam |
alagnānīva śāntātmā yaḥ paśyati sa paśyati
]

`v 5 [
viṣaṃ yathā svāntareva durghuṇībhavati svayam |
na ca durghuṇatā nāma viṣādanyāsti kācana
]

`v 6 [
svarūpamajahattvevaṃ jīvatāmadhitiṣṭhati |
tathātmā tatparijñānamātraikapravilāpinīm
]

`v 7 [
jīvo bhavati durghūṇo'mṛtyātmaiva `note[dīrghatvamārṣam |] yathā tathā |
atyajantī nijaṃ rūpaṃ cijjaḍaṃ rūpamṛcchati
]

`v 8 [
brahmaṇyananyo'pyanyābho durghuṇaḥ kvacidutthitaḥ |
tatsthaḥ sa evāsa ivāpyatatstha iva sargakaḥ
]

`v 9 [
viṣaṃ viṣatvamajahadyathā svāntaḥ kṛmiḥ kramāt |
na jāyate na mriyate mriyate'pi ca jāyate
]

`v 10 [
svenaiva saṃvidarthena padārthāmagnarūpiṇā |
tīryate goṣpadamiva na tu daivādbhavārṇavaḥ
]

`v 11 [
sarvabhāvāntarāvasthā sarvabhāvātiśāyinī |
antaḥśītalatā yasmiṃstasminkimiva helanam
]

`v 12 [
jagatpadārthasattāntaḥ sāmānyenāśu bhāvite |
manohaṃkārabuddhyādi kaḥ kalaṅko'malātmani
]

`v 13 [
yathā ghaṭapaṭādyarthānpaśyasyevaṃ śarīrakam |
tathāhantvamanobuddhivedanādyapi paśya he
]

`v 14 [
jagatpadārthasārthaughamanobuddhyādi saṃsthitam |
jña evāsaṃvidaṃstiṣṭha pariniṣṭhitaniṣṭhayā
]

`v 15 [
na kenacitkasyacideva kaściddoṣo na caiveha guṇaḥ kadācit |
sukhena duḥkhena bhavābhavena na cāsti bhoktā na ca kartṛtā ca
]