`v 1 [
trayodaśādhikaśatatamaḥ sargaḥ 113
śrīvasiṣṭha uvāca |
balānyanutaranto'tha taditthaṃ dravatāṃ dviṣām |
dūrāddūrataraṃ prāptāścatvāraste vipaścitaḥ
]

`v 2 [
sarvaśaktimayaikena cetaneneśvareṇa te |
prahitā digjayaṃ cakruḥ sarva eva samāśayāḥ
]

`v 3 [
dūrāttāvadavicchinnamanusasrurbalāni te |
yāvattīraṃ samudrāṇāṃ pravāhāḥ saritāmiva
]

`v 4 [
dūrāviśrāntayānena teṣāṃ tatsarvasādhanam |
ātmīyaṃ parakīyaṃ ca kṣīṇaṃ kusaridambuvat
]

`v 5 [
ātmīyānyanyadīyāni teṣāṃ vīkṣyabalānyalam |
kṣīṇādīva mumukṣūṇāṃ puṇyapāpāni dhāvatām
]

`v 6 [
svayamastrāṇi śāntāni kṛtakṛtyānyathāmbare |
jvālājālāni vahnīnāṃ dāhyasyāsaṃbhavādiva
]

`v 7 [
ālayeṣu rathāśvebhavṛkṣaughādiṣu hetayaḥ |
āsannidrālavo līnā dinānte vihagā iva
]

`v 8 [
taraṅgā iva toye'ntarnīhārā iva vāride |
meghā vāyāvivāmodā vyomanīva nililyire
]

`v 9 [
dhārāpaṅkatalālīnaśāntahetijalecaraḥ |
nārācasīkarāsāranīhāraparivarjitaḥ
]

`v 10 [
cakrāvartaśatonmukto yuktaḥ saumyatayācchayā |
praśāntameghasaṃrambhataraṅgottuṅgavarṣaṇaḥ
]

`v 11 [
praśāntāni meghasaṃrambhaprayuktāni taraṅgebhyo'pyuttuṅgāni varṣaṇāni yasmin | 10
|
antarlīnarkṣaratnaughakoṇasaṃsthārkavāḍavaḥ |
śūnyatāvāriramalo vyomaikābdhirabhūtpṛthuḥ
]

`v 12 [
lambaprakāśagambhīraṃ prasannaṃ kāntimattatam |
rajovirahitaṃ reje khaṃ mano mahatāmiva
]

`v 13 [
athārṇavāṃste dadṛśurākāśasyānujāniva |
vistīrṇānvimalākārānpūritākhiladiktaṭān
]

`v 14 [
taraṅgakaṇakallolamahāgulugulākulān |
bhūrisīkaranīhārahārihāriśarīriṇaḥ
]

`v 15 [
sthitānātmānamāstīrya bhūmau vyādhyāturāniva |
śvasanārtāṃścaladdehānvivartormimahābhujān
]

`v 16 [
jaḍānapi spandamayānkallolākoṭakoṭarān |
saṃsārāniva vistīrṇāṃścakrāvartadaśākulān
]

`v 17 [
ratnarāśitaṭoddyotapīvarīkṛtabhāskarān |
śaṅkharāśiviśadvātaśabdatarjitaghuṃghumān `note[vardhitetyapi kvacitpāṭhaḥ
sa na vyākhyānuguṇaḥ |]
]

`v 18 [
māṃsalormighaṭāghoṣaghargharāmbaraḍambarān |
vartulāvartavistāraprabhramadvidrumadrumān
]

`v 19 [
māṃsalānāṃ puṣṭānāmūrmighaṭānāṃ ghoṣairmeghaghargharāmbaraḍambarayuktān |
18 |
makaravyūhanirhrādaghargharodaraghuṃghumān |
matsyapucchacchaṭācchinnamajjatpotakṛtāravān
]

`v 20 [
udgrīvakūrmamakaranigīrṇairṇanarotkarān |
ūrmibimbitasaptāśvasahasnārkanabhonibhān
]

`v 21 [
bhāṃkārakāripavanapatadbhūtyatatodghaṭān |
ūrmyudastamaṇivrātabalājjhaṇajhaṇadhvanīn
]

`v 22 [
nānājālairbalabhujairhelāspṛṣṭārkamaṇḍalān
namadunnamadudraśmiratnamāṇikyamaṇḍalān
]

`v 23 [
utphālaphenilāvartavivartamakarotkarān |
kvacitkarikaronnāmaiḥ kṣaṇaṃ vaṃśavanīkṛtān
]

`v 24 [
taharīvallarīvālānpṛṣṭhatāliṣu mādhvān |
kvacidantaraviśrāntasaparicchadamādhavān
]

`v 25 [
ekadeśasthitāsaṃkhyanānāsurasurālayān |
tārānavataraṅgaughaparidanturitāmbarān
]

`v 26 [
guhāmaśakavadgartabhītaśākhāyitācalān |
nayatombutaraṅgaughairvelādrīnatikharvatām
]

`v 27 [
khakṣetrāropitānalparatnaraśmipathāṅkurān |
śuddhaśuktimukhonmuktamuktāntaritasaikatān
]

`v 28 [
nānāratnāṃśukauśeyasūtracitrāṃstaraṅgitān |
viśannadīndaśādigbhiḥ samākīrṇānpaṭāniva
]

`v 29 [
indranīlataṭairvyuptamuktāśuktiśatāṅkitaiḥ |
kvaciddarśayataḥ kāntaśatendukanakhaśriyam
]

`v 30 [
ratnāṃśujālasaṃdigdhāstaraṅgādeśabimbitāḥ |
parivartayataḥ phullāstīratālīvanāvalīḥ
]

`v 31 [
elālavaṅgakaṅkolaphalamālāṃ jighṛkṣubhiḥ |
velāvanalatābhraṣṭāmāttāvṛttīñjalecaraiḥ
]

`v 32 [
cūtanīpakadambāgravihagānpratibimbitān |
bhuñjānairvipralambhena kṛtācchoṭāñjalecaraiḥ
]

`v 33 [
khecarapratibimbena vidravadbhiritastataḥ |
bhagnabandhabṛhatsetūnkṣaṇaḥ prati jalecaraiḥ
]

`v 34 [
amūrtānpratibimbena hṛdayasthajagattrayān |
caturo vyomavipulāndikṣu nārāyaṇāniva
]

`v 35 [
atigāmbhīryanairmalyavistāravibhavairnabhaḥ |
nigīrya saṃdarśayato hṛdayādiva bimbitam
]

`v 36 [
jalacārivihaṅgānāṃ sākāśaṃ pratibimbitam |
āśayairdadhataḥ sāraiḥ padmānbhṛṅgamivātmagam
]

`v 37 [
taraṅgataralāsphālamārutairāhatāmbarān |
kandarodgāragambhīraiḥ kalpāntajaladālayān
]

`v 38 [
guhāgulugulāvartanirghoṣāśanibhīṣaṇān |
bhṛśaṃ bhāvayato grastānagastyaurvānalāniva
]

`v 39 [
bhūrisīkarapuṣpāṇi taraṅgaughatarūṇi ca |
prāptānyambuvanānīva laharīmañjarīṇi kham
]

`v 40 [
tathā khaṃ prāptānyambuvanāni bhāvayata iva sthitān | kīdṛśānyambuvanāni |
bhūrisīkarā eva puṣpāṇi yeṣu tāni | taraṅgaughāstaravo yeṣu | laharyo mañjaryo yeṣu |
39 |
sarattaraṅgajālāni proḍḍīnaprāṇimantyadhaḥ |
ākāśakhaṇḍakhaṇḍatvātpatitānīva vibhramāt
]

`v 41 [
elālavaṅgabakulāmalakītamālahiṃtālatāladalatāṇḍavakhaṇḍitāgre |
prāpte patallavaṇavāridhidīrghatīraṃ rekhā babhāvalinibhāmbaraśailamūrdhni | 41
|
varṇitaprakāraiḥ patatāṃ taraṅgaiḥ pratyudgacchatāṃ lavaṇavāridhīnāṃ dīrghatīraṃ
vipaścitsainye prāpte sati parito dīrghe tīrāgre ambarasaṃpṛktānāṃ śailānāṃ mūrdhni
elālavaṅgādivṛkṣāṇāṃ dalatāṇḍavaiḥ khaṇḍitā vibhaktā alinibhā śyāmalā
vanarekhā babhau aśobhatetyarthaḥ
]