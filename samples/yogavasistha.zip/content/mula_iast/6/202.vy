`v 1 [
dvyadhikadviśatatamaḥ sargaḥ 202
śrīvālmīkiruvāca |
etacchrutvā vasiṣṭhasya vacaḥ saṃsadi pārthivāḥ |
siktā ivāmṛtāpūrairantaḥśītalatāṃ yayuḥ
]

`v 2 [
rāmaḥ kamalapatrākṣo rarāja vadanendunā |
kṣīroda iva saṃpūrṇaḥ sudhāpūreṇa cāruṇā
]

`v 3 [
vāmadevādayaḥ sarve tattvajñānaviśāradāḥ |
aho bhagavatā jñānamuktamityūcurādarāt
]

`v 4 [
śāntāntaḥkaraṇo rājā mudā daśaratho babhau |
tuṣṭyaiva saṃprahṛṣṭāṅgo navāṃ dyutimupāgataḥ
]

`v 5 [
jñātajñeyeṣu bahuṣu sādhuvādakathāsvatha |
uvāca galitājñāno rāmo vākyamidaṃ punaḥ
]

`v 6 [
śrīrāma uvāca |
bhagavanbhūtabhavyeśa tvayāsmākamalaṃ malam |
saṃpramṛṣṭamidaṃ hemnaḥ śyāmatvamiva vahninā
]

`v 7 [
abhūma vayamātmīyakāyamātradṛśaḥ purā |
prabho saṃprati saṃpannā viṣvagviśvāvalokinaḥ
]

`v 8 [
kāyamātradṛśo dehaparicchinnātmadṛṣṭayaḥ | viśvāvalokinaḥ sarvātmadarśinaḥ |
7 |
sthito'smi sarvasaṃpūrṇaḥ saṃpanno'smi nirāmayaḥ |
jāto'smi vigatāśaṅko budho jāgarmi saṃprati
]

`v 9 [
ānandito'smyakhedāya sukhitosmi cirāya ca |
sthito'nastamayāyaiva śāśvtārthodayo mama
]

`v 10 [
aho bata pavitreṇa śītena jñānavāriṇā |
tvayā siktosmi hṛṣyāmi padmavaddhṛdaye svayam
]

`v 11 [
iyamadya mayā labdhā padavī tvatprasādataḥ |
yasyāṃ sthitasya me sarvamamṛtatvaṃ gataṃ jagat
]

`v 12 [
antaḥprasannamatirastasamastaśokaḥ śobhāṃ gato'hamamalāśaya eva śāntyā |
ānandamātmani gataḥ svayamātmanaiva nairmalyamabhyupagato'smi namostu
mahyam
]