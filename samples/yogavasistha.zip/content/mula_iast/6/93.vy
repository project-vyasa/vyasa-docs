`v 1 [
trinavatitamaḥ sargaḥ 93
śrīvasiṣṭha uvāca |
athaivaṃrūpasaṃvitteḥ parāvṛttya prayatnataḥ |
tamambarakuṭīkośadeśamāgatavānaham
]

`v 2 [
yāvattatra na paśyāmi svadehaṃ kvacana sthitam |
paśyāmi kevalaṃ siddhaṃ kamapyanyaṃ puraḥ sthitam
]

`v 3 [
upaviṣṭaṃ samādhānaniṣṭhamiṣṭaṃ padaṃ gatam |
saumyodayamivādityaṃ dagdhendhanamivānalam
]

`v 4 [
baddhapadmāsanaṃ śāntaṃ samādhānaniriṅganam |
gulphadvitayamadhyasthavṛṣaṇaṃ viṣayātigam
]

`v 5 [
mṛṣṭasaumyasamābhogaskandhabandhurakandharam |
susthirodāraviśrāntasphārakasthitisundaram
]

`v 6 [
nābhīnikaṭagottānapāṇidvitayadīptibhiḥ |
hṛdayāmbhojatejobhirbahiṣṭhairiva bhāsitam
]

`v 7 [
śliṣṭapakṣmekṣaṇaṃ kṣīṇasarvekṣaṃ svacchatāṃ gatam |
saro nimīlitāmbhojamiva suptaṃ dinātyaye
]

`v 8 [
avikṣubhitamāśāntamantaḥkaraṇakoṭaram |
dadhānaṃ dhīrayā vṛttyā śāntotpātamivāmbaram
]

`v 9 [
apaśyatā nijaṃ dehaṃ taṃ muniṃ paśyatā puraḥ |
idaṃ mayā tadā tatra cintitaṃ cārucetasā
]

`v 10 [
ayaṃ kaścinmahāsiddhaḥ saṃprāpto'smindigantare |
vicāryāhamivaikāntaṃ viśrāmārthī mahāmbaram
]

`v 11 [
samādhiyogyamekāntaṃ labheyetīha cintayā |
kuṭī dṛṣṭeyametena satyasaṃkalpaśālinā
]

`v 12 [
madāgamanametena tato'cintayatā ciram |
taṃ svadehaṃ śavībhūtamapāsyeha kṛtā sthitiḥ
]

`v 13 [
tadihāstamahaṃ yāmi svaṃ lokamiti niścayam |
yāvadgantuṃ pravṛtto'smi tāvatsaṃkalpanakṣayāt
]

`v 14 [
sā nivṛttā kuṭī tatra saṃpannaṃ vyoma kevalam |
sa siddho'pi nirādhāraḥ patitodhaḥ samādhimān
]

`v 15 [
svapnasaṃkalpasaṃśāntau svapnasaṃkalpapattanam |
yadā sā sukuṭī naṣṭā matsaṃkalpopaśāntitaḥ | 15 |
pattanam iveti śeṣaḥ | pūrvasya parasya cāyaṃ kuṭīnāśasya dṛṣṭāntaḥ
]

`v 16 [
sa papāta tato dhyānī jalotpīḍa ivāmbudāt |
khādivānilanunno'bda indubimbamiva kṣaye
]

`v 17 [
vaimānika ivāpuṇyaśchinnamūla iva drumaḥ |
khāttyakta iva pāṣāṇaḥ sa papāta tato'vanau
]

`v 18 [
ahaṃ yāvadiyaṃ tāvatkuṭikāstviti kalpane |
kṣīṇe kuṭīkṣaye jāte sa siddhaḥ patitaḥ kṣaṇāt
]

`v 19 [
patatā tena siddhena tataḥ saujanyakautukaḥ |
manasaivāhamaganaṃ nabhaso vasudhātalam
]

`v 20 [
so'patatpavanaskandhavalanāvartavṛttibhiḥ |
saptadvīpasamudrānte gīrvāṇaramaṇāvanau
]

`v 21 [
prāṇāpānordhvagāmitvātkhādyathāsthitameva saḥ |
sṛṣṭapūrvordhvamūrdhorvyāṃ baddhapadmāsano'patat
]

`v 22 [
na prabuddho babhūvāsauvicaraṃ tamacetanaḥ |
pāṣāṇadeha iva tā tūlātmevaiva vā laghuḥ
]

`v 23 [
mayā tadavabodhārthamatha yatnavatā tadā |
kṛtvā jaladatāṃ vyomni vṛṣṭaṃ garjitamūrjitam
]

`v 24 [
karakāśanipātena tena tasmindigantare |
mayūraṃ prāvṛṣevāmuṃ buddhyā bodhitavānasau
]

`v 25 [
babhūvābhāsitāṅgaśrīrvikāsitavilocanaḥ |
dhārānikaraphullātmā prāvṛṣīvāmbujākaraḥ
]

`v 26 [
prabuddhaṃ saṃpraśāntāyāṃ dṛṣṭau tamahamagrataḥ |
apṛcchaṃ svacchayā vṛttyā nivṛttaṃ paramārthataḥ
]

`v 27 [
kva sthito'si karoṣīdaṃ kiṃ ca bho munināyaka |
kastvaṃ kasmādalaṃ dūrānna bhraṃśamapi cetasi
]

`v 28 [
ityukto māmasau prekṣya saṃsmṛtya prāktanīṃ gatim |
uvāca vacanaṃ cāru cātako jaladaṃ yathā
]

`v 29 [
siddha uvāca |
pratipālaya me yāvatsvavṛttāntaṃ smarāmyaham |
kathayiṣyāmi te paścātpāścātyaṃ vṛttamātmanaḥ
]

`v 30 [
ityuktvā cintayitvāśu sa yathā vṛttamakṣatam |
smṛtavānsāyamahnīva samācaritamātmanaḥ
]

`v 31 [
māmathovāca vacanaṃ cāru candrāṃśuśītalam |
āhlādanamanindyaṃ ca niravadyaṃ sukhodayam
]

`v 32 [
vakṣyamāṇavacanasya vivekavairāgyapradhānatvāccārvityādiviśeṣaṇaiḥ praśaṃsā | 31
|
siddha uvāca |
adhunā tvaṃ mayā brahmanparijñāto'bhivādaye |
atikramo'yaṃ kṣantavyaḥ svabhāvo hi satāṃ kṣamā
]

`v 33 [
mune ciramahaṃ bhrānto devopavanabhūmiṣu |
bhogāmodavimoheṣu ṣaṭpadaḥ padminīṣviva
]

`v 34 [
dṛśyanadyāmatho cittajalakallolahelayā |
cakrāvartohyamānena mayodvignena cintitam
]

`v 35 [
saṃsārasāgare dṛśyakallolairahamākulaḥ |
kālenodvegamāyātaścātako'vagrahe yathā
]

`v 36 [
saṃvinmātraikasāreṣu ramyaṃ bhogeṣu nāma kim |
avatiṣṭhe gatodvegasaṃvidvyomnyeva kevalam
]

`v 37 [
śabdarūparasasparśagandhamātrādṛte param |
neha kiṃcana nāmāsti kimetāvatyahaṃ rame
]

`v 38 [
na hyaparicchinnaṃ sukhaṃ vihāya parigaṇite paricchinne asukhe ramaṇamucitamityāha ##-
cinmātrākāśamevaitatsarvaṃ cinmātrameva vā |
tatkimatrāsadākāre rame naṣṭamatiryathā
]

`v 39 [
viṣayā viṣavaiṣamyā vāmāḥ kāmavimohadāḥ |
rasāḥ sarasavairasyā luṭhanneṣu na ko hataḥ
]

`v 40 [
jīrṇā jīvitajambālajaracchapharikāmatiḥ |
kāyaṃ drutagatā''dātuṃ jarecchati bṛhadbakī
]

`v 41 [
kāyo'yamacirāpāyo budbudo'mbunidhāviva |
sphuranneva purontarddhi yāti dīpaśikhā yathā
]

`v 42 [
vividhākulakallolā cakrāvartavidhāyinī |
mṛtijanmabṛhatkūlā sukhaduḥkhataraṅgiṇī
]

`v 43 [
yauvanollāsakalilā jarādhavalaphenilā |
kākatālīyayogena saṃpannasukhabudbudā
]

`v 44 [
vyavahāramahāvāhalekhājaḍaravākulā |
rāgadveṣaghanollāsā bhūtalāloladehikā
]

`v 45 [
lobhamohamahāvartā pātotpātavivartanī |
hā taptā jīvitākhyeyaṃ nadī nadanaśītalā
]

`v 46 [
apūrvāṇyupagacchanti tathā pūrvāṇi yāntyalam |
saṃsārasaridambūni saṃgatāni dhanāni ca
]

`v 47 [
pravṛttā ye nivartante tairalaṃ hatabhāvaikaiḥ |
apūrvā ye pravartante teṣvathāstheha kīdṛśī
]

`v 48 [
sarvasyāḥ sarito vāri prayātyāyāti cākarāt |
dehanadyāḥ payastvāyuryātyevāyāti no punaḥ
]

`v 49 [
śataśaḥ parivartante pratipiṇḍaṃ kṣaṇaṃ prati |
kulālacakrakābhāvā iva bhāvā bhavāmbudhau
]

`v 50 [
caranti caturāścaurā viṣamā viṣayārayaḥ |
haranti bhāvasarvasvaṃ jāgarmi svapimīha kim
]

`v 51 [
āyuṣaḥ khaṇḍakhaṇḍāśca nipatantaḥ punaḥ punaḥ |
na kaścidvetti kālena kṣatāni divasānyaho
]

`v 52 [
idamadya tathedaṃ ca tathedamidamasya me |
evaṃ kalanayā loko gataṃ prāptaṃ na vettyaho
]

`v 53 [
bhuktaṃ pītamanantāsu bhrāntaṃ ca vanabhūmiṣu |
dṛṣṭāni sukhaduḥkhāni kimanyadiha sādhyate
]

`v 54 [
sukhaduḥkhānubhavanādbhūyobhūyo vivartanāt |
anityatvācca bhāvānāṃ sthitā niṣkautukā vayam
]

`v 55 [
bhuktāni bhogavṛndāni dṛṣṭā cānityatā bhṛśam |
nopalabhyata evāti viśrāntiriha kutracit
]

`v 56 [
bhrāntamuttuṅgaśṛṅgāsu merūpavanabhūmiṣu |
lokapālapurīṣūccaiḥ saṃprāptaṃ kimakṛtrimam
]

`v 57 [
sarvatra dārubhirvṛkṣā māṃsairbhūtāni bhūrmṛdā |
duḥkhānyanityatā ceti kathamāśvāsyate vada
]

`v 58 [
na dhanāni na mitrāṇi na sukhāni na bāndhavāḥ |
śaknuvanti paritrātuṃ kālenākalitaṃ janam
]

`v 59 [
jano jīmūtajaṭharajalavadgirikukṣiṣu |
yātyantaḥśūnya evāstaṃ pāṃsūpacayapelavaḥ
]

`v 60 [
na me manoramāḥ kāmā na ca ramyā vibhūtayaḥ |
idaṃ mattāṅganāpāṅgabhaṅgalolaṃ ca jīvitam
]

`v 61 [
kveva kasya kathaṃ nāma kuta āśvāsanā mune |
adya śvo vā''padaṃ pāpo mṛtyurmūrdhni niyacchati
]

`v 62 [
śarīraṃ parṇavadbhraṃśi jīvitaṃ jīrṇasaṃsthiti |
dhīradhīratayā grastā rasā nīrasatāṃ gatāḥ
]

`v 63 [
nītaṃ manorathaireva nīrasairvā''yurātatam |
na mama svaṃ camatkārakāri kiṃcidapīhitam
]

`v 64 [
moho'dya māndyamāyāto deho nehopayujyate |
anāsthaivottamāvasthā sthānāsthaivādhamā sthitiḥ
]

`v 65 [
āpadāpatitaiveyamaho mohavidhāyinī |
nityamityeva mantavyaṃ saktavyaṃ neha saṃsṛtau
]

`v 66 [
vidhibhiḥ pratiṣedhaiśca śāśvatairapyaśāśvataiḥ |
yatheṣṭaṃ nīyate loko jalaṃ nimnonnatairiva
]

`v 67 [
vivekāmodasarvasvaṃ cetaḥ kusumakośataḥ |
hṛtvā mūrcchāṃ prayacchanti viṣayā viṣavāyavaḥ
]

`v 68 [
yataḥ karmiṇāmaihikāmuṣmikaviṣayāvivekaṃ hṛtvā anarthameva prāpayantītyāha ##-
asadeva tathā nāma dṛṣṭaṃ sattāmupāgatam |
yathā'sadeva sadrūpaṃ saṃpannamasadeva sat
]

`v 69 [
dolāyantyo'vanau dehaṃ sāgarānsāgarāṅganāḥ |
yathā dhāvanti dhāvanti janatā viṣayāṃstathā
]

`v 70 [
dhāvanti viṣayāṁllakṣyamunmuktāścittasāyakāḥ |
spṛśanti na guṇānbhūyaḥ kṛtaghnāḥ sauhṛdaṃ yathā
]

`v 71 [
utpātavāyurevāyurmitrāṇyevātiśatravaḥ |
bandhavo bandhanānyeva dhanānyevāti naidhanam
]

`v 72 [
sukhānyevātiduḥkhāni saṃpadaḥ paramāpadaḥ |
bhogā bhavamahārogā ratireva parāratiḥ
]

`v 73 [
āpadaḥ saṃpadaḥ sarvāḥ sukhaṃ duḥkhāya kevalam |
jīvitaṃ maraṇāyaiva bata māyāvijṛmbhitam
]

`v 74 [
bahūnkālaparāvartāniṣṭāniṣṭānsukhaṃ manāk |
paśyanpriyaviyogāṃśca yāti jarjaratāṃ janaḥ
]

`v 75 [
bhogā viṣayasaṃbhogā bhogā eva phaṇāvatām |
daśantyeva manāk spṛṣṭā dṛṣṭā naṣṭāḥ pratikṣaṇam
]

`v 76 [
āyuryāti nirāyāsapadaprāptivivarjitaiḥ |
udarkabhaṅgurākāraiḥ karālaiḥ kaṣṭaceṣṭitaiḥ
]

`v 77 [
bhogāśābaddhatṛṣṇānāmapamānaḥ pade pade |
ālānamavalīnānāṃ vanyānāmiva dantinām
]

`v 78 [
saṃpadaḥ pramadāścaiva taraṅgotsaṅgabhaṅgurāḥ |
kastāsvahiphaṇācchatracchāyāsu ramate budhaḥ
]

`v 79 [
satyaṃ manoramāḥ kāmāḥ satyaṃ ramyā vibhūtayaḥ |
kiṃtu mattāṅganāpāṅgabhaṅgalolaṃ hi jīvitam
]

`v 80 [
āpātaramaṇīyeṣu ramante viṣayeṣu ye |
atyantavirasānteṣu patanti nirayeṣu te
]

`v 81 [
dvandvadoṣoparuddhāni duḥsādhyānyasthirāṇi ca |
dhanānyabhavyasevyāni mama jātu na tuṣṭaye
]

`v 82 [
āpātamātramadhurā duḥkhaparyavasāyinī |
mohanāyaiva lokasya lakṣmīḥ kṣaṇavilāsinī
]

`v 83 [
āpātaramaṇīyāni vimardavisarāṇyati |
duḥkhānyāpatpradātṛṇi saṃgatāni khalairiva
]

`v 84 [
śaradambudharacchāyāgatvaryo yauvanaśriyaḥ |
āpātaramyā viṣayāḥ paryantaparitāpinaḥ
]

`v 85 [
antakaḥ paryavasthātā jīvite mahatāmapi |
calantyāyūṃṣi śākhāgralambāmbūnīva dehinām
]

`v 86 [
jīryante jīryataḥ keśā dantā jīryanti jīryataḥ |
kṣīyate jīryate sarvaṃ tṛṣṇaivaikā na jīryate
]

`v 87 [
bhogābhogātigahane sarvasminkāyakānane |
paramullāsamāyāti tṛṣṇaikā viṣamañjarī
]

`v 88 [
bālyaṃ yauvanavadyāti yauvanaṃ yāti bālyavat |
upamānopameyatvaṃ bhaṅguratvaṃ mitho'nayoḥ
]

`v 89 [
jīvitaṃ galati kṣipraṃ jalamañjalinā yathā |
pravāha iva vāhinyā gataṃ na vinivartate
]

`v 90 [
jhaṭityevāgato dehaḥ kuto'pyarjunavātavat |
yāti paśyata evāstaṃ taraṅgāmbudadīpavat
]

`v 91 [
ramyeṣvaramyatā dṛṣṭā sthireṣvasthiratāpi ca |
satyeṣvasatyatārtheṣu teneha virasā vayam
]

`v 92 [
sukhaṃ yadātmaviśrāntau gate manasi sattvatām |
pātāle bhūtale svarge tanna bhogeṣu keṣucit
]

`v 93 [
api saṃpūrṇahṛdyārthāḥ pañcāpīndriyavṛttayaḥ |
tāvajjayanti māmetā bhṛṅgaṃ citralatā iva
]

`v 94 [
adya dīrgheṇa kālena nirahaṃkṛtinā mayā |
svargāpavargavaitṛṣṇyamidamāsāditaṃ dhiyā
]

`v 95 [
ciramekāntaviśrāntyai tenaitannabhasaḥ padam |
tvamivāgatavānatra dṛṣṭavānasmi tāṃ kuṭīm
]

`v 96 [
adyaitatsaṃparijñātaṃ yadeṣā bhavataḥ kuṭī |
āgantā tvaṃ punaśceti mayā tatra vicāritam
]

`v 97 [
tadā tvatra mayā jñātaṃ kaścitsiddho'yamātmanā |
dehaṃ tyaktveha nirvāṇaṃ gata ityanumānataḥ
]

`v 98 [
etanme bhagavanvṛttameṣo'smīti yathāsthitam |
mayā te kathitaṃ sarvaṃ yathā jānāsi tatkuru
]

`v 99 [
siddhairna yāvadavadhānaparairvicārya nirṇītamuttamadhiyāntaraśeṣavastu |
tāvattrikālakalanaṃ na vidanti kiṃcidityabjajādimanaso'pi mune svabhāvaḥ
]