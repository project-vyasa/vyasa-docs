`v 1 [
aṣṭamaḥ sargaḥ 8
bhuśuṇḍa uvāca |
vidyādhara dharādhāro girikandaramandiraḥ |
digantarāmbarācāracārasaṃcāracañcaraḥ
]

`v 2 [
iha saṃsāravṛkṣasya jñānāduccheda īyate |
saṃkalpamaṇḍapaprāyaḥ saṃsāra upavarṇyate |
īdṛśo'yaṃ jagadvṛkṣo jāyate'haṃtvavījataḥ |
bīje jñānāgninirdagdhe naiva kiṃcana jāyate
]