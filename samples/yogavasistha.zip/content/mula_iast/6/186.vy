`v 1 [
ṣaḍaśītyadhikaśatatamaḥ sargaḥ 186
śrīvālmīkiruvāca |
kundadante vadatyevaṃ vasiṣṭho bhagavānmuniḥ |
uvācedamanindyātmā paramārthocitaṃ vacaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
vata vijñānaviśrāntirasya jātā mahātmanaḥ |
karāmalakavadviśvaṃ brahmeti paripaśyati
]

`v 3 [
kiledaṃ bhrāntimātrātma viśvaṃ brahmeti bhātyajam |
bhrāntirbrahmaiva ca brahma śāntamekamanāmayam
]

`v 4 [
yadyathā yena yatrāsti yādṛgyāvadyadā yataḥ |
tattathā tena tatrāsti tādṛktāvattadā tataḥ
]

`v 5 [
śivaṃ śāntamajaṃ maunamamaunamajaraṃ tatam |
suśūnyāśūnyamabhavamanādinidhanaṃ dhruvam
]

`v 6 [
tacca śuddhāviruddham | māyāyā vikāraṃ vinaiva vaicitryaprakaṭanādityāśayenāha ##-
yasyā yasyāstvavasthāyāḥ kriyate saṃvidā bharaḥ |
sā sā sahasraśākhatvameti sekairyathā latā
]

`v 7 [
paro brahmāṇḍamevāṇuścidvyomnontaḥsthito yataḥ |
paramāṇureva brahmāṇḍamantaḥsthitajagadyataḥ
]

`v 8 [
tasmāccidākāśamanādimadhyamakhaṇḍitaṃ saumyamidaṃ samastam |
nirvāṇamastaṃgatajātibandho yathāsthitaṃ tiṣṭha nirāmayātmā
]

`v 9 [
svayaṃ dṛśyaṃ svayaṃ draṣṭṭa svayaṃ cittvaṃ svayaṃ jaḍam |
svayaṃ kiṃcinna kiṃcicca brahmātmanyeva saṃsthitam
]

`v 10 [
yathā yatra jagatyetatsvayaṃ brahma khamātmani |
svarūpamajahacchāntaṃ yatra saṃpadyate tathā | 10 |
yatra yadvāsanayā yathā saṃpadyate tatra tathā sthitamityanukarṣaḥ
]

`v 11 [
brahma dṛśyamiti dvaitaṃ na kadācidyathāsthitam |
ekatvametayorviddhi śūnyatvākāśayoriva
]

`v 12 [
dṛśyameva paraṃ brahma paraṃ brahmaiva dṛśyatā |
etanna śāntaṃ nā'śāntaṃ nānākāraṃ na cākṛtiḥ
]

`v 13 [
yādṛgprabodhe svapnādistādṛgdeho nirākṛtiḥ |
saṃvinmātrātmā pratighaḥ svānubhūto'pyasanmayaḥ
]

`v 14 [
saṃvinmayo yathā janturnidrātmāste jaḍobhavat |
jaḍībhūtā tathaiṣāste saṃvitsthāvaranāmikā
]

`v 15 [
sthāvaratvājjaḍāccittvaṃ jaṅgamātma prayāti cit |
jīvaḥ suṣuptātmā svapnaṃ jāgraccaiva jagacchataiḥ
]

`v 16 [
āmoṃkṣameṣā jīvasya bhuvyambhasyanile'nale |
khe khātmabhirjagallakṣaiḥ svapnābhairbhāsate sthitiḥ
]

`v 17 [
ciccinoti tathā jāḍyaṃ naro nidrāsthitiryathā |
cinoti jaḍatāṃ cittvaṃ na nāma jaḍatāvaśāt
]

`v 18 [
citā vedanavettāraṃ sthāvaraṃ kriyate vapuḥ |
citā vedanavettāraṃ jaṅgamaṃ kriyate vapuḥ
]

`v 19 [
yathā puṃso nakhāḥ pādāvekameva śarīrakam |
tathaikamevāpratighaṃ citaḥ sthāvarajaṅgamam
]

`v 20 [
ādisarge svapna iva yatprathāmāgataṃ sthitam |
cito rūpaṃ jagaditi tattathaivānta ucyate
]

`v 21 [
taccaivāpratighaṃ śāntaṃ yathāsthitamavasthitam |
na prathāmāgataṃ kiṃcinnāsīdaprathitaṃ hitam
]

`v 22 [
ayamādirayaṃ cāntaḥ sargasyetyavabhāsate |
citaḥ sughananidrāyāḥ suṣuptasvapnakoṣṭhataḥ
]

`v 23 [
sthita eko hyanādyantaḥ paramārthaghano yataḥ |
pralayasthitisargāṇāṃ na nāmāpyasti māṃ prati
]

`v 24 [
tatkutastatrāha - sthita iti | māṃ prabuddhaṃ prati nāmāpi nāsti dūre rūpamityarthaḥ |
23 |
pralayasthitisargādi dṛśyamānaṃ na vidyate |
etanna cātmanaścānyaccitre citravadhūryathā
]

`v 25 [
kartavyacitrasenāsmādyathā citrānna bhidyate |
nānā'nānaiva pratighā cittattve sargatā tathā
]

`v 26 [
vibhāgahīnayāpyeṣa bhāgaścidghananidrayā |
suṣuptānmuṣyate mokṣa iti svapnastu cittakam
]

`v 27 [
pralayo'yamiyaṃ sṛṣṭirayaṃ svapno ghanastvayam |
bhāso'pratigharūpasya citsahasraruceriti
]

`v 28 [
cinnidrāyāḥ svapnamayo bhāgaścittamudāhṛtam |
tadeva mucyate bhūtaṃ jīvo devāsurādidṛk
]

`v 29 [
eṣa eva parijñātaḥ suṣuptirbhavati svayam |
yadā tadā mokṣa iti procyate mokṣakāṅkṣibhiḥ
]

`v 30 [
śrīrāma uvāca |
cittaṃ devāsurādyātma cinnidrā svātmadarśanam |
kiyatpramāṇaṃ bhagavankathamasyodare jagat
]

`v 31 [
śrīvasiṣṭha uvāca |
viddhi cittaṃ naraṃ devamasuraṃ sthāvaraṃ striyam |
nāgaṃ nagaṃ piśācādi khagakīṭādirākṣasam
]

`v 32 [
pramāṇaṃ tasya cānantaṃ viddhi tadyatra reṇutām |
ābrahmastambaparyantaṃ jagadyāti sahasraśaḥ
]

`v 33 [
yadetadādityapathādūrdhvaṃ saṃyāti vedanam |
etaccittaṃ bhūtametadaparyantāmalākṛti
]

`v 34 [
etadugraṃ cito rūpamasyāntarbhuvanarddhayaḥ |
yadāyānti tadā sargaścittādāgata ucyate
]

`v 35 [
duḥsahasaṃsāraduḥkhabahulatvādugram | asyaiva samaṣṭyātmano'ntarbhuvanarddhayo
yadā brahmāṇḍādikalpanayā āyānti tadā sargaḥ sa cāsmābhiścittādāgata ityucyate | 34
|
cittameva vidurjīvaṃ tadādyantavivarjitam |
khaṃ ghaṭeṣviva deheṣu cāste nāste tadicchayā
]

`v 36 [
nimnonnatānbhuvo bhāgān gṛhṇāti ca jahāti ca |
saritpravāho'ṅga yathā śarīrāṇi tathā manaḥ
]

`v 37 [
asya tvātmaparijñānādeṣa dehādisaṃbhramaḥ |
śāmyatyāśvavabodhena maruvāḥpratyayo yathā
]

`v 38 [
jagatyantaraṇuryatra tatpramāṇaṃ hi cetasaḥ |
sadeva ca pumāṃstasmātpuṃsāmantaḥsthitaṃ jagat
]

`v 39 [
yāvatkiṃcididaṃ dṛśyaṃ taccittaṃ svapnabhūṣviva |
tadeva ca pumāṃstasmātko bhedo jagadātmanoḥ
]

`v 40 [
cidevāyaṃ padārthaugho nāstyanyasminpadārthatā |
vyatiriktā svapna iva hemnīva kaṭakāditā
]

`v 41 [
yathaikadeśe sarvatra sphurantyāpo'mbudhau pṛthak |
brahmaṇyananyā nityasthāścito dṛśyātmikāstathā
]

`v 42 [
yathā dravatvamambhodhāvāpo jaṭharakośagāḥ |
sphurantyevaṃ vido'nanyāḥ padārthaughāstathāpare
]

`v 43 [
yathāsthitajagacchālabhañjikākāśarūpadhṛk |
citstambhoyamapaspandaḥ sthita ādyantavarjitaḥ
]

`v 44 [
evaṃ ca yathāsthitajagallakṣaṇaḥ śālabhañjikānāṃ
yadākāśarūpamātyantikaśūnyatā tadrūpadhṛk citstambha eva nispando'calaḥ sthitaḥ |
43 |
yathāsthitamidaṃ viśvaṃ saṃvidvyomni vyavasthitam |
svarūpamatyajacchāntaṃ svapnabhūmāvivākhilam
]

`v 45 [
samatā satyatā sattā caikatā nirvikāritā |
ādhārādheyatānyonyaṃ caitayorviśvasaṃvidoḥ
]

`v 46 [
svapnasaṃkalpasaṃsāravaraśāpadṛśāmiha |
sarobdhisaridambūnāmivānyatvaṃ na vāthavā
]

`v 47 [
śrīrāma uvāca |
varaśāpārthasaṃvittau kāryakāraṇatā katham |
upādānaṃ vinā kāryaṃ nāstyeva kila kathyatām
]

`v 48 [
śrīvasiṣṭha uvāca |
svavadātacidākāśakacanaṃ jagaducyate |
sphuraṇe payasāmabdhāvāvartacalanaṃ yathā
]

`v 49 [
dhvananto'bdhijalānīva bhānti bhāvāścidātmakāḥ |
saṃkalpādīni nāmāni teṣāmāhurmanīṣiṇaḥ
]

`v 50 [
kālenābhyāsayogena vicāreṇa samena ca |
jātervā sāttvikatvena sāttvikenāmalātmanā
]

`v 51 [
samyagjñānavato jñasya yathā bhūtārthadarśinaḥ |
buddhirbhavati cinmātrarūpā dvaitaikyavarjitā
]

`v 52 [
nirāvaraṇavijñānamayī cidbrahmarūpiṇī |
saṃvitprakāśamātraikadehādehavivarjitā
]

`v 53 [
so'yaṃ paśyatyaśeṣeṇa yāvatsaṃkalpamātrakam |
svamātmakacanaṃ śāntamananyatparamārthataḥ
]

`v 54 [
asyā idaṃ hi saṃkalpamātramevākhilaṃ jagat |
yathā saṃkalpanagaraṃ yathā svapnamahāpuram
]

`v 55 [
ātmā svasaṃkalpavaraḥ svavadāto yathā yathā |
yadyathā saṃkalpayati tathā bhavati tasya tat
]

`v 56 [
saṃkalpanagare bālaḥ śilāproḍḍayanaṃ yathā |
satyaṃ vettyanubhūyāśu svavidheyaniyantraṇam
]

`v 57 [
svasaṃkalpātmabhūte'sminparamātmā jagattraye |
varaśāpādikaṃ satyaṃ vettyananyattathātmanaḥ
]

`v 58 [
svasaṃkalpapure tailaṃ yathā siddhyati saikatāt |
kalpanātsargasaṃkalpairvarādīha tathātmanaḥ
]

`v 59 [
anirāvaraṇajñapteryataḥ śāntā na bhedadhīḥ |
tataḥ saṃkalpanādvaitādvarādyasya na siddhyati
]

`v 60 [
yā yathā kalanā rūḍhā tāvatsādyāpi saṃsthitā |
na parāvartitā yāvadyatnātkalpanayānyayā
]

`v 61 [
brahmaṇyavayavonmukte dvitaikatve tathā sthire |
yathā sāvayave tattve vicitrāvayavakramaḥ
]

`v 62 [
śrīrāma uvāca |
anirāvaraṇājñānātkevalaṃ dharmacāriṇaḥ |
śāpādīnsaṃprayacchanti yathā brahmaṃstathā vada
]

`v 63 [
śrīvasiṣṭha uvāca |
saṃkalpayati yannāma sargādau brahma brahmaṇi |
tattadevānubhavati yasmāttatrāsti netarat
]

`v 64 [
brahma vetti yadātmānaṃ sa brahmāyaṃ prajāpatiḥ |
sa ca no brahmaṇo bhinnaṃ dravatvamiva vāriṇaḥ
]

`v 65 [
saṃkalpayati yannāma prathamo'sau prajāpatiḥ |
tattadevāśu bhavati tasyedaṃ kalpanaṃ jagat
]

`v 66 [
nirādhāraṃ nirālambaṃ vyomātma vyomni bhāsate |
durdṛṣṭeriva keśoṇḍraṃ dṛṣṭamuktāvalīva ca
]

`v 67 [
saṃkalpitāḥ prajāstena dharmo dānaṃ tapo guṇāḥ |
vedāḥ śāstrāṇi bhūtāni pañca jñānopadeśanāḥ
]

`v 68 [
tapasvino'tha vādaiśca yadbrūyuravilambitam |
yadyadvedavidastatsyāditi tenātha kalpitam
]

`v 69 [
idaṃ cidbrahmacchidraṃ khaṃ vāyuśceṣṭāgniruṣṇatā |
dravo'mbhaḥ kaṭhinaṃ bhūmiriti tenātha kalpitāḥ
]

`v 70 [
ciddhāturīdṛśo vāsau yadyatkhātmāpi cetati |
tattathānubhavatyāśu tvamahaṃ sa ivākhilam
]

`v 71 [
yadyathā vetti cidvyoma tattathā tadbhavatyalam |
svapne tvamahamādīva sadātmāpyasadātmakam
]

`v 72 [
śilānṛtaṃ yathā satyaṃ saṃkalpanagare tathā |
jagatsaṃkalpanagare satyaṃ brahmaṇa īpsitam
]

`v 73 [
citsvabhāvena śuddhena yadbuddhaṃ yacca yādṛśam |
tadaśuddho'nyathā kartuṃ na śaktaḥ kīṭako yathā
]

`v 74 [
abhyastaṃ bahulaṃ saṃvitpaśyatītaradalpakam |
svapne jāgratsvarūpe ca vartamāne'khilaṃ ca sat
]

`v 75 [
sadā cidvyoma cidvyomni kacadekamidaṃ nijam |
draṣṭṭadṛśyātmakaṃ rūpaṃ paśyadābhāti netarat
]

`v 76 [
ekaṃ draṣṭā ca dṛśyaṃ ca cinnabhaḥ sarvagaṃ yataḥ |
tasmādyatheṣṭaṃ yadyatra dṛṣṭaṃ tattatra satsadā
]

`v 77 [
vāyvaṅgagaspandanavajjalāṅgadravabhāvavat |
yathā brahmaṇi brahmatvaṃ tathājasyāṅgagaṃ jagat
]

`v 78 [
brahmaivāhaṃ virāḍātmā virāḍātmavapurjagat |
bhedo na brahmajagatoḥ śūnyatvāmbarayoriva
]

`v 79 [
yathā prapāte payaso vicitrāḥ kaṇapaṅktayaḥ |
vicitradeśakālāntā nipatantyutpatanti ca
]

`v 80 [
nipattyaivaikayā''kalpaṃ manobuddhyādivarjitāḥ |
ātmanyevātmano bhānti tathā ya brahmasaṃvidaḥ
]

`v 81 [
tābhiḥ svayaṃ svadeheṣu buddhyādiparikalpanāḥ |
kṛtvorarīkṛtā sargaśrīradbhirdravatā yathā
]

`v 82 [
tadevaṃ jagadityasti durbodhena mama tvidam |
akāraṇakamadvaitamajātaṃ karma kevalam
]

`v 83 [
astasthitiḥ śarīre'sminyādṛgrūpānubhūyate |
upalādau jaḍā sattā tādṛśī paramātmanaḥ
]

`v 84 [
yathaikasyāṃ sunidrāyāṃ suṣuptasvapnakau sthitau |
tathaite sargasaṃhārabhāsau brahmaṇi saṃsthite
]

`v 85 [
evaṃ ca sṛṣṭipralayau dvāvapyajñānanidrāvāntaraviśeṣāvevetyāha - yatheti | 84
|
suṣuptasvapnayorbhātaḥ prakāśatamasī yathā |
ekasyāmeva nidrāyāṃ sargāsargau tathā pare
]

`v 86 [
yathā naro'nubhavati nidrāyāṃ dṛṣadaḥ sthitim |
paramātmānubhavati tathaitajjaḍasaṃsthitim
]

`v 87 [
aṅguṣṭhasyāthavāṅgulyā vātādyasparśane sati |
yo'nyacittasyānubhavo dṛṣadādau sa ātmanaḥ
]

`v 88 [
vyomopalajalādīnāṃ yathā dehānubhūtayaḥ |
tathāsmākamacittānāmadya nānānubhūtayaḥ
]

`v 89 [
kāle kalpeṣu bhāntyetā yathāhorātrasaṃvidaḥ |
tathā'saṃkhyāḥ pare bhānti sargasaṃhārasaṃvidaḥ
]

`v 90 [
ālokarūpamananānubhavaiṣaṇecchāmuktātmani sphurati vārighane svabhāvāt |
āvartavīcivalayādi yathā tathāyaṃ śānte pare sphurati saṃhṛtisargapūgaḥ
]