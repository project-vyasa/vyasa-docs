`v 1 [
catuḥsaptatitamaḥ sargaḥ 74
śrīvasiṣṭha uvāca |
tasminkalpe tu saṃkalpe tasya yadvapurāsthitam |
śṛṇu tatra vyavastheyaṃn vicitrācārahāriṇī
]

`v 2 [
paramaṃ yaccidākāśaṃ tadvirāḍātmano vapuḥ |
ādyantamadhyarahitaṃ laghu tvasya vapurjagat
]

`v 3 [
saṃkalparahito brahmā svāṇḍaṃ saṃkalpanātmakam |
vapuṣaḥ parito bhāsvatpaśyatyākāśameva tat
]

`v 4 [
brahmātmaiva svasaṃkalpaṃ svamaṇḍamakaroddvidhā |
taijasaṃ taijasākāraḥ puṣṭaḥ puṣṭaṃ vihaṃgavat
]

`v 5 [
aṇḍasyaikaṃ nabho dūraṃ gataṃ saṃbuddhavānasau |
bhuvodhaḥsaṃsthitaṃ bhāgaṃ vyatiriktaṃ ca nātmanā
]

`v 6 [
dūramūrdhvaṃ gatamiti saṃbuddhavān saṃkalpitavān evamātmanā na
vyatiriktamabhinnaṃ ca saṃkalpitavān | madhyamātrakhaṃ āntarākāśamadhyamiti yāvat |
5 |
brahmāṇḍabhāga ūrdhvastho virājaḥ śira ucyate |
adhobhāgo'sya pādākhyo nitambo madhyamātrakham
]

`v 7 [
dūraṃ vimuktayoḥ saṃdhiḥ khaṇḍayoriti vistṛtā |
anantā vyomalekhā sā śyāmā śūnyeti dṛśyate
]

`v 8 [
dyaustālu vipulaṃ tasya tārārudhirabindavaḥ |
saṃvidvātalavā dehe surāsuranarādayaḥ
]

`v 9 [
dehāntaḥ kṛmayastasya bhūtapretapiśācakāḥ |
lokāntarāṇi randhrāṇi suṣirāṇyasya dehake
]

`v 10 [
bhūtapretapiśācakā raktamāṃsādyaśucilolupatvātkṛmayaḥ | lokāntarāṇi
sūryacandrādilokāścakṣurādirandhrāṇi | yāmyādinārakalokāntarāṇyadhaḥsuṣirāṇi | 9
|
brahmāṇḍakhaṇḍamasyādho vistṛtaṃ pādayostalam |
jānumaṇḍalarandhrāṇi pātālakuharāṇyadhaḥ
]

`v 11 [
jalaiścalacalāyantī suṣirānekarandhrikā |
bhūrantarmaṇḍalī lolā samudradvīpaveṣṭanā
]

`v 12 [
jalairguḍaguḍāyantyo nadyo nāḍyaḥ saridrasaḥ |
jambūdvīpaṃ hṛdambhojamasya hemādrikarṇikam
]

`v 13 [
kukṣayaḥ kakubhaḥ śūnyā yakṛtplīhādayo'calāḥ |
mṛdvyaḥ snigdhāḥ paṭākārā medaso jālikā ghanāḥ
]

`v 14 [
candrārkau locane tasya brahmaloko mukhaṃ smṛtam |
tejaḥ somo'sya kathitaḥ śleṣmā prāleyaparvataḥ
]

`v 15 [
agnilokastathairvāgniḥ pittamasyātiduḥsaham |
vātaskandhamahāvātāḥ prāṇāpānā hṛdi sthitāḥ
]

`v 16 [
kalpadrumavanānyasya sarpavṛndāni ca kvacit |
lomajālānyanantāni vanānyupavanāni ca
]

`v 17 [
ūrdhvaṃ brahmāṇḍakhaṇḍaṃ tu samastamurumastakam |
brahmāṇḍaprāntarandhrārcirasya dīptā śikhotthitā
]

`v 18 [
svayameṣa manastena mano nāsyopayujyate |
ātmaiva bhoktṛtāmeti kila kasya kathaṃ kutaḥ
]

`v 19 [
svayamevendriyāṇyeṣa tenānyatrāstitā kṛtā |
yatastatkalpanāmātramevendriyagaṇaḥ kila
]

`v 20 [
avayavāvayavinorivehendriyacittayoḥ |
na manāgapi bhedo'sti caikyamekaśarīrayoḥ
]

`v 21 [
tasya tānyeva kāryāṇi jagatāṃ yāni kānicit |
saṃkalpā eva puṃvṛttyā calantyārūpitadvitāḥ
]

`v 22 [
jāgate tasya vijñeye nānye'sya mṛtijanmanī |
sa evedaṃ jagatyasmatsaṃkalpātmāsya netarat
]

`v 23 [
tatsattayā jagatsattā tanmṛtyaiva jaganmṛtam |
yādṛśī spandamarutoḥ sattikā tādṛśī tayoḥ
]

`v 24 [
jagadvirājoḥ sattikā pavanaspandayoriva |
jagadyatsa virāḍeva yo virāṭ tajjagatsmṛtam
]

`v 25 [
jagadbrahmā virāṭ ceti śabdāḥ paryāyavācakāḥ |
saṃkalpamātramevaite śuddhacidvyomarūpiṇaḥ
]

`v 26 [
śrīrāma uvāca |
saṃkalpātsa virāḍeva khamevākṛtimāgatam |
astu nāma svadehāntaḥ kathaṃ brahmaiva tiṣṭhati
]

`v 27 [
śrīvasiṣṭha uvāca |
yathā dhyānena dehāntastiṣṭhasi tvaṃ yathā sthitam |
tathāste nijadehe'ntaḥ saṃkalpātmā pitāmahaḥ
]

`v 28 [
nṛṇāṃ tathā ca mukhyānāṃ jīvo brahmapurodare |
utpattiputrikādehaḥ pratibimbopamo'sti saḥ
]

`v 29 [
yatra tvamapi dehāntaḥ kartuṃ śakto'syalaṃ sthitam |
saṃkalpātmā vibhustatra brahmā kiṃ na kariṣyati
]

`v 30 [
bījāntaḥ sthāvaraṃ hyāste padārthe yatra jaṃgamaḥ |
kiṃ nāste tatra dehe'ntarnijacitkalpanātmikā
]

`v 31 [
sākāro gaganātmāstu nirākāraṃ khanastu vā |
āste bahirathāntaśca bhinne bāhyāntare bahiḥ
]

`v 32 [
ātmārāmaḥ kāṣṭhamaunī na jaḍo'pi dṛṣajjaḍaḥ |
ahaṃtvamityādimayo virāḍātmani tiṣṭhati
]

`v 33 [
āveṣṭitojjhitalatātṛṇadārupiṃvaducchabdamamburayavacca viropitāṅgaḥ |
nānāvidhe'pi viharannapi kāryajāle tajjñaḥ śilājaṭharaśāntamanaska eva
]