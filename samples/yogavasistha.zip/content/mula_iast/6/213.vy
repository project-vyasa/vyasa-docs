`v 1 [
trayodaśādhikadviśatatamaḥ sargaḥ 213
śrīvasiṣṭha uvāca |
yathā yatpṛṣṭavānadya tvaṃ māmariniṣūdana |
śiṣyeṇaiva satā pūrvamahaṃ pṛṣṭo gurustvayā
]

`v 2 [
purākalpe hi kasmiṃścittattvamātmādikātmikā |
āsīdityaṃ citpratibhā guruśiṣyātmanā vane
]

`v 3 [
gurustatrāhamabhavaṃ śiṣyastvamabhavastadā |
pṛṣṭavānmāṃ tvamagrastha idamuddāmadhīradhīḥ
]

`v 4 [
śiṣya uvāca |
sarvasya bhagavañchindi mamemamatisaṃśayam |
kiṃ naśyati mahākalpe kiṃ vastu na vinaśyati
]

`v 5 [
gururuvāca |
putra śeṣamaśeṣeṇa dṛśyamāśu vinaśyati |
yathā tathā svapnapuraṃ sauṣuptīṃ sthitimīyuṣaḥ
]

`v 6 [
nirviśeṣeṇa naśyanti bhuvaḥ śailā diśo daśa |
kriyā kālaḥ kramaścaiva na kiṃcidavaśiṣyate
]

`v 7 [
naśyanti sarvabhūtāni vyomāpi pariṇaśyati |
sa sarvajagadābhāsamupalabdhurasaṃbhavāt
]

`v 8 [
brahmaviṣṇvindrarudrādyā ye hi kāraṇakāraṇam |
teṣāmapyatikalpānte nāmāpīha na vidayte
]

`v 9 [
śiṣyate hi cidākāśamavyayasyānumīyate |
tatkālaśeṣatānena sargānubhavahetunā
]

`v 10 [
śiṣya uvāca |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ |
idaṃ tatkathamābhogi vidyamānaṃ kva gacchati
]

`v 11 [
gururuvāca |
na vinaśyata evedaṃ tataḥ putra na vidyate |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ
]

`v 12 [
yattu vastuta evāsti na kadācana kiṃcana |
tadabhāvātma tadrāma kathaṃ nāma vinaśyati
]

`v 13 [
kva sthitaṃ mṛgatṛṣṇāmbu kva sthiro dvīnduvibhramaḥ |
kva sthirā keśadṛgvyomni kva bhrāntyanubhavaḥ sthiraḥ
]

`v 14 [
sarvaṃ dṛśyamidaṃ putra bhrāntimātramasanmayam |
svapne puramivābhāti kathametanna śāmyati
]

`v 15 [
śāmyatīdamaśeṣeṇa tathā sarvatra sarvadā |
yathā jāgradvidhau svapnaḥ svapne vā jāgaro yathā
]

`v 16 [
yathā svapnapuraṃ śāntaṃ na jāne kvāśu gacchati |
śāntaṃ tathā jagaddṛśyaṃ na jāne kvāśu gacchati
]

`v 17 [
yadi nāstyeva dṛśyaṃ tarhi dṛśyaveṣeṇa kaṃcitkālaṃ paramārthataḥ kiṃ vastu
bhāti tadeva bodhottaraṃ punastathā na vibhāti ca kimarthamityarthaḥ
]

`v 18 [
gururuvāca |
cidākāśamidaṃ putra svacchaṃ kacakacāyate |
yannāma tajjagadbhāti jagadanyanna vidyate
]

`v 19 [
asyaitadvastuno rūpaṃ cidvyomno vitatākṛteḥ |
rūpamatyajadevācchaṃ yaditthamavabhāsate
]

`v 20 [
kacanākacanaṃ sargakṣayātmāsya nijaṃ vapuḥ |
vyomātma śuklakṛṣṇaṃ syādyathāvayavino vapuh
]

`v 21 [
yathāyaṃ tvaṃ sitodāntareka evāditaḥ kacaiḥ |
tathā brahmaivamacchātma sarge sargakṣaye'kṣayam
]

`v 22 [
yathā svapne suṣupte ca nidraikaivākṣayāniśam |
sarge'sminpralaye caiva brahmaikaṃ citiravyayam
]

`v 23 [
yathā svapne jagaddraṣṭuḥ śāntaṃ śāmyatyaśeṣataḥ |
tadvadasmajjagadidaṃ śāntaṃ śāmyatyaśeṣataḥ
]

`v 24 [
tadanyatrāsti khe khākhyaṃ tathetyaṅga na vidmahe |
aśaṅkyaṃ parakhe tvetadasmaccidvyomni saṃbhavāt
]

`v 25 [
yathehāsmaccidākāśakacanaṃ sargasaṃkṣaye |
tathānyatsaṃvidākāśaṃ naivamityatra kā pramā
]

`v 26 [
śiṣya uvāca |
evaṃ cittadyathā svapne draṣṭuranyaḥ sa dṛśyadhīḥ |
vidyate tadvadanyatra manye'sti jagadādidhīḥ
]

`v 27 [
gururuvāca |
evametanmahāprājña svarūpaṃ tu na tajjagat |
citi bhāti svarūpaṃ tattadvadeva na bhāti ca
]

`v 28 [
na bhāti na ca tatkiṃcinna ca tatkiṃcideva sat |
taccidākāśakacanaṃ ke tatra sadasaddṛśau
]

`v 29 [
vidyate taddhi sarvatra sarvaṃ sarveṇa sarvadā |
na vidyate ca tatkiṃcitsarvaṃ sarvatra sarvadā
]

`v 30 [
tatsattatsarvadā sarvamasaccāsaddhi vākhilam |
tanmayaṃ taccidākāśaṃ na nāśi na ca nāśi tat
]

`v 31 [
yannāma saccidākāśaṃ sargapralayarūpi tat |
tadduḥkhāyāparijñātaṃ parijñātaṃ paraḥ śamaḥ
]

`v 32 [
vidyate sarvathaivedaṃ sarvaṃ sarvatra sarvadā |
na vidyate sarvathā ca sarvaṃ sarvatra sarvadā
]

`v 33 [
eṣa devo ghaṭaḥ śailaḥ paṭaḥ sphoṭastaṭo vaṭaḥ |
tṛṇamagniḥ sthāvaraṃ ca jaṃgamaṃ sarvameva ca
]

`v 34 [
asti nāsti ca śūnyaṃ ca kriyā kālo nabho mahī |
bhāvābhāvau bhavo bhūtirnāśāḥ pāśāḥ śubhāśubhāḥ
]

`v 35 [
tannāstyeva na yannāma nityamekastathā bahiḥ |
ādimadhyamathāntaṃ tu kālatritayameva ca
]

`v 36 [
sarvaṃ sarveṇa sarvatra sarvadaivātra vidyate |
sarvaṃ sarveṇa sarvatra sarvadātra na vidyate
]

`v 37 [
yadaiva. rāma sarvātma sarvamevāsti sarvadā |
brahmātmatvātsvapnasaṃvitpuranyāyena vai tadā
]

`v 38 [
brahmabhāvena darśane tṛṣṇādayaḥ sarve padārthāḥ pratyekaṃ sarvakartāraḥ
sarvabhoktāraḥ sarveśvarāścetyetadapi prapañcayati - brahmātmatvādityādinā | 37
|
tṛṇaṃ kartṛ tṛṇaṃn bhoktṛ brahmātmatvāttṛṇaṃ vibhuḥ |
ghaṭaḥ kartā ghaṭo bhoktā ghaṭaḥ sarveśvareśvaraḥ
]

`v 39 [
paṭaḥ kartā paṭo bhoktā paṭaḥ sarveśvareśvaraḥ |
dṛśiḥ kartā dṛśirbhoktā dṛśiḥ sarveśvareśvaraḥ
]

`v 40 [
giriḥ kartā girirbhoktā giriḥ sarveśvareśvaraḥ |
naraḥ kartā naro bhoktā naraḥ sarveśvareśvaraḥ
]

`v 41 [
pratyekaṃ sarvavastūnāṃ kartā bhoktā parātparaḥ |
anādinidhano dhātā sarvaṃ brahmātmakaṃ yataḥ
]

`v 42 [
sarvavastūnāṃ pratyekamekaṃ vastu kartā bhoktā parātparaḥ śreṣṭhādapi śreṣṭhaḥ |
41 |
tṛṇakumbhādayastvete svayā vibhutayā vibhuḥ |
evaṃrūpā sthitā rūpaṃ yadvibhātaḥ kṣayodayau
]

`v 43 [
bāhyo'rthosti sa eveha kartā bhoktā tathāvidhaḥ |
vijñānamātramevāsti kartṛ bhoktṛ tathāvidām
]

`v 44 [
ukte'rthe vādināmanubhavaṃ saṃvādayati - bāhyo'rtha iti | yeṣāṃ bāhyo
vijñānātirikto'rthosti teṣāṃ sa eva kartā bhoktā ca | yathā vaiśeṣikasautrāntikādīnām |
yeṣāṃ tu vādināṃ vijñānamātramevāsti tathāvidāṃ teṣāṃ tadeva kartṛ bhoktṛ ca |
43 |
na kaściccaiva karteha na ca bhoktā tathāvidām |
kaścidīśvara eveha kartā bhoktā tathāvidām
]

`v 45 [
sarvameva pade tasminsaṃbhavatyuttamottame |
vidhayaḥ pratiṣedhāśca ke te santi na santi ke
]

`v 46 [
śuddhe draṣṭeva cidvyoma dṛśyatāmiva bhāvayat |
svmātmānaṃ jagaditi paśyettiṣṭhedanāmayam
]

`v 47 [
sarvā dṛśo vidhiniṣedhadṛśaśca sarvāḥ
saṃkalpavedanaviśeṣasaśeṣapūrvāḥ |
satyātmikāḥ satatameva na caiva satyā rūpaṃ yathānubhavamatra yataḥ svarūpam |
47 |
he rāma sarveṣāṃ jīvānāṃ sarvāḥ svasvānubhavasiddhāḥ padārthādidṛśaḥ sarvāḥ
parasparavilakṣaṇavidhiniṣedhadṛśaśca
yasmāttattatsaṃkalpatattadvedanaviśeṣatattadanubhavaśeṣavāsanāsahitatattatkāma##-
tattadarthakriyāsamarthatvātsatyātmikāḥ paradṛśā tu pratīterevābhāvānna caiva satyāḥ
śaśa"ṣṛṅgakalpāḥ | yataḥ pratyagātmarūpaṃ yathānubhavameva jagadrūpaṃ dhatte
iti śeṣaḥ
]

`v 48 [
iti tvayā śiṣyatayā madantikācchrutaṃ purā tena na cāsi buddhavān |
tato'nubhūyānyajagadbhavādbhavānihādya jāto'si tadeva pṛcchasi
]

`v 49 [
jñānaṃ sadetadakhilaṃ śrutamuttamaṃ citsaṃsāradīrgharajanīsitaraśmibimbam |
jātastvamabhyudayavānamalaikabodha utsārya mohamanutiṣṭha yathāgataṃ tvam |
49 |
atrāpi tvayā madupadiṣṭamuttamaṃ sat paramārthavastugocaramata eva saṃsāralakṣaṇāyā
dīrgharajanyāstāpatamonivartakatvātsitaraśmeḥ pūrṇacandrasya bimbamiva sthitaṃ
jñānamakhilaṃ samagraṃ śrutaṃ tena tvaṃ mohamajñānamutsārya
niratiśayānandarūpaparamapuruṣārthalābhābhyudayavān amalaikabodharūpo jātaḥ evaṃ
kṛtakṛtyastvamataḥparaṃ yathāgataṃ vyavahāraparaṃparāprāptaṃ
svarājyaparipālanādikamanutiṣṭha
]

`v 50 [
tiṣṭhaṃstadātmani pare vimalasvabhāve sarvātmake tapati sarvapadārthamuktaḥ |
nirvāṇaśantamatirambarakośakānto dharmeṇa rājyamanupālaya tīrṇatṛṣṇaḥ |
50 |
he rāma tvaṃ vimalasvabhāve tapati sarvataḥ prakāśamāne sarvātmake ātmani
sarvadṛśyapadārthamuktastiṣṭhansan nirvāṇo niratiśayānandamagno'tra eva śāntā
matiryasya tahāvidhaḥ sannambarakośamiva kānto manoharastīrṇastṛṣṇaḥ san dharmeṇa
rājyamanupālayetyante maṅgalārthamāśīḥ
]