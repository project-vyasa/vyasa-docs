`v 1 [
caturdaśādhikadviśatatamaḥ sargaḥ 214
śrīvālmīkiruvāca |
ityuktavatyatha munau nabhaso nanāda varṣāmṛtābhramiva dundubhirāmaro drāk |
śuklikṛtākhilakakubvadanā tuṣāravrṣopamā bhuvi papāta ca puṣpavṛṣṭiḥ
]

`v 2 [
kiṃjalkajāladivasāntaghanāṅgarāgā vātāvadhūtasitakesaragaurahārā |
puṣpodarotthamṛdusīkaraśītalāṅgā prāptā svayaṃ surapurādiva puṇyalakṣmīḥ
]

`v 3 [
kalpāntakālakapikampitaśuṣkaśākhātsvargadrumātpatitamāśu viḍambayantī |
tārāgaṇaṃ prathitabhāsamanalpahāsamāśāmukhaprasṛtabhairavamambarasthā |
3 |
punaḥ kīdṛśī sā puṣpavṛṣṭiḥ | kalpāntakālalakṣaṇo yaḥ kapirmarkaṭastena
kampitāḥ śuṣkāḥ kalpadrumaśākhā dikpālapuralokabhedarūpaśākhāśca yasya
tathāvidhātsvrgarūpāddrumādāśu patitaṃ āśāmukheṣu jhaṭiti pātanāya prasṛto
bhairavaḥ saṃhārarudro yasya tathāvidhaṃ prathitabhāsaṃ tārāgaṇamaṃbarasthā
satītyanalpahāsaṃ yathā syāttathā viḍambayantī tārāgaṇaprathitahāsaṃ bhairavaṃ ca
viḍambayantīti vā utprekṣā
]

`v 4 [
sā puṣpavṛṣṭiratha dundubhinādagarjatkiṃjalkapuñjajaladā śamamājagāma |
āpūritākhilasabhā himahāripuṣpapūreṇa kautukavikāsakarīkṣaṇena
]

`v 5 [
tāni divyāni puṣpāṇi yathāsthānamadhaḥsthitāḥ |
vasiṣṭhāya namaskṛtvā sabhyāḥ saṃśokitāṃ jahuḥ
]

`v 6 [
daśaratha uvāca |
aho'nusuviśātmānaḥ saṃsāravitatākṛteḥ |
viśrāntāḥ smaściraṃ śrāntāḥ śuddhā meghā ivācale
]

`v 7 [
karmaṇāmavadhiḥ pūrṇo dṛṣṭaḥ sīmānta āpadām |
jñātaṃ jñeyamaśeṣeṇa viśrāntāḥ smaḥ pare pade
]

`v 8 [
dhyānalabdhaparavyomacirānubhavanabhramaiḥ |
dhāraṇādhāraviśrāntyā dehasaṃtyajanakramaiḥ
]

`v 9 [
sarveṣāṃ tṛtīyāntapadānāṃ ṣaṣṭhaśloke evamādibhiranyaiśca
dṛṣṭāntairdṛśyadṛṣṭirmārjitetyatrānvayaḥ | dhyānena labdhaṃ kalpitaṃ
paramanyadvyoma tatra ciraṃ vihārādyanubhavanabhramairlīlopākhyānādau pradarśitaiḥ
dhāraṇayā sarvādhāre brahmaṇi viśrāntyā dehasaṃtyajanakramo'pi līlāyā varṇita eva | 8
|
saṃkalpanavanirmāṇaiḥ svapnadṛṣṭijagajjvaraiḥ |
śuktirūpyānubhavanaiḥ svapnātmamṛtidarśanaiḥ
]

`v 10 [
ananyaiḥ pavanaspandairananyaiḥ saliladravaiḥ |
indrajālapurāpūrairgandharvanagarotkaraiḥ
]

`v 11 [
māyāpūrṇapurābhogairmṛgatṛṣṇānadīrayaiḥ `note[mūlapāṭhe
hrasvatvamārṣaṃ purābogairiti vā pāṭhaḥ sādhuḥ |] |
āyatau pavanasparśairdvicandrānubhavodayaiḥ
]

`v 12 [
madabhraṃśapuraspandairmudhā tvavanikampanaiḥ |
bālayakṣādyanubhavaiḥ khakeśoṇḍrakadarśanaiḥ
]

`v 13 [
evamādibhranyaiśca dṛṣṭāntaiḥ svānubhūtidaiḥ |
aho nu mārjitā dṛśyadṛṣṭirbhagavatā mama
]

`v 14 [
śrīrāma uvāca |
naṣṭo mohaḥ padaṃ prāptaṃ tvatprasādānmunīśvara |
saṃpanno'hamahaṃ satyamatyantamavadātadhīḥ
]

`v 15 [
sthito'smi gatasaṃdehaḥ svabhāve brahmarūpiṇi |
nirāvaraṇavijñānaḥ kariṣye vacanaṃ tava
]

`v 16 [
smṛtvā smṛtvā'mṛtāsekasaukhyadaṃ vacanaṃ tava |
arhito'pi ca śāntopi hṛṣyāmīva muhurmuhuḥ
]

`v 17 [
naiva me'dya kṛtenārtho nākṛteneha kaścana |
yathā sthito'smi tiṣṭhāmi tathaiva vigatajvaraḥ
]

`v 18 [
upāyastu tathā tena dṛṣṭirvāstīha kīdṛśī |
aho nu vitatā bhūmiḥ kaṣṭametādṛśī daśā
]

`v 19 [
na śatrurna ca mitraṃ me na kṣetraṃ durjano janaḥ |
durbodhaiṣā jagatkṣubdhā śāntā sarvārthasundarī
]

`v 20 [
kathametāṃ jano vetti vinā bhavadanugraham |
vinaiva setuṃ potaṃ vā bālo'bdhiṃ laṅghayetkatham
]

`v 21 [
lakṣmaṇa uvāca |
janmāntaropacitasaṃśayanāśanena janmāntaropacitapuṇyaśatoditena |
jāto'dya me munivacaḥparibodhanena jāto'dya me manasi candra iva prakāśaḥ
]

`v 22 [
īdṛśyāṃ dṛśyamānāyāṃ dṛśi doṣadaśāśataiḥ |
kāṣṭhavaddahyate lokaḥ svadurbhagatayā tayā
]

`v 23 [
viśvāmitra uvāca |
aho bata mahatpuṇyaṃ śrutaṃ jñānaṃ munermukhāt |
yena gaṅgāsahasreṇa snātā iva vayaṃ sthitāḥ
]

`v 24 [
śrīrāma uvāca |
saṃpadāmatha dṛṣṭīnāṃ śāstrāṇāmāpadāṃ girām |
deśānāmatha dṛṣṭānāṃ dṛṣṭaḥ sīmānta uttamaḥ
]

`v 25 [
nārada uvāca |
yanna śrutaṃ brahmaloke svarge bhūmitale tathā |
karṇau tajjñānamākarṇya yātau me'dya pavitratām
]

`v 26 [
lakṣmaṇa uvāca |
hārdaṃ bāhyaṃ ca timiramapamṛṣṭavatā tvayā |
mune paramabhānutvaṃ nūnaṃ naḥ saṃpradarśitam
]

`v 27 [
śatrughna uvāca |
nirvṛto'smi praśānto'smi prāptosmi paramaṃ padam |
cirāya paripūrṇo'smi sukhamāse ca kevalam
]

`v 28 [
daśaratha uvāca |
bahujanmopalabdhena puṇyenāyaṃ munīśvaraḥ |
dhīraḥ kathitavānnastadyena pāvanatāṃ gatāḥ
]

`v 29 [
śrīvālmīkiruvāca |
iti teṣu vadatsvatra sabhyeṣu saha bhūbhṛtā |
vasiṣṭhaḥ sa uvācedaṃ jñānapāvanayā girā
]

`v 30 [
rājan raghukulaikendo yadahaṃ vacmi tatkuru |
itihāsakathānte hi pūjanīyā dvijātayaḥ
]

`v 31 [
idānīṃ śrīvasiṣṭho maṅgalādīni maṅgalamadhyāni maṅgalāntāni śāstrāṇi
prathante vīrapuruṣakāṇyāyuṣmatpuruṣakāṇi ca bhavanti adhyetāraśca maṅgalayuktā
yathā syuḥ iti mahābhāṣye bhagavatpatañjalinodāhṛtāṃ śrutimanusṛtya nirvighnaṃ
samāptasya mahataḥ śāstroktaphalasiddhaye
brāhmaṇadevapitṛsujanapūjotsavādimaṅgalamaucityajñāpanamukhenājñāpayati ##-
tadadya brāhmaṇaughāṃstvaṃ sarvakāmaiḥ prapūraya |
vedārthasamanuṣṭhānaphalaṃ prāpsyasi śāśvatam
]

`v 32 [
mokṣopāyakathāvastusamāptau dvijapūjanam |
śaktitaḥ kīṭakenāpi kāryaṃ kimu mahībhṛtā
]

`v 33 [
iti maunaṃ vacaḥ śrutvā sahasrāṇi nṛpo daśa |
dūtairākārayāmāsa dvijānāṃ vedavādinām
]

`v 34 [
mathurāyāṃ surāṣṭreṣu gauḍeṣu ca vasanti ye |
tebhyaḥ kulebhyaḥ so'bhyarcya samānīya dvijanmanām
]

`v 35 [
adhikātyadhikajñānaprakṛtadvijabhojanaḥ |
tadā daśasahasrāṇi bhojayāmāsa bhūpatiḥ
]

`v 36 [
yathābhimatabhojyānnadānadakṣiṇayā tayā |
evaṃ saṃpūjya tānviprānpitṛndevānnṛpāṃstathā
]

`v 37 [
paurāmātyāṃstathā bhṛtyāndīnāndhakṛpaṇāṃśca tān |
tasmindaśaratho rājā dine saha suhṛjjanaiḥ
]

`v 38 [
labdhasaṃsṛtisīmāntaścakārotsavamuttamam |
tathā nṛpagṛhe tasminkauśeyamaṇikāñcane
]

`v 39 [
bhūṣite nagare caiva gīrvāṇanagasundare |
nanṛturmattakāminyo vilāsinyo gṛhe gṛhe
]

`v 40 [
lasadvaṃśalatākāṃsyavīṇāmurajamardalam |
tāṇḍavenoddhatārāvamanyonyetaraśekharāḥ
]

`v 41 [
kṣubdhīkṛtāpaṇakarabhrāntipallavitāmbarāḥ |
mugdhāṭṭahāsavikṣiptadantendukiraṇacchaṭāḥ
]

`v 42 [
madākulitahuṃkārā līlāsu taralasvarāḥ |
ekapādatalāghātahelāhatadharātalāḥ
]

`v 43 [
sragdāmatāravigalatkusumāsārapāṇḍurāḥ |
dhārāpātitavicchinnahāramuktāskhalatpadāḥ
]

`v 44 [
lolābharaṇasākāraṃ kāmaṃ nanṛturaṅganāḥ |
peṭhuḥ sphuṭapadaṃ viprā bandino'pyaṅganāśca tāḥ
]

`v 45 [
papuruttāṇḍavaṃ pānaṃ pānapā madaśālinaḥ |
bhojyaṃ bubhujire citraṃ bhūṣitā bhojanārthinaḥ
]

`v 46 [
sudhādiparilepena rañjitā gṛhabhittayaḥ |
rejū rāmendubhānena puṣpadhūpavilepanaiḥ
]

`v 47 [
vāsāṃsi vasiṃtāścitrāṇyuttamasragvibhūṣaṇāḥ |
ceruḥ paricarāśceṭyaścārugandhā nṛpādhvare
]

`v 48 [
dehayaṣṭiṣu saṃyojya vanitā yakṣakardamam |
jagmustāṇḍavanartakyaḥ śṛṅgārātmāṅgaṇāntaram
]

`v 49 [
bhavabahulaniśāvasānaharṣāditi ghanamutsavameva saptarātram |
daśarathanṛpatiḥ sadānabhogaśriyamakarotpadamakṣayaṃ sametaḥ
]