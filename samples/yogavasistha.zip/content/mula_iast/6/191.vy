`v 1 [
ekanavatyadhikaśatatamaḥ sargaḥ 191
śrīrāma uvāca |
evaṃ cettanmuniśreṣṭha paramārthamayaṃ jagat |
sarvadā sarvabhāvātmā nodeti na ca śāmyati
]

`v 2 [
bhrāntireveyamābhāti jagadābhāsarūpiṇī |
bhrāntirevāpi vā naiva brahmasattaiva kevalā
]

`v 3 [
śrīvasiṣṭha uvāca |
kākatālīyavadbrahma yadbhātīvātmanātmani |
sa tenaivātmanātmaiva jagadityavabudhyate
]

`v 4 [
śrīrāma uvāca |
kathaṃ tapatyaho'dikkaṃ sargasyādau paratra ca |
kathaṃ bhittyā vinā bhāti vada dīpaprabhā mune
]

`v 5 [
śrīvasiṣṭha uvāca |
itthaṃrūpamidaṃ bhāti citirūpaprabhāprabhā |
paśya saivātmanāśte yatprakāśādibhireva ca
]

`v 6 [
bhittau prakāśo bhātīva tatkuḍyaṃ bhāsanaṃ ca tat |
dṛśyasyāsaṃbhavādādau vaktā draṣṭā pradṛśyatām
]

`v 7 [
tasmāddraṣṭāsti no dṛśyaṃ naivāstīdamanāmayam |
citprabhaivātmanā bhittirbhavatyābhāsanaṃ tathā
]

`v 8 [
draṣṭṭadṛśyātmikaikaiva svātmanaiva virājate |
svapnādiṣu yathehādya draṣṭṭadṛśyātmikā satī
]

`v 9 [
cidbhātyeva hi sargādau kacantī bhāti sargavat |
bhāsanīyaṃ ca bhānaṃ ca rūpaṃ yatra svayaṃprabhā
]

`v 10 [
ekaiva cittrayaṃ bhūtvā sargādau bhāti sargavat |
eṣa eva svabhāvo'syā yadevaṃ bhāti bhāsurā
]

`v 11 [
etattu svapnasaṃkalpanagareṣvanubhūyate |
itthaṃ nāma tapatyeṣā ciddīptiḥ prathamoditā
]

`v 12 [
nabhasyeva nabhorūpā yadidaṃ bhāsate jagat |
anādyantamidaṃ tasyāḥ sargāḥ sargātmabhāsanam
]

`v 13 [
svabhāvabhūtamasmākaṃ tvidaṃ bhāti mahātmanām |
bhāsyabhāsakasaṃvittirnaśyati pratibhāmitā
]

`v 14 [
tadā tu nāma sargādau nāsīdbhāsyo na bhāsakaḥ |
mithyājñānavaśādeva sthāṇau puṃspratyayo yathā
]

`v 15 [
tathātmani dvitābhānāccitte dvaitavibhāsanam |
sargādau na ca bhāsyosti na ca vā nāsti bhāsakaḥ
]

`v 16 [
kāraṇābhāvatodvaitaṃ cidvyomābhāti kevalam |
kiṃ nāma kāraṇaṃ brūhi sargādau citi vastutaḥ
]

`v 17 [
sargādau jagadbhānasya jāgradādyavasthātrayānantarbhāvādapi turyacidevetthaṃ
prakāśata ityāha - abhāvāditi
]

`v 18 [
na svapno'saṃbhavāddṛśyaṃ kevalaṃ brahma bhāsate |
cinmātravyomasargādāvitthaṃ kacakacāyate
]

`v 19 [
yatsvameva vapurvetti jagadityajaganmayam |
cinmātravyomasargādāvitthaṃ bhāti vikāsanam
]

`v 20 [
yadidaṃ jagadityeva śūnyatvāmbarayoriva
]

`v 21 [
buddhvā ca yāvatsvanubhūtiyuktaṃ sthātavyametena vikalpamuktam |
pāṣāṇamaunaṃ kujanena tūktaṃ na grāhyamajñena hi bhuktamuktam
]

`v 117 [
abhāvādarthadṛṣṭīnāṃ cidevetthaṃ prakāśate |
jagadbhānamidaṃ yattanna jāgranna suṣuptakam
]