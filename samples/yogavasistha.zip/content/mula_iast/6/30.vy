`v 1 [
pdf 186, p. 1126
triṃśaḥ sargaḥ 30
śrīvasiṣṭha uvāca |
ahaṃtaiva parā'vidyā nirvāṇapadarodhinī |
tayaivānviṣyate mūḍhaistadityunmattaceṣṭitam
]

`v 2 [
ahaṃtaivālamajñānādajñatvasya nidarśanam |
na hi tajjñasya śāntasya mamāhamiti vidyate
]

`v 3 [
ahaṃtāmalamutsṛjya nirvāṇaḥ khamivāmalaḥ |
sadehamapadehaṃ vā jñastiṣṭhati gatajvaraḥ
]

`v 4 [
na tathā śaradākāśaṃ na tathā stimito'rṇavaḥ |
pūrṇendumadhyaṃ na tathā yathā jñaḥ parirājate
]

`v 5 [
citrasaṃgarayuddhasya sainyasyākṣubdhatā yathā |
tathaiva samatā jñasya vyavahāravatopi ca
]

`v 6 [
nirvāṇaikatayā jñasya vāsanaiva na vāsanā |
lekhādāmopamā tvabdherūrmyādi na jaletarat
]

`v 7 [
tarattaraṅgo jaladhirjalameva yathākhilam |
dṛśyocchūnamapi brahma tathā brahmaiva netarat
]

`v 8 [
antarastaṃgato'kṣubdho bahirastaṃgataḥ śamī |
vidyate codito yasya sa mukta iti kathyate
]

`v 9 [
ahaṭvasargarūpeṇa saṃvitsaṃvinmaye pare |
sphuratyambhombhasīvatto nānāteyaṃn kimātmikā
]

`v 10 [
dhūmasya sphurato vyomni yathā gajarathādayaḥ |
vyūhā dhūmānna te bhinnāstathā sargāḥ pare pade
]

`v 11 [
saṃvidbhrāntivicāreṇa bhrāntyalābhavilāsinaḥ |
vijayadhvaṃ viṣādaṃ mā''gatā jñāstajjñatā hi vaḥ
]

`v 12 [
aṅkuro'nubhavatyantarvṛkṣapatraphalaṃ yathā |
tathā jagadahaṃtve jñaḥ svātmā svātmakhamapyalam
]

`v 13 [
rūpālokamanaḥsattā jvālārciṣviva daṇḍatā |
satyopi ca na santyetā bhrānteścittābalā iva
]

`v 14 [
yathā sukhaṃ yathārambhaṃ yathā nāśaṃ yathodayam |
yathā deśaṃ yathā kālamajarāḥ śāntamāsyatām
]

`v 15 [
ato he śrotāraḥ sarva jagat yathā udeti sthitaṃ ca yathā svakāryamārabhate yathā ca
sukhaduḥkhe'nubhāvayati yathā ca naśyati yathā ca tadīyau deśakālau tathā tathā
utpattisthityupaśamaprakaraṇoktayuktibhirvimṛśya mithyeti niścitya śāntamāsyatām |
14 |
iṣṭāniṣṭopalambheṣu śānto vyavaharannapi |
śavavannānyatāmantarnirvāṇo'nubhavatyalam
]

`v 16 [
amanovāsanāhaṃtā dhatte yacca jagacciram |
jīvato'jīvataścaiva cijjīvaḥ sa paraṃ padam
]

`v 17 [
sattaiva jaḍavāhena duḥkhabhārāya kevalam |
nṛṇāṃ pāśāvabaddhānāṃ potakānāmivārṇave
]

`v 18 [
mokṣasattā śrayati taṃ nājñānānubhavādiva |
mṛtena yatkila prāpyaṃ jīvanprāpnoti tatkatham
]

`v 19 [
yadyatsaṃkalpyate tattatsaṃkalpādeva nāśabhāk |
na saṃbhavati yatraitattatsatyaṃ padamakṣayam
]

`v 20 [
nānyo na cāhamasmīti bhāvanānnirbhayo bhava |
satyaṃ yuktaṃ bhavatyetadviṣamapyamṛtaṃ yathā
]

`v 21 [
jaḍaṃ dehādi cittāntaṃ vicārya sakalaṃ vapuḥ |
labhyate nāhamasmīti tasmānnāsmīti satyatā
]

`v 22 [
śāntāśeṣaviśeṣāṇāmahaṃtāntāvicāraṇāt `note[ahaṃtāyā anto yasyāṃn
tathāvidhā muktatetyarthaḥ |] |
kevalaṃ muktatodeti na tu kiṃcidvinaśyati
]

`v 23 [
bhogatyāgavicārātmapauruṣānnānyadatra hi |
upayujyata ityajñāḥ svātmaivāśu praṇamyatām
]

`v 24 [
nirvāsanaṃ mananamevamudāharanti mokṣaṃ vinā bhavati tanna ca jātu bodhāt |
sanno jagadbhrama itīha paraḥ prabodho na pratyayo'tra yadataḥ sucirāya bandhaḥ |
24 |
evamahaṃtāvadhikasarvadvaitopaśamena nirvāsanaṃ sarvavāsanākṣayopalakṣitaṃ
yanmananaṃ manaso brahmabhāvenāvasthānaṃ tadeva mokṣaṃ śrutayo
vidvāṃsaścodāharanti | tacca bodhāttattvajñānādvinā jātu kadācidapi na bhavati | sa ca
paraḥ prabodho jagadbhramaḥ san paramārtho no na bhavatyeva iha mokṣaśāstre prasiddhaḥ
| yadyasmātkāraṇādara īdṛśe bodhe neha nānāsti kiṃcana ityādiśrutyā jāyamāno'pi
rāgādipuruṣadoṣaprābalyājjagatsatyatābhramadārḍhyācca pratyayo viśvāso nāsti | ato
hetoḥ sucirāya jīvasya saṃsārabandho'nuvartat ityarthaḥ
]

`v 25 [
jagadahamasadityupetya samyagjanadhanadāraśarīranirvyapekṣaḥ |
bhavati hi sa ca cetanasvarūpaḥ parimitakhaṃ khalu nānyathāsti muktiḥ
]