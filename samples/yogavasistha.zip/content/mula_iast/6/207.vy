`v 1 [
saptādhikadviśatatamaḥ sargaḥ 207
śrīvasiṣṭha uvāca |
śṛṇu rājanyathā spaṣṭametatte kathayāmyaham |
yena te sarvasaṃdehā yāsyantyalamamūlatām
]

`v 2 [
sarve tāvajjagadbhāvā asadrūpāḥ sadaiva hi |
sadrūpāśca sadaiveme yathāsaṃvedanaṃ sthiteḥ
]

`v 3 [
idamitthamiti protā yatra saṃvittadeva tat |
bhavatyavaśyaṃ tattvaṅga sadevāstvasadeva vā
]

`v 4 [
īdṛksvabhāvā saṃvittistayā deho vibhāvyate |
eka eva svarūpeṇa tasyāste na ca tadvidā
]

`v 5 [
vidameva vidurdehaṃ svapnādāvitaretarā |
saṃvitkācitsaṃbhavati na cānyāsti śarīratā
]

`v 6 [
āśritasvapnasaṃdarśastathedaṃ bhāsate jagat |
samastakāraṇābhāvātsargādāvanyatātra kā
]

`v 7 [
evaṃ yadeva vimalaṃ vedanaṃ brahmasaṃjñitam |
tadevedaṃ jagadbhāti tatkeva jagato'nyatā
]

`v 8 [
evaṃ pūrvāparaṃ śuddhamavikāryajagatsthiteḥ |
lokavedamahāśāstrairanubhūtamudāhṛtam
]

`v 9 [
apalāpyaiva ye mūḍhā andhakūpakamekavat |
samastabhūtasaṃvittau rūḍhapūrṇaṃ mahātmabhiḥ
]

`v 10 [
vartamānānubhavanamātramohapramāṇakāḥ |
śarīrakāraṇā saṃviditi mohamupāgatāḥ
]

`v 11 [
unmattā eva te'jñāste yogyā nāsmatkathāsu te |
akṣībakṣībayormūḍhabuddhayoḥ kaiva saṃkathā
]