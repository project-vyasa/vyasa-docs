`v 1 [
pañcanavatitamaḥ sargaḥ 95
śrīvasiṣṭha uvāca |
tataścidākāśavapurbhūtapañcakavarjitaḥ |
viharannahamākāśe piśāca iva saṃsthitaḥ
]

`v 2 [
na māṃ paśyanti candrārkaśakrā hariharādayaḥ |
na devasiddhagandharvakiṃnarā nāpsarogaṇāḥ
]

`v 3 [
nākrāmanti mayākrāntā na ca śṛṇvanti madvacaḥ |
ityahaṃ mohamāpanno vikrīta iva sajjanaḥ
]

`v 4 [
atha cintitavānasmi satyakāmā ime vayam |
paśyantu māṃ suragaṇāstena tasmin surālaye
]

`v 5 [
draṣṭuṃ pravṛttā māmagre vāstavyāḥ sarva eva te |
jhaṭityeva puraṃ prāptamindrajāladrumaṃ yathā
]

`v 6 [
atha gīrvāṇageheṣu saṃpanno vyavahāryaham |
yathāsthitasamācāraḥ sthito niḥśaṅkaceṣṭitaḥ
]

`v 7 [
yairavijñātavṛttāntairdṛṣṭo'hamajirotthitaḥ |
vasiṣṭhaḥ pārthiva iti lokeṣu prathito'smi taiḥ
]

`v 8 [
vyomanyādityaraśmibhyo dṛṣṭo'haṃ yairnabhogataiḥ |
vasiṣṭhastaijasa iti lokeṣu prathito'smi taiḥ
]

`v 9 [
vātātsamudito dṛṣṭo yairahaṃ gaganāspadaiḥ |
siddhairvātavasiṣṭhākhyastairahaṃ samudāhṛtaḥ
]

`v 10 [
yairahaṃ salilāddṛṣṭaḥ protthitastairmunīśvaraiḥ |
ukto vārivasiṣṭho'hamiti me janmasaṃtatiḥ
]

`v 11 [
tataḥprabhṛti loke'haṃ pārthivaḥ prathitaḥ kvacit |
ammayaḥ kvacidanyeṣāṃ taijaso mārutaḥ kvacit
]

`v 12 [
atha kālena me tatra tasminnevātivāhike |
ādhibhautikatā dehe rūḍhā rūḍhāntareritā
]

`v 13 [
yadetadātivāhitvamādhibhautikatā ca kham |
dvayamapyekadehātma tataḥ kacati me citiḥ
]

`v 14 [
evamātma kvacidvyoma kacanātmāpyahaṃ nabhaḥ |
parameva nirākāraṃ yuṣmāsvākāravānapi
]

`v 15 [
jīvanmukto vyavaharaṃstathāste brahmakhātmakaḥ |
tathaivādehamukto'pi tiṣṭhati brahmamātrakaḥ
]

`v 16 [
mama na brahmatāpetā tādṛgvyavahṛterapi |
asaṃbhavādanyadṛśo yuṣmadādiṣvahaṃ tvaham
]

`v 17 [
yathā'jñasya svapnanare nirjanmani nirākṛtau |
ādhibhautikatābuddhistathā me jagatopi ca
]

`v 18 [
evamevāvabhāsante sarva eva svayaṃbhuvaḥ |
sargāśca na tu jāyante prayātā iva coditāḥ
]

`v 19 [
eṣa sohamihākāśavasiṣṭhaḥ puṣṭatāmiva |
gato'dya svātmanābhyāsādbhavatāṃ vā bhavatsthitiḥ
]

`v 20 [
ākāśātmāna evaite sarva eva svayaṃbhuvaḥ |
yathā tvetanmanomātramime sargāstathaiva hi
]

`v 21 [
ahamādirayaṃ sargastvaparijñānadoṣataḥ |
vetāla iva bālānāṃ gato vo vajrasāratām
]

`v 22 [
parijñātastu kālena svalpenaivopaśāmyati |
vāsanātānavātsneho bandhau dūragate yathā
]

`v 23 [
ghanatvamahamāsādya tathā sargasya śāmyati |
parijñātā yathā svapnanidherādeyabhāvanā
]

`v 24 [
ahaṃkārarūpaṃ ghanatvaṃ sthaulyaṃ tathā śāmyati | ādeyabhāvanā upādeyatāvāsanā |
23 |
śāmyanti saṃparijñātāḥ sakalā dṛśyadṛṣṭayaḥ |
yathā marunadīvegavārigrahaṇabuddhayaḥ
]

`v 25 [
mahārāmāyaṇaprāyaśāstraprekṣaṇamātrataḥ |
etadāsādyate nityaṃ kimetāvati duṣkaram
]

`v 26 [
saṃsāravāsanābhāvarūpe saktā nu yasya dhīḥ |
mando mokṣe nirākāṅkṣī sa śvā kīṭo'thavā janaḥ
]

`v 27 [
bhogābhogaḥ kilāyaṃ yaḥ sa jīvanmuktabuddhinā |
kīdṛśo bhujyamānaḥ syātkīdṛksyānmaurkhyasevinā
]

`v 28 [
mahārāmāyaṇaprāyaśāstraprekṣaṇamātrataḥ |
antaḥśītalatodeti parārtheṣu himopamā
]

`v 29 [
mokṣaḥ śītalacittatvaṃ bandhaḥ saṃtaptacittatā |
etasminnapi nārthitvamaho lokasya mūḍhatā
]

`v 30 [
ayaṃ prakṛtyā viṣayairvaśīkṛtaḥ parasparaṃ strīdhanalolupo janaḥ |
yathārthasaṃdarśanataḥ sukhī bhavenmumukṣuśāstrārthavicāraṇāditaḥ
]