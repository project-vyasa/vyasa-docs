`v 1 [
ekasaptatitamaḥ sargaḥ
śrīvasiṣṭha uvāca |
ityuktvā bhagavānbrahmā brahmalokajanaiḥ saha |
baddhapadmāsano'nantasamādhānagato'bhavat
]

`v 2 [
oṃkārārdho'rdhamātrāntaḥ śāntaniḥśeṣamānasaḥ |
lipikarmārpitākāra āsīdāśāntavedanaḥ `note[āśāntavāsanaḥ iti pāṭhaḥ suvacaḥ |
]
]

`v 3 [
tamevānusarantī sā tathaiva dhyānagā satī |
vāsanāsīdaśeṣāṃśā śāntā cākāśarūpiṇī
]

`v 4 [
parameṣṭhinyasaṃkalpe tasmiṃstānavameyuṣi |
sarvagānantacidvyomarūpo'paśyamahaṃ yadā
]

`v 5 [
yāvatsaṃkalpanaṃ tasya virasībhavati kṣaṇāt |
tathaivāśu tathaivorvyāḥ sādridvīpapayonidheḥ
]

`v 6 [
tṛṇagulmalatāśālisamudbhavanaśaktatā |
samastaivāstamāgantumārabdhā ca śanaiḥ śanaiḥ
]

`v 7 [
kila tasya virāḍātmarūpasyāṅgaikadeśatām |
sā bibharti mahī tena tadasaṃvedanodayāt
]

`v 8 [
vicetanā sā virasā babhūva parijarjarā |
mārgaśīrṣāntavallīva jarāvidhuratāṃ gatā
]

`v 9 [
yathāsmākamasaṃvitteraṅgālī virasā bhavet |
tathā viriṃcisaṃvitterdharā vaidhuryamāgatā
]

`v 10 [
saṃpannā saṃhatānekamahotpātabharāvṛtā |
duṣkṛtāṅgāranirdagdhanarakonmukhamānavā
]

`v 11 [
durbhikṣākāṇḍadausthityadainyadāridryadurbhagā |
duḥśīlāśeṣavanitā nirmaryādanarāvṛtā
]

`v 12 [
pāṃsupramandanīhāradhūlidhūsarasūryakā |
dvandvimūrkhamahāduḥkhivyasanivyādhitākulā
]

`v 13 [
agnidāhajalāpūrayuddhaprocchinnamaṇḍalā |
avṛṣṭyavagrahonnaṣṭakaṣṭaceṣṭitapāmarā
]

`v 14 [
aśaṅkitamahotpātapatatparvatapattanā |
śiśuśrotriyamunyāryaguṇināśarudajjanā
]

`v 15 [
aśaṅkitasthalīmadhyasaṃjātāgādhakūpakā |
varṇasaṃkaranārīṇāmāsaktajanabhūmipā
]

`v 16 [
jaladaurlabhyādaśaṅkitaṃ sthalīmadhye yatra kvacana jalāśayākhananāt sarvataḥ
saṃjātā agādhakūpakā yasyām | varṇasaṃkarāya nārīṇāṃ madhye
gotrasāpiṇḍyāgamyādivicāraṃ vinaiva vivāhādyāsaktā janā bhūmipāśca yasyām | 15
|
aṭṭaśūlākhilajanā śivaśūlacatuṣpathā |
keśaikaśūlavanitā pātraśūlajaneśvarā
]

`v 17 [
duḥkhaśūlasamācārā dvandvaśūlākhilaprajā |
adharmaśūlavanitā pānaśūlajaneśvarā
]

`v 18 [
adharmaśūlavalitā kuśāstraśataśūlinī |
durjanākhilavittāḍhyā vipadvihatasajjanā
]

`v 19 [
anāryavasudhāpālā tadanādṛtapaṇḍitā |
lobhamohabhayadveṣarāgarogarajoratā
]

`v 20 [
apyanyagāmipuruṣā ruṣābhihatasadvijā |
anārataparākrandaparāparyantapāmarā
]

`v 21 [
dasyūtsannapuragrāmadevadvijasamāśrayā |
āpātamadhurārambhaduḥkhadodarabhaṅgurā
]

`v 22 [
ālasyollāsavilasatkāryavaidhuryadharmiṇī |
sarvāpadupatāpāntā krameṇotsannadiggaṇā
]

`v 23 [
bhasmaśeṣapuragrāmā nirjanākhilamaṇḍalā |
rorūyamāṇabhasmābhrakuṇḍaloḍ.āmarāmbarā
]

`v 24 [
durbhagāḍambarārambharodanoruravodarī |
muṣṭipramāṇajanatā janatāpānuṣaṅgiṇī
]

`v 25 [
nīrasāśeṣadeśāntā sarvartuguṇavarjitā |
ityasya pārthive dhātau brahmaṇo gatavedane
]

`v 26 [
pṛthivī pṛthuvaidhuryā saṃpannāsannanāśataḥ |
atha tatsaṃvidunmukto jaladhātuḥ kṣayonmukhaḥ
]

`v 27 [
yadā vikṣubhitātmāsīttadā niyatilaṅghanāt |
samutsāryāryamaryādāmarṇavā vivṛtārṇasaḥ
]

`v 28 [
pravṛttā vikṛtiṃ gantumunmattā iva rāviṇaḥ |
vīcivikṣobhavinyāsairvelāvipinalāvakāḥ
]

`v 29 [
kallolavalanāvartavivartodvartitāśrayāḥ |
mahābhrabhramaduttuṅgataraṅgāttanabhodiśaḥ
]

`v 30 [
bṛhadgulugulāvartagarjanoddravakandarāḥ |
sīkaraughamahārambhaghanasaṃvalitācalāḥ
]

`v 31 [
calaccalacaladvīramakarāghūrṇitāntarāḥ |
ullasanmakarākrāntadrumakānanitodarāḥ
]

`v 32 [
darīvidāraṇabhraṣṭasiṃhāhatajalecarāḥ |
ūrmyudastamahāratnabharatārakitāmbarāḥ
]

`v 33 [
utphālamakaracchannanabhaścarabṛhadghanāḥ |
parasparormisaṃghaṭṭabhāṃkārakaṭuṭāṃkṛtāḥ
]

`v 34 [
tarattaralamātaṅgaphūtkārā dhautabhāskarāḥ |
anyonyavellanavyagrapravidīrṇādribhittayaḥ
]

`v 35 [
taṭaparvataluṇṭākataraṅgakaramaṇḍalāḥ |
garjadgiridarīgehaviśadunmattavārayaḥ
]

`v 36 [
bhūpāḥ parapurākrāntā lagnā iva hatārayaḥ |
tārāravaraṇadgehavidrāvitanabhaścarāḥ
]

`v 37 [
praluṇṭhitavanavyūhalūnakānanitāmbarāḥ |
sapakṣaparvatākārataraṅgāpūritāmbarāḥ
]

`v 38 [
praluṇṭhitairutkhāyonnītairvanavyūhairlūnakānanamiva kṛtamambaramākāśaṃ yaiḥ |
37 |
mahāravamarucchinnakallolācalacālitāḥ |
cañcattīragirivrātapatattaṭaraṭajjalāḥ
]

`v 39 [
ullasadvipulāvartaprokṣiptamakarotkarāḥ |
vimajjannistalāvartanigīrṇagirikandarāḥ
]

`v 40 [
darīdalanasaṃprāptadṛṣaddaśanadanturāḥ |
śṛṅgalambidarīprāntamagnavīcijalebhakāḥ
]

`v 41 [
vyālolavalanākrāntaviṭapiprotakacchapāḥ |
yamendravasudhāvāhairutkarṇairbhayavihvalaiḥ
]

`v 42 [
śrūyamāṇapatacchailataṭīkaṭakaṭāravāḥ |
matsyapucchacchaṭācchinnamagnonmagnadrutādrayaḥ
]

`v 43 [
līlālūnavanavyūhaśītalāsāravārayaḥ |
prajvaladvaḍavāvahnijvālāvalimilajjalāḥ
]

`v 44 [
sarasena vibhornāśairviśaṅkitamahānalāḥ |
milacchikharimālāgrajalamātaṅgayodhinaḥ
]

`v 45 [
nṛtyantīva taraṅgaughairjalāvalanavedhinaḥ |
jalācalācalānyonyasaṃghaṭṭasphoṭapaṇḍitāḥ
]

`v 46 [
bṛhadgirivanavrātaprāṇimaṇḍalamaṇḍitāḥ |
uḍḍāmaravanebhendrabherīvādanabhāsuraiḥ
]

`v 47 [
asurairiva pātālaṃ kallolairalamākulāḥ |
athodapatadunnāsadiṅnāgavadanadhvaniḥ
]

`v 48 [
pātālatalatālvantarvisphoṭāmoṭanodbhaṭaḥ |
cañcalācalakīlorvī cacāla kṣaṇacālitā
]

`v 49 [
kīdṛśaḥ sa dhvaniḥ | pātālatalalakṣaṇasya tālunaḥ antarvisphoṭena vidāraṇena
āmoṭanena piṇḍīkaraṇena codbhaṭo ghanataraḥ | giggajaiścānuhyamānā urvī cañcalāni
mervādyacalakīlāni yasyāstathāvidhā bhūtvā kṣaṇādeva svasthānāccālitā satī
vyālolairambhodhibhirlaṅghitā ca satī lolā śaivālavallīva cacāleti pareṇa sahānvayaḥ |
48 |
lolā śaivālavallīva vyālolāmbhodhilaṅghitā |
atha durvāranirghoṣanirvātāḍambarānvitā
]

`v 50 [
pusphoṭeva patantī dyaurdiśāṃ patiravāravaiḥ |
āvartavalanākārāḥ ketavaḥ peturambarāt
]

`v 51 [
hemaratnamayā muktāḥ sindūrabhujagā iva |
kakubbhyo nabhaso bhūmerudagurdagdhadiktaṭāḥ
]

`v 52 [
calajjvālājaṭāṭopā vividhotpātapaṅktayaḥ |
pṛthvyādīnyasurādīni brahmonmuktāni sarvataḥ
]

`v 53 [
dvividhāni mahābhūtānyalaṃ saṃkṣobhamāyayuḥ |
candrārkānilaśakrāgniyamāḥ kolāhalākulāḥ
]

`v 54 [
paripātaparā āsanbrahmalokagateśvarāḥ |
kampaiḥ kaṭakaṭārāvapatatpādapapaṅktayaḥ
]

`v 55 [
bhūmeranvabhavanbhūridolāndolanamadrayaḥ |
bhūkampalolakailāsamerumandarakandarāḥ |
petuḥ kalpatarūnmuktā raktastabakavṛṣṭayaḥ
]

`v 56 [
lokāntarādripuravāridhikāanāntamutpātakalpapavanena mitho hatānām |
kolāhalairjagadabhūtpravikīrṇaśīrṇaṃ pūrṇārṇave tripurapūra ivābhipātī
]