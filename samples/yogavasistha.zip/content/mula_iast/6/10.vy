`v 1 [
daśamaḥ sargaḥ 10
bhuśuṇḍa uvāca |
viddhi tvaṃ cetanādeva cetanetaracetanam |
jale'gniriva cijjāḍye nāto bhinne manāgapi
]

`v 2 [
tadvedanāvedanayorabhedātsvasthamāsyatām |
niryantrameva citrasthajñaptivadvyomamadhyavat
]

`v 3 [
brahmaṇyaśeṣaśaktitvādacittvaṃ vidyate tathā |
akṣubdhe vimale toye bhāviphenalavo yathā
]

`v 4 [
na kāraṇaṃ vinodeti jalātphenalavo yathā |
na kāraṇaṃ vinodeti sargādi brahmaṇastathā
]

`v 5 [
na ca kāraṇamastyatra sargavṛttāvakāraṇe |
nātaḥ saṃjāyate kiṃcijjagadādirna naśyati
]

`v 7 [
atyantaṃ kāraṇābhāvānna kiṃcijjāyate jagat |
marāvambviva nāstyeva dṛṣṭamapyagrato `note[dṛśyaṃ iti pāṭhaḥ |] jagat |
6 |
brahmānantamajaṃ śāntamato'stīdaṃ na sargadhīḥ |
kāraṇābhāvatastena brahmaivedamakhaṇḍitam
]

`v 8 [
ataḥ śilodarābho'si vyomakośopamopi ca |
brahmaikaghanarūpatvādajo'navayavo'si ca
]

`v 9 [
jño'si kiṃcinna kiṃcidvā niḥśaṅkamalamāsyatām |
acetanācidābhāse śāmyatāmātmanātmani
]

`v 10 [
nityānandatayā'jasya kāraṇaṃ nāsti kāryakṛt |
sargādyasaṃbhave tasmādyadasti tadajaṃ śivam
]

`v 11 [
ajo yeṣāṃ tu cidrūpo nāsti maurkhyavilāsinām |
sarganāśe samutpanne kiṃ teṣāṃ pravicāryate
]

`v 12 [
yatra yatra paraṃ brahma tatra santi jaganti hi |
jagacchabdārtharūpeṇa muktānyevaṃvidhāni ca
]

`v 13 [
tṛṇe kāṣṭhe jale kuḍye sarvatraiva paraṃ sthitam |
sarvatraiva ca sargaughaḥ pariprotaḥ sthito `note[sthira iti pāṭhaḥ |] mithaḥ
]

`v 14 [
brahmaṇaḥ kaḥ svabhāvo'sāviti vaktuṃ na yujyate |
anante parame tattve svatvāsvatvātyasaṃbhavāt
]

`v 15 [
abhāvasavyapekṣasya bhāvasyāsaṃbhavādapi |
padaṃ badhnanti nānante svabhāvādyā duruktayaḥ
]

`v 16 [
asvatvābhāvayornitye'nante'tyantamasaṃbhavāt |
svatvabhāveṣu siddheṣu svabhāvoktirna tiṣṭhati
]

`v 17 [
nāhantvaṃ labhyate sādho buddhyāloke nirīkṣitam |
asadeva kuto'pyetadbālayakṣa ivoditam
]

`v 18 [
muktaṃ tvahantvaśabdārthairlabhyate yacca tatparam |
yuktaṃ tvahantvaśabdārthaiḥ prekṣyamāṇaṃ vilīyate
]

`v 19 [
bhedo jagadbrahmadṛśorabhedaḥ paryāyaśabdārthavilāsatulyaḥ |
saṃkalpamātraṃ kathito na satyo yathānayorvai kaṭakatvahemnoḥ
]