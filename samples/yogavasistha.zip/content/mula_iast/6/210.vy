`v 1 [
daśādhikadviśatatamaḥ sargaḥ 210
śrīvasiṣṭha uvāca |
phale kṣayendubhārūpe prāpte dhyātṛśatairnabhaḥ |
yathā na śatapūrṇendu tathedaṃ kathanaṃ śṛṇu
]

`v 2 [
candrabimbasya dhyātāraḥ prāptāḥ prāptavyasusthitāḥ |
nedaṃ nabhastalaṃ prāptā na cemaṃ śaśinaṃ śritāḥ
]

`v 3 [
satyacandrabimbasyāhaṃbhāvena dhyātāraḥ prāptavye candrabhāve
ciradhyānenānyabhāvavismaraṇādaindavanyāyena susthitāḥ santaścandrabhāvaṃ prāptā
eva tathāpi nedaṃ nabhastalaṃ prāptā nāpyenaṃ śaśinaṃ śritāḥ | praviṣṭā ityarthaḥ |
2 |
kvevānyasaṃkalpapuramanyaḥ prāpnoti kathyatām |
saṃkalpapuryāmarthāptistajjantāveva nāpare
]

`v 4 [
pṛthakpṛthaksvasaṃkalpasargekheṣveva te sthitāḥ |
candrāstapanti tatraiva kalākṣayavivarjitāḥ
]

`v 5 [
viśeyamasminnevendāviti dhyātvā niśākare |
asminneva viśatyantarātmabuddhisukhojjhitaḥ
]

`v 6 [
ahaminduṃ praviṣṭaḥ syāmindubimbasukhānvitaḥ |
dhyāteti tādṛksukhabhāgbhavatīti viniścayaḥ
]

`v 7 [
yathāyamanusaṃdhatte svabhāvaṃ saṃvidavyayā |
taṃ tathaivānubhavati bhavecceddṛḍhaniścayaḥ
]

`v 8 [
yathendutvaṃ svasaṃkalpātsarvadhyātuḥ pṛthakpṛthak |
bhātyevameva vanitālābhaḥ kālpanikaḥ svataḥ
]

`v 9 [
yā dhyāne dhyātṛlakṣāṇāṃ sādhvī bhāryātvamāgatā |
tatkalpanānubhavanaṃ teṣāṃ sattvātmani sthitam
]

`v 10 [
gṛhādanirgato jīvaḥ saptadvīpaparaḥ sthitaḥ |
tasyāpi tatkālpanikaṃ rājyaṃ vyomni svamandire
]

`v 11 [
gṛhānirgacchamākalpaṃ nṛpaḥ sa dvīpasaptake iti praśno'pyanena samāhita ityāha ##-
samastaṃ kalpanāmātramidamādyajñajanmanaḥ |
śūnyamapratighaṃ śāntaṃ teṣvapi syātkimanyathā
]

`v 12 [
dānaurdhvadehikatapojapādīnāṃ paratra yat |
amūrtānāṃ phalaṃ mūrtaṃ tadidaṃ kathyate śṛṇu
]

`v 13 [
dānadharmāditapasāmaurdhvadehikakarmaṇām | ihasthānāmamūrtānāṃ mūrtaṃ
pretyāsti kiṃ phalam iti praśnamanūdya tatsamādhānaṃ vaktuṃ pratijānīte - dāneti |
12 |
dānādicihnitadhiyaḥ paratra svapnavatphalam |
paśyantyamūrtāmūrtābhamajaṃ cinmūrtikalpanāt
]

`v 14 [
vedanāvedanākārā spandāspandātma vai punaḥ |
cinmātrasyāsya tadbhrāntiśāntau śāntātma nirmalam
]

`v 15 [
cinmātrābhamito dānādamutrāttamavāpnuyāt |
saṃkalpātmeti kavayaḥ kathaṃ tannopalabhyate
]

`v 16 [
ita ihānuṣṭhitāddānādamutra paraloke cinmātrābhaṃ citpratibhāsātmakaṃ
tattatphalamāttamupanītaṃ tatsaṃkalpātmā jīvaḥ avāpnuyāditi kavayo vadantīti śeṣaḥ |
15 |
kalpanātmani saṃsāre saṃkalpo'kṛtrimaṃ phalam |
cinmātramabhito'dānāddānādvā'stu yathoditaḥ
]

`v 17 [
etatte kathitaṃ sarvaṃ yathāpṛṣṭaṃ mahīpate |
jagadapratighaṃ sarvamidaṃ cinmātrakalpanam
]

`v 18 [
rājovāca |
sargādau bhagavandehamidaṃ cinmātrakalpanam |
kathaṃ bhāti kathaṃ kuḍyaṃ vinā dīpaḥ prakāśate
]

`v 19 [
śrīvasiṣṭha uvāca |
tvayārtho dehaśabdasya yo buddhaḥ sa mahāmate |
tattvajñaṃ prati nāstyeva śilānṛttamivāmbare
]

`v 20 [
ya eva brahmaśabdārtho dehaśabdārtha eva saḥ |
nārthayoranayorbhedo vidyate'mbvambhasoriva
]

`v 21 [
yadeva brahmadeho'sau svapnābhaḥ svapna eṣa tu |
tvadbodhāyocyate yuktirna tu tatsvapna eva tu
]

`v 22 [
svapnastavānubhūtārthastenātastvaṃ prabodhyase |
na tu sarge cidābhāte sādṛśyaṃ svapnabhasmanā
]

`v 23 [
kastatra nāma deho'yaṃ kasyaite svapnadhīḥ kva vā |
svapnena jñāvabuddhena bhrameṇājño'vabodhyate
]

`v 24 [
tatra jāgranna ca svapno na suṣuptaṃ na cetarat |
kimapītthamidaṃ bhānaṃ khamātraṃ maunamomalam
]

`v 25 [
abhātameva bhātīva yadadyetthamidaṃ tu tat |
prāgvibhātaṃ tathātyacchaṃ jāgratsvapnādi no yathā
]

`v 26 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
tanmayaṃ sarvamevedaṃ dvaitamadvaitameva ca
]

`v 27 [
anyatra cinmayaṃ svapnaṃ dvaitādvaitaṃ śubhāśubham |
nirāvaraṇacinmātranabhasaivopamīyate
]

`v 28 [
śūnyamarthopalambhaśca bhānaṃ cābhānameva |
dvaitamaikyamasatsacca sarvaṃ cidgaganaṃ param
]

`v 29 [
pūrṇātpūrṇaṃ prasarati pūrṇameva sthitaṃ jagat |
na ca bhātaṃ na cābhātaṃ śilābaddhodaropamam
]

`v 30 [
yato jagaccidunmeṣo vyomātmāpratighaṃ tataḥ |
cinmātraṃ yatra yatrāsti tatra tatrocitaṃ jagat
]

`v 31 [
cidvyoma cāsti sarvatra sarvaṃ caitajjaganmayam |
sarvaṃ brahmamayaṃ śāntaṃ jagadityapi śabditam
]

`v 32 [
yathāsthitamidaṃ viśvaṃ tathāsaṃsthamanāmayam |
brahmaiva viravadyātma citsaṃkalpapurākṛti
]

`v 33 [
asaṃbhavādanyayukteryuktireṣaiva śobhanā |
ayuktyanubhavaṃ tūktaṃ nārthināmiha śobhate
]

`v 34 [
loke śāstre'tha vedādau yatsiddhaṃ siddhameva tat |
sadastvasadvātmani taddhātuṃ śakyaṃ na vā kvacit
]

`v 35 [
tadevetthaṃ parijñātaṃ brahmatāmupagacchati |
yadā tena samaṃ viśvaṃ sthitameva vilīyate
]

`v 36 [
nyāyenaitadihoktena lokavedādi sidhyati |
sarvaṃ sa jīvanmuktatvameṣa evocitastataḥ
]

`v 37 [
parijñātaṃ cidākāśamaparijñātapādape |
so'haṃ trijagadityeva bandhamokṣavinirṇayaḥ
]

`v 38 [
yathāsthitamidaṃ dṛśyaṃ parijñānādvilīyate |
tajjñasyāstaṃgatasyaiva śilāmaunaṃ tu śiṣyate
]

`v 39 [
loke śāstre ca vede ca yatsiddhaṃ siddhameva tat |
saṃvedyate tadevātastadevaṃ phalati sphuṭam
]

`v 40 [
sakalārthanirāsena yadyatsaṃvedyate ciram |
tadeva prāpyate'vaśyaṃ sarvatraivānyabhāvitam
]

`v 41 [
yathānubhūtaṃ yattattattathā nāmānubhūyate |
tatsatyamastvasatyaṃ vā yāvallābhaṃ tathā nu tat
]

`v 42 [
itthaṃ mahāpraśnavicāraṇaṃ te mayedamuktaṃ matimanmahātman |
anena gacchāśu pathā nirādhirnirāmayo nirvyasano bhavoccaiḥ
]