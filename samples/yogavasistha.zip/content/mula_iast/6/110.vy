`v 1 [
daśādhikaśatatamaḥ sargaḥ 110
śrīvasiṣṭha uvāca |
puropakaṇṭhasaṃprāptaiścaturdikkaṃ sahāribhiḥ |
etasminnantare tatra pravṛttaṃ dāruṇaṃn raṇam
]

`v 2 [
luṇṭhitagrāmanagaraṃ prajākulamahākulam |
agnidāhajvaladdehaṃ dhūmābhrapaṭalāvṛtam
]

`v 3 [
śarajālamahādhūmacchannārkavilasattamaḥ |
kṣipradṛṣṭaravi kṣipramadṛṣṭaravimaṇḍalam
]

`v 4 [
agnidāhamahātāpapratapatparṇakānanam |
lolālātalatāśūlamusalopalapūrṇakham
]

`v 5 [
pratapatparṇāni śuṣyatpatrāṇi kānanāni yatra | lolairalātalatādibhiḥ pūrṇaṃ khaṃ yatra |
4 |
analapratibimbaughaurdviguṇajvalanāyudham |
raṇabhagnamahāśūraprāptendravanitāsudham
]

`v 6 [
uddāmavāraṇārāvai raṇalampaṭaharṣadam |
bhuśuṇḍīmaṇḍalaprāsaśūlatomaravarṣadam
]

`v 7 [
bhaṭakolāhalollāsahṛdbhaṅgamṛtapāmaram |
rajaḥpaṭalaśubhrābhrakṛtadyupathavāraṇam
]

`v 8 [
maraṇavyagrasāmantamuktanādavrajadvrajam |
itaścetaśca nipatadvaidyutopahataprajam
]

`v 9 [
agnidagdhapatadgehaprojjhitāgnimayāmbudam |
maraṇāhlādadāsaṃkhyaśaradhārāmayāmbudam
]

`v 10 [
jitasāgarakallolaṃ turaṅgamataraṅgakaiḥ |
dantidantaviniṣpeṣatārakreṃkārakarkaśam
]

`v 11 [
koṭakoṭikuṭīkuḍyakaṇṭakodbhaṭasadbhaṭam |
caṭatkuṇṭhitakoṭāṭṭakūṭāṭananaṭacchaṭam
]

`v 12 [
luṭhatpaṭanakuṭṭākasāṭopasphuṭapaṭṭiśam |
khe vaṭatketupaṭṭāṭṭapaṭatpaṭapaṭāravam
]

`v 13 [
dantidantaguṇodgīrṇairhetipāṣāṇagharṣaṇaiḥ |
tārakreṃkārahuṃkārairāhūtasuravāraṇam
]

`v 14 [
vahaccharanadīpūrapūrṇāmbaramahārṇavam |
vicalaccakrakuntāsidhārāmakarakarkaśam
]

`v 15 [
unnādayodhasaṃghaṭṭakaṃkaṭotkaṭaṭāṃkṛtaiḥ |
lasajjhaṇajhaṇārāvairghaṭitadvīpamaṇḍalam
]

`v 16 [
pādapātaparāpiṣṭaśarasaṃjātakardamam |
vahadraktanadīraṃhaḥprohyamāṇarathadvipam
]

`v 17 [
suparṇahelānipatatprotpatatpaṭṭapaṭṭiśam |
śaravāritaraṅgārtabhagnāyudhajalecaram
]

`v 18 [
hetisaṃghaṭṭaniṣkrāntajvālāprajvalitāmbaram |
valīpalitanirmuktaśūrākrāntatriviṣṭapam
]

`v 19 [
pāṇḍupāṃsupayovāhakacaccakrāciradyuti |
hetinirvivarākāśayudhānādhārabhūtalam
]

`v 20 [
pāṇḍuṣu pāṃsulakṣaṇeṣu payovāheṣu kacaccakralakṣaṇā aciradyutayo vidyuto yatra |
hetibhirnirvivaraṃ niravakāśaṃ yudhānāṃ saṃprahārāṇāmanādhāraṃ bhūtalaṃ yatra |
19 |
kaṭadbhaṭabhaṭāṭoparaṭatpratibhaṭotkaṭam |
caṭacchakaṭasaṃghaṭṭapiṣṭakāṣṭhaluṭhadratham
]

`v 21 [
kabandhabhaṭavetālamiśrakaṇṭakasaṃkaṭam |
vetālabhujyamānāgryaśavamāṃsahṛdambujam
]

`v 22 [
śūraśātitaśīrārdhaśiraḥkarakhurorukam |
kabandhadordrumaspandavanīkṛtanabhastalam
]

`v 23 [
śūraiḥśātitaṃ śīrārdha śirārdham | chāndaso dīrghaḥ | śirāṃsi karādikaṃ ca yatra |
22 |
tarallolāsyavetālahāsaghaṭṭitapeṭakam |
kaṃkaṭotkaṭasāṭopabhaṭabhrukuṭibhīṣaṇam
]

`v 24 [
ekāntamāraṇaikāntamaraṇaikāntabhūṣaṇam |
prahāradānagrahaṇakārpaṇyāpāradūṣaṇam
]

`v 25 [
śūravāraṇasāmantamadavāriviśoṣaṇam |
māraṇaikāntarasikakṛtāntānandapoṣaṇam
]

`v 26 [
avikatthanaguptānāṃ śūrāṇāṃ jayaghoṣaṇam |
aśūrāṇāṃ ca guptānāṃ prabhāvudghoṣaṇaṃn param
]

`v 27 [
śauryādīnāṃ prasuptānāṃ svaguṇānāṃ prabodhanam |
dhanamādhārabhūtānāṃ rāṣṭreṣu bhujaśālinām
]

`v 28 [
dantyārūḍharathāsphoṭaprabhagnakaṭavāraṇam |
samastamattagandhebhadānavārinivāraṇam
]

`v 29 [
dantyārūḍhānāṃ rathānāṃ ca parasparamāsphoṭe yuddhe prabhagnakaṭā vāraṇā yatra |
samastānāṃ mattagandhebhānāṃ dānavāriṇāṃ madajalānāṃ nivāraṇaṃ viśoṣaṇam |
28 |
sārasāravasāmantamuktamattamataṅgajam |
jarajjitakarānīkakalpitāsīkavedanam
]

`v 30 [
dinaṃ dinakarasyeva nṛpasya śaraṇaṃ gatam |
anāgatabhaṭavrātapiṣṭārdhamṛtamānavam
]

`v 31 [
mānavāyubalonmattanataprārabdhakuṭṭanam |
dhanānāṃ prāṇapaṇyānāṃ navamāpaṇapattanam
]

`v 32 [
paṭanaddhapatākaughajātasaṃcāridordrumam `note[paṭanaddhāḥ patākaughā eva
saṃcāriṇo dordrumā abhūvan |] |
raktojjvalatvāttrailokyalakṣmyā bhūṣaṇavidrumam
]

`v 33 [
mandarāhananodbhūtakṣīrodajalasundaraiḥ |
chatraiśchāditahetyoghapuṣpāḍhyagaganāṅganam
]

`v 34 [
gaṇagīrvāṇagandharvagītaśūrāśayaṃ kṛtam |
tadbhātaralatālāgrahetihālāhalāyudham
]

`v 35 [
saṃghapraharaṇāsaṃkhyayātudhānājhaṇajjhaṇam |
bhuktvā cādriguhāgehapūritāpūrvadurdrumam
]

`v 36 [
kacatkuntavanavyastaśiraḥkaravṛtāmbaram |
kṣepaṇonmuktapāṣāṇapūraplutakakublatam
]

`v 37 [
mahācaṭacaṭāśabdasphuṭadravabṛhaddrumam |
nārīhalahalārāvaraṇannagaramandiram
]

`v 38 [
mandarāvānalākāranabhobhātāyudhavrajam |
parityajya dhanaṃ gehaṃ dūrorvīvidrutaprajam
]

`v 39 [
sarvatohetivahanātsamakṣaprekṣakojjhitam |
varjitaṃ bhīrubhiḥ pakṣirājavṛndamivāhibhiḥ
]

`v 40 [
dantidantaviniṣpiṣṭaśiṣṭasadbhaṭasaṃkaṭam |
kaṭe mṛtyoriva naradrākṣāpīḍanayantrake
]

`v 41 [
yantrapāṣāṇasaṃghaṭṭapiṣṭāmbaragatāyudham |
yodhanādanadaddantivṛndabandhurakandaram
]

`v 42 [
dharādharadarīrantaḥpratiśrutprotagarjitam |
arjitaṃ prāṇasarvasvamarjayadbhirupārjitam
]

`v 43 [
bharjitaṃ hetidahanairagnidāhaiśca saṃtataiḥ |
tairevānyairathānyaiśca dvandvayuddhairaniṣṭhitam
]

`v 44 [
veṣṭitaṃ mṛtaśiṣṭaiśca sāraiḥ subhaṭapeṭakaiḥ |
kailāsairiva saṃśuddhairīśvarādhāratāṃ gataiḥ
]

`v 45 [
tairudāraiḥ samākrāntaṃ ye mṛtyorapi mṛtyavaḥ |
maraṇaṃ jīvitaṃ yeṣāṃ jīvitaṃ maraṇaṃ raṇe
]

`v 46 [
raṇe nabhasi nirlūnavaravāraṇavārije |
sārasāḥ sarasīvātra rejuratyudbhaṭā bhaṭāḥ
]

`v 47 [
yantrāśmakṣepaṇānāṃ prasaraṇasaritāṃ ghūkṛtaiḥ phūtkṛtairdrāk
krāntānāṃ vyomni mūrdhnāṃ śarasalilamucāṃ sainikānāṃ ca nādaiḥ |
ṭāṃkārairāyudhānāṃ nabhasi
visaratāmaśvacakrebhaśabdairāsīnniḥsaṃdhibandhopalajaṭharajaḍaṃ
jīrṇakarṇaṃ gataṃ tat
]