`v 1 [
aṣṭasaptatyadhikaśatatamaḥ sargaḥ 178
śrīrāma uvāca |
padārthā dvividhāḥ santi mūrtāmūrtā jagattraye |
yatra sapratighāḥ kecitkecidapratighā api
]

`v 2 [
tānihāpratighānāhurnānyonyaṃ vellayanti ye |
tāṃśca sapratighānāhuranyonyaṃ vellayanti ye
]

`v 3 [
iha sapratighānāṃ tu dṛṣṭamanyonyavellanam |
na tvapratigharūpāṇāṃ keṣāṃcidapi kiṃcana
]

`v 4 [
tatra saṃvedanaṃ nāma yadidaṃ candramaṇḍale |
itaḥ patatyapratighaṃ tatsarveṇānubhūyate
]

`v 5 [
ardhaprabuddhasaṃkalpavikalpādvaitakalpitam |
vadāmyabhyupagamyedaṃ na tu bodhadaśāsthitam
]

`v 6 [
kaḥ prāṇamārutaḥ kṣobhaṃ janayatyāśayasthitaḥ |
praveśanirgamamayaṃ kathaṃ vā vada me prabho
]

`v 7 [
kathamapratighaṃ nāma vedanaṃ pratighātmakam |
imaṃ dehaṃ cālayati bhāraṃ bhāraharo yathā
]

`v 8 [
yadi sapratighaṃ vastu vellatyaprtighātmakam |
kathaṃ saṃvittimātreṇa puṃsaḥ śailo na valgati
]

`v 9 [
śrīvasiṣṭha uvāca |
vikāsamatha saṃkocamatra nālī hṛdi sthitā |
yadā yāti tadā prāṇaśchedairāyāti yāti ca
]

`v 10 [
bāhyopaskarabhastrāyāṃ yathākāśāspadātmakaḥ |
vāyuryātyapi cāyāti tathātra spandanaṃ hṛdi
]

`v 11 [
śrīrāma uvāca |
bahirbhastrāmayaskāraḥ saṃkocanavikāsanaiḥ |
yojayatyāntaraṃ nāḍīṃ kaścālayati cālakaḥ
]

`v 12 [
śataṃ kathaṃ bhavedekaṃ kathamekaṃ śataṃ bhavet |
kathaṃ sa cetanā ete kāṣṭhaloṣṭopalādayaḥ
]

`v 13 [
kasmānna sthāvaraṃ vastu praspandyapi camatkṛtam |
vastu jaṅgamameveha spandi mātreva kiṃ vada
]

`v 14 [
śrīvasiṣṭha uvāca |
antaḥsaṃvedanaṃ nāma cālayatyāntraveṣṭanam |
bahirbhastrāmayaskāra iva loke'nuceṣṭanam
]

`v 15 [
śrīrāma uvāca |
vāyvantrādiśarīrasthaṃ sarvaṃ sapratighaṃ mune |
kathamapratighā saṃviccālayediti me vada
]

`v 16 [
saṃvidapratighākārā yadi sapratighātmakam |
cālayedacaliṣyattaddūramambho yadicchayā
]

`v 17 [
sapratighāpratighayormitho yadi padārthayoḥ |
vellanaṃ syāttadicchaiva kartṛkarmendriyaiḥ kva kim
]

`v 18 [
sapratighāpratighayoḥ śleṣo nāsti bahiryathā |
tathaivāntarahaṃ manye śeṣaṃ kathaya me mune
]

`v 19 [
antaḥ svayaṃ yoginā vā yathaitadanubhūyate |
amūrtasyaiva mūrtena vellanaṃ tadvadāśu me
]

`v 20 [
śrīvasiṣṭha uvāca |
sarvasaṃdehavṛkṣāṇāṃ mūlakāṣamidaṃ vacaḥ |
sarvaikatānubhūtyarthaṃ śṛṇu śravaṇabhūṣaṇam
]

`v 21 [
evamākṣipto vasiṣṭhaḥ prāguktagūḍhābhisaṃdhyuttaramapi vāsanānāṃ
bāhyādhyātmikaparicchedabhrāntimātramūlatvādanavasthāgrastaṃ niṣkarṣāsahaṃ
rāmeṇa jñātamudghāṭitamapi rāmaḥ khaṇḍayiṣyatyeveti manyamānastadupekṣya
siddhāntāvalambanenaivaikoktyā sarvaṃ samādhatte - sarveti | sarveṣāṃ
saṃdehānāṃ tattvājñānamūlakatvātsarvaikatānubhavalakṣaṇa##-
neha kiṃcinna nāmāsti vastu sapratighaṃ kvacit |
sarvadā sarvamevedaṃ śāntamapratighaṃ tatam
]

`v 22 [
śuddhaṃ saṃvinmayaṃ sarvaṃ śāntamapratighātmakam |
padārthajātaṃ pṛthvyādi svapnasaṃkalpayoriva
]

`v 23 [
ādāvante ca nāstīdaṃ kāraṇābhāvato'khilam |
bhrāntyātmā vartamānāpi bhāti citsvapnagā yathā
]

`v 24 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
mahatā kāraṇaughena bodhamapratighaṃ viduḥ
]

`v 25 [
antaḥkaraṇabhūtādi mṛtkāṣṭhadṛṣadādi vā |
sarvaṃ śūnyamaśūnyaṃ ca cetanaṃ viddhi netarat
]

`v 26 [
tatraivamaindavākhyānaṃ śṛṇu śravaṇabhūṣaṇam |
mayā ca pūrvamuktaṃ tatkiṃcānyadabhivarṇyate
]

`v 27 [
tathāpi vartamānoktapraśnabodhāya tacchṛṇu |
yathedaṃ sarvamadryādi cidityeva tu bhotsyate
]

`v 28 [
prastutapraśnasamādhānaprayojanabhedādapi paunaruktyamadoṣāyetyāha - tathāpīti |
amūrtā cidityeva praśnasamādhānaṃ tvayā bhotsyate | karmaṇi ḷṭi sye bhaṣbhāvaḥ |
27 |
kasmiṃścitprāktanenaiva jagajjāle'bhavaddvijaḥ |
tapovedakriyādhāro brahmanninduriti smṛtaḥ
]

`v 29 [
daśa tasyābhavanputrā jagato diktaṭā iva |
mahāśayā mahātmāno mahatāmāspadaṃ satām
]

`v 30 [
sa teṣāṃ kālavaśataḥ pitā'ntardhimupāyayau |
daśānāṃ bhagavān rudra ekādaśa iva kṣaye
]

`v 31 [
tasyānugamanaṃ cakre bhāryā vaidhavyabhītibhiḥ |
anuraktā dinasyeva saṃdhyā tārāvilocanā
]

`v 32 [
tayoste tanayā duḥkhakalitā vipinaṃ gatāḥ |
kṛtaurdhvadehikāstyaktvā vyavahāraṃ samādhaye
]

`v 33 [
dhāraṇānāṃ samastānāṃ kā syāduttamasiddhidā |
dhāraṇā yanmayāḥ santaḥ syāma sarveśvarā vayam
]

`v 34 [
iti te tatra saṃcintya baddhapadmāsanā daśa |
idaṃ saṃcintayāmāsurnirvighne kandarodare
]

`v 35 [
padmajādhiṣṭhitāśeṣajagaddhāraṇayā sthitāḥ |
bhavāmaḥ padmajopetaṃ jagadrūpamavighnataḥ
]

`v 36 [
iti saṃcintya sabrahmajagaddhāraṇayā ciram |
nimīlitadṛśastasthuste citraracitā iva
]

`v 37 [
athaitaddhāraṇābaddhacittāste tāvadacyutāḥ |
āsanmāsāndaśāṣṭau ca yāvatte tatra dehakāḥ
]

`v 38 [
śuṣkāḥ kaṃkālatāṃ yātāḥ kravyādaiścarvitāṅgakāḥ |
nāśamabhyāyayustatra cchāyābhāgā ivātapaiḥ
]

`v 39 [
ahaṃ brahmā jagaccedaṃ sargo'yaṃ bhuvanānvitaḥ |
iti saṃpaśyatāṃ teṣāṃ dīrghakālo'bhyavartata
]

`v 40 [
tāni cittānyadehāni daśaikadhyānatastataḥ |
saṃpannāni jagantyeva daśa dehāni vai pṛthak
]

`v 41 [
iti teṣāṃ cidicchā sā saṃpannā sakalaṃ jagat |
atyantasvaccharūpaiva sthitā cākāravarjitā
]

`v 42 [
saṃvinmayatvājjagatāṃ teṣāṃ bhūmyacalādi tat |
sarvaṃ cidātmakaṃ viddhi no cedanyatkimucyatām
]

`v 43 [
kila yattrijagajjālaṃ teṣāṃ kimātma tattathā |
saṃvidākāśaśūnyatvamātramevetaranna tat
]

`v 44 [
vidyate na yathā kiṃcittaraṅga salilādṛte |
saṃvittattvādṛte tadvadvidyate calanādikam
]

`v 45 [
aindavāni tathaitāni cinmayāni jaganti khe |
tathā cinmayameteṣu kāṣṭhaloṣṭopalādyapi
]

`v 46 [
yathaivaindavasaṃkalpāste jagattvamupāgatāḥ |
tathaivābjajasaṃkalpo jagattvamayamāgataḥ
]

`v 47 [
tasmādiheme girayo vasudhā pādapā ghanāḥ |
mahābhūtāni sarvaṃ ca cinmātramayamātatam
]

`v 48 [
cidvṛkṣāścinmahī ciddyauścidākāśaṃ cidadrayaḥ |
nācitkvacitsaṃbhavati teṣvaindavajagatsviva
]

`v 49 [
cinmātrakhakulālena svadehacalacakrake |
svaśarīramṛdā sargaḥ kutoyaṃ kriyate'niśam
]

`v 50 [
saṃkalpanirmite sarge dṛṣadaścenna cetanāḥ |
tadatra loṣṭaśailādi kimetaditi kathyatām
]

`v 51 [
etena kathaṃ sacetanā ete kāṣṭhaloṣṭopalādayaḥ iti praśno'pi samāhita ityāśayenāha ##-
kalanasmṛtisaṃskārā dadhatyarthaṃ ca nodare |
prāṅmṛṣṭaṃ kalpanādīnāmanyaivārthakalāvatām
]

`v 52 [
taddhāma saṃvido dhāmni maṇirāśau maṇiryathā |
sarvātmani tathā citte kaścidartha udetyalam
]

`v 53 [
akāryakaraṇasyārtho na bhinno brahmaṇaḥ kvacit |
svabhāva iti tenedaṃ sarvaṃ brahmeti niścayaḥ
]

`v 54 [
itaśca tṛṇakāṣṭhādiścetano yato'yamakāryakaraṇasya tasya sṛṣṭiḥ | yathā sūryasya
prabhā tatsvabhāva eva nāprakāśarūpā tadvadidaṃ sarva cetanaṃ brahmaivetyarthaḥ | 53
|
yathā pravṛttaṃ cidvāri vahatyāvartate'vanau |
svayatnenātitīvreṇa parātmīyātmanā vinā
]

`v 55 [
padmalīlā jagadiva prakacanti jaganti yat |
cinmātrādbrahmaṇaḥ svasmādanyāni na manāgapi
]

`v 56 [
yathā pādme kalpe bhagavannābhipadmalīlā eva jagadiva kacanti
tadvaccinmātrādbrahmaṇaḥ sakāśājjaganti prakacanti yattato'pi manāgapi tato nānyāni |
55 |
ajātamaniruddhaṃ ca sanmātraṃ brahma khātmakam |
śāntaṃ sadasatormadhyaṃ cidbhāmātramidaṃ jagat
]

`v 57 [
yatsaṃvinmayamadryādi saṃkalpajagati sthitam |
tadasaṃvinmayamiti vaktā'jño jñairvihasyate
]

`v 58 [
jagantyātmeva saṃkalpamayānyetāni vetti khe |
khātmakāni tathedaṃ ca brahma saṃkalpajaṃ jagat
]

`v 59 [
yāvadyāvadiyaṃ dṛṣṭiḥ śīghraṃ śīghraṃ vilokyate |
tāvattāvadidaṃ duḥkhaṃ śīghraṃ śīghraṃ vilīyate
]

`v 60 [
yāvadyāvadiyaṃ dṛṣṭiḥ prekṣyate na cirāccitā |
tāvattāvadidaṃ duḥkhaṃ bhavetpratighanaṃ ghanam
]

`v 61 [
dīrghaduṣkṛtamūḍhānāmimāṃ dṛṣṭimapaśyatām |
saṃsṛtirvajrasāreyaṃ na kadācitpraśāmyati
]

`v 62 [
nehākṛtirna ca bhavābhavajanmanāśāḥ sattā na caiva na ca nāma tathāstyasattā |
śāntaṃ paraṃ kacati kevalamātmanītthaṃ brahmāthavā kacanamapyalamatra nāsti
]

`v 63 [
ādyantavarjitamalabhyalatāgramūlanirmāṇamūlapariveśamaśeṣamaccham |
antasthanirgaganasargakaputrakaughaṃ nityaṃ sthitaṃ nanu ghanaṃ
gatajanmanāśam
]

`v 64 [
sanmātramantarahitākhilahastajātaṃ paryantahīnagaṇanāṅgamamuktarūpam |
ātmāmbarātmakamahaṃ tvidameva sarvaṃ sustambharūpamajamaunamalaṃ
vikalpaiḥ
]