`v 1 [
ekapañcāśaḥ sargaḥ 51
śrīrāma uvāca |
kathaṃ kevalajāgrattvamakāraṇamanarthakam |
parādvikasati brahmangaganādiva pādapaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
akāraṇaṃ mahābuddhe na kāryamupalabhyate |
tajjāgrataḥ kevalasya na kaścidiha saṃbhavaḥ
]

`v 3 [
tasyāto saṃbhavādanye jīvabhedāḥ sajīvakāḥ |
sarve na saṃbhavantyeva kāraṇābhāvavikṣatāḥ
]

`v 4 [
neha prajāyate kiṃcinneha kiṃcana naśyati |
upadeśyopadeśārthaṃ śabdārthakalanodayaḥ
]

`v 5 [
śrīrāma uvāca |
kaḥ karoti śarīrāṇi manobuddhyādicetanaiḥ |
ko mohayati bhūtāni sneharāgādibandhanaiḥ
]

`v 6 [
astvevaṃ tathāpi bhogāyatanasya dehādeḥ karmādidvārā sākṣādvā kaścinnirmātā
avaśyaṃ vācyaḥ | kāryamātrasya sakartṛkatvaniyamāt | tatra ca jīvaṃ praveśya
viṣayairvyāmohayitā'nyo vināvyāmohakaṃ cetanasya vyāmohādarśanāt | tathā ca
vyāmohyavyāmohakau dvau cetanāvanyau jīveśvarākhyau
sargādiśrutiyuktiprāmāṇyātsvīkāryāveveti punā rāmaḥ śaṅkate - kaḥ karotīti | 5
|
śrīvasiṣṭha uvāca |
na kaścideva kurute śarīrāṇi kadācana |
na mohayati bhūtāni kaścideva kadācana
]

`v 7 [
anādyantāvabhāsātmā bodha ātmani saṃsthitaḥ |
nānāpadārtharūpeṇa kamūrmyāditayā yathā
]

`v 8 [
bāhyaṃ na vidyate kiṃcidbodhaḥ sphurati bāhyavat |
udeti bodhahṛdayādbījādiva varadrumaḥ
]

`v 9 [
bodhasyāntaridaṃ viśvaṃ sthitameva raghūdvaha |
stambhasyāntaryathā śālabhañjikā prakaṭīkṛtā
]

`v 10 [
sabāhyābhyantarātmaikamanantaṃ deśakālataḥ |
bodhāmodaprasaraṇaṃ jagadeva prabudhyatām
]

`v 11 [
ayameva paro loko bhāvyatāṃ vāsanākṣayaḥ |
śāmyatāṃ paralokasthaṃ kāḥ kilāyānti vāsanāḥ
]

`v 12 [
deśakālakriyālokarūpacittātmasatpadam |
deśakālādiśabdārtharahitaṃ na ca śūnyakam
]

`v 13 [
pade padavidāmeva tasminbodhagatirbhavet |
draṣṭṝṇāṃ śāntadṛśyānāmevānyeṣāṃ na rāghava
]

`v 14 [
ye vai taralagambhīramahaṃtāgartamāśritāḥ |
paśyanti te tamālokaṃ na kadācana kecana
]

`v 15 [
caturdaśavidhānantabhūtajātasughuṃghumā |
jagaddṛṣṭiriyaṃ jñasya śarīrāvayavopamā
]

`v 16 [
kāraṇābhāvataḥ sṛṣṭirnoditā na ca śāmyati |
yādṛśaṃ kāraṇaṃ vā syāttādṛgbhavati kāryakam
]

`v 17 [
yadi syātkāraṇe kāryaṃ sthitaṃ kāraṇatāsya kā |
kāryamevopalambhāttadasaddvayamavedanāt
]

`v 18 [
saumyasyāntaryathāmbhodherūrmyāvartādayaḥ sthitāḥ |
brahmaṇyasaṃbhavakṣobhe jagaccittādayastathā
]

`v 19 [
sarvātmaivāmalaṃ brahma piṇḍa eka iva sthitam |
nānābhāṇḍātma hemaiva yathāntaḥsthitarūpakam
]

`v 20 [
svapnakāle svapna eva jāgradvyagrāparigrahāt |
jāgratkāle jāgradeva svapnaḥ satyāvabodhataḥ
]

`v 21 [
cittamātratayā buddhaṃ mṛgatṛṣṇāmbuvatsthitam |
jāgratsvapnatvamāyāti vicāravikalīkṛtam
]

`v 22 [
samyagjñānena bhūtāni jñasya dehatayā saha |
pīṭhabandhaṃ vimuñcanti gatakāla ivāmbudāḥ
]

`v 23 [
yathā galitumārabdho ghano gaganatāmiyāt |
tathā satyāvabodhena śāmyetsātmagrahaṃ jagat
]

`v 24 [
śaradabhravadālūnā mṛgatṛṣṇāmbuvattathā |
punaḥ saṃspṛśyamānaiva bodhādgalati dṛśyatā
]

`v 25 [
yathā dīptānale līnaṃ suvarṇaṃ ghṛtamindhanam |
ekatāṃ yāti vijñāne tathā bhuvanacittadṛk
]

`v 26 [
bodhena tanutāmeti piṇḍabandho jagattraye |
piśācabuddhiḥ sadane bodhitasya yathā śiśoḥ
]

`v 27 [
bodhasyānantarūpasya svayamevātmanātmani |
jagaccittāditā bhātā piṇḍabandhaḥ kilātrakaḥ
]

`v 28 [
bodhābodhanamevedaṃ jagaccittamivoditam |
tadevāstaṃ gataṃ bodhātpiṇḍabandhasya kāstitā
]

`v 29 [
jahāti piṇḍakāṭhinyaṃn jāgratsvapnāvabodhataḥ |
parāṃ pelavatāmeti hema drutamivāgninā
]

`v 30 [
yathāsthitaṃ bodha eva ghanatāmiva gacchati |
vinaiva deśakālābhyāṃ tau vinirmāya hemavat
]

`v 31 [
jāgratyevaṃ vicāreṇa svapnābhe pelave sthite |
kṣīyamāṇe śaratkāla ivaiti tanutāṃ rasaḥ
]

`v 32 [
parāṃ pelavatāṃ yātā dṛśyalakṣmyaḥ sthitā api |
svapnā iva parijñātā na svadante vivekinaḥ
]

`v 33 [
kva kila svātmaviśrāntiḥ kvaitadviṣayavedanam |
suṣuptajāgratoraikyaṃ bhrāntābhrāntātmanorbhavet
]

`v 34 [
cittamātre bhrāntimātre svapnamātrātmani sthite |
jagatīha padārthebhyaḥ satyabuddhirnivartate
]

`v 35 [
kasya svadante'satyāni kathameva mahāmate |
mṛgatṛṣṇājalānīva dṛśyānyapi puraḥsthitaiḥ
]

`v 36 [
satyabuddhau vilīnāyāṃ jagatpaśyati śāntadhīḥ |
jāladvīpāṃśujālābhamapiṇḍātmāmbarātmakam
]

`v 37 [
jāgrato vastutaḥ śūnyātparijñātānnivartate |
cittabhramātmano `note[cittamātrātmana iti pāṭhaḥ suvacaḥ |]
bhrāntirūpāsvādanabhāvanā
]

`v 38 [
yadavastviti vijñātaṃ tatropādeyatā kutaḥ |
kena svapnaṃ parijñāya svapnahemābhigamyate
]

`v 39 [
svapnādiva parijñātādraso dṛśyānnivartate |
draṣṭṭadṛśyadaśādoṣagranthicchedaḥ pravartate
]

`v 40 [
nīrasaḥ śāntamanano nirvāṇāhaṃkṛtiḥ kṛtī |
vītarāgo nirāyāsaḥ śāntastiṣṭhati buddhadhīḥ
]

`v 41 [
rase nīrasatāṃ yāte vāsanā pravilīyate |
śikhāyāṃ pravilīnāyāṃ pradīpasyāṃśavo yathā
]

`v 42 [
bodhāddīpāṃśujālābhamaghanaṃ vyoma dṛśyate |
bhrāntirūpaṃ jagatkṛtsnaṃ gandharvanagaraṃ yathā
]

`v 43 [
naivātmānaṃ na cākāśaṃ na śūnyaṃ na ca vedanam |
atyantapariṇāmena paśyanpaśyati tatpadam
]

`v 44 [
yatra nātmā na śūnyaṃ ca na jagatkalanā na ca |
na cittadṛśyodayadhīḥ sarvaṃ cāsti yathāsthitam
]

`v 45 [
bhūmyāditā'jñasaṃbuddhā jñānādastamupāgatā |
jñasya śūnyaiva saṃpannā saṃsthitāpi na vidyate
]

`v 46 [
bhavatyekasamādhānasaumyātmā vyomanirmalaḥ |
tiṣṭhatyapagatāsaṅgaḥ sthita evāpyasatsamaḥ
]

`v 47 [
astaṃgatamanā maunī nirodhapadavīṃ gataḥ |
tīrṇaḥ saṃsārajaladheḥ karmaṇāmantamāgataḥ
]

`v 48 [
tanubhuvanagaganagirigaṇakaraṇaparaṃ paramamajñānam |
vigalati galite tasmin sakalamidaṃ vidyamānamapi
]

`v 49 [
saṃśāntāntaḥkaraṇo galitavikalpaḥ svarūpasāramayaḥ |
paramaśamāmṛtatṛptastiṣṭhati vidvānnirāvaraṇaḥ
]