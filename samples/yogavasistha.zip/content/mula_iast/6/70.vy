`v 1 [
saptatitamaḥ sargaḥ 70
anyajagadbrahmovāca |
athāhaṃ cinmayākāśastvanyākāśamayīṃ sthitim |
parāṃ grahītumicchāmi tenehopasthitaḥ kṣayaḥ
]

`v 2 [
mahāpralayakāle'smiṃstyaktumeṣā mayādhunā |
munīndra nūnamārabdhā tena vairasyamāgatā
]

`v 3 [
ākāśatvādyadādyo'yaṃ parākāśo bhavāmyaham |
tadā mahāpralayatā vāsanāyāśca saṃkṣayaḥ
]

`v 4 [
tenaiṣā virasībhūtā manmārgaṃ paridhāvati |
nānugacchati ko nāma nirmātāramudāradhīḥ
]

`v 5 [
ihādyāyaṃ kalerantaścaturyugaviparyayaḥ |
prajāmanvindradevānāmadyaivānto'yamāgataḥ
]

`v 6 [
adyaiva cāyaṃ kalpānto mahākalpānta eva ca |
mamāyaṃ vāsanānto'dya dehavyomānta eva ca
]

`v 7 [
teneyaṃ vāsanā brahmankṣayaṃ gantuṃ samudyatā |
kveva padmākarāśoṣe gandhalekhāvatiṣṭhatām
]

`v 8 [
yathā jaḍābdhilekhāyā jāyate laharī calā |
vāsanāyāstathaivecchā mudhodetyapakāraṇam
]

`v 9 [
ābhimānikadehāyā vāsanāyāḥ svabhāvataḥ |
asyā ātmāvalokecchā svayamevopajāyate
]

`v 10 [
ātmatattvaṃ nu paśyantyā dhāraṇābhyāsayogataḥ |
dṛṣṭo'nayā bhavatsargo vargavyagranirargalaḥ
]

`v 11 [
anayāmbarasaṃcāraparayādriśiraḥśilā |
dṛṣṭā svajagadādhārabhūtāsmākaṃ tu khātmikā
]

`v 12 [
etadyasmiñjagadyatra taddṛṣattvaṃ jagadgirau |
asmajjagatpadārtheṣu saṃtyanyāni jagantyapi
]

`v 13 [
vayaṃ tāni na paśyāmo bhedadṛṣṭau sthitā ime |
bodhaikatāṃ gatāstvāśu paśyāmastāni vīkṣaṇāt
]

`v 14 [
ghaṭe paṭe vaṭe kuḍye khe'nale'mbhasi tejasi |
jaganti santi sarvatra śilāyāmiva sarvadā
]

`v 15 [
jagannāma mudhā bhrāntiḥ kila svapnapuropamā |
mithyaiveyaṃ kva nāmāsau cidrūpāstyatha nāsti ca
]

`v 16 [
parijñātā satī yeṣāmeṣā cinnabhasaikatām |
gatā te na vimuhyanti śiṣṭāstu bhramabhājanam
]

`v 17 [
athānyadhāraṇābhyāsātsvavirāgavaśoditam |
sādhayantyā'rthamātmīyaṃ dṛṣṭastvamanayā mune
]

`v 18 [
kimidaṃ bhūtabhavyeśa yadiyaṃ māmupāgatā iti
yatsvasamīpāgamanasāmarthyakāraṇaṃ pṛṣṭaṃ tasyottaramāha - atheti | atha
prāguktanirvedapāptyanantaraṃ svavirāgavaśāduditamātmīyaṃ
svābhilaṣitamātmajñānānukūlaṃ ca gurūpasadanaśravaṇamananādyarthaṃn
tvadupadeśātsādhayantyā sādhayitumicchantyā anayā anyāsāṃ
prāguktajagatsargadarśanahetudhāraṇāvyatiriktānāṃ
khecarasiddhibrahmāṇḍāntarasaṃcāraparamanaḥkalpitasūkṣmārthānupraveśasiddha##-
cūḍālopākhyānopavarṇitadhāraṇāviśeṣāṇāmabhyāsāttvatsaṃkalpakalpitaṃ
tvatsamādhisthānaṃ parijñāya tatra gatayā anayā antarhito'pi tvaṃ dṛṣṭa ityarthaḥ | 17
|
iti māyeva duṣpārā cicchaktiḥ parijṛmbhate |
itthamādyantarahitā brāhmī śaktiranāmayā
]

`v 19 [
pravartante nivartante neha kāryāṇi kānicit |
dravyakālakriyādyotā citistapati kevalam
]

`v 20 [
deśakālakriyādravyamanobuddhyādikaṃ tvidam |
cicchilāṅgakamevaikaṃ viddhyanastamayodayam
]

`v 21 [
cideveyaṃ śilākāramavatiṣṭhati bibhratī |
aṅgamasyā jagajjālaṃ marutaḥ spandanaṃ yathā
]

`v 22 [
vijñānaghanamātmānaṃ jagadityavabudhyate |
anādyantāpi sādyantā cittvāditi gatāpi cit
]

`v 23 [
cicchileyamanādyantā sādyantāstīti bodhataḥ |
sākārāpi nirākārā jagadaṅgeti saṃsthitā
]

`v 24 [
yadvatsvapne cideva svaṃ rūpaṃ vyomaiva pattanam |
vetti tadvadidaṃ vetti pāṣāṇaṃ jagadaṅgakam
]

`v 25 [
na sarantīha sarito na cakraṃ parivartate |
nārthāḥ pariṇamantyantaḥ kacatyetaccidambaram
]

`v 26 [
na mahākalpakalpāntasaṃvidaḥ saṃvidambare |
saṃbhavanti pṛthagrūpāḥ payasīva payontaram
]

`v 27 [
jaganti santyeva na santi śānte cidambare sarvagataikamūrtau |
nabhontarāṇīva mahānabhontaścitsanti sattāni parāmbarāṇi
]

`v 28 [
vasiṣṭha tadgaccha mune jagatsvaṃ tvaṃ cāsane saṃprati śāntimehi |
buddhyādirūpāṇi paraṃ vrajantu vayaṃ bṛhadbrahmapadaṃ prayāmaḥ
]