`v 1 [
aṣṭādaśādhikaśatatamaḥ sargaḥ 118
sahacarasahacaryaḥ krameṇocuḥ |
nirguṇasya bakasyāsya guṇa eko'sti dṛśyatām |
yatprāvṛṣaṃ smārayati prāvṛt prāvṛḍiti bruvan
]

`v 2 [
baka haṃsa ivābhāsi saraḥstho madgusauhṛdam |
nṛśaṃsatvaṃ ca vāṇīṃ ca tyaktvā haṃso bhava sphuṭam
]

`v 3 [
gambhīraṃ vārigarbhaṃ prasṛtajalacaraṃ ye praviśya praviśya
pāṅmatsyānprotacañcavaścaturatara paraṃ jagdhavanto vidagdhāḥ |
te kenāpyadya diṣṭyā mṛtatimigamitāḥ kālayukte mahimnā nākrāmanti
kramasthāḥ suharamapi puraḥ paṅgavo madgavo'mī
]

`v 4 [
evaṃ vihanyate lokaḥ svārtheneti pradarśayan |
madgurmadgurutāṃ yāta ityevaṃ stauti durjanaḥ
]

`v 5 [
utkandharo vitatanirmalacārupakṣo haṃso'yamatra nabhasīti janaiḥ pratītaḥ |
gṛhṇāti palvalajalācchapharīṃ yadāsau jñātastadā khalu bako'yamitīha lokaiḥ | 5
|
atra nabhasi utkandhara ūrdhvīkṛtakaṇṭho vitatau nirmalau cārū pakṣau yasya
tathāvidho'yaṃ parovartī haṃsa eveti prāgjanaiḥ pratīto niścito bako yadā asau iha bhūmau
palvalajalācchapharīṃ gṛhṇāti tadā bako'yamiti lokairjñātaḥ
]

`v 6 [
atibahukālavilolānavalokya bakāṃstapodambhān |
atraivātimirasthāṃstaṭavanitā vismitā dhūrtān
]

`v 7 [
atra jale himahelāḥ paśyaitā apaharanti sitapadmān |
icchasi tā anugantuṃ nāhaṃ te vallabhā vrajāmīti
]

`v 8 [
kupitāṃ tāmanunetuṃ yatnaparaḥ pāntha eṣa pathi kāntām |
avalokaya naranāyaka kusumalatākuharakelitīravane
]

`v 9 [
iti hāvabhāvavilasitavivalanakopārdhadṛṣṭihasitāni |
kurvāṇā varavanitā kathayati te dṛśyatāṃ rājan
]

`v 10 [
bakamadguśarārūṇāṃ nityamekaukasāmapi |
saṃkaro'sti mitho buddherna mūrkhaviduṣāmiva
]

`v 11 [
cañcvagre khañjarīṭasya kīṭaḥ kiṭikiṭāyate |
daurbhāgyasya purāṇasya patākevocchritonnate
]

`v 12 [
tāraṃ tīratarau sa rauti taralo yāvadbakaḥ prollasaṃstāvatpalvalagoṣpade'mbukalile
yāvadvalāddehakam |
majjantyā priyavakṣasīva nipuṇaṃ trātaṃ śapharyā bhayāddhṛdbhaṅgena
mahāpadīha hi mṛternānyadbhavetsaukhyadam
]

`v 13 [
bakājagaramadgūnāṃ hṛdi yā prāṇināṃ dhṛtiḥ |
acarvitanigīrṇānāṃ manye nidropamaiva sā
]

`v 14 [
āsannamadgubakagṛdhrabiḍālasarpadṛṣṭyā bhayaṃ bhavati yatsalilāśayānām
|
tasyāgratastṛṇamivāśanipātabhaṅgo jātismareṇa viduṣoktamadaḥ purā me | 14
|
salilāśayānāṃ matsyādīnāṃ āsannamadgubakādidarśanena yadbhayaṃ bhavati tasya
bhayasyāgrataḥ aśanipātaprayukto bhaṅgo bhayaṃ tṛṇamivālpameva | adaḥ rahasyaṃ
me purā jātismareṇa matsyādiyoniduḥkhāni smaratā viduṣā svānubhūtamuktam
nāsatyamiti mantavyamityarthaḥ
]

`v 15 [
iha sarovaratīratarostale kusumaśālini mugdhamṛgānpuraḥ |
samavalokaya lokamalau balātsamavakīrṇanavotpalaketakān
]

`v 16 [
barhī pronnatacittatvāttoyamindraṃ prayācate |
sa pūrayati tenāsya mahātmā nikhilāṃ mahīm
]

`v 17 [
meghānanusarantyete mayūrāstanapā iva |
malino malinasyaiva putra ityanumīyate
]

`v 18 [
mṛgānālokya pathikaścintayandayitekṣaṇe |
puraḥstheṣu padārtheṣu yantraputrikatāṃ gataḥ
]

`v 19 [
śikhī vāryapi nādatte bhūmerbhuṅkte balādahim |
daurātmyaṃ tanna jāne kiṃ sarpasya śikhino'thavā
]

`v 20 [
sajjanāśayanīkāśaṃ tyaktvā barhī mahatsaraḥ |
pibatyambvabhraniṣṭhyūtaṃ manye tannatibhītitaḥ
]

`v 21 [
lasatkalāpajaladāḥ paśya nṛtyanti barhiṇaḥ |
dhunvānāḥ picchakāntīnduṃ prāvṛṣaḥ potakā iva
]

`v 22 [
varavane vanavātavisāriṇāṃ capalacandrakacārutaraṅgiṇām |
iha payonidhireva kalāpināṃ visṛtamuktatayeva vilāsanaḥ
]

`v 23 [
cara tṛṇāni pibāmbu vanāvanau kalaya viśramaṇaṃ kadalīvane |
cakitacātaka pāvakadūṣitā na hi sukhāya bhavatyatimānitā
]

`v 24 [
nāyaṃ mayūra makarālayavāripūrapūrṇodaro jaladharo'mbaramārurukṣuḥ |
dāvāgnidagdhavanapādapakoṭarāgradhūmāvalīvalaya utthita eṣa śailāt
]

`v 25 [
yenābdena śaradvidhāvapi śikhī saṃtarpito vāribhirno varṣāsvapi pūrayedyadi
sarastadbālalokocitam |
ārabdhaṃ samavekṣya sajjanajano hāsena duḥstho bhavedbarhītyātmatṛṣaiva
netumakhilaṃ kālaṃ samabhyudyataḥ
]

`v 26 [
sphaṭikavimalaṃ pītvā toyaṃ ghanodaranirgataṃ pibati na punarmārge
kṣubhyaṃstṛṣāpi śikhī jalam |
sphurati ca ghanaṃ smṛtvā smṛtvā na cāpi vipadyate guṇavati jane
baddhāśānāṃ śramo'pi sukhāvahaḥ
]

`v 27 [
ihātivāhayantyete mārgadausthyaṃ ghanāgame |
kathābhiḥ pathikāḥ prāyo vimūḍhā jīvitaṃ yathā
]

`v 28 [
kāntāviyogināṃ pathikānāṃ varṣāsu kvacit kathālāpādinā kaṣṭena kālayāpanaṃ yathā
ātmajñānahīnānāṃ mūrkhānāṃ janmayāpanaṃ tathetyāha - iheti | ete pathikāḥ |
27 |
paśyātra nātha sarasaḥ kamalotpalakumudabisamṛṇālānām |
kahlārapatrapayasāṃ bhārānādāya bālikāścalitāḥ
]

`v 29 [
kimidaṃ nayatheti tataḥ pṛṣṭābhistābhiruktametasya |
vyasanajvarataptāyāḥ pathika vayaṃ bālasakhya iti
]

`v 30 [
atha rāgaraktahṛdayāḥ stanabharavitatā vilāsalalitāṅgyaḥ |
pathikānāṃ smaraṇapathaṃ bhūyo'pyanayanpriyāḥ svagehasthāḥ
]

`v 31 [
sā nūnaṃ mama kāntā dṛṣṭvā susnigdhaghanatamaḥśyāmam |
gaganaṃ ca śūnyagahanaṃ pralapati bhuvi patati viskhalati
]

`v 32 [
bhṛṅgāvalīkuvalayāvalitābjapātrasaṃpreryamāṇanalinīmadhupānamattaḥ |
hā vāti tīratarupallavalāsyalabdhasaṃmugdhaśabdagaṇagītaguṇo nabhasvān
]