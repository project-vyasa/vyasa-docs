`v 1 [
pañcaviṃśaḥ sargaḥ 25
śrīvasiṣṭha uvāca |
saṃvedanaṃ bhāvanaṃ ca vāsanā kalaneti ca |
anarthāyeha śabdārthe vigatārtho vijṛmbhate
]

`v 2 [
vedanaṃ bhāvanaṃ viddhi sarvadoṣasamāśrayam |
tasminnevāpadaḥ santi latā madhurase yathā
]

`v 3 [
saṃsāramārge gahane vāsanāveśavāhinaḥ |
upayāti vicitraughairvṛttavṛttāntasaṃtatiḥ
]

`v 4 [
vivekino vāsanayā saha saṃsārasaṃbhramaḥ |
kṣīyate mādhavasyānte śanairiva dharārasaḥ
]

`v 5 [
asyāḥ saṃsarasallakyā vāsanotsedhakāriṇī |
kadalyā vanajālinyā rasalekheva mādhavī
]

`v 6 [
saṃsārāndhyatayodeti vāsanātmā rasaścitau |
yathā vanatayā tasthau madhumāsarasaḥ kṣitau
]

`v 7 [
cinmātrādamalācchūnyādṛte kiṃcinna vidyate |
nānyatkiṃcidaparyante khe śūnyatvetaradyathā
]

`v 8 [
vedanātmā na so'styanya iti yā pratibhā sthirā |
eṣā'vidyā bhramastveṣa sa ca saṃsāra ātataḥ
]

`v 9 [
anālokanasaṃsiddha ālokenaiva naśyati |
asadātmā sadābhāso bālavetālavatkṣaṇāt
]

`v 10 [
sarvadṛśyadṛśo bādhe bodhasāratayaikatām |
yāntyaśeṣamahīpīṭhasaritpūrā ivārṇave
]

`v 11 [
mṛnmayaṃ tu yathā bhāṇḍaṃn mṛcchūnyaṃn nopalabhyate |
cinmayāditayā cetyaṃn cicchūnyaṃ nopalabhyate
]

`v 12 [
bodhāvabuddhaṃ yadvastu bodha eva taducyate |
nābodhaṃ budhyate bodho vairūpyāttena nānyatā
]

`v 13 [
draṣṭṭadar'sanadṛśyeṣu pratyekaṃ bodhamātratā |
sārastena tadanyatvaṃ nāsti kiṃcitkhapuṣpavat
]

`v 14 [
sajātīyaḥ sajātīyenaikatāmanugacchati |
anyonyānubhavastena bhavatvekatvaniścayaḥ
]

`v 15 [
yadi kāṣṭhopalādīnāṃ na bhavedbodharūpatā |
tatsadānupalambhaḥ syādeteṣāmasatāmiva
]

`v 16 [
yadā tveṣā nu dṛśyaśrīrbodhamātraikarūpiṇī |
tadānyevāpyananyaiva satī bodhena bodhyate
]

`v 17 [
sarvaṃ jagadgataṃ dṛśyaṃn bodhamātramidaṃ tatam |
spandamātraṃ yathā vāyurjalamātraṃ yathārṇavaḥ
]

`v 18 [
miśrībhūtā api hyete jatukāṣṭhādayo yathā |
mitho'nanubhave miśrā aikyaṃ hyanubhave mithaḥ
]

`v 19 [
anyonyānubhavo hyaikyamaikyaṃ tvanyonyavedanam |
yathāmbhasoḥ kṣīrayorvā na kāṣṭhajatunoriva
]

`v 20 [
ahamityeva bandhāya nāhamityeva muktaye |
etāvanmātrake bandhe svāyatte kimaśaktatā
]

`v 21 [
candradvayapratyayavanmṛgatṛṣṇāmbubuddhivat |
kimanutthita evāyamasadevāhamutthitaḥ
]

`v 22 [
mamedamiti bandhāya nāhamityeva muktaye |
etāvanmātrake vastunyātmāyatte kimajñatā
]

`v 23 [
yaḥ kuṇḍabadaranyāyo yā ghaṭākāśayoḥ sthitiḥ |
sa saṃbandho'pi naivānyamaikyaṃ hyanyonyavedanam
]

`v 24 [
anyonyāvedanaṃ tvaikyaṃ bhāgaśo gatamapyalam |
ajaḍaṃ vā jaḍaṃ vāpi naikaṃ rūpaṃ vimuñcati
]

`v 25 [
nājaḍaṃ jaḍatāmeti svabhāvā hyanapāyinaḥ |
yaccājaḍaṃ jaḍaṃ dṛṣṭaṃ dvaiti tatrāsti naikatā
]

`v 26 [
vāsanāveśavalitāḥ kuvikāraśatātmabhiḥ |
vrajantyadhodho dhāvantaṃ śilāḥ śailacyutā iva
]

`v 27 [
vyūḍhānāṃ vāsanāvātairnṛtṛṇānāmitastataḥ |
tānyāpatanti duḥkhāni tatra vaktuṃ na pāryate
]

`v 28 [
bhrāntvā bhṛśaṃ karatalāhatakandukābhaṃ lokāḥ patanti nirayeṣu rasena
raktāḥ |
kleśena tatra parijarjaratāṃ prayātāḥ kālāntareṇa punaranyanibhā bhavanti
]