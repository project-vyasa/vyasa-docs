`v 1 [
pañcaṣaṣṭitamaḥ sargaḥ 65
vidyādharyuvāca |
atha kālena mahatā so'nurāgo virāgatām |
prapto mama śaracchāntau virasaḥ pallavo yathā
]

`v 2 [
vṛddha ekāntarasiko nīrasaḥ snehavarjitaḥ |
bhartā'jihmamatirmaunī kiṃ manye jīvitena me
]

`v 3 [
varaṃ vaidhavyamābālyādvaraṃ maraṇameva ca |
varaṃ vyādhirathāpadvā nāhṛdyaprakṛtiḥ patiḥ
]

`v 4 [
etāvajjanmasāphalyaṃ saubhāgyamavikhaṇḍitam |
rasikaḥ peśalācāro yannāryāstaruṇaḥ patiḥ
]

`v 5 [
hatā nīrasanāthā strī hatā'saṃskāriṇī ca dhīḥ |
hatā durjanabhuktā śrīrhatā veśyāhṛtā ca hrīḥ
]

`v 6 [
sā strī yānugatā bhartrā sā śrīryānugatā satā |
sā dhiryā madhurodārā sādhutā samadṛṣṭitā
]

`v 7 [
nādhayo vyādhayo naiva nāpado na durītayaḥ |
kurvanti manaso bādhāṃ daṃpatyoranuraktayoḥ
]

`v 8 [
utphullāḥ kusumasthalyonandanodyānabhūmayaḥ |
dhanvāyante kunāthānāṃ vināthānāṃ ca yoṣitām
]

`v 9 [
sarva eva jagadbhāvā yathecchaṃ guṇaleśataḥ |
saṃtyajyante pramādāttu varjayitvā patiṃ striyā
]

`v 10 [
sthirayauvanayā duḥkhānyetāni munināyaka |
bhuktāni varṣavṛndāni paśya daurbhāgyajṛmbhitam
]

`v 11 [
atha krameṇa tenaiva sarāgo me virāgatām |
āyayau himadagdhāyā nalinyā iva nīrasaḥ
]

`v 12 [
virāgavāsanāstena sarvabhāvānurañjanā |
tavopadeśenecchāmi mune nirvāṇamātmanaḥ
]

`v 13 [
aprāptābhimatārthānāmaviśrāntadhiyāṃ pare |
maraṇairuhyamānānāṃ jīvitānmaraṇaṃ varam
]

`v 14 [
sa madbhartādya nirvāṇamīhamāno divāniśam |
rājā rājñeva manasā mano jetuṃn prabudhyate
]

`v 15 [
brahmaṃstasya ca madbharturmama cājñānaśāntaye |
nyāyopapannayā vācā kuru smaraṇamātmanaḥ
]

`v 16 [
yadā māmanapekṣyaiva sa madbhartātmani sthitaḥ |
tadā virāgo vairasyamanayanme jagatsthitim
]

`v 17 [
saṃsāravāsanāveśavarjitāsmi tato'vasam |
nibadhyābhimatāṃ tīvrāṃ vyomasaṃcāradhāraṇām
]

`v 18 [
arjayitvā tahā vyomni gatiṃ dhāraṇayā mayā |
abhyastā dhāraṇā bhūyaḥ siddhasaṅgaphalapradā
]

`v 19 [
tataḥ svajagadādhārapūrvāparanirīkṣayā |
sthitāhaṃ dhāraṇāṃ baddhvā sāpi siddhiṃ samāgatā
]

`v 20 [
atha svajagato dṛṣṭvā hṛdayaṃ tasya bāhyagā |
ahaṃ dṛṣṭavatī sthūlāṃ lokālokagireḥ śilām
]

`v 21 [
etāvatāpi kālena daṃpatyorāvayormune |
paraṃ draṣṭumabhūdicchā na kācana kadācana
]

`v 22 [
madbhartā kevalaṃ śuddhavedārthaikāntacintayā |
na ca yātaṃ na cāyātaṃ vettyaho vigataiṣaṇaḥ
]

`v 23 [
tenāsau matpatirvidvānapi na prāptavānpadam |
adya so'haṃ ca vāñchāvaḥ prayatnena paraṃ padam
]

`v 24 [
tadetāmarthitāṃ brahmansaphalāṃ kartumarhasi |
mahatāmarthino vyarthā na kadācana kecana
]

`v 25 [
bhramantī siddhasenāsu sadā nabhasi mānada |
tvadṛte neha paśyāmi ghanājñānadavānalam
]

`v 26 [
brahmanvinaiva karuṇākarakāraṇena santo yato'rthijanavāñchitapūraṇāni |
kurvanti tena śaraṇāgatatāmupetāṃ māmarhasīha na tiraskaraṇena yoktum
]