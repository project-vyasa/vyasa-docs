`v 1 [
aṣṭasaptatitamaḥ sargaḥ 78
śrīvasiṣṭha uvāca |
vātavarṣahimotpātapātabhagne dharātale |
jaḍavego'gamadvṛddhiṃ kalāviva mahīpatiḥ
]

`v 2 [
gaṅgāpravāhapatitadhārāpātavivardhitaḥ |
saritsahasraiḥ sahasā merumandarabhāsuraiḥ
]

`v 3 [
ādityapathasaṃprāptakandro jaḍamantharaḥ |
ekārṇavaḥ samucchūna āsīnmūrkha iveśvaraḥ
]

`v 4 [
vipulāvartavṛttyāttavivṛttādrijarattṛṇaḥ |
sphurattuṅgataraṅgāgranigīrṇādityamaṇḍalaḥ
]

`v 5 [
merumandarakailāsavindhyasahyajalecaraḥ |
galitāvanipaṅkāntarlīnavyālamṛṇālakaḥ
]

`v 6 [
ardhadagdhadrumavanavyūhaśaivalasaṃkaṭaḥ |
trailokyabhasmasaṃsṛṣṭa āsītkardamakutsitaḥ
]

`v 7 [
nabhaḥstambhabṛhaddhānottālabhāskarapuṣkaraḥ `note[stamba ityapi pāṭhaḥ |
] |
dhārājālamahāmbhodavilīnanalinīdalaḥ
]

`v 8 [
ḍiṇḍīraparvataprāntanadadunmattavāridaḥ|
bhramadindrānilārkendupurapattanapūraṇaiḥ
]

`v 9 [
kāṣṭhavatprohyamāṇograsurāsurajanotkaraḥ |
śanaiḥ kramocchūnatayā lihannādityamaṇḍalam
]

`v 10 [
tarattāratarārāvadhārādharasamudbhavaiḥ |
budbudaiḥ parisaṃdigdhaprohyamāṇamahācalaḥ
]

`v 11 [
kimete budbudā uta mahācalā iti paritaḥ saṃdigdhāḥ prohyamāṇā mahācalā yasmin | 10
|
bhramadbudbudaviśrāntabhrāntakalpāntavāridaḥ |
uttālaistairanādhāraiḥ paśyannaparavāridam
]

`v 12 [
mahāpravāhavāryoghaghoṣaghuṃghumitāmbaraḥ |
ekapravāhamahitasavyomakulaparvataḥ
]

`v 13 [
caṇḍavātakṛtāpūrvajalaughakulaparvataiḥ |
mahāghuraghurārāvaghargharogramahārayaḥ
]

`v 14 [
brahmāṇḍakhaṇḍasaṃghaṭṭaparāvṛttibhiruddhataḥ |
kurvanyojanalakṣāṇi vitatānyunnatāni ca
]

`v 15 [
tṛṇairiva taraṅgeṣu dolāndolanamadribhiḥ |
kurvadbhirupalāghātabhagnabhāskaramaṇḍalaḥ
]

`v 16 [
śūnyabrahmāṇḍavipulajalaghātakulāyake |
nīlānacalakākolāñjahransalilajālakaiḥ
]

`v 17 [
mṛtāmṛtamahadbhūtamajjanonmajjanākulān |
taraṃgamakarāvartapratibimbānvitāniva
]

`v 18 [
mṛtaśiṣṭānpurabhraṣṭānphenādritaṭikoṭiṣu |
dadhajjalabalaśrāntāṃstridaśānmaśakāniva
]

`v 19 [
vipulādyatanākāśavipulānambubudbudān |
sahasrasaṃkhyānkalayaṃllocanānīva vāsavaḥ
]

`v 20 [
vipulo yodyatanaḥ prasiddhaḥ ākāśaḥ
adhomukhīkṛtarajatakaṭāhavaddṛśyamānastadvadvipulāniti
budbudāntarniviṣṭaprāṇidṛṣṭyoktiḥ | locanānīva vāsava iti bahiṣṭadṛṣṭyā upamā |
19 |
śaradvyomasamābhogairvaladbhirbudbudekṣaṇaiḥ |
paśyanniva nadīdhārānmeghānātāmrapūrakān
]

`v 21 [
puṣkarāvartakābhrāṇāṃ bahubhirvīcimaṇḍalaiḥ |
kurvannāliṅganānīva sapakṣādrivadutthitaiḥ
]

`v 22 [
trijagadgrāsasaṃtṛptaḥ pragāyanniva ghargharaiḥ |
svairnṛtyannniva cogrādrikaṭakairvīcidordrumaiḥ
]

`v 23 [
nadīdhārādharairūrdhve madhye dagdhairdharādharaiḥ |
adho dharādharairnāgairadharaḥ paṅkagairvṛtaḥ
]

`v 24 [
dhārātripathagāpūrairnipatadbhirnirantaram |
magnonmagno hyamānādriśṛṅgaḍiṇḍīrabudbudaḥ
]

`v 25 [
uhyamānadalatsvargakhaṇḍakrandannabhaścaraḥ |
vahadvidyādharīvṛndapadminīsundarāntaraḥ
]

`v 26 [
ekārṇavapayaḥpūrairghargharārāvaraṃhasi |
trailokyakhaṇḍasaṃhāre prohyamāṇe mahāmbhasi
]

`v 27 [
nāsītkaścitparitrātā hantā'vīcivaśo'pi ca |
śaknoti kaḥ paritrātuṃ kālena kavalīkṛtam
]

`v 28 [
nākāśamāsīnna diganta āsīdadho'pi nāsīnna tadūrdhvamāsīt |
bhūtaṃ na āsīnna ca sarga āsīdāsītparaṃ kevalameva vāri
]