`v 1 [
ṣaṭsaptatitamaḥ sargaḥ 76
śrīvasiṣṭha uvāca |
atha kalpāntamaruti vahatyavadhutācale |
balenāmbhodhikallolairnabhasyāvartakāriṇi
]

`v 2 [
samudreṣu vimudreṣu maryādollaṅghane ghane |
adhaneṣu dhaniṣvambudāridryopadravadrute
]

`v 3 [
bhūtale bhūtaleśāṃśavarjite vahnibharjite |
pātālamapi pātāle gate kimapi kālataḥ
]

`v 4 [
divi vā vidyamānāyāṃ viśīrṇe sargavargake |
loke vyomagatāloke śokaukasi kakubgaṇe
]

`v 5 [
kuto'pyākāśakuharāddṛptadaityagaṇā iva |
puṣkarāvartakā meghāścakrurgulugulāravam
]

`v 6 [
brahmavisphoṭitasvāṇḍakuḍyavisphoṭanodbhaṭam |
anyonyāsphālanotphālamattārṇavaravāvilam
]

`v 7 [
lokārṇavapurodgīrṇaghanakolāhalolbaṇam |
etatkulācalaskandhabaddhograravaghargharam
]

`v 8 [
brahmāṇḍaśaṅkhajaṭharapūraṇāvartamantharam |
svarlokarodaḥpātālatalato'tisagulmakam
]

`v 9 [
samastadūradigbhittihelāhelanagharṣulam |
mahāpralayasaṃpannāpānakāpānatarṣulam
]

`v 10 [
prasṛtapralayākhyendramattairāvatabṛṃhitam |
ākalpakṣubdhameghābdhinirhrādamiva saṃbhṛtam
]

`v 11 [
mahāpralayasaṃkṣubdhakṣīrodamathanāravam |
brahmāṇḍogrāraghaṭṭe'sminvāryantramiva sāravam
]

`v 12 [
athāsminsati kalpāgnau sthitimeti kathaṃ ghanaḥ |
iti vismitavānasmi dṛśaṃ dignavake'tyajam
]

`v 13 [
yāvanna kvacidevātra paśyāmyāśāsu kevalam |
taranti taralāsphālamulmukāśanivṛṣṭayaḥ
]

`v 14 [
tena jvalanatāpena bahuyojanakoṭiṣu |
padārthā bhasmatāṃ yānti dūre dikṣu daśasvapi
]

`v 15 [
anantaraṃ kṣaṇādvyomni dūre'hamanubhūtavān |
ūrdhvataḥ śītalaṃ vātamadhastādanalopamam
]

`v 16 [
etāvati nabhomārge dūre kalpāmbudāḥ sthitāḥ |
yasteṣāmagnitāpānāṃ viṣayo na ca saddṛśām
]

`v 17 [
atha vāruṇadigbhāgādāyayau kalpamārutaḥ |
yasmiṃstṛṇavaduhyante vindhyameruhimālayāḥ
]

`v 18 [
tena jvālācalāḥ prāntoḍḍīnāṅgāravihaṃgamāḥ |
lololmukavanākrāntā jagmuragnidiśaṃ drutam
]

`v 19 [
saṃdhyābhrasadṛśākārāsteruraṅgāravāridāḥ |
bhremurbhasmabharābhrāṇi pūtāṅgārarajāṃsi khe
]

`v 20 [
sa jvālavilasadvāto duṣṭo'naladṛśaṃ vrajan |
hemādrīṇāṃ sapakṣāṇāmanīkaṃ dravatāmiva
]

`v 21 [
dharādrimaṇḍalābhoge saumyāṅgārabharātmani |
jvālāvaligaṇe jāte bhāte tejasi bhāsvatām
]

`v 22 [
arṇaveṣvanalārṇasssu kvathanotphālavāriṣu |
vaneṣvasmṛtaparṇeṣu dīptāgnitarudhāriṣu
]

`v 23 [
brahmalokasthanātheṣu brahmalokapureṣu ca |
sāṅganābālavṛddheṣu dagdheṣu nipatatsu kham
]

`v 24 [
kalpāntānalapadminyā brahmāgrāvasarovare |
jvālāpallavaśālinyāḥ sabījāyāḥ saṭolmukaiḥ
]

`v 25 [
anilātmasu mūleṣu nāgeṣu ca nageṣu ca |
āpātālaṃ nimagneṣu mahatyaṅgārakardame
]

`v 26 [
uṣṭrasainyamivālakṣya gatimannikaṭaṃ nabhaḥ |
āyayāvañjanaśyāmaḥ kalpāmbudagaṇaḥ kvaṇan
]

`v 27 [
sthirakalpānalajvālātulyavidyunmayācalaḥ |
ekakoṇakaviśrāntasaptārṇavapayobharaḥ
]

`v 28 [
bhittibhāsuranīhārabhāranirvāradiktaṭaḥ |
brahmāṇḍakuḍyanibiḍamaṇḍalāsphoṭapaṇḍitaḥ
]

`v 29 [
kalpāntakṣubhitāmbhodhirvartulāvartavṛttimān |
taḍijjalacaraḥ sāranirhnādaḥ khamivāgataḥ
]

`v 30 [
kalpāntakṣubhitāmbhodhireva khamāyāto'dhirūḍha ivetyutprekṣā |
vartulāvartasthānīyadvādaśāadityapariveṣavṛttimānityādiviśeṣaṇānyut##-
mṛto dagdho niśānāthastato dviguṇaśītalaḥ |
anyamākāramāśritya paraṃ lokamivāgataḥ
]

`v 31 [
hemasaṃbhārarūpeṇa himālayamivākhilam |
jāḍyastambhitaniḥśeṣajalakāṣṭhācalaṃ dadhat
]

`v 32 [
atha brahmāṇḍavisphoṭakaṭhinaṃ ghaṭitāmbaram |
prāgdrutodbhaṭatauṣārakāṣṭhā vṛṣṭiḥ papāta ha
]

`v 33 [
atha meghāgamanānantaraṃ vṛṣṭiḥ papāta | katham | brahmāṇḍasya
visphoṭavatkaṭhinavajranirghātena ghaṭitamambaraṃ yasminkarmaṇi tathāvidhā prāk
prathamaṃ drutā udbhaṭanīhārāḥ `note[mūlasthatauṣārapadasyaivāyamarthaḥ | athavā
etadanurodhena mūle udbhaṭanīhāreti pāṭho vā kalpyaḥ |] kāṣṭhā diśo yasyām | 32
|
agnidāhavanākāśavidyudunmeṣabhīṣaṇā |
caṭadgaḍagaḍāsphoṭasphuṭadbrahmāṇḍamaṇḍalā
]

`v 34 [
prathitotthitasītkāraśatakṣveḍākṣayāravā |
śītasīkaranīhārabhittibandhamayāmbarā
]

`v 35 [
rodomaṇḍapavaidūryastambhasaṃbhārabhāsuraiḥ |
dhārāsārairdharādhuryaśailaśātakaśālinī
]

`v 36 [
dharācaṭacaṭāsphoṭasphuṭadaṅgārapattanā |
garjitorjitasaṃpātapatallokāntarākulā
]

`v 37 [
sā babhūvātha sāṅgārajagadgehavilāsinī |
kṛtapratyudgamā bāṣpaśriyā'jvalanayā bhuvaḥ
]

`v 38 [
jvālālavollalanaḍambaramambaraṃ tadvyūḍhasthalābjadalajālamivālamāsīt |
jvālābhramadbhramarapaṅktinibhāstadāsaṃstatra
sphuracchiśirasīkarapakṣapuñjāḥ
]

`v 39 [
udyadbṛhaccaṭacaṭāravapūritāśo bhīmo'bhavatsaliladānalasaṃnipātaḥ |
durvāravairiviṣamo mahatāṃ balānāṃ saṃgrāma ugra iva hetihatograhetiḥ
]