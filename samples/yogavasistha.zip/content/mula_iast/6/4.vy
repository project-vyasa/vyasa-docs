`v 1 [
pdf 160, p. 1076
caturthaḥ sargaḥ 4
śrīvasiṣṭha uvāca |
sāhaṃtādijagacchāntau bodhe saṃvitkalātmani |
saṃśāntadīpasaṃkāśastyāgaḥ siddhyati nānyathā
]

`v 2 [
īhāhaṃtaiva saṃsāramūlamityupavarṇyate |
tattyāgaścānahaṃbhāvabhāvanādātmabodhataḥ |
dṛgātmanaḥ sarvadṛśyatyāgo hi mokṣaḥ sa ca snehakṣaye
dīpanirvāṇavattattvabodhena sarvadṛśyamūlājñānabādhe siddhyati nānyathetyāha ##-
na tyāgaḥ karmasaṃtyāgo bodhastyāga iti smṛtaḥ |
ajagatpratibhaikātmā yo'nahaṃtādiravyayaḥ
]

`v 3 [
ayaṃ sohamidaṃ tanma iti niḥsnehadīpavat |
śānte paramanirvāṇe prabodhātmeti śiṣyate
]

`v 4 [
ayaṃ sohamidaṃ tanme śāntamityeva yasya no |
na jñānaṃ tasya no śāntirna tyāgo na ca nirvṛtiḥ
]

`v 5 [
mamedamayamevāhamityetāvati yaḥ kṣayaḥ |
bodhātmā śivamāśāntaṃ tasmādanyanna vidyate
]

`v 6 [
ahamaṃśe vidā kṣīṇe sarvameva kṣayaṃ gatam |
na kiṃcicca kvacitkṣīṇaṃ nirvāṇaikaghanaṃ sthitam
]

`v 7 [
ahaṃvidanahaṃvittvādeva śāmyatyavighnataḥ |
etāvanmātrasādhyeyaṃn kimiveyaṃ kadarthanā
]

`v 8 [
ahaṃnāhamiti bhrāntirna ca cittvādṛte'sti sā |
cittvaṃ cākāśaviśadamataḥ kvaiṣā `note[kaiṣā ityapi pāṭhaḥ |] bhramasthitiḥ
]

`v 9 [
na bhramo bhramaṇaṃ naiva na bhrāntirbhrāmako'sti vā |
anālokanamevedamālokānnedamasti te
]

`v 10 [
viddhi cinmātramevedamasadrūpopamaṃ tatam |
tenālaṃ maunamāssvaivaṃ sarvaṃ nirvāṇamātrakam
]

`v 11 [
yenaivāśu nimeṣeṇa tvahamityeva cetati |
tenaiva nāhamityeva cetitvāśu na śocyate
]

`v 12 [
ahaṃbhāvaṃ nabhorthena nirvācyārūḍhabāṇavat |
ajasramāśu vā'kṣīṇaṃ tiṣṭhāvaṣṭabdhatatpadaḥ
]

`v 13 [
sanabhorthāmahantāṃ tvaṃ cetannevamanāratam |
sarvabhāvairanārūḍho bhava tīrṇabhavārṇavaḥ
]

`v 14 [
svabhāvamātravijaye svayaṃ yasya na vīratā |
tasyottamapadaprāptau paśorbrūhi kathaiva kā
]

`v 15 [
ṣaḍvargo nirjitaḥ pūrvaṃ yenottamavidā svataḥ |
bhājanaṃ sa mahārthānāṃ netaro naragardabhaḥ
]

`v 16 [
yasya svāntarmanovṛttirjīyamānā jitāthavā |
viṣayaḥ sa vivekānāṃ sa pumāniti kathyate
]

`v 17 [
artho dṛṣadivāmbhodhau yo ya āpatati tvayi |
tasmādeva palāyasva nāhamityeva bhāvayan
]

`v 18 [
nāhamasmīti `note[astīti pāṭhaḥ |] buddhvāpi sopapattikamapyalam |
jānāno jñaptimātraṃ ca kimajña iva muhyasi
]

`v 19 [
na jñeyamarthato'stīha hemnīva kaṭakāditā |
bhrāntimātrādṛte sā ca śāmyatyasmaraṇena te
]

`v 20 [
yo yo bhāva udetyantastvayi spanda ivānile |
nāhamasmīti cidvṛttyā tamanādhāratāṃ naya
]

`v 21 [
lobho lajjā mado moho yenādāviti no jitāḥ |
nirarthakamanarthe'sminsa kimarthaṃ pravartate
]

`v 22 [
ahantvaṃ pavane spanda iva yattvayi saṃsthitam |
paramātmani tannānyadetatspanda ivānile
]

`v 23 [
asargasaṃvidā sargaḥ pare'sto'tivirājate |
saṃniveśaviśeṣeṇa durartho'pi hi śobhate
]

`v 24 [
paramātmā tu nodeti nāstaṃ yāti kadācana |
na cāsmādanyadastīti ko bhāvo'bhāva eva vā
]

`v 25 [
paraṃ pare pūrṇaṃ pūrṇe śāntaṃ śānte śivaṃ śive |
ityevamātraṃ vitataṃ nāhaṃ na ca jaganna dhīḥ
]

`v 26 [
anirvāṇe vinirvāṇaṃ śāntaṃ śānte śive śivam |
nirvāṇamapyanirvāṇaṃ sanabhorthaṃ na vāpi tat
]

`v 27 [
pdf 161, 1078
śastrāghātāḥ prasahyante sahyante vyādhivedanāḥ |
nāhamityevamātrasya sahane kā kadarthanā
]

`v 28 [
jagatpadārthasārthānāmahamityakṣayo'ṅkuraḥ |
tasminnirmūlatāṃ yāte jagannirmūlatāṃ gatam
]

`v 29 [
vāṣpeṇevāhamarthena niḥsāreṇāpi sāravat |
vyāmalaḥ paramādarśastacchāntau saṃprasīdati
]

`v 30 [
ahamarthaḥ pare vāyau spandastatpraśame tu tat |
anirdeśyamanābhāsamanantamajamavyayam
]

`v 31 [
ahamarthaḥ puro dravyapratibimbapradaściti |
tacchāntau sā nirābhāsamanantamajamavyayam
]

`v 32 [
ahamarthāmbude kṣīṇe paramārthaśarannabhaḥ |
parayānantayā lakṣmyā svacchayācchaṃ virājate
]

`v 33 [
ahamarthamalonmuktamavyaktaṃ tāmramaṅga cet |
tatparaṃ paramābhāsaṃ saṃpannaṃ hema kāntimat
]

`v 34 [
yathā nirabhidhārthaśrīrbhajatyavyapadeśyatām |
tathānahantāhanteyaṃ brahmatvamadhigacchati
]

`v 35 [
astyahantve sthitaṃ brahma sanāmeva padārthavat |
śāntavatsadivābhāsaṃ tadvatsa vyapadeśavān
]

`v 36 [
ahamartho jagadbījaṃ yadi dagdhamabhāvanāt |
tadahantvaṃ jagadbandha ityādeḥ kalanaiva kā
]

`v 37 [
sadbrahma śivamātmeti pare nāmakalaṅkitā |
udetyahantā kumbhatvādiva mṛddhātuvismṛtiḥ
]

`v 38 [
ahamarthādiyaṃ bījātsattā bimbalatotthitā |
yasyāṃ jagantyanantāni phalānyāyānti yānti ca
]

`v 39 [
sādryabdhyurvīnadī seyaṃ rūpālokaiṣaṇādikā |
ahamarthasya maricabījasyāntaścamatkṛtiḥ
]

`v 40 [
dyauḥ kṣamā vāyurākāśaṃ parvatā sarito diśaḥ |
ityāmodo'hamarthograkusumasya vikāsinaḥ
]

`v 41 [
ahamarthaḥ pravisṛtaḥ prakaṭīkurute jagat |
sadrūpālokamananaṃ pravṛtta iva vāsaraḥ
]

`v 42 [
pravṛttena dinenārthaḥ prakaṭīkriyate yathā |
asajjagadahantvena kṣaṇānnirmīyate tathā
]

`v 43 [
ahamityarthadustailalavo brahmaṇi vāriṇi |
prasṛto yattadāśvetattrijagaccakrakaṃ sthitam
]

`v 44 [
unmeṣamātreṇāhantā jagantyanubhavatyaho |
na nimeṣeṇa dṛgiva satyānītyapyasantyalam
]

`v 45 [
ahamarthe pravisṛte saṃsāro hyanubhūyate |
nāntarbhūya parikṣīṇe locanasyeva tārake
]

`v 46 [
ahamaṃśe niraṃśatvaṃ nīte śāśvatasaṃvidā |
śāmyatīyamaśeṣeṇa saṃsāramṛgatṛṣṇikā
]

`v 47 [
svasaṃvidbhāvanāmātrasādhye'sminvaravastuni |
siddhamātrātmani svairaṃ mā khedaṃ gaccha mā bhramīm
]

`v 48 [
svayatnamātrasaṃsādhyādasahāyādisādhanāt |
anahaṃvedanānnānyacchreyaḥ paśyāmi te'nagha
]

`v 49 [
vismṛtyāhaṃ tvamāssva pravisṛtavibhavaḥ pūritāśeṣaviśvo
viṣvakśailāntarikṣakṣitijaladhimarunmārgarūpo'malātmā |
svasthaḥ śānto viśokaḥ karaṇamalakalāvarjito niṣprapañco
niḥsaṃcāraścarātmā sakalamasakalaṃ ceti siddhāntasāraḥ
]