`v 1 [
iti
śrīmatparamahaṃsaparivrājakācāryavaryaśrīmatsarvajñasarasvatīpūjyapādaśiṣyaśrīrā
macandrasarasvatīpūjyapādaśiṣyaśrīgaṅgādharendrasarasvatyākhyabhikṣoḥ śiṣyeṇa
śrīmadānandabodhendrasarasvatyākhyabhikṣuṇā viracite
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśe nirvāṇaprakaraṇasya pūrvārdhaṃ
saṃpūrṇam |
samāptamidaṃ nirvāṇaprakaraṇasya pūrvārdham |
śrīḥ |
yogavāsiṣṭhaḥ |
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsaṃvalitaḥ |
nirvāṇaprakaraṇasya uttarārdham 6 |
prathamaḥ sargaḥ 1
śrīrāma uvāca |
naiṣkarmyātkalpanātyāgāttanuḥ patati dehinaḥ |
kathametadato brahmansaṃbhavatyāśu jīvataḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
jīvataḥ kalpanātyāgo yujyate na tvajīvataḥ |
rūpamasya yathātattvaṃ śṛṇu śravaṇabhūṣaṇam
]

`v 3 [
ahaṃbhāvanamevāhuḥ kalpanaṃ kalpanāvidaḥ |
nabhorthabhāvanaṃ tasya saṃkalpatyāga ucyate
]

`v 4 [
padārtharasamevāhuḥ kalpanaṃ kalpanāvidaḥ |
nabhorthabhāvanaṃ tasya saṃkalpatyāga ucyate
]

`v 5 [
idaṃ vastviti saṃvegamāhuḥ kalpanamuttamāḥ |
nabhorthabhāvanaṃ tasya saṃkalpatyāga ucyate
]

`v 6 [
smaraṇaṃ viddhi saṃkalpaṃ śivamasmaraṇaṃ viduḥ |
tacca prāganubhūtaṃ ca nānubhūtaṃ ca bhāvyate
]

`v 7 [
anubhūtāṃ nānubhūtāṃ smṛtiṃ vismṛtya kāṣṭhavat |
sarvamevāśu vismṛtya gūḍhastiṣṭha mahāmate
]

`v 8 [
sarvāsmaraṇamātrātmā tiṣṭhāyāteṣu karmasu |
ardhasuptaśiśuspanda ivābhyastopapattiṣu
]

`v 9 [
niḥsaṃkalpapravāheṇa cakraṃ praspandate yathā |
spandasvakarmasvanaghapraksaṃskāravaśāttathā
]

`v 10 [
avidyamānacittastvaṃ sattvasaṃskāramāgataḥ |
pravāhapatiteṣveva spandasva sveṣu karmasu
]

`v 11 [
ūrdhvabāhurviraumyeṣa na ca kaścicchṛṇoti me |
asaṃkalpaḥ paraṃ śreyaḥ sa kimantarna bhāvyate
]

`v 12 [
aho mohasya māhātmyaṃ yadayaṃ sarvaduḥkhahā |
cintāmaṇirvicārākhyo hṛtstho'pi tyajyate janaiḥ
]

`v 13 [
avedanamasaṃkalpastanmayenaiva bhūyatām |
etāvatparamaṃ śreyaḥ svayamevānubhūyatām
]

`v 14 [
kila tūṣṇīṃ sthitenaiva tatpadaṃ prāpyate param |
paramaṃ yatra sāmrājyamapi rāma tṛṇāyate
]

`v 15 [
gamyadeśaikaniṣṭhasya yathā pānthasya pādayoḥ |
spando vigatasaṃkalpastathā spandasva karmasu
]

`v 16 [
sarvakarmaphalābhogamalaṃ vismṛtya suptavat |
pravāhapatite kārye spandasva gatavedanam
]

`v 17 [
spandasvākṛtasaṃkalpaṃ sukhaduḥkhānyabhāvayan |
pravāhapatite kārye ceṣṭitonmuktaśaṣpavat
]

`v 18 [
rasabhāvanamantaste mālaṃ bhavatu karmasu |
dāruyantramayasyeva parārthamiva kurvataḥ
]

`v 19 [
nīrasā eva te santu samastendriyasaṃvidaḥ |
ākāramātrasaṃlakṣyā hemantartau latā iva
]

`v 20 [
bodhārkapītarasayā spandan ṣaḍvargasattayā |
yantraspandopamastiṣṭha vallyeva śiśire drumaḥ
]

`v 21 [
cidāntararasānyeva pravṛttānyapi dhāraya |
svayatnenendriyāṇyāśu hemantartustarūniva
]

`v 22 [
sarasendriyavṛtteste kurvato'kurvatastathā |
saṃsārānarthasārtho'yaṃ na kadācana śāmyati
]

`v 23 [
niḥsaṃkalpamarujjvālāyantrāmbuspandavadyadi |
spandase tadanantāya śreyase parikalpase
]

`v 24 [
etadeva paraṃ dhairyaṃ janmajvaranivāraṇam |
yadavāsanamabhyastā nijakarmasu kartṛtā
]

`v 25 [
avāsanamasaṃkalpaṃ yathāprāptānuvṛttimān |
śanaiścakrabhramābhoga iva spandasva karmasu
]

`v 26 [
mā karmaphalabuddhirbhūrmā te saṅgo'stvakarmaṇi |
ubhayaṃ vā tyajaitattvamubhayaṃ vā samāśraya
]

`v 27 [
bahunātra kimuktena saṃkṣepādidamucyate |
saṃkalpanaṃ manobandhastadabhāvo vimuktatā
]

`v 28 [
neha kāryaṃ na vā'kāryamasti kiṃcinna kutracit |
sarvaṃ śivamajaṃ śāntamanantaṃ prāgvadāsyatām
]

`v 29 [
paśyankarmaṇyakarmatvamakarmaṇi ca karmatām |
yathābhūtārthacidrūpaḥ śāntamāsva yathāsukham
]

`v 30 [
avedanaṃ viduryogaṃ cittakṣayamakṛtrimam |
atyantaṃ tanmayo bhūtvā tathā tiṣṭha yathāsi bhoḥ
]

`v 31 [
same śānte śive sūkṣme dvaitaikyaparivarjite |
tate'nante pare śuddhe kiṃ kena kila khidyate
]

`v 32 [
nodetu tvayi saṃkalpo marubhūmāvivāṅkuraḥ |
icchā nodetu bhavati latikevopalodare
]

`v 33 [
avedanasya śāntasya jīvato vāpyajīvataḥ |
neha kiṃcitkṛtenārtho nākṛtenāpi kaścana
]

`v 34 [
yatkarmākarma śānte'ntaḥ śāśvatābhedarūpiṇi |
na karmaṇi ca karmāṇi na kartaryapi kartṛtā
]

`v 35 [
ahaṃmameti saṃvidanna duḥkhato vimucyase |
asaṃvidanvimucyase yadīpsitaṃ tadācara
]

`v 36 [
ahaṃ mameti nāstyalaṃ yadasti tacchivaṃ param |
parātparaṃ tvidaṃ śivādaśabdamartharūpakam
]

`v 37 [
yaddṛśyate jagadidaṃ khalu kiṃcidetaddhemno'ṅgadatvamiva bhāti na
vidyamānam |
asya kṣayaṃ viduravedanameva paścātsatyaṃ tadeva paramārthamathāvaśiṣṭam |
37 |
etadeva spaṣṭamāha - yaditi | kiṃcit itthamīdṛśaṃ ceti nirvacanaśabdaśūnyam |
etadbādhādhiṣṭhānaṃ tu atha tadabodhabādhānantaraṃ paścādavaśiṣṭamavedanaṃ
vedanāviṣayamevānubhavaniṣṭhāḥ satyaikarūpaṃ paramapuruṣārtharūpaṃ vidurityarthaḥ
]