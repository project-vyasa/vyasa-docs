`v 1 [
ekanavatitamaḥ sargaḥ 91
śrīvasiṣṭha uvāca |
tato'hamabhavaṃ tejastejodhāraṇayeddhayā |
candrārkatārakāgnyādivicitrāvayavānvitam
]

`v 2 [
nityaṃ sattvapradhānatvātprakāśākṛtirājagat |
sarvaṃ dṛśyamṛte sarvacauradhvāntapratāpayuk
]

`v 3 [
dīpādibhiḥ śanaiḥ snigdhairdaśāśatavihāribhiḥ |
pratyakṣīkṛtasarvārthaṃ pratigehaṃ surājavat
]

`v 4 [
lokāloke ca hṛṣitaiścandrārkādyaṃśuromabhiḥ |
paraprakāśaikaratairdūrotkṣiptāmbarāmbaram `note[dūrotkṣiptāsitāmbaram iti
pāṭhaḥ |]
]

`v 5 [
andhakārasya dainyasya samastaguṇanāśinaḥ |
dṛśyaṃ saddṛśyamaniśaṃ sarvasya guṇaśālinaḥ
]

`v 6 [
tamastamālaparaśuḥ paraśuddhikaraṃ padam |
suvarṇamaṇimāṇikyamuktādijanajīvitam
]

`v 7 [
śuklakṛṣṇāruṇādīnāṃ nityaṃ jyotsnāṅgaśāyinām |
putrāṇāmiva varṇānāṃ sarveṣāṃ dehadaḥ pitā
]

`v 8 [
ghanasneharasaṃ pṛthvyā rakṣitānalavedhanam |
gṛhaṃ prati ghanānandairvṛtadīpakaputrakam
]

`v 9 [
dṛṣṭaṃ pātālakeṣvīṣattamorūpeṣu `note[atra ṭīkākṛtāṃ īṣatpāvaka iti
pāṭho'bhipreta iti dṛśyate |] pāvakam |
ardhadṛṣṭaṃ rajorūpe bhūtale bhūtamālite
]

`v 10 [
tamorajaḥsattvabahaleṣu pātālādiṣu lokeṣu tejasaḥ prakāśatāratamyamāha -
dṛṣṭamiti sārdhena | īṣatpāvakaṃ īṣatprakāśakam | ardhadṛṣṭamardhaprakāśam | 9
|
sattvātmasu mahāsattvaṃ nityatvaṃ devasadmasu |
jagajjīrṇakuṭīdīpaḥ kūpombhastamasormahān
]

`v 11 [
digvadhūvimalādarśo niśānīhāramārutaḥ |
sattvaṃ candrārkavahnīnāṃ kuṅkumālepanaṃ divaḥ
]

`v 12 [
kedāraṃ dinasasyānāṃ tamocchūnāmanugrahaḥ |
nabhaḥkācabṛhatpātrakṣālanāmbu samullasat
]

`v 13 [
sattāpradatayārthānāṃ prakāśakatayāpi ca |
cinmātraparamārthasya sahodara ivānujaḥ
]

`v 14 [
kriyākamalinībhānurbhūtalodarajīvitam |
rūpālokamanaskāracamatkāraściteryathā
]

`v 15 [
nabhastalagatāsaṃkhyanakṣatramaṇimālitaḥ |
dinartuvatsarābṛṃhyavāḍavāgnyādiphenilaḥ
]

`v 16 [
candrārkāditaraṅgāntarajaḍaṃ paṅkilo mahān |
bṛhadbrahmāṇḍakhātastho nityamekārṇavo'kṣayaḥ
]

`v 17 [
hemādiṣu suvarṇatvaṃ narādiṣu purākramaḥ |
kācakacyaṃ ca ratnādau varṣādiṣvavabhāsanam
]

`v 18 [
jyotsnā mukhendubimbeṣu pakṣmalekṣaṇalakṣmasu |
sravatsnehāmṛtāpūro hāsasauhārdabhāsanam
]

`v 19 [
kapolabāhunetrākṣibhrūkarālakalāsakaḥ |
nijo'jeyatayā jāto vilāsaḥ kāminījane
]

`v 20 [
tṛṇīkṛtatribhuvanacapeṭāsphoṭitadviṣām |
śiraḥsu vajrīkaraṇaṃ vīryaṃ siṃhādicetasi
]

`v 21 [
kaṭukaṅkaṭakuṭṭākakhaḍgasaṃghaṭṭaṭāṃkṛtaiḥ |
paṭuspuṭāṭoparaṭi bhaṭeṣvaṭanamudbhaṭam
]

`v 22 [
deveṣu dānavāritvaṃ surāritvaṃ surāriṣu |
sarvabhūteṣu sojastvamunnāmaḥ sthāvarādiṣu
]

`v 23 [
atha te maruvadbhāsvāṃstatrāhamanubhūtavān |
jagadākāśakośeṣu teṣu tāmarasekṣaṇa
]

`v 24 [
digantadaśanistīrṇaiḥ karajālairjagatkhagam |
gṛhṇadadryaṅgamarkatvaṃ grāmavaddṛṣṭabhūtalam
]

`v 25 [
kāmotpale kośacakraṃ vāḍavaṃ timirārṇave |
brahmāṇḍasadane dīpaṃ vṛkṣaṃ dinaphalāvaleḥ
]

`v 26 [
rasāyanahradākāramindutvaṃ vadanaṃ divaḥ |
niśāniśācarīhāsaṃ vikāsaṃ rajanīviśām
]

`v 27 [
jagallāvaṇyalakṣmīṇāṃ sarvāsāmupamāspadam |
rajanīrohiṇīnārīkairavāṇāṃ paraṃ priyam
]

`v 28 [
netravṛndasya vaktrasya dyulatāpuṣpajālakam |
svargaughamaśakavyūhaṃ tārakāpaṭalaṃ mṛdu
]

`v 29 [
vaṇiṅmātre vaṇigghastatulātolanadolitam |
ratnatvaṃ jalakallolahastāndolanamabdhibhiḥ
]

`v 30 [
abdhā'bdhau śapharāvartamabdhā gomañjarīgaṇaḥ |
abdādau dāvadahanaṃ vaidyutaṃ dyotanaṃ tanau
]

`v 31 [
dārudāraṇadurvāradīptaṃ jvalanamātatam |
yajñāgnidāhakalyāṇaṃ visphoṭakaṭhināravam
]

`v 32 [
kacatkāñcanamāṇikyamuktāmaṇimayaṃ mahaḥ |
tapastāṃ nītamākṣipya pāṇḍityamiva pāmaraiḥ
]

`v 33 [
niśrāntaṃ stanaśṛṅgeṣu muktāhāratayā tayā |
asuroragagandharvanaranāyakayoṣitām
]

`v 34 [
pādāhatiṃ gataṃ mārge tilakatvaṃ vadhūmukhe |
khadyotena mayā labdhaṃ paśyāvasthāsu cāpalam
]

`v 35 [
kvacidvidyuttayā teṣu śapharyā cārṇaveṣviva |
khastheṣu vikṛtaṃ cāru vāryāvartavirāviṣu
]

`v 36 [
kvaciddīpatayānīya kalikākomalāṅgayā |
antaḥpureṣu kāntānāṃn suratālokanaṃ kṛtam
]

`v 37 [
kvacitkajjalajālasya jvālākanakadākṛte |
khedinā ghanakūrmābhaṃ saṅgenaiva svakoṭare
]

`v 38 [
kalpānteṣu kvacitsarvajagadbhramaghanaśramāt |
khe kajjalāsite līnaṃ rudrebha iva vidyutā
]

`v 39 [
kvacidākalpamāpīya vāḍavāgnitayā jalam |
jagatsu gaganeṣvante nanṛte jalarāśiṣu
]

`v 40 [
gaganeṣu śūnyatāṃ prāpteṣu jalarāśiṣu mayā ante gagane nanṛte |
gātravikṣepārthasya nṛterdhātvarthopasaṃgṛhītakarmakatvenākarmakatvādbhāve liṭ |
39 |
kvacidulmukadantena mayā jvālābhujātmanā |
viloladhūmāvartograkuntalenākulaujasā
]

`v 41 [
purapalvaladāheṣu `note[pallava pallalaityapi pāṭhau |] kavalīkṛtajantunā |
kṛtāḥ kṛtāṣṭa kāṣṭhādipadārthāḥ khādanocitāḥ
]

`v 42 [
hatena śastrapāṣāṇairayaḥpiṇḍādivāsinā |
hantṛdāhārthamudgīrṇāḥ kaṇakopalatāḥ kvacit
]

`v 43 [
kvacinmahāśilākośe pāṣāṇamaṇinā mayā |
samastabhūtādṛśyena sthitaṃ yugaśatānyapi
]

`v 44 [
śrīrāma uvāca |
mune tasyāmavasthāyāmanubhūtaṃ tvayā sukham |
uta duḥkhamiti brūhi bodhāya mama mānada
]

`v 45 [
śrīvasiṣṭha uvāca |
yathā yāti naraḥ supto jaḍatāṃ cetano'pi san |
cidvyoma gaccheddṛśyatvaṃ tathā jāḍyaṃ pracetati
]

`v 46 [
ātmānaṃ cetati brahma pṛthvyādīva yadā tadā |
suptaṃ jaḍamivāste'ntaḥ syādasya na tadanyathā
]

`v 47 [
vastutastasya khorvyādi nāsadrūpaṃ na sanmayam |
draṣṭṭadṛśyamivābhāti brahma caitatsamaṃ sthitam
]

`v 48 [
etatsatyaparijñānaṃn yasyotpannamakhaṇḍitam |
na tasya pañcabhūtāni na dṛśyadraṣṭṭavibhramaḥ
]

`v 49 [
tadā mayaivaṃ śuddhena tatkṛtaṃ brahmarūpiṇā |
brahmarūpādṛte kiṃcidetatkarturna yujyate
]

`v 50 [
yadā sarvamidaṃ dṛśyaṃ jātaṃ brahma nirāmayam |
tadā brahmapadasthena mayātmaivaivamīkṣitaḥ
]

`v 51 [
yadā punarahaṃ pañcabhūtānītyeva bhāsayan |
bhavāmi jaḍa evāhaṃ tadā cetāmi kiṃ kila
]

`v 52 [
supto'smīti dṛḍhaṃ bhāvaṃ buddhavāṃścetano'pi san |
naidramevaityalaṃ jāḍyaṃ lasaccetati kiṃcana
]

`v 53 [
yastu jñānaprabuddhātmā dehastasyādhibhautikaḥ |
śāmyatyudeti vimalo bodhātmaivātivāhitaḥ
]

`v 54 [
ātivāhikadehena tena bodhātmanāṇunā |
bṛhatā vā yathākāmaṃ nirvāṇātmāvatiṣṭhate
]

`v 55 [
bodhadehena hṛdayaṃ śilānāmapyabhedinām `note[puṃstvamārṣam | abhedi neti
vā pāṭhastatrābhedi neti cchedaḥ | nā puruṣaḥ | abhedīti
hṛdayaviśeṣaṇamityanumīyate |] |
praviśyāśu viniryāti yāti pātālamambaram
]

`v 56 [
tasmānmayā purā rāma bodhadehena tattadā |
tathā kṛtamanantena cinmayavyomarūpiṇā
]

`v 57 [
vajrapāṣāṇapātālanabhombaragamāgamān |
kurvatastādṛśasyāśu na vighna upajāyate
]

`v 58 [
bodhamātraśarīreṇa yāvadāste jaḍeṣvasau |
padārtheṣu tathābhūtastāvattatrāvatiṣṭhate
]

`v 59 [
svecchayaiva calitvātha tato'nyatra prayāti cet |
tattatraiva sthitiṃ yāti tattathaivāgatiryathā
]

`v 60 [
bodhamātraṃ vidurdehamātivāhikamavyayam |
idānīṃ tvaṃ tameveha budho'nubhavasi svayam
]

`v 61 [
cinmātravyomarūpo'smītyarkādāviti bodhataḥ |
ātmaivāstamupānītaḥ sannevāsannivātmanā
]

`v 62 [
sthitaṃ svapnādijagati tamasevāsateva ca |
āvṛteneva vānyāsāmalabhyena satā dṛśam
]

`v 63 [
taraṅgalekhayāṅgārasaritaḥ svāṅgalagnayā |
manorājyaśriyevāśuk protpannastadvadehayā
]

`v 64 [
kajjalālikayā vahnivipinaḥ puṣpaśobhayā |
phullasthalāmbujākāraṃ kiṃśukāśokarūpayā
]

`v 65 [
vitatārambhayāpyuccairjvālājvalatayeddhayā |
upotthāyāṅga galitaṃ khalalakṣmyeva lolayā
]

`v 66 [
tejastayāpi paramāṇukaṇodare'pi dṛṣṭetthamevamiha rāma mayā jagacchrīḥ |
anyā ca sā na ca cidambarataḥ parasmātsvapne purācalagaṇo'tra nnidarśanaṃ vaḥ |
66 |
he rāma mayā tejastayāpi paramāṇukaṇānāmudare'pi pratyekaṃ itthamevaṃ
jagacchrīrdṛṣṭā sā jagacchrīrbhavadādiprasiddhā ca jagachrīḥ parasmāccidambarataḥ
anyā na | atrāsminnarthe vaḥ yuṣmākaṃ svapne prasiddhaḥ puragaṇaḥ acalagaṇaśca
nidarśanaṃ dṛṣṭānta ityarthaḥ
]