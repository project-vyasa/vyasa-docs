`v 1 [
saptanavatyadhikaśatatamaḥ sargaḥ 197
śrīrāma uvāca |
tathā kuru muniśreṣṭha yathā vaivadhikakramam |
asaṃdehamimaṃ samyagavagacchāmi mānada
]

`v 2 [
śrīvasiṣṭha uvāca |
ye te vaivadhikā rāma ta ete mānavā bhuvi |
teṣāṃ dāridryaduḥkhaṃ yattadajñānaṃ mahātapaḥ
]

`v 3 [
yattanmahāvanaṃ proktaṃ guruśāstrakramādi tat |
yadudyatāste grāsārthaṃ janā bhogārthino hi te
]

`v 4 [
bhogaughāḥ siddhimāyāntu mama niṣkṛpaṇo janaḥ |
anapekṣitakāryārthaḥ śāstrādau saṃpravartate
]

`v 5 [
bhogārthaṃ saṃpravṛtto'pi prāpnotyabhyāsataḥ kramāt |
jantuścintitamevādyapadaṃ paravaśo'pi san
]

`v 6 [
dārvarthamudyato bhāvī yathā saṃprāptavānmaṇim |
bhogārthamāttaśāstro'yaṃ tathāpnoti janaḥ padam
]

`v 7 [
kiṃ syācchāstravicārābhyāmiti saṃdehalīlayā |
kaścitpravartate paścādāpnoti padamuttamam
]

`v 8 [
adṛṣṭottamatattvārthaḥ śāstrādau saṃpravartate |
saṃdehenārthabhogārthaṃ janaḥ prāpnoti tatpadam
]

`v 9 [
anyathā saṃpravartante śāstrairvāsanayā janāḥ |
anyadāsādayantyādyaṃ maṇiṃ vaivadhikā iva
]

`v 10 [
paropakāre'virataṃ svabhāvena pravartate |
yaḥ sa sādhuriti proktaḥ pramāṇaṃ tvasya ceṣṭitam
]

`v 11 [
sādhvācāravaśālloko bhogasaṃprāptiśaṅkayā |
saṃdehaścāpyatattvajñaḥ śāstrādau saṃpravartate
]

`v 12 [
bhogārthaṃ saṃpravṛtto'sau bhogamokṣāvubhāvapi |
tasmātprāpnoti dārvarthī vanāccintāmaṇiṃ yathā
]

`v 13 [
keciccandanadārūṇi keciccintāmaṇiṃ maṇim |
kecitsāmānyaratnāni prāpnuvanti yathā vanāt
]

`v 14 [
kecitkāmaṃ kecidarthaṃ keciddharmatrayaṃ tu vā |
kecinmokṣamaśeṣaṃ ca labhante śāstratastathā
]

`v 15 [
vargatrayopadeśo hi śāstrādiṣvasti rāghava |
brahmaprāptistvavācyatvānnāsti tacchāsaneṣvapi
]

`v 16 [
kevalaṃ sarvavākyārthairdhvanyamānāvagamyate |
kālaśrīḥ prasaveneva svayaṃ svānubhavena sā
]

`v 17 [
sarvārthātigataṃ śāstre vidyate brahmavedanam |
sarvagātigataṃ svacchaṃ lāvaṇyamiva yoṣiti
]

`v 18 [
na śāstrānna gurorvākyānna dānānneśvarārcanāt |
eṣa sarvapadātīto bodhaḥ saṃprāpyate paraḥ
]

`v 19 [
etānyakaraṇānyeva kāraṇatvaṃ gatānyalam |
paramātmaikaviśrāntau yathā rāghava tacchṛṇu
]

`v 20 [
śāstrādabhyāsayogena cittaṃ yātaṃ viśuddhatām |
anicchadevamevāśu padaṃ paśyati pāvanam
]

`v 21 [
etacchāstrādavidyāyāḥ sāttviko bhāga ucyate |
tāmasaḥ sāttvikenāsyābhāgenāyāti saṃkṣayam
]

`v 22 [
nūnaṃ malaṃ pradhānena kṣālayacchāstrarūpiṇā |
puruṣaḥ śuddhatāmeti paramāṃ vastuśaktitaḥ
]

`v 23 [
anicchayoreva yathā saptasaptisamudrayoḥ |
prāgadṛśyaṃ tṛtīyatvaṃ `note[tṛtīyaṃ tu svabhāvavaśata iti
pāṭhaṣṭīkānuguṇaḥ |] svabhāvavaśataḥ svataḥ
]

`v 24 [
svasaṃnidhānamātreṇa viditapratibhāsanam |
sadasanmayamābhogi pratibimbaṃ pravartate
]

`v 25 [
mumukṣuśāstrayorevaṃ mithaḥ saṃbandhamātrataḥ |
sarvasaṃvitpadātītamātmajñānaṃ pravartate
]

`v 26 [
anayoḥ prekṣaṇaddehe viveko jāyate yathā |
tathā svabhāvataḥ śāstravivekājjñeyavedanam
]

`v 27 [
loṣṭena loṣṭaṃ salile kṣālayanbālako yathā |
kṣayeṇa loṣṭayorhastanairmalyaṃ labhate param
]

`v 28 [
tathā śāstravikalpaughairvikalpāṃścetanādbudhaḥ |
kṣālayansvavicāreṇa paramāṃ yāti śuddhatām
]

`v 29 [
mahāvākyārthaniṣyandaṃ svātmajñānamavāpyate |
śāstrāderikṣurasataḥ svādviva svānubhūtitaḥ
]

`v 30 [
prabhābhittyoḥ samāsaṅgādyathā''loko'nubhūyate |
śrutaśrutavatoḥ saṅgādātmajñānaṃ tathā bhavet
]

`v 31 [
trivargamātrasiddhyai yanna mokṣāya ca tacchrutam |
vipulaśrutacarcāsu tucchamaśrutameva tat
]

`v 32 [
tacchrutaṃ yatkila jñaptyai sā jñaptiḥ samatā yayā |
tatsāmyaṃ yatra sauṣuptī sthitirjāgrati jāyate
]

`v 33 [
evaṃ hi sarvametattacchāstrādeḥ samavāpyate |
tasmātsarvaprayatnena śāstrādyabhyāsamāharet
]

`v 34 [
śāstrārthabhāvanavaśena girā gurūṇāṃ satsaṅgamena niyamena śamena rāma |
tatprāpyate sakalaviśvapadādatītaṃ sarveśvaraṃ paramamādyamanādiśarma | 34
|
he rāma tatsakalaviśvapadādbrahmalokāntaiśvaryasukhādapyatītamatiśayitaṃ pāvanaṃ
sarveśvaraṃ mokṣākhyamanādisukhaṃ gurūṇāṃ girā śāstrārthabodhanavaśenaiva
prāpyate tacca satsaṃgamādinetyarthaḥ
]