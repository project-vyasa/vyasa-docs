`v 1 [
pañcasaptatitamaḥ sargaḥ 75
śrīvasiṣṭha uvāca |
athāgrasthabrahmaloko brahmaṇi dhyānaśālini |
nikṣiptākṣaḥ śanairdikṣu dṛṣṭavānahamagrataḥ
]

`v 2 [
dvitīyamarkaṃ madhyāhne paścādabhyuditaṃ sphuṭam |
digdāhamiva digvaktre vanadāhamivācale
]

`v 3 [
vahnilokamiva vyomni vaḍavāgnimivārṇave |
tato'paśyamahaṃ dīptaṃ sūryaṃn nairṛtadiṅmukhe
]

`v 4 [
sūryaṃ yāmye kakubbhāge sūryamagnikakubmukhe |
sūryamaindrakakubbhāge sūryamīśānadiṅmukhe
]

`v 5 [
kuberakakubhi sūryaṃ sūryaṃn vāyavyadiktaṭe |
sūryaṃ varuṇadigbhāge tena vismayavānaham
]

`v 6 [
yāvadvicārayāmyāśu vidhivaidhuryamākulam |
udabhūdbhūtalāttāvadarka aurva ivārṇavāt
]

`v 7 [
ekādaśe'khilārkāṇāṃ pratibimbamivotthitam |
udabhūttrayamarkāṇāmantare diggaṇāmbare
]

`v 8 [
taddhi raudraṃ vapustatra tanmadhye locanatrayam |
taddvādaśaparīmāṇaṃ dīptaṃ vṛndaṃ vivasvatām
]

`v 9 [
tatra tasminnarke tanmadhye raudravapurmadhye locanatrayaṃ tadraudraṃ vapureva
dvādaśādityākāraparimāṇaṃ vivasvatāṃ vṛndaṃ bhūtvā dadāheti pareṇānvayaḥ | 8
|
sarvadikkaṃ dadāhoccaiḥ śuṣkaṃ vanamivānalaḥ |
athodabhūjjagatkhaṇḍaśoṣaṇagrīṣmavāsaraḥ
]

`v 10 [
anagnragnidāho drāgadṛśyolmukagulmakaḥ |
anagnināgnidāhena tena tāmarasekṣaṇa
]

`v 11 [
aṅgāni dāvadagdhāni khinnānīva mamābhavan |
pradeśaṃ tamatha tyaktvā dūramārūḍhavānaham
]

`v 12 [
dṛḍhahastatalāghātahatakandukavannabhaḥ |
apaśyaṃ gaganastho'hamuditaṃ caṇḍatejasam
]

`v 13 [
tapantaṃ dvādaśādityagaṇaṃ dikṣu daśasvapi |
bṛhattatra satārāvajvāleva bhagaṇaṃ calam
]

`v 14 [
mahākuhakuhāśabdaṃ kvathatsaptābdhiḍambaram |
sajvālolmukanīrandhralokāntarapurāntaram
]

`v 15 [
ita ūrdhva sārdhadvādaśaślokeṣu sthitāni sarvāṇi dvitīyāntapadāni
prastutadvādaśādityagaṇaviśeṣaṇatvena yojyāni | kuhakuheti kvathanaśabdānukaraṇam |
14 |
jvālāghanapaṭāṭopasindurīkṛtaparvatam |
dīpyamānamahāgārasthiravidyutkakutpaṭam
]

`v 16 [
sphuratkaṭakaṭāṭopacaṭatpattanamaṇḍalam |
vidadhadbhūtalodbhūtadhūmadaṇḍaiḥ śilāghanaiḥ
]

`v 17 [
kācastambhasahasrāḍhyaṃ bhuvanasthānamaṇḍapam |
kvathadbhūtamahābhūtatārākrandātighargharam
]

`v 18 [
bhūtalokapurāpātasphuṭaccaṭacaṭodbhaṭam |
tārāviśaraṇodghātaghṛṣṭaratnadharātalam
]

`v 19 [
sarvasthalālayacaladdahyamānajanavrajam |
kṣīṇākrandakvathadbhūtagaṇadurvāsadiktaṭam
]

`v 20 [
uttaptāmbūdarākhinnajalecaramahārṇavam |
sarvavikkānalaploṣakṣīṇākrandapurāntaram
]

`v 21 [
vidaladdagdhadigdantidantottambhitabhūdharam |
dharādharadīrandhradhūmamaṇḍalakuṇḍalam
]

`v 22 [
patatparvataniṣpiṣṭapluṣṭapattanamaṇḍalam |
pacatpacapacāśabdaśabditādrīndrakuñjaram
]

`v 23 [
tāpataptonnamadbhūtajvaritārṇavaparvatam |
hṛdayasphoṭaniḥsārapatadvidyādharāṅganam
]

`v 24 [
ākrandarodanaśrāntamūrdhaniḥsaraṇāmaram |
nāgalokajvalajjvālāpātālottaptabhūtalam
]

`v 25 [
śuṣkārṇavasadāpakvavivartograjalecaram |
aurveṇābindhanābhāvātproḍḍīyeva sahasradhā
]

`v 26 [
gatena nṛtyatotthāya gṛhītagaganāṅganam |
athodabhūjjvalajjvālākiṃśukāṃśukaśobhitaḥ
]

`v 27 [
tāṇḍavāyeva kalpāgnistaralolmukamālyavān |
tāraṃ paṭapaṭāṭopī raṭadbhaṭa ivodbhaṭaḥ
]

`v 28 [
jvālodbhujo dhūmakaco jagajjīrṇakuṭīnaṭaḥ |
jajvalurvanajālāni purāṇi nagarāṇi ca
]

`v 29 [
maṇḍaladvīpadurgāṇi jaṅgalāni sthalāni ca |
sarvakhāni mahākāśamāśā daśa divaḥ śiraḥ
]

`v 30 [
śvabhrarūpāraghaṭṭāṭṭapaṭṭanodāradiktaṭaḥ |
śṛṅgāṇi siddhavṛndāni girayaḥ sāgarārṇavāḥ
]

`v 31 [
saraḥ sarasyaḥ sarito devāsuranaroragāḥ |
āśāḥ śanaśanāśabdaiḥ puruṣaiśca śivārciṣām
]

`v 32 [
āsankṣveḍākurākṣasyo jvālājālojjvalordhvajāḥ |
bhamadbhamiti bhāṃkārairbhīṣaṇairbhūribhasmabhiḥ
]

`v 33 [
jvālāḥ śvabhrādribhūmīnāṃ guhābhyaḥ pariniryayuḥ |
jvālodarasthā aruṇāḥ samastā bhūtajātayaḥ
]

`v 34 [
sthalapadmodarālīnāmājahruḥ śriyamaśriyaḥ |
sadyo niḥsṛtaraktābhaiḥ sindūrāmbhodasundaraiḥ
]

`v 35 [
dhagaddhagiti gāyadbhirjvālājālairjagadgataiḥ |
āsīdraktāṃśukaiḥ kīrṇaṃ saṃdhyābhrairiva vā nabhaḥ
]

`v 36 [
utphullakiṃśukavanairuḍḍīnairiva vā''vṛtam |
aurveṇa cāvṛtā āsanphullāśokavanā iva
]

`v 37 [
iva sthalābjavalitā rāvirā iva cārṇavāḥ |
nānāvarṇajvalajjvālādhūmavinyāsabandhavān
]

`v 38 [
rūḍhaṃ vahnimivādhātuṃ citrasaudhalatāśrayam |
ananta iva vinyāsa vanayauvanapāvakaḥ
]

`v 39 [
udayāstamayādibhyo vindhyo vidhuratāmagāt |
aṅgārakalpaviṭapairjvālāvanavivalganaiḥ
]

`v 40 [
śanairīṣadiva kṣubdhaiḥ sahyo'sahyatvamāyayau |
madhyamadhyakacatkārṣṇyabhramaddhūmālimālitam
]

`v 41 [
valajjvālābjamalinaṃ dṛṣṭaṃ sara ivāmbaram |
khe'drīṇāṃ śikhare vyomni śikhāśikharaśekharāḥ
]

`v 42 [
śikhāśikharaśekharāḥ jvālāgrottaṃsāḥ | keturdhūmāvarto dhūmaketvākhya
utpātaviśeṣaśca kuntalasthānīyo yāsāṃ tathāvidhā nāśā mṛtyavastallakṣaṇā
nartakyaḥ adrīṇāṃ khe vivarākāśe śikhare śṛṅgadeśe vyomni
adryādiśūnyaśuddhākāśapradeśe ca nīrasāḥ karuṇādirasaśūnyāḥ satyo nanṛtuḥ |
41 |
nanṛturnīrasā naśanartakyaḥ ketukuntalāḥ |
talāhitānalajvālā brahmāṇḍordhvakapāṭabhūḥ
]

`v 43 [
tarjanaprotpatadbhūtadhānaughā bhrāṣṭrabhūmikā |
kvaṇacchreṇī mṛjjalāgnirnānāvarṇānanāruṇā
]

`v 44 [
hṛtprakoṣṭhe jagallakṣmyāḥ sauvarṇīvābhavattadā |
śailāścaṭacaṭāsphoṭairvṛkṣāḥ kaṭakaṭāravaiḥ
]

`v 45 [
deśā halahalollāsairalaṃ vidalanaṃ yayuḥ |
abdhayaḥ kvathitākāraḥ phenilollāsamāṃsalāḥ
]

`v 46 [
vīcīkaratalāghātāṃścakrurarkamukhe mukhe |
anyonyavellitollolabhūtalākāraparvatam
]

`v 47 [
jahrurvīcīkarairdehe jaḍāḥ `note[prāptamiti śeṣaḥ | dehe prāptaṃ
parvatamityanvayaḥ |] prakupitā iva |
āśākāśāśināmeṣāṃ guhāguhaguhāravān
]

`v 48 [
papāṭha śabda āgneyo jvālātaṭataṭodbhavaḥ |
lokapālapurāpātataptāṅgārādribhittayaḥ
]

`v 49 [
diśo daśāpi vaivaśyaṃ yayurunmattavṛttayaḥ |
kāñcanadravasādrīndradrumāgāraguhāgṛhaḥ
]

`v 50 [
śanaiścārvākṛtirmerurāsīddhima ivātape |
kṣaṇenaivānalāttasmāddhimavāñjatuvaddrutaḥ
]

`v 51 [
sarvāntaḥśītalaḥ śuddho durjanādiva sajjanaḥ |
tasyāmapi daśāyāṃ tu malayo'malasaurabhaḥ
]

`v 52 [
āsīttyajatyudārātmā na nāśe'pyuttamaṃ guṇam |
naśyannapi mahān hlādaṃ na khedaṃ saṃprayacchati
]

`v 53 [
candanaṃ dagdhamapyāsīdānandāyaiva jīvatām |
na kadācana saṃyāti vastūttamamavastutām
]

`v 54 [
pralayānalanirdagdhamapi hema na naṣṭavat |
dve hemanabhasī tasminna naṣṭe pralayānale
]

`v 55 [
tayoreva vapuḥ ślāghyaṃ sarvanāśe'pyanāśayoḥ |
nabho vibhutayā'nāśi hemākṛṣṭatayākṣayam
]

`v 56 [
sattvamekaṃ sukhaṃ manye na rajo na ca vā tamaḥ |
caladuccavanānīva vikīrnāṅgāravarṣaṇaḥ
]

`v 57 [
dagdhābdādrirmahādhūmajvālo'bhūdvahnivāridaḥ |
rasavismaraṇārtānāṃ śūnyānāṃ sphāradehinām
]

`v 58 [
śuṣkāṇāṃ vyomaviṭapipatrāṇāṃ pātrarūpiṇām |
vāridānāṃ savārīṇāṃ dagdhānāṃ pralayārciṣā
]

`v 59 [
jñasyevāṅga na doṣāṇāṃ dṛṣṭaṃ bhasmāpi na kvacit |
na laṅghayati kailāsaṃ yāvadullasito'nalaḥ
]

`v 60 [
tāvattaṃ kalpakupito rudro netrāgninādahat |
dāhasphuṭaddrumasthūlaśilācaṭacaṭāravāḥ
]

`v 61 [
lakuṭopalaloṣṭaughairayudhyanteva bhūbhṛtaḥ |
jvālāghanaghaṭāṭopasāvataṃsacalāntimāḥ
]

`v 62 [
babhūvurvyomavikasatsthūlapadmavanā iva |
sargaḥ kadācidevāsīdityagātsmaraṇīyatām
]

`v 63 [
kalpāntaḥ smārayanmūrkhānagādasmaraṇīyatām |
tāpopatāpaparamāḥ paramāraṇatatparāḥ |
vahnayo'pahnavaṃ cakrurjagatāmasatāmiva
]

`v 64 [
vavuraśaninipātapīḍitāṅgā kacadanalolmukagulmamaṇḍalābhāḥ |
pralayasamayavāyavo'nalāntāddaladamarāvalayo laye lihantaḥ
]

`v 65 [
vyālolasphuṭadānaladrumavanaprodbhūtabhasmoṣmaṇā
dattābhrābhramadulmukāhativahatsāṅgāragaurārciṣaḥ |
bhraśyatpāvakaśṛṅgamadhyavilasajjvālāvalīśyāmalā
niḥśeṣāgninikāśasustavajavā vegena vātā vavuḥ
]