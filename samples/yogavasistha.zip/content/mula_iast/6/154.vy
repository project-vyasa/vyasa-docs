`v 1 [
catuḥpañcāśadadhikaśatatamaḥ sargaḥ 154
muniruvāca |
iti nirṇīya dṛśye'sminsthito'smi vigatajvaraḥ |
avītarāgo nirāśaṅko nirvāṇo nirahaṃkṛtiḥ
]

`v 2 [
nirādhāro nirādheyo nirmāno nirupāśrayaḥ |
svabhāvasthaḥ svayaṃ śāntaḥ sargātmā sarvathoditaḥ
]

`v 3 [
yathāprāptasya kartāsmi na kartāsmi kadācana |
svayameva hi yo vyoma kartṛtā tasya kīdṛśī
]

`v 4 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
ityekātma nabhaḥ sarvaṃ bhūtajālaikacidvapuḥ
]

`v 5 [
śāmyāmi parinirvāmi sukhamāse ca kevalam |
na vidhipratiṣedhau me na me bāhyaṃ na me'ntaram
]

`v 6 [
iti me tiṣṭhata iha yathāsaṃsthānasaṃsthiteḥ |
adyāyaṃ tvamanuprāptaḥ kākatālīyavatpuraḥ
]

`v 7 [
īt te sarvamākhyātaṃ yathā svapno yathā vayam |
yathā jagadyathā ca tvaṃ yathā dṛśyamidaṃ tathā
]

`v 8 [
evamanuprāptāya pṛcchate te iti yathāvarṇitaprakāraṃ sarvam | tadeva prapañcayati ##-
tvaṃ ca yādṛgdṛśyamidaṃ yathā dṛśyamidaṃ puraḥ |
yathā bhāvā yathā brahma yathemā janatāḥ puraḥ
]

`v 9 [
etadbuddhvā bhavāñchānto mithyā lubdhaka lubdhaka |
śāntaivaivamiyaṃ sattā cinmātravyomarūpiṇī
]

`v 10 [
svayamābhāti nirvāṇā naiva vābhāti kiṃcana |
lubdhaka uvāca |
evaṃ cettadahaṃ tvaṃ ca sarve vā vibudhādayaḥ
]

`v 11 [
sarva eva mithaḥ svapnapuruṣāḥ sadasanmayāḥ |
muniruvāca |
evametadidaṃ sarvamanyonyaṃ svapnavatsthitam
]

`v 12 [
anyonyamātmani tathā sadasaccānubhūyate |
dṛśyaṃ yena yathā buddhaṃ tathā tenānubhūyate
]

`v 13 [
nānaikaṃ vastvato'nekaṃ na sannāsanna madhyagam |
jāgrati svapnanagaramiva vedanamātrakam
]

`v 14 [
adṛṣṭapūrvadūrasthadṛśyamānapuropamam |
iti te sarvamākhyātaṃ bodhito'si nirantaram
]

`v 15 [
svayaṃ prājño'si jānāsi yathecchasi tathā kuru |
evaṃ prabodhitasyāpi tava vyādha mate matiḥ
]

`v 16 [
kṣaṇaṃ prabodhaviśrāntā na viśrāntā pare pade |
nābhyāsena vinā bodha eṣa yāti manohṛdi
]

`v 17 [
parāṃ pariṇatiṃ prājña dāruṇīvāmbudhāraṇe |
abhyāsādbodhaviśrāntau guruśāstraikasevanāt |
dvaitādvaitadṛśoḥ śāntyā nirvāṇaṃ cittamucyate
]

`v 18 [
nirmānamohā jitasaṅgadoṣā adhyātmanityā vinivṛttakāmāḥ |
dvandvairvimuktāḥ sukhaduḥkhasaṃjñairgacchantyamūḍhāḥ padamavyayaṃ tat |
18 |
ukte'rthe bhagavadvacanasaṃmatiṃ darśayati - nirmāneti | antarnirmānamohāḥ |
bahirjitasaṅgadoṣāḥ | antarnirmānamohāḥ | bahirjitasaṅgadoṣāḥ |
antarbahiścādhyātmanityāḥ | sarvataḥ pūrṇānandātmalābhādvinivṛttakāmāḥ |
sukhaduḥkhayoḥ samyagjñānaṃ saṃjñā yebhyastathāvidhaiḥ priyādidvandvairvimuktā
amūḍhāstattvavidastadviṣṇoḥ paramaṃ padaṃ nirvāṇākhyaṃ gacchanti |
anubhavantītyarthaḥ
]