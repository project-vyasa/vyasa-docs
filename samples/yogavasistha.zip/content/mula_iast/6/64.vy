`v 1 [
catuḥṣaṣṭitamaḥ sargaḥ 64
śrīvasiṣṭha uvāca |
tatastatkuvalollāsimālatīmālyalocanā `note[tataḥ kuvalayollāsi iti pāṭhaḥ suvacaḥ
kuvalayaparyāyaḥ kuvalaśabdo'pyastīti yathāvasthito'pi saṃgacchata eva |] |
lalanā lalitālokya līlayā''lapitā mayā
]

`v 2 [
ka tvaṃ kamalagarbhābhe kimarthaṃ māmupāgatā |
kasyāsi kiṃ prārthayase kva gatāsi kimāspadā
]

`v 3 [
vidyādharyuvāca |
mune śṛṇu yathāvattvamātmodantaṃ vadāmyaham |
praṣṭumarhasi visrabdhamārtāṃ karuṇayārthinīm
]

`v 4 [
paramākāśakośasya kasmiṃścitkoṇakoṭare |
yuṣmākaṃ saṃsthitaṃ kiṃcididaṃ tāvajjagadgṛham
]

`v 5 [
pātālabhūtalasvargā ihāpavarakāstrayaḥ |
kalpanaikā kumāryatra kṛtā dhātṛtvamāyayā
]

`v 6 [
tatra dvīpaiḥ samudraiśca valitaṃ valayairiva |
pāṭalotthaṃ jagallakṣmyāḥ prakoṣṭhamiva bhūtalam
]

`v 7 [
ante dvīpasamudrāṇāṃ sarvadikkamavasthitā |
yojanānāṃ sahasrāṇi daśa hemamayī mahī
]

`v 8 [
svayaṃprakāśasaṃkalpaphaladāmbaranirmalā |
cintāmaṇimayī svacchā svacchāyājitaviṣṭapā
]

`v 9 [
sāpsaromarasiddhānāṃ līlāviharaṇāvaniḥ |
saṃkalpamātrasaṃpannasarvasaṃbhogasundarī
]

`v 10 [
sāpsarasāmamarāṇāṃ siddhānāṃ ca līlāviharaṇocitā avaniḥ | seti pṛthakpadaṃ vā | 9
|
ante tasyā bhuvaḥ śailo lokāloko'sti viśrutaḥ |
bhūpīṭhasya prakoṣṭhasya valayāvalanāṃ dadhat
]

`v 11 [
kvacinnityaṃ tamovyāpto mūḍhabuddherivāśayaḥ |
kvacinnityaṃ prakāśātmā manaḥ sattvavatāmiva
]

`v 12 [
kvacidāhlādajanakaḥ sādhūnāmiva saṃgamaḥ |
kvacidudvegajanako mūrkhairiva samāgamaḥ
]

`v 13 [
kvacitprakaṭasarvārtho mano matimatāmiva |
kvacidatyantagahano mūrkhaśrotriyacittavat
]

`v 14 [
kvacidaprāptasomāṃśuḥ kvacidaprāptasūryabhāḥ |
kvacillokamayastena kvacidāśūnyadiktaṭaḥ
]

`v 15 [
kvaciddevapuravyāptaḥ kvaciddaityapurānvitaḥ |
kvacitpātālagahanaḥ kvacicchṛṅgordhvakandharaḥ
]

`v 16 [
kvacicchvabhrabhramadgṛdhraḥ kvacitsānumanoharaḥ |
kvacicchṛṅgaśikhākrāntavairiñcanagarāntaraḥ
]

`v 17 [
kvacicchūnyamahāraṇyavahatkalpāntamārutaḥ |
kvacitpuṣpavanodyānagāyadvidyādharīgaṇaḥ
]

`v 18 [
kvacitpātālagambhīraguhākumbhāṇḍabhīṣaṇaḥ |
kvacinnandanasodaryamunyāśramamanoramaḥ
]

`v 19 [
kvacidakṣayamattābhraḥ kvaciddurlabhavāridaḥ |
kvacidgarbhaguhāśvabhragahanopāntamaṇḍalaḥ
]

`v 20 [
kvacitkṣubdhajanākṣepasamutsāditabhūtabhūḥ |
kvacidvāstavyajanatāsaujanyajitaviṣṭapaḥ
]

`v 21 [
kvacinnityaṃn vahadgrātājātasthāvarajaṅgamaḥ |
kvacitsarvakṣayonmuktasthirasthāvarajaṅgamaḥ
]

`v 22 [
kvacinmahāmarumarunmuktabhāṃkārabhīṣaṇaḥ |
kvacitkaṇatkamalinīmattasārasabhūṣaṇaḥ
]

`v 23 [
kvacitsalilakallolajaladollāsaghargharaḥ |
kvacinmattāpsarodolāvilāsajanitasmaraḥ
]

`v 24 [
kvacitpiśācakumbhāṇḍaveṣṭitāceṣṭadiktaṭaḥ |
kvacidvidyādharīsiddhanṛtyagītasarittaṭaḥ
]

`v 25 [
kvacidudvarṣadambhodasaridbāhuluṭhattaṭaḥ |
kvacitsatatagānītanītanānābhrasatpaṭaḥ
]

`v 26 [
kvacitkamalinīkośavaktrasthādhyānamaṇḍalaḥ |
kvacitsvargāṅganāsiddhasundarīdantamaṇḍanaḥ
]

`v 27 [
kvacittapaddinakarajanatācārasundaraḥ |
kvacinnaiśatamogehanṛtyanmattaniśācaraḥ
]

`v 28 [
kvacidutpatadutpātataya naśyajjanāvaniḥ |
kvacitsaurājyasaṃpattyā prodbhavatpuramaṇḍalaḥ
]

`v 29 [
kvacidatyantaniḥśūnyaḥ kvacijjanapadāvṛtaḥ |
kvacicchvabhrāntagambhīraḥ kvacitpātālabhīṣaṇaḥ
]

`v 30 [
kvacidbṛhatkalpataruḥ kvacinnirjalajaṅgamaḥ |
kvacinmahākarikulaḥ kvacinmattaharivrajaḥ
]

`v 31 [
kvacinnirbhūtamudyātaḥ kvacidunmattarākṣasaḥ |
kvacitkarañjagahanaḥ kvacittālamahāvanaḥ
]

`v 32 [
kvacidvyomopamasarāḥ kvaciddīrghamarusthalaḥ |
kvacinnityabhramatpāṃśuḥ kvacitsarvartukānanaḥ
]

`v 33 [
śikhareṣu śilāstasya sāmānyācalasaṃnibhāḥ |
santi susthitakalpābhrā ratnamayyo'mbarāmalāḥ
]

`v 34 [
kṣīrodakārkagaurīṇāṃ vanaskandhaukasāmiva |
viśrāmyantyaniśaṃ yāsu harayo hariyonayaḥ
]

`v 35 [
tāsāmuttaradigbhāge pūrvaśṛṅgaśilodare |
nivasāmyahamakṣīṇavajrasārasamatvaci
]

`v 36 [
vidhinā tatra baddhāsmi vasāmyupalayantrake |
atrāsaṃkhyā mune yātā manye yugagaṇā mama
]

`v 37 [
na kevalamahaṃ baddhā yāvadbhartāpi tatra me |
baddhaḥ sāyaṃtane padmakuḍmale ṣaṭpado yathā
]

`v 38 [
tena sārdhaṃ mayā bhartrā śilākoṭarasaṃkaṭe |
anubhūtāściraṃ kālamatra varṣagaṇā gatāḥ
]

`v 39 [
adyāpyātmaikadoṣeṇa na hi mokṣaṃ labhāvahe |
ciraṃ tatraiva tiṣṭhāvastathaivābaddhabhāvanau
]

`v 40 [
pāṣāṇasaṃkaṭe tasminbaddhāvāvāṃ na kevalam |
baddho yāvadaśeṣeṇa parivāro'pi tatra nau
]

`v 41 [
purāṇapuruṣo baddho dvijastatrāsti me patiḥ |
ekasthānānna calati jīvanyugaśatānyasau
]

`v 42 [
ābālyādbrahmacārī ca śrotriyaḥ pāṭhako'lasaḥ |
ekānta ekae evāste'jihmavṛttiracāpalaḥ
]

`v 43 [
ahaṃ vyasaninī bhāryā tasya vedavidāṃ vara |
na nimeṣaṃ samarthāsmi taṃ vinā dehadhāraṇe
]

`v 44 [
śṛṇu tena kathaṃ brahmanbhāryāhaṃ samupārjitā |
kathaṃ vṛddhimayaṃ yātaḥ sneho'smākamakṛtrimaḥ
]

`v 45 [
tena jātena madbhartrā bālenaiva satā purā |
kiṃcijjñena sataikena tiṣṭhatātmālaye'male
]

`v 46 [
śrotriyatvānurūpeṇa jāyā me janmaśālinī |
kutaḥ saṃbhavatītyeva nirṇīya ciracintayā
]

`v 47 [
svayamevānavadyāṅgī tena tāmarasekṣaṇa |
utpāditāsmi nāthena jyotsneva śaśinā'malā
]

`v 48 [
manasā mānasībhāryā mandarottamasundarī |
tato vṛddhiṃ prayātāsmi vasanta iva mañjarī
]

`v 49 [
sahajāmbarasaṃchannā bhūtānāṃ cittahāriṇī |
pūrṇendubimbavadanā dyaurivāmalatārakā
]

`v 50 [
korakoccastanabharā samagrarasaśālinī |
latāvaravaneneva karapallavaśālinī
]

`v 51 [
sarvasya jantujātasya nityaṃ hṛdayahāriṇī |
hariṇītāranayanā madanonmādadāyinī
]

`v 52 [
līlāvilāsaikaratā helāvalitalocanā |
geyavādyapriyā nityaṃ na ca tṛptānurāgiṇī
]

`v 53 [
saubhāgyabhogaparamā lakṣmyalakṣmyoḥ priyā sakhī |
ananyā mohajālānāmakhinnā saṃpadāpadoḥ
]

`v 54 [
na kevalamahaṃ gehaṃ dhārayāmi dvijanmanaḥ |
yāvattrailokyasadanamidamaṅga bibharmyaham
]

`v 55 [
ahaṃ kulakarī bhāryā kalatrabharaṇakṣamā |
trailokyagṛhasaṃbhāradhāraṇaikabharodvahā
]

`v 56 [
athāhaṃ taruṇī jātā samudbhinnonnatastanī |
latollaladguluccheva vilāsarasaśālinī
]

`v 57 [
patirmāṃ dīrghasūtratvācchrotriyatvāttaporataḥ |
kayāpyapekṣayādyāpi na vivāhitavānimām
]

`v 58 [
tena yauvanasaṃpannavilāsarasaśālinī |
taṃ vinā vyasanenāhaṃ dahye'gnāviva padminī
]

`v 59 [
śītānilavilolāsu nalinīṣu nirantaram |
aṅgadāhamavāpnoti pūtāṅgārasthalīṣviva
]

`v 60 [
udyānāvanayaḥ sarvāḥ pūrṇāḥ kusumavarṣaṇaiḥ |
saṃpannāstaptasikatāḥ śūnyā me marubhūmayaḥ
]

`v 61 [
jalakallolakahlārakamalotkarakomalāḥ |
sarasyaḥ sārasārāvasarasā mama nīrasāḥ
]

`v 62 [
ahaṃ puṣkaramandārakumudotkaramālitā |
bhṛśaṃ dāhamavāpnomi kaṇṭakeṣviva dolitā
]

`v 63 [
kumudotpalakahlārakadalītalpapālayaḥ |
madaṅgasaṅgamādgrīṣmamarmarā yānti bhasmatām
]

`v 64 [
yatkāntamucitaṃ svādu vicitraṃ cittahāri ca |
tadālokya bhavāmyantarbāṣpapūrṇāyatekṣaṇā
]

`v 65 [
vyasanānalasaṃtaptāḥ patanto bāṣpabindavaḥ |
chamacchamiti majjanti kamalotpalapaṅktiṣu
]

`v 66 [
kadalīkandalīskandhadolāndolanalīlayā |
lālitodyānakhaṇḍeṣu mukhamācchādya rodimi
]

`v 67 [
tuṣāranikarākīrṇaṃ kadalīdalamaṇḍapam |
paśyāmyūṣmāṇamujjhantaṃ khadirāṅgārabhīṣaṇam
]

`v 68 [
nalinīnāladolāsu sārasīṃ sārasāśritām |
dīnānanā vilokyāntarnindāmi nijayauvanam
]

`v 69 [
ramye rodimi madhyasthe padārthe yāmi saumyatām |
hṛṣyāmyaśobhane dīnā na jāne kimahaṃ sthitā
]

`v 70 [
dṛṣṭāni kundamandārakumudāni himāni ca |
mayā kāmāgnidagdhānāṃ bhasmānīva diśaṃ prati
]

`v 71 [
ānīlapallavamṛṇālalatotpalānāṃ kahlārakundakadalīdalamālatīnām |
śayyā mamāṅgacalanena viśoṣayantyā vyarthaṃ gatāni navayauvanavāsarāṇi | 71
|
ānīlānāṃ tamālādipallavānāṃ mṛṇālalatānāṃ utpalānāṃ ca tathā kahlārādīnāṃ
ca śayyāḥ aṅgacalanena dehasaṃyogena viśoṣayantyā mama navayauvanavāsarāṇi
vyarthaṃ gatāni
]