`v 1 [
dvipañcāśadadhikaśatatamaḥ sargaḥ 152
muniruvāca |
ityuktvā sa munistatra tūṣṇīṃ svaśayane niśi |
āsīdvismayataścāhamathāśaṃ prohyamānavat
]

`v 2 [
tataścireṇa kālena mayoktaṃ tasya sanmune |
evaṃ svapno vibho sarvaḥ sadrūpa iti me matiḥ
]

`v 3 [
anyamuniruvāca |
satsaṃbhavati yatrānyattatredaṃ saditi smayaḥ |
yukto yatra tvetadeva sattālpaṃ tatra kā pramā
]

`v 4 [
yathā svapnastathaivāyamādau sargo'vabhāsate |
pṛthvyādirahito'pyeṣa pṛthvyādibhiravasthitaḥ
]

`v 5 [
itthamadyatanātsvapnātsargasvapno'malātmakaḥ |
śṛṇu puṣkarapatrakṣa mune vyādha mahāguro
]

`v 6 [
adya dṛṣṭapadārthābhyāṃ svapnaṃ svapnavato'bhavat |
sargasvapnastu dṛṣṭārtha evādau khe virājate
]

`v 7 [
evaṃ satsvapna ityeva saṃdigdhamiva vakṣi kim |
sphuṭamapyanubhūtaṃ satsvapnadhyānodyamaḥ katham
]

`v 8 [
idamitthaṃ yadābhogi sphuṭaṃ svapnajaganmune |
sadevānubhavatyeva tatra saṃdigdhatā katham
]

`v 9 [
athaivaṃvādinastasya vākyamākṣiptavānaham |
pṛṣṭavānvyādhagurutā kāsau me kathyatāmiti
]

`v 10 [
anyamuniruvāca |
śrūyatāmidamākhyānamaparaṃ kathayāmi te |
saṃkṣepeṇa mahāprājña nāstyanto vistarasya me
]

`v 11 [
asmyahaṃ tāvadādīrghatapāstvamatidhārmikaḥ |
śrutvedaṃ madvacaḥ satyamihaiva ratimeṣyasi
]

`v 12 [
ihasthaṃ māmimaṃ tvaṃ ca na tyakṣyasi saparyayā |
ahaṃ bhavadbhiḥ sahito nivatsyāmīti niścayaḥ
]

`v 13 [
sādho yāteṣu varṣeṣu tataḥ katipayeṣviha |
sarvabandhuvināśaste durbhikṣeṇa bhaviṣyati
]

`v 14 [
mattasīmāntasāmantavigraheṇa tadaiva ca |
sarvo gṛhāttanuprāṇirgrāmako'yaṃ vinaṅkṣyati
]

`v 15 [
tato duḥkhamajānantau ciramāśvasitau mithaḥ |
śāntau viditavedyatvātsamau sarvārthanispṛhau
]

`v 16 [
ihaivaikatra kasmiṃścittarukhaṇḍakajālake |
samācārau nivatsyāvaḥ śūnye candraravī yathā
]

`v 17 [
utpatsyate tvaraṇye'sminkālena vanamuttamam |
śālatālalatājālavalitākhilabhūtalam
]

`v 18 [
tālītamāladalatāṇḍavamaṇḍitāśaṃ vyākośapadmavanavandyavikāsivṛkṣam |
kūjaccakoracayacārulatānikuñjamudbhāsi nandanamivāgatamantarikṣāt
]

`v 121 [
ihasthaṃ māṃ ca tvaṃ na tyakṣyasi
]