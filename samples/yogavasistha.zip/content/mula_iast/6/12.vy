`v 1 [
dvādaśaḥ sargaḥ 12
bhuśuṇḍa uvāca |
kha eva vyoma saṃpannamiti saṃkalpanaṃ yathā |
bhrāntimātramasadrūpaṃ tathāhaṃbhāvabhāvanam
]

`v 2 [
khe khaṃ jātamiti bhrānterahaṃ kalpayitā yathā |
tathā nirvyapadeśyātma sadastyasadivātatam
]

`v 3 [
khe khātmaivāsti cidrūpaṃ tatsvakaṃ budhyate vapuḥ |
bhāsate yadidantvena nāhamasmi na cānaham
]

`v 4 [
tataścidrūpamastīdṛgyatra sthūlaṃ khamapyalam |
aṇāviva mahāmerustatsaṃvittirhi khāditā
]

`v 5 [
ata eva tatparamasūkṣmaṃ sarvasthūlakalpanādhiṣṭhānaṃ brahmāstīti pariceyamityāha ##-
ghanastato'cidābhāsaḥ khādapyatitarāmaṇuḥ |
jānāti yatsvabhāvaṃ tadetatsargatayā sthitam
]

`v 6 [
ahantākhāditādyātmavidaḥ prasaraṇaṃ jagat |
ambhodravaprasaraṇaṃ yathāvartādiveṣṭanam
]