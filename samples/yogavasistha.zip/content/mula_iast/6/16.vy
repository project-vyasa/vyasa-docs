`v 1 [
ṣoḍaśaḥ sargaḥ 16
bhuśuṇḍa uvāca |
kathayatyevamapyevaṃ sa vidyādharanāyakaḥ |
āsītsaṃśāntasaṃvittiḥ samādhipariṇāmavān
]

`v 2 [
prabodhyamāno'pi mayā bhūyobhūyastatastataḥ |
na papāta purodṛśye paraṃ nirvāṇamāgataḥ
]

`v 3 [
sa prāpa paramaṃ sthānaṃ tāvanmātraprabodhavān |
kenacinnādhikenāṅga yatnenātiśayaiṣiṇā
]

`v 4 [
mukhyādhikāritvāttāvanmātreṇa madupadeśena prabodhavān |
śravaṇāvṛttimanananididhyāsanādyatiśayaiṣiṇā na | aṅgeti vasiṣṭhasaṃbodhanam | 3
|
ata uktaṃ mayā rāma yadi śuddhe hi `note[vicetasi ityapi pāṭhaḥ |] cetasi |
upadeśaḥ prasarati tailabindurivāmbhasi
]

`v 5 [
nāhamityasti te nāntarmainaṃ bhāvaya śāntaye |
etāvadupadeśoktiḥ paramā netarāsti hi
]

`v 6 [
eṣaivābhavyamanasi patitā pravilīyate |
uttāne masṛṇādarśe muktāphalamivāmalam
]

`v 7 [
bhavye tu śāntamanasi lagatyabhyetyavicyutim |
praviśyāntarvicārākhyāmarcirarkamaṇau yathā
]

`v 8 [
ahaṃbhāvanamevoccairbījaṃ duḥkhākhyaśālmaleḥ |
mamedaṃ tadvadādīti śākhāprasarakāraṇam
]

`v 9 [
ahamādau mametyantastata icchā pravartate |
idamarthaśatānarthakāriṇī bhavabhāriṇī
]

`v 10 [
evaṃvidhā muniśreṣṭha mūḍhā api cirāyuṣaḥ |
bhavantyaniyamo hyaṅga dīrghāyuṣyasya kāraṇam
]

`v 11 [
antaḥśuddhamanaskā ye sucirāyābhayapradam |
manāgapyupadiṣṭāste prāpnuvanti paraṃ padam
]

`v 12 [
śrīvasiṣṭha uvāca |
merumūrdhani māmevamuktvā sa vihagādhipaḥ |
tūṣṇīṃ babhūva muktātmā ṛṣyamūka ivāmbudaḥ
]

`v 13 [
ahamāpṛcchya taṃ siddhaṃ vidyādharamatho punaḥ |
prāpta ātmāspadaṃ rāma munimaṇḍalamaṇḍitam
]

`v 14 [
etattavādya kathitaṃ balibhukkathoktaṃ vidyādharopaśamanaṃ laghubodhanottham |
asminbhuśuṇḍavihagendrasamāgame me caikādaśeha hi gatāni mahāyugāni
]