`v 1 [
ṣaṣṭitamaḥ sargaḥ 60
śrīvasiṣṭha uvāca |
tato'hamabhito bhrāntastādṛśaṃ pravicārayan |
bahukālamasaṃruddhasaṃvidākāśatāṃ gataḥ
]

`v 2 [
śabdaṃ paścāttamaśrauṣamahaṃ vīṇāsvanopamam |
kramātsphuṭapadaṃ jātaṃ tata āryātvamāgatam
]

`v 3 [
āryātvaṃ āryākhyacchandolakṣaṇalakṣitatvam | yathāhuḥ yasyāḥ prathame pāde
dvādaśamātrāstathā tṛtīye'pi | aṣṭādaśa dvitīye caturthake pañcadaśa sā''ryā | iti | 2
|
śabdadeśapataddṛṣṭirdṛṣṭavānvanitāmaham |
pārśve kanakaniṣpandaprabhayā bhāsitāmbarām
]

`v 4 [
ālolamālyavasanāmalakākulalocanām |
loladdhammillavalanāmanyāṃ śriyamivāgatām
]

`v 5 [
kāntakāñcanagaurāṅgīṃ mārgasthanavayauvanām |
vanadevīmivāmodisarvāvayavasundarīm
]

`v 6 [
sā pūrṇacandravadanā puṣpaprakārahāsinī |
yauvanoddāmavadanā pakṣmalakṣaṇaśālinī
]

`v 7 [
ākāśakośasadanā śaśāṅkakarasundarī |
muktākalāparacanā kānatā madanusāriṇī
]

`v 8 [
svareṇa madhureṇaivamāryāmāryavilāsinī |
papāṭhākaṭhinaṃ vāmā matpārśve mṛduhāsinī
]

`v 9 [
asaducitariktacetanasaṃsṛtisariti pramuhyamānānām |
avalambanataṭaviṭapinamabhimaumi bhavantameva mune
]

`v 10 [
ityākarṇyāhamālokya tāṃ cāruvadanasvanām |
lalaneyaṃn kimanayetyanādṛtyaiva tāṃ gataḥ
]

`v 11 [
tato jagadvṛndamayīṃ māyāṃ saṃprekṣya vismitaḥ |
anādṛtyaiva tāṃ vyomni vihartumahamudyataḥ
]

`v 12 [
tatastāṃ tatkṛtāṃ cintāmalamutsṛjya khe sthitām |
jaganmāyāṃn kalayituṃ vyomātmāhaṃ pravṛttavān
]

`v 13 [
yāvattāni tathogrāṇi jaganti sakalāni kham |
śūnyameva yathā svapne saṃkalpe kathane tathā
]

`v 14 [
na paśyanti na śṛṇvanti kadācitkānicitkvacit |
tāni kalpamahākalpamahājanmaikatānyatha
]

`v 15 [
pramattapuṣkarāvartānunmattotpātamārutān |
sphuṭitādrīndṛḍhākāraghaṭitabrahmamaṇḍapān
]

`v 16 [
jvalatkalpāgnivisphoṭacaṭadaiḍaviḍāspadān |
pratapaddvādaśākārakandumārtaṇḍamaṇḍalān
]

`v 17 [
luṭhatsurapuravrātavitatākrandaghargharān |
raṇasarvādrikaṭakaśreṇīnigiraṇodbhaṭān
]

`v 18 [
kalpāgnijvalanollāsapaṭhatpaṭapaṭāravān |
ātmabhraṃśabṛhatkṣobhakṣubdhāmbaramahārṇavān
]

`v 19 [
devāsuranarāgāraghargharākrandakarkaśān |
saptārṇavamahāpūrapūritārkendumaṇḍalān
]

`v 20 [
na vicetanti kalpāntānsarvāṇyevaṃ parasparam |
ekamandirasaṃsuptāḥ svapne raṇarayāniva
]

`v 21 [
īdṛśānapi tattadantaḥpravṛttānkalpāntān sarvāṇyeva jaganti parasparaṃ na vicetanti |
20 |
tatra rudrasahasrāṇi brahmakoṭiśatāni ca |
dṛṣṭāni viṣṇulakṣāṇi kalpavṛndānyalaṃ mayā
]

`v 22 [
tatra kvacidanāditye nirahorātrabhūtale |
ākalpayugavarṣānte jagatyūhaiḥ kṣayodayaḥ
]

`v 23 [
citi sarvaṃ citaḥ sarvaṃ citsarvaṃ sarvataśca cit |
citsatsarvātmiketyetaddṛṣṭaṃ tatra mayākhilam
]

`v 24 [
tvaṃ kiṃciditi cedvakṣi tatra kiṃ cidivāṅga cit |
sā hi śūnyatamā vyomno na ca nāma na kiṃcana
]

`v 25 [
tadākāśamidaṃ bhāti jagadityabhiśabditam |
tenaiva śabdanabhasā sarvaṃ hi paramaṃ nabhaḥ
]

`v 26 [
dṛśyadṛṣṭiriyaṃ bhrāntirākāśatarumañjarī |
cidvyomāṅga kameveti tatrāhamanubhūtavān
]

`v 27 [
buddhyākāśaikarūpeṇa vyāpinā bodharūpiṇā |
tatrānantena `note[atra anantena nasaṅkalpaḥ iti padaviśleṣaṣṭīkākāraiḥ kṛtaḥ
sa ca sudhībhirvimarśanīyaḥ |] saṃkalpamanubhūtamidaṃ mayā
]

`v 28 [
brahmavyoma jagajjālaṃ brahmavyoma diśo daśa |
brahmavyoma kalākāladeśadravyakriyādikam
]

`v 29 [
tatrāhamiva saṃsāraśate bhāte munīśvarāḥ |
dṛṣṭā vasiṣṭhanāmāno brahmaputrāḥ saduttamāḥ
]

`v 30 [
brahmandvāsaptatistretāḥ sarvā eva sarāghavāḥ |
tatra dṛṣṭaṃ kṛtaśataṃ dvāparāṇāṃ śataṃ tathā
]

`v 31 [
bhedodayena vai dṛṣṭāstāstāḥ sargadaśāstathā |
bodhena cettadatyacchamekaṃ brahma nabhastatam
]

`v 32 [
nedaṃ brahmaṇi nāmāsti jagadbrahmaṇyatha tvidam |
brahmaivājamanādyantaṃ tatsarvaṃ tatpadādikam
]

`v 33 [
pāṣāṇamaunapratimaṃ nakiṃcidabhiśabditam |
yattatkiṃciditi dyotarūpaṃ brahma jagatsmṛtam
]

`v 34 [
vibhātyacetyaṃn cidvyomni svasattaiva jagattayā |
nirākāre nirākārā svapnānubhavasaṃnibhā
]

`v 35 [
ananyamātmano brahma sarvaṃ bhāmātrarūpakam |
prakāśanamivālokaḥ karoti na karoti ca
]

`v 36 [
teṣu nāmānubhūyante jagallakṣeṣu tatra vai |
uṣṇāni candrabimbāni sūryāḥ śītalamūrtayaḥ
]

`v 37 [
prajāstamasi paśyanti paśyantyeva na tejasi |
ulūkasya samācārāstasyaiva sadṛśasvarāḥ
]

`v 38 [
itaḥ śebhena naśyanti yānti pāpaistathā divam |
viṣāśanena jīvanti mriyante'mṛtabhojanaiḥ
]

`v 39 [
yadyathā budhyate bodhe yathodetyathavā svataḥ |
tathāśu sphuṭatāmeti sadvāsadvā tadeva tat
]

`v 40 [
viṭapākāramūlaughadarśanādvajraśobhibhiḥ |
ghūrṇate patrapuṣpābhaiḥ pādapairvyomni kānanam
]

`v 41 [
sikatāḥ pīḍitāḥ satyaḥ sravanti snehajaṃ rasam |
śilāphalakakebhyaśca jāyante kamalānyalam
]

`v 42 [
dāruṇyaśmani bhittau ca cañcalāḥ śālabhañjikāḥ |
devāṅganābhiḥ sahitaṃ gāyanti kathayanti ca
]

`v 43 [
meghānparidadhatyuccairbhūtānyuccaiḥ paṭāniva |
prativarṣaṃ vijātīyānyutpadyante phalānyage
]

`v 44 [
saṃniveśairna niyatairaṅgānāṃ vividhāṅgakaiḥ |
śirobhiḥ sarvabhūtāni parikrāmanti bhūmigaiḥ
]

`v 45 [
śāstravedavihīnāni nirdharmāṇyeva kānicit |
yatkiṃcanaikakārīṇi tiryagvanti jagantyadhaḥ
]

`v 46 [
kāmasaṃvittihīnāni niḥstrījātāni kānicit |
bhūtaiḥ saṃśuṣkahṛdayairvyāptānyaśmamayairiva
]

`v 47 [
pavanāśanabhūtāni samaratnāśmakāni ca |
ajātārthānyalubdhāni nigarvāṇīva kāni ca
]

`v 48 [
kvacitpratyekamātmānaṃ paśyatyāpnoti netarat |
bahubhūtakamapyasti jagadityekabhūtakam
]

`v 49 [
nakhakeśādike yadvattadvadanyatra saṃsthitaḥ |
ātmavatsarvabhūtānāmekībhūtātmabhāvanā
]

`v 50 [
anantāpāraparyantaṃ śūnyameva bahu kvacit |
yatnataḥ saṃvidāpnoti tasyānte na jagatpunaḥ
]

`v 51 [
atyantābuddhabuddhāni mokṣaśabdārthadṛṣṭiṣu |
dāruyantramayāśeṣabhūtaughānīva kānicit
]

`v 52 [
ṛkṣacakravihīnāni niṣkālakalanāni ca |
mūkasaṃketasārāṇi bhūtajālāni kānicit
]

`v 53 [
kānicidvarjitānyeva netraśabdārthasaṃvidā |
vyarthadīptātmatejāṃsi bhūtānītyekacintayā
]

`v 54 [
prāṇasaṃvidvihīnāni vyarthāmodāni kānicit |
mūkāni śabdavaiyarthyācchrutihīnāni kānicit
]

`v 55 [
vākyasaṃvidvihīnatvānmūkānyanyāni kānicit |
sparśasaṃvidvihīnatvādaśmāṅgānīva kānicit
]

`v 56 [
saṃvinmātramayānyeva dṛṣṭānyapi ca kānicit |
vyavahārīṇyapyagrāhyāṇyeva nityaṃ piśācavat
]

`v 57 [
bhūmayānyekaniṣṭhāni niṣpiṇḍānyena kānicit |
kānicidvāripūrṇāni vahnipūrṇāni kānicit
]

`v 58 [
kānicidvātapūrṇāni sarvākārāṇi kānicit |
jaganti vyomarūpāṇi bata tatra kacanti khe
]

`v 59 [
dharāpīṭhaikapūrṇeṣu tiṣṭhantyanyeṣu dehinaḥ |
bhekā iva śilākośe kīṭā iva dharodare
]

`v 60 [
jalaikaparipūrṇeṣu tiṣṭhantyurvīvanādriṣu |
bhramantyanyeṣu bhūtāni nityamevogramīnavat
]

`v 61 [
evaṃ vāryādipūrṇeṣvapi jīvanotpattirbodhyetyāha - jaleti | ugramīno grāhastadvat | 60
|
anyeṣvagnyekapūrṇeṣu jalādirahitānyapi |
bhūtānyagnimayānyeva sphurantyalamalātavat
]

`v 62 [
anyeṣvanilapūrṇeṣu bhūtānyastetarāṇyapi |
vātamātramayāṅgāni sphurantyarjunavātavat
]

`v 63 [
arjunavāto rogaviśeṣaḥ | tadvanto hi janā ākāśe bhramantīti deśaviśeṣe prasiddham | 62
|
anyeṣu vyomamātrātmadeheṣu vyomarūpiṇaḥ |
prāṇinaḥ santi sargeṣu darśanavyavahāriṇaḥ
]

`v 64 [
pātālapātiṣu tathāmbaramutpatatsu tiṣṭhatsu vibhramapadeṣvatha diṅmukheṣu |
nānājagatsu kimivāsti mayā na dṛṣṭaṃ yannāma cijjaladhicañcalabudbudeṣu | 64
|
tatra cidākāśe adha ūrdhvaṃ paritaśca kalpite digvibhāge plavamānāni sarvāṇi vicitrāṇi
jaganti tadantargatavastūni ca mayā dṛṣṭānītyupasaṃharati - pātāleti |
cijjaladheścañcalabudbudaprāyeṣu nānājagatsu mayā yanna dṛṣṭaṃ nāma tatkimiva |
na kiṃcidityarthaḥ | sarvajñasākṣyaviṣayasyāprasiddheriti bhāvaḥ
]