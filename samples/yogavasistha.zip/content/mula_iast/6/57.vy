`v 1 [
saptapañcāśaḥ sargaḥ 57
śrīrāma uvāca |
śrīrāma uvāca |
tvāmapyuditanirvāṇamahaṃkārapiśācakaḥ |
bādhate kimiti brūhi mune saṃdehaśāntaye
]

`v 2 [
śrīvasiṣṭha uvāca |
ahaṃbhāaṃ vinā dehasthitistajjñājñayoriha |
ādheyasya nirādhārā na saṃsthehopapadyate
]

`v 3 [
ayaṃ tvatra viśeṣastaṃ śṛṇu viśrāntacetasaḥ |
śrutena yenāhaṃbhāvapiśācaḥ śāntimeti te
]

`v 4 [
ahaṃbhāvapiśāco'yamajñānaśiśunāmunā |
avidyamāna evāntaḥ kalpitastena saṃsthitaḥ
]

`v 5 [
ajñānamapi nāstyeva prekṣitaṃ yanna labhyate |
vicāriṇā dīpavatā svarūpaṃ tamaso yathā
]

`v 6 [
yathā yathā vilokyate tathā tathā vilīyate |
ihājñatāpiśācikā tathā vicāritā satī
]

`v 7 [
kila satyāmavidyāyāmajñatodeti śāśvatī |
buddhimohātmikā yakṣī nirdehaiva yathā niśi
]

`v 8 [
sati sarge tvavidyāyāḥ saṃbhavo nānyataḥ kvacit |
sati dvitīye śaśini dvitīyo vidyate śaśaḥ
]

`v 9 [
evaṃ kāraṇāvidyāpi
kāryāvidyodayakālamātravyavahāratvāttadupādhikajīvacidvedyatvācca tadadhīnetyāha ##-
sargastvayamajātatvādajñajñāto na vidyate |
na jātaḥ kāraṇābhāvātpūrvameva khavṛkṣavat
]

`v 10 [
paramākāśakośāntarādisarge nirāmaye |
pṛthvyāderupalambhasya bhavetkimiva kāraṇam
]

`v 11 [
manaḥṣaṣṭhendriyātītaṃ manaḥṣaṣṭhendriyātmanaḥ |
sākārasya nirākāraṃ kathaṃ bhavati kāraṇam
]

`v 12 [
bījātkāraṇataḥ kāryamaṅkuraḥ kila jāyate |
na bījamapi yatrāsti tatra syādaṅkuraḥ kutaḥ
]

`v 13 [
kāraṇena vinā kāryaṃ na ca nāmopapadyate |
kadā ka iva khe kena dṛṣṭo labdhaḥ sphuṭo drumaḥ
]

`v 14 [
saṃkalpenāmbare yadvaddṛśyate viṭapādikam |
sa saṃkalpastathābhūto na tatrāsti padārthatā
]

`v 15 [
evaṃ yeyaṃ cidākāśe sargādāvanubhūyate |
śūnyarūpa ivākāśe sargasthitiranargalā
]

`v 16 [
sama eva cidākāśaḥ kavatyātmani tattathā |
svabhāva eva sargākhyaścittvāccaitanyamīśvaraḥ
]

`v 17 [
svapnasargo'tra dṛṣṭāntaḥ pratyahaṃ yo'nubhūyate |
svayaṃ saṃvedane svapne sphuratyadripurākṛtiḥ
]

`v 18 [
citsvabhāve yathā svapne āste sarga iveha yaḥ |
asarge sargavadbhāti tathā pūrvaṃ mahāmbare
]

`v 19 [
avedyavedanaṃ śuddhamekaṃ bhātyajamavyayam |
sargādau yadanādyantaṃ sthitaḥ sargaḥ sa eva naḥ
]

`v 20 [
neha sargo'sti naivāyaṃ pṛthvyādigaṇagolakaḥ |
sarvaṃ śāntamanālambaṃ brahmaiva brahmaṇi sthitam
]

`v 21 [
sarvaśaktyātma tadbrahma yathā kacati yādṛśam |
rūpamatyajadevācchaṃ tathā bhavati tādṛśam
]

`v 22 [
yathā svapnapuraṃ jantościnmātrapravijṛmbhitam |
tathaiva sargaḥ sargādau śuddhacinmātrajṛmbhitam
]

`v 23 [
svacche citparamākāśe cidākāśo ya āsthitaḥ |
svabhāva eva sargo'sāviti tenaiva bhāvitaḥ
]

`v 24 [
bhāvyabhāvakabhāvādibhūmīnāṃ bhāvanaṃ bhṛśam |
sarvaṃ cinnabha evācchamātmanātmani saṃsthitam
]

`v 25 [
evaṃ sthite kutaḥ sargaḥ kuto vidyā kva cājñatā |
brahma śāntaṃ ghanaṃ sarvaṃ kvāhaṃkārādayaḥ sthitāḥ
]

`v 26 [
ahaṃbhāvasya saṃśāntireṣā'sau kathitā tava |
ahaṃbhāvaḥ parijñātaḥ piśāca iva śāmyati
]

`v 27 [
mayā tvevamahaṃbhāvaḥ parijñāto yadākhilaḥ |
tadā me vidyamāno'pi niṣphalaḥ śaradabhravat
]

`v 28 [
citrāgnidāho vijñāto yathā dāhyeṣu niṣphalaḥ |
tathāhaṃbhāvasargādi jñātaṃ niṣphalatāmiyāt
]

`v 29 [
iti me'hakṛtestyāge rāge ca samatā yadā |
tadā vyomna ivāvyomnaḥ sarge sarge ca me sthitiḥ
]

`v 30 [
ahaṃbhāvasya naivāhaṃ nāhaṃbhāvo mameti ca |
tena viddhi cidākāśamevedamiti nirghanam
]

`v 31 [
yathā mama tathānyeṣāmapi bodhavatāmiha |
agnitvamiva citrāgnernāstyayaṃn bodhavibhramaḥ
]

`v 32 [
nāhamasmi na cānyo'sti sarvaṃ nāstīti niścaye |
prakṛtavyavahārastvaṃ śilāmaunamayo bhava
]

`v 33 [
ākāśakośaviśadākṛtireva tiṣṭha nirdeśavacciramapahnutasarvabhāvaḥ |
adyāditaśca kila cinmayameva sarvaṃ no dṛśyamasti śivamevamaśeṣamittham |
33 |
nirdeśo niravakāśaḥ śilāghanastadvat | adya sargakāle | āditaḥ sargaprākkāle |
sārvavibhaktikastasiḥ
]