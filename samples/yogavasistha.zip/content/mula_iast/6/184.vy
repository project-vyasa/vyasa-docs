`v 1 [
caturaśītyadhikaśatatamaḥ sargaḥ 184
kundadanta uvāca |
ityuktavānasau pṛṣṭaḥ kadambatalatāpasaḥ |
saptadvīpā bhuvo'ṣṭau tāḥ kathaṃ bhātā gṛheṣviti
]

`v 2 [
kadambatāpasa uvāca |
ciddhāturīdṛgevāyaṃ yadeṣa vyomarūpyapi |
sarvago yatra yatrāste tatra tatrātmani svayam
]

`v 3 [
ātmānamitthaṃ trailokyarūpeṇānyena vā nijam |
paripaśyati rūpaṃ svamatyajanneva khātmakam
]

`v 4 [
kundadanta uvāca |
ekasminvimale śānte śive paramakāraṇe |
kathaṃ svabhāvasaṃsiddhā nānātā vāstavī sthitā
]

`v 5 [
kadambatāpasa uvāca |
sarvaṃ śāntaṃ cidākāśaṃ nānāstīha na kiṃcana |
dṛśyamānamapi sphāramāvartātmā yathāmbhasi
]

`v 6 [
asatsveṣu padārtheṣu padārthā iti bhānti yat |
citkhaṃ svapnasuṣuptātma tattasyācchaṃ nijaṃ vapuḥ
]

`v 7 [
saspando'pi hi niḥspandaḥ parvato'pi na parvataḥ |
yathā svapneṣu cidbhāvaḥ svabhāvo'rthagatastathā
]

`v 8 [
na svabhāvā na caivārthāḥ santi sarvātmakocite |
sargādau kacitaṃ rūpaṃ yadyathā tattathā sthitam
]

`v 9 [
na ca nāma paraṃ rūpaṃ kacanākacanātmakam |
dravyātmā cicca cidvyoma sthitamitthaṃ hi kevalam
]

`v 10 [
ekaiva cidyathā svapne senāyāṃ janalakṣatām |
gatevācchaiva kacati tathaivāsyāḥ padārthatā
]

`v 11 [
yatsvataḥ svātmani svacche citkhaṃ kacakacāyate |
tattenaiva tadākāraṃ jagadityanubhūyate
]

`v 12 [
asatyapi yathā vahnāvuṣṇasaṃviddhi bhāsate |
saṃvinmātrātmake vyomni tathārthaḥ svasvabhāsakaḥ
]

`v 13 [
asatyapi yathā stambhe svapne khe stambhatā vidaḥ |
tathedamasyā nānātvamananyadapi cānyavat
]

`v 14 [
ādisarge padārthatvaṃ tatsvabhāvācchameva ca |
cidvyomnā yadyathā buddhaṃ tattathādyāpi vindate
]

`v 15 [
puṣpe patre phale stambhe tarureva yathā tataḥ |
sarvaṃ sarvatra sarvātma parameva tathā'param
]

`v 16 [
paramārthāmbarāmbhodhāvāpaḥ sargaparaṃparā |
paramārthamahākāśe śūnyatā sargasaṃvidaḥ
]

`v 17 [
paramārthaśca sargaśca paryāyau taruvṛkṣavat |
bodhādetadabodhāttu dvaitaṃ duḥkhāya kevalam
]

`v 18 [
paramārtho jagaccedamekamityeva niścayaḥ |
adhyātmaśāstrabodhena bhavetsaiṣā hi muktatā
]

`v 19 [
saṃkalpasya vapurbrahma saṃkalpakacidākṛteḥ |
tadeva jagato rūpaṃ tasmādbrahmātmakaṃ jagat
]

`v 20 [
yato vāco nivartante na nivartanta eva vā |
vidhayaḥ pratiṣedhāśca bhāvābhāvadṛśastathā
]

`v 21 [
amaunamaunaṃ jīvātma yatpāṣāṇavadāsanam |
yatsadevāsadābhāsaṃ tadbrahmābhidhamucyate
]

`v 22 [
sarvasminnekasughane brahmaṇyeva nirāmaye |
kā pravṛttirnivṛttiḥ kā bhāvābhāvādivastunaḥ
]

`v 23 [
ekasyāmeva nidrāyāṃ suṣuptasvapnavibhramāḥ |
yadā bhāntyavicitrāyāṃ citrā iva nirantarāḥ
]

`v 24 [
etasyāṃ citkhasattāyāṃ tathā mūlakasargakāḥ |
bahavo bhāntyacitrāyāṃ citrā iva nirantarāḥ
]

`v 25 [
dravye dravyāntaraṃ śliṣṭaṃ yatkāryāntaramākṣipet |
tadvadantastathābhūtacitsāraṃ sphuraṇaṃ mithaḥ
]

`v 26 [
sarve padārthāścitsāramātramapratighāḥ sadā |
yathā bhānti tathā bhānti cinmātraikātmatāvaśāt
]

`v 27 [
cinmātraikātmasāratvādyathāsaṃvedanaṃ sthitāḥ |
niḥspandā nirmanaskārāḥ sphuranti dravyaśaktayaḥ
]

`v 28 [
avidyamānamevedaṃ dṛśyate'thānubhūyate |
jagatsvapna ivāśeṣaṃ sarudropendrapadmajam
]

`v 29 [
vicitrāḥ khalu dṛśyante cijjale spandarītayaḥ |
harṣāmarṣaviṣādotthajaṅgamasthāvarātmani
]

`v 30 [
svabhāvavātādhūtasya jagajjālacamatkṛteḥ |
hā cinmarīciṣāṃśvabhranīhārasya visāritā
]

`v 31 [
yathā keśoṇḍrakaṃ vyomni bhāti vyāmalacakṣuṣaḥ |
tathaiveyaṃ jagadbhrāntirbhātyanātmavido'mbare
]

`v 32 [
yāvatsaṃkalpitaṃ tāvadyathā saṃkalpitaṃ tathā |
yathā saṃkalpanagaraṃ kacatīdaṃ jagattathā
]

`v 33 [
saṃkalpanagare yāvatsaṃkalpasakalā sthitiḥ |
bhavatyevāpyasadrūpā satīvānubhave sthitā
]

`v 34 [
pravahatyeva niyatirniyatārthapradāyinī |
sthāvaraṃ jaṅgamaṃ caiva tiṣṭhatyeva yathākramam
]

`v 35 [
jāyate jaṅgamaṃ jīvātsthāvaraṃ sthāvarādapi |
niyatyādho vahatyambu gacchatyūrdhvamathānalaḥ
]

`v 36 [
vahanti dehayantrāṇi jyotīṃṣi pratapanti ca |
vāyavo nityagatayaḥ sthitāḥ śailādayaḥ sthirāḥ
]

`v 37 [
jyotirmayaṃ vivṛttaṃ tu dhārāsārāmbarīkṛtam |
yugasaṃvatsarādyātma kālacakraṃ pravartate
]

`v 38 [
bhūtalaikāntarābdhyadrisaṃniveśaḥ sthitāyate |
bhāvābhāvagrahotsargadravyaśaktiśca tiṣṭhati
]

`v 39 [
kundadanta uvāca |
prāgdṛṣṭaṃ smṛtimāyāti tatsvasaṃkalpanānyataḥ |
bhāti prathamasrge tu kasya prāgdṛṣṭabhāsanam
]

`v 40 [
tāpasa uvāca |
apūrvaṃ dṛśyate sarvaṃ svapne svamaraṇam yathā |
prāgdṛṣṭaṃ dṛṣṭamityeva tatraivābhyāsataḥ smṛtiḥ
]

`v 41 [
cittvāccidvyomni kacati jagatsaṃkalpapattanam |
na sannāsadidaṃ tasmādbhātābhātaṃ yataḥ svataḥ
]

`v 42 [
citprasādena saṃkalpasvanādyadyānubhūyate |
śuddhaṃ cidvyoma saṃkalpapuraṃ mā smaryatāṃ katham
]

`v 43 [
harṣāmarṣavinirmuktairduḥkhena ca sukhena ca |
prakṛtenaiva mārgeṇa jñaiścakrairiva gamyate
]

`v 44 [
nidrāvyapagame svapnanagare yādṛśaṃ smṛtau |
cidvyomātma paraṃ viddhi tādṛśaṃ trijagadbhramam
]

`v 45 [
saṃvidābhāsamātraṃ yajjagadityabhiśabditam |
tatsaṃvidvyoma saṃśāntaṃ kevalaṃ viddhi netarat
]

`v 46 [
yasminsarvaṃ yataḥ sarvaṃ yatsarvaṃ sarvataśca yat |
sarvaṃ sarvatayā sarvaṃ tatsarvaṃ sarvadā sthitam
]

`v 47 [
yatheyaṃ saṃsṛtirbrāhmī bhavato yadbhaviṣyati |
yathā bhānaṃ ca dṛśyasya tadetatkathitaṃ mayā
]

`v 48 [
uttiṣṭhataṃ vrajatamāspadamahni padmaṃ bhṛṅgāvivābhimatamāśu
vidhīyatāṃ svam |
tiṣṭhāmi duḥkhamalamastasamādhisaṃsthaṃ bhūyaḥ samādhimahamaṅga ciraṃ
viśāmi
]