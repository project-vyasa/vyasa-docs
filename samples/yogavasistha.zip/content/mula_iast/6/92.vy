`v 1 [
dvinavatitamaḥ sargaḥ 92
śrīvasiṣṭha uvāca |
atha vātamayīṃ kṛtvājagatprekṣaṇakautukāt
dhāraṇāṃ dhīrayā vṛttyā vitatāmahamāgataḥ
]

`v 2 [
saṃpanno'smyanilo vallīlalanālokalāsakaḥ |
kamalotpalakundādijālakāmodapālakaḥ
]

`v 3 [
sīkarotkaranīhārahelāharaṇatatparaḥ |
surataśrāntasarvāṅgasamāhlādanatarṣulaḥ
]

`v 4 [
tṛṇagulmalatāvallīdalatāṇḍavapaṇḍitaḥ |
latauṣadhiphalollāsakusumāmodamaṇḍitaḥ
]

`v 5 [
mṛdurmaṅgalakāleṣu lalanālokalālakaḥ |
bhīma utpātakāleṣu parṇavatprauḍhaparvataḥ
]

`v 6 [
nandane kundamandāramakarandarajoruṇaḥ |
narake'ṅgārasaṃbhārabhūrinīhārabhāsuraḥ
]

`v 7 [
sāgare saralāvartalekhānumitasarpaṇaḥ |
divi vāridasaṃcāramṛṣṭāmṛṣṭendudarpaṇaḥ
]

`v 8 [
saralābhirāvrtalekhābhistaraṅgalekhābhiranumitaṃ sarpaṇaṃ pracalanaṃ yasya |
meghāpasāraṇe mṛṣṭa iva tadācchādanenāmṛṣṭo malinīkṛta ivendudarpaṇo yena |
7 |
nakṣatrakṣatrasainyasya ratho raṃhovibṛṃhitaḥ |
trailokyasiddhasaṃcāravimānadharaṇe hitaḥ
]

`v 9 [
sahodara iva kṣipragāmitvādasya cetasaḥ |
anaṅgo'pi samastāṅgaḥ spandānandanacandanaḥ
]

`v 10 [
tuṣārasīkarāsārajarāromavivarjaraḥ |
āmodayauvanonmādo maunamārdavaśaiśavaḥ
]

`v 11 [
nandanāmodamadhuro `note[nandanodāramadhuraḥ iti pāṭho vyākhyānuguṇaḥ |
] madhurodārasaṃsṛtiḥ |
cārucaitrarathonmukto hṛtakāntārataśramaḥ
]

`v 12 [
nandane indrodyāne udāro madhuraśca | caitrarathātkuberodyānādunmuktaḥ prasṛtaḥ |
11 |
ciraṃ gaṅgātaraṅgāṅgadolāndolanasaśramaḥ |
śramasvarūpājñatayā nivāritatataśramaḥ
]

`v 13 [
puṣpabhārānatāḥ sparśairvasantavanitālatāḥ |
ciraṃ capalayaṁlloladalahastālilocanāḥ
]

`v 14 [
ciraṃ bhuktvendubimbāgraṃ suptā pūrṇābhratalpake |
vidhūya kamalānīkamapanītarataśramaḥ
]

`v 15 [
indubimbe agraṃ śreṣṭhamamṛtaṃ ciraṃ bhuktvā | rataśramaḥ svīyaḥ parakīyo vā | 14
|
samastarajasāmeko vyomagāmī turaṃgamaḥ |
āmodamadamātaṅgasamullāsamahāsuhṛt
]

`v 16 [
dhīreṇāpya taḍicchṛṅgaṃ payodapaśupālakaḥ |
tantuḥ sīkaramuktānāmaridharmā rajorujām
]

`v 17 [
ākāśakusumāmodaḥ sarvaśabdasahodaraḥ |
nāḍīpraṇālīsalilam bhūtāṅgopāṅgavartakaḥ
]

`v 18 [
marmakarmakaraikātmā hṛdguhāgehakesarī |
nityamekāntapathikaḥ sāravijjātavedasaḥ
]

`v 19 [
āmodaratnaluṇṭāko vimānanagarāvaniḥ |
dāhāndhakāraśītāṃśuḥ śaityendukṣīrasāgaraḥ
]

`v 20 [
prāṇāpānakalārajjvā prāṇināṃ yantravāhakaḥ |
arirmitraṃ ca dvīpānāṃ dvīpasaṃcāraṇe rataḥ
]

`v 22 [
purogato'pyadṛśyātmā manorājyapuropamaḥ |
tālavṛntatiletailamālānaṃ spandadantinaḥ | 21 |
ekakṣaṇalavenaiva cālitākhilabhūdharaḥ |
varṇāvalitaraṅgāṇāṃ gaṅgāvāha ivaikakṛt
]

`v 23 [
dhūmāmbuvāharajasāṃ mahāvartakṛdambhasām |
dyunadīvāhavāryoghanabhonīlotpalālikaḥ
]

`v 24 [
śarīrāveṣṭitonmuktapurāṇatṛṇacopanaḥ |
spandapadmavanādityaḥ śabdavarṣaikavāridaḥ
]

`v 25 [
vyomakānanamātaṅgaḥ śarīragṛhagargaṭaḥ |
dhūlīkadambavipinamālāliṅgananāyakaḥ
]

`v 26 [
śarīragṛhe gargaṭo yantraviśeṣa iva sadaiva śabdāyamānaḥ |
dhūlīlakṣaṇanāyikākadambasya vipinamālālakṣaṇanāyikānāṃ cāliṅgane nāyakaḥ | 25
|
styānīkaraṇasaṃśoṣadhṛtispandanasaurabhaiḥ |
saśaityaiḥ karmabhiḥ ṣaḍbhiralabdhakṣaṇa ākṣayam
]

`v 27 [
rasākarṣaṇasavyagro nityaṃ bhrāteva tejasaḥ |
haraṇādānakartṝṇāmaṅgānāṃ viniyogakṛt
]

`v 28 [
śarīranagare nāḍīmārgairgatinirargalaḥ |
rasabhāṇḍe parāvartādāyurmaṇimahāvaṇik
]

`v 29 [
śarīranagarīnāśanirmāṇaikaparāyaṇaḥ |
rasakiṭṭakalādhātupṛthakkaraṇakovidaḥ
]

`v 30 [
pratisūkṣmāṇukaṃ dehe tato dṛṣṭaṃ mayā jagat |
tatretthaṃ rūpavānasmi sphuṭamābhogi susthiram
]

`v 31 [
paramāṇuprati tvatra prohyanta iva sargakāḥ |
na ca kiṃcitkilohyante khākṛte kimivohyate
]

`v 32 [
sacandrārkānilāgnīndrapadmavaiśravaṇeśvarāḥ |
sabrahmaharigandharvā vidyādharamahoragāḥ
]

`v 33 [
sasāgaragiridvīpadigantaramahārṇavāḥ |
salokāntaralokeśakriyākālakalākramāḥ
]

`v 34 [
sasvargabhūmipātālatatalokāntarāntarāḥ |
sabhāvābhāvavaidhuryajarāmaraṇasaṃbhramāḥ
]

`v 35 [
evaṃ nāma tadā rāma bhūtapañcakarūpiṇā |
mayā pravihṛtaṃ tatra tailokyanalinodare
]

`v 36 [
rasaḥ pīto'nubhūtaśca kṣmājalānilatejasām |
mūlajālena vṛkṣāṇāṃ prāṇināṃ vasatā mayā
]

`v 37 [
rasāyanaghanāṅgeṣu candanadravaśobhiṣu |
luṭhitaṃ candrabimbeṣu tuṣāraśayaneṣviva
]

`v 38 [
rasāyanamamṛtaṃ tadghanāṅgeṣu candanadravavacchaityaśauklyādiguṇaśobhiṣu | 37
|
sarvartuvanajāleṣu nānāmodāni dikṣvalam |
bhuktāni puṣpajālāni procchiṣṭaṃ dadatā'laye
]

`v 39 [
tatonnatāsu mṛdvīṣu svāstīrṇāsvambarājire |
suptaṃ śubhrābhramālāsu navanītasthalīṣviva
]

`v 40 [
sumanaḥpatramṛduṣu nīlalakṣmīvilāsiṣu |
surasiddhāṅganāṅgeṣu dūrāstasmaravāsanam
]

`v 41 [
kṛtaḥ kumudakahlārakamale nalinīvane |
komalaḥ kalahaṃsībhirlīlākalakalāravaḥ
]

`v 42 [
saratsaricchirāsārā mūlabhūmaṇḍalānvitāḥ |
aṅgairūḍhāḥ sphuradbhūtā lomālaya ivādrayaḥ
]

`v 43 [
khādrayaḥ prathitā dīrghasaritsūtraiḥ samudrakaiḥ |
ādarśairiva viśrāntamaṅgeṣu pratibimbibhiḥ
]

`v 44 [
bhūtasargeṇa viśrāntaṃ siddhavidyādharādinā |
maddehe cetiteneva makṣikāyaukarūpiṇā
]

`v 45 [
matprasādena muditairlabdhamarkādibhirvapuḥ- |
kṛṣṇaraktasitāpītaharitairharitairiva
]

`v 46 [
samudramudrayā saptadvīpasaptātmarūpayā |
saṃsthayā sthāpitā bhūmiḥ prakoṣṭhe valayopamā
]

`v 47 [
vidyādharapurandhrīṇāṃ parāmṛṣṭāṅgayaṣṭinā |
adṛṣṭenaiva vihitaḥ pulakollāsa ātmanā
]

`v 48 [
saricchirāmalasphārarasāni suṣirāṇi ca |
jagantyevāsthijālāni mamāsansaṃsthitāni ca
]

`v 49 [
asaṃkhyairvyomamātaṅgaiścandrārkacalacāmaraiḥ |
udumbarāntarmaśakairiva maddhṛdaye sthitam
]

`v 50 [
sarvapātālapādena bhūtalodaradhāriṇā |
khamūrdhnāpi tadā rāma na tyaktātha parāṇutā
]

`v 51 [
dikṣu sarvāsu sarvatra sarvadāsarvakāriṇā |
sarvātmanāpyasarveṇa śūnyarūpeṇa saṃsthitam
]

`v 52 [
kiṃcittvaṃ sadakiṃcittvaṃ sākṛtitvaṃ nirākṛti |
anubhūtaṃ sajāḍhyaṃ ca cetanatvamalaṃ mayā
]

`v 53 [
mainākamugdhapīnasya sāgarasyāvaniṃ prati |
santi sargasahasrāṇi sthāṇubhūtānyatho mayā
]

`v 54 [
jagantyaṅge mayoḍhāni gūḍhāni prakaṭānyapi |
pratibimbapurāṇīva mukureṇājaḍātmanā
]

`v 55 [
evaṃ jalānilāgnitvaṃ bhūmitvaṃ khātmanā mayā |
kṛtaṃ citeva svapneṣu bata māyāvijṛmbhitam
]

`v 56 [
api tasyāmavasthāyāṃ jagantyākāśakośake |
mayā dṛṣṭānyasaṃkhyāni paramāṇukaṇaṃ prati
]

`v 57 [
paramāṇu prati vyoma paramāṇu prati sthitam |
sargavṛndaṃ yathā svapne svapnāntarayutaṃ puram
]

`v 58 [
svamevāhamabhūvaṃ bhūmaṇḍalaṃ dvīpakuṇḍalam |
sarvātmanāpi na vyāptaṃ kiṃcanāpi mayā kvacit
]

`v 59 [
samutpādayatāśeṣaṃ latātarutṛṇāṅkuram |
bhūtalena rasāḥ kṛṣṭā mayārthenaiva puṃbhṛtām
]

`v 60 [
avadātatame yuddhabodhakālamupeyuṣi `note[śuddhabodhakālamaye mayi iti pāṭhaḥ
|] |
jagallakṣāṇi tiṣṭhanti na tiṣṭhanti ca kānicit
]

`v 61 [
citi yāstu camatkāraṃ camatkurvanti yatsvataḥ |
svacamatkṛtayo'ntasthāstadetāḥ sṛṣṭidṛṣṭayaḥ
]

`v 62 [
anubhūtaṃ kṛtaṃ kaṣṭaṃ yāvatkvacana kiṃcana |
paramārthacamatkārādṛte nehopalabhyate
]

`v 63 [
pratyekaṃ viśvarūpātmā sarvakartā nirāmayaḥ |
prabuddhaḥ śuddhabodhātmā sarvaṃ brahmātmakaṃ yataḥ
]

`v 64 [
sarvaḥ sarvatra sarvātmā sarvagaḥ sarvasaṃśrayaḥ |
etatprabuddhaviṣayamaprabuddhaṃ na vedmyaham
]

`v 65 [
ākāśakośaviśadātmani citsvarūpe yeyaṃ sadā kacati sargaparampareti |
sāntastadeva kila tāpa ivāntarūṣmā bhedopalambha iti nāsti sadastyanantam
]