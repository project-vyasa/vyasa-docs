`v 1 [
aṣṭatriṃśadadhikaśatatamaḥ sargaḥ 138
tāpasa uvāca |
gantumevaṃ vicāryāhaṃ tatastatsaṃvidaikatām |
pravṛttaścauttamābjena saurabheṇeva saurabham
]

`v 2 [
yāvattaccetanaṃ tasya tamojodhātumatyajam |
pravṛttaṃ bāhyasaṃvittau samastendriyasaṃvidā
]

`v 3 [
saṃvidaṃ saṃvidā gṛhṇaṃstānbāhye'ntarapi kṣaṇāt |
ahaṃ prasṛtavāṃstatra tailabindurivāmbhasi
]

`v 4 [
tatsaṃvidi tathaivātha yāvatpariṇamāmyaham |
bhuvanaṃ dṛṣṭavāṃstāvatsarvaṃ dviguṇitaṃ sthitam
]

`v 5 [
diśo dviguṇatāṃ yātāstapatastapanāvubhau |
bhūmaṇḍale dve saṃpanne dve vai dyāvai samutthite
]

`v 6 [
vadanapratibimbe dve darpaṇapratibimbite |
yathā bhātastathā bhāte miśrite te jagaccitam
]

`v 7 [
tailavadbhāti kośasthaṃ yaccetanatiladvaye |
tasmiñjagaddvayaṃn tattattathā bhāti vimiśritam
]

`v 8 [
saṃviddvitayakośaste miśrite apyamiśrite |
te ubhe jagatī bhāte same kṣīrajale yathā
]

`v 9 [
nimeṣāddṛṣṭamātreṇa sā tatsaṃvinmayā tataḥ |
sakalaivātmatāṃ nītā parimityeva saṃvidā
]

`v 10 [
ṛturṛtvantareṇeva saritevālpikā sarit |
vātenāmodalekheva dhūmalekheva vārmucā
]

`v 11 [
ekatvenāśu saṃvitteryayau me jagadekatām |
durdṛṣṭerdvivapuścandraḥ sudṛṣṭerekatāmiva
]

`v 12 [
tato me taccitisthasya svaṃ vivekamanujjhataḥ |
alpībhūtaḥ svasaṃkalpastatsaṃkalpasthitiṃ gataḥ
]

`v 13 [
taccittavṛttyaiva tato bāhyamālokayaṃstataḥ |
abhuñji taddinācāraṃ tattaddhṛdayamatyajan
]

`v 14 [
tato yadṛcchayaivāso śanairnidrākulo'bhavat |
padmaḥ sāyamivāpīya payo bhuktvānnamucchramaḥ
]

`v 15 [
prasṛtaṃ dignikuñjeṣu rūpālokakriyākaram |
saṃjahāra bahiścittaṃ sāyamarko ruciṃ yathā
]

`v 16 [
saha cittena tāstasya samastendriyavṛttayaḥ |
hṛtkośamaviśañchannāḥ kūrmasyevāṅgasaṃdhayaḥ
]

`v 17 [
mudritā hṛdayākārāsta āsaṃścakṣurādayaḥ |
loṣṭarūpā mṛtāveva lipikarmārpitā iva
]

`v 18 [
ahaṃ taccittavṛttyaiva sahasonnamya tatsthitaḥ |
taccittānuvidhāyitvāttattaddhṛdayamāviśam
]

`v 19 [
saṃhṛtya bāhyānubhavamantareva tadojasi |
kṣaṇamanvabhavaṃ śūnyaṃ suṣuptaṃ talpakomale
]

`v 20 [
klamānnapānabahulairnibiḍāsvapi nāḍiṣu |
suṣirāsveva vā vāyurna niryātyeva yāti ca
]

`v 21 [
yadā tadātmakātmaikaparo hṛdi sahasthitam |
apradhānīkarotyetaccittaṃ svārthasvabhāvataḥ
]

`v 22 [
svārthamātro'dya tasyāntaḥ parakṛtyaṃ na kasyacit |
kacati svārthasattāyāmetadeva vapuryataḥ
]

`v 23 [
śrīrāma uvāca |
manaḥ prāṇavaśādeva manute kiṃ mahāmune |
svarūpaṃ manaso nāsti tasmāttatkevalaṃ ca kim
]

`v 24 [
śrīvasiṣṭha uvāca |
deha eveha nāstyeva svānubhūto'pyayaṃ nijaḥ |
manasaḥ kalpanātmedaṃ vapuḥ svapne giriryathā
]

`v 25 [
taccittamapi nāstyeva cetyārthābhāvayogataḥ |
sargādau kāraṇābhāvāddṛśyānutpattihetutaḥ
]

`v 26 [
evaṃ cittasyāpi cetyārthanirūpyatvāccetyārthābhāve tatpṛthakkṛtaṃ svarūpaṃ
nāstītyapi suvacamityāha - taditi | pūrvapūrvacetyaṃ tannirūpakamiti cettatrāpyāha ##-
ataḥ sarvamidaṃ brahma tacca sarvātmakaṃ yadā |
tadā viśvamidaṃ viṣvagastyeva ca yathāsthitam
]

`v 27 [
brahmaṇaḥ sarvātmakatvāttatsattayā sattvoktau tu mana-ādisarvavastu astyevetyāha ##-
asti cittādi dehādi tadbrahmaiva ca tadvidām |
yādṛktattadvidāmetadasmākaṃ viṣaye na tat
]

`v 28 [
yathedaṃ trijagadbrahma yatheti vividhātmakam |
atremaṃ rājaputra tvaṃ varṇyamānaṃ kramaṃ śṛṇu
]

`v 29 [
asti cinmātramamalamanantākāśarūpi yat |
sarvadā sarvarūpātma na jaganna ca dṛśyatā
]

`v 30 [
sarvavittvāttu tenedaṃ manastvaṃ cetitaṃ svataḥ |
rūpamatyajatā śuddhaṃ buddhamādhivivarjitam
]

`v 31 [
manasā kalpitaṃ tena yadvai saraṇamātmanaḥ |
tadetatprāṇapavanaṃ viddhi vedyavidāṃ dhara
]

`v 32 [
prāṇataiṣā yathā tena kalpitevānubhūyate |
tathaivendriyadehādi dikkālakalanādi ca
]

`v 33 [
iti viśvamidaṃ viṣvak cittamātramakhaṇḍitam |
cittaṃ tu citparaṃ brahma tasmādbrahmedamātatam
]

`v 34 [
anākāramanādyantamanābhāsamanāmayam |
śāntaṃ cinmātrasanmātraṃ brahmaivedaṃ jagadvapuḥ
]

`v 35 [
sarvaśakti paraṃ brahma manaḥśaktyā yathā sthitam |
yatra tatra tathā rūpaṃ svamevānubhavatyalam
]

`v 36 [
saṃkalpātma mano brahma saṃkalpayati yadyathā |
tattathaivānubhavati siddhamābālamīdṛśam
]

`v 37 [
prāṇīkṛtaḥ svayamayaṃ nanu cetasātmā dehīkṛtastribhuvanīkṛta eva nādyaḥ
|
dehīkṛtaḥ khavapureva girīkṛtaśca svapneṣu kalpitapurīṣvanubhūtametat
]