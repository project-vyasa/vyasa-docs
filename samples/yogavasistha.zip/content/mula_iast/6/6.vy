`v 1 [
pdf 162, p. 1080
ṣaṣṭhaḥ sargaḥ 6
vidyādhara uvāca |
yadudāramanāyāsaṃ kṣayātiśayavarjitam |
padaṃ pāvanamādyantarahitaṃ tadvadāśu me
]

`v 2 [
etāvantamahaṃ kālaṃ supta āsaṃ jaḍātmakaḥ |
idānīṃ saṃprabuddho'smi prasādādātmano mune
]

`v 3 [
mano mahāmayottaptaṃ kṣubdhamajñānavṛttiṣu |
māmuddhara durantehaṃ mohādahamiti sthitāt
]

`v 4 [
śrīmatyapi etantyāśu śātanāḥ kātarādayaḥ |
guṇavatyugrapatre'pi tuhinānīva paṅkaje
]

`v 5 [
jāyante ca mriyante ca kevalaṃ jīrṇajantavaḥ |
na dharmāya na mokṣāya maśakā iva paṅkaje
]

`v 6 [
jñānābhāve devayonīnāṃ maśakādiyonisāmyameva dharmādhikārābhāvāditi
sūcayansvavairāgyahetuṃ sarvatra doṣadarśanaṃ prapañcayati - jāyante ityādinā | 5
|
bhāvaistaireva taireva tucchālambhaviḍambanaiḥ |
cireṇa parikhinnāḥ smo vipralambhāḥ punaḥ punaḥ
]

`v 7 [
nānto'styasya na ca sthairyāvasthā'viśrāntamānasam |
bhramato bhogabhaṅgeṣu marubhūmiṣvivādhvanaḥ
]

`v 8 [
āpātamadhurārambhā bhaṅgurā bhavahetavaḥ |
acireṇa vikāriṇyo bhīṣaṇā bhogabhūmayaḥ
]

`v 9 [
mānāvamānaparayā durahaṃkārakāntayā |
na rame vāmayā tāta hatavidyādharaśriyā
]

`v 10 [
dṛṣṭāścaitrarathodyānabhuvaḥ kusumakomalāḥ |
kalpavṛkṣalatādattasamastavibhavaśriyaḥ
]

`v 11 [
vihṛtaṃ merukuñjeṣu vidyādharapureṣu ca |
vimānavaramālāsu vātaskandhasthalīṣu ca
]

`v 12 [
viśrāntaṃ surasenāsu kāntābhujalatāsu ca |
hārihāravilāsāsu lokapālapurīṣu ca
]

`v 13 [
na kiṃciducitaṃ sādhu sarvamādhiviṣoṣmaṇā |
dagdhaṃ bhasmāyate tāta vijñātamadhunā mayā
]

`v 14 [
rūpālokanalolena vanitānanagṛdhnunā |
sāvabhāsena doṣāya duḥkhaṃ nītosmi cakṣuṣā
]

`v 15 [
idaṃ guṇāvahaṃ nedamiti muktvā vikalpanam |
rūpamātrānusāritvādavastunyapi dhāvati
]

`v 16 [
tāvadāyāti viratiṃ na vaśaṃ yāvadāpadām |
nānābandhaparaṃ cetaḥ parānarthehitonmukham
]

`v 17 [
ghrāṇametadanarthāya dhāvaccaivābhitaḥ sphuṭam |
na nivārayituṃ tāta śaknomīha hayaṃ yathā
]

`v 18 [
gandhodakapraṇālena mukhaśvāsānupātinā |
vairiṇevātidoṣeṇa ghrāṇenāsmi niyojitaḥ
]

`v 19 [
ciraṃ rasanayā cāhamanayā nayahīnayā |
gajagomāyugupteṣu duḥkhādriṣvalamāhataḥ
]

`v 20 [
nayo bhakṣyābhakṣyavibhāgaparaṃ śāstraṃ taddhīnayā |
kṛmikīṭapaśvādiyonilakṣaṇeṣu duḥkhādriṣu | surāpāḥ kṛmayo
bhavantyabhakṣyabhakṣiṇaśca ityādismṛteriti bhāvaḥ | yatra balavatāṃ gajo
buddhimatāṃ gomāyuśca śreṣṭha iti tayoreva goptṛtāprasaktirnānyasyeti tathoktiḥ | 19
|
niroddhuṃ na ca śaknomi sparśalampaṭatāṃ tvacaḥ |
grīṣmakālasamiddhasya tāpamaṃśumato yathā
]

`v 21 [
śubhaśabdarasārthinyo muneḥ śravaṇaśaktayaḥ |
māṃ yojayanti viṣame tṛṇecchā hariṇaṃ yathā
]

`v 22 [
praṇatāḥ priyakāriṇyaḥ prahvabhṛtyasamīritāḥ |
vādyageyaravonmiśrāḥ śubhaśabdaśriyaḥ śrutāḥ
]

`v 23 [
śriyaḥ striyo diśaścaiva taṭāścāmbhodhibhūbhṛtām |
dṛṣṭā vibhavahāriṇyaḥ prakvaṇanmaṇibhūṣaṇāḥ
]

`v 24 [
ciramāsvāditāḥ svādu camatkāramanoramāḥ |
prahvakāntājanānītāḥ ṣaḍrasā guṇaśālinaḥ
]

`v 25 [
kauśeyakāminīhārakusumāstaraṇānilāḥ |
nirvighnamabhitaḥ spṛṣṭā bhṛśamābhogabhūmiṣu
]

`v 26 [
vadhūmukhauṣadhīpuṣpasamālambhanabhūmayaḥ |
anubhūtā mune gandhā mandānilasamīritāḥ
]

`v 27 [
śrutaṃ spṛṣṭaṃ tathā dṛṣṭaṃ bhuktaṃ ghrātaṃ punaḥ punaḥ |
saṃśuṣkavirasaṃ bhūyaḥ kiṃ bhajāmi vadāśu me
]

`v 28 [
bhuktvā varṣasahasrāṇi durbhogapaṭalīmimām |
ābrahmastambaparyantaṃ na tṛptirupajāyate
]

`v 29 [
sāmrājyaṃ suciraṃ kṛtvā tathā bhuktvā vadhūgaṇam |
bhaṃktvā parabalānyuccaiḥ kimapūrvamavāpyate
]

`v 30 [
yeṣāṃ vināśanaṃ nāsīdyairbhuktaṃ bhuvanatrayam |
te'pi te'pyacireṇaiva samaṃ bhasmapadaṃ gatāḥ
]

`v 31 [
prāptena yena no bhūyaḥ prāptavyamavaśiṣyate |
tatprāptau yatnamātiṣṭhetkaṣṭayāpi hi ceṣṭayā
]

`v 32 [
yena kāntāściraṃ bhuktā bhogāstasyeha jantubhiḥ |
dṛṣṭo na kasyacinmūrdhni tarurvyomaplavaśca vā
]

`v 33 [
ciramāsu durantāsu viṣayāraṇyarājiṣu |
indriyairvipralabdho'smi dhūrtabālairivārbhakaḥ
]

`v 34 [
adya tvete parijñātā mayā svaviṣayārayaḥ |
kaṣṭā indriyanāmāno vañcayitvā tu māṃ punaḥ
]

`v 35 [
saṃsārajaṅgale śūnye dagdhaṃ naramṛgaṃ śaṭhāḥ |
āśvāsyāśvāsya nighnanti viṣayendriyalubdhakāḥ
]

`v 36 [
viṣamāśīviṣairebhirviṣayendriyapannagaiḥ |
yena dagdhā na dṛṣṭāste dvitrā eva jagatyapi
]

`v 37 [
bhogabhīmebhavalitāṃ tṛṣṇātaralavāgurām |
lobhograkaravālāḍhyāṃ kopakuntakulāṅkitām
]

`v 38 [
dvandvajālarathavyāptāmahaṃkārānupālitām |
ceṣṭāturaṃgamākīrṇāṃ kāmakolāhalākulām
]

`v 39 [
śarīrasīmāntagatāṃ durindriyapatākinīm |
ye jetumutthitāstāta ta eveha hi sadbhaṭāḥ
]

`v 40 [
susādhyaḥ karaṭodbhedo mattairāvaṇadantinaḥ |
notpathapratipannānāṃ svendriyāṇāṃ vinigrahaḥ
]

`v 41 [
pauruṣasya mahattvasya sattvasya mahataḥ śriyaḥ |
indriyākramaṇaṃ sādho sīmānto mahatāmapi
]

`v 42 [
tāvaduttamatāmeti pumānapi divaukasām |
kṛpaṇairindriyairyāvattṛṇavannāpakṛṣyate
]

`v 43 [
jitendriyā mahāsattvā ye ta eva narā bhuvi |
śeṣānahamimānmanye māṃsayantragaṇāṃścalān
]

`v 44 [
manaḥsenāpateḥ senāmimāmindriyapañcakam |
jetuṃ cedasti me yatno jayāmi tadalaṃ mune
]

`v 45 [
indriyottamarogāṇāṃ bhogāśāvarjanādṛte |
nauṣadhāni na tīrthāni na ca mantrāśca śāntaye
]

`v 46 [
nīto'smi paramaṃ khedamabhidhāvadbhirindriyaiḥ |
eka eva mahāraṇye taskaraiḥ pathiko yathā
]

`v 47 [
paṅkavantyaprasannāni mahādaurbhāgyavanti ca |
gandhiśaivalatucchāni palvalānīndriyāṇi ca
]

`v 48 [
duratikramaṇīyāni nīhāragahanāni ca |
janitātaṅkajālāni jaṅgalānīndriyāṇi ca
]

`v 49 [
paṅkajāni sarandhrāṇi sudurlakṣyaguṇāni ca |
granthimanti jaḍāṅgāni mṛṇālānīndriyāṇi ca
]

`v 50 [
rūkṣāṇi ratnalubdhāni kallolavalitāni ca |
durgrahagrāhaghorāṇi kṣārāmbūnīndriyāṇi ca
]

`v 51 [
bāndhavodvegadāyīni dehāntarakarāṇi ca |
karuṇākrandakārīṇi maraṇānīndriyāṇi ca
]

`v 52 [
avivekiṣvamitrāṇi mitrāṇi ca vivekiṣu |
gahanānantaśūnyāni kānanānīndriyāṇi ca
]

`v 53 [
ghanāsphoṭānyasārāṇi malināni jaḍāni ca |
vidyutprakāśānyetāni bhīmābhrāṇīndriyāṇi ca
]

`v 54 [
kṣudraprāṇigṛhītāni varjitāni kṛtātmabhiḥ |
rajastamobhibhūtāni svendriyāṇyavaṭāni ca
]

`v 55 [
kṣudraistucchasukhāsaktaiḥ kīṭādibhiśca parigṛhītāni | avaṭāni gartotkarasthalāni | 54
|
pātanaikāntadakṣāṇi doṣāśīviṣavanti ca |
rūkṣakaṇṭakalakṣāṇi śvabhrāgrāṇīndriyāṇi ca
]

`v 56 [
ātmaṃbharīṇyanāryāṇi sāhasaikaratāni ca |
andhakāravihārīṇi rakṣāṃsi svendriyāṇi ca
]

`v 57 [
antaḥśūnyānyasārāṇi vakrāṇi granthimanti ca |
dahanaikārthayogyāni durdārūṇīndriyāṇi ca
]

`v 58 [
ghanamohaprabandhīni duṣkūpagahanāni ca |
mahāvakaratucchāni kupurāṇīndriyāṇi ca
]

`v 59 [
ananteṣu padārtheṣu kāraṇāni ghaṭādiṣu |
saṃbhramāṇi sapaṅkāni cakrakāṇīndriyāṇi ca
]

`v 60 [
āpannimagnamimamevamakiṃcanaṃ tvaṃ māmuddharoddharaṇaśīla dayodayena |
ye nāma kecana jagatsu jayanti santastatsaṃgamaṃ paramaśokaharaṃ vadanti
]