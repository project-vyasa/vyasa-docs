`v 1 [
pañcatriṃśaḥ sargaḥ 35
śrīvasiṣṭha uvāca |
deśāddeśāntaraṃ dūraṃ prāptāyāḥ saṃvidaḥ kṣaṇāt |
yadrūpamamalaṃ madhye paraṃ tadrūpamātmanaḥ
]

`v 2 [
gacchañchṛṇvanspṛśañjighrannunmiṣannimiṣanhasan |
nūnaṃn nirāmayatvāya nityametanmayo bhava
]

`v 3 [
tata eva nirābhāsātsatyānnirvāsanaiṣaṇāt |
yathāsthitaṃ yathācāramacalā'maraśailavat
]

`v 4 [
etadrūpamavidyāyāḥ prekṣitā yanna labhyate |
prekṣitā labhyate cetsā tadvidyaiva parābhavat
]

`v 5 [
avidyāsaṃbhavāccetyacittve saṃbhavataḥ kva kim |
cetyate kathamevāntaḥ śāntireva baloditā
]

`v 6 [
satyaṃ brahma jagaccaikaṃ sthitamekamanekavat |
sarvaṃ vā'sarvavadbhāti śuddhaṃn cāśuddhavattatam
]

`v 7 [
aśūnyaṃ śūnyamiva ca śūnyaṃn vā'śūnyavatsphuṭam |
sphāramasphāramiva tadasphāraṃ sphārasannibham
]

`v 8 [
avikāraṃ vikārīva samaṃ śāntamaśāntavat |
sadevāsadivādṛśyaṃ tadevātadivoditam
]

`v 9 [
avibhāgaṃ vibhāgīva nirjāḍyaṃ jaḍavadgatam |
acetyaṃn cetyabhāvīva niraṃśaṃ sāṃśaśobhanam
]

`v 10 [
anahaṃ so'hamiva tadanāśamiva nāśavat |
akalaṅkaṃ kalaṅkīva nirvedyaṃ vedyavāhivat
]

`v 11 [
āloki dhvāntaghanavannavavacca purātanam |
paramāṇorapi tanu garbhīkṛtajagadgaṇam
]

`v 12 [
sarvātmakamapi tyaktadṛṣṭaṃ kaṣṭena bhūyasā |
ajālamapi jālāḍhyaṃ cāśeṣavadanekadhā
]

`v 13 [
nirmāyamapi māyāṃśumaṇḍalāmalabhāskaram |
brahma viddhi vidāṃnāthamapāmiva mahodadhim
]

`v 14 [
jagadratnamahākośaṃ tulāyāṃ tūlakāllaghu |
māyāmarīciśaśinamapi nekṣaṇagocaram
]

`v 15 [
anantamapi niṣpāraṃ na ca kvacidapi sthitam |
ākāśe vanavinyāsanaganirmāṇatatparam
]

`v 16 [
aṇīyasāmaṇīyāṃsaṃ sthaviṣṭhaṃ ca sthavīyasām |
garīyasāṃ gariṣṭhaṃ ca śreṣṭhaṃ ca śreyasāmapi
]

`v 17 [
akartṛkarmakaraṇamakāraṇamakārakam |
antaḥśūnyatayaivaitaccirāya paripūritam
]

`v 18 [
jagatsamudgakamapi nityaṃ śūnyamaraṇyavat |
anantaśailakaṭhinamapyākāśalavānmṛdu
]

`v 19 [
pratyekaṃ pratyahaṃ prāyaḥ purāṇaṃ pelavaṃ navam |
ālokamandhakārābhaṃn tamastvālokamātatam
]

`v 20 [
pratyakṣamapi durlakṣyaṃn parokṣamapi cāgragam |
cidrūpameva ca jaḍaṃ jaḍameva cidātmakam
]

`v 21 [
ahamevānahaṃbhāvamanahaṃ vā'hameva ca |
anyadeva tadevāhamahamevānyadeva tat
]

`v 22 [
asya pūrṇārṇavasyāntarime tribhuvanormayaḥ |
sphuranta iva tiṣṭhanti svabhāvadravatātmakāḥ
]

`v 23 [
bibharti sarvamaṅgasthaṃ tuṣāramiva śuklatām |
bhāti sarvastvanenaiva tuṣāreṇeva śuklatā
]

`v 24 [
adeśakālāvayavo'pyeṣa devo divāniśam |
asajjagattanotīva yathā vāritaraṅgakam
]

`v 25 [
etasminvikasantīmā vipulākāśakānane |
jagajjaraṭhamañjaryaḥ prasaratpatrapañcakāḥ
]

`v 26 [
eṣa svapratibimbasya svayamālokanecchayā |
atyantanirmalākāraḥ svayaṃ mukuratāṃ gataḥ
]

`v 27 [
vyomavṛkṣaphalasyāsya svecchāvayava ujjvalāḥ |
sargopalambha udyacca camatkurvanti saṃvidi
]

`v 28 [
antasthena bahiṣṭhena nānānānātayātmani |
eṣa so'ntarbahirbhāti bhāvābhāvavibhāvayā
]

`v 29 [
etadrūpā padārthaśrīretasminnetadicchayā |
camatkarotyetadarthaṃ jihneva svāsyakoṭare
]

`v 30 [
asyāmbhaso dravatvaṃ yattadidaṃ jagaducyate |
saṃvitsvādūpalambhāṅgaṃ bhuvanāvartavṛttimat
]

`v 31 [
śāmyatyatra padārthaśrīḥ sarvāsāmeva bhāsvati |
etasmādeva codeti svāloka iva tejasaḥ
]

`v 32 [
idameva jagatsarvaṃ śuklatvaṃ tuhine yathā |
atae etāḥ pravartante vida indorivāṃśavaḥ
]

`v 33 [
idaṃ brahmā | ato'syā vidaścidrūpabrahmaṇaḥ sakāśāt | etāḥ padārthaśriyaḥ | 32 |
etasmādraṅgato'naṅgājjagaccitramidaṃ sthitam |
viddhyabhāvavikārādiśāntametanmayaṃ tatam
]

`v 34 [
asmādvanataroretāḥ svarūḍhā gaganāṅgaṇe |
dṛśyaśākhāḥ pravartante jagajjālagulucchakāḥ
]

`v 35 [
vyayodayavatī nūnamatra dṛśyataraṅgiṇī |
nānātānantakusumā vahatyavicalācale
]

`v 36 [
asminvyomātmake raṅge bhuvanābhinayabhramaiḥ |
nṛtyatyaviratārambhaṃ vārairniyatinartakī
]

`v 37 [
jagatkoṭimahākalpakalponmeṣanimeṣaṇaḥ |
vitāne nāṭyate bhūyo janyate kālabālakaḥ
]

`v 38 [
udyatsvapi jagatsveṣa śāntamevāvatiṣṭhate |
aniccha eva mukuraḥ pratibimbaśateṣviva
]

`v 39 [
bhūtānāṃ vartamānānāṃ sargāṇāṃ saṃbhaviṣyatām |
eṣo'kāraṇakaṃ bījaṃ sargāṇāmiva kāraṇam
]

`v 40 [
asyonmeṣo jagallakṣmīrnimeṣaḥ pralayāgamaḥ |
anunmeṣanimeṣo'sāvātmanyevāvatiṣṭhate
]

`v 41 [
udyantyamūni subahūni mahāmahānti sargāgamapralayajanmadaśā jaganti |
sarvāṇi tānyayamapārasvarūpa eva praspandanāni marudeva yathāsva śāntam
]