`v 1 [
aśītyadhikaśatatamaḥ sargaḥ 180
śrīrāma uvāca |
imaṃ me saṃśayaṃ chindhi bhagavanbhāskaraṃ tamaḥ |
bhuvanasyeva bhāvānāṃ samyagrūpānubhūtaye
]

`v 2 [
kadācidahamekāgro vidyāgehe vipaścitām |
saṃsadi sthitavānyāvattāpasaḥ kaścidāgataḥ
]

`v 3 [
vidvāndvijavaraḥ śrīmānvidehajanamaṇḍalāt |
mahātapāḥ kāntiyuto durvāsā iva duḥsahaḥ
]

`v 4 [
sa praviśyābhivādyāśu sabhāmābhāsvaradyutim |
upaviśyāsane tiṣṭhannasmābhirabhivāditaḥ
]

`v 5 [
vedāntasāṃkhyasiddhāntavādānsaṃhṛtya sattamam |
sukhopaviṣṭaṃ viśrāntaṃ tamahaṃ pṛṣṭavānidam
]

`v 6 [
dīrghādhvanā pariśrāntaḥ sayatna iva lakṣyase |
vadādya vadatāṃ śreṣṭha kuta āgamanaṃ kṛtam
]

`v 7 [
brāhmaṇa uvāca
evametanmahābhāga sumahāyatnavānaham |
yadarthamāgato'smīha tasyākarṇaya nirṇayam
]

`v 8 [
vaideho nāma deśo'sti sarvasaubhāgyasaṃyutaḥ |
svargasyāmbarasaṃsthasya pratibimbamivāvanau
]

`v 9 [
tatrāhaṃ brāhmaṇo jātaḥ prāptavidyaśca saṃsthitaḥ |
kundāvadātadantatvātkundadanta iti śrutaḥ
]

`v 10 [
athāhaṃ jātavairāgyaḥ pravihartuṃ pravṛttavān |
devadvijamunīndrāṇāṃ saṃbhramācchramaśāntaye
]

`v 11 [
śrīparvatamakhaṇḍehaṃ kadācitprāptavānaham |
tatrāvasaṃ ciraṃ kālaṃ mṛdu dīrghaṃ tapaścaran
]

`v 12 [
tatrāstyaraṇyaṃ viditaṃ muktaṃ tṛṇavanādibhiḥ |
tyaktatejastamobhrādibhūmāviva nabhastalam
]

`v 13 [
tatrāsti madhye viṭapī laghuḥ pelavapallavaḥ |
sthita eṣo'mbare śūnye mandaraśmirivāṃśumān
]

`v 14 [
lambate tasya śākhāyāṃ puruṣaḥ prāvanākṛtiḥ |
bhānurbhānāviva raśmigṛhīto grathitākṛtiḥ
]

`v 15 [
mauñjadāmanibaddhordhvapādo nityamavākśirāḥ |
aṣṭhīlatvaṃ dadhadiva mahāṣṭhīlasya śālmaleḥ
]

`v 16 [
tadeva spaṣṭamāha - mauñjeti | aṣṭhīlatvaṃ pralambaparvagranthibhāvaṃ dadhadiva |
15 |
dṛṣṭaḥ prāptena taṃ deśaṃ sa kadācinmayā pumān |
vicārito nikaṭato vakṣaḥsthāñjalisaṃpuṭaḥ
]

`v 17 [
yāvajjīvatyasau vipro niḥśvasityahatākṛtiḥ |
śītavātātapasparśānsarvānvetti ca kālajān
]

`v 18 [
anantaramasāveko nopacarya mayā bahūn |
divasātapakhedena viśrambhe pātitaḥ śanaiḥ
]

`v 19 [
pṛṣṭaśca ko'si bhagavankimarthaṃ dāruṇaṃ tapaḥ |
karoṣīdaṃ viśālākṣa lakṣyālakṣyātmajīvitaḥ
]

`v 20 [
atha tenoktamarthaste ka ivānena tāpasa |
arthe nātivicitrā hi bhavantīcchāḥ śarīriṇām
]

`v 21 [
ityuktavānprayatnena so'nubandhena vai mayā |
yadā pṛṣṭastadā tena mamoktamidamuttaram
]

`v 22 [
mathurāyāmahaṃ jāto vṛddhiṃ yātaḥ piturgṛhe |
bālyayauvanayormadhye sthitaḥ padapadārthavit
]

`v 23 [
samagrasukhasaṃbhārakośo bhavati bhūmipaḥ |
ityahaṃ śrutavāṃstatra bhogārthī navayauvanaḥ
]

`v 24 [
atha saptamahādvīpavistīrṇāyā bhuvaḥ patiḥ |
syāmityahamudārātmā paribimbitavāṃściram
]

`v 25 [
ityarthena samāgatya deśamitthamahaṃ sthitaḥ |
atra dvādaśa varṣāṇi samatītāni mānada
]

`v 26 [
tadakāraṇamitra tvaṃ gaccheṣṭaṃ deśamāśugaḥ |
ahaṃ cābhimataprāpteritthameva dṛḍhasthitiḥ
]

`v 27 [
iti tenā'hamuktaḥ saṃstamitthaṃ proktavāñchṛṇu |
āścaryaśravaṇe cetaḥ khedameti na dhīmataḥ
]

`v 28 [
sādho yāvattvayā prāpto na nāmābhimato varaḥ |
tvadrakṣāparicaryārthamiha tāvadahaṃ sthitaḥ
]

`v 29 [
tāvatkālamahamapi tava rakṣārtha paricaryā sevā tadartha ca sthito bhaviṣyāmītyarthaḥ | 28
|
mayetyukte sa pāṣāṇamaunavānabhavacchamī |
nimīlitekṣaṇaḥ kṣīṇarūpastvakalano bahiḥ
]

`v 30 [
tathāhaṃ puratastasya kāṣṭhamaunavato'vasam |
ṣaṇmāsānvigatodvegaṃ vegānkālakṛtānsahan
]

`v 31 [
arkabimbādviniṣkramya tatpradeśāntare sthitam |
ekadā dṛṣṭavānasmi puruṣaṃ bhānubhāsvaram
]

`v 32 [
tasminpradeśāntare tasya tāpasasya purodeśe āgatya sthitaṃ bhānubhāsvaraṃ puruṣam |
31 |
sa tena pūjyate yāvanmanasā karmaṇā mayā |
uvāca tāvadvavanamamṛtasyandasundaram
]

`v 33 [
śākhāpralambanapara he brahmandīrghatāpasa |
tapaḥ saṃhara saṃhāri gṛhāṇābhimataṃ varam
]

`v 34 [
saptābdhidvīpavalayāṃ pālayiṣyasi medinīm |
saptavarṣasahasrāṇi dehenānena dharmataḥ
]

`v 35 [
anena dehena kṛtāttapodharmatona tvanena dehena pālayiṣyasīti | uttaragranthavirodhāt | 34
|
evaṃ samīhitaṃ dattvā sa dvitīyo divākaraḥ |
gantumastamathārkābdhimaviśatprodito yataḥ
]

`v 36 [
tasminyāte mayā proktaṃ tasya śākhātapasvinaḥ |
śrutadṛṣṭānubhūtāgryavaradasya vivekinaḥ
]

`v 37 [
saṃprāptābhimataṃ brahmaṃstaruśākhāvalambanam |
tapastyaktvā yathāprāptaṃ vyavahāraṃ samācara
]

`v 38 [
evamaṅgīkṛtavataḥ pādau tasya mayā tataḥ |
muktau viṭapinastasmādālānātkālabhāviva
]

`v 39 [
snātaḥ pavitrahasto'sau cakre japtvāghamarṣaṇam |
phalena puṇyalabdhena viṭapādvratapāraṇam
]

`v 40 [
tatpuṇyavaśataḥ prāptaiḥ svādubhistaistaroḥ phalaiḥ |
samāśvastāvasaṃkṣubdhāvāvāṃ tatra dinatrayam
]

`v 41 [
saptadvīpasamudramudritadiśaṃ bhoktuṃ samagrāṃ mahīṃ vipraḥ
pādapalambitena vapuṣā taptvordhvapādastapaḥ |
saṃprāpyābhimataṃ varaṃ dinakṛto viśvasya cāhnāṃ trayaṃ sārdhaṃ
matsuhṛdā svameva sadanaṃ gantuṃ pravṛtto'bhavat
]