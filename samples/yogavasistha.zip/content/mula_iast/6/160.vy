`v 1 [
ṣaṣṭyadhikaśatatamaḥ sargaḥ 160
śrīvālmīkiruvāca |
vipaściti vadatyevaṃ tadvṛttāntamavekṣitum |
iva lokāntaraṃ bhānuḥ pādairdūrāyatairyayau
]

`v 2 [
udabhūtpūrayannāśā dinaparyantadundubhiḥ |
tuṣṭābhiriva nirmukto digbhirjayajayāravaḥ
]

`v 3 [
āśā diśaḥ | dinaparyantaḥ sāyaṃkālastatsūcako dundubhiḥ | tuṣṭābhiriti tatrotprekṣā | 2
|
vipaścite daśaratho gṛhadāradhanādikam |
rājyānurūpaṃ vibhavaṃ prottasthau kalpayankramāt
]

`v 4 [
rājarāmavasiṣṭhādyā mithaḥ kṛtvā visarjanaṃ |
yathākramaṃ pūjanaṃ ca prayayuḥ svāspadāni te
]

`v 5 [
snātvā bhuktvā niśāṃ nītvā prabhāte punarāyayuḥ |
tenaiva saṃniveśena sā sabhā saṃsthitā'bhavat
]

`v 6 [
kramānmuniruvācātha tāṃ yathāprastutāṃ kathām |
śaśīvāmṛtamāhlādamudgiranmukhadīptibhiḥ
]

`v 7 [
rājanneyamavidyeyamasatyeva satī sthitā |
nedṛśenāpi yatnena nirṇītaiṣā vipaścitā
]

`v 8 [
avidyaivamavijñātā cirānantāvabhāsate |
parijñātā tu nāstyeva mṛgatṛṣṇānadī yathā
]

`v 9 [
mantriṇaste mahābuddhe bhāsasyāsya vipaścitaḥ |
itivṛttaṃ tvamityasya svayameva hi dṛṣṭavān
]

`v 10 [
sadṛśo'yamitastvābhiḥ kathābhirjñātatatpadaḥ |
avidyāyāṃ praśāntāyāṃ jīvanmukto bhaviṣyati
]

`v 11 [
avidyeti dhṛtā saṃvidbrahmaṇātmani sattayā |
tadbhrameṇāsadapyasyāḥ sadrūpamiva lakṣyate
]

`v 12 [
yadā brahmātmikaiveyamavidyā netarātmikā |
tadāstyeṣā'parijñātā parijñātā na bhidyate
]

`v 13 [
avidyaivamananteyaṃ nānāprasavaśālinī |
jaḍā hṛdyā rasamayī mohamādhavamañjarī
]

`v 14 [
antaśūnyā granthimatī ślakṣṇā svaṅkurakaṇṭakā |
jaḍā rasamayī dīrghā lateva vanavaiṇavī
]

`v 15 [
phalāśaṅkā mudhaivātiniṣphalā cittahāriṇī |
akālapuṣpamāleva śreyasā nābhinanditā
]

`v 16 [
na kiṃcidrūpiṇī pīnā nānābhuvanapūriṇī |
bhūtākulā nirālokā sudīrgheva tamomayī
]

`v 17 [
keśoṇḍrakabhrāntiriva vicitragranthiveṣṭanā |
mithyaiva dṛśyamānā khe'dṛśyamānā na kiṃcana
]

`v 18 [
avicitravarṇā viguṇā śūnye ca vitatākṛtiḥ |
jaḍaspandotpātamayī śakracāpalateva khe
]

`v 19 [
jaḍakallolabahulā kaluṣollāsaphenilā |
cakrāvartākṣayamayī prāvṛṣīva taraṅgiṇī
]

`v 20 [
anāratavahacchūnyajaganmṛganadīśatā |
rajorāśimayī rūkṣā śavabhūriva durbhagā
]

`v 21 [
antaṃ prāpnoti na yathā ciraṃ svapnapure caran |
jāgradākhye svapnapure tathaivāsmiṃściraṃ caran
]

`v 22 [
yāni saṃkalpajālāni pratiṣṭhāmāgatānyalam |
tyaktaikadṛśyajālasthadehānāṃ dṛḍhacetasām
]

`v 23 [
sthitāni tāni cidvyoma kośaratnānyasaṃkaṭam |
vimānapurabhūmyādirūpeṇetthaṃ sthitātmanā `note[sthirātmaneti kvacitpāṭhaḥ |
]
]

`v 24 [
tānyeva siddhasadmāni vyomni bhānti parasparam |
adṛṣṭānyapyasaṃkhyāni sūpalabdhānyasantyapi
]

`v 25 [
suvarṇamaṇimāṇikyamuktāvanimayāni ca |
bhakṣyabhojyānnapānāḍhyarasāyanasarāṃsi ca
]

`v 26 [
madhumadyadadhikṣīraghṛtakulyākulāni ca |
rasāyanamayākāravanitāvalitāni ca
]

`v 27 [
sarvartupuṣpaphalapallavapūravanti līlāvilolalalanākulitālayāni |
saṃkalpamātraracanena ca sarvakālaṃ saṃpannasarvavibhavotkarasaṃkulāni
]

`v 28 [
sahasracandrabimbāni śatasūryāṇi kānicit |
suvarṇāmṛtaveṣāmbumayabhūtāni kānicit
]

`v 29 [
svecchātamaḥprakāśāni nityānandamayāni ca |
kānicinnīyamānāni tanutūlalaghūni ca
]

`v 30 [
kṣaṇotpattivināśāni kānicitkalanāvaśāt |
anantasvannapānāni nirjarāmaraṇāni ca
]

`v 31 [
vicitrasaṃniveśāni vicitravibhavāni ca |
sarvartuguṇaramyāṇi sarvakāmamayāni ca
]

`v 32 [
tāni saṃkalpajālāni kila kalyāṇakārataḥ |
sthirāṇāṃ manasāṃ bhittiḥ kathamevaṃ bhavettu sā
]

`v 33 [
nānyatkiṃcana nāmeha brahmamātramayātmani |
saṃbhavatyaṅga tenaitaducyatāmastu kiṃmayam
]

`v 34 [
sargādāveva sargādi kiṃcanāpīdamasti no |
kāraṇābhāvatastena jagatkiṃmayamastvidam
]

`v 35 [
saṃkalpyante nirantāni kila tāni yathā yathā |
citau tathā tathā bhānti kevātra vada citratā
]

`v 36 [
idānīmapi he sādho tvamapyanye'pi ke'pi vā |
tīvrasaṃvegasaṃkalpanagarāṇyevameva khe
]

`v 37 [
kurvantyekarasābhyāsādyadi nāma yadṛcchayā |
tattānīdaṃ vapustyaktvā prāpnuvantyacireṇa khe
]

`v 38 [
yastvidaṃ kalpitaṃ ca dve vastunī anuvartate |
svargādivadavāpnoti prāpnotyevaikamekadhīḥ
]

`v 39 [
siddhāḥ sadā vibhāntyevaṃ yathāntaḥkalpanāvaśāt |
narakādīni duḥkhāni tathaivābhānti kalpanāt
]

`v 40 [
yadyatsaṃvedyate kiṃcittattathāpyanubhūyate |
sati vā'sati dehe'smindeha eva manomayaḥ
]

`v 41 [
jīvastyajati yadbhāve ekāṃ dehamayīṃ dhiyam |
tadbhāvaikamayīmanyāmāśu tatraiva paśyati
]

`v 42 [
śubhā saṃvicchubhāṁllokānsaṃpaśyatyaśubhā'śubhān |
khātmikā khātmakāneva ciraṃ vānubhavatyapi
]

`v 43 [
śuddhā siddhapurāṇyeva paśyatyanubhavatyapi |
cidaśuddhāni rūpāṇi duḥkhāni narakeṣvati
]

`v 44 [
ghūrṇatpāṣāṇayamalagiricakrakapeṣaṇam |
tatrāndhakūpapatanaṃ punaruddhāravarjitam
]

`v 45 [
dāruṇenātiśītena dehaṃ pāṣāṇatāṃ gatam |
bhūtāṅgāramayānantamarumārgāspadaṃ vapuḥ
]

`v 46 [
pūtāṅgāramayāmbhodasaradaṅgāravarṣaṇam |
taptanārācanikaraparuṣāsāradāruṇam
]

`v 47 [
avahatpāṣāṇacakrāsisaridākāśasaṃcaram |
vakṣomuktāmbudākārakuṭhārāghātabhedanam
]

`v 48 [
taptāyaḥparuṣāśleṣacchamicchamitimajjanam |
bṛhatkaṭakaṭāśabdaśastrayantranipīḍanam
]

`v 49 [
cakravajragadāprāsaśūlāsiśaravarṣaṇam |
śālmalīgrahaṇaṃ pāśaṃ `note[pāśabandhanam |] kuśaktiśatatodanam
]

`v 50 [
taptasaikatasaṃbhārapātapātālamajjanam |
dīpacchannānalabhayaṇm bṛhadvāyasacarvaṇam
]

`v 51 [
nirnirgamākṛśāṅgāramahāṅgārapraveśanam |
śaraśaktigadāprāsabhuśuṇḍīcakravedhanam
]

`v 52 [
kṣutkṣobhaparuṣapretavrātānyonyāṅgacarvaṇam |
tālottālātiparuṣaśilātalanipātanam
]

`v 53 [
rudhirāmedhyapaṅkāṅkapūyanadyādisaṃkaṭam |
śilāśastramayāśvebhapādapāṣāṇapeṣaṇam
]

`v 54 [
śvabhrābholūkalikhitaṃ janaughamusalāhatam |
śiraḥkarakhuraskandhakhaṇḍotkagṛdhramaṇḍalam
]

`v 55 [
etasmātkukṛtādetatphalamityeva bhāvanāt |
paśyatyevaṃdeśadṛḍhādavisaṃvādivistṛtaḥ
]

`v 56 [
yannāma kiṃcana kadācana cetanaṃ khe bhātaṃ na bhātamathavā yadapūrvameva |
tatkalpanādbhavati tanmayameva taddhi tasmācciraṃ ca calatīti yadṛcchayaiva
]