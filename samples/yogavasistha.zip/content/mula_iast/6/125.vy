`v 1 [
pañcaviṃśatyadhikaśatatamaḥ sargaḥ 125
śrīvasiṣṭha uvāca |
varṣe śāntabhayābhikhye jaladhāre girau tarau |
tādṛkkartaripānīyaṃ śākadvīpe piban sthitaḥ
]

`v 2 [
pūrvo'tha varṣasaptatyā pāścātyenaitya mokṣitaḥ |
vidyayā krakaceneva chittvā vṛkṣatvamakṣataḥ
]

`v 3 [
pāścātyaḥ śiśire varṣe pāṣāṇatvamupāgataḥ |
mocito dakṣiṇenāśu gomāṃsādiprayogataḥ
]

`v 4 [
śive'stācalapārasthe varṣe varṣeṇa paścimaḥ |
mocito dakṣiṇenaitya gopiśācyā vṛṣīkṛtaḥ
]

`v 5 [
atraiva kṣemake varṣe āmbikeyagirau tarau |
dakṣiṇo yakṣatāṃ yāto mokṣaṃ yakṣeṇa labdhavān
]

`v 6 [
atraiva vṛṣake `note[kṣemake varṣe iti pāṭhaḥ |] varṣe śaile kesaranāmani |
kesaritvaṃ gataḥ pūrvaḥ pāścātyenaiva mocitaḥ
]

`v 7 [
śrīrāma uvāca |
ekadeśagatā viṣvagvyāpya karmāṇi kurvate |
yoginastriṣu kāleṣu sarvāṇi bhagavankatham
]

`v 8 [
śrīvasiṣṭha uvāca |
iha rāmāprabuddhānāṃ yadastyastvalameva naḥ |
tena yattu prabuddhānāṃ tadidaṃ śṛṇu kathyate
]

`v 9 [
cinmātrasattāsāmānyādṛte'nyannātma tadvidām |
dṛśyātyantābhāvabodhe sargāsargadṛśoḥ kṣaye
]

`v 10 [
cinmātrasattāsāmānye viśrāntasya nirantaram |
sarveśasyeha sarvatvaṃ sarvātmatvaṃ ca sarvadā
]

`v 11 [
vada kena kathaṃ kutra kadā kimiva rodhyate |
sarvagastvatha sarvātmā yatra bhāti yadā yathā
]

`v 12 [
tathā bhāti tadā tatra sarvātmani kimasti no |
atītaṃ vartamānaṃ ca bhaviṣyatsthūlamapyaṇu
]

`v 13 [
tathā dūramadūraṃ ca nimeṣaḥ kalpa eva ca |
svarūpamajahatyeva sāmānye tāni sarvadā
]

`v 14 [
sarvātmani sthitānyeva paśya māyāvijṛmbhitam |
ajātamaniruddhaṃ ca yathāsthitamavasthitam
]

`v 15 [
vijñānaghanamevedamata eva jagattrayam |
nabhastvamatyajaṃścaiva sarvātmaiva nabhaḥ sthitam
]

`v 16 [
jagadātmā jagadrūpaṃ draṣṭṭadṛśyatayoditam |
viśvātmadṛgvapuryatsyāttatkiṃ kena kathaṃ kadā
]

`v 17 [
duḥsādhyaṃ brūhi tattvajña sādhyāsādhyasvarūpiṇaḥ |
tasmādasyāḥ sadaikasyā vipaścidrājasaṃvidaḥ
]

`v 18 [
prabodhamanugacchantyā aprāptāyāḥ paraṃ padam |
ekasyā apyanekasyāḥ sarvaṃ sarvatra yujyate
]

`v 19 [
bodhābodhātmarūpe hi kiṃ nāmāsti parātmani |
aprāptāyāḥ paraṃ bodhaṃ padārthākulatocitā
]

`v 20 [
kiṃcidbodhaṃ praviṣṭāyāḥ siddhatāpyucitaiva sā |
evaṃ te sarvadiksamsthāḥ sarvameva parasparam
]

`v 21 [
paśyantyanubhavantyāśu cikitsante ca saṃkaṭam |
bodhākāśaḥ svakādrūpādīṣaccyuta ivāśu cet
]

`v 22 [
tadanyatāmivādatte susthito'pi yathāsthitam |
śrīrāma uvāca |
vipaścitaḥ prabuddhāścetkathaṃ siṃhavṛṣāditām
]

`v 23 [
dikṣu yāntīti me brahmanbodhāya kathayāśvalam |
śrīvasiṣṭha uvāca |
prabuddhāḥ kathitā ye te yoginaste mayānatha
]

`v 24 [
tvayā yoginaḥ kathaṃ vyāpya karmāṇi kurvate iti pṛṣṭamiti mayātra yoginaḥ prabuddhā
varṇitā na tu vipaścito'pi prabuddhā yogina itīti vasiṣṭha samādhatte - prabuddhā iti |
23 |
prasaṅgarūpāntarato na prabuddhā vipaścitaḥ |
vipaścito mahābāho prabuddhā nipuṇaṃ na te
]

`v 25 [
bodhābodhadṛśormadhye te hi dolayitāḥ sthitāḥ |
mokṣacihnāni dṛśyante bandhacihnāni cābhitaḥ
]

`v 26 [
nityadharmaprabuddhānāṃ tathābhūtatayā tayā |
vipaścito dhāraṇayā yogino na paraṃ gatāḥ
]

`v 27 [
dhāraṇāyoginaste hi dhāraṇāprāptasiddhayaḥ |
ye paraṃ bodhamāyātā yeṣvavidyā na vidyate
]

`v 28 [
hṛdayādipradeśeṣvagnidevatāyāṃ cittanirodhena
tatprasādaprāptasiddhitvāddhāraṇāyogino na tu jñānayogino yeṣvavidyā naṣṭetyarthaḥ |
27 |
kimavidyāmavekṣante te tāmarasalocana |
dhāraṇāyogino hyete vareṇa prāptasiddhayaḥ
]

`v 29 [
avidyā vidyate teṣāṃ tena te'tadvicāriṇaḥ |
anyacca śṛṇu he rāma jīvanmuktaśarīriṇām
]

`v 30 [
bhavedvyavahṛtāveva padārthāntaravedanam |
mokṣo'pi cetaso dharmaścetasyeva sa tiṣṭhati
]

`v 31 [
na dehe dehadharmasya na dehādvinivartate |
na kadācana nirmuktaṃ ceto bhūyo nibadhyate
]

`v 32 [
yatnenāpi punarbaddhaṃ kena vṛntacyutaṃ phalam |
dehastu dehadharmeṇa jīvanmuktimatāmapi
]

`v 33 [
gṛhyate tadgataṃ teṣāṃ cetastvacalameva tat |
mokṣo hi na parajñeyo dhāraṇādiprayogavat
]

`v 34 [
ātmasaṃvedya evāsau madhvādyāsvādasaukhyavat |
sukhaduḥkhairyuto yo'sau svayaṃ bandhānubhūtimān
]

`v 35 [
tanmuktau mukta ityuktaḥ svānubhūtipradastvasau |
antaḥśītalacitto hi mukta ityabhidhīyate
]

`v 36 [
bandhaḥ saṃtaptacitteti dehādestanna dṛśyate |
śarīre kaṇaśaḥ kṛtte rājye vā viniyojite
]

`v 37 [
rudato hasataścaiva jīvanmuktamateriha |
na duḥkhaṃ na sukhaṃ kiṃcidantarbhavati tatsthitam
]

`v 38 [
gṛhṇato'pyanubhūtistu tatraivaiṣāsti nāpare |
dṛśyante paṇḍitā bhagnā rūpāntaramupāgatāḥ
]

`v 39 [
dehādijīvanmuktānāṃ svabhāvānna kadācana |
mṛto'pi naiva mriyate rudannapi na roditi
]

`v 40 [
vihasanna hasatyeva jīvanmukto mahodayaḥ |
vītarāgāḥ sarāgābhā akopāḥ kopasaṃyutāḥ
]

`v 41 [
amohā mohavalitā dṛśyante tattvadarśinaḥ |
idaṃ sukhamidaṃ duḥkhamityādikalanāstu tāḥ
]

`v 42 [
alaṃ dūragatāsteṣāmaṅkurā nabhaso yathā |
jagadātmā ca nāstyeva yasyaikaṃ sarvamasti ca
]

`v 43 [
sukhaduḥkhādi tasyeti vāgvyomaviṭapopamā |
aśokā eva śocante jīvanmuktā jayānvitāḥ
]

`v 44 [
acchinnā ekatadbhāvā dṛśyante tattvadarśinaḥ |
śiraḥ kamalajasyoccaiḥ sāmagāyanatatparam
]

`v 45 [
haro nakhena ciccheda sukumāramivāmbujam |
śakto'pi na punarbrahmā janayāmāsa tacchiraḥ
]

`v 46 [
vyomaikatāsya cidvyomno mudhā mūrdhnetareṇa kim |
naiva tasya kṛtenārtho nākṛteneha kaścana
]

`v 47 [
yadyathā nāma saṃpannaṃ tattathāstvitareṇa kim |
haro hariṇaśāvākṣīmakṣīṇaśarato'śru ca |
dhatte vapuṣi dugdhābdhirguptāmṛtakalāmiva
]

`v 48 [
śakto'pi rāgitāmeṣa na tyajatyuttamāśayaḥ |
pañceṣudāhasamaye dṛṣṭā nīrāgatāguṇāḥ
]

`v 49 [
naiva tasya kṛtenārtho nākṛteneha kaścana |
na cāsya sarvabhūteṣu kaścidarthavyapāśrayaḥ
]

`v 50 [
rāgitaiṣāstu mā vāsya kimarāgitayānyayā |
yadyathā nāma saṃpannaṃ tattathāstvitareṇa kim
]

`v 51 [
karoti kārayatyuccairmriyate māryate'pi ca |
jāyate vardhate'jasraṃ jīvanmukto janārdanaḥ
]

`v 52 [
na cājavaṃ javībhāvaṃ tyaktuṃ śakto'pyasauna tam |
tena tyaktena naivārthastasya naivāśritena ca
]

`v 53 [
tadyathāsthitamevāstu iha ityastavāsanam |
harirniriccha evāste śuddhacinmātrarūpabhṛt
]

`v 54 [
ātmānamāndolayati kālakandukatāṃ gatam |
ajasraṃ nityamādityo jagadgṛhanabhoṅgaṇe
]

`v 55 [
na ca rodhayituṃ dehaṃ na samartho dineśvaraḥ |
niriccha eva nirvāṇastathāpyāste yathāsthitam
]

`v 56 [
candro'nubhavati vyarthamākalpaṃ kṣayamakṣayam |
jīvanmuktatayā khinno yathāsthitamavasthitaḥ
]

`v 57 [
maruttahavyagaurīśavīryagrāsādikheditām |
jīvanmukto vahatyagniryathā sthityā samasthitiḥ
]

`v 58 [
bahvībhirvijigīṣābhiḥ kṛpaṇāviva tiṣṭhataḥ |
jīvanmuktāvapi gurū loke śukrabṛhaspatī
]

`v 59 [
karoti janako rājyaṃn jīvanmuktamanā muniḥ |
jagatyāmājiṣūgrāsu dehaṃ jarjaratāṃ nayan
]

`v 60 [
nalamāndhātṛsagaradilīpanahuṣādyaḥ |
jīvanmuktāściraṃ rājyaṃn cakrurākulitā iva
]

`v 61 [
vyavahāre yathaivājñastathaiva khalu paṇḍitaḥ |
vāsanāvāsane eva kāraṇaṃ bandhamokṣayoḥ
]

`v 62 [
baliprahlādanamucivṛtrāndhakamurādayaḥ |
jīvanmuktāḥ sthitiṃ cakrurvitarāgāḥ sarāgavat
]

`v 63 [
tasmādasattve sattve ca rāgadveṣakṣayodaye |
na manāgapi bhedo'sti j~anakhaṃ prati svarūpiṇi
]

`v 64 [
jñānenākāśaśuddhena dharmānye gaganopamān |
vindanti jīvanmuktānāṃ teṣāṃ bhedamatiḥ kutaḥ
]

`v 65 [
bhāsvaraṃ śakrakodaṇḍaṃ yathā nāneva śūnyakam |
ābhāsamātramevāyaṃ tathā dṛśyātmako bhramaḥ
]

`v 66 [
śakracāpe yathā bhānti nānāvarṇā nabhoṅgaṇe |
tathā śūnyātmakā eva brahmāṇḍaparamāṇavaḥ
]

`v 67 [
idaṃ jagadasadbhāti sadiva vyaktimāgatam |
ajātamaniruddhaṃ ca yathā śūnyatvamambare
]

`v 68 [
sādyantamapyanādyantamaśūnyamapi śūnyakam |
jagajjātaṃ tathā'jātamaruddhaṃ ruddhameva ca
]

`v 69 [
apyarthe tathāśabdaḥ | jātamapyajātameva ruddhaṃ naṣṭaṃ aruddhamanaṣṭameva |
jagattayāpi gṛhīte nityakūṭasthāsaṅgādvaye vastuni ādyantādyaprasakteriti bhāvaḥ | 68
|
jātaṃ niruddhamastyevaṃ brahma vyomaiva bhāsate |
yathā dārumayaḥ stambhastathā tacchālabhañjikā
]

`v 70 [
jagadbhāva iva tajjanmanirodhabhāvo'pi brahmaṇi kalpanayopapādyate iti cediṣṭāpattiḥ
kalpanāmātreṇa kauṭasthyākṣaterityāśayenāha - jātamiti | yathā stambho dārumayo
dārveva tathā tasya stambhasyaikadeśasthā śālabhañjikā pratimāpi dārvevetyarthaḥ | 69
|
samastakalanonmuktaṃ samaṃ nirnidramāsanam |
yadekāntacidākāśaṃ tadvidyāttanmayaṃ jagat
]

`v 71 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
anunmeṣaṃ cidākāśaṃ tadvidyāttanmayaṃ jagat
]

`v 72 [
tatra yaddvaitamaikyaṃ tanmanye tadapi naiva ca |
tadvyoma kevalaṃ bhāti manye tadapi naiva vā
]

`v 73 [
jagadākāśamevedamātmaivātmani vā sthitam |
bhaviṣyatpuravaddṛṣṭamapi sphāramapi sphuṭam
]

`v 74 [
ākāśakośaviśadāśaya dṛśyajātaṃ maunātma tiṣṭhati śilāghanameva
śāntam |
yannāma tasya jagadityabhidhāṃ vidhāya svātmaiva mohita ivāyamaho nu māyā | 74
|
he ākāśakośamiva viśadāśaya rāma yaddṛśyajātaṃ śilāghanaprāyameva śāntaṃ
brahmaiva maunaṃ tiṣṭhati nāma tasya svātmaiva jagadityabhidhāṃn vidhāyāyaṃ mohita
iva tiṣṭhati aho nu māyā atyāścaryabhūtetyarthaḥ
]