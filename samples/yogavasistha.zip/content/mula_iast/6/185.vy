`v 1 [
pañcāśītyadhikaśatatamaḥ sargaḥ 185
kundadnta uvāca |
jaranmunirapītyuktvā dhyānamīlitalocanaḥ |
āsīdaspanditaprāṇamanāścitra ivārpitaḥ
]

`v 2 [
āvābhyāṃ praṇayodāraiḥ prārthito'pi punaḥ punaḥ |
vākyaiḥ saṃsāramavidanna vaco dattavānpunaḥ
]

`v 3 [
āvāṃ pradeśatastasmāccalitvā mandamutsukau |
dinaiḥ katipayaiḥ prāptau gṛhaṃ muditabāndhavam
]

`v 4 [
atha tatrotsavaṃ kṛtvā kathāḥ procya ciraṃtanī |
sthitāstāvadvayaṃ yāvatsaptāpi bhrātaro'tha te
]

`v 5 [
krameṇa vilayaṃ prāptāḥ pralayeṣvarṇavā iva |
mukto'sau me sakhaivaika ekārṇava ivāṣṭakaḥ
]

`v 6 [
tataḥ kālena so'pyastaṃ dinānte'rka ivāgataḥ |
ahaṃ duḥkhaparītātmā paraṃ vaidhuryamāgataḥ
]

`v 7 [
tato'haṃ duḥkhito bhūyaḥ kadambatarutāpasam |
gato duḥkhopaghātāya tajjñānaṃ praṣṭumādṛtaḥ
]

`v 8 [
tatra māsatrayeṇāsau samādhivirato'bhavat |
praṇatena mayā pṛṣṭaḥ sannidaṃ proktavānatha
]

`v 9 [
kadambatāpasa uvāca |
ahaṃ samādhivirataḥ sthātuṃ śaknomi na kṣaṇam |
samādhimeva praviśāmyahamāśu kṛtatvaraḥ
]

`v 10 [
paramārthopadeśaste nābhyāsena vinānagha |
lagatyatra parāṃ yuktimimāṃ śṛṇu tataḥ kuru
]

`v 11 [
ayodhyānāma pūrasti tatrāsti vasudhādhipaḥ |
nāmnā daśarathastasya putro rāma iti śrutaḥ
]

`v 12 [
sakāśaṃ tatra gaccha tvaṃ tasmai kulaguruḥ kila |
vasiṣṭhākhyo muniśreṣṭhaḥ kathayiṣyati saṃsadi
]

`v 13 [
mokṣopāyakathāṃ divyāṃ tāṃ śrutvā suciraṃ dvija |
viśrāntimeṣyasi pare pade'hamiva pāvane
]

`v 14 [
ityuktvā sa samādhānarasāyanamahārṇavam |
viveśāhamimaṃ deśaṃ tvatsakāśamupāgataḥ
]

`v 15 [
eṣo'hametadvṛttaṃ me sarvaṃ kathitavānaham |
yathāvṛttaṃ yathādṛṣṭaṃ yathāśrutamakhaṇḍitam
]

`v 16 [
śrīrāma uvāca |
sa kundadanta ityādikathākathanakovidaḥ |
sthitastataḥprabhṛtyeva matsamīpagataḥ sadā
]

`v 17 [
sa eṣa kundadantākhyo dvijaḥ pārśve samāsthitaḥ |
śrutavānsaṃhitāmetāṃ mokṣopāyābhidhāmiha
]

`v 18 [
sa eṣa kundadantākhyo mama pārśvagato dvijaḥ |
adya niḥsaṃśayo jāto na veti paripṛcchyatām
]

`v 19 [
śrīvālmīkiruvāca |
ityukte rāghaveṇātha provāca vadatāṃvaraḥ |
sa vasiṣṭho muniśreṣṭhaḥ kundadantaṃ vilokayan
]

`v 20 [
śrīvasiṣṭha uvāca |
kundadanta dvijavara kathyatāṃ kiṃ tvayānagha |
buddhaṃ śrutavatā jñeyaṃ maduktaṃ mokṣadaṃ param
]

`v 21 [
kundadanta uvāca |
sarvasaṃśayavicchedi ceta eva jayāya me |
sarvasaṃśayavicchedo jñātaṃ jñeyamakhaṇḍitam
]

`v 22 [
jñātaṃ jñātavyamamalaṃ dṛṣṭaṃ draṣṭavyamakṣatam |
prāptaṃ prāptavyamakhilaṃ viśrānto'smi pare pade
]

`v 23 [
buddheyaṃ tvadidaṃ sarvaṃ paramārthaghanaṃ ghanam |
ananyenātmano vyomni jagadrūpeṇa jṛmbhitam
]

`v 24 [
tvat tvatta iyamātmacit mayā buddhā | kathaṃ buddhā tadāha - idaṃ sarvamityāha | 23
|
sarvātmakatayā sarvarūpiṇaḥ sarvagātmanaḥ |
asarvaṃ sarveṇa sarvatra sarvadā saṃbhavatyalam
]

`v 25 [
saṃbhavanti jagantyantaḥ siddhārthakaṇakoṭare |
na saṃbhavanti ca yathā jñātametadaśeṣataḥ
]

`v 26 [
gṛhe'ntaḥ saṃbhavatyeva saptadvīpā vasuṃdharā |
gehaṃ ca śūnyamevāste satyametadasaṃśayam
]

`v 27 [
yadyadyadā vastu yathoditātma bhātīha bhūtairanubhūyate ca |
tattattadā sarvaghanastathāste brahmetthamādyantavimuktamasti
]