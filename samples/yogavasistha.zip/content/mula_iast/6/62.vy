`v 1 [
dviṣaṣṭitamaḥ sargaḥ 62
śrīrāma uvāca |
yadetadbhavatā dṛṣṭaṃ cidvyomavapuṣā tadā |
tadekadeśasaṃsthena kimuta bhramatāmbare
]

`v 2 [
śrīvasiṣṭha uvāca |
saṃpanno'hamanantātmā vyāpī vyoma tadā kila |
syātāṃ tasyāmavasthāyāṃ kīdṛśau tau gamāgamau
]

`v 3 [
naikasthānasthitamayo nāhaṃ gatimayo'bhavam |
tadanena sva evāsmindṛṣṭametanmayātmani
]

`v 4 [
yathāṅgāni śarīratve paśyāmyāpādamastakam |
cinnetreṇāpyanetreṇa tathaitadvṛṣṭavānaham
]

`v 5 [
anākṛterniravayavasthitestadā tathā'bhavadvimalacidambarātmanaḥ |
jaganti tānyavayavajālakāni me yathā svato na vigalitā na vastutā
]

`v 6 [
pramāṇamatra te svapnadṛṣṭo'bhuvanavibhramaḥ |
svapne'nubhūyate dṛśyaṃ na ca kiṃcitkhameva tat
]

`v 7 [
yathā paśyati vṛkṣaḥ svaṃ patrapuṣpaphalādikam |
svasaṃvedananetreṇa tathaitaddṛṣṭavānaham
]

`v 8 [
yathāmbudhiranantātmā vetti sarvān jalecarān |
taraṅgāvartaphenāṃśca tathaitadbuddhavānaham
]

`v 9 [
avayavānsvānavayavī yathā vetti nijātmani |
ananyānātmanaḥ sargāṃstathaitānbuddhavānaham
]

`v 10 [
kiṃ bahunā sarvaprāṇiṣvapi svāvayavānāṃ tathā vedanaṃ prasiddhamityāśayenāha ##-
adyāpi tānahaṃ dehe vyomni śaile jale sthale |
tathaiva sargānpaśyāmi rāma bodhaikatāṃ gataḥ
]

`v 11 [
puro'smākamidaṃ viśvaṃ gṛhasyāntarbahistathā |
pūrṇametajjagadvṛndairvedmi bodhaikatāṃ gataḥ
]

`v 12 [
yathāmbho rasatāṃ vetti śaityaṃ vetti yathā himam |
spandaṃ vetti yathā vāyustathaitadvetti śuddhadhīḥ
]

`v 13 [
yo yo nāma vivekātmā śuddhabodhaikatāṃ gataḥ |
sama eṣa mayaikātmā vedmi svātmānamīdṛśam
]

`v 14 [
asyā dṛṣṭeḥ pariṇatervettṛvedanavedyadhīḥ |
na kācidastyabhyuditā vijñānātmaikatā yataḥ
]

`v 15 [
divyā dṛgadrisaṃsthasya tathā yojanakoṭigān |
bhāvānvetti bahiścāntarevaṃ tadbuddhavānaham
]

`v 16 [
yathā bhūmaṇḍalaṃ bhāvānnidhidhāturasādikān |
vettyevaṃ tanmayā buddhamananyaddṛśyamātmanaḥ
]

`v 17 [
śrīrāma uvāca |
brahmannanubhavatyevaṃ tvayi tāmarasekṣaṇa |
sā kiṃ kṛtavatī brūhi kāntā'ryāpāṭhapāṭhinī
]

`v 18 [
vasiṣṭha uvāca |
tāmevāryāṃ paṭhantī sā tathaivānunayānvitā |
matsamīpe nabhodehā vyomni devīva saṃsthitā
]

`v 19 [
yathāhamākāśavapustathaivāsau kharūpiṇī |
tena dṛṣṭā na sā pūrvaṃ dehena lalanā mayā
]

`v 20 [
ahamākāśamātrātmā sā khamātraśarīriṇī |
jagajjālaṃ khamātraṃ taditi tatra tadā sthitam
]

`v 21 [
śrīrāma uvāca |
śarīrasthānakaraṇaprayatnaprāṇasaṃbhavaiḥ |
yadudeti vaco varṇaistatkutastādṛśākṛteḥ
]

`v 22 [
rūpālokamanaskāraḥ kuto nāmātmanāmiti |
brūhi me bhagavaṃstattvaṃ yathāvṛttaśca niścayam
]

`v 23 [
śrīvasiṣṭha uvāca |
rūpālokamanaskārāḥ śabdapāṭhavacāṃsi ca |
yathā svapne nabhasyeva santi tatra tathāmbare
]

`v 24 [
rūpālokamanaskāraiḥ svapne cinnabha eva te |
yathodeti tathā tatra taddṛśyaṃn khātmakaṃ sthitam
]

`v 25 [
na kevalaṃ tu taddṛśyaṃ yāvattu viṣayaṃ vayam |
jagaccedaṃ khamevācchaṃ yathā tannastathākhilam
]

`v 26 [
paramārthamahādhāturvedyanirmuktacidvapuḥ |
evaṃ nāma svayaṃ bhāti svabhāvasyeva niścayaḥ
]

`v 27 [
śarīrasthānakaraṇasattāyāṃ kā tava pramā |
yathaiva teṣāṃ dehādi tathāsmākamidaṃ sthitam
]

`v 28 [
yathaiva tattathaivedaṃ tathaivedaṃ yathaiva tat |
asatsattāmiva gataṃ saccāsadiva ca sthitam
]

`v 29 [
yathā svapne dharādhvādipṛṣṭhavyavahṛtirnabhaḥ |
tadā hyahaṃ ca tvaṃ sā ca tadidaṃ ca tathā nabhaḥ
]

`v 30 [
yathā svapne nṛbhiryuddhakolāhalagamāgamāḥ |
asanto'pyanubhūyante saṃsāranikarāstathā
]

`v 31 [
vakṣi cetsvapnadṛśyaśrīḥ kasmāttadasamañjasam |
avācyametaddheturhi nānyo'styanubhavasthiteḥ
]

`v 32 [
kathamālakṣyate svapna iti praṣṭuḥ prakathyate |
yathaivaṃ paśyasītyeva heturatrāsti netaraḥ
]

`v 33 [
svapnajanturiva vyomni bhāti prathamasargataḥ |
prabhṛtyeva virāḍātmā khe khameva paraspare
]

`v 34 [
svapnaśabdena bodhārthaṃ tava vyavaharāmyaham |
dṛśyaṃn tvidaṃ na sannāsanna svapno brahma kevalam
]

`v 35 [
atha rāghava sā kāntā mayā kāntānuṣaṅgiṇī |
saṃvidaṃ tanmayīṃ kṛtvā pṛṣṭedaṃ dṛśyarūpiṇī
]

`v 36 [
vyavahāro yathodeti svapne svapnajanaiḥ saha |
tathā tadā tayā sārdhaṃ vyavahāro mamoditaḥ
]

`v 37 [
yathaiva svapnasaṃkāśo vyavahāraḥ khameva saḥ |
tathaiva tvamimaṃ viddhi māmātmānaṃ jagacca kham
]

`v 38 [
yathā svapnajagadrūpaṃ khamevaivamidaṃ jagat |
jāgradādau sa hi svapnaḥ sargādau jagadudbhavaḥ
]

`v 39 [
svapno'yaṃ jagadābhogo na kiṃcidvā khameva ca |
nirmalaṃ jñaptitāmātramitthaṃ sanmātrasaṃsthitam
]

`v 40 [
svapnasya vidyate draṣṭā sākāro yuṣmadādikaḥ |
draṣṭā tu sargasvapnasya cidvyomaivāmalaṃ svataḥ
]

`v 41 [
yathā draṣṭāmalaṃ vyoma dṛśyaṃ tadvadgataṃ tathā |
svapnarūpajagatyuccairjagattvenāmalaṃ nabhaḥ
]

`v 42 [
cidvyomno'nākṛteḥ svapno hṛdi sphurati yaḥ svataḥ |
sargastasya kutastena sākṛtitvaṃ kathaṃ bhavet
]

`v 43 [
sākārasyaiva yatsvapnajagattadvyoma nirmalam |
nirākārasya cidvyomnaḥ sargaḥ svapnaḥ kathaṃ na kham
]

`v 44 [
nirupādānasaṃbhāramabhittāveva cinnabhaḥ |
paśyatyakṛtamevemaṃ jagatsvapnaṃ kṛtaṃ yathā
]

`v 45 [
mṛdvyā cidākāśamṛdā brahmaṇā brāhmaṇena khe |
kṛto'pi na kṛtaḥ sargamaṇḍapo'kṣagavākṣakaḥ
]

`v 46 [
no kartṛtā na ca jaganti na bhoktṛtāsti nāstīti nāsti na ca kiṃcidato budhaḥ san |
pāṣāṇamaunamavalambya yathāpravāhamācāramācara śarīramihāstu mā vā | 46
|
ataḥ sarvadṛśyamārjanātpariśiṣṭo budhastatsākṣyeva san paramārthaḥ | ato he rāma
tvamantaḥ pāṣāṇamaunamavalambya bahiryathāpravāhamācāramācara | tatra te śarīraṃ
yāvatprārabdhaśeṣamastu taduttaraṃ māstu vā na kaścidviśeṣa ityarthaḥ
]