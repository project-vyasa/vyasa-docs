`v 1 [
dviṣaṣṭyadhikaśatatamaḥ sargaḥ 162
śrīvasiṣṭha uvāca |
cidvyomārthatayārthānāṃ yathāsthitamidaṃ jagat |
sarūpālokamananamapi cidvyoma kevalam
]

`v 2 [
svapnacitpurarūpatvādanyadyasmānna vidyate |
jagattasmānnabhaḥ śāntaṃ neha nānāsti kiṃcana
]

`v 3 [
cidābhānamanānaiva nāneva parilakṣyate |
anātmaivātmanātmānaṃ svapnākāśapureṣviva
]

`v 4 [
sargādāviva cidvyoma svapnākāśapuraṃ jagat |
ābhātamevāsatyaṃ ca nūnaṃ satyamiva sthitam
]

`v 5 [
tajjñājñāto na mūrkhāṇāmajñājñāto na tadvidām |
vidyate sargaśabdārthaḥ satyāsatyamayātmakaḥ
]

`v 6 [
tajjñājñayostayorantaḥpratipattau tu yatsthitam |
na boddhuṃ na ca vaktuṃ te jānītastau parasparam
]

`v 7 [
svabuddhau svargaśabdārtho mithontastatkilānayoḥ |
sthairyāsthairye jāgrato dve akṣībakṣībayoriva
]

`v 8 [
dravasthitimitā yadvatsaridvāriṇi vīcayaḥ |
citau sthitimitāstadvaccetanātsargavīcayaḥ
]

`v 9 [
cidrūpaṃ yanna kiṃcittadidaṃ kiṃcidavasthitam |
bhāti dṛśyamivādṛśyamapi svapnapureṣviva
]

`v 10 [
cicchāyeyaṃ prakacati jagadityabhiśabditā |
nanvamūrtaiva mūrteva dravyacchāyeva vai tatā
]

`v 11 [
kāyamātrakamevedaṃ bhrāntimātramasanmayam |
piśācavibhramālokaprāyamāyāsanaṃ dṛḍham
]

`v 12 [
manorājyamivāsatyaṃ lolaṃ lambāmbubinduvat |
dvābhyāmityanubhūtibhyāṃ yadasattatra kātmatā
]

`v 13 [
vidāryadāruravavattaraṅgānilaśabdavat |
khe śabdāḥ pavanasphoṭā bhāntyarthā vāsanodayāḥ
]

`v 14 [
sargāditaḥ svaparibhā kacati svapnaśailavat |
vastutastu na śabdosti nārtho'sti na ca dṛśyatā
]

`v 15 [
yadihaṃ cāsti cābhāti tatsarvaṃ paramārthasat |
anyādṛkkāraṇābhāvātsargādāveva noditam
]

`v 16 [
anyādṛk sadvyatiriktaṃ rūpaṃ tu sargādāveva kāraṇābhāvānnoditaṃ notpannameva |
15 |
nirastaśabdabhedārthamanirastākhilārthakam |
śāmyāmi parinirvāmi vyomaivāsmīti buddhyatām
]

`v 17 [
tyajyatāmātmaviśrāntyā śuddhabodhaikarūpayā |
jīve'javaṃ javībhāvastvasadutthita ātmanā
]

`v 18 [
ātmaiva hyātmano bandhurātmaiva ripurātmanaḥ |
ātmātmanā na cettrātastadupāyo'sti netaraḥ
]

`v 19 [
tara tāruṇyamastīdaṃ yāvatte tāvadambudheḥ |
nanu saṃsāranāmno'smādbuddhyā nāvā viśuddhayā
]

`v 20 [
yāvattāruṇyamasti tāvadeva buddhyā nāvā saṃsāranāmno'mbudhestara paratīraṃ vraja |
19 |
adyaiva kuru yacchreyo vṛddhaḥ sankiṃ kariṣyasi |
svagātrāṇyapi bhārāya bhavanti hi viparyaye
]

`v 21 [
śaiśavaṃ vārdhakaṃ jñeyaṃ tiryaktvaṃ mṛtireva ca |
tāruṇyameva jīvasya jīvitaṃ tadviveki cet
]

`v 22 [
saṃsāramimamāsādya vidyutsaṃpātacañcalam |
sacchāstrasādhusaṃparkaiḥ kardamātsāramuddharet
]

`v 23 [
aho bata narāḥ krūrā gatiḥ kaiṣāṃ bhaviṣyati |
kurvanti kardamonmagne nātmanyapi nijodayam
]

`v 24 [
yathā mṛnmayavetālasabhā grāmyasya bhaṅgadā |
yathā bhūtārthavijñānānmṛnmayyeva na bhaṅgadā
]

`v 25 [
tathā brahmamayī dṛśyalakṣmīrajñasya bhaṅgadā |
yathā bhūtārthavijñāne brahmaivāste na bhaṅgadā
]

`v 26 [
śāmyatyaśāntamevedaṃ sthitameva vilīyate |
dṛśyaṃ tattvaparijñānāddṛśyamānaṃ na dṛśyate
]

`v 27 [
sphuṭānubhavanasyāpi svapnakāle nije yathā |
parijñānādasatyatvameva satyapadaṃ gatā
]

`v 28 [
tathānubhūyamānāpi sargasaṃvedanāmbare |
cinmaye tattvavijñānācchūnyataivāvaśiṣyate
]

`v 29 [
jātijvarajvalitajīvitajaṅgaleṣu jīrṇāni vātahariṇāharaṇakrameṇa |
mādyanmanaḥpavanapātayutānyamūni jitvendriyāṇi jayamehi jahīhi janma
]