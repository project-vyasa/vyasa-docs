`v 1 [
pañcanavatyadhikaśatatamaḥ sargaḥ 195
śrīvasiṣṭha uvāca |
aho nu saṃprabuddho'si rāghavāghavighātinī |
vāgiyaṃ tava saṃpannā prabuddheṣvavahāsinī
]

`v 2 [
vibhātīvāsadevedamasaṃkalpena śāmyati |
etacchāntisti nirvāṇamityeva paramārthatā
]

`v 3 [
kalpanākalpane rūpaṃ parasyaivetarasya no |
spandanāspandanaṃ vāyoryathā nātraikatādvite
]

`v 4 [
prabuddhasyaiva yā puṃsaḥ śilājaṭharavatsthitiḥ |
śāntau vyavahṛtau vāpi sāmalā muktatocyate
]

`v 5 [
vayamasminpade sthitvā rāghavāghavighātini |
śāntatve vyavahāre ca samamitthamavasthitāḥ
]

`v 6 [
asminneva pade nityaṃ brahmaviṣṇuharādayaḥ |
tiṣṭhanti vyavahārasthā api śāntā jñarūpiṇaḥ
]

`v 7 [
śailodarasthitimatāṃ prabuddhānāmanāmayam |
asmākaṃ padamevaṃ tadālabhyaitadihoṣyatām
]

`v 8 [
śrīrāma uvāca |
brahmaṇyevamasadrūpamanutpannamabhāsuram |
anārambhamanākāramevedaṃ bhāsate jagat
]

`v 9 [
mṛgatṛṣṇāmbusadṛśaṃ taraṅgāvartivārivat |
rucakādīva kanake svapnasaṃkalpaśailavat
]

`v 10 [
śrīvasiṣṭha uvāca |
buddhavānasi cedrāma tatsvabodhavivṛddhaye |
kuru saṃśayavicchedaṃ pṛcchataḥ pracchakasya me
]

`v 11 [
itthaṃ nityānubhūto'pi śirastho'pyatibhāsuraḥ |
jagadākhyo'yamābhāsaḥ kathaṃ nāma na vidyate
]

`v 12 [
śrīrāma uvāca |
pūrvamevedamutpannaṃ na kiṃcana kadācana |
tena vandhyāsutasyāsya na sattā kalpanādṛte
]

`v 13 [
kimivāsyā jagadbhrānteḥ kāraṇaṃ protthitā yataḥ |
na kāraṇaṃ vinā kāryaṃ kiṃcitsaṃbhavati kvacit
]

`v 14 [
na cāvikāramajaraṃ savikāraṃ kṣayādṛte |
kāraṇaṃ kvacideveha kiṃcidbhavitumarhati
]

`v 15 [
brahmaivedamanākhyātma kāraṇaṃ pravijṛmbhate |
tatkva kasya kathaṃ nāma jagacchabdārthasaṃvidaḥ
]

`v 16 [
tadanākhye pade śānte cirātprathamacetanam |
kaṃcitkālalavaṃ tiṣṭhatyātivāhikadehabhṛt
]

`v 17 [
kṣaṇe vatsarasaṃvittiṃ svapne tvamiva cetati |
kākatālīyavattatra candrārkādīṃśca paśyati
]

`v 18 [
saṃkalpaikātmanastasya deśakālakriyānvitam |
atyantameva vyomnyeva bhuvanaṃ bhāsate svayam
]

`v 19 [
tasminmithyopasaṃpanne sa mithyāpuruṣastataḥ |
mithyaiva tatsamācāraṃ kurvanviparivartate
]

`v 20 [
adhastādūrdhvamāyāti punarūrdhvādvrajatyadhaḥ |
kalpitānantasaṃbhārapadārthānarthasaṃbhramaḥ
]

`v 21 [
kākatālīyavattasya saṃkalpasya bhavedyadi |
yadyathā tattathādyāpi susthirāmāttavānsthitim
]

`v 22 [
śilā vandhyāsutamukhe vyomacūrṇena rañjanam |
karotītyādivadidaṃ mithyā jagadupasthitam
]

`v 23 [
satyamevedamathavā mithyātvaṃ tu kutaḥ kila |
na mithyātvaṃ na satyatvaṃ kimapīdamajaṃ tatam
]

`v 24 [
ākāśakośavatsvacchaṃ śilājaṭharavadghanam |
pāṣāṇamaunavaccedaṃ śāntamevākṣayaṃ jagat
]

`v 25 [
cinmātrasarvasaṃkalpe virāḍātmātivāhike |
dehe saṃvedanaṃ vyoma jagadityavabhāsate
]

`v 26 [
evaṃ brahma mahākāśamevedaṃ kva jagatkathā |
śāntaṃ samasamābhogamekamādyantavarjitam
]

`v 27 [
yathā payasi vīcīnāmunmajjananimajjanaiḥ |
na jalānyatvamevaṃ hi bhāvābhāvaiḥ paraiḥ pare
]

`v 28 [
parāvaravidaḥ kecidetasminparame pade |
śuddhe pariṇamantyantarvāribindurivāmbhasi
]

`v 29 [
pare'paramidaṃ bhāti parasyeva parātmakam |
saṃbhavantyamale śānte na jaganti na tatkriyāḥ
]

`v 30 [
parasya brahmaṇo veṣa iva kāryamiva avayava iva vā aparamidaṃ jagat jīvarūpaṃ bhāti |
tacca tattvato vicāre parameva saṃbhavati | jaganti tatkriyāḥ vyavahārāśca na saṃbhavanti |
29 |
svapne svapna iti jñāte dṛśye brahmatayāpi ca |
mṛgāmbuni paratvena ko bhāvayati bhāvanām
]

`v 31 [
paramārthacamatkāramantaḥsthānubhavaṃ vinā |
anyasyānyaṃ na jānāti sīdhusvādumiva dvijaḥ
]

`v 32 [
nirvāya nija ātmāyaṃ parivṛtyāvalokitaḥ |
cetyonmukhatvamutsṛjya saṃtiṣṭhecchānta ātmani
]

`v 33 [
śrīvasiṣṭha uvāca |
dṛśyaṃ bījāṅkura iva sthitaṃ brahmaṇi kāraṇe |
iti sargādisadbhāvaḥ kasmānnehopapadyate
]

`v 34 [
evaṃ samāhito vasiṣṭhaḥ punarbījāṅkuranyāyena brahmaṇi jagatsatyatāṃ śaṅkate ##-
śrīrāma uvāca |
bīje'ṅkuro'ṅkuratayā saṃśrito nopalabhyate |
bījodare tu yā sattā bījameva hi sā bhavet
]

`v 35 [
brahmaṇo'ntarjagattaivaṃ jagattaivopalabhyate |
asti cettadbhavennityaṃ sā brahmaivāvikāri tat
]

`v 36 [
avikārādanākārādvikāryākṛtibhāsuram |
udetīti kilāsmābhirnaiva dṛṣṭaṃ na ca śrutam
]

`v 37 [
anākṛtāvākṛtimanna caitatsthātumarhati |
paramāṇau na caivāntariva saṃbhānti meravaḥ
]

`v 38 [
samudgake ratnamiva jagadbrahmaṇi tiṣṭhati |
mahākāraṃ nirākāra ityunmattavaco bhavet
]

`v 39 [
śāntaṃ paraṃ ca sākārasyādhāra iti rājate |
na vaktuṃ rājate kveva sākārasyāvināśitā
]

`v 40 [
bodha evāyamākāra iti kalpanayāpi dhīḥ |
apūrvaiḥ svapnavadrūḍhaiḥ saṃsārairnopalabhyate `note[vyākhyānānurodhena
ākārairiti pāṭho'pekṣita iti |]
]

`v 41 [
apūrva eva svapno'yaṃ yadvai sargo'nubhūyate |
svapnaḥ kilānubhūtārthaḥ svabhyasta eva dṛśyate
]

`v 42 [
yadeva jāgrattatsvapna iti nātropapadyate |
svapne pradagdhaḥ puruṣaḥ kathaṃ prātarvilokyate
]

`v 43 [
aśarīrasya na svapna ityetadapi nocitam |
saṃbhavanti piśācādyāsteṣāṃ ca svapnavatsthitiḥ
]

`v 44 [
tasmātsvapnavadābhāsaḥ saṃvidātmani saṃsthitaḥ |
sargādinānākṛtinā `note[nānākṛtibhiḥ iti pāṭhaḥ sādhuḥ |] paramātmā
nirākṛtiḥ
]

`v 45 [
svapne cideva śailādirūpeṇātmani tiṣṭhati |
brahmātmākhilamukto'sāvanyenāsau kṛtau yadi
]

`v 46 [
nehāstitvaṃ na nāstitvamupalabdhe'nubhūyate |
naivānubhavitṛtvaṃ ca na cānubhavanakramaḥ
]

`v 47 [
kimapīdamanākhyeyaṃ buddhenaivānubhūyate |
svasaṃvedanasaṃvedyaṃ sattāsattāvijṛmbhitam
]

`v 48 [
abhāvarūpiṇo bhāvā abhāvā bhāvarūpiṇaḥ |
sarvadā sarvathā sarve bhānti bhāsuratāṃ gatāḥ
]

`v 49 [
bṛṃhati brahmaṇi brahma vyoma vyomani vardhate |
na copapadyate kiṃcidbrahma vyomni vibṛṃhaṇam
]

`v 50 [
draṣṭṭadṛśyadṛgātmāyamahaṃ sargādivibhramaḥ |
śāntacidvyomavistāro na kuḍyādyupapadyate
]

`v 51 [
yathā na sanna kuḍyādi svasaṃkalpanapattanam |
tathaivāyaṃ jagaditi śāntamekamanāmayam
]

`v 52 [
pūrṇaṃ hi paramaṃ śāntamidaṃ sarvamakhaṇḍitam |
aniṅganamanābhāsamanādyantamacetitam
]

`v 53 [
ajanmamaraṇaṃ śāntamanādinidhanaṃ mahat |
anupādhi nirākāraṃ svapadaṃ buddhavānaham
]

`v 54 [
yā saṃvidantaḥ sphurati saivopāyāti vākyatām |
yadbījaṃ līnamavanau tadyātyaṅkuratāṃ kila
]

`v 55 [
mamedaṃ vākyaṃ satyameva nāstyamanubhavamūlakatvāditi sayuktikamāha - yeti | 54
|
śuddhajñānāmayaikātmā dvaitaikyaparivarjitaḥ |
manāgapi na jānāmi dvaitaikyakalanākalām
]

`v 56 [
sarve tūṣṇīṃmayā eva jīvanmuktā ime janāḥ |
saṃśāntasarvasaṃrambhāḥ khe svabhāva iva sthitāḥ
]

`v 57 [
jagatsparśamahārambhamapi tūṣṇīmidaṃ sthitam |
citraṃ bhittāviva kṛtaṃ manorājya ivoditam
]

`v 58 [
śailādivotkīrṇasamaṃ kathāyāmiva varṇitam |
śambareṇeva racitaṃ vyomni svapna ivoditam
]

`v 59 [
kila svapnavadevedaṃ sargādāveva bhāti yat |
abhittikaṃ niṣpratighaṃ jagatkevāsya satyatā
]

`v 60 [
jagadbuddhāvidaṃ satyaṃ parijñānavato mṛṣā |
brahmātmaka idaṃ brahma śānte śāntaṃ parāmbaram
]

`v 61 [
sarva eva ime bhāvāḥ saha sthāvarajaṅgamāḥ |
asmadādaya ākāśaṃ jagajjñaviṣayaṃ tathā
]

`v 62 [
khamahaṃ khaṃ bhavāṃścitkhaṃ jagatkhaṃ khaṃ khameva ca |
cidākāśaikatāmetya bhajaikākāśarūpatām
]

`v 63 [
jñānenākāśakalpena sarvātma gaganopamam |
jñeyābhinnena saṃbodhāttaṃ vande dvipadāṃ varam
]

`v 64 [
cidrūpatvādudetīdaṃ jagattatraiva līyate |
akāraṇakamevāntaḥ paraṃ vyomaiva nirmalam
]

`v 65 [
etatsarvapadātītaṃ sarvaśāstrakalātigam |
padamāsādya nirdvandvaṃ tvamākāśātmako'bhavaḥ
]

`v 66 [
ahaṃ jagacca no pādapāṇyādi na ghaṭādi ca |
sarvamākāśamākāśamevācchaṃ sūkṣmacidbhavet
]

`v 67 [
sarvāpahnava evāyaṃ mayā yo darśitastava |
sa nindyo vādināṃ vādeṣvātmajñāneṣu rājate
]

`v 68 [
kāṣṭhamaunātmako vāde na sarvāpahnavo yadā |
kriyate tena vādeṣu nātmajñānaṃ prasīdati
]

`v 69 [
pratyakṣādipramāṇānāṃ yadagamyamacihnitam |
svānubhūtibhavaṃ brahma vādaistallabhyate katham
]

`v 70 [
sarvāgamārthasamatītamacihnamacchamākāśamekamajamādyamanāmarūpam |
śuddhaṃ cidātmakamihāstyanubhūtimātraṃ śāntābhidhānakalanaṃ
malaśaṅkayālam
]