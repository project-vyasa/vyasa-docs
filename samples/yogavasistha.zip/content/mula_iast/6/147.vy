`v 1 [
saptacatvāriṃśadadhikaśatatamaḥ sargaḥ 147
muniruvāca |
anantaraṃ mahābāho suṣuptānnirgatasya me |
svapne jagaddṛśyamidaṃ sāgarādiva nirgatam
]

`v 2 [
ākāśāṅgādivotkīrṇamutkīrṇamavaneriva |
utkīrṇamiva vā cittādutkīrṇamiva vā dṛśaḥ
]

`v 3 [
praphullamiva vṛkṣebhyaḥ sargaḥ pūrvamivotthitaḥ |
taraṅgajālaṃ rodho'bdheriva vā kacanaṃ dṛśām
]

`v 4 [
nabhastalādivāyāṃ kakubbhya iva cāgatam |
parvatebhya ivotkīrṇaṃ bhūmeriva samutthitam
]

`v 5 [
hṛdayādiva niṣkrāntaṃ saṃpraviṣṭamivāmbudaiḥ |
prasūtamiva vṛkṣebhyo jātaṃ vā sasyavadbuvaḥ
]

`v 6 [
aṅgebhya iva niryātaṃ samutkīrṇamivendriyaiḥ |
paṭādiva prakaṭitaṃ mandirādiva nirgatam
]

`v 7 [
kuto'pyāgatya patitamuḍḍīya gaganādiva |
upāyanaṃ pare loke gṛhītamiva vā bhavaḥ
]

`v 8 [
prasūnaṃ brahmavṛkṣasya taraṅgamiva vāmbudheḥ |
anutkīrṇaprakaṭanāccitstambhe cāruputrikā
]

`v 9 [
ākāśamṛnmayānantakuḍyamākāśapattanam |
mano matto gajamayo mithyā jīvasya jīvitam
]

`v 10 [
abhittikamaraṅgaṃ ca vicitraṃ citramambare |
śambareśasya sarvasvamavidyākhyasya kasyacit
]

`v 11 [
mahārambhaṃ sthiramapi deśakālavivarjitam |
nānāḍhyamapi cādvaitaṃ nānātmāpi na kiṃcana
]

`v 12 [
gandharvapuradṛṣṭāntasyāpyavastutayā samam |
jāgarāyāṃ hi kila tadbhrāntamapyupalabhyate
]

`v 13 [
cidbhāmātramanārabdhamapyārabdhamiva sthitam |
deśakālakriyādravyasargasaṃhārasaṃyutam
]

`v 14 [
surāsuranarādhāragarbhagarbhamanoharam |
pṛthakkoṣṭhasthabījaughasaṃpūrṇamiva dāḍimam
]

`v 15 [
nadīśailavanādisthavyomatārābhrasaṃkulam |
gītābdhiraṇapāṭhāḍhyapavanārāvaghargharam
]

`v 16 [
tato vilokitaṃ tatra tanmayā dṛśyamaṇḍalam |
yāvattameva paśyāmi grāmaṃ prāktanamāspadam
]

`v 17 [
tāneva sakalānbandhūṃstathāsaṃsthānasaṃsthitān |
tānputrāṃstāṃ mahelāṃ ca tadeva ca tadā gṛham
]

`v 18 [
tāṃ dṛṣṭvā prāktanīṃ grāmyāmāharadvāsanāṃ balāt |
taṭasthaṃ muhyamānāṅgamiva vīcirmahārṇave
]

`v 19 [
athāhamabhavaṃ tatra tadāliṅgananirvṛtaḥ |
gṛhītavāsano nūnaṃ vismṛtaprāktanasmṛtiḥ
]

`v 20 [
bimbaṃ tattadupādatte yadyadagre'vatiṣṭhati |
yathādarśaścidādarśastathaivāyaṃ svabhāvataḥ
]

`v 21 [
yastu cinmātragaganaṃ sarvamityeva bodhavān |
dvaitena bodhyate neha so'ṅgaḥ tiṣṭhati kevalaḥ
]

`v 22 [
na naśyati smṛtiryasya vimalā bodhaśālinī |
ayaṃ dvaitapiśācastaṃ manāgapi na bādhate
]

`v 23 [
yeṣāmabhyāsayogena sādhusacchāstrasaṃgamaiḥ |
udeti bodhadhīrbhūyo yā vismarati nodayam
]

`v 24 [
aprauḍhā me tadā sāsīdbodhadhīryā tayā hatā |
adya śaknoti me buddhiṃ hantuṃ ka iva durgrahaḥ
]

`v 25 [
tavāpi vyādha viddhīdaṃ buddhiḥ satsaṅgavarjitā |
dvaitabodhena kaṣṭena kṛcchrācchāntimupaiṣyati
]

`v 26 [
vyādha uvāca |
evametanmune satyaṃ pāvanaistvadvibodhanaiḥ |
īdṛśairapi me buddhirna viśrāmyati satpade
]

`v 27 [
syādīdṛśamatho na syāditi saṃdehajālikā |
naitasminsvānubhūte'pi vastunyadyāpi śāmyati
]

`v 28 [
aho bata duranteyamabhyāsasudṛḍhīkṛtā |
avidyā vidyamānaiva yā śāntaiva na śāmyati
]

`v 29 [
satsaṅgataiḥ padapadārthavibuddhabuddheḥ
sacchāstrasatkramavicāramanoharāṅgaiḥ |
abhyāsataḥ praśamameti jagadbhramo'yaṃ nānyena kenacidapīti viniścitirme
]