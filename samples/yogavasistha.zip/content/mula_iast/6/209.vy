`v 1 [
navādhikadviśatatamaḥ sargaḥ 209
śrīvasiṣṭha uvāca |
ekasya jīvitaṃ puṃsaḥ suhṛdā maraṇaṃ dviṣā |
mṛtvārthitaṃ prayāgādau kṣetre yattadidaṃ śṛṇu
]

`v 2 [
kṣetrāṇāmarthadharmāṇāṃ sarveṣāṃ prati taṃ phalam |
brahmaṇā kalpitaṃ sarge svake saṃkalpapattane
]

`v 3 [
yatra puṇyaṃ yadarthaṃ ca kṣetraṃ tābhyāṃ tathā kṛtam |
yadi tadviniyojyasya tasyonnamati niṣkṛtāt
]

`v 4 [
yatra saṃkalpapattane yadarthaṃ yasyādhikāriṇo vāñchitārthasiddhyarthaṃ kāmapradaṃ
prayāgādikṣetraṃ tatrānuṣṭhitaṃ snānadānatapoyajñādipuṇyaṃ tathā tābhyāṃ
kṛtaṃ saṃskṛtaṃ śarīraṃ ca yadi śāstraviniyojyasya puruṣasyāsti tadā tasya
puruṣasya niṣkṛtādavaśyamatra madiṣṭaṃ phalaṃ bhaviṣyatīti niścitya
kṛtātprayāgamaraṇādeḥ sakāśāttatkāmitaṃ phalamunnamatyāvirbhavatyevetyarthaḥ |
3 |
tattasmānmahataḥ pāpādbhāgamenokhilaṃ ca vā |
citiśaktyātma tatpuṇyaṃ paribhrāmyopaśāmyati
]

`v 5 [
vineyapāpamalpaṃ cetkṣetradharmo'dhikastataḥ |
tatpāpaṃ nāśayitvā tacchabda eva vivalgati
]

`v 6 [
kṣetradharmeṇa tenāsya vineyasya mahīpate |
dve śarīre vidau samyakkacataḥ pratibhātmike
]

`v 7 [
ityevamādipāpānāṃ puṇyānāṃ ca phalaṃ mahat |
brahmasaṃkalpakacitaṃ yathā yadyattathaiva tat
]

`v 8 [
brahmocyate'sau ciddhātuḥ so'bjajādyahamādi ca |
sa yathāste tathā tattattasya saṃkalpanaṃ jagat
]

`v 9 [
pratibhaiva vineyasya kṣetrapuṇyena tādṛśī |
tathaivodeti sā dhāturviparītavato yathā
]

`v 10 [
ekātmanāhamadyaiṣa mṛto'mī mama bandhavaḥ |
rudantīme paraṃ lokaṃ prāpto'yamahamekakaḥ
]

`v 11 [
bandhūnāmapi tatraiva tadaivāsya tathaiva ca |
pratibhā tādṛśaiveti dhātukṣobhavatāmiva
]

`v 12 [
atyugraiḥ puṇyapāpaiḥ svairvā mahātmabhirīkṣite |
lakṣyāṇyapyanyathā santi nṛṇāṃ citkalpanāvaśāt
]

`v 13 [
acetanaṃ śavībhūtaṃ te'pi paśyanti taṃ mṛtam |
rudanti taṃ ca dahane kṣipanti saha bāndhavaiḥ
]

`v 14 [
vineyaḥ sa yathānyena saṃvidrūpeṇa dehinā- |
'jarāmaraṇamātmānaṃ vetti sthitamaduḥkhitam
]

`v 15 [
yathāsthitena dehena vettyasau jīvitasthitam |
mṛtiṃ tvadṛśyenānyena kṣetrapuṇyavideritaḥ
]

`v 16 [
āvilā saṃvidā saṃvicchūnyayā vedyate kṣaṇāt |
na hi sannaddhagātrasya kleśo'sannaddhabhedane
]

`v 17 [
paśyanti bandhavo'pyenaṃ tathaivāmaratāṃ gatam |
dvayamityeṣa labhate jīvitaṃ maraṇaṃ samam
]

`v 18 [
idamapratighārambhaṃ bhrāntimātraṃ jagattrayam |
na saṃbhavati ko nāma bhrāntau bhrāntiviparyayaḥ
]

`v 19 [
saṃkalpasvapnapurayoryā bhrāntiranubhūyate |
tato'dhiko'yaṃ `note[tato'dhikeyaṃ na nyūnā jāgraditi pāṭho'trāpekṣitaḥ |] na
nyūnājjāgratsvapne'nubhūyate
]

`v 20 [
rājovāca |
dharmādharmau kathaṃ brahmankāraṇaṃ dehasaṃvidaḥ |
tasyāmūrtau kathaṃ caiko dviśarīratvamṛcchati
]

`v 21 [
śrīvasiṣṭha uvāca |
saṃkalpanagare brāhme jagatyasminmahāmate |
kiṃ nāma no saṃbhavati satyaṃ vāpyasamañjasam
]

`v 22 [
yathaiva saṃkalpapure yanna saṃbhavatīha hi |
tannāstyeva tadetasminkiṃ vā'stu brahmakalpane
]

`v 23 [
svapnasaṃkalpapurayoreko gacchati lakṣatām |
tahā caikaiva citsvapne senātvamupagacchati
]

`v 24 [
sahasrāṇyekatāṃ yānti tathā saiva suṣuptakam |
anyathā svapnasaṃkalpasenānubhavasaṃsmṛtau
]

`v 25 [
saṃkalpasvapnapurayoriti ko nānubhūtavān |
saṃvidākāśamātre'smiñjagatyanubhavātmani
]

`v 26 [
tasmādasmiṃścidākāśasaṃkalpe jagadātmani |
na saṃbhavati kiṃ nāma tatsaṃbhavati vāpi kim
]

`v 27 [
evamevamiyaṃ bhrāntirbhāti bhāsvannabhomayam |
neha kiṃcana sannāsanna vāśadiha kiṃcana
]

`v 28 [
yathānubhūyate yadyattattathā tattvadarśinaḥ |
prabuddhasyātra kiṃ nāma tatsa evāṅgatetyalam
]

`v 29 [
iha cedvihito dharmastatsvarge'mṛtaparvatāḥ |
sthitā itīha saṃkalpe kasmānna prāptavāngirīn
]

`v 30 [
iha yatkriyate karma tatparatropabhujyate |
itīha saṃkalpapure sarvamevāsamañjasam
]

`v 31 [
yadi syātsusthiraṃ kiṃcidvastu taddṛśyako bhavet |
nyāya eṣo'khilaḥ kiṃtu saṃvittvātsvasvakaṃ sthitaḥ
]

`v 32 [
ityeṣa kathito nyāyaḥ siddhāsvanubhavastataḥ |
yato jaganti saṃkalpaścito brahmasvarūpataḥ
]

`v 33 [
tava saṃkalpanagare nāstyevāsaṃbhavo yathā |
sarvārthānāṃ tathā brāhme saṃkalpe nāstyasaṃbhavaḥ
]

`v 34 [
yadyadyathā tatra brāhmasaṃkalpe kalpitaṃ tat tādṛśasaṃniveśavattathā
svabhāvenāsti
]

`v 35 [
tataḥ saṃprekṣaṇamiha saṃkaro na pravartate |
vinānyaccitprayatnena bhavatyarthastu nānyathā
]

`v 36 [
ākalpamajasaṃkalpe yathā bhātaṃ jagatsthitam |
punaranyena saṃkalparūpeṇānyadupaiṣyati
]

`v 37 [
saṃkalpātma svayaṃ bhāti kalpe kalpe jagattathā |
pratijīvaṃ citisvapne svapne svāpnapuraṃ yathā
]

`v 38 [
saṃkalpapattanatanorna tadasti kiṃcidyadyanna saṃbhavati tacca cidātmano'smāt |
nānyatprakampayiturādyaparasvarūpādbrahmaiva tena sakalaṃ jagadaṅga viddhi |
38 |
saṃkalpapattanatanorasya jagato yanna saṃbhavatīti manyase tannāsti sarvaṃ saṃbhavatyeva
tacca prakalpayiturasmāccidātmano nānyat tena hetunā jagadbrahmaiva viddhītyarthaḥ
]

`v 44 [
yadyathā kalpitaṃ tatra yāvatsaṃkalpamev tat |
svabhāvena tathaivāsti yatastatsaṃniveśavat
]