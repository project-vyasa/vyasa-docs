`v 1 [
dvādaśādhikadviśatatamaḥ sargaḥ 212
śrīvasiṣṭha uvāca |
cittvādbrahmakhamevāhamiti vettīva yatsvayam |
tadeva parameṣṭhitvaṃ tasyodaramidaṃ jagat
]

`v 2 [
evaṃ sthite na ca brahmā na ca jātaṃ jagatsthitam |
sthitaṃ yathāsthitamajaṃ paraṃ brahmaiva pūrvavat
]

`v 3 [
saṃvittau tu jagadrūpaṃ bhāsate'pyevameva tat |
mṛgatṛṣṇeva mithyaiva dṛśyamānamapi tvasat
]

`v 4 [
ataḥ prabhṛti śūnyeyaṃ bhrāntirabhyuditā navā |
kutaḥ keva kila bhrāntirbrahmaiva tadanāmayam
]

`v 5 [
jagadbrahmajalāvarto dvitvaikatve kilātra ke |
kvāvartapayasordvitvaṃ dvitvābhāvātkva caikatā
]

`v 6 [
tadbrahma ghanamāśāntaṃ cittvāccetatyahaṃ vidat |
nijaṃ śūnyatvamantasthaṃ vyomeva vitatāntaram
]

`v 7 [
pavanaḥ spandanamiva hutāśana ivoṣṇatām |
svaśaityamiva pūrṇenduḥ sattāmartha ivātmanaḥ
]

`v 8 [
śrīrāma uvāca |
etadbrahmankadā nāma tanna cetitavanmune |
nirāvṛtamanādyantaṃ kimidānīṃ pracetati
]

`v 9 [
śrīvasiṣṭha uvāca |
evametatsadaivaitadahamādyapi cetati |
na hyanāderajasyāsya kāpyapekṣā svasaṃvidā
]

`v 10 [
sargāsarganabhorūpaṃ brahma sarvatra sarvadā |
na kadācididaṃ nedaṃ jñātaṃ nedaṃ na kiṃcana
]

`v 11 [
pavanaspandanaṃ candraśaityaṃ śūnyatvamambaram |
brahmāhaṃtvamananyātma na kadācinna cetati
]

`v 12 [
sarvadaivedṛśī sattā na kadācidanīdṛśī |
jagadyasmādanādyantaṃ brahmātmaiva nirāmayam
]

`v 13 [
kevalaṃ tvamabuddhatvācchabdaśravaṇavedhitaḥ |
advaye brahmabodhe'smindvitāmabhyupagacchasi
]

`v 14 [
na kaścitkiṃcideveha na kadācinna cetati |
na kaścicca tadanyātmā na kadācicca cetati
]

`v 15 [
idaṃ tribhuvanābhāsamīdṛśaṃ bhātī sarvadā |
śāntaṃ rāma samaṃ brahma neha nānāsti kiṃcana
]

`v 16 [
na kadācana jāyante nabhasaḥ pādapādrayaḥ |
brahmaṇaśca jagantīti matvā śāntiṃ parāṃ vraja
]

`v 17 [
upadeśyopadeśārthaṃ saṃdehāvasare'lpadhīḥ |
yāvanna buddhastāvattvaṃ bhedamabhyupagacchasi
]

`v 18 [
bodhasya tu viduddhasya na śāstrādi na śabdadhīḥ |
na bhedabuddhirno bhedaḥ kimapyeṣa prajāpateḥ
]

`v 19 [
śrīrāma uvāca |
buddhametanmayā brahmanprakṛtaṃ tadudāhara |
vaco madavabodhārthaṃ yadudāhṛtavānasi
]

`v 20 [
kiṃ tasmiṃścetite'haṃtve pade saṃpadyate pare |
buddhavānasi śuśrūṣurnāhaṃ tṛptimupaimi hi
]

`v 21 [
śrīvasiṣṭha uvāca |
ahaṃtve satyathaitasminvyomasattā pravartate |
diksattā kālasattā ca bhedasattābhyudeti ca
]

`v 22 [
yadā kilehāhamiti tadā nātrāhamityapi |
bhātītyudeti nānā khe svātmaiva dvaitamakramam
]

`v 23 [
vyomātmikānāmetāsāṃ sattānāmabhidhānadhīḥ |
bhaviṣyatyuttaraṃ kālaṃ tadā tvākāśameva tat
]

`v 24 [
etasminparisaṃpanne dikkālakalanātmani |
ahaṃbhāve nirākāre vyoma tanmātravedini
]

`v 25 [
idamābhāti bhārūpaṃ vedanaṃ dṛśyanāma yat |
bhūtvā brahmaiva nirbādhamabrahmeva virājate
]

`v 26 [
brahmaiva śāntamajamekamanādimadhyaṃ vyomaiva jīvakalanāmiva bhāvayitvā |
vyomnyeva paśyati nirāvaraṇe visāri dṛśyaṃ svarūpamapi cānyadivā''trmavittvāt
]