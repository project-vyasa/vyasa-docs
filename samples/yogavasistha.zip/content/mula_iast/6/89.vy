`v 1 [
ekonanavatitamaḥ sargaḥ 89
śrīrāma uvāca |
pārthivīṃ dhāraṇāṃ baddhvā jaganti samavekṣitum |
saṃpannastvamasau bhūmilokaḥ kimuta mānasaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
idaṃ ca mānasaṃ cāhaṃ saṃpannaḥ pṛthubhūtalam |
nedaṃ na mānasaṃ naiva saṃpanno vastutastvaham
]

`v 3 [
amānasaṃ mahīpīṭhaṃ na saṃbhavati kiṃcana |
yadasadvetsi yatsadvā manomātrakameva tat
]

`v 4 [
cidākāśamāhaṃ śuddhaṃ tasya me tatpadātmanaḥ |
yaccinmātrātmakacanaṃ tatsaṃkalpābhidaṃ smṛtam
]

`v 5 [
tanmanastanmahīpṛṣṭhaṃ tajjagatsa pitāmahaḥ |
saṃkalpapuravadvyomni kacatyetanmanonabhaḥ
]

`v 6 [
evaṃ saṃkalpamātraṃ me manomātraṃ tadātatam |
dhāraṇābhyāsasaṃpuṣṭaṃ bhūmaṇḍalamiti sthitam
]

`v 7 [
nedaṃ bhūmaṇḍalaṃ tadvai tadanyaddhi manomayam |
ākāśamātrakacanamacetyaṃ kacanaṃ citeḥ
]

`v 8 [
tadevākāśamātratma tathābhūtaṃ ciraṃ sthitam |
idaṃpratyayalabdhatvānmānasatvaṃ samujjhati
]

`v 9 [
idaṃ sthiraṃ sukaṭhinaṃ vitataṃ bhūmimaṇḍalam |
astīti jāyate buddhirvyomnīva ciravedanāt
]

`v 10 [
nyāyenedamivānena na sthitaṃ vasudhātalam |
idaṃ caivaikamevādyasargasyādyamupāgatam
]

`v 11 [
vācārambhaṇaśrutidarśitanyāyena tu darśane idamivājñaprasiddharūpeṇa
vasudhātalaṃ na sthitaṃ kiṃtvādyasargasya manorūpasya ādyaṃ sūkṣmaṃ yadekameva
rūpaṃ tadevopāgataṃ sthitam | trīṇi rūpāṇītyeva satyam iti śrutyopadarśitamityarthaḥ |
10 |
yathā svapne puratvena cideva vyomni bhāsate |
tathā cideva sargādāvidaṃ jagaditi sthitam
]

`v 12 [
viddhi cidrūpabālasya manorājyaṃ jagattrayam |
mahītalādikaṃ dṛśyamidaṃ sarvaṃ ca sarvadā
]

`v 13 [
cidrūpasyātmano nānyaḥ saṃkalpastanmayaṃ jagat |
vastutastu na satyātma na piṇḍātma na bhāsuram
]

`v 14 [
dṛśyamastyaparijñātaṃ parijñātaṃ na vidyate |
parijñātaṃ tadevāsya śṛṇoṣi yadidaṃ ciram
]

`v 15 [
sarvaṃ cinmātramāśāntaṃ prakacatyātmanātmani |
bhūmaṇḍalātma dṛśyātma dvaitaikyābhyāṃ vivarjitam
]

`v 16 [
maṇiryathā svabhāvena śuklapītādikāstviṣaḥ |
akurvanneva kurute cidākāśastathā jagat
]

`v 17 [
yato na kiṃcitkurute na ca rūpaṃ samujjhati |
tasmānna mānasaṃ nedaṃ kiṃcidasti mahītalam
]

`v 18 [
mahītalamivābhāti cidvyomaiva nirantaram |
ātmanyevātalaṃ vyoma yathāmalatalaṃ sthitam
]

`v 19 [
svabhāvamātrakacanaṃ tattadeva yathāsthitam |
bhūmaṇḍalamivātyacchaṃ khameva viśatāntaram
]

`v 20 [
antaraṃ bhedaṃ antarddhiṃ vā viśatā svabhāvena bhūmaṇḍalamiva dṛśyata ityarthaḥ |
19 |
idaṃ bhūmaṇḍalaṃ tacca dvayametanmahāciteḥ |
svarūpameva kacati tava svapnapuraṃ yathā
]

`v 21 [
idamākāśamātrātma tadapyākāśamātrakam |
ajñānātmaparijñānājjñānānnedaṃ na tatkvacit
]

`v 22 [
trailokyabhūtajālānāṃ kālatritayabhāvinām |
saṃbhramaḥ svapnasaṃkalo manorājyadaśāsthitau
]

`v 23 [
bhūtānyatha bhaviṣyanti vartamānāni yāni ca |
bhūmaṇḍalāni tānyaṅga sattā sāmānyatāṃ gatā
]

`v 24 [
ahameva samagrāṇi teṣāmantargatānyapi |
tena tānyanubhūtāni tathā dṛṣṭāni cākhilam
]

`v 25 [
cinmātrametadajaraṃ paramātmatattvaṃ śuddhātmatāmajahadaṅgagataṃ vibharti
|
sarvaṃ yathāsthitamidaṃ jagadāttabhedaṃ buddhaṃ sadaṅga na bibharti tu
kiṃcanāpi
]