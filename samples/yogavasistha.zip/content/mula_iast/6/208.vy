`v 1 [
aṣṭādhikadviśatatamaḥ sargaḥ 208
śrīvasiṣṭha uvāca |
śubhāśubhaṃ yathodeti prajānāṃ gṛhasaṃgame |
asaṃbaddhairapratighairdūrasthaistadidaṃ śṛṇu
]

`v 2 [
brahmasaṃkalpanagaraṃ jagattāvadidaṃ sthitam |
yaddṛśyaṃ dṛśyabodhena brahmaiva brahmabodhataḥ
]

`v 3 [
yadyatsaṃkalpanagare yadā saṃkalpyate yathā |
tathānubhūyate tattattādṛgviracnaṃ tadā
]

`v 4 [
evamasmingṛhe yāte saṃpannaivamiyaṃ prajā |
evaṃ saṃkalpasaṃpanne jagatyevaṃ bhavatyalam
]

`v 5 [
etatsvasaṃkalpapure yādṛśaṃ te tathā sthitam |
yathā saṃkalpayasi yattattathā kila paśyasi
]

`v 6 [
yathaiva varaśāpābhyāṃ śuddhasaṃvidavāpyate |
saṃvittathaiva bhavati brāhmameveti kalpanam
]

`v 7 [
prajāvidhiniṣedhābhyāmekayāśthāvyavasthayā |
tathaiva phalamāpnoti brāhmameveti kalpanam
]

`v 8 [
dehino ye jagatyasmiṃstānpratyanupalambhataḥ |
asadāsījjagatpūrvaṃ satyamityupalabhyate
]

`v 9 [
cidrūpabrahmasaṃkalpavaśādevaitadaṅga sat |
cidunmeṣanimeṣau yau tāvetau pralayodayau
]

`v 10 [
rājovāca |
kiṃ nopalabhyate pūrvaṃ kiṃ paścādupalabhyate |
jagaccaladvapuridaṃ susthirārambhabhāsvram
]

`v 11 [
śrīvasiṣṭha uvāca |
asmiṃścidvyomasaṃkalpapurasthe bhāva īdṛśaḥ |
yadbhūtvā na bhavatyeva punarbhavati ca kṣaṇāt
]

`v 12 [
bālasaṃkalpapuravadvyomakeśoṇḍrakādivat |
kilaite sadasadrūpā bhānti sargāścidātmani
]

`v 13 [
tvaṃ saṃkalpapuraṃ kṛtvā vināśyasi tatkṣaṇāt |
svato'nyasaṃvidvaśataḥ svasvabhāvaḥ sa te yathā
]

`v 14 [
cidvyomakalpanapure yadunmajjanamajjanam |
svabhāvakacanaṃ tasya tadviddhi vimalaṃ tathā
]

`v 15 [
saṃvidghanastvanādyantavyomaiva trijagannabhaḥ |
tenāsāvadya yannāma karotyapi ca cetati
]

`v 16 [
tadanāvaraṇasyāsya yojanānāṃ śateṣvapi |
yugairapi svapna iva kāryakṛdvartamānavat
]

`v 17 [
kila deśāntare nityamatha lokāntare'pi ca |
nirāvṛto ya ekātmā sa kiṃ nāma na cetati
]

`v 18 [
yathā maṇau prakacati pronmajjananimajjane |
parāvartaḥ svabhāsāsya cinmaṇau jagatāṃ tathā
]

`v 19 [
vidhīnāṃ pratiṣedhānāṃ lokasaṃsthāprayojanam |
saiva saṃvidi rūḍhatvātpretyāpi phaladā sthitā
]

`v 20 [
na kadācana yātyastamudeti na kadācana |
brahma brahmacidābhānaṃ sarvadātmanyavasthitam
]

`v 21 [
yathā tu draṣṭṭadṛśyatvātkalpanā kalpanāpuram |
svayaṃ jagadivābhāti jātamityucyate tathā
]

`v 22 [
yadā svabhāvātkacanaṃ saṃhṛtyātmani tiṣṭhati |
brahmacidgaganaikātmā śānta ityucyate tathā
]

`v 23 [
kacanākacane yasya svabhāvo nirmalo'kṣayaḥ |
yathaitāvātmano nānyau spandāspandau nabhasvataḥ
]

`v 24 [
jarāmaraṇahantṛṇi kṣaṇānyatra pṛthakpṛthak |
bhavantviti yathaitāni santi tvatkalpanāpure
]

`v 25 [
brahmasaṃkalpanagare svabhāvā uditāstathā |
oṣadhīnāṃ padārthānāṃ sarveṣāṃ ca jagattraye
]

`v 26 [
na saṃkalpayitā rājansaṃkalpanagare svayam |
tṛṇaṃ tṛṇaṃ kalpayati bālaḥ krīḍanakāniva
]

`v 27 [
tarhi kimīśvaraḥ pratikṣaṇaṃ prativastu śaktikāryādibhedānsaṃkalpayitā kalpyate
netyāha - na saṃkalpayiteti | prativastu pratikṣaṇamīśvaro na saṃkalpayitā kalpyate
kiṃtu bālaḥ krīḍanakānyantraviśeṣāniva sakṛdeva
saṃkalpayatyetajjātīyametajjātīyakāryakṛdbhavatu tacca tajjātīyamitthamutpadyatāmiti |
tadevaśādeva bījāṅkurādikrameṇa pūrvapūrvatṛṇamuttarottaratṛṇaṃ kalpayati | 26
|
svayaṃ svabhāva evaiṣa cidghanasyāsya susphuṭam |
yadyatsaṃkalpayatyāśu tatra te'vayavā api
]

`v 28 [
cidātmakatayā bhānti nānātmakatayātmanā |
apyekasārāstiṣṭhanti nānākārasvabhāvagāḥ
]

`v 29 [
pratyekaṃ kila tatrāsti brahmacinmātratātmani |
sarvātmikā sā yatrāste yathāntarbhāti tattathā
]

`v 30 [
anādimadhyāntamanantavīryaṃ kiṃcinna kiṃcicca sadapyasatyam |
sthitaṃ yathā yatra tadātma tatra sarvātmabhūrbhūtatṛṇādijātau
]