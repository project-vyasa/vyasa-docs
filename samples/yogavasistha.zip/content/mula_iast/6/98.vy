`v 1 [
aṣṭanavatitamaḥ sargaḥ 98
śrīvasiṣṭha uvāca |
vivekino viraktā ye viśrāntā ye pare pade |
teṣāṃ tanutvamāyānti lobhamohādayo'rayaḥ
]

`v 2 [
na hṛṣyanti na kupyanti nāviśantyāharanti ca |
udvijante'pi no lokāllokānnodvejayanti ca
]

`v 3 [
nāviśanti kvāpi viṣaye nābhiniviśante | evaṃ nāharanti na saṃgṛhṇanti bhogyajātam |
2 |
na nāstikyānna cāstikyātkaṣṭānuṣṭhānavaidikāḥ |
manojñamadhurācārāḥ priyapeśalavādinaḥ
]

`v 4 [
evaṃ pāralaukikakarmasvapi nātyantakāyakleśāvaheṣu
śuṣkavaidikavaddhaṭhātkliśyantītyāha - neti | asti paraloka iti matiryasya sa āstikaḥ
nāsti sa iti matiryasya sa nāstikaḥ tadanyatarabhāvābhimānaprayuktāddhaṭhādityarthaḥ | 3
|
saṅgādāhlādayantyantaḥ śaśāṅkakiraṇā iva |
vivecitāraḥ kāryāṇāṃ nirṇetāraḥ kṣaṇādapi
]

`v 5 [
anudvegakarācārā vāndhavā nāgarā iva |
bahiḥ sarvasamācārā antaḥ sarvārthaśītalāḥ
]

`v 6 [
śāstrārtharasikāstajjñā jñātalokaparāvarāḥ |
heyopādeyavettāro yathāprāptābhipātinaḥ
]

`v 7 [
viruddhakāryaviratā rasikāḥ sajjanasthitau |
anāvaraṇasaugandhyaiḥ parāspadasukhāśanaiḥ
]

`v 8 [
pūjayantyāgataṃ phullā bhaṅgaṃ padmā ivārthinam |
āvarjayanti janatāṃ janatāpāpahāriṇaḥ
]

`v 9 [
śītalāspadavatsnigdhāḥ prāvṛṣīva payodharāḥ |
bhūbhṛdbhaṅgakaraṃ dhīrā deśabhaṅgadamākulam
]

`v 10 [
rodhayantyāgataṃ kṣobhaṃ bhūkampamiva parvatāḥ |
utsāhayanti vipadi sukhayanti ca saṃpadi
]

`v 11 [
candrabimbopamākārā dārā iva guṇākarāḥ |
yaśaḥpuṣpāmaladiśo bhāvisatphalahetavaḥ
]

`v 12 [
puṃskokilasamālāpā mādhavā iva sādhavaḥ |
kallolabahulāvartaṃ vyāmohamakarālayam
]

`v 13 [
luṭhantamiva hemantaṃ loḍayantaṃ janāspadam |
vīcivikṣobhacapalaṃ paracittamahārṇavam
]

`v 14 [
tacca rodhayituṃ śaktāstaṭasthāḥ sādhuparvatāḥ |
āpatsu buddhināśeṣu kalloleṣvākuleṣu ca
]

`v 15 [
saṃkaṭeṣu duranteṣu santa eva gatiḥ satām |
ebhiścihnairathānyaiśca jñātvā tānucitāśayān
]

`v 16 [
āśrayetaikaviśrāntyai śrāntaḥ saṃsāravartmanā |
yasmādatyantaviṣamaḥ saṃsāroragasāgaraḥ
]

`v 17 [
vinā satsaṅgamanyena potakena na tīryate |
āstāṃ kiṃ me vicāreṇa yadbhavedastu tanmama
]

`v 18 [
ityantaḥ kalkamāsādya na stheyaṃ gartakīṭavat |
eko'pi vidyate yasya guṇastaṃ sarvamutsṛjan
]

`v 19 [
anādṛtānyataddoṣaṃ tāvanmātraṃ samāśrayet |
guṇāndoṣāṃśca vijñātumābālyātsvaprayatnataḥ
]

`v 20 [
yathāsaṃbhavasatsaṅgaśāstraiḥ prāgdhiyamedhayet |
doṣaleśamanādṛtya nityaṃ seveta sajjanam
]

`v 21 [
sthūladoṣaṃ tvanirvāṇaṃ śanaiḥ pariharetkramāt |
yāti ramyamaramyatvaṃ sthiramasthiratāmapi
]

`v 22 [
yathā dṛṣṭaṃ tathā manye yāti sādhurasādhutām |
eṣa so'tyanta utpāto yaḥ sādhuryāti duṣṭatām
]

`v 23 [
deśakālavaśātpāpairmahotpāto'pi dṛśyate |
sarvakarmāṇi saṃtyajya kuryātsajjanasaṃgamam |
etatkarma nirābādhaṃ lokadvitayasādhanam
]

`v 24 [
na sajjanāddūrataraḥ kvacidbhavedbhajeta sādhūnvinayakriyānvitaḥ |
spṛśantyayatnena hi tatsamīpagaṃ vidāriṇastadgatapuṣpareṇavaḥ
]