`v 1 [
caturadhikadviśatatamaḥ sargaḥ 204
śrīvasiṣṭha uvāca |
bhūya eva mahābāho śṛṇu me paramaṃ vacaḥ |
ādarśo rājate'tyarthaṃ paunaḥpunyena mārjitaḥ
]

`v 2 [
artho vedanasaṃketaḥ śabdo jalaravopamaḥ |
dṛśyametaccidābhānaṃ svapnavatkvābhavajjagat
]

`v 3 [
jāgadvai svapnasaṃdṛṣṭaḥ smaraṇātma sthitaṃ puraḥ |
saṃvidvedanamātraṃ sattadanyākāravattatam
]

`v 4 [
yathācchaṃ saṃvidākāśaṃ mayi svapnapurātmakam |
sarūpamapi nīrūpaṃ tathedaṃ bhuvanatrayam
]

`v 5 [
śrīrāma uvāca |
saṃpanneyaṃ kathaṃ bhūmiḥ saṃpannā girayaḥ katham |
kathaṃ saṃpannamambhaśca saṃpannā upalāḥ katham
]

`v 6 [
kathaṃca tejaḥ saṃpannaṃ saṃpannā ca kathaṃ kriyā |
kathaṃ ca kālaḥ saṃpannaḥ saṃpannaḥ pavanaḥ katham
]

`v 7 [
kathaṃ ca śūnyaṃ saṃpannaṃ saṃpannaṃ cinnabhaḥ katham |
iti jñātaṃ mayā bhūyo bodhāya vada me prabho
]

`v 8 [
śrīvasiṣṭha uvāca |
brūhi rāghava tattvena svapnadṛṣṭamahāpure |
saṃpannā bhūḥ kathamiva saṃpannaṃ kathamambaram
]

`v 9 [
kathaṃ vāri ca saṃpannaṃ saṃpannā upalāḥ katham |
kathaṃ ca tejaḥ saṃpannaṃ saṃpannāśca kathaṃ diśaḥ
]

`v 11 [
saṃpannaśca kathaṃ kālaḥ saṃpannā ca kathaṃ kriyā |
kathametannimittādi `note[niyatyādīti pāṭhaḥ |] sarvaṃ saṃpannamucyatām | 10
|
kenedaṃ nirmitaṃ dagdhamānītaṃ racitaṃ citam |
utpāditaṃ prakaṭitaṃ kimācāraṃ kimātmakam
]

`v 12 [
śrīrāma uvāca |
ātmāsya kevalaṃ vyoma na sadbhūmyacalādikam |
jagataḥ svapnarūpasya nirākāro nirāspadaḥ
]

`v 13 [
ātmaiva vyomarūpo'sya nirādhāro nirākṛtiḥ |
vinākṛtervā vyomno'sya kimādhāreṇa kāraṇam
]

`v 14 [
na kiṃcidetatsaṃpannaṃ sadyathaitanna saṃvidaḥ |
etaccitkacanaṃ nāma mana eva tathā sthitam
]

`v 15 [
abhyupetya pṛthvyādyākārasaṃpattimidamuktaṃ vastutastu tatsaṃpattirapi nāstyevetyāha
- na kiṃciditi | etajjagadākāraṃ citkacanaṃ svapnavanmana eva tathā sthitaṃ nānyat |
14 |
dikkālādyatra cidbhānaṃ cidbhānamacalādikam |
cijjalādi tathā bodhāccitkhaṃ vāyvādi tadvidah
]

`v 16 [
saṃvideva kila vyoma tiṣṭhati vyomatāmitā |
dṛṣattayāste kāṭhinyāddravājjalamiva sthitā
]

`v 17 [
vastutastu na bhūmyādi kiṃcittanna ca dṛśyatā |
cidākāśamanantaṃ tatsarvamekaṃ tadātmakam
]

`v 18 [
dravtvādambu hṛdyābdhernānāvṛttitayā yathā |
anānaiva bhavennānā cidvyomātmani vai tathā
]

`v 19 [
kāṭhinyavedanādurvī giritāmāgateva cit |
śūnyatāvedanācchūnyaṃ vetti vyomeva cidvapuḥ
]

`v 20 [
dravatvavedanādvetti vāri spandatayānilam |
auṣṇyasaṃvittato vahnimatyajantī nijaṃ vapuḥ
]

`v 21 [
evaṃsvabhāva evāyaṃ ciddhāturgaganātmakaḥ |
yadevaṃ nāma kacati niṣkāraṇaguṇakramam
]

`v 22 [
na caitadvyatirekeṇa kiṃcinnāpīha vidyate |
anyacchūnyatvavāribhyāmṛte khārṇavayoriva
]

`v 23 [
na tu cidgaganādanyanna saṃbhavati kiṃcana |
idaṃ tvamahamityādi tasmādāśāntamāsyatām
]

`v 24 [
idaṃ tvamahamityādi jagat cidgaganādanyanna tu | yataḥ kiṃcana tadvinā na saṃbhavati |
23 |
tvaṃ yathāsmin gṛhe kurvannagniśailādikāṃ vidam |
tadeva paśyasyavapurevaṃ cidgaganaṃ tathā
]

`v 25 [
cidvyoma bhāti dehābhaṃ sargādau na tu dehakaḥ |
akāraṇatvādasataścidudetīti cintyatām
]

`v 26 [
manobuddhirahaṃkāro bhūtāni girayo diśaḥ |
śilājaṭharavanmaunamayaṃ sarvaṃ yathāsthitam
]

`v 27 [
evaṃ na kiṃcidutpannaṃ naṣṭaṃ na ca na kiṃcana |
yathāsthitaṃ jagadrūpaṃ cidbrahmātmani tiṣṭhati
]

`v 28 [
citau yatkacanaṃ nāma svrūpapravijṛmbhaṇam |
tadetajjagadityuktaṃ drava eva yathā jalam
]

`v 29 [
idaṃ jagadbhānamabhānameva cidvyoma śūnyaṃ paramārtha eva |
yathārthasaṃdarśanabuddhabuddherabuddhabuddhestu yathā tathāstu
]