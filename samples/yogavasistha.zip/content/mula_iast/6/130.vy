`v 1 [
triṃśadadhikaśatatamaḥ sargaḥ 130
śrīvālmīkiruvāca |
atha rāma uvācāsya mune kena vipaścitaḥ |
syādupāyena duḥkhāntaḥ prāktanātmodayāditi
]

`v 2 [
śrīvasiṣṭha uvāca |
yenaivābhyuditā yasya tasya tena vinā gatiḥ |
na śobhate na sukhadā na hitāya na satphalā
]

`v 3 [
vipaścito'gniḥ śaraṇaṃ tatpraveśādayaṃ mṛgaḥ |
pūrvarūpamavāpnoti nirmalaṃ kanakaṃ yathā
]

`v 4 [
karomyetadahaṃ sarvaṃ dṛśyatāṃ darśayāmi vaḥ |
agnipraveśaṃ hariṇaḥ karotyeṣo'dhunā puraḥ
]

`v 5 [
śrīvālmīkiruvāca |
ityuktvā sa munistatra vasiṣṭhaḥ śreṣṭhaceṣṭitaḥ |
upaspṛśya yathānyāyaṃ svakamaṇḍaluvāriṇā
]

`v 6 [
dadhyāvanindhanaṃ vahniṃ jvālāpuñjamayātmakam |
taddhyānena sabhāmadhyājjvālājālaṃ samudyayau
]

`v 7 [
aṅgārarahitākāramindhanena vivarjitam |
svacchaṃ dhamadhamāyantamadhūmamapakajjalam
]

`v 8 [
mugdhamugdhakacatkānti hemamandirasundaram |
utphullakiṃśukākāraṃ saṃdhyāmbudavadutthitam
]

`v 9 [
dūrāpasṛtasabhyaṃn tajjvālājālaṃ vilokayan |
mṛgaḥ prāgbhaktibhāvena prollalāsa vilokitaiḥ
]

`v 10 [
taṃ samālokayanvahniṃ vivikṣuḥ kṣīṇaduṣkṛtaḥ |
paścādupasasārāśu dūraṃ siṃha ivotpatan
]

`v 11 [
etasminnantare dhyāne vicārya munipuṅgavaḥ |
mṛgaṃ vilokitaiḥ kṣīṇapāpaṃ kurvannuvāca ha
]

`v 12 [
saṃsmṛtya prāktanīṃ bhaktiṃ bhagavanhavyavāhana |
kuru kāruṇyataḥ kāntaṃ mṛgamenaṃ vipaścitam
]

`v 13 [
vadatyevaṃ munau dūrāddhāvitvā nṛpasaṃsadi |
mṛgo'gniṃ veganirmuktaḥ śaro lakṣyamivāviśat
]

`v 14 [
jvālājālaṃ praviṣṭo'sāvādarśa iva bimbitaḥ |
saṃdhyābhra iva viśrānto dṛṣṭaḥ spaṣṭaśarīrakaḥ
]

`v 15 [
sa paśyatsveva sabhyeṣu mṛgo'tha naratāmagāt |
jvālodare nabhasyabhralavo rūpāntaraṃ yathā
]

`v 16 [
adṛśyatātha jvālāyāmantaḥkanakakāntimān |
puruṣaḥ pāvanākāraḥ kāntāvayavasundaraḥ
]

`v 17 [
arkabimba ivādityaścandrabimba ivoḍupaḥ |
mahāmbhasīva varuṇaḥ saṃdhyābhra iva vā śaśī
]

`v 18 [
cakṣuḥkanīnikākośe mukure salile maṇau |
pratibimba ivārkābho bhaktinādhārapāvakaḥ
]

`v 19 [
anantaraṃ sabhāmadhyādvātairdīpa ivāhataḥ |
jvālājālaṃ yayau kvāpi saṃdhyāmbuda ivāmbarāt
]

`v 20 [
kuṭīkuḍyeṣu bhagneṣu pratibimba ivāmaraḥ |
atiṣṭhatpuruṣastatra paṭānnaṭa ivodgataḥ
]

`v 21 [
akṣamālādharaḥ śānto hemayajñopavītavān |
agniśaucāmbaracchannaḥ sadyaścandra ivoditaḥ
]

`v 22 [
aho bhā iti sabhyoktyā tasya veṣasya bhāsanāt |
bhāsvāniva viśālābho bhāsa ityeṣa śabditaḥ
]

`v 23 [
asau mūrta ivābhāso bhāsanāmnā bhaviṣyati |
sabhāsthaiḥ kaiścidityuktaṃ tena bhāsaḥ sa ucyate
]

`v 24 [
athopaviśya tatraiva sa bhāso dhyānasaṃsthitaḥ |
ātmodantamaśeṣeṇa sasmāra prāktanaṃ tanau
]

`v 25 [
sabhāloke gataspande smayenātmani tiṣṭhati |
bhāso muhūrtamātreṇa dṛṣṭvā svodantamakṣatam
]

`v 26 [
smayena vismayena `note[smitena iti mudritapustake pāṭhaḥ |] | dṛṣṭvā smṛtvā | 25
|
āyayau pūrvajanmabhyo dhyānālokādvyabudhyata |
sabhāmālokayāmāsa samutthāya yathākramam
]

`v 27 [
sa cāgatya vasiṣṭhāya praṇāmamakaronmudā |
jñānārkaprāṇada brahmannamaste'stvityudāharat
]

`v 28 [
tamuvāca vasiṣṭho'pi hastena śirasi spṛśan |
adya te sucirādrājannavidyāyāḥ kṣayo'stviti
]

`v 29 [
rāmaṃ jayeti jalpantaṃ nataṃ daśaratho'tha tam |
āsanātkiṃciduttiṣṭhansamuvāca hasanniva
]

`v 30 [
daśaratha uvāca |
svāgataṃ te'stu bho rājannidamāsanamāsyatām |
anekabhavasaṃbhārabhrānta viśramyatāmiha
]

`v 31 [
śrīvālmīkiruvāca |
vadatyevaṃ daśarathe vipaścidbhāsanāmabhṛt |
viveśa viṣṭare viśvāmitrādīnpraṇamanmunīn
]

`v 32 [
daśaratha uvāca |
aho bata ciraṃ kālamālāneneva dantinā |
anyenāvidyayā duḥkhamanubhūtaṃ vipaścitā
]

`v 33 [
asamyagbodhadurdṛṣṭeraho nu viṣamā gatiḥ |
vyomnyeva darśayatyeṣā sargāḍambarasaṃbhramam
]

`v 34 [
kiyantyāścaryametāni jaganti vitatātmani |
saṃtatāni ciraṃ tāni vibhrāntāni vipaścitā
]

`v 35 [
vyomātmano'pi mahimāyamaho nu kīdṛgasya svabhāvavibhavasya cidātmavṛtteḥ |
yaḥ śūnya eva paramātmaghane'mbare'ntarevaṃvidhāni vividhāni jaganti bhānti | 35
|
cidātmavṛttermāyāsvabhāvarūpasyāsya vibhavasya vastuto vyomātmanaḥ
śūnyasyāpyayaṃ mahimā kīdṛk | aho ityāścarye | nu iti vitarke | yo mahimā śūnya eva
sannambaravadasaṅge śūnye eva paramātmaghane antaḥ evaṃvidhāni prāguktaprakārāṇi
vividhāni vicitrāṇi jaganti bhūtvā bhānti | idamatyāścaryamityarthaḥ
]