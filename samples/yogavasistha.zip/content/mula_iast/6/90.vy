`v 1 [
navatitamaḥ sargaḥ 90
śrīrāma uvāca |
anantaraṃ vada brahmañjaganti bhavatā tadā |
bhūmaṇḍalānāṃ hṛdaye kvaciddṛṣṭāni naiva vā
]

`v 2 [
śrīvasiṣṭha uvāca |
parātmajāgratsvapnorvīmaṇḍalaughātmanā mayā |
tato'nubhūtaṃ hṛdaye dṛṣṭaṃ ca parayā dṛśā
]

`v 3 [
yāvattathaiva sarvatra jagajjālamavasthitam |
sarvaṃ dṛśyamayaṃ śāntamapi dvaitamayātmakam
]

`v 4 [
jaganti santi sarvatra sarvatra brahma saṃsthitam |
sarvaṃ śūnyaṃ paraṃ śāntaṃ sarvamārambhamantharam
]

`v 5 [
sarvatraivāsti pṛthvyādi sthūlaṃ tacca na kiṃcana |
cidvyomaiva yathā svapnapuraṃ paramajātavat
]

`v 6 [
neha nānāsti no nānā na nāstitvaṃ na cāstitā |
ahamityeva naivāsti yatra tatra kuto'sti kim
]

`v 7 [
anubhūtamapīdaṃ sadahamityādirūpakam `note[dṛśyakaṃ iti pāṭhaḥ] |
nāstyeva yadi vāpyasti tadbrahmājamanāmayam
]

`v 8 [
yatsvapnapuramevedaṃ sargādāveva cinnabhaḥ |
astitānāstite tatra kīdṛśe kva kutaḥ sthite
]

`v 9 [
yathāhaṃ dṛṣṭavāṃstāni jagantyavanirūpadhṛk |
tathā mayā jalībhūya dṛṣṭaṃ tādṛśameva tat
]

`v 10 [
vāridhāraṇayā vāri bhūtvā jaḍamivājaḍam |
samudramandireṣvantaściraṃ gulagulāyitam
]

`v 11 [
tṛṇavṛkṣalatāgulmavallīnāṃ stambhanāḍiṣu |
mṛdvalakṣitamārūḍhaṃ tavāṅgeṣviva yūkayā
]

`v 12 [
sarvotthānopamāstambhe tacchede valayopamā |
mṛdvyā karṇāhigatyeva `note[mayā karṇāhigatyeva mṛdvyā gatyā tṛṇādīnāṃ
stambhe prakāṇḍe sarvotthānopamā sarveṣāṃ
tṛṇādīnāmutthānamūrdhvasthitistadupamā tatsadṛśī yathā ūrdhvasthitiḥ
syāttathetyarthaḥ | teṣāṃ tṛṇādīnāṃ chede bhede parvabhede tadudare
chidrabhede ca valayopamā valayākāravatī racanā prakṛtā saṃpāditetyartha iti
yojanā kāryā | pūrvaśloke yūkopamayā hyārohaṇamātraṃ pratipāditaṃ
karṇāhītyādyupamayā tvākāraviśeṣapratipādanapūrvakaṃ tatpratipāditamiti
jñeyam |] racanā prakṛtodare
]

`v 13 [
vallītamālatālādipallaveṣu phaleṣu ca |
viśramya puṣṭayā''kṛtyā rekhāviracanaṃ kṛtam
]

`v 14 [
mukhenāviśya hṛdayamṛtuvaidhuryadhāriṇā |
hṛtā vidhuritā bhuktā lūnā deheṣu dhātavaḥ
]

`v 15 [
suptaṃ pallavatalpeṣu prāleyakaṇarūpiṇā |
tulyakālamaśeṣeṣu dikṣu sarvāsvakhedinā
]

`v 16 [
nānāhradanadīgehagrāhiṇā'viratādhvanā |
viśrāntaṃ setusuhṛdaḥ prasādena kvacitkvacit
]

`v 17 [
vidā'vidanusaṃdhānājjaḍena tadanāśrayāt |
jaḍāyaśeṣūllasitaṃ jalenāvartavartinā
]

`v 18 [
mayā duṣkṛtinevordhvaśilāsvasthena bhūbhṛtām |
svāvartavartinā śvabhrapāteṣu śatadhā gatam
]

`v 19 [
dhūmarūpeṇa nirgatya dārubhyo gaganārṇave |
kaṇaratnena nīlarkṣamaṇyantarvartinā sthitam
]

`v 20 [
viśrāntamabhrapīṭheṣu vidyudvanitayā saha |
bhinnendranīlanīlena śeṣāṅgeṣviva śauriṇā
]

`v 21 [
paramāṇumaye sarge piṇḍarūpeṣvalakṣitam |
sthitamantaḥpadārtheṣu brahmaṇevākhilātmanā
]

`v 22 [
prāpya jihvāṇubhiḥ saṅgamanubhūtiḥ kṛtottamā |
yāmātmano na dehasya manye jñānasya kevalam
]

`v 23 [
na mayā na ca dehena nānyenāsvāditātma yat |
tadantarvivṛtaṃ cetyamajñānāya tadapyasat
]

`v 24 [
sarvarturasarūpeṇa nānāmodāni dikṣvalam |
bhuktāni puṣpajālāni procchiṣṭaṃ dadatālaye
]

`v 25 [
caturdaśaprakārāṇāṃ bhūtānāmaṅgasandhiṣu |
uṣitaṃ cetaneneva jaḍenāpyajaḍātmanā
]

`v 26 [
sīkarotkararūpeṇa rathamāruhya mārutam |
āmodeneva vihitaṃ vimalavyomavīthiṣu
]

`v 27 [
rāma tasyāmavasthāyāṃ paramāṇukaṇaṃ prati |
anubhūtamaśeṣeṇa yathāsthitamidaṃ jagat
]

`v 28 [
ajaḍena jaḍeneva samayā jālayā tayā |
antaḥsarvapadārthānāṃ jñātājñātena saṃsthitam
]

`v 29 [
jagatāṃ tatra lakṣāṇi nāśotpātaśatāni ca |
mayā dṛṣṭāni rūḍhāni kadalīdalapīṭhavat
]

`v 30 [
evaṃ jagaccājagadvā sākāraṃ vā nirākṛti |
cinmātragaganaṃ sarvamākāśādhikanirmalam
]

`v 31 [
na kiṃcana tvaṃ ca na kiṃcanedaṃ śuddhaḥ paro bodha idaṃ vibhāti |
sa cāpi no kiṃcana nāpi śūnyamākāśamevāsi vikāsamāsva
]