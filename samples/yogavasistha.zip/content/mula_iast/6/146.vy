`v 1 [
ṣaṭcatvāriṃśadadhikaśatatamaḥ sargaḥ 146
vyādha uvāca |
anantaraṃ muniśreṣṭha tasminhṛdi tadojasi |
sthitasya tava kiṃ vṛttaṃ nāmato bhrāntirūpiṇi
]

`v 2 [
muniruvāca |
anantaraṃ tadā tatra śṛṇu kiṃvṛttamaṅga me |
tejodhātuniṣaṇṇasya tajjīvāvalitākṛteḥ
]

`v 3 [
tasmiṃstadā vartamāne ghore kalpāntasaṃbhrame |
tṛṇavatprauḍhaśailendre vahati pralayānile
]

`v 4 [
girivṛṣṭirjhaṭityeva kuto'pi samupāyayau |
uhyamānavanābhogaśikharagrāmapattanā
]

`v 5 [
tasyāntastatra saṃprāptaṃ tadā pariṇataṃ yadā |
tadā tadeva sūkṣmo'hamapaśyaṃ śailavarṣaṇam
]

`v 6 [
tenānnalavaśailoccapūreṇa pratipiṇḍitaḥ |
suṣuptamadhatāmiśramahayanvabhavaṃ ghanam
]

`v 7 [
atha kaṃcittadā kālamanubhūya suṣuptatām |
tadā padmākara iva śanairbodhonmukho'bhavam
]

`v 8 [
yathā dṛṣṭiścirāddhvānte bhāti cakrakarupiṇī |
suṣuptameva tatrāsīttathā svapnatvamāgatam
]

`v 9 [
tathā suṣuptaviśrānteḥ svapne nidrāmahaṃ viśam |
apaśyaṃ dṛśyamojo'ntaḥ svamūrmitvamivārṇavaḥ `note[svamūrtitvaṃ iti
pāṭhaḥ |]
]

`v 10 [
saṃvitkośātmakaṃ dṛśyaṃ tattathā māmupāgatam |
aspandasyānilasyāntarananyatspandanaṃ yathā
]

`v 11 [
agnyādau ca yathoṣṇatvaṃ jalādau dravatā yathā |
marīcādau yathā taikṣṇyaṃ cidvyomnaśca jagattathā
]

`v 12 [
citsvabhāvaikarūpatvājjagaddṛśyaṃ tadātatam |
tatsuṣuptātmano dṛśyātprasūtaṃ bālaputravat
]

`v 13 [
vyādha uvāca |
tatsuṣuptātmano dṛśyāditi tadvyapadeśataḥ |
suṣuptadṛśyaṃ kiṃ vakṣi vada me vadatāṃ vara
]

`v 14 [
tatsuṣuptātmano dṛśyāttvatsuṣuptātmano'pi ca |
kimanyajjāyate janyamathavānyasuṣuptatā
]

`v 15 [
muniruvāca |
jāyate bhāti kacati ghaṭādi jagadādi ca |
iti dvaitopataptānāṃ pralāpaḥ kalpanātmakaḥ
]

`v 16 [
jātaśabdo hi sanmātraparyāyaḥ śrūyatāṃ katham |
prādurbhāve janistūktaḥ prādurbhāvasya bhūrvapuḥ
]

`v 17 [
sattārtha eva bhūḥ proktastasmātsaṃjātamucyate |
sargato jāta ityukte sansarga iti śabditam
]

`v 18 [
budhānāmasmadādīnāṃ na kiṃcinnāma jāyate |
na ca naśyati vā kiṃcitsarvaṃ śāntamajaṃ ca sat
]

`v 19 [
sarvasattātmakaṃ brahma sarvasattātmakaṃ jagat |
vidhayaḥ pratiṣedhāśca vada tatra laganti ke
]

`v 20 [
yā nāma śaktiḥ kācitsā tatraivāsti ca nāsti ca |
yasmāttadātma tadbrahma tathaivātma tadātmakam
]

`v 21 [
jāgratsvapnasuṣuptādiparamārthavidāṃ vidām |
na vidyate kiṃcidapi yathāsthitamavasthitam
]

`v 22 [
svapnasaṃkalpapurayornāstyapyanubhavasthayoḥ |
manāgapi yathā rūpaṃ sargādau jagatastathā
]

`v 23 [
draṣṭāsyāḥ svapnadṛṣṭestu jīvaḥ saṃbhavatīha hi |
cidacetyā tu sargādau bhātyacchā gaganādapi
]

`v 24 [
neha draṣṭāsti no bhoktā sarvamastīha tādṛśam |
yanna kiṃcicca kiṃcicca maunamevātivāgapi
]

`v 25 [
sargādau kāraṇābhāvādyadyathā kacitaṃ citau |
tattathāste ciraṃ rūpaṃ svapnasaṃkalpapūryathā
]

`v 26 [
tathāsmāccetanāddvaitādbibheti na bibheti vā |
aṅgasaṃsthādyathā citrātsvarūpātpuruṣaḥ svayam
]

`v 27 [
anādimadhyāntamanantamekamatyacchamevātivikāri nānā |
yathāsthitaṃ bhāsvaramapyaśāntamidaṃ samastaṃ pariśāntameva
]