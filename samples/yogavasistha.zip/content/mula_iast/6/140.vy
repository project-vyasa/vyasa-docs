`v 1 [
catvāriṃśadadhikaśatatamaḥ sargaḥ 140
vyādha uvāca |
bhagavaṃstvādṛśastāṃ tāmavasthāṃ ca kathaṃ gataḥ |
kathaṃ dhyānaprayogeṇa tadā nopaśamaṃ gataḥ
]

`v 2 [
muniruvāca |
kalpānteṣu vinaśyanti nāśairnānāvidhātmabhiḥ |
jaganti bhrāntirūpāṇi nabhasyābhāsarūpibhiḥ
]

`v 3 [
kadācitkramaśo nāśaḥ kalpānte saṃpravartate |
aśaṅkitaṃ kadāciddrāgekadhādivikārataḥ
]

`v 4 [
tadā drāgityeva yadā vikṛtaṃ vāri tattathā |
tena yāvatsarantyādyaṃ tāvannītā jalaiḥ surāḥ
]

`v 5 [
anyacca vipinādhīśa kālaḥ sarvaṃkaṣo hyam |
yatra kāle tatastasmiṃstvavaśyaṃbhāvi tattathā
]

`v 6 [
balaṃ buddhiśca tejaśca kṣayakāla upasthite |
viparyasyati sarvatra sarvathā mahatāmapi
]

`v 7 [
anyacca vipinādhīśa mayaitattava varṇitam |
svapnadṛṣṭaṃ kila svapne kiṃ na saṃbhavatīha kam
]

`v 8 [
vyādha uvāca |
asadetadyadi vibho svapnasaṃbhramamātrakam |
kathitena tadaitena ko'rthaḥ kalyāṇakovida
]

`v 9 [
muniruvāca |
tvadbodhanātmakaṃ kāryaṃ mahadastyatra buddhiman |
etadbhramātmakaṃ vetti bhavānsatyaṃ tu me śṛṇu
]

`v 10 [
anantaramahaṃ tasminmattaikārṇavaraṃhasi |
jantorojaḥ sthitaḥ svapne bhrāntaṃ bhrānto vyalokayaṃ
]

`v 11 [
yāvatsasakalaṃ vāri kvāpi nirgantumudyatam |
vikṣubdhavajravitrastasapakṣādrīndravṛndavat
]

`v 12 [
labdhavānuhyamāno'haṃ kaṃciddaivavaśāttaṭam |
avasaṃ tamavaṣṭabhya śikharaprāntasaṃnibham
]

`v 13 [
atha kṣaṇena salilaṃ tadaśeṣeṇa niryayau |
vīcyagrasphuṭitākārairdevaistārakitāmbaram
]

`v 14 [
tārāgaṇaiśca pātālagatairmaṇimayodaram |
āvarteṣu parāvṛttaiḥ sphāramadrijarattṛṇaiḥ
]

`v 15 [
hemadvīpopamairvyāptaṃ gīrvāṇapuramandiraiḥ |
bhramatsurāṅganālīnanalinījālamālitam
]

`v 16 [
madhyohyamānakalpābhranīlaśaivālajālakam |
vidyudgorocanāmbhodanīlanīrajanirbharam
]

`v 17 [
sphuratsīkaranīhārameghādrikṛtadiktaṭam |
ulloladvīcisaṃdigdhavahatkalpadrumavrajam
]

`v 18 [
athaikārṇavakhāto'sāvabhavacchuṣkakoṭaraḥ |
kvacidgalitasahyādri kvacitsaṃśīkamandaraḥ
]

`v 19 [
kvacitkaṅkanimagnenduyamavāsavatakṣakaḥ |
kvacitpaṅkanimagnādhaḥśākhakalpadrumotkaraḥ
]

`v 20 [
kvacitkamalavatkīrṇalokapālaśiraḥkaraḥ |
kvacitpaṅkajaviśrāntarudhirahradapāṭalaḥ
]

`v 21 [
kvacidākaṇṭhanirmagnakvaṇadvidyādharīgaṇaḥ |
kvacitsvapnamṛtebhābhayāmyogramahiṣāvṛtaḥ
]

`v 22 [
kvacitsannamahākāyagaruḍāmaraparvataḥ |
kvacinmattamahāseturyamadaṇḍena bhūjuṣā
]

`v 23 [
kvacitpramṛtavairiñcahaṃsasasmitapaṅkabhūḥ |
kvacitpaṅkavinirmagnadehārdhāmaravāraṇaḥ
]

`v 24 [
etasminnantare tatra sānuṃ prāpyāśrame śramāt |
viśrāntosmi yadā tena bhṛśaṃ nidrājagāma mām
]

`v 25 [
tataḥ suṣuptanidrāntastayā vāsanayānvitaḥ |
taṃ tādṛgeva kalpāntamapaśyaṃ svaujasi sthitaḥ
]

`v 26 [
dṛṣṭvā taddviguṇaṃ duḥkhaṃ cireṇātrāhamākulaḥ |
prabuddho dṛṣṭavānsānuṃ tamevāsya hṛdi sthitam
]

`v 27 [
atha tatra dvitīye'hni bhāskarodayasundaram |
salokākāśabhūśailaṃ bhuvanaṃ dṛṣṭavānaham
]

`v 28 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
iti me cetaso jātaṃ patrādi viṭapādiva
]

`v 29 [
tatastasmiṃstathā dṛṣṭe bhūtale taiḥ padārthakaiḥ |
vyavahāraṃ pravṛtto'haṃ kiṃcidvismṛtadhīritaḥ
]

`v 30 [
jātasya me'dya varṣāṇi ṣoḍaśaiṣa pitā mama |
iyaṃ mātāspadaṃ cedamiti me pratimodabhūt
]

`v 31 [
apaśyaṃ grāmakaṃ kaṃcitkaṃcicca brāhmaṇāśramam |
kiṃcidgehaṃ tathā kaścidbandhuḥ kasmiṃścidāśrame
]

`v 32 [
atha me tiṣṭhataḥ sārdhaṃ bandhubhirgrāmamandire |
ahorātreṣu gacchatsu jāgradādīṃstadeva sat
]

`v 33 [
tataḥ kālavaśāttatra prāktanī bodhadhīrmama |
vismṛtā tādṛśābhyāsādaho tasyeva matsyatā
]

`v 34 [
ityahaṃ grāmavāstavyaḥ saṃpanno brāhmaṇastadā |
dehamātrakabaddhāstho dūrīkṛtavivekabhūḥ
]

`v 35 [
śarīramātrātmavapurdāramātrānurañjitaḥ |
vāsanāmātrasārātmā dhanamātraikatatparaḥ
]

`v 36 [
jīrṇagomātrakadhanaḥ saṃropitalatāvṛtiḥ |
saṃcitāgnyavaniprāṇirupārjitakamaṇḍaluḥ
]

`v 37 [
calavṛkṣakabaddhāstho lokācārarataḥ sadā |
gṛhapārśvagatānīlaśādvalasthalikāsthitiḥ
]

`v 38 [
śākaśākāyatārāmaracanānītavāsaraḥ |
sariddhradanadītīrthasarasi snānatatparaḥ
]

`v 39 [
gomayānnajalāmbvagnikāṣṭheṣṭā kaṣṭasaṃcayī |
idaṃ kāryamidaṃ neti pāśābhyāṃ vivaśīkṛtaḥ
]

`v 40 [
iti me jīvatastatra saṃvatsaraśataṃ gatam |
ekadābhyāgato dūrāttāpaso'tithirātmavān
]

`v 41 [
pūjito'sau viśaśrāma madgṛhe snānapūrvakam |
bhuktavāñchayane sthitvā rātrau varṇitavānkathām
]

`v 42 [
nānādigdeśaśailorvīvyavahāramanohare |
kathāprasaṅge kasmiṃścinnānāvidharasāśraye
]

`v 43 [
sarvaṃ cinmātramevedamanantamavikāri ca |
jagattayeva kacati yathāsthitamapi sthitam
]

`v 44 [
ityahaṃ bodhitastena bodhaikaghanatāṃ gataḥ |
smṛtavāṃstamaśeṣeṇa vṛttāntaṃ dhāraṇāvaśāt
]

`v 45 [
smṛtavānātmavṛttāntaṃ yasyāhamudare sthitaḥ |
taṃ virāḍrūpamāśaṅkya tasmānnirgantumudyataḥ
]

`v 46 [
tadāsyaṃ nirgamadvāramatha jānāmi no yadā |
vistīrṇe bhuvane yasminbhūmyabdhyadrisaridvṛte
]

`v 47 [
tadā tamatyajanneva deśaṃ bandhujanāvṛtam |
tasya prāṇaṃ praviṣṭo'haṃ nirgantuṃ pavanaṃ bahiḥ
]

`v 48 [
ihasthasya virājo'sya bāhyamābhyantaraṃ tathā |
anyajaṃ sarvamīkṣe'hamiti nirṇīya tādṛśam
]

`v 49 [
dhāraṇāṃ saṃvidā baddhvā pradeśaṃ svaṃ tamatyajam |
tatprāṇaiḥ saha niryāta āmodaḥ kusumādiva
]

`v 50 [
pavanaskandhamāsādya prāpya tanmukhakoṭaram |
bahirvātarathenāhaṃ nirgato dṛṣṭavānpuraḥ
]

`v 51 [
yāvattathaiva maddeho baddhapadmāsanaḥ sthitaḥ |
kvāpi munyāśramaḥ śiṣyaiḥ pālito girikandare
]

`v 52 [
puro me tiṣṭhatāṃ teṣāṃ matsaṃrakṣaṇakarmaṇām |
muhūrtamātraṃ ca gataḥ kālaścānte nivāsinām
]

`v 53 [
hṛdayaṃ saṃpraviṣṭo'sau yasyāhaṃ sa pumānapi |
pṛṣṭhenotsavalabdhena śete tṛpto'ndhasā sukham
]

`v 54 [
tadāścaryaṃ mayā dṛṣṭvā noktaṃ kiṃ ca na kasyacit |
punastasyaiva hṛdayaṃ praviṣṭaḥ kautukādaham
]

`v 55 [
prāpto'smyojaḥpradeśaṃ taṃ tasya tasminhṛdantare |
avekṣituṃ svabandhūṃstānvyāpto vāsanayā tayā
]

`v 56 [
yāvattatra yugasyāntaḥ saṃpravṛtto'tidāruṇaḥ |
bhuvanaṃ tadviparyāsamāgataṃ saha saṃsthayā
]

`v 57 [
anya evācalāstatra vasudhānyā ca saṃsthitā |
anya eva kakubbhedastathānyā bhuvanasthitiḥ
]

`v 58 [
te bandhavaḥ sa ca grāmaḥ sa bhūbhāgaḥ sa diktaṭaḥ |
na jāne kva gataṃ sarvaṃ vyūhya nītamivānilaiḥ
]

`v 59 [
tadā paśyāmi bhuvanaṃ yāvadanyadavasthitam |
apūrvasaṃniveśaṃ tajjagadanyadivoditam
]

`v 60 [
tapanti dvādaśādityāḥ prajvalanti diśo daśa |
śītāśyānāmbuvacchailāḥ pravṛttā galituṃ balāt
]

`v 61 [
adrāvadrau diśidiśi jvalanti vanapaṅktayaḥ |
dagdhāḥ smṛtipadaṃ yātāḥ samastā ratnabhūtayaḥ
]

`v 62 [
sarva evābdhayaḥ śuṣkā mahāvātāḥ puraḥsthitāḥ |
aṅgārarāśitāṃ yātaṃ bhūmaṇḍalamaśeṣataḥ
]

`v 63 [
pātālato bhūtalato'tha digbhyo jvālā vinirgantumanupravṛttāḥ |
saṃdhyābhravaccāśu babhūva viśvaṃ jvālāmayaṃ maṇḍalamekameva
]

`v 64 [
jvālāmaye sadmani hemapadmakośe bhramadbhṛṅga iva praviṣṭaḥ |
tato'hamārācchalabhakrameṇa na cāptavāndāhavikāraduḥkham
]

`v 65 [
jvālāmaye sādhu mahāmbuvāhe bhramāmyahaṃ vidyudivānilātmā |
jvālāparispandavilolavarṣmā sthalābjakhaṇḍabhramaropamaśrīḥ
]