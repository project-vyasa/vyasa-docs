`v 1 [
caturnavatitamaḥ sargaḥ 94
śrīvasiṣṭha uvāca |
atha hemamayākāśavistīrṇāyāṃ mahābhuvi |
sauhārdādeva siddhasya tasyedamahamuktavān
]

`v 2 [
tvayā na kevalaṃ tāvanmayāpi na vicāritam |
āvyāptirahitā nāma na saṃbhavati dehinām
]

`v 3 [
kasmānmayā tavodantaṃ vicāryāsau sthirīkṛtā |
na kuṭī vyomni tena tvamabhaviṣyaḥ sthirasthitiḥ
]

`v 4 [
uttiṣṭha siddhalokeṣu nivasāvo yathāsthitam |
svāspadasthitayaḥ saumyāḥ svātmasiddhau susādhanam
]

`v 5 [
iti nirṇīya tāvuccairutsṛtau tārakopamau |
samamekapuṭoḍḍīnau vyoma yantropalāviva
]

`v 6 [
praṇāmapūrvamanyonyamatha kṛtvā visarjanam |
gataḥ so'bhimataṃ deśamahaṃ cābhimataṃ gataḥ
]

`v 7 [
iti vṛttāntamakhilamuktavānasmi rāghava |
tavāścaryamayīṃ paśya saṃsṛtīnāṃ vicitratām
]

`v 8 [
śrīrāma uvāca |
bhagavaṃstava deho'sau pṛthivyāmaṇutāṃ gataḥ |
bhrāntaḥ kena śarīreṇa siddhalokāṃstato bhavān
]

`v 9 [
śrīvasiṣṭha uvāca |
ā smṛtaṃ śṛṇu vṛttāntaṃ tato mama jagadgṛhe |
bhramataḥ siddhasenāsu lokapālapurīṣu ca
]

`v 10 [
ahamindrapuraṃ prāpto na kaścittatra dṛṣṭavān |
māmimaṃ deharahitamātivāhikadehinam
]

`v 11 [
ahaṃ kila tadā rāma saṃpanno gaganākṛtiḥ |
na cādhāro na cādheyaścidākāśamayātmakaḥ
]

`v 12 [
na grahītā na ca grāhyastvādṛśārthāvabodhinām |
na caiva deśakālānāṃ kvacidāvṛttikārakaḥ
]

`v 13 [
manomananamātrātmā pṛthvyādiparivarjitaḥ |
saṃkalpapuruṣākāraḥ padārthānāmarodhakaḥ
]

`v 14 [
aruddhaśca padārthaughaiḥ svayaṃ svānubhavonmukhaḥ |
vyavahartā tathābhūtairevaṃ puṃbhirmanomayaiḥ
]

`v 15 [
svapnānubhūtayo rāma dṛṣṭānto'trāvikhaṇḍitaḥ |
anubhūtyapalāpaṃ tu yaḥ kuryāttena te'stvalam
]

`v 16 [
yathā svapnacaro gehe vyavahartā na dṛśyate |
tathā tadā na dṛṣṭosmi purastho'pi nabhogataiḥ
]

`v 17 [
ahamanyānprapaśyāmi pārthivākārabhāsurān |
māmātivāhikātmānaṃ na kaścidapi paśyati
]

`v 18 [
śrīrāma uvāca |
na dṛśyate videhatvādbhavānvyomavapuryadi |
tatkathaṃ tena siddhena dṛṣṭo'si kanakāvanau
]

`v 19 [
māṃ na kaścidapi paśyatītyetatte svoktiviruddham | prāk siddhena dṛṣṭo'hamiti
tvayaivoktatvāt | ahamanyānprapaśyāmītyapyasaṃgatam | manaso bahirasvātantryātsvapne
svamanomayānāmeva darśanādityāśayena rāmaḥ pṛcchati - na dṛśyata iti | 18
|
śrīvasiṣṭha uvāca |
asmadādirjano nāma yathā saṃkalpakalpitān |
nāsaṃkalpitamāpnoti satyakāmavapuryataḥ
]

`v 20 [
vyavahāreṣu magnena laukikeṣvamalātmanā |
kṣaṇādvismaryate puṃsā ātivāhikamātmanaḥ
]

`v 21 [
mayā paśyatu māmeṣa iti saṃkalpitaṃ tadā |
tena māṃ dṛṣṭavāneṣa svasaṃkalpārthabhājanam
]

`v 22 [
jano jaraṭhabhedatvānna saṃkalpārthabhājanam |
sa eṣa jīrṇabhedatvātsatyakāmatvabhājanam
]

`v 23 [
dvayostu siddhayoḥ siddhaviruddhepsitayormithaḥ |
adhikaikāvadātātmā jayī puruṣayatnavān
]

`v 24 [
bhramataḥ siddhasenāsu lokapālapurīṣu me |
vismṛtā vyavahāraughaiḥ sātivāhikatātmanaḥ
]

`v 25 [
yadā tadāhamaparairvyavahartuṃ mahāmbare |
pravṛtto na ca māṃ kaścittatra paśyati cañcalam
]

`v 26 [
atyantamapyāraṭataḥ śabdo na śrūyate mama |
kenacitsuralokeṣu svapnapuṃsa ivānagha
]

`v 27 [
avaṣṭabdhuṃ pravṛttasya nānyāvaṣṭabdhaye mama |
saṃpadyate kiṃcidapi manomananadehinaḥ
]

`v 28 [
evaṃ vyomapiśāco'haṃ saṃpanno raghunandana |
mayānubhūtā kāpyeṣā devāgārapiśācatā
]

`v 29 [
śrīrāma uvāca |
piśācāḥ santi lokesminkimākārāḥ kimāspadāḥ |
kiṃjātīyāḥ kimācārāḥ kīdṛśāḥ kīdṛśāśayāḥ |
prāsaṅgiko rāmapraśnaḥ
]

`v 30 [
śrīvasiṣṭha uvāca |
piśācāḥ santi loke'sminyādṛśāstādṛśānśṛṇu |
na sabhyo'sau na yo vakti prasaṅgāpatitaṃ vacaḥ
]

`v 31 [
piśācāḥ kecidākāśasadṛśāḥ sūkṣmadehakāḥ |
hastapādādisaṃyuktāḥ paśyanti tvamivākṛtim
]

`v 32 [
chāyayā bhayadāyinyā tvanyatra bhramarūpayā |
te cittākramaṇaṃ kṛtvā bodhayanti narāśayam
]

`v 33 [
ghnantyadanti pibantyāśu laghusattvabalaṃ janam |
balaṃ sattvamatho jīvānhisantyākramya cittakam
]

`v 34 [
ākāśasadṛśāḥ kecitkecinnīhārasaṃnibhāḥ |
kecitsvapnanarākārāḥ sākārā api svātmakāḥ
]

`v 35 [
kecidabhradalaprakhyāḥ kecitpavanadehakāḥ |
kecidbhramātmakā eva sarve buddhimanomayāḥ
]

`v 36 [
grahītuṃ naiva yujyante grahītuṃ śaknuvanti no |
ākāśaśūnyavapuṣaḥ paśyantyākṛtimātmanaḥ
]

`v 37 [
śītātapādivihitaṃ sukhaṃ duḥkhaṃ vidanti ca |
pātumattumavaṣṭabdhumīhituṃ śaknuvanti no
]

`v 38 [
icchādveṣabhayakrodhalobhamohasamanvitāḥ |
mantrauṣadhatapodānadhairyadharmavaśīkṛtāḥ
]

`v 39 [
sattvāvaṣṭambhayantreṇa mantreṇārādhitena vā |
dṛśyante'pi ca gṛhyante kadācitkenacitkvacit
]

`v 40 [
devayonirhi sā tena keciddevopamādayaḥ |
kecinnarasamaśrīkāḥ kecinnāgasamanvayāḥ
]

`v 41 [
śvaśṛgālopamāḥ kecidgrāmajaṅgalavāsinaḥ |
kulyāvakararathyāsu vasanti nirayeṣu ca
]

`v 42 [
nirayeṣu nrakaprāyeṣvaśucideśeṣu | 41 |
etadāspadameteṣāmityākārāḥ prakīrtitāḥ |
piśācā evamācārā janmaiṣāṃ śrūyatāmidam
]

`v 43 [
acetyacinmayaṃn brahma sarvaśaktisvabhāvataḥ |
yatsthitaṃ buddhamevāntaścetyaṃ saṃkalpayanniva
]

`v 44 [
taṃ jīvaṃ viddhi sa prauḍhastvahaṃkāra iti smṛtaḥ |
so'haṃkāraḥ smṛtaḥ puṣṭo mana ityuditātmabhiḥ
]

`v 45 [
sa eva kathyate brahmā saṃkalpākāśarūpavān |
asadevāsato bījaṃ jagato vigatākṛtiḥ
]

`v 46 [
sa manorūpo jīva eva samaṣṭyātmanā brahmā kathyate | asato jagataḥ asanmana eva bījam |
45 |
evaṃ manaḥsthito brahmā sadeho'pyamalaṃ nabhaḥ |
tatsvapnapuruṣākāraḥ sannevāsadvapuḥ sadā
]

`v 47 [
pṛthvyādimūrtirahitastvātivāhikadehavān |
pṛthvyādayaḥ kila kutaḥ saṃkalpapuruṣasya khe
]

`v 48 [
bhavanmano yathākāśapuraṃ paśyati kalpitam |
tathā manovirañcitvaṃ paśyatyātmani kalpitam
]

`v 49 [
yadvetti kalpitaṃ tatsatpaśyatyanubhavatyapi |
yo yāvanmātrakastatsa kasmātkila na paśyati
]

`v 50 [
sa yatpaśyati tattādṛk śūnyātmā śūnyamambare |
brahma brahmaṇi vā brahmā tadidaṃ jagaducyate
]

`v 51 [
tathā saṃprati bhāso'sya cirakālaikabhāvanāt |
ghanībhūtaḥ sthitaḥ puṣṭaḥ sudīrghasvapnasundaraḥ
]

`v 52 [
ātivāhikadehasya tasya taccirabhāvanāt |
sargānubhavanaṃ bhūri brahmaṇo brahmarūpyapi
]

`v 53 [
gataṃ prakaṭatotkarṣādādhibhautikadehatām |
tenaiva sarga ityukto bhedasaṃtatibhāsuraḥ
]

`v 54 [
sa brahmā brahmamātrātmā brahmamātrātmanostayoḥ |
ajātayoreva sadā tadātmajagatordvayoḥ
]

`v 55 [
abhinnayoreva bhṛśaṃ śūnyatvāmbarayoriva |
aikātmyenaiva vasatoḥ pavanaspandayoriva
]

`v 56 [
vetti bhūtamayatvaṃ tanmithyaiva na tu vāstavam |
tathā yathā tvaṃ saṃkalpapuruṣasya sato'sataḥ
]

`v 57 [
tataḥ śarīradhātūnāṃ tena pṛthvyādikāḥ kṛtāḥ |
abhidhāḥ pañca citpuṣṭā jagadityeva tāḥ sthitāḥ
]

`v 58 [
brahmāṇḍātmakasvaśarīradhātūnāṃ kaṭhinadravādibhāgānāṃ tena brahmaṇā
pṛthvyādikā abhidhāḥ saṃjñāḥ kṛtāḥ | tāḥ samuditarūpeṇa jagadityeva sthitāḥ |
57 |
yathā tvasatya evāyaṃ saṃkalpaḥ satya eva te |
tathāsāvātmasaṃkalpaṃ satyamevānubhūtavān
]

`v 59 [
yathā asatyo'pi te saṃkalpo manorājyakautukādyarthakriyākāritvāt satya evānubhūyate
tvayā tathā asau brahmāpi ātmanaḥ saṃkalpaṃ satyamityevānubhūtavān | tasya
samaṣṭyātmatvāttu tatsaṃkalpajasya sarvajanasādhāraṇārthakriyeti viśeṣa iti bhāvaḥ | 58
|
sa svayaṃ cinmayākāśaḥ sa saṃkalpaścidambaram |
ataḥ svapno jagatsarvaṃ kṛtau nāśodbhavau sthitau
]

`v 60 [
yathaivaitanmanaḥ satyaṃ tadaṃśāḥ satyameva te |
tathaiva tatkṛtāścandrarudrārkendumarīcayaḥ
]

`v 61 [
evaṃ sthite jagajjālaṃ tanmanorājyamucyate |
tacca śūnyaṃn nirālambamākāśakacanaṃ citi
]

`v 62 [
yathā svapnapuraṃ vyoma saṃkalpādriryathā nabhaḥ |
tathā brahma jagaccaiva khamevācchamanākṛti
]

`v 63 [
evamābhāsamātrasya kacato'niśamavyayam |
sargādimadhyāntadṛśo mudhaivātroditāḥ sthitāḥ
]

`v 64 [
kiṃcidākāśakośasya tava vā mama vānagha |
jagato vāpi jāyeta kiṃ vā naśyati me vada
]

`v 65 [
tatkimarthamanarthāya nirarthakamapārthakāḥ |
kasmādabhyuditā brūhi rāgadveṣabhayādayaḥ
]

`v 66 [
vastuto'ṅga na sargādirna sargo nāpyasargatā |
vidyate sakṛdābhātamidamitthaṃ sadaiva tat
]

`v 67 [
āśūnye vipulābhoge svacchacijjalapūrite |
kalanāpaṅkakalile bhaviṣyati cidambare
]

`v 68 [
antarikṣākṣayakṣetre khātmano gaganātmikā |
tasmādbījādityaṃ jātā bhūribhūtaśilāvaliḥ
]

`v 69 [
nāsti kiṃcidiha kṣetraṃ vyuptaṃ nāma na kiṃcana |
na bījamasti no jātaṃ kiṃcitsarvaṃ ca saṃsthitam
]

`v 70 [
yāḥ śilāvalayastatra puṣṭāstā vibudhādayaḥ |
yāstu varṇojjvalā etāḥ svāsthitā buddhabuddhayaḥ
]

`v 71 [
yāstvardhapakvāstā etā naranāgādijātayaḥ |
yāstvāśyānā rajonaṣṭāstāḥ kṛmisthāvarādayaḥ
]

`v 72 [
yāstu gurvyaḥ phalairhīnāḥ śūnyākārāḥ kṣayakṣatāḥ |
aśarīrāḥ śarīriṇyastāḥ piśācādikāḥ smṛtāḥ
]

`v 73 [
na hi saṃkalpituḥ svecchā kvacitparyanuyujyate |
tāstathecchā viriñcasya tathā nāma tathoditāḥ
]

`v 74 [
sarvā eva cidākā"asrūpiṇyo bhūtajātayaḥ |
ātivāhikadehinyaḥ pṛthvyādirahitātmikāḥ
]

`v 75 [
tāścirābhyāsavaśatastvādhibhautikasaṃvidam |
prāptā dīrghānubhavanātsvapnajāgraddaśāmiva
]

`v 76 [
piśācādyāstathā ete tathābhūtādhibhautikāḥ |
tiṣṭhanti tuṣṭamanasaḥ svasaṃsāravihāriṇaḥ
]

`v 77 [
paśyanti kāścidanyonyaṃ grāmyā grāmyeyakāniva |
svapnaikalokavāstavyā ivaitā bhūtajātayaḥ
]

`v 78 [
kāścidbahunaraprāptasvapnanirmāṇalokavat |
nānyonyamapi paśyanti nānāsaṃsthānasaṃsthitāḥ
]

`v 79 [
sthitā yathaitā jagati paśācādyāḥ kujātayaḥ |
prāyastathaitāḥ kumbhāṇḍayakṣapretādayaḥ sthitāḥ
]

`v 80 [
yathā yetreha vai nimnā jalaṃ tatrāvatiṣṭhate |
tathā yatra piśācādyāstamastatrāvatiṣṭhate
]

`v 81 [
madhyāhnepi piśācaścedajire tiṣṭhati svayam |
tattasyāndhaṃ tamastatra saṃnidhānaṃ karotyalam
]

`v 82 [
na nihanti ca tadbhānurna cānyastatprapaśyati |
sa eva cānubhavati paśya māyāvijṛmbhitam
]

`v 83 [
agnerādityacandrādestaijasaṃ maṇḍalaṃ yathā |
piśācāderajanyātma tāmasaṃ maṇḍalaṃ tathā
]

`v 84 [
yāti tejasyanojastvaṃ tamasyojaḥpradhānatām |
ulūkavatpiśācādyā āścaryaṃ tatsvabhāvataḥ
]

`v 85 [
eṣā piśācājanitasya jātiḥ proktā mayā te samayānapetā |
piśācatulyaḥ suralokapālalokeṣu jāto'hamiti prasaṅgāt
]