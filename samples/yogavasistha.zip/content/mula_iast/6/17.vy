`v 1 [
saptadaśaḥ sargaḥ 17
śrīvasiṣṭha uvāca |
anahaṃvedanādevaṃ śubhāśubhaphalapradā |
saṃsāraphalinī nūnamicchāntarupaśāmyati
]

`v 2 [
anahaṃvedanābhyāsātsamaloṣṭāśmakāñcanaḥ |
bhūtvā śāntabhavāpīḍo na naraḥ paritāmyati
]

`v 3 [
kāmoparame lobhādidoṣakṣayādvairāgyādisaṃpadā sarvamānasaduḥkhakṣaya ityāha ##-
ahaṃtāpuṭakoḍḍīnaparabodhabaleritaḥ |
ahamityarthapāṣāṇo na jāne kvāśu gacchati
]

`v 4 [
ahaṃtāpuṭakoḍḍīno brahmavīrabaleritaḥ |
ahamityarthapāṣāṇo na jāne kvāśu gacchati
]

`v 5 [
ahaṃtāpuṭakoḍḍīno brahmavīrabaleritaḥ |
śarīrayantrapāṣāṇo na jāne kvāśu gacchati
]

`v 6 [
ahamarthahimaṃ tvantaranahaṃtā cidarciṣā |
uḍḍīyeva vilīnaṃ sanna jāne kvāśu gacchati
]

`v 7 [
anahaṃtābhāvanāvṛttipratiphalitacitaivāhaṃtānāśa iti pakṣo vā'stvityāśayenāha ##-
ahaṃraso vilīnontaranahaṃtācidarciṣā |
śarīraparṇādudvarṇānna jāne kvāśu gacchati
]

`v 8 [
śarīraparṇānniṣpītastvahaṃbhāvarasāsavaḥ |
anahaṃtārkamārgeṇa paratāmadhigacchati
]

`v 9 [
śayane kardame śaile gṛhe vyomni sthale jale |
sthūlā sūkṣmā nirākārā rūpāntaragatāpi ca
]

`v 10 [
yatra tatra sthitā suptā prabuddhā bhasmatāṃ gatā |
dhṛtā nītā nimagnā ca dūrasthā nikaṭā satī
]

`v 11 [
śarīravaṭadhānāntaḥsthitāhaṃtvanavāṅkurā |
śākhājālaṃ tanotyāśu saṃsārākhyamidaṃ kṣaṇāt
]

`v 12 [
ahaṃtvavaṭadhānāntaḥsthitadehabṛhaddrumaḥ |
saṃsāraśākhānivahaṃ yatra tatra tanotyalam
]

`v 13 [
śākhāśateddhadalapuṣpaphaladrumo'sti bījodare nanu dṛśā paridṛśyate'sau |
deho'styahaṃtvakaṇikāntaraśeṣadṛśyasaṃvitparīta iti buddhidṛśaiva
dṛṣṭam
]

`v 14 [
dehādahaṃtvamanavāptavato vicāraiścidvyomamātravapuṣo vapuṣo'tha voccaiḥ |
nāhaṃtvabījajaṭharādasato'bhyudeti saṃsāravṛkṣa iha bodhamahāgnidagdhāt | 14
|
evamavicāraphalaṃ sarvatrānirmokṣamuktvā vicāraphalaṃ mokṣamāha - dehāditi |
vicāraiḥ śravaṇādibhistattvabodhāccidvyomamātraṃ vapuḥsvarūpaṃ yasya tathāvidhasya
jīvanmuktasya vidyamānādapi dehādahaṃtvaṃ tattādātmyābhimānamanavāptavataḥ
athavā adehavato videhamuktasyoccairniratiśayānande pratiṣṭhitasya puṃso
bodhamahāgnidagdhāhaṃtvabījajaṭharāt saṃsāravṛkṣo nābhyudeti
]