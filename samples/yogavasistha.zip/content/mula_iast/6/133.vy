`v 1 [
trayastriṃśādhikaśatatamaḥ sargaḥ 133
vipaściduvāca |
kasmiṃścidanyatra jagatyapūrve dṛṣṭaṃ mayedaṃ śṛṇu kiṃ vicitram |
mahāghavṛttāntadaśāsamānamavidyayāndhena valātkṛtaṃ yat
]

`v 2 [
asti kvacitkhe bhavatāmagamye jagajjvaladdīptivicitrasargaḥ |
etādṛgapyambaratastadanyat svāpnaṃ puraṃ jāgrati cetasīva
]

`v 3 [
tasminmayā viharatā hṛdayasthamarthamanveṣṭumakṣi nihitaṃ kakubhāṃ
mukheṣu |
paśyāmi yāvadacalapratimā dharāyāṃ chāyālijālamalinā paribaṃbhramīti
]

`v 4 [
āścaryamātramucitaṃ kimidaṃ nimeṣādityakṣi vai jagati yāvadahaṃ tyajāmi |
khāttāvadadrimatulaṃ puruṣākṛtiṃ drāgāvartavṛttibhirapaśyamahaṃ
patantam
]

`v 5 [
tataḥ atimahattvādāścaryamātramidaṃ chāyākāraṃ kimucitamiti vimṛśan yāvdakṣi
jagati ūrdhvabhāge tyajāmi prerayāmi tāvadadrīṇāṃ mānaṃ parimāṇaṃ adrimā sā tulā
yasya tathāvidhaṃ khādāvartavṛttibhiḥ patantaṃ puruṣākṛtimahaṃ drāgapaśyam | 4
|
kaḥ syādayaṃ giriguruḥ puruṣo virāḍvā paryastaparvatavadāśu pataccharīraḥ |
ākāśapūrakavapuḥ paramāmbaro'pi yo naiva bhāti pihitākhilavāsaraśrīḥ
]

`v 6 [
evaṃvidhāṃ hṛdi manākkalayāmi yāvattāvatpapāta sahasā nabhaso vivasvān |
kalpāntavātaparivṛttapitāmahāṇḍapṛṣṭhāvapātaghanaghoṣajuṣā javena
]

`v 7 [
tasminpatati bhīmātmanyapārāvāradehini |
saptadvīpāṃ vasumatīṃ paripūrayati kṣaṇāt
]

`v 8 [
svātmano nāśamāśaṅkya sadvīpabhuvanaiḥ saha |
avaśyabhāvipārśvasthamahamagnimathāviśam
]

`v 9 [
sa jātavedā bhagavānjanmāntaraśatārcitaḥ |
mā bhaiṣīriti dehena māmuvācenduśītalaḥ
]

`v 10 [
jaya deva tvamasmākaṃ pratijanma parāyaṇam |
akāla eva kalpānto jāto'taḥ pāhi māṃ prabho
]

`v 11 [
ityuktenāgninā proktaṃ mā bhaiṣīriti tatpunaḥ |
uttiṣṭhāgaccha gacchāvo mallokamiti cānagha
]

`v 12 [
ityuktvā śukapṛṣṭhe'sāvāropya bhagavāṃstataḥ |
dehaikadeśe tatpāti bhūtaṃ dagdhvā nabhaḥ plutaḥ
]

`v 13 [
anantaraṃ nabhaḥ prāpya dṛṣṭaḥ kaṣṭākṛtirmayā |
sa tādṛgbhūtasaṃpātamahotpāto bhayapradaḥ
]

`v 14 [
tasminjavena patite vasudhā cacāla sāmbhodhiśailavanapattanajaṅgalaughā |
cakre bhṛgudvayamayānajalasravantī bhīmākṛtīnvyadhuradehavibhedagartān |
14 |
tasminmahāśave javena patite sati ambhodhyādisahitā vasudhā cacāla | ayānajalāḥ
niruddhodakapravāhāḥ sravantyo nadyo yasyāṃ tathāvidhā satī girinadīnāṃ kūladvaye
mārgāntareṇa jalasravaṇāt bhṛgudvayaṃ jalaprapātadvayaṃ cakre | patanti jalāni
bhīmākṛtīn bhayaṃkarākārān adehavibhedān
manuṣyādidehakṛtabhūvidāraṇajanyavāpīkūpādivilakṣaṇāngartānvyadhuścakruḥ |
vidhuradehavibhedakartān iti pāṭha vasudhāvidhureṇa visaṃṣṭhulena svadehavibhedena
kartān vaprādikartanāni cakre ityarthaḥ
]

`v 15 [
urvī rarāsa kakubuttarato rarāsa virarāsa ca dakṣiṇā dik |
dyaurārarāsa virarāsa saśailabhūtaṃ sarvaṃ jagatpralayasaṃbhramabhītamuccaiaḥ
]

`v 16 [
urvī rarāsa dharaṇe savirāvaraṃhaḥsaṃrambhatarjitasamastadigantarāsā `note[rāso
dhvaniḥ |] |
vyomāpi ghuṃghumamalaṅghyamalaṃ cakāra
nāgārivṛndabhayavidravaṇapracaṇḍam
]

`v 17 [
nirghātaśabda udabhūdabhito bhayāya bhīmāya bhūdharadarīdṛḍhadāraṇotthaḥ
|
utpātabhīmajavajālayugāntavātasaṃrabdhakalpaghanaghoṣavitīrṇatarjaḥ
]

`v 18 [
tasmiñjavena patite vasudhā rarāsa sārāvadiṅmukhatayā śatavedhamāgāt |
tatrāsphuṭankulagirīndramahātaṭāni pātāladeśamaviśanhimavacchirāṃsi
]

`v 19 [
āsīttatpatanaṃ tasya meruśailaśilākṛteḥ |
dalanaṃ śailaśṛṅgāṇāṃ vidāraṇakaraṃ bhuvaḥ
]

`v 20 [
kṣobhaṇaṃ jalarāśīnāmadrīṇāṃ bhūtalārpaṇam |
pīḍanaṃ sarvabhūtānāṃ krīḍanaṃ pralayārthinām
]

`v 21 [
pātanaṃ bhūtale bhānoḥ sthaganaṃ dvīpapaddhateḥ |
cūrṇīkaraṇamadrīṇāṃ dalanaṃn maṇḍalāvaneḥ
]

`v 22 [
dvitīyamiva bhūpīṭhaṃ brahmāṇḍārdhamivāparam |
patitaṃ khamivākṛtyā tadapaśyannabhaścarāḥ
]

`v 23 [
atha paśyāmyahaṃ yāvadasau māṃsamayo'calaḥ |
na māti saptadvīpāyāṃ bhuvi tasyāṅgamekakam
]

`v 24 [
tamālokya mayā devaḥ prasāde samavasthitaḥ |
saṃpṛṣṭo bhagavānvahniḥ prabho kimidamityatha
]

`v 25 [
kathaṃ māṃsamayaḥ sārdhaṃ sa cārkaḥ patito divaḥ |
sa na māti hi bhūpīṭhe saparvatavanāmbudhau
]

`v 26 [
agniruvāca |
pratipālaya putra tvaṃ kṣaṇamekaṃ gatatvaraḥ |
yāvacchāmyatu `note[śāmyati ityubhayatrāpi pāṭaḥ |] doṣo'yaṃ kathayiṣyāmi
te tataḥ
]

`v 27 [
atha tasminvadatyevaṃ samājagmurnabhaścarāḥ |
tajjagajjālajātīyā digbhyo gaganajākhilāḥ
]

`v 28 [
siddhasādhyāpsarodaityagandharvoragakinnarāḥ |
ṛṣayo munayo yakṣāḥ pitaro mātaro'marāḥ
]

`v 29 [
atha sarveśvarīṃ devīṃ śaraṇyāṃ te nabhaścarāḥ |
bhaktinamraśiraḥkāyāḥ kālarātriṃ pratuṣṭuvuḥ
]

`v 30 [
nabhaścarā ūcuḥ |
baddhvā khaṭvāṅgaśṛṅge kapilamurujaṭāmaṇḍalaṃ padmayoneḥ kṛtvā
daityottamāṅgaiḥ srajamurasi śiraḥśekharaṃ tārkṣyapakṣaiḥ |
yā devī bhuktaviśvā pibati jagadidaṃ sādribhūpīṭhabhūtaṃ sā devī niṣkalaṅkā
kalitatanulatā pātu naḥ pālanīyān
]