`v 1 [
dvyaśītyadhikaśatatamaḥ sargaḥ 182
vṛddhatāpasa uvāca |
tasminneva kadambe'sminvarṣāṇi svecchayā daśa |
sthitvā gaurī jagāmātha haravāmārdhamandiram
]

`v 2 [
tatsparśāmṛtasikto'yaṃ kadambataruputrakaḥ |
utsaṅga iva cāsīno na yātyeva purāṇatām
]

`v 3 [
tato gauryāṃ prayatāyāṃ tadvanaṃ tādṛśaṃ mahat |
sāmānyavanatāṃ yātaṃ janavṛndopajīvitam
]

`v 4 [
mālavo nāma deśo'sti tatrāhaṃ pṛthivīpatiḥ |
kadācittyaktarājyaśrīrmunīnāmāśramānbhraman
]

`v 5 [
imaṃ deśamanuprāpta iha cāśnamavāsibhiḥ |
pūjito'sya kadambasya dhyānaniṣṭhastale sthitaḥ
]

`v 6 [
kenacittvatha kālena bhrātṛbhiḥ saptabhiḥ saha |
bhavānabhyāgataḥ pūrvaṃ taporthamimamāśramam
]

`v 7 [
tapasvino'ṣṭāviha te tathā nāma tadā'vasan |
yathā tapasvino'nye te teṣāṃ mānyāstapasvinaḥ
]

`v 8 [
kālenānantaramasāvekaḥ śrīparvataṃ gataḥ |
svāminaṃ kārtikeyaṃ ca dvitīyastapase gataḥ
]

`v 9 [
vārāṇasīṃ tṛtīyastu caturtho'gāddhimācalam |
ihaiva te pare dhīrāścatvāro'nye paraṃ `note[paramatyantamatapan
tapaścakrurityarthaḥ | aḍabhāva ārṣaḥ |] tapan
]

`v 10 [
sarveṣāmeva caiteṣāṃ pratyekaṃ tvetadīpsitam |
yathā samastadvīpāyā bhuvo'syāḥ syāṃ mahīpatiḥ
]

`v 11 [
atha saṃpāditaṃ teṣāṃ sarveṣāmetadīpsitam |
tapastuṣṭābhiriṣṭābhirdevatābhirvarairvaraiḥ
]

`v 12 [
tapataste tato yātā bhrātaraḥ sadanaṃ nijam |
bhūmau dharmayugaṃ bhuktvā vedhā brahmapurīmiva
]

`v 13 [
tairbhavadbhrātṛbhirbhavya varadānavidhau tadā |
idaṃ varodyatā yatnātprārthitāḥ sveṣṭadevatāḥ
]

`v 14 [
devyasmākamime sarve saptadvīpeśvrasthitau |
satyāḥ prakṛtayaḥ santu sarva āśramavāsinaḥ
]

`v 15 [
tamiṣṭadevatāsārthamurarīkṛtya sādaram |
teṣāmastvevamityuktvā jagāmāntarddhimīśvarī
]

`v 16 [
te tataḥ sadanaṃ yātāsteṣāmāśramavāsinaḥ |
sarva eva gatāḥ paścādeka evāsmi no gataḥ
]

`v 17 [
ahaṃ kevalamekānte dhyānaikagatamānasaḥ |
vāgīśvarīkadambasya tale tiṣṭhāmi śailavat
]

`v 18 [
atha kāle vahatyasminnṛtusaṃvatsarātmani |
idaṃ sarvaṃ vanaṃ chinnaṃ janaiḥ paryantavāsibhiḥ
]

`v 19 [
idaṃ `note[ayaṃ cāsau kadambaśceti vigrahaḥ |] kadambamamlānaṃ janatāḥ
pūjayantyalam |
vāgīśvarīgṛhamiti māṃ caivaikasamādhigam
]

`v 20 [
athainaṃ deśamāyātau bhavantau dīrghatāpasau |
etattatkathitaṃ sarvaṃ dhyānadṛṣṭaṃ mayākhilam
]

`v 21 [
tasmādutthāya he sādhū gacchataṃ gṛhamāgatau |
tatra te bhrātaraḥ sarve saṃgatā dārabandhubhiḥ
]

`v 22 [
aṣṭānāṃ bhavatāṃ bhavyaṃ sadane sve bhaviṣyati |
mahātmanāṃ brahmaloke vasūnāmiva saṃgamaḥ
]

`v 23 [
bhavatāmaṣṭānāmapi saṃgamo bhaviṣyati | vasūnāmaṣṭānām | brahmaloke devaloke | 22
|
ityukte tena sa mayā pṛṣṭaḥ paramatāpasaḥ |
saṃdehādidamāścaryamāryāstadvarṇayāmyaham
]

`v 24 [
ekaiva saptadvīpāsti bhagavanbhūriyaṃ kila |
tulyakālaṃ bhavantyaṣṭau saptadvīpeśvarāḥ katham
]

`v 25 [
kadambatāpasa uvāca |
asamañjasametāvadeva no yāvaducyate |
idamanyadasaṃbaddhataraṃ saṃśrūyatāṃ mama
]

`v 26 [
ete'ṣṭau bhrātarastatra tāpasā dehasaṃkṣaye |
saptadvīpeśvarāḥ sarve bhaviṣyanti gṛhodare
]

`v 27 [
aṣṭau hyete mahīpīṭheṣveteṣveteṣu sadmasu |
saptadvīpeśvarā bhūpā bhaviṣyantīha me śṛṇu
]

`v 28 [
astyeteṣāṃ kilāṣṭānāṃ bhāryāṣṭakamaninditam |
digantarāṇāṃ niyataṃ tārāṣṭakamivojjvalam
]

`v 29 [
tadbhāryāṣṭakameteṣu yāteṣu tapase ciram |
babhūva duḥkhitaṃ strīṇāṃ yadviyogo'hiduḥsahaḥ
]

`v 30 [
duḥkhitāḥ pratyaye teṣāṃ cakrustā dāruṇaṃ tapaḥ |
śatacāndrāyaṇaṃ tāsāṃ tuṣṭābhūttena pārvatī
]

`v 31 [
adṛśyovāca sā tāsāṃ vaco'ntaḥpuramandire |
devī saparyāvasare pratyekaṃ pṛthagīśvarī
]

`v 32 [
devyuvāca |
bhartrarthamatha cātmārthaṃ gṛhyatāṃ bālike varaḥ |
ciraṃ kliṣṭāsi tapasā nidāgheneva mañjarī
]

`v 33 [
ityākarṇya vaco devyā dattapuṣpā ciraṃṭikā |
svavāsanānusāreṇa kurvāṇaiveśvarīstavam
]

`v 34 [
ānandamantharovāca vacanaṃ mṛdubhāṣiṇī |
ākāśasaṃsthitāṃ devīṃ mayūrīvābhramālikām
]

`v 35 [
ciraṃṭikovāca |
devi devādhidevena yathā te prema śaṃbhunā |
bhartrā mama tathā prema sa bhartāstu mamāmaraḥ
]

`v 36 [
devyuvāca |
āsṛṣṭerniyaterdārḍhyādamaratvaṃ na labhyate |
tapodānairato'nyaṃ tvaṃ varaṃ varaya suvrate
]

`v 37 [
ciraṃṭikovāca |
alabhyametanme devi tanmadbharturgṛhāntarāt |
mṛtasya mā viniryātu jīvo bāhyamapi kṣaṇāt
]

`v 38 [
dehapātaśca me bharturyadā syādātmamandire |
tadetadastviti varo dīyatāmambike mama
]

`v 39 [
devyuvāca |
evamastu sute tvaṃ ca patyau lokāntarāsthite |
bhaviṣyasi priyā bhāryā dehānte nātra saṃśayaḥ
]

`v 40 [
ityuktvā virarāmāsau gauryā gīrgaganodare |
meghamālādhvaniriva niravadyasamudyatā
]

`v 41 [
devyāṃ gatāyāṃ bhartārastāsāṃ kālena kenacit |
te kakubbhyaḥ samājagmuḥ sarve prāptamahāvarāḥ
]

`v 42 [
adyāyamapi saṃyātu bhāryāyā nikaṭaṃ patiḥ |
bhrātṝṇāṃ bāndhavānāṃ ca bhavatvanyonyasaṃgamaḥ
]

`v 43 [
idamanyadathaiteṣāmasamañjasamākulam |
śṛṇu kiṃvṛttamāścaryamāryakāryoparodhakam
]

`v 44 [
tapyatāṃ tapa eteṣāṃ pitarau tau vadhūyutau |
tīrthamunyāśramaśreṇīṃ draṣṭuṃ duḥkhānvitau gatau
]

`v 45 [
śarīranairapekṣyeṇa putrāṇāṃ hitakāmyayā |
gantaṃ kalāpagrāmaṃ taṃ yatnavantau babhūvatuḥ
]

`v 46 [
tau prayātau munigrāma mārge dadṛśatuḥ sitam |
puruṣaṃ kapilaṃ hrasvaṃ bhasmāṅgaṃ cordhvamūrdhajam
]

`v 47 [
dhūlīlavamanādṛtya taṃ jaratpānthaśaṅkayā |
yadā tau jagmatustena sa uvācānvitaḥ krudhā
]

`v 48 [
savadhūka mahāmūrkha tīrthārthī dārasaṃyutaḥ |
māṃ durvāsasamullaṅghya gacchasyavihitānatiḥ
]

`v 49 [
vadhūnāṃ te sutānāṃ ca gacchatastapasārjitāḥ |
viparītā bhaviṣyanti labdhā api mahāvarāḥ
]

`v 50 [
ityuktavantaṃ taṃ yāvatsadāro'tha vadhūyutaḥ |
sanmānaṃ kurute tāvanmunirantardhimāyayau
]

`v 51 [
atha tau pitarau teṣāṃ savadhūkau suduḥkhitau |
kṛśībhūtau dīnamukhau nirāśau gṛhamāgatau
]

`v 52 [
ato vadāmyahaṃ teṣāṃ naikaṃ nāmāsamañjasam |
asamañjasalakṣāṇi gaṇḍe sphoṭāḥ sphuṭā iva
]

`v 53 [
cidvyomasaṃkalpamahāpure'sminnitthaṃ vicitrāṇyasamañjasāni |
niḥśūnyarūpe'pi hi saṃbhavanti dṛśye yathā vyomani dṛśyajṛmbhāḥ
]