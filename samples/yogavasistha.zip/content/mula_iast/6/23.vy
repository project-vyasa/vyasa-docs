`v 1 [
trayoviṃśaḥ sargaḥ 23
śrīvasiṣṭha uvāca |
virāgavāsanāpāstasamastabhavavāsanaḥ |
utthāya gaccha prakṛterasyā maṅkirivāṅkitaḥ
]

`v 2 [
maṅkirnāmābhavatpūrvaṃ brāhmaṇaḥ saṃśitavrataḥ |
sa kathaṃ śṛṇu nirvāṇamāptavānmadvibodhitaḥ
]

`v 3 [
ahaṃ kadācidākāśakośādavanimāgataḥ |
bhavatpitāmahārthena kenāpyupanimantritaḥ
]

`v 4 [
viharanbhūtalaṃ gacchaṃstvatpitāmahapattanam |
prāpto'smi kāmapyādīrghāmaraṇyānīṃ mahātapām
]

`v 5 [
pāṃsupratardanahatāṃ prakacattaptasaikatām |
adṛṣṭāpāraparyantāṃ kvacidrāma kilāṅkitām
]

`v 6 [
akṣubdhasvānilālokajalabhūśāntiśālinīm |
tatāṃ śūnyāṃ mahārambhāṃ brahmasattāmivāmalām
]

`v 7 [
avidyāmiva saṃmohamṛgatṛṣṇāṃ gatāṃ bhramāt |
jaḍatāmātatāṃ śūnyāṃn diṅmohamihikākulām
]

`v 8 [
atha tasyāmaraṇyānyāṃn yāvatpraviharāmyaham |
tāvatpaśyāmi purato vadantaṃ pathikaṃ śramāt
]

`v 9 [
pāntha uvāca |
aho nu parikhedāya prauḍhaprāyātapo raviḥ |
paritāpāya pāpo'yaṃ durjaneneva saṃgamaḥ
]

`v 10 [
sugalantīva marmāṇi sphuratīvāgnirātape |
saṃkucatpallavāpīḍāstāpyante vanarājayaḥ
]

`v 11 [
tattāvadevamagrasthaṃ grāmakaṃ praviśāmyaham |
śramamatrāpanīyāśu vahāmyadhvānamāśugaḥ
]

`v 12 [
iti saṃcintya so'grasthaṃ kirātagrāmakaṃ yadā |
praveṣṭumicchati tāa mayā proktamidaṃ vacaḥ
]

`v 13 [
aparijñātanīrāgamārga mitra śubhākṛte |
marumārgamahāraṇyapāntha svāgatamastu te
]

`v 14 [
ciraṃ manuṣyadeśe'sminnirjanagrāmamadhvani |
adharādhvaga viśrāntiṃ viśrāntopi na lapsyase
]

`v 15 [
grāme viśramaṇaṃ naiva vartate pāmarāspade |
tṛḍvai lavaṇapānena bhūya evābhivardhate
]

`v 16 [
ete grāmaikaśaraṇāḥ pallavāḥ spandabhīravaḥ |
ayathāpathasaṃcārā hariṇā iva jantavaḥ
]

`v 17 [
na sphuranti vicāreṣu prajvalantyanubhūtiṣu |
na trasyanti durācārādaśmayantramayā iva
]

`v 18 [
kāmārtharāgasadveṣapariniṣṭhitapauruṣā |
karmaṇyāpātamadhure ramante dagdhabuddhayaḥ
]

`v 19 [
ābhijātyātatodārā śītalā rasaśālinī |
neha viśvasiti prajñā meghamālā marāviva
]

`v 20 [
varamandhaguhāhitvaṃ śilāntaḥkīṭatā varam |
varaṃ marau paṅgumṛgo na grāmyajanasaṃgamaḥ
]

`v 21 [
nimeṣāsvādamadhurāḥ kṣaṇāntaravirāgiṇaḥ |
māraṇaikāntaniratā grāmyā viṣakaṇā iva
]

`v 22 [
vānti bhasmakaṇākīrṇā jīrṇāḥ saṃśīrṇasadmasu |
tṛṇaparṇavanavyagrā grāmyādhārmikavāyavaḥ
]

`v 23 [
evamuktena tenāhamidamuktastato'nagha |
madvākyena samāśvāsya snātenevāmṛtāmbhasā
]

`v 24 [
pāntha uvāca |
bhagavanko'si pūrṇātmā mahātma kathamātmavān |
paśyasyanākulo lokaṃ grāmayātrāmivādhvagaḥ
]

`v 25 [
kiṃ tvayā pītamamṛtaṃ kiṃ tvaṃ samrāḍvirāḍatha |
sarvārtharikto'pi ciraṃ saṃpūrṇaṃ iva rājase
]

`v 26 [
śūnyo'si paripūrṇo'si ghūrṇo'sīva sthiro'si ca |
na sarvamapi sarvaṃ ca na kiṃcitkiṃcideva ca
]

`v 27 [
upaśāntaṃn ca kāntaṃ ca dīptamapratighāti ca |
nivṛttaṃ corjitaṃ tādṛgrūpaṃ kimiti te mune
]

`v 28 [
bhūsaṃstho'pi samastānāṃ lokānāmuparīva khe |
saṃsthito'si nirāstho'si ghanāstho'sīva lakṣyase
]

`v 29 [
prasṛtaṃ na padārtheṣu na padārthātmanā'sti vai |
tavendoriva śuddhasya mano'mṛtamayaṃ sthitam
]

`v 30 [
kalāvānakalaṅko'ntaḥśītalo bhāsvaraḥ samaḥ |
rasāyanabharāpūrṇaḥ pūrṇenduriva rājase
]

`v 31 [
tvadicchāyāṃ tu sadasadbhāvaṃ paśyāmi te citi |
saṃsāramaṇḍalamidaṃ sthitaṃ phalamivāṅkure
]

`v 32 [
ahaṃ tāvadayaṃn vipra śāṇḍilyakulasaṃbhavaḥ |
maṅkirnāma mahābhāga tīrthayātrāprasaṅgataḥ
]

`v 33 [
evaṃ praśaṃsayābhimukhīkṛtāya vasiṣṭhāya
svavairāgyādisādhanasaṃpattyopadeśārhatāṃ darśayituṃ svagotranāmādi kīrtayati ##-
gatvā sudūramadhvānaṃ dṛṣṭvā tīrthāni saṃprati |
cirakālena sadanamātmīyaṃ gantumudyataḥ
]

`v 34 [
na ca me gantumudyogo viraktamanaso gṛham |
dṛṣṭvā taḍitsakāśāni bhūtāni bhuvanodare
]

`v 35 [
bhagavansatyamātmānaṃ kathayehānukampayā |
gambhīrāṇi prasannāni sādhucetaḥsarāṃsi hi
]

`v 36 [
darśanādeva mitratvaṃ kurvatāṃ mahatāṃ puraḥ |
kamalānīva bhūtāni vikasantyāśvasanti ca
]

`v 37 [
mamedaṃ ca mano mohātsaṃsārabhramasaṃbhavam |
manye hātuṃ na samarthaṃ sa tvaṃ bodhānukampitaiḥ
]

`v 38 [
śrīvasiṣṭha uvāca |
vasiṣṭho'smi mahābuddhe munirasmi nabhogṛhaḥ |
kenāpyarthena rājarṣerimaṃ mārgamupasthitaḥ
]

`v 39 [
māgā viṣādaṃ panthānamāgato'si manīṣiṇām |
prāyaḥ prāptosi saṃsārasāgarasya paraṃ taṭam
]

`v 40 [
vairāgyavibhavodārā matiruktirapīdṛśī |
ākṛtiḥ śāntarūpā ca na bhavatyamahātmanaḥ
]

`v 41 [
maṇirmadhurakāṣeṇa yathaiti vimalātmatām |
tathā kaṣāyapākena cittameti vivekitām
]

`v 42 [
kiṃ jñātumicchasi kathaṃ saṃsāraṃ hātumicchasi |
upadiṣṭamahaṃ manye saṃpādayati karmabhiḥ
]

`v 43 [
vimalavāsana uttamamānasaḥ pariviviktamatirjanatejasā |
padamaśokamalaṃ khalu yujyate janititīrṣumateridamucyate
]