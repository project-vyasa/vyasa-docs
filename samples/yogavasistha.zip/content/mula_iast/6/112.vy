`v 1 [
dvādaśādhikaśatatamaḥ sargaḥ 112
śrīvasiṣṭha uvāca |
lokahārāmbaravyālaṃ cedicandanakānanam |
chinnaṃ paraśudhārābhiḥ patitaṃ dakṣiṇārṇave
]

`v 2 [
parṇavatprohya `note[mūlasthaprohyeti lyabantasya pravahaṇaṃ prāpyetyarthakaraṇe
phalitamidam |] pūreṇa pārasīkāḥ parasparam |
praharanto vimohena vinaṣṭā vañjulāvane
]

`v 3 [
dardurādrau duranteṣu daradīrṇahṛdantarāḥ |
darīrandhreṣu saṃlīnā daradā dānavā iva
]

`v 4 [
caturāyudhadhārāgracūrṇanīhāradhāriṇaḥ |
vidyudvalayino vātā vellitāyudhavāridāḥ
]

`v 5 [
dantino'nyonyamābhagnadantadehaughapīḍitāḥ |
mṛtyūdarombhakagrāsapiṇḍapiṇḍā ivābhavan
]

`v 6 [
tajjā raivatikā rātrau raudratomaratāḍitāḥ |
rūpikābhiḥ piśācībhirbhuktā bhāgīkṛtāṅgakāḥ
]

`v 7 [
tālītamālagahane daśārṇā jīrṇajaṅgale |
gale pādaṃ nidhāyāntaḥ kṛttāḥ siṃhairgatāsavaḥ
]

`v 8 [
paścimārṇavatīrasthā nālikeradharāvanau |
yavanā vigataprāṇā nigīrṇā makarotkaraiḥ
]

`v 9 [
nārācanikaraṃ nīlaṃ nimeṣaṃ nāsahañchakāḥ |
ramaṭhā nalinīṣaṇḍā iva tāṇḍavitāsavaḥ
]

`v 10 [
śravaṇābhogaśṛṅgāgro mahendro'drirdivi vrajaiḥ |
vidrutairvalito nīlairjālairjalamucāmiva
]

`v 11 [
cāmīkaravarākārā bhagnā taṅgaṇavāhinī |
mṛtā hṛtāmbarā corairbhuktaikānte niśācaraiḥ
]

`v 12 [
dyaurivarkṣabharairāsīttadāsāraṃ bhuvastalam |
vivartamānairabhitaḥ kacadbhirjvalanāyudhaiḥ
]

`v 13 [
dhārādharadharārandhrapratiśruddhanaghuṃghumā |
jagadgehaguhāsīddyorghanaṃ gātumivodyatā
]

`v 14 [
dvipāntarajanāścakrairjarjarā jīvitaṃ jahuḥ |
mīnajaṅgalajambāle jīrṇamatsyā ivājale
]

`v 15 [
mīnavihārajaṃgalabhūte jambāle śaivalapalvale daivādajale sati matsyā iva aśaraṇāḥ |
14 |
yāvaddvīpā jitāḥ kukṣau sahyādrau samamūrtayaḥ |
āśvasya divasānsapta yayurāyāsamantharam
]

`v 16 [
gandhamādanapunnāgavanakuñjeṣu puñjitāḥ |
vidyādharakumārībhirgāndhārāḥ parirakṣitāḥ
]

`v 17 [
hūuṇacīnakirātānāṃ muktaistaiścakravarṣaṇaiḥ |
kamalānīva lūnāni śirāṃsyabhimukhānilaiḥ
]

`v 18 [
nilīpā nalinīnāle kaṇṭakā iva niścalāḥ |
drume drume drumamayā bhayāttvasyāvasaṃściram
]

`v 19 [
cārusāraṅgaraṅgāsu śailakānanabhūmiṣu |
caturdikkaṃ tadāpātaiḥ saṃpannaṃ kṣobhaṇaṃ ghanam
]

`v 20 [
sāraṅgāṇāṃ mṛgāṇāṃ pakṣiṇāṃ ca vihāre raṅgabhūmibhūtāsu
śailakānanabhūmiṣu tasya vipaścita āpātairghanamatiśayitaṃ kṣobhaṇaṃ saṃpannam |
19 |
kaṇṭakasthalanāmānaḥ kaṇṭakasthalakarkaśāḥ |
kaṇṭakasthalagā āsankaṇṭakasthalamaṇḍale
]

`v 21 [
pārasīkāḥ paraṃ pūraiḥ pāraṃ prāpya payonidheḥ |
nipetuḥ pavanaiḥ pūtāḥ pralaye tārakā iva
]

`v 22 [
vavurambhodhikuṭṭākā dṛṣadāṃ kaṭakāṅkitāḥ |
sarvadigvanaluṇṭākā vātāḥ pralayaśaṅkitāḥ
]

`v 23 [
āsārasārāḥ paṅkāmbuplutāḥ saghanaghuṃghumāḥ |
āsandaśadiśo'dṛśyā bahukṣubdhāyudhānilaiḥ
]

`v 24 [
nirhrādakāribhirvātairvahacchapachapāravam |
prasasrurbhuvi nīhārā mahārṇavarayā iva
]

`v 25 [
vidūrasthā rathebhyaśca vīcicītkārakāriṇaḥ |
sarombhasyanilaiḥ petuḥ padmebhya iva ṣaṭpadāḥ
]

`v 26 [
āyudhaughe'pi cakraughātpādātaṃ balamāvilam |
rajorāśirivāsāre na samarthaṃ palāyate
]

`v 27 [
hūṇā āmastakaṃ magnā uttarārṇavasaikate |
klinnāstatraiva paṅkāntaḥ pūraṇāvilaśūlavat
]

`v 28 [
tīrailāvanalekhāsu śakāḥ pūrvapayonidheḥ |
nītā baddhvā dinaṃ muktā na gatā yamasādanam
]

`v 29 [
mandaṃ mandrā mahendrādrau krandantaḥ patitā divaḥ |
āśvāsitā munivarairnijāśramamṛgā iva
]

`v 30 [
praviṣṭā yācanaṃ sahye labdhāḥ surabilāddvayam |
anarthenā'rtha āyāti kākatālīyataḥ kvacit
]

`v 31 [
patitā dardurāraṇye daśārṇā jīrṇaparṇavat |
bhuktvā viṣaphalānyajñā mṛtāstatraiva te svayam
]

`v 32 [
viśalyakaraṇīṃ bhuktvā kākatālīyayogataḥ |
himādrau haihayā yātā gṛhaṃ vidyādharā iva
]

`v 33 [
pṛṣṭhanṛmlānakusumā dhanurbhirgṛhamāgatāḥ |
vaṅgā nādyāpi dṛśyante piśācatvamivāgatāḥ
]

`v 34 [
aṅgā vanaphalairbhuktairvidyādharapadapradaiḥ |
vidyādharībhiḥ krīḍanti divi vidyādharāḥ sthitāḥ
]

`v 35 [
tālītamālakhaṇḍeṣu patitāḥ pātitāṅgakāḥ |
pārasīkā gatā mohaṃ bhramādvaimānikā iva
]

`v 36 [
taralāsāramātaṅgaṃ patitaṃ taṅgaṇāṅgaṇe |
aṅgairaṅga kaliṅgānāṃ caturaṅgaṃ balaṃ hatam
]

`v 37 [
kramatyaribale sālvāḥ śaraśailodakodare |
patitāḥ prabhuṇā sārdhamadyāpyevopalāḥ sthitāḥ
]

`v 38 [
asaṃkhyāḥ prapalāyantaḥ kakubhaṃ kakubhaṃn prati |
narāḥ sarattaraṅgeṣu sāgareṣu layaṃ gatāḥ
]

`v 39 [
kṣetrāṭavīpurajalasthalaśailakūlakulyāgrahārasaridabdhibhṛgudrumeṣu |
grāmārapaṭṭigirikūpaguhāgṛheṣu bhraṣṭāni kaḥ kalayituṃ kubalāni śaktaḥ |
39 |
na kevalaṃ sāgareṣveva kiṃtu kṣetreṣvaṭavīṣu pureṣu jaleṣu sthaleṣu śaileṣu kūleṣu
kulyāsu agrahāreṣu saritsu abdhiṣu bhṛguṣu drumeṣu tathā grāmeṣu ārapaṭṭiṣu
śulkasthāneṣu giriṣu kūpeṣu guhāsu gṛheṣu ca bhraṣṭāni mṛtāni teṣāṃ kubalāni
kalayituṃ gaṇayituṃ kaḥ śaktaḥ | na kaścidapītyarthaḥ
]