`v 1 [
trayodaśaḥ sargaḥ 13
bhuśuṇḍa uvāca |
jagatprasararūpasya na deśa upayujyate |
na kālo dhāraṇe stambha ālokasyāmbare yathā
]

`v 2 [
manomanananirmāṇamātrametajjagattrayam |
śāntaṃ tanu laghu svacchaṃ vātāntaḥ saurabhādapi
]

`v 3 [
ciccamatkṛtimātrasya sādho jagadaṇoḥ kila |
vātāntaḥ saurabhaṃ meruranyānubhavayogataḥ
]

`v 4 [
yaṃn prayudeti sargoyaṃ sa evainaṃ hi cetati |
padārthaḥ saṃniveśaṃ svamiva svapnaṃ pumāniva
]

`v 5 [
atraivodāharantīmamitihāsaṃ purātanam |
yadvṛttaṃ devarājasya trasareṇūdare purā
]

`v 6 [
kvacitkadācitkasmiṃścitkiṃcitkalpadrume'bhavat |
kasyāṃcidyugaśākhāyāṃ phalaṃ jagadudumbaram
]

`v 7 [
sasurāsurabhūtaughamaśakāhitaghuṃghumam |
śailamāṃsalapātāladyubhūmyugrakapāṭakam
]

`v 8 [
ciccamatkṛticārūccairvāsanārasapīvaram |
vividhānubhavāmodaṃ cittāsvādamanoharam
]

`v 9 [
bṛhadbrahmataruprauḍhasattāvratatikoṭigam |
ahaṃkāramahāvṛntaṃ samālokasamujjvalam
]

`v 10 [
mokṣadvāravikāsyāsyaṃ saridabdhiśirāvṛtam |
mātrāpañcakakośasthaṃ tarattārakasīkaram
]

`v 11 [
kalpāvasānajaraṭhaṃ kākakokilagāmyatha |
patitaṃ śāntimāyātaṃ kvāpyantāvāsanaṃ gatam
]

`v 12 [
tatrābhūdamarādhīśaḥ śakrastribhuvaneśvaraḥ |
kṣaudrakumbhaniṣaṇṇānāṃ kṣudrāṇāmiva nāyakaḥ
]

`v 13 [
gurūpadeśasvābhyāsātsa kṣīṇāvaraṇo'bhavat |
mahātmā bhāvitāntātmā pūrvāparavidāṃ varaḥ
]

`v 14 [
nārāyaṇādiṣu tataḥ kadācidvīryaśāliṣu |
kvacideva nilīneṣu satsvekaḥ sasurādhipaḥ
]

`v 15 [
śastrajvālānalodbhārairayudhyata mahāsuraiḥ |
vijitastairmahāvīryairato vyadravadādrutam
]

`v 16 [
diśo daśa suvegena dudrāvābhidruto'ribhiḥ |
na viśrāmāspadaṃ prāpa paraloka ivādhamaḥ
]

`v 17 [
tadbhrāntadṛṣṭiṣvariṣu manāk chidramavāpya saḥ |
praśamaṃ kāyasaṃkalpaṃ nītvā svaṃ svāntare bahiḥ
]

`v 18 [
kamapyarkāṃśukośasthaṃ trasareṇuṃ viveśa saḥ |
saṃvidrūpatayā padmakośaṃ madhukaro yathā
]

`v 19 [
sa tatrāśu viśaśrāma cirādāśvāsamāyayau |
atha vismṛtasaṃgrāmo nivṛttiṃ samupāgamat
]

`v 20 [
kalpitaṃ sadma tatrātha sa kṣaṇādanubhūtavān |
tasminsadmani padmānte reme sva iva viṣṭare
]

`v 21 [
gṛhasthaḥ sa dadarśātha kalpitaṃ nagaraṃ hariḥ |
maṇimuktāpravālādikṛtaprākāramandiram
]

`v 22 [
nagarāntargato'paśyattato janapadaṃ hariḥ |
nānādrigrāmagokāṭapattanāraṇyarājitam
]

`v 23 [
tādṛgratiścetitavānsaśrakro bhuvanaṃ tataḥ |
sādryabdhyurvīnadīśāntaṃ sakriyākālakalpanam
]

`v 24 [
tādṛgratiścetitavānsa śakrastrijagattataḥ |
sapātālamahīvyomaviṣṭapārkādiparvatam
]

`v 25 [
tatrātiṣṭhatsureśatve sa bhogabharabhūṣitaḥ |
putro babhūva tasyātha kundo nāmātha vīryavān
]

`v 26 [
tato jīvitaparyante tyaktvā dehamaninditaḥ |
nirvāṇamāyayau śakro niḥsneha iva dīpakaḥ
]

`v 27 [
kundastrailokyarājo'bhūjjanayitvā sutaṃ nijam |
kālena jīvitasyānte jagāma paramaṃ padam
]

`v 28 [
tatputro'pi tathaivātha kṛtvā rājye sutaṃ nijam |
jagāma jīvitasyānte pāvanaṃ paramaṃ padam
]

`v 29 [
evaṃ pautrasahasrāṇi samatītāni sundara |
tatrādyāpi sureśasya yeṣāṃ rājye sthitoṃ'śakaḥ
]

`v 30 [
ityadyayāvadamareśvaravaṃśa eva saṃkalpite jagati śakrapadaṃ vidhatte |
tasminkṣate'pi galite'pi hate'pi naṣṭe kvāpyambare dinakarātapapāvanāṇau
]