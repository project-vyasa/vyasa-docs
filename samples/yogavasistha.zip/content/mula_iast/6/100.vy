`v 1 [
śatatamaḥ sargaḥ 100
śrīrāma uvāca |
yuktiḥ syātkīdṛśī brahmansaṃsāre duḥkhaśāntaye |
teṣāṃ yeṣāmayaṃ pakṣaḥ śrūyatāmucyatāṃ tataḥ
]

`v 2 [
yāvajjīvaṃ sukhaṃ jīvennāsti mṛtyuragocaraḥ |
bhasmībhūtasya śāntasya punarāgamanaṃ kutaḥ
]

`v 3 [
śrīvasiṣṭha uvāca |
yaṃ yaṃ niścayamādatte saṃvidantarakhaṇḍitam |
tattathaivānubhavati pratyakṣamiti sarvagam
]

`v 4 [
yathā khaṃ sarvagaṃ śāntaṃ tathā cidvyoma sarvagam |
tadevaikyamatha dvaitamanyārthasyātyasaṃbhavāt
]

`v 5 [
sargādau tadṛte'nyo'rtho mahāpralayarūpiṇi |
akāṇaratvānnāstyeva brahmaivedamatastatam
]

`v 6 [
samastavedaśāstrārthaṃ ye mahāpralayādi ca |
necchanti te mahāmūḍhā niḥśāstrā no mṛtā iva
]

`v 7 [
sarvaśāstrāviruddhena sarvaṃ brahmedamityalam |
sthitaṃ sānubhavaṃ yoktṛ yeṣāṃ tairna kathākramaḥ
]

`v 8 [
nityā nirantarodeti yādṛśī saṃvidāśaye |
bhūyate tanmayenaiva puṃsā deho'stu māthavā
]

`v 9 [
bodhāccetsaṃvido jātaḥ sa duḥkhī puruṣo bhavet |
viruddhaṃ vedanaṃ yāvattāvajjīvo'ṅga tanmayaḥ
]

`v 10 [
jagaccidvyomakacanamātrameveti bhāvite |
tatkathaṃ vedanaṃ vyomnā bodhaḥ kasya kuto bhavet
]

`v 11 [
nā kānicitpradhāvanti ekaniścayasaṃvidām |
puṃsāṃ sukhāni duḥkhāni rajāṃsi nabhasāmiva
]

`v 12 [
saṃvitsatyāstvasatyā vā niścayastāvadīdṛśaḥ |
ābālametatsaṃsiddhaṃ kenāpahnūyate katham
]

`v 13 [
na dehaḥ puruṣo vāpi jīvo'nya upalabhyate |
saṃvitsarvamidaṃ sā tu yathā vetti tathā jagat
]

`v 14 [
sā satyāpyathavāsatyā tayā deho'nubhūyate |
svātantryeṇa yathā svapne pātāle khe jale divi
]

`v 15 [
saṃvitsatyāstvasatyā vā tāvanmātraḥ smṛtaḥ pumān |
sa yathāniścayo nūnaṃ tatsatyamiti niścayaḥ
]

`v 16 [
prāmāṇyaṃ sarvaśāstrāṇāmetenaiva prasiddhyati |
sarvasiddhāntasiddhānta eṣa eveti me matiḥ
]

`v 17 [
tasmādabodhatā yāste yathā saṃvittathaiva sā |
bhavatyakaluṣākārā tathaiva phalabhāginī
]

`v 18 [
deśakālakriyādravyavedaśāstraiṣaṇābhramaiḥ |
abodhatā tu yā saṃvitkadācitsā na naśyati
]

`v 19 [
āvirbhavati sā bhūyaḥ kṣīṇāśaṅkā kṣaṇena cet |
tatkena saṃvido duḥkhaṃ kadā nāmopaśāmyati
]

`v 20 [
bodhe bādhitāyā avidyāyāḥ punarāvirbhāvastu na śaṅkyo
bījābhāvādanirmokṣaprasaṅgāccetyāha - āvirbhavatīti | ātyantikabādhena kṣīṇā
punaḥ prasaktyāśaṅkāpi | sā avidyā bhūyaḥ kṣaṇādāvirbhavati cettattarhi saṃvido
jīvasya duḥkhaṃ kadā kena vā nāmopaśāmyati - na kadācinna kenacidapītyarthaḥ |
19 |
saṃvideva nṛṇāṃ jīvaḥ sa yathā dṛḍhabhāvanaḥ |
tathā sukhī vā duḥkhī vā bhavedityeṣa niścayaḥ
]

`v 21 [
saṃviccedasti tajjñānāṃ śaraṇaṃ bhavabhedane |
nāsti cettacchilāmūkamāndhyamevāvaśiṣyate
]

`v 22 [
yattayaiva ca saṃvittyā vedanenaiva labhyate |
ayaṃ svabhāvajñaptyāntarjāḍyaṃ puṃseva nidrayā
]

`v 23 [
śrīrāma uvāca |
dikṣvadhastācca nānto'syā bhāvī nāpi jagatkṣayaḥ |
astīti bhāvitaṃ yena saṃtyaktā'bhāvabuddhinā
]

`v 24 [
vijñānaghanamevedamiti nūnamapaśyatā |
paśyatā ca yathādṛṣṭaṃ sarvakṣayamapaśyatā
]

`v 25 [
tasya syātkīdṛśī brahmanyuktirādhivināśane |
iti me saṃśayaṃ chindhi bhūyo bodhābhivṛddhaye
]

`v 26 [
śrīvasiṣṭha uvāca |
atraikaṃ tāvaducitaṃ pūrvameva tathottaram |
dvitīyamuttaraṃ nyāyyaṃ vakṣyamāṇamidaṃ śṛṇu
]

`v 27 [
īdṛgbhāvastvayā prokto yaḥ pumānpuruṣottama |
sa tāvaccetanāmātraṃ bhavatītyanubhūyate
]

`v 28 [
sa cākāravināśena yujyate nātra saṃśayaḥ |
athāvināśo dehaścettadduḥkhasyātra kaḥ kramaḥ
]

`v 29 [
tatkutastatrāha - sa ceti | hyarthe'yaṃ caḥ paṭhitaḥ | yasmātsa
dehādyākāropādhināśena paramātmanā saha yujyate ekībhavati | dvitīye tvāha -
atheti | vināśinyannamaye dehe ātmatābuddhau sarvato vināśāśaṅkayā duḥkham |
avināśinyātmatāniścaye tu na dehākāratvadarśanamātrāparādhena duḥkhaprasaktiriti
kramātso'pi bodhyamānastattvaṃ pratipatsyata iti bhāvataḥ | tat tarhi | kramaḥ prasaṅgaḥ |
28 |
bhavedbhāgavibhāgātmavināśastvavicāritaḥ |
avaśyaṃ tasya bhavati kileti nanu niścayaḥ
]

`v 30 [
mṛtaḥ sa saṃvidātmatvādbhūyo no vetti saṃsṛtim |
jñānadhautā na yā saṃvinna sā tiṣṭhatyasaṃsṛtiḥ
]

`v 31 [
caturthakalpe'pyāha - mṛta iti | sa śuddhasaṃvidātmadarśī | jīvanmuktaḥ sarvadā
sarvatra līlayā jagatpaśyannapi mṛto videhatāmātreṇa kaivalyaṃ prāptaḥ sanbhūyaḥ
saṃsṛtiṃ no vetti | na paśyatītyarthaḥ | pañcamakalpe'pyāha - jñāneti | yā saṃvit
tattvajñānena na dhautā sā saṃsṛtibījabhāvāvināśādasaṃsṛtirna tiṣṭhati | avaśyaṃ
saṃsaratyevetyarthaḥ | tathā ca tasyā api kvacijjanmani jñānodayānnistāra iti bhāvaḥ | 30
|
athavā nāsti saṃvittiriti niścayavānyadi |
tatastādṛgvedanato bhavatyeva dṛṣajjaḍaḥ
]

`v 32 [
yathāvedanamartheṣu cittve dehakṣayātkṣate |
mṛtireva paraṃ śreyo dṛṣṭaṃ nānubhavāditi
]

`v 33 [
asaṃbhavācchuddhavido niḥśarīrā bhavanti ye |
jaḍabhāvā jaḍībhūya durbhedāndhyā bhavanti te
]

`v 34 [
ye cāpi svapnapuravatsarvaṃ paśyanti cinmayāḥ |
teṣāmidamivāśeṣaṃ jagajjālaṃ pravartate
]

`v 35 [
ye'pi vijñānavādinaḥ kṣaṇikavijñānamayaṃ svapnatulyaṃ jagaditi paśyanti teṣāmapi
vyavahārasiddhistulyetyāha - ye cāpīti | cinmayāḥ kṣaṇikavikāricidātmabhūtāḥ | 34
|
sthairyāsthairyeṇa bhūtānāṃ kimapūrvamatau bhavet |
bhūtasthairye tathāsthairye sukhaṃ caivāsukhaṃ samam
]

`v 36 [
sthiramastvasthiraṃ vāpi mahyādimahatāmapi |
cidbhāmātramidaṃ bhāti yāvadajñānamātatam
]

`v 37 [
saṃvidā saṃvido'sattāmihāvyāpya vinaṣṭayā |
nirṇīyāṅgīkṛtaṃ yairvā jāḍyaṃ tadbālakairalam
]

`v 38 [
saṃvidastu na kṣaṇikatvaṃ tatyā svāsattālakṣaṇasya svanāśasya jāḍyasya ca
vyāptumaśakyatayā saṃvidvyāptimantareṇa tadubhayasiddhyayogācca
taduktisaṃbhavābhāvādityāha - saṃvideti | saṃvidaḥ kālato'sattā kṣaṇikatvaṃ
deśataḥ asattā tu jāḍyaṃ dvividhāmapi tāṃ avyāpya aspṛṣṭvā vinaṣṭayā
kṣaṇikatvābhimatasaṃvidā jāḍyam | kṣaṇikatvasyāpyupalakṣaṇametat |
yairnirṇīyāṅgīkṛtaṃ taistathāvidhairbālakairmūrkhairalaṃ saṃbhāṣaṇenetyarthaḥ | 37
|
yeṣāṃ vidbhyaḥ śarīrāṇi te vandyāḥ puruṣottamāḥ |
śarīrebhyo vido yeṣāṃ tairalaṃ puruṣādhamaiḥ
]

`v 39 [
cidrūpo jīvabījaugha ākāśakṛmijālavat |
ūrdhvaṃ tiryagadho yāti pūryamāṇa iva svayam
]

`v 40 [
cetyate yena kartānyo bījaughena sa tatparaḥ |
tathaivānubhavatyantaḥ svayameva vivalgati
]

`v 41 [
sā nānākartṛjīvasamaṣṭitāpi hiraṇyagarbhacitaḥ svakalpanābhiniveśavaśādevetyāha
- cetyata iti | bījaughenetītthaṃbhāve tṛtīyā | yena hiraṇyagarbhacidābhāsena
bījaughabhāvena samaṣṭitāṃ svasyopāsyatadvāsanānusārātkalpādau anyaḥ bahudhā
bhinno vyaṣṭirūpaḥ kartā svāntaścetyate sa tatparastadāsaktaḥ saṃstathaiva
nānākartṛrūpaṃ svāntaḥ svayamevānubhavati tathaiva vivalgati saṃsarati cetyarthaḥ | 40
|
yadyathā cetyate yena tajjīvenāśu tena tat |
cidrūpeṇāpyate siddhametadābālamakṣatam
]

`v 42 [
yathā dhūmasya nabhasi yathāmbhodhau mahāmbhasaḥ |
āvartavṛttayaścitrāstathā cidvyomni saṃsṛteḥ
]

`v 43 [
purī bhavati cidvyoma yathā svapne naraṃ prati |
tathādisargātprabhṛti tadevedaṃ jagatsthitam
]

`v 44 [
sahakārinimittāni yathā svapne na santi vai |
pṛthivyādīni bhūtāni tathaivādau jagatsthiteḥ
]

`v 45 [
aṅgānāṃ svapnanagare vasudhā vividhāḥ kṛtāḥ |
yāstā eva jagatsvapnanagare puṣṭatāṃ gatāḥ
]

`v 46 [
cinmātrākāśamevemāḥ prajā dvaitaikyavarjitāḥ |
ke vātra rañjanānyā khe yadvābhāti khameva tat
]

`v 47 [
ciccandrikā caturdikkaṃ śītalāhlādakāriṇī |
tanoti cetanālokaṃ tasyedaṃ kacanaṃ jagat
]

`v 48 [
adyaivādyantayorvyomni cinmaye sargadarśanam |
cidunmeṣanimeṣābhyāṃ khātmodetyastameti ca
]

`v 49 [
yadyathā vetti yattatsattathaivānubhavatyalam |
yasmātsamastaṃ cinmātraṃ kimivātra na vidyate
]

`v 50 [
śaradākāśaviśadaṃ saṃvidaḥ saumyamānasāḥ |
asanta eva tiṣṭhanti santo'dhigatatatpadāḥ
]

`v 51 [
nirmānamohā jitasaṅgadoṣāḥ pravāhasaṃprāptanijārthabhājaḥ |
tiṣṭhanti kāryavyavahāradṛṣṭau nirāmayā yantramayā ivaite
]