`v 1 [
ekaṣaṣṭyadhikaśatatamaḥ sargaḥ 161
śrīrāma uvāca |
yanmunivyādhayoretadvṛttaṃ nānādaśāśatam |
anyakāraṇakaṃ kiṃ syādetatkiṃ vā svabhāvajam
]

`v 2 [
śrīvasiṣṭha uvāca |
īdṛśāḥ pratibhāvartāḥ paramātmamahāmbudhau |
anārataṃ pravartante svataḥ svātmani khātmakāḥ
]

`v 3 [
yathā spandātmano vāyorajasraṃ spandalekhikāḥ |
udyantyeva sataścittvāccidvyomni pratibhāyutāḥ
]

`v 4 [
yā yathā svāṅgabhūtāsmāduditā pratibhā prabhā |
tāvatseha tathaivāste na hatā yāvadanyayā
]

`v 5 [
nānāvayavavāneka evehāvayavī yathā |
cidbrahmaikamidaṃ vyoma tathaivaṃ pratibhātmakam
]

`v 6 [
brahma kāścitsthirāḥ kāścidasthirāḥ pratibhārthavat |
dehāvasthā ivātmasthāḥ sthitamātmani khātmani
]

`v 7 [
svātmani svapnapuravadbhānaṃ citi camatkṛtiḥ |
kiṃ sāraṃ kimasāraṃ vā kiṃ satkiṃ vāpyasadbhavet
]

`v 8 [
parijñātamidaṃ yāvatsarvaṃ cidvyomamātrakam |
dṛśyaṃ jagadbhavadbuddhaṃ na sannāsatkimucyate
]

`v 9 [
cidvyomamātrakacanaṃ saṃsāre sarvataḥ śive |
āsthānāsthādi kiṃ tajjñā yathāsaṃsthānamāsthita
]

`v 10 [
samudyanti svato'mbhodhervīcivatpratibhākṛtāḥ |
svātmikāḥ svātmano devātkāryakāraṇadṛktayā `note[dyotamānāt |]
]

`v 11 [
sphāraṃ yatparamaṃ vyomnaḥ svasaṃkalpasvasargavat |
tattenaiva jagadbuddhaṃ kutaḥ pṛthvyādayo'tra ke
]

`v 12 [
bhātyevamayamābhāso naiva bhāti ca kiṃcana |
brahmaṇyeva sthitaṃ brahma tadavidyābhidhaṃ svataḥ
]

`v 13 [
ghanatā cidghaneneha cidvyomaivākhilaṃ jagat |
ityeva paramo bodha etatprauḍhistu muktatā
]

`v 14 [
cidvyomaśūnyatārūpamātramābhāsa ātataḥ |
aidamapratighaṃ śāntaṃ jagadityeva bhāsate
]

`v 15 [
dhyāyinaḥ kṣīṇadehasya dhyāne dṛktve kṣaṇaṃ sthite |
cinmātravyatirekeṇa śaktatvaṃ syātkimucyatām | 15 |
etacca dhyāyināmanubhavasiddhamityāha - dhyāyina iti |
nirvikalpasamādhipratiṣṭhayā kṣīṇadehasya ucchinnadehabhāvasya | dṛktve
sākṣicinmātrarūpatve | śaktatvaṃ jagaddarśanasāmarthyaṃ kiṃ syāt |
tasmādajñānadṛśaiva tatsāmarthyaṃ pariśeṣāditi bhāvaḥ
]

`v 16 [
ciddhātuvyomabhāgo yo bhāti yatra yathā yathā |
tathā tathā sa tatrāste yāvaditthaṃ svabhāvataḥ
]

`v 17 [
avicāravato dṛśyabhrāntirgaganamayyapi |
jātitaimirikadvīndudoṣavannopaśāmyati
]

`v 18 [
yadidaṃ dṛśyate kiṃcittadrahmaiva nirāmayam |
cidākāśamanādyantaṃ tatkathaṃ kiṃ praśāmyati
]

`v 19 [
svamasantyajato rūpaṃ svacchasaṃvedanātmakam |
svapnavatkacanaṃ svasya yannāma tadidaṃ jagat
]

`v 20 [
śāstrārthaistīkṣṇayā buddhyā mitho yanna vikalpanaiḥ |
kṛtvā suptamivātmānaṃ kiṃcidbuddhena bodhyate
]

`v 21 [
rūḍhā yeyamavidyeti saṃvidavyabhicāriṇī |
bhavatāṃ nanu nāstyeva sā saritsviva pāṃsubhūḥ
]

`v 22 [
yathā svapne'vanirnāsti svānubhūtāpi kutracit |
tatheyaṃ dṛśyatā nāsti svānubhūtāpyasanmayī
]

`v 23 [
cidvyomamātramevārthā'nalavadbhāsate yathā |
svapne tathaiva jāgrattve'nalaṃ svasyaiva lakṣyate
]

`v 24 [
idaṃ jāgradayaṃ svapna iti nāstyeva bhinnatā |
satye vastuni niḥśeṣasamayoryānubhūtitaḥ
]

`v 25 [
naitadevamiti svapnaprabodhātpratyayo yathā |
mṛtvāmutra prabuddhasya jāgrati pratyayastathā
]

`v 26 [
kālamalpamanalpaṃ ca svapnajāgraditīha dhīḥ |
vartamānānubhavanasāmyāttulye tayordvayoḥ
]

`v 27 [
bāhye tadevamityādiguṇasāmyādaśeṣataḥ |
na jāgratsvapnayorjyāyāneko'pi yamayoriva
]

`v 28 [
yadeva jāgratsvapno'yaṃ yaḥ svapno jāgradeva tat |
naitadevaṃ kiletyasti dhīḥ kālenobhayorapi
]

`v 29 [
ājīvitāntaṃ svapnānāṃ śatānyaniyataṃ yathā |
anirvāṇamahābodhe tathā jāgracchatānyapi
]

`v 30 [
utpannadhvaṃsinaḥ svapnāḥ smaryante bahavo yathā |
tathaiva buddhaiḥ smaryante siddhairjanmaśatānyapi
]

`v 31 [
evaṃ samastasādharmye samastānubhavātmani |
kacati svapnavajjāgrajjāgradvatsvapnavedanam
]

`v 32 [
yathā dṛśyaṃ jagacceti nityamekārthatāṃ gatau |
ubhau śabdau tathaivaitajjāgratsvapnātmakau smṛtau
]

`v 33 [
evaṃ svapnapuraṃ sphāraṃ yathā vyomaiva cinmayam |
tathaivedaṃ jagadataḥ kvāvidyā dṛśyate kutaḥ
]

`v 34 [
tadevākāśamātrātma yadyavidyeti kathyate |
tadyadāste tadevāhaṃ bandhaḥ svakalanātmakaḥ
]

`v 35 [
tanmaivaṃ kriyatāmetadabandhasyaiva bandhanam |
kānyatā amalavyomnaścinmayasya nirākṛteḥ
]

`v 36 [
cinmayākāśakacane kvāsminkila nirākṛteḥ |
dṛśyanāmanyavidyākhye bandho mokṣo'thavā kutaḥ
]

`v 37 [
nāvidyā vidyate nāma bandho bandho na kasyacit |
mokṣo na kasyacinmokṣaścāstināstīti nāstyalam
]

`v 38 [
nāstyeva vidyā'vidyā vā cideveyaṃ kacatyajā |
kha eva khākṛtiḥ svapna iva sargasvadehinī
]

`v 39 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
tajjāgratsvapnadṛśyasya rūpamityeva niścayaḥ
]

`v 40 [
sabāhyābhyantare dṛśye śāntanidrasya yadvapuḥ |
ekasya niśi tadrūpaṃ jāgratsvapnadṛśāmiha
]

`v 41 [
viddhi tadrūpamevedaṃ bhedavedanamityapi |
cityantamāgataḥ ko'nyo nāma syādbhedavedane
]

`v 42 [
cidvyomaivābhedabuddhiścidvyomaiva ca bhedadhīḥ |
dvaitādvaite caikameva tathā śāntamakhaṇḍitam
]

`v 43 [
sadaṃśo bodhatadgrāhyamaya eva yathā tathā |
dṛṣṭā ya eva dṛśyaṃ taddvaitavedanamekakam
]

`v 44 [
tadbrahma khaṃ vidurdvaitamadvaitādvaitameva ca |
sarga eva paraṃ brahma dvaitamadvaitameva sat
]

`v 45 [
neti neti vinirṇīya sarvato'bhibhavatyapi |
paścāttyaktvā cidākāśe śilāṃ kṛtvāsyatāmiha
]

`v 46 [
yathākramaṃ subhaga yathāsthitasthiti yathodayaṃ vraja piba bhuṃkṣva bhojaya |
abhīpsitaṃ gatamanano niriṅganaḥ sucinmaye paramapadopalo bhavān
]