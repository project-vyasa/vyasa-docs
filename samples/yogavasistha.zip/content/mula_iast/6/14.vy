`v 1 [
caturdaśaḥ sargaḥ 14
bhuśuṇḍa uvāca |
tasya śakrasya kulajaḥ kaścidāsītsurādhipaḥ |
tatrottamaguṇaḥ śrīmānpāścātyā yasya sā tanuḥ
]

`v 2 [
athendrakulaputrasya tasya tatra babhūva ha |
pratibhājñānasaṃprāptirbṛhaspatigiroditā
]

`v 3 [
tato viditavedyo'sau yathāprāptānuvṛttimān |
cakāra jagatāṃ rājyamājyapānāmadhīśvaraḥ
]

`v 4 [
yuyudhe dānavaiḥ sārdhamajayatsarvaśātravān |
śataṃ cakāra yajñānāmajñānottīrṇamānasaḥ
]

`v 5 [
uvāsa kāryavaśato bisabālāntare ciram |
anyānyapi ca vṛttāntaśatānyanubabhūva ha
]

`v 6 [
kadācidāsīttasyecchā prabodhabalaśālinaḥ |
brahmatattvamavekṣe'haṃ yathāvaddhyānavāniti
]

`v 7 [
so'paśyatpraṇidhānena tata ekāntasaṃsthitaḥ |
sabāhyābhyantare'śeṣakāraṇatyāgaśāntadhīḥ
]

`v 8 [
sarvaśaktiparaṃ brahma sarvavastumayaṃ tatam |
sarvathā sarvadā sarvaṃ sarvaiḥ sarvatra sarvagam
]

`v 9 [
sarvataḥpāṇipādāntaṃ sarvatokṣiśiromukham |
sarvataḥśrutimalloke sarvamāvṛtya saṃsthitam
]

`v 10 [
sarvendriyaguṇairmuktaṃ sarvendriyaguṇānvitam |
asaktaṃ sarvabhṛccaiva nirguṇaṃ guṇabhoktṛ ca
]

`v 11 [
bahirantaśca bhūtānāmacaraṃ carameva ca |
sūkṣmatvāttadavijñeyaṃ dūrasthaṃ cāntike ca tat
]

`v 12 [
sarvatra candrārkamayaṃn sarvatraiva dharāmayam |
sarvatra parvatamayaṃn sarvatrābdhimayaṃ tathā
]

`v 13 [
sarvatra sāragurukaṃ sarvatraiva nabhomayam |
sarvatra saṃsṛtimayaṃ sarvatraiva jaganmayam
]

`v 14 [
sarvatraiva ca mokṣātma sarvatraivādyacinmayam |
sarvatra sarvārthamayaṃ sarvataḥ sarvavarjitam
]

`v 15 [
ghaṭe paṭe vaṭe kuḍye śakaṭe vānare tathā `note[nare iti pāṭhaḥ |] |
dhāmni vyomni tarāvadrāvanile salile'nale
]

`v 16 [
nānācāravicārāṇi vividhāvṛttimanti ca |
paramāṇvaṃśamātre'pi trijaganti dadarśa saḥ
]

`v 17 [
maricasyāntare taikṣṇyaṃn śūnyatvamiva cāmbare |
trijagatsatyasati ca vidyate cinmayātmani
]

`v 18 [
ityevaṃ bhāvayanmuktabhāvayā śuddhasaṃvidā |
śakraḥ krameṇa tenaiva tathaiva dhyānavānabhūt
]

`v 19 [
dhyānena sarvamekatra paśyaṃściramudāradhīḥ |
dadarśemamasau sargamasmadīyaṃ mahāmatiḥ
]

`v 20 [
tato'sminvicaransarge śakrānte śakratāṃ gataḥ |
cakāra rājatāṃ `note[jagatāṃ iti mudritapāṭhaṣṭīkākartrasaṃmataḥ |] rājyaṃ
vṛttāntaśataśobhitam
]

`v 21 [
vidyādharakulādhīśa ityadyaiva sa devarāṭ |
tasyendrasya kulotpanna iti viddhi yathāsthitam
]

`v 22 [
tato hṛdayabījasthaprāṅmukhyābhyāsayogataḥ |
bisabālanivāsādivṛttāntamanubhūtavān
]

`v 23 [
yathaiṣa śakraḥ kathitastrasareṇūdarāspadaḥ |
bisabālāspadaścaitatkulajaḥ kāntimānatha
]

`v 24 [
tathā śatasahasrāṇi tatretaścānyataśca khe |
tādṛśavyavahārāṇi samatītāni santi ca
]

`v 25 [
vahatīyamavicchinnā cirāyaivaṃ taraṅgiṇī |
tāvaddṛśyasaritprauḍhā rūḍhārūḍhe ca tatpade
]

`v 26 [
iti māyeyamādīrghā prasṛtā pratyayonmukhī |
satyāvalokamātrātivilayaikavilāsinī
]

`v 27 [
yataḥ kutaścinmāyeyaṃ yatra kvacana vānagha |
yathākathaṃcitsaṃpannamātraiva paridṛśyate
]

`v 28 [
ahaṃbhāvacamatkāramātrādvṛṣṭirivāmbudāt |
jāyate mihikevāśu prekṣāmātravināśinī
]

`v 29 [
yenāyatābhimatadarśanadraṣṭṭadṛśyamuktasvabhāvamavabhāsanamātma##-
sarvārthaśūnyamata eva ca śūnyarūpamekaṃ khamātramiva mātravikalpameva | 29
|
yena hetunā mātṛsarvasākṣibrahmarūpamavikalpaṃ sarvavikalparahitameva
paramārthataḥ | ata eva ahaṃkāravaśādāyatāni vistīrṇāni yāni abhimatāni
mānasavikalpāḥ darśanāni tripuṭīlakṣaṇaindriyakavikalpāśca tairmuktasvabhāvam |
jāgradavasthāśūnyamiti yāvat | ata eva vāsanāmayasvāpnasarvārthaśūnyamata eva ca
pratiyogyaprasiddhyā sarvaśūnyatālakṣaṇena sauṣuptājñānena ca śūnyaṃn
khamātramiva pūrṇamavabhāsanaṃn cidrūpamātmatattvaṃ pariśiṣṭamityarthaḥ
]