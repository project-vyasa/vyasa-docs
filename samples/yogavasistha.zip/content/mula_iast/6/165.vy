`v 1 [
pdf 352, p. 1455
pañcaṣaṣṭyadhikaśatatamaḥ sargaḥ 165
śrīvasiṣṭha uvāca |
jāgratsvapne svapna eva jāgrattvamanugacchati |
svapnajāgrati jāgrattu svapnatāmupagacchati
]

`v 2 [
svapno jāgratpraviśati jāgratsvapnātprabudhyate |
jāgratsvapnaṃ praviśati prabuddhaḥ svapnajāgrataḥ
]

`v 3 [
jāgratsvapnavatā svapnaḥ svapna ityabhidhīyate |
svapnajāgradvatā jāgrajjāgradityabhidhīyate
]

`v 4 [
tajjāgrajjāgratīveha na tu svapnaḥ kadācana |
svapne svapno jāgradeva na tu jāgratkadācana
]

`v 5 [
laghukālātmakaḥ svapnaḥ sarvadaiva hi jāgrati |
laghukālātmakaṃ jāgratsvapnakāle sadaiva ca
]

`v 6 [
na jāgratsvapnayorbhedaḥ kaścanāsti kadācana |
ekasyāvasaro'nyatra dvayorapi na sanmayaḥ
]

`v 7 [
mṛtiprabodhasamaye jāgratsvapnaḥ praśāmyati |
svapnānubhavabodhe ca śūnya evātibhāsvaraḥ
]

`v 8 [
jīvataḥ svapnasamaye mṛtibodhodayaṃ vinā |
paralokātmakaṃ jāgratkiṃcanāpi na dṛśyate
]

`v 9 [
sthite jīvitabodhe'smiñchūnye nānāmayātmani |
paralokātmakaḥ svapnaḥ kaścanāpi na dṛśyate
]

`v 10 [
ciccamatkṛtimātrātma yathā svapne jagattrayam |
hṛdi sargātprabhṛtyeva tathaivābhāti jāgrati
]

`v 11 [
ciccamatkāramātrātmatvaṃ ca dvayorapi tulyamityāha - ciditi | hṛdi antaḥkaraṇe | 10
|
santyevāsatyabhūtāni sphārāpi paramārthataḥ |
nāstyevākāravatteyaṃ svapnorvyāmiva jāgrati
]

`v 12 [
nānātmabhāsuramapi svapne śūnyaṃ yathā jagat |
tathaiva jāgratyakhilaṃ vyomaivedaṃ cidātmakam
]

`v 13 [
cidvyomno hi svabhāvo'yaṃ yadidaṃ jagadambare |
kacatītthamiha sphāramāloka iva tejasaḥ
]

`v 14 [
citeścamatkṛtiriyaṃ jagannāmnī cakāstyalam |
sahajā gagane kuḍye paramāṇau sthale jale
]

`v 15 [
bhrāntāvasatyarūpāyāṃ sthitāyāṃ satyavastuvat |
ākāśamātradehāyāṃ ka ivaināṃ prati grahaḥ
]

`v 16 [
grahītṛgrahaṇagrāhyarūpamāśūnyameva ca |
sadastvevāsadevāstu jagadatrāṅga kiṃ grahaḥ
]

`v 17 [
itthamastvidamathānyathāstu vā maiva bhūdbhavatu ko'tra saṃbhramaḥ |
ko'tra phalguni phale phalagraho buddhameva tadalaṃ vikalpanaiḥ
]