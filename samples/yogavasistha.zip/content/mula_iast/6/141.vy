`v 1 [
ekacatvāriṃśadadhikaśatatamaḥ sargaḥ 141
muniruvāca |
tatra daṃdahyamāno'pi nābhavaṃ duḥkhabhāgaham |
svapne svapno'yamityeṣa jānannagnāvapi cyutaḥ
]

`v 2 [
jvālājālanavoḍḍītimaṇḍalairakhilairnabhaḥ |
alātacakravaccāru kevalaṃ bhrāntavānaham
]

`v 3 [
taṃ davāgnimahaṃ yāvattattvavittyādakhinnadhīḥ |
vicārayāmyakhinnātmā mārutastāvadāyayau
]

`v 4 [
sītkāramatigambhīraṃ dadhanmegharavopamam |
jagatpadārthairāvṛttairuhyamānaiḥ parāvṛtaḥ
]

`v 5 [
bṛhadbhirghuṃghumāvegairvane dviguṇitāmbudaḥ |
sūryairāvṛttibhirvyūḍhairvimiśrālātacakrakaḥ
]

`v 6 [
jvālāsaṃdhyābhranivahairbṛhadagninadīśataḥ |
śailadviguṇabhūkhaṇḍadānavāmarapattanaḥ
]

`v 7 [
bhūtairdviguṇapātraugho bhrāntairambarakukṣiṣu |
dagdhādagdhābhirapyardhadagdhābhiritaretaram
]

`v 8 [
patantībhiḥ surastrībhirdviguṇāgniśikhālavaḥ |
patadaṅgāradhāraughakaṇasīkaradanturaḥ
]

`v 9 [
alātavidyuto dhunvanpūtāṅgārogramaṇḍalīḥ |
dhūmāndhakāraiḥ sthagayanmlānamūrdhvadiśomukham
]

`v 10 [
bhūmervyomno diṅmukhebhyaḥ samantājjvālāsaṃdhyāvāridā nirgatāste |
yaistairjvālāśailasaṃpiṇḍamātraṃ savyomaukāḥ saṃsthitā saptalokī
]

`v 11 [
kvāpi protphālakīrṇānalakaṇakapilaprollasanmūrdhajāliḥ kvāpi
proḍḍīnakuḍyaḥkaṭuraṭanapaṭurbhasmasaṃpiṇḍapāṇḍuḥ |
kvāpi jvālāpaṭālīṃ paridadhadabhitaḥ sampatantīṃ gṛhītāṃ raudraḥ kartuṃ
pravṛtto hara iva sa tadā māruto nṛtyalīlāḥ
]