`v 1 [
ekāśītitamaḥ sargaḥ 81
śrīvasiṣṭha uvāca |
atha rāghava rudraṃ taṃ tadā tasminmahāmbare |
pravṛttaṃ nartituṃ mattamapaśyaṃ vitatākṛtim
]

`v 2 [
vyomevākṛtimāpannamajahadvyāpitāṃ nijām |
mahākāraṃ ghanaśyāmaṃ daśāśāparipūrakam
]

`v 3 [
arkenduvahninayanaṃ caladdaśadigambaram |
ghanadīrghaprabhājālamālānaṃ śyāmalārciṣām
]

`v 4 [
vaḍavāgnidṛśaṃ lolabhujormibharabhāsuram |
ekārṇavārṇo drāgdehabandheneva samutthitam
]

`v 5 [
baḍavāgnaya iva dṛśo yasya | dehabandhena śarīragrahaṇena samutthitamivetyutprekṣā |
4 |
paśyāmyanantaramahaṃ yāvattasya śarīrataḥ |
chāyeva pariniryāti nartanānuvidhāyinī
]

`v 6 [
sūryeṣvavidyamāneṣu mahātamasi cāmbare |
sthitā kathamiyaṃ chāyā bhavediti matirmama
]

`v 7 [
yāvadvicārayāmyāśu tāvattasya tadā puraḥ |
sā sthitā parinṛtyantī vistīrṇā śrītrilocanā
]

`v 8 [
kṛṣṇā kṛśā śirālāṅgī jarjarā vitatākṛtiḥ |
jvālākulānalālolavanasaṃbhāraśekharā `note[jvālākulānanā iti pāṭho yuktaḥ |
]
]

`v 9 [
bhinnāñjanatamaḥśyāmā yāminīvākṛtiṃ gatā |
tamaḥśrīrdehayukteva sākārevāmbaradyutiḥ
]

`v 10 [
atidīrghā karālāsyā nabho mātumivodyatā |
dīrghajānubhujabhrāntyā mātukāmeva diṅmukham
]

`v 11 [
kṛśā bahūpavāseva parinimnamahātanuḥ |
kajjalaśyāmalā meghamāleva pavanākulā
]

`v 12 [
kṛśāśaktā yadā sthātuṃ sudīrghā vidhinā tadā |
grathiteva śirārūpairdāmabhirdairghyaśālibhiḥ
]

`v 13 [
tathā nāma sudīrghā sā yathā tasyāḥ śiraḥkhuram |
mayā dṛṣṭaṃ prayatnena cirordhvādhogamāgamaiḥ
]

`v 14 [
antrāntratantrīgrathitaśiraḥkarakhurotkarā |
āmūlātsūtravalitā kaṇṭakānāmiva sthalī
]

`v 15 [
viśvarūpamayārkādiśiraḥkamalajālakaiḥ |
kṛtamālāmalālokavātavahnimayāñcalā
]

`v 16 [
pralambakarṇālulutanāgā nṛśavakuṇḍalā |
śuṣkatumbīlatāṣṭhīlādīrghālolāsitastanī
]

`v 17 [
kumārabarhipicchaughairbrāhmamūrdhajamaṇḍalaiḥ- |
lāñchitoccasurādhīśaśiraḥkhaṭvāṅgamaṇḍalā
]

`v 18 [
tandendumālāvimalā vimaloddyotapātataḥ |
tamorṇavorddhvalekheva vṛttāvartavivartinī
]

`v 19 [
śuṣkatumbīlatevoccairākāśatarusaṃsthitā |
vilolāvayavāṣṭhīlā vātaiḥ paṭapaṭāravā
]

`v 20 [
bṛhattaraṅgordhvabhujā śyāmalollāsaśālinī |
ekārṇavormimāleva nṛttāvṛttivivartinī
]

`v 21 [
kṣaṇamekabhujākārā kṣaṇaṃ bahubhujākulā |
anantograbhujākṣiptajagannartanamaṇḍapā
]

`v 22 [
kṣipramekamukhākārā kṣipraṃ bahumukhākṛtiḥ |
anantogramukhī kṣipraṃ nirmukhī cāpi ca kṣaṇam
]

`v 23 [
ekapādānvitā kṣipraṃ kṣipraṃ pādaśatānvitā |
kṣaṇaṃ cānantapādāḍhyā niṣpādākāriṇī kṣaṇam
]

`v 24 [
kālarātririyaṃ seti mayānumitadehikā |
kālī bhagavatī seyamitinirṇītasajjanā
]

`v 25 [
jvālāpūrṇāraghaṭṭograkhātābhanayanatrayā |
jvaladdharendranīlādrisānūpamalalāṭabhūḥ
]

`v 26 [
lokālokendranīlograśvabhrabhīmahanudvayā |
vātaskandhaguṇaprotatārāmuktākalāpinī
]

`v 27 [
indranīlādritulyoccatoraṇoccaiḥprabhāmbare |
viśrāntakācaśailābhabhagabhīṣaṇavāyasī
]

`v 28 [
nṛtyadbhujalatāpuṣpairnakhaśubhrābhramaṇḍalaiḥ |
pūrṇacandraśatānīva bhramayantī nabhastale
]

`v 29 [
bhramadbhirvyāptadikcakrā bhujaiḥ kalpāmbudairiva |
varṣadbhiḥ prāṇijaprāntatārālekhābṛhatprabhāḥ
]

`v 30 [
nakhapuṣpāṅgulīvallījālairbhrāntabhujadrumaiḥ |
kṛṣṇaiḥ kānanitāśeṣagaganāgrogramūrtibhiḥ
]

`v 31 [
tamālatālataḥ sthūlāṃ bhuvaṃ dagdhamahāvanaiḥ |
viḍambayantī valitāṃ jaṅghāsaṅghena lolatā
]

`v 32 [
apyanante mahāvyomni pāraṃ prāptaiḥ śiroruhaiḥ |
kurvāṇevātataṃ vāsaṃ carattimiradantinaḥ
]

`v 33 [
uhyante meravo yena tena niśvāsavāyunā |
ghanaghuṃghumadikcakragaganagrāmaghoṣiṇā
]

`v 34 [
ghanamārutaphūtkārakṣveḍageyaṃ pragāyatā |
niyatānunayeneva calitā sānuvṛttinā
]

`v 35 [
tato nṛttavaśāveśādvardhamānaśarīriṇī |
mayā dṛṣṭāvadhānena gaganābhogabhūriṇā
]

`v 36 [
yāvattayā''vṛtā dehe helāvalanasārayā |
mālā malayakailāsasahyamandaramerubhiḥ
]

`v 37 [
āsīttasyā yugāntābhramālikā paṭṭapaṭṭikā |
ādarśamaṇḍalānyaṅge trīṇi lokāntarāṇi ca
]

`v 38 [
karṇayorhimavanmerū rūpyakāñcanamudrike |
brahmāṇḍaghuṃghumairmālā mahatī kaṭimekhalā
]

`v 39 [
srajaḥ kulācalāḥ śṛṅgavanapattanagucchakāḥ |
jaratpuravanadvīpagrāmapelavapallavāḥ
]

`v 40 [
tasyā aṅgeṣu dṛṣṭāni purāṇi nagarāṇi ca |
ṛtavaśca trayo lokā māsāhorātramālikāḥ
]

`v 41 [
muktālatādikaṃ nadyaḥ kālindītripathādikāḥ |
dharmādharmāvubhau karṇabhūṣaṇe cānyakarṇayoḥ
]

`v 42 [
stanāstasyāstu catvāraḥ sravaddharmapayolavāḥ |
vedāḥ sakalaśāstrārthacatuḥsaṃsthānacūcukāḥ
]

`v 43 [
triśūlaiḥ paṭṭiśaiḥ prāsaiḥ śaraśaktyṛṣṭimudgaraiḥ |
niryadāyudhajālāni sragdāmāni vibharti sā
]

`v 44 [
caturdaśavidhā bhūtajātayo yāḥ surādikāḥ |
tasyāḥ śarīraśālinyāstā lomāvalayaḥ sthitāḥ
]

`v 45 [
tasyāśca nagaragrāmagirayo dehaśāyinaḥ |
nṛtyantyā saha nṛtyanti punarjanma mudeva te
]

`v 46 [
jaṅgamātmaikamevaitajjagadasthāvaraṃ tadā |
nṛtyatīti mayā jñātaṃ paraloke sukhaṃ sthitam
]

`v 47 [
nigīrṇaṃ jagadaṅgasthaṃ kṛtvā tṛptimupāgatā |
parinṛtyati sā mattā jagajjīrṇāhicātakī
]

`v 48 [
ādarśapratibimbasthamivābhātyakhilaṃ jagat |
tasyā vapuṣi vistīrṇe svarūpiṇi sarūpadhṛk
]

`v 49 [
sā na nṛtyati tatsarvaṃ saśailavanakānanam |
jagannṛtyati nānātma mṛtvā punarupāgatam
]

`v 50 [
kadācidanṛtyantyāmapi tasyāṃ tadantargataṃ jagannṛtyatīti mayā dṛṣṭamityāha ##-
tajjagannartanaṃ cāru taddehādarśasaṃsthitam |
ciraṃ mayā tadā dṛṣṭamavinaṣṭaṃ punaḥ sthitam
]

`v 51 [
vicalattārakājālaṃ bhramatparvatamaṇḍalam |
maśakavyūhavadvātavyādhūtāmaradānavam
]

`v 52 [
saṃgrāmonmuktacakrābhadvīpārṇavavṛtāmbaram |
helāvivalanāvartaprauḍhaśailadharātṛṇam
]

`v 53 [
nīlameghāṃśukāvṛttivātaghuṃghumitāmbaram |
kāṣṭhāsthyādisphuṭāsphoṭapaṭatpaṭapaṭāravam
]

`v 54 [
jagatpadārthairvyāmiśrairamiśrairmukurairyathā |
vyāptamābhogibhāṃkārairaṅgairaṅgabhramaistathā
]

`v 55 [
merurnṛtyati loloccakulācalabṛhadbhujaḥ |
bhramadabhrapaṭopetanamattanutanūruhaḥ
]

`v 56 [
atyajantaḥ samudrāśca maryādāmudraṇaṃ drumāḥ |
bhūmernabhastalaṃ yānti nabhaso yānti bhūtalam
]

`v 57 [
purāṇi ghargharārāvairdṛśyante luṭhitānyadhaḥ |
sagṛhāṭṭālavāstavyaṃ na ca kiṃcilluṭhatyadhaḥ
]

`v 58 [
vāstuṣuveśmabhūmiṣu bhavā vāstavyāstadantaiḥ sahitaṃ yathā syāttathā luṭhitāni | 57
|
tasyāṃ bhramantyāṃ caturaṃ candrārkadinarātrayaḥ |
nakhāgralekhālokāntarbhrāntikāñcanasūtravat
]

`v 59 [
vibhānti sṛṣṭayastasyā gharmāṇi jalajālikāḥ |
iva nīhārahāriṇyā nīlavāridavāsasaḥ
]

`v 60 [
khameva tasyāḥ saṃpannaṃ kabarīmaṇḍalaṃ bṛhat |
pātālaṃ caraṇau bhūmirudaraṃ bāhavo diśaḥ
]

`v 61 [
dvīpābdhayo'ntravalayaḥ pārśvakāḥ sarvaparvatāḥ |
prāṇāpānāvalīdolāḥ pavanaskandhaśālikāḥ
]

`v 62 [
dvīpā abdhayaśca antrasahitā valayaḥ saṃpannāḥ | āvahodvahapravahādayaḥ
pavanaskandhalakṣaṇā nabhaḥsaudhaśālikāstasyāḥ prāṇāpānāvalīdolāḥ saṃpannāḥ |
61 |
tadānubhūtaṃ nṛtyantyāstasyā vapuṣi vistṛte |
himavanmerusahyādyairdolanabhramamadribhiḥ
]

`v 63 [
taradadrigulucchāstā valayantyā tayā srajaḥ |
punaḥ kalpānta ārabdha iva tāṇḍavahelayā
]

`v 64 [
surāsuroragānīkaromaśāṅgaḥ śarīrakaḥ |
nispandaṃ sthātumaśakannasau bhramati cakravat
]

`v 65 [
nānāvibhavavijñānayajñayajñopavītinī |
sā sarantī nabhasyāsīdghanaghūtkāraghoṣiṇī
]

`v 66 [
tatra bhūtalamākāśamākāśamapi bhūtalam |
pratikṛti bhavatyantarna ca kiṃcidvivartate
]

`v 67 [
bṛhannāsāguhāgehanirgatā ghanaghuṃghumāḥ |
tatrogrā vāyavo vānti ghoraghūtkārakāriṇaḥ
]

`v 68 [
nabhaḥkaraśataistasvāścaturāvṛttivartibhiḥ |
bhāti caṇḍānilodbhūtairākīrṇamiva pallavaiḥ
]

`v 69 [
tadaṅgajajagadvastujātabhramaṇasaṃbhavāt |
dṛṣṭirdhīrāpi me mohe sannā seneva saṃgare
]

`v 70 [
prohyante  yantravacchailā nipatanti nabhaścarāḥ |
luṭhantyamaragehāni valite dehadarpaṇe
]

`v 71 [
meravaḥ parṇavadvyūḍhā malayāḥ pallavā iva |
himādrayo himakaṇā ivaurvyo'bjalatā iva
]

`v 72 [
sahyā mahyāmiva khagā vindhyā vidyādharā iva |
vṛkṣāvarte bhramanto'ntā rājahaṃsā ivāmbare
]

`v 73 [
dvīpānyapi tṛṇānīva samudrā valayā iva |
suralokālayaḥ padmā āsaṃstaddehavāriṇi
]

`v 74 [
viśadākāśasaṃkāśe svapnāñjanapuropame |
aṅge tasyā bṛhajjaṅge piṇḍādityasamatviṣi
]

`v 75 [
vindhyo nṛtyati kāñcanācalavane sahyaśca sahyo giriḥ kailāso malayo
mahendraśikharī krauñcācalo mandaraḥ |
gokarṇo gaganāṅgaṇe vasumatī vidyādharāṇāṃ puraṃ sarve jaṃgamatāṃ gatā
vanabhavastasyāḥ śarīre sadā
]

`v 76 [
abdhirnṛtyati parvate girirapi proccairnabhaḥkoṭare vyomāpīndudivākaraiḥ kva
calitaṃ bhūmeradhastādgatam |
sadvīpācalapattano vanagaṇaḥ protkīrṇapuṣpo divi vyālolaṃ jagadambudhāviva
tṛṇaṃ dikcakrake bhrāmyati
]

`v 77 [
vyomni bhramanti girayo'mbudhayo digante lokāntarāṇi purapattanamaṇḍalāni |
nadyaḥ sarāṃsi mukurāntariva pravṛddhavātāvakīrṇatṛṇavikramaṇakrameṇa |
77 |
tathā girayo vyomni bhramanti | ambudhayaśca digante bhramanti | purapattanamaṇḍalāni
nadyaḥ sarāṃsi ca svāśrayalokāllokāntarāṇi mukurāntariva praviśya pravṛddhena
vātenāvakīrṇānāṃ tṛṇānāṃ yāni vikramaṇāni uḍḍayanāni loke prasiddhāni
tatkrameṇa bhramantītyarthaḥ
]

`v 78 [
matsyāścaranti ca marau varavāriṇīva vyomni sthirāṇi nagarāṇi bhuvīva bhānti |
khe bhūdharā gaganasaṃkṣayavārivāhamutpātavātaparivṛttagiristhitaṃ tat
]

`v 79 [
ṛkṣotkaro bhramati dīpasahasrayantracakrakrameṇa maṇivarṣaṇavegacāruḥ |
antarbahiśca paritaḥ praṇayena muktaṃ vidyādharāmaragaṇairiva puṣpavarṣam |
79 |
kiṃ ca ṛkṣotkaro nakṣatrasamūho maṇīnāṃ varṣaṇavega iva cārurmanoharaḥ san
dīpasahasrāṇāṃ bhramanti yāni yantracakrāṇi tatkrameṇa bhūmerantarbahiśca bhramati |
yathā vidyādharāmaragaṇaiḥ praṇayena tvatsabhāyāṃ muktaṃ puṣpavarṣamantarbahiśca
bhramati tadvat
]

`v 80 [
saṃhārasarganicayā dinarātribhāge bindūpamā rajatayordivasotkarāśca |
kṛṣṇāḥ sitāśca parito'malaśuklakṛṣṇasvādarśamaṇḍalavadākulamullasanti |
80 |
kiṃ ca taddehe saṃhārāḥ pralayāḥ sarganicayāśca dinarātryorbhāge pakṣe ullasanti |
dinarātriprāyā alpā iti yāvat | tathā divasotkarā dinarātrisamūhāśca malināmalinayo
rajatayorbindūpamā atyalpā ullasanti | kṛṣṇāḥ sitāśca pakṣāḥ paritaḥ amalā ye
śuklāḥ kṛṣṇāśca vajrendranīlādinirmitāḥ śobhanā
ādarśāstanmaṇḍalavadullasantītyarthaḥ
]

`v 81 [
ratnāni bhāskaraniśākaramaṇḍalāni tārotkarāstaralamaṇḍalakāntihārāḥ |
svacchāmbarāṇi valitāni mahāmbarāṇi kurvantyanāratamanalpamalātalekhāḥ | 81
|
tathā taddehe bhāskaraniśākaramaṇḍalāni ratnāni saṃpannāni | tārotkarā
nakṣatrasamūhāstu taralā maṇḍalākārā kāntiryeṣāṃ tathāvidhā hārāḥ saṃpannāḥ |
svacchānyambarāṇyākāśāstu valitāni veṣṭitāni mahāntyambarāṇi vastrāṇi
saṃpannāni | teṣu bhramadvaidyutāgnyādayaḥ alātalekhā anāratamanalpaṃ prakāśaṃ
kurvantītyarthaḥ
]

`v 82 [
kalpāntakālaviluṭhattrijaganmaṇīni vyāvartanairjhagiri jātajhaṇajjhaṇāni |
tejāṃsi jhaṃkṛtatayordhvamadhaśca yānti nānāvidhāni guṇavanti vibhūṣaṇāni |
82 |
tannṛtye kalpāntakāle viluṭhat trijagadvyāvartanairjhagiti jhaṭiti jātajhaṇajjhaṇāni
maṇīni saṃpannāni | tathā jhaṃkṛtatayā jhaṃkāreṇa ūrdhvamadhaśca yānti
sūryāditejāṃsi nānāvidhāni guṇavanti nūpuravalayādivibhūṣaṇāni saṃpannānītyarthaḥ
]

`v 83 [
saṃgrāmamattabhaṭakhaḍgamarīcivīciśyāmāyamānasakalātapavāsarāṇām |
vyāvṛttibhirviluṭhatāmapi susthirāṇāmākarṇyate kalakalo janamaṇḍalānām | 83
|
kiṃcāparamatyāścaryam - saṃgrāmeṣu mattānāṃ bhaṭānāṃ
khaḍgaprabhāvīcibhiḥ śyāmāyamānasakalātapā vāsarā yeṣām | tathā devītāṇḍave
vyāvṛttibhirbhramaṇairviluṭhatāmapyadhiṣṭhānabrahmasthairyātsusthirāṇāṃ
vīrajanamaṇḍalānāṃ kalakalo mahāyuddhakolāhala ākarṇyate
]

`v 84 [
brahmendraviṣṇuharavahniravīndupūrvā devāsurāḥ parivivṛttibhirāpatantaḥ |
anye'nya eva vividhā upayānti yānti vātāvadhūtamaśakāśanivibhrameṇa
]

`v 85 [
saṃhārasargasukhaduḥkhabhavābhavehānīhāniṣedhavidhijanmamṛti##-
sārdhaṃ pṛthakca vilasanti sadaiva sarge vyāmiśratāmupagatā api tatra bhāvāḥ |
85 |
kiṃcāparamāścaryam - tatra tasyāḥ śarīre pratīyamāne sarge saṃhārasargādayaḥ
parasparaviruddhā api sarvabhāvāḥ parasparāsaṃsparśena sadā sārdhaṃ pṛthak ca
vilasanti | vyāmiśratāmupagatā api vilasantītyarthaḥ
]

`v 86 [
bhāvodbhavasthitivipatkaraṇabhramāṇāṃ saṃhārasargabhuvanāvanivibhramāṇām
|
mithyaiva khe prakacatāṃ khaśarīrakāṇāṃ saṃlakṣyate'tra na manāgapi nāma
saṃkhyā
]

`v 87 [
utpātaśāntimaraṇotsavayuddhasāmyavidveṣarāgabhayaviśvasanādi tatra |
ekatra kośa iva ratnacayo vibhāti nānārasāpratighasargaparamparaṃ tat
]

`v 88 [
tasyāścidambaramaye vapuṣi svabhāvabhūtāsphuṭānubhavabhāvajagadvyavasthāḥ |
sarvakṣayā malinadṛkkalitāmbarasthakeśoṇḍrakasphuraṇavatparitaḥ sphuranti |
88 |
kiṃ ca tasyāḥ paramārthataścidambaramaye vapuṣi svabhāvabhūtaḥ
aśāstrīyapratītisiddho yo māyāvaraṇalakṣaṇo'sphuṭānubhavabhāvastatprayuktā
jagadvyavasthāḥ sarvakṣayāśca paritastimirarogamalinadṛśā kalitāni
ambarasthakeśoṇḍrakasphuraṇānīva sphuranti
]

`v 89 [
jagatsaṃkṣubdhamakṣubdhaṃ dṛśyate sthitisaṃsthiti |
saṃcālyamānamukurapratibimba ivāsthitam
]

`v 90 [
nṛtyasphuratpratāpāntarjagadarthāḥ pratikṣaṇam |
sthitiṃ tyajanti gṛhṇanti bālasaṃkalpasargavat
]

`v 91 [
kriyāśaktiḥ śarīre'ntaḥ pūryamāṇā anāratam |
rāśībhūya viśīryante jaganmudgakaṇotkarāḥ
]

`v 92 [
kṣaṇamālakṣyate kiṃcinna kiṃcidapi sā kṣaṇam |
kṣaṇamaṅguṣṭhamātraiva kṣaṇamākāśapūriṇī
]

`v 93 [
yasmātsā sakalā devī saṃvicchaktirjaganmayī |
anantā paramākāśakośaśuddhaśarīriṇī
]

`v 94 [
kālatrayasthitajagattritayāntarī hi citsā tathā kacati tena yathāsthitena |
rūpeṇa citrakṛdudāramanaḥsthacitrasaṃsārajālasadṛśena kacajjavena
]

`v 95 [
sarvātmakaikavapurekacidātmakatvātsaṃśāntakhaikavapurekacidātmatattvāt |
evaṃ nimeṣaṇasamunmiṣitaikarūpaṃ sā bibhratī vapuranantamanādi bhāti
]

`v 97 [
tasyāṃ vibhāti tadanantaśilātmakośe lekhābjacakraracanādivadeva dṛśyam |
vyomātmakaṃ gaganamātraśarīravatyāṃ cittvāddravajjaladhikośa ivormilekhā | 96
|
vivartadṛśā pariṇāmadṛśā ca jīvanmuktānāṃ yauktikānāṃ ca tasyāṃ jagadbhāne
dṛṣṭāntadvayamāha - tasyāmiti | śilātra sphaṭikaśilā |
gaganamātraśarīravatyāmityantamādyadṛṣṭāntasya vivaraṇaṃ śiṣṭaṃ dvitīyasya | 96
|
mahatī bhairavī devī nṛtyantyāpūritāmbarā |
tasya kalpāntarudrasya sā puro bhairavākṛteḥ
]

`v 98 [
itthaṃ tasyāstannṛtyasya ca tattvamupavarṇya punastannatyamutprekṣādimirvarṇayati ##-
śiromandāśritogrāgnidagdhasthāṇuvanāvaniḥ |
kalpāntavātavyādhṛtā vanamāleva nṛtyati
]

`v 99 [
kuddālolūkhalabṛsīphalakumbhakaraṇḍakaiḥ |
musalodañcanasthālīstambhaiḥ sragdāmadhāriṇī
]

`v 100 [
evaṃvidhānāṃ sragdāmajālānāṃ kusumotkaram |
kirantī saṃsṛjantīva nṛttakṣubdhaṃ kṣaṃyakṣatam
]

`v 101 [
vandyamānastayā so'pi tathaivākāśabhairavaḥ |
tathaiva vitatākārastadoccaiḥ parinṛtyati
]

`v 102 [
ḍiṃbaṃ ḍiṃbaṃ suḍiṃbaṃ paca paca sahasājhamya jhamyaṃn prajhamyaṃ
nṛtyantī śabdavādyaiḥ srajamurasi śiraḥśekharaṃ tārkṣyapakṣaiḥ | pūrṇaṃ
raktāsavānāṃ yamamahiṣamahāśṛṅgamādāya pāṇau pāyādbo vandyamānaḥ
pralayamuditayā bhairavaḥ kālarātryā
]