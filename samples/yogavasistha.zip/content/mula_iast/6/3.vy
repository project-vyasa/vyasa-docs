`v 1 [
pdf 159, p. 1074
tṛtīyaḥ sargaḥ 3
śrīrāma uvāca |
avedanaṃ vedanasya munīndra kriyate katham |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ |
yadā tadaiva sukaraṃ vedanāvedanaṃ svayam
]

`v 3 [
etau vedanaśabdārthau rajjusarpabhramopamau |
asatyāvuditau viddhi mṛgatṛṣṇāmbhasā samau
]

`v 4 [
abodhastvanayoḥ śreyānbodho duḥkhāya `note[duḥkhāyate tayoḥ iti pāṭhaḥ |]
caitayoḥ |
tasmātsadeva buddhyasva mā'sadbuddhyasva rāghava
]

`v 5 [
jantorvedanaśabdārthabodho duḥkhakaraḥ paraḥ |
niṣkṛtya jñaptiśabdārthabodhaṃ tiṣṭha yathāsthitam
]

`v 6 [
sarvāvabodhāvasare jñaptiśabdārthayoriha |
nirvāṇodaya ityeva paramomiti śāmyatām
]

`v 7 [
śubhāśubhātmakarma svaṃ nāśanīyaṃ vivekinā |
tannāstītyavabodhena tattvajñānena sidhyati
]

`v 8 [
karmamūlanikāṣeṇa saṃsāraḥ pariśāmyati |
suvicāritamanviṣṭaṃ yāvatkarma na vidyate
]

`v 9 [
cidrūpo bilvamajjāntaścittasaṃjñāṃ yadātmani |
karoti tadyathā bilvānna svalpamapi bhidyate
]

`v 10 [
na yathā saṃniveśāntaḥ saṃniveśastataḥ pṛthak |
tathā nabhorthādi pṛthaṅ na parasmānmanāgapi
]

`v 11 [
yadevāmbhastadevāntardravatvamapṛthagyathā |
cittvameva tathā cittaṃ tadrūpatvāttadarthayoḥ
]

`v 12 [
yathā dravatvaṃ payasi yathā''lokaśca tejasi |
tathā brahmaṇyatadbhāvaṃ cittvaṃ cittaṃ ca vidyate
]

`v 13 [
cetanaṃ karma tatsvāntarnnirmūlaṃ bhramayakṣavat |
udetyahetukaṃ taccennoditaṃ tanna vidyate
]

`v 14 [
cetanaṃ karma taccetadbhāti spanda ivānilaḥ |
ahetukaṃ yadātmaitadbahiranta'sca sārthadhīḥ
]

`v 15 [
vistāraḥ karmaṇāṃ dehaḥ so'haṃtātmā sasaṃsṛtiḥ |
acetanānahantvena śāmyasyaspandavātavat
]

`v 16 [
acetanādanantātmā bhūtvā jño'pyupalopamaḥ |
saṃsāramūlakaṣaṇaṃ kuru kroḍamukhāgravat
]

`v 17 [
karmabījakalākośatyāga evaṃ kṛto bhavet |
nānyathā rāghavāntaste śāntamastu sadā sthitam
]

`v 18 [
karmabījakalātyāge tvetasmāditarātmani |
avidyamāne jīvasya tajjñairviditavastubhiḥ
]

`v 19 [
śāntairna gṛhyate kiṃcinna ca saṃtyajyate'pi ca |
tyāgādānena jānanti tatastaiḥ śāntamānasam
]

`v 20 [
ākāśaśūnyahṛdayairjñairyathāsthitamāsyate |
kriyate ca yathāprāptaṃ nāpyetaiḥ kriyatepi ca
]

`v 21 [
pravāhapatitaṃ sarvaṃ spandate śāntamānasam |
teṣāṃ karmendriyāṇyevamardhasaṃsuptabālavat
]

`v 22 [
rase nirvāsane labdhe rasā apyatinīrasāḥ |
nāntastiṣṭhanti na bahirajñānanipuṇā iva
]

`v 23 [
karmaṇo vedanaṃ tyāgaḥ sa ca siddhaḥ prabodhataḥ |
avastu netareṇārthaḥ kiṃ kṛtenākṛtena vā
]

`v 24 [
avedanamasaṃvedyaṃ yadavāsanamāsitam |
śāntaṃ samamanullekhaṃ sa karmatyāga ucyate
]

`v 25 [
apunaḥsmaraṇaṃ samyak ciravismṛtakarma `note[karmavaditi pāṭhaḥ |] tat |
sthitaṃ stambhodarasamaṃ sa karmatyāga ucyate
]

`v 26 [
atyāgaṃ tyāgamiti ye kurvate vyarthabodhinaḥ |
sā bhuṅkte tānpaśūnajñānkarmatyāgapiśācikā
]

`v 27 [
samūlakarmasaṃtyāgenaiva ye śāntimāsthitāḥ |
naiva teṣāṃ kṛtenārtho nākṛteneha kaścana
]

`v 28 [
samūlamalamuddhṛtya karmabījakalāmiti |
nityamekasamādhānāstajjñāstiṣṭhantyataḥ sukham
]

`v 29 [
pravāhapatite kārye īṣatspandā atanmayāḥ |
ghūrṇamānā iva kṣībā yantrasaṃcāritā iva
]

`v 30 [
mokṣalakṣmyā vilāsinyā vyasanopahatā iva |
ardhasuptaprabuddhābhāḥ kāmapyavanimāgatāḥ
]

`v 31 [
yatsamūlaṃ parityaktaṃ tattyaktamiti kathyate |
amūlakāṣastyāgo yaḥ sa śākhālavanopamaḥ
]

`v 32 [
pdf 160, p. 1076
akṛṣṭamūlaśākhāgralavanaḥ  karmapādapaḥ |
punaḥ śākhāsahasreṇa duḥkhāya parivardhate
]

`v 33 [
avedanātmanā tena karmatyāgo'ṅga sidhyati |
krameṇa netareṇāta etadevāharanbhava
]

`v 34 [
ye tvevaṃ karmasaṃtyāgamakṛtvānyatprakurvate |
atyāgaṃ tyāgarūpātma gaganaṃ mārayanti te
]

`v 35 [
bodhātmakatayā karmatyāgaḥ saṃpadyate svayam |
dagdhabījā niricchoccairakriyaiva bhavetkriyā
]

`v 36 [
buddhīndriyehitaṃ karma saphalaṃ rasabhāvanāt |
veṣṭitavyaṃn kudāmneva spando'nyo niṣphalo'ṅgajaḥ
]

`v 37 [
karmatyāge sthite bodhājjīvanmukto vivāsanaḥ |
gṛhe tiṣṭhatvaraṇye vā śāmyatvabhyetu vodayam
]

`v 38 [
gehamevopaśāntasya vijanaṃn dūrakānanam |
aśāntasyāpyaraṇyāni vijanā sajanā purī
]

`v 39 [
pariśāntamaterjñasya svapne'pyaprāptamānavā |
nirmalā vitatā hṛdyā hṛdyeva vanabhūmikā
]

`v 40 [
jñasya nirvāṇadṛśyasya nispandārthā nabhomayī |
śāntāśeṣaviśeṣārthā jagadeva mahāṭavī
]

`v 41 [
anantasaṃkalpavato hṛdayasthajagatsthiteḥ |
hṛdyevāvartate bhūmirajñasyākhilasāgarā
]

`v 42 [
janasyājñasya dīnasya vividhadvandvasaṃkaṭā |
sārambhā vividhākārā hṛdyeva grāmamaṇḍalī
]

`v 43 [
vividhakāryavikāradaśāmayī sapurapattanamaṇḍalaparvatā |
mukurakośa iva pratibimbitā hṛdi bhavatyamalā maline mahī
]