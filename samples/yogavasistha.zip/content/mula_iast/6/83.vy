`v 1 [
tryaśītitamaḥ sargaḥ 83
śrīvasiṣṭha uvāca |
cinmātraparamākāśa eṣa yaḥ kathito mayā |
eṣo'sau śiva ityuktastadā rudraḥ pranṛtyati
]

`v 2 [
cinmātrameva sa śivo na kālī bhairavākṛtiḥ |
bodhāya kalpanādṛṣṭyā tathā bhātīti varṇyate |
yāsau tasyākṛtirnāsāvākṛtiḥ kṛtināṃ vara |
taccinmātraghanaṃ vyoma tathā kacati tādṛśam
]