`v 1 [
saptatriṃśadadhikaśatatamaḥ sargaḥ 137
vyādha uvāca |
evaṃ cettanmune brūhi kīdṛgduḥkhaparikṣaye |
na karkaśo na ca mṛdurvyavahārakramo bhavet
]

`v 2 [
muniruvāca |
idānīmeva saṃtyajya dhanuṣā saha sāyakān |
maunamācāramāśritya śāntaduḥkhamihoṣyatām
]

`v 3 [
śrīvasiṣṭha uvāca |
iti saṃbodhitastena parityajya dhanuḥśarān |
āsīnmunisamācārastatraivāyācitāśanaḥ
]

`v 4 [
viveśa manasā maunī tataḥ śāstravivekitām |
dinaireva yathā puṣpamāmodena narāśayam
]

`v 5 [
apṛcchanmuniśārdūlaṃ kadācittamarindama |
bhagavandṛśyate svapnaḥ kathamantarbahiḥ sthitaḥ
]

`v 6 [
muniruvāca |
mamāpi sādho prathamameṣa eva vivekinaḥ |
purā citte vitarko'bhūtkuto'pyabhramivāmbare
]

`v 7 [
tata etaddidṛkṣārthamahamabhyastadhāraṇaḥ |
baddhapadmāsanastasyāṃ saṃvidyevābhavaṃ sthiraḥ
]

`v 8 [
tatrastho dūravikṣiptaṃ tayaivāhṛtavānaham |
cetaḥ svahṛdayaṃ sāyaṃ ruceva ravirātapam
]

`v 9 [
vedaneraṇayā prāṇastataścittānvito mayā |
śarīrādrecito bāhye saurabhaṃ kusumādiva
]

`v 10 [
vyomasthacittavalitaḥ sa prāṇapavano mayā |
agrasthasya mukhāgrasthe jantoḥ prāṇe niyojitaḥ
]

`v 11 [
yaḥ prāṇavalitaḥ prāṇastena nīto hṛdantaram |
svehayā svaṃ svakaḥ sarpaḥ karabheṇeva hiṃsitaḥ
]

`v 12 [
tato'haṃ hṛdayaṃ tasya praviṣṭaḥ prāṇavājinā |
saṃkaṭasthaḥ svayā buddhyā tāvevānusarontaram
]

`v 13 [
caradrasābhirbahvībhirnāḍībhirabhito vṛtam |
kulyābhiḥ sthūlatanvībhirbāhyade'samivākhilam
]

`v 14 [
parśukāpañjaraplīhayakṛdraktādiḍimbakaiḥ |
saṃkaṭaṃ jīvasadanaṃ bhāṇḍopaskaraṇairiva
]

`v 15 [
sarvaiḥ śalaśalāyadbhiruṣṇairavayavairvṛtam |
nidāghatāpasaṃtaptairūrmijālairivārṇavam
]

`v 16 [
navaṃ navaṃ bahiḥśaityaṃ nāsāgrāccetanātmakam |
jīvanāyāniśaṃ ceto vātonnītamanāratam
]

`v 17 [
raktakuṭṭarasaśleṣmavasāniḥsrāvapicchilam |
ghanāndhakāramuṣṇam ca saṃkaṭaṃ narakopamam
]

`v 18 [
udayāvayavāśleṣaspaṣṭāspaṣṭamarudrataiḥ |
sthityantānāṃ tu vaiṣamyādāgāmigadasūcakam
]

`v 19 [
daratsarabhasacchidrāvātavātena śabditam |
padmanālapraṇālāntarjvaladarṇavavāḍavam
]

`v 20 [
milatpadārthanīrandhraṃ sitamacchaṃ savāyubhiḥ |
kvacitsaumyaṃn kvacitkṣubdhaṃn corairiva puraṃ niśi
]

`v 21 [
rasanadaparairnāḍīmārgavidyādharādhvagaiḥ |
saṃcaradbhirvṛtaṃ vātairākārārdhārdhagītibhiḥ | 21 |
koṣṭhagatānāmannarasānāṃ nāde dhvanane tatparairata eva nāḍīmārgeṣu
gāyadvidyādharādhvagaprāyaiḥ saṃcaradbhirvātairvṛtam |
dvimātrāakārastadardhamekamātrastadardhordhamātraśca gītiṣu yeṣām | gītimātrasya
vātasādhyatvādit bhāvaḥ
]

`v 22 [
tadahaṃ hṛdayaṃ jantorāviśaṃ viṣamāntaram |
naro'vayavasaṃbādhaṃ naravṛndamivādhikaḥ
]

`v 23 [
anantaramahaṃ prāptastejodhātuṃ hṛdantare |
dūrasthamiva yatnena rātrāvindumivārkaruk
]

`v 24 [
yasmāttribhuvanādarśo dīpastrailokyavastuṣu |
sattā sarvapadārthānāṃ jīvastatrāvatiṣṭhate
]

`v 25 [
kāye sarvagato jīvaḥ svāmodaḥ kusume yathā |
tathāpyojasi kiñjalkairmukhe śaityaṃ vivasvatā
]

`v 26 [
tajjīvādhāramojastu praviṣṭo'hamalakṣitam |
rakṣitaṃ paritaḥ prāṇairvātaiḥ pracchādanaṃ yathā
]

`v 27 [
tato'ñjaḥ saṃpraviṣṭo'hamāmoda iva mārutam |
uṣṇāṃśuriva śītāṃśuṃ mṛtpātramiva vā payaḥ
]

`v 28 [
dvitīyendvaṃśusaṃkāśe śuklābhralavapelave |
navanītaguḍaprakhye kṣīrabudbudasundare
]

`v 29 [
tatra paśyāmyahaṃ tiṣṭhanpraveśavyagrayojjhitaḥ |
svaujasīva vasansvapna iva viśvamakhaṇḍitam
]

`v 30 [
pūrvasthāneṣviva praveśaprayuktayā vyagrayā śrāntyā ujjhitaḥ san svasya hṛdi sthite
ojasīva svastho vasan svīyasvapna iva tadīyasvapnarūpamakhaṇḍitaṃ viśvaṃ paśyāmi | 29
|
sārkaṃ saparvataṃ sābdhi sasurāsuramānavam |
sapattanavanābhogaṃ salokāntaradiṅmukham
]

`v 31 [
sadvīpasāgarāmbhodhi sakālakaraṇakramam |
sakalpakṣaṇasarvartu sahasthāvarajaṃgamam
]

`v 32 [
tatsvapnadarśanaṃ tatra sthirameva samaṃ sthitam |
vasāmyatyeva nidrānte nidrā'nte nāgatā yataḥ
]

`v 33 [
anidra eva kiṃ svapnaṃ paśyāmīti mayā tataḥ |
paricintayatā jñātamidaṃ vyādha vibodhinā
]

`v 34 [
nanu nāmāsya cidghātoḥ svarūpamidamaiśvaram |
svaṃ yadvyapadiśatyeṣa jagannāmnāmbarātmakam
]

`v 35 [
ciddhāturyatra yatrāste tatra tatra nijaṃ vapuḥ |
paśyatyeṣa jagadrūpaṃ vyomatāmeva cātyajat
]

`v 36 [
aho tvadyedamājñātaṃ yaditthaṃ dṛśyate jagat |
tatkathyate svapna iti svacitkacanamātrakam
]

`v 37 [
ciddhātoryatkhakacanaṃ tatkiṃcitsvapna ucyate |
kiṃcicca jāgradityuktaṃ jāgratsvapnau tu na dvidhā
]

`v 38 [
svapnaḥ svapno jāgarāyāmeṣa svapne tu jāgarā |
svapnastu jāgaraiveti jāgaraiva sthitā dvidhā
]

`v 39 [
cetanaṃ nāma puruṣaḥ sa mṛteṣu śateṣvapi |
śarīreṣu mahābuddhe kathaṃ kasya kadā mṛtaḥ
]

`v 40 [
taccetanaṃ khamevāsti sthitaṃ taddehavatkacat |
anantamavibhāgātma pratighāpratighātmakam
]

`v 41 [
svabhāvasyāpratighasya nityānantoditātmanaḥ |
paramāṇościdākhyasya majjā jagaditi smṛtaḥ
]

`v 42 [
cidvyomna udare bhānti samastānubhavāṇavaḥ |
tathā yathāvayavino vicitrāvayavāṇavaḥ
]

`v 43 [
nivṛtto bāhyato jīvo jīvādhāre hṛdi sthitaḥ |
rūpaṃ svaṃ svapnasargo'yamiti vetti cidākacān
]

`v 44 [
prathamatṛtīyapraśnau samāhitau dvitīyaṃ praśnaṃ samādhatte - nivṛtta iti |
bāhyato jāgarato jāgradbhogapradakarmoparame nivṛttaḥ san svaṃ rūpameva
bāhyasaṃskārānurodhena bāhyaḥ svapnasvargo'yamiti cidākacān cidvivartāneva vetti | 43
|
bāhyonmukhaṃ bahirjāgracchabditaṃ kacitaṃ svakam |
rūpaṃ paśyati jīvo'yamantasthaṃ svapna ityapi
]

`v 45 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
prasṛto jīva ityantarbahiścaikātmakaḥ sthitaḥ
]

`v 46 [
arko'rkabimbasaṃstho'pi yathehāpi sthitastviṣā |
tathā jīvo jagadrūpo bahirantaśca saṃsthitaḥ
]

`v 47 [
antaḥsvapno bahirjāgradahameveti vetti cet |
cidātmako yathābhūtaṃ mucyate tadavāsanaḥ
]

`v 48 [
acchedyo'yamadāhyo'yamapi jīvo'nyathā vadan |
dvaitasaṃkalpayakṣeṇa muhyatyeva śiśuryathā
]

`v 49 [
antarmukho'ntarātmānaṃ bahiḥ paśyabahirmukhaḥ |
āste jīvo jagadrūpaṃ yatsvante svapnajāgratī
]

`v 50 [
iti cintayataḥ kiṃ syātsuṣuptamiti me matiḥ |
jātā tena suṣuptāṃśamanveṣṭumahamudyataḥ
]

`v 51 [
yāvatkiṃ dṛśyadṛṣṭyāntastūṣṇīṃ tiṣṭhāmyahaṃ ciram |
niścitta iti saṃvittiḥ śamā nānyatsuṣuptakam
]

`v 52 [
nakhakeśādi dehe'sminviditāviditaṃ yathā |
na jaḍaṃ ca jaḍaṃ caiva suṣuptaṃ cetanātmani
]

`v 53 [
saṃvittyā kiṃ śramārto'smi śāntamāsevi mānasam |
ityekapariṇāmatvānnānyadasti suṣuptakam
]

`v 54 [
etannidrāghanaṃ jāgratyapi saṃbhavati svataḥ |
na kiṃciccintayābhyāse śānta ityekarūpakam
]

`v 55 [
jāgratyapi puruṣe etatsuṣuptakaṃ cintāparityāgadaśāyāṃ saṃbhavatītyāha - etaditi |
54 |
eṣāvasthā yadā yāti ghanatā mucyate tadā |
nidrāśabdena tanvī tu svapnaśabdena kathyate
]

`v 56 [
suṣuptamiti niścitya turīyānveṣaṇāmaham |
pravṛttaḥ kartumudyukto yuktaḥ paramayā dhiyā
]

`v 57 [
yāvadrūpaṃ turīyasya kiṃcanāpi na labhyate |
samyagbodhādṛte śuddhātprakāśastamaso yathā
]

`v 58 [
yathāsthitamidaṃ viśvaṃ samyagbodhādvilīyate |
yathāsthitaṃ ca bhavati na ca kiṃcidvilīyate
]

`v 59 [
ataḥ svapno jāgarā ca suṣuptaṃ ca turīyake |
sayathāsthitamastīdaṃ nūnaṃ nāsti ca kiṃcana
]

`v 60 [
kāraṇājjagadutpannaṃ na brahmetthamavasthitam |
jagattayā śāntamajaṃ bodha ityeva turyatā
]

`v 61 [
asaṃbhavātsaṃbhavakāraṇānāṃ na jāyate kiṃcana nāma sargaḥ |
ciccetanenaiva hi sargasaṃvit svayaṃ gṛhītā dravatāmbuneva
]