`v 1 [
aṣṭapañcāśaḥ sargaḥ 58
śrīrāma uvāca |
aho nu vitatodārā vimalā vipulācalā |
bhavatā bhagavanbhūtyai bhūyo dṛṣṭirudāhṛtā
]

`v 2 [
sarvathā sarvadā sarvaṃ sarvaṃ sarvatra sarvadā |
sadityeva sthitaṃ satyaṃ samaṃ samanubhūtitaḥ
]

`v 3 [
ayamasti mama brahmansaṃśayastaṃ nivāraya |
kimidaṃ bhagavannāma pāṣāṇākhyānamucyate
]

`v 4 [
śrīvasiṣṭha uvāca |
sarvatra sarvadā sarvamastīti pratipādane |
pāṣāṇākhyānadṛṣṭānto mayāyaṃ tava kathyate
]

`v 5 [
nīrandhraikaghanāṅgasya pāṣāṇasyāpi koṭare |
santi sargasahasrāṇi kathayeti pradarśyate
]

`v 6 [
bhūtākāśe mahatyasminkhaśūnyatvamanujjhati |
santi sargasahasrāṇi kathayeti pradarśyate
]

`v 7 [
antargulmāṅkurādīnāṃ prāṇivāyvambutejasām |
santi sargasahasrāṇi kathayeti pradarśyate
]

`v 8 [
śrīrāma uvāca |
kuḍyādau santi sargaughā iti cetkathyate mune |
tatkhe vibhānti sargaughā iti kiṃ na pradṛśyate
]

`v 9 [
śrīvasiṣṭha uvāca |
etatte varṇitaṃ rāma mukhyameva mayākhilam |
yo'yamālakṣyate sargaḥ sa kha eva khamāsthitam
]

`v 10 [
ādāveva hi notpannamadyāpi na ca vidyate |
dṛśyaṃ yaccāvabhātīdaṃ tadbrahma brahmaṇi sthitam
]

`v 11 [
nāsti bhūraṇumātrāpi sargairnirvivarā na yā |
na ca kvacana vidyante sargā brahmakhameva te
]

`v 12 [
āropadṛṣṭau tu pratibhūtaparamāṇu sarvamāropya draṣṭuṃ śakyam apavādadṛṣṭau
tu tadvaiparītyamityāśayenāha - nāstītyādinā | nirvivarā gāḍhabharitā yā na
tādṛśī aṇumātrāpi bhūrnāsti | sarvāpi sargabharitaivetyarthaḥ | evamagre'pi yojyam | 11
|
na tejaso'ṇurapyasti sargairnirvivaro na yaḥ |
na ca kvacana sargāste `note[vidyante sargā brahma iti pāṭhaḥ |] santi
brahmakhameva tat
]

`v 13 [
na vāyoraṇurapyasti sargairnirvivaro na yaḥ |
na ca kvacana vidyante sargā brahmakhameva tat
]

`v 14 [
khaṃ nāṇumātramapyasti sargairnirvivaraṃ na yat |
na kha kvacana sargāste santi brahmakhameva tat
]

`v 15 [
na sā mahābhūtatāsti sargairnirvivarā na yā |
na ca kvacana vidyante sargā brahmakhameva tat
]

`v 16 [
śailānāṃ nāṇurapyasti sa sargairyo na nirghanaḥ |
na ca kvacana vidyante sargā brahmakhameva tat
]

`v 17 [
brahmaṇo nāṇurapyasti sargairnirvivaro na yaḥ |
na ca kvacana sargāste santi brahmakhameva tat
]

`v 18 [
sargeṣu nāṇurapyasti na brahmātmaiva yaḥ sadā |
brahmasargāstathetyeṣa vāci bhedo na vastuni
]

`v 19 [
sargeṣu tatkṛteṣu bhuvanabhūtagrāmeṣu | tathā sati yatphalitaṃ tadāha - brahmeti |
18 |
sargā eva paraṃbrahma paraṃ brahmaiva sargatā |
manāgapyasti na dvaitamatrāgnyarkauṣṇyayoriva
]

`v 20 [
ime sargā idaṃ brahma te'tyantāvācyadṛṣṭayaḥ |
vidāryadāruravavadbhāntyarthaparivarjitāḥ
]

`v 21 [
dvaitamaikyaṃ ca yatrāsti na manāgapi tatra te |
sargabrahmādiśabdārthāḥ kathaṃ kasyeva bhāntu ke
]

`v 22 [
śāntamekamanādyantamidamacchamanāmayam |
vyavahāravato'pyaṅga jñasya maunaṃ śilāghanam
]

`v 23 [
nirvāṇamevamakhilaṃ nabha eva dṛśyaṃ tvaṃ cāhamadrinicayāśca
surāsurāśca |
tādṛgjagatsamavalokaya yādṛgaṅgasvapne'tha jantumanasi vyavahārajālam | 23
|
varṇitaṃ pāṣāṇākhyāyikātātparyamupasaṃharati - nirvāṇamiti | he aṅga rāma
tvaṃ jagattādṛksamavalokaya | atha jāgarānantaraṃ jantumanasi svapne dṛṣṭaṃ
yādṛgvyavahārajālamīṣatsmaryamāṇamapyātmamātraśeṣamityarthaḥ
]