`v 1 [
aṣṭapañcāśadadhikaśatatamaḥ sargaḥ 158
muniruvāca |
etatte kathitaṃ sarvaṃ bhaviṣyadbhūtavattava |
yathecchasi tathedānīṃ vyādha sādhu vidhīyatām
]

`v 2 [
agniruvāca |
iti tasya vacaḥ śrutvā vismayākulacetanaḥ |
kṣīṇaṃ sthitvā jagāmāśu snātuṃ vyādhastathā muniḥ
]

`v 3 [
iti tau ceratustatra tapaḥ śāstravicāraṇaiḥ |
akāraṇasuhṛdbhūtāvubhau vyādhamahāmunī
]

`v 4 [
athālpenaiva kālena munirnirvāṇamāyayau |
dehaṃ tyaktvā'padeśānte pare pariṇatiṃ gataḥ
]

`v 5 [
kālena bahunānyena tato yugaśatātmanā |
vyādhasya kāmanāṃ dātuṃ padmajanmā samāyayau
]

`v 6 [
vyādhaḥ svavāsanāveśaṃ nivārayitumakṣamaḥ |
jānannapi varaṃ pūrvaṃ varṇitaṃ samayācata
]

`v 7 [
brahmaivamastviti procya yayāvabhimatāṃ diśam |
vyādhastapaḥphalaṃ bhoktuṃ khagavadyoma pupluve
]

`v 8 [
vardhamānena dehena jagatpāre mahānabhaḥ |
vegādagaṇitaṃ kālaṃ pūrayāmāsa śailavat
]

`v 9 [
mahāgaruḍavegena tiryagūrdhvamadhastathā |
vyoma pūrayatastasya kālo bahutaro yayau
]

`v 10 [
atha dīrgheṇa kālena yadā vidyābhramasya saḥ |
antaṃ na samavāpnoti tatrodvegamupāyayau
]

`v 11 [
udvegādatha baddhvāsau prāṇarecanadhāraṇām |
prāṇāṃstatyāja nabhasi śavībhūtamadhovapuḥ `note[adhobhuvīti pāṭhe
vapurityadhyāhāryam |]
]

`v 12 [
cittaṃ prāṇānvitaṃ vyomni yayau tatraiva sindhutām |
vidūrathārirūpāṃ tāmakhilāvanipālinīm
]

`v 13 [
adeho meruśatākāramahāśava ivābhavat |
dvitīyorvīnibho vyomnaḥ papātāśanivajravat
]

`v 14 [
pidhānamiva kasyorvīvīthī kasmiṃścidambare |
keśoṇḍrakavadābhāte kasmiṃścijjāgate bhrame
]

`v 15 [
ākārapūritāśeṣavasudhācalamaṇḍalaḥ |
vipaścicchreṣṭha kathitametatte tanmahāśavam
]

`v 16 [
yasmiñchavaṃ saṃpatitaṃ jagatyavanimaṇḍale |
tadidaṃ jagadābhātamasmākaṃ svapnapūryathā
]

`v 17 [
tadetacchavamāsvādya śuṣkā pūrṇā mahodarī |
saṃpannā caṇḍikā devī raktā raktāntrapūritā
]

`v 18 [
medinī medinī jātā śavasyaitasya medasā |
pūritā'pūrvarūpeṇa himavadgirirūpiṇā
]

`v 19 [
tadaivaitanmahāmedo mṛddhātutvamupāgatam |
kālena vasudhā bhūyo bhūtvā mṛnmayatāṃ gatā
]

`v 20 [
bhūyaḥ prajātāni vanāni bhūmau grāmāḥ kṛtāḥ pattanasaṃyutāśca |
pātālataḥ sādhusamutthitāste śailāḥ pravṛttā vyavahāralakṣmīḥ
]