`v 1 [
ṣaṭcatvāriṃśaḥ sargaḥ 46
śrīvasiṣṭha uvāca |
paramārthaphale jñāte muktau pariṇatiṃ gate |
bodho'pyasadbhavatyāśu paramārtho manomṛgaḥ
]

`v 2 [
kvāpi sā mṛgatā yāti prakṣīṇasnehadīpavat |
paramārthadaśaivāste tatrānantāvabhāsinī
]

`v 3 [
dhyānadrumaphalaprāptau bodhatāmāgataṃ manaḥ |
vajrasārāṃ sthitiṃ dhatte chinnapakṣa ivācalaḥ
]

`v 4 [
manastā kvāpi saṃyāti tiṣṭhatyacchaiva bodhatā |
nirbādhā nirvibhāgā ca sarvā'kharvātmikā `note[sarvātmikā ityapyubhayatra
pāṭhaḥ |] satī
]

`v 5 [
suviviktatayā cittasattā bodhatayoditā |
anādyantā bhavatyacchaprakāśaphaladāyinī
]

`v 6 [
svayameva tatastatra nirastasakalaiṣaṇam |
anādyantamanāyāsaṃ dhyānamevāvaśiṣyate
]

`v 7 [
yāvannādhigataṃ brahma na viśrāntaṃ pare pade |
tāvattanmananatvena na dhyānamavagamyate
]

`v 8 [
paramārthaikatāmetya na jāne kva mano gatam |
kva vāsanā kva karmāṇi kva harṣāmarṣasaṃvidaḥ
]

`v 9 [
kevalaṃ dṛśyate yogī gato dhyānaikaniṣṭhatām |
sthito vajrasamādhāne vipakṣa iva parvataḥ
]

`v 10 [
virasākhilabhogasya praśāntendriyasaṃvidaḥ |
nīrasāśeṣadṛśyasya svātmārāmasya yoginaḥ
]

`v 11 [
krameṇa vigaladvṛtterbalādviśrāntimīyuṣaḥ |
arthāyātaṃ samādhānaṃ kena nāma vicāryate
]

`v 12 [
tāvadviṣayavairasyaṃ bhāvayantyucitāśayāḥ |
na paśyantyeva tānyāvadbhogāṃścitranaro yathā
]

`v 13 [
tasya paravairāgyamapyarthasiddhamityāha - tāvaditi | citranaraścitralikhitānpuruṣān |
12 |
apaśyañjāgatānarthānnirvāsanatayātmavān |
balādvajrasamādhāne tvanyeneva niveśyate
]

`v 14 [
prāvṛṣīva nadīpūro yaḥ samādhirupasthitaḥ |
balādeva tamāyātaṃ bhūyaścalati no manaḥ
]

`v 15 [
sarvārthaśītalatvena balāddhyāne yadā''gatam |
jñānādviṣayavairasyaṃ sa samādhirhi netaraḥ
]

`v 16 [
dṛḍhaṃ viṣayavairasyameva dhyānamudāhṛtam |
tadeva paripākena vajrasāraṃ bhavatyalam
]

`v 17 [
tadetadbhogavaitṛṣṇyaṃ dhyānamaṅkuritaṃ hi tat |
tadeva pīṭhabandhena baddhaṃ bhavati bandhuram
]

`v 18 [
samyagjñānaṃ samucchūnaṃ sadaivojjhitavāsanam |
dhyānaṃ bhavati nirvāṇamānandapadamāgatam
]

`v 19 [
asti cedbhogavaitṛṣṇyaṃ kimanyaddhyānadurdhiyā |
āsti cedbhogavaitṛṣṇyaṃ kimanyaddhyānadurdhiyā
]

`v 20 [
dṛśyasvadanamuktasya samyagjñānavato muneḥ |
nirvikalpaṃ samādhānamavirāmaṃ pravartate
]

`v 21 [
yasmai na svadate dṛśyaṃn sa saṃbuddha iti smṛtaḥ |
na svadante yadā bhogāḥ samyagbodhastathoditaḥ
]

`v 22 [
yasya svabhāvaviśrāntiḥ kathaṃ tasyāsti bhogitā |
asvabhāvo hi bhitvaṃ tatkṣaye tatkathaṃ kutaḥ
]

`v 23 [
śrutapāṭhajapānteṣu samādhinirato bhavet |
samādhivirataḥ śrāntaḥ śrutapāṭhajapāñchrayet
]

`v 24 [
nirvāṇamāsīta nirastakhedaṃ samastaśaṅkāstamayābhirāmam |
suṣuptasaumyaṃ samaśāntacittaṃ śaraddhanābhogaviśuddhamantaḥ
]