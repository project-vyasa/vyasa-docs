`v 1 [
ṣoḍaśādhikaśatatamaḥ sargaḥ 116
anucarā ūcuḥ |
deva paśyātra saṃgrāmalagnasīmāntabhūbhṛtām |
kacanti hetisaṃghātā visaranti balāni ca
]

`v 2 [
hatānhatānabhimukhānvīrānvīraiḥ sahasraśaḥ |
āropyāropya khaṃ yānti paśya paśyāṅganārathaiḥ
]

`v 3 [
vijigīṣo punaḥ prāpte saṃkaṭe prakaṭe raṇe |
dharmyaṃ virājate yuddhaṃ yauvane surataṃ yathā
]

`v 4 [
lokairaninditā lakṣmīrārogyaṃ śrīsamanvitam |
dharmyaṃ yuddhaṃ parārthena jīvitasyottamaṃ phalam
]

`v 5 [
avirodhena dharmasya yuddhe saṃmukhamāgatam |
yodhānurūpaṃ yo hanti śūraḥ svargyaḥ sa netaraḥ
]

`v 6 [
hastasthitāsivaranīlasarojadāmaśyāmo hayotthaghanareṇuniśāgamo'tra |
ālokaya kramaṇameṣa kathaṃ karoti pronnāmahetibharabhūṣaṇabhāji lakṣmyāḥ | 6
|
he rājan pronnāmā udyatā hetibharā eva bhūṣaṇāni tadbhāji asmin śūrapuruṣe eṣa
saṃgrāmalakṣmyā hastasthitāsivaralakṣaṇena nīlasarojadāmnā śyāmo
hayotthaghanareṇukṛto'ndhakāralakṣaṇo niśāgamo'trāsyāṃ saṃgrāmabhūmaukathaṃ
kramaṇaṃ karoti | kiṃ lakṣīrenamasyāṃ niśi svayaṃvarevṛṇīte uta neti kautukaṃ
paśyetyarthaḥ
]

`v 7 [
ete kacanti śaraśaktigadābhuśuṇḍīśūlāsikuntapaṭutomaracakrapūrṇāḥ |
tāpāḥ satāṇḍavakacapracale cale'bdhau dehena valgati bhuvīva phaṇīndrasaṃghāḥ |
7 |
śaraśaktyādyāyudhaiḥ pūrṇā ete yodhāḥ satāṇḍavakacaprāyatṛṇadārupracale acale
parvate prajvalitāstāpā davāgnaya iva kacanti | teṣu ca śaraśaktyādisaṃghāḥ abdhau
dehena valgati sati tatratyāḥ phaṇīndrasaṅghāḥ bhuvi prasūtā iva kacanti
]

`v 8 [
paśyāmbaraṃ balavadambudharābdhipūrṇaṃ paśyāmbaraṃ
taralatārakatārahāram |
paśyāmbaraṃ sughanasaktamasaikasāraṃ paśyāmbaraṃ
viśadacandrakarāvasiktam
]

`v 9 [
yatrānekasurāsurāspadaghaṭā tārāpadeśaṃ gatā ṛkṣāṇāṃ ca yadāspadaṃ
visaratāṃ sarvonnatānāṃ ca yat |
tasmiñchūnyamiti pratītiradhunāpyastaṃ gatā nāmbare ko'nyo mārjayituṃ
jano'jñaracitaṃ lokāpavādaṃ kṣamaḥ
]

`v 10 [
meghāṭopaiḥ
pralayadahanairadripakṣābhighātaistārāpūrairamaraditijakṣubdhasaṃgrāma##-
vyomādyāpi prakṛtivikṛtiṃ nāma nāyātyasaṃkhyairantaḥ
sārāśayaguṇavatāṃ lakṣyate no mahimnaḥ
]

`v 11 [
āndolayasyaviralaṃ gaganārkamaṅkenārāyaṇaṃ ca śaśinaṃ ca tathetarāṇi |
tejāṃsi bhāsurataḍitprabhṛtīni sādho citraṃ tathāpi na jahāsi yadāndhyamantaḥ |
11 |
he sādho gaganatvamaviratamarkaṃ nārāyaṇaṃ cakārāttatparijanānsarvāndevān
śaśinaṃ cakārādanyān grahāṃstathā itarāṇi bhāsurataḍitprabhṛtīni tejāṃsi ca aṅke
āndolayasi tathāpyantaryadāndhyaṃ tamaḥ śyāmikālakṣaṇaṃ tanna jahāsi
citramāścaryamityarthaḥ
]

`v 12 [
ākāśa kāśasi tu yatra śaśāṅkabimbaṃ tvatkīrṇakajjalatamo malino'sitatvam |
saṅgānna yannayasi tatkhalu citramuccaiḥ ko nāma vāntaramalaṃ malinīkaroti
]

`v 13 [
pūrṇasyāpi jagaddoṣaiḥ sarvadaivāvikāriṇaḥ |
khasya manye budhasyeva sukhaṃ sarvārthaśūnyatā
]

`v 14 [
kalpābhradrumavīrudunnatidṛśāṃ kartāsi dhartāsi ca
ākāśendughanārkakinnaramarutskandhāmarāṇāmapi |
sarvaṃ ramyamasaṃkulāśaya samasvacchasvabhāvasya te
yattvetaddahanatvamaṅga tadaho mukhyāya khedāya naḥ
]

`v 15 [
ākāśa kāśamasi nirmalamacchamuccairādhāra unnatatayottamamuttamānām |
tvāmetva kiṃtu viaralaṃ karakāghano'yaṃ lokaṃ vimardayati tena paro'si nīcaiḥ | 15
|
he ākāśa tvaṃ nirmalamacchaṃ `note[meghādyāvaraṇaśūnyam |] kāśaṃ
bhāsvaraṃ unnatatayā uttamānāṃ devādīnāmuttamamādhāraścāsi kiṃtu viralaṃ
sāvakāśaṃ tvāmetya āśritya ayaṃ karakāvarṣī ghano lokaṃ janaṃ vimardayati tena
taddoṣeṇa paraḥ nīcaiḥ atyantamapakṛṣṭo'sītyarthaḥ
]

`v 16 [
ākāśa karṣakaṣa eva nikarṣaṇaṃ te manye ciraṃ samacitaṃ na tu kiṃcidanyat |
śūnyo'si yajjaladhararkṣavimānacandrasūryānilānvahasi bhāsi na cārthaśūnyaḥ |
16 |
he ākāśa te tava svarṇavatkarṣakaṣe karṣakaṣaṇasthāne nikaṣopala eva nigharṣaṇaṃ
ciramucitam | na tvanyatkiṃcittvatparīkṣāsthānamityarthaḥ | yadyasmāttvaṃ śūnyo'si
tathāpi jaladharān ṛkṣāṇi vimānāni candraṃ sūryamanilāṃśca vahasi bhāsi
arthaśūnyo niṣprayojanaśca na cāsīti tava sakalakanakaguṇaśālino guṇaparīkṣārthamapi
tadguṇaparīkṣāsthānasyaivaucityāditi bhāvaḥ
]

`v 17 [
ahni prakāśamasi raktavapurdinānte yāmāsu kṛṣṇamatha cākhilavasturiktam |
nityaṃ na kiṃcidapi sadvahasīti māyāṃ na vyoma vetti viduṣo'pi viceṣṭitaṃ te
]

`v 18 [
akiṃcano'pi kāryāṇi sādhayatpātatāśayaḥ |
antaḥśūnyamapi vyoma sarvasyonnatikāraṇam
]

`v 19 [
na tṛṇasalilaṃ naiva grāmo na nāma ca pattanaṃ na ca
dalabharasnigdhacchāyastarurna ca satprapā |
tadapi gaganādhvānaṃ sūryaḥ prayāti dine dine viṣamamapi yatprārabdhaṃ
tattyajanti na sāttvikāḥ
]

`v 20 [
yāmā dhvāntapaṭena śītalaruciḥ karpūrapūraiḥ karairarkālokanavāṃśukena
divasastāraughapuṣpotkaraiḥ |
dyaurambhodatuṣāravārikusumaiḥ sarvartavo bhūṣayantyete
kālakalātmanostribhuvane vyomāṅgaṇaṃ nāthayoḥ
]

`v 21 [
dhūmābhrareṇutimirārkaniśeśasaṃdhyā tārāvimānagaruḍādrisurāsurāṇām |
kṣobhairapi prakṛtimujjhati nāntarikṣaṃ citrotthitā sthitiraho na mahāśayasya | 21
|
mahāśayasya sthitiścitrā āścaryarūpā utthitā unnatā dṛśyate yato'ntarikṣaṃ
dhūmādīnāṃ trayodaśānāṃ kṣobhairapi prakṛtiṃ pūrvāvasthāṃ nojjhati
]

`v 22 [
digbhittibaddhamidamūrdhvatalāntarikṣamurvītalaṃ ghanapurācalabhūribhāṇḍam |
vidyādharāmaramahoragajālakāraṃ lokaughasaṃsaraṇasaṃghapipīlikāḍhyam
]

`v 23 [
kālaḥ kriyā ca bhuvanaṃ bhavanaṃ cirāya nāmādhitiṣṭhata ivopavanaṃ vikāsi |
āśaṅkyate pratidinaṃ nanu naṣṭameva nādyāpi naśyati ca keyamaho nu māyā | 23
| (yugalakam |)
īdṛśamidaṃ bhuvanaṃ bhavanaṃ kālaḥ kriyā ceti dampatī cirāya nāma adhitiṣṭhataḥ
pālayataḥ | yathā mālākāradampatī vikāsi upavanamadhitiṣṭhatastadvat | yadyapi
kālakriyābhyāṃn nādhiṣṭhīyate pratidinaṃ nanu naṣṭamevāśaṅkyate tathāpi nādyāpi
naśyati cakārānnaśyati catathāpi pravāheṇānuvartata eva | evaṃ naśyadapi na naśyatīti
viruddhadharmakatvādaho nu māyā | indrajālasadṛśametadityarthaḥ | tathā ca śrutiḥ
kasmāttāni na kṣīyante adyamānāni sarvadā iti | puruṣo vā akṣitiḥ sa hīdamannaṃ dhiyā
dhiyā janayate karmabhiḥ iti
]

`v 24 [
khaṃ manye pādapādīnāṃ rodhayatyadhikonnatim |
akartureva mahato mahimnodeti kartṛtā
]

`v 25 [
jagatāṃ yarta lakṣāṇi na bhavantyudbhavanti ca |
tacchūnyamucyate vyoma dhikpāṇḍityamakhaṇḍitam
]

`v 26 [
vyomanyeva pralīyante vyomataḥ prodbhavanti ca |
gacchatonmattatāmetāmīśvarānyabhidā kṛtā
]

`v 27 [
āyānti yānti nipatanti tathotpatanti sargaśriyaḥ kaṇaghaṭā iva pāvakotthāḥ |
yatrāmalaṃ tadahamekamanādimadhyaṃ manye khameva na tu
kāraṇamīśvarākhyam
]

`v 28 [
ādhāramāyatataraṃ trijaganmaṇīnāmaṅge bibhartyamitamantaraśeṣavastu |
vyomaiva cidvapurahaṃ parameva manye yatrodayāstamayameti jagadbhramo'yam | 28
|
amitaṃ yadaśeṣavastu aṅge bibharti trijaganmaṇīnāmāyatataramādhāraṃ tadvyomaiva
cidvapuḥ paraṃ brahmaivetyahaṃ manye
]

`v 29 [
vanāvanau vanacaracāarukāminā manoharadrumagahaneṣu gīyate |
ito gireḥ śirasi vilokyate'munā viyoginā pathi vahatā rasākulam
]

`v 30 [
gītaṃ śṛṅgatarūccapallavapuṭe niḥśvasya sotkaṇṭhayā kaṃṭhāśliṣṭagirā
viyogahatayā vidyādharāṇāṃ striyā |
yannāmātra tadeṣa nātha pathikaḥ socchvāsamākarṇayan dolāndolanayeva
cañcaladhiyā no yāti nonūcyate
]

`v 31 [
gāyatyadriśirastarau dalapuṭe niḥśvasya vidyādharī kākalyā'tilakaṃ viyogavidhurā
bāṣpākulaiṣā puraḥ |
nāthotsaṅgagṛhe gṛhītacibukaṃ smeraṃ bhavaccumbanaṃ smṛtvāsvādya
rasāyanaṃ hatasamā nītā mayaitā iti
]

`v 32 [
asyāḥ prāgbhavasatpatiḥ sa muninā śāpena vṛkṣīkṛto varṣadvādaśakaṃ
tadeva gaṇayantyeṣaiva sātra sthitā |
gāyatyutkalitā tadeva dayitaṃ taṃ pādapaṃ saṃśritā mārge mārgavihāriṇāṃ
vadanato rājanmamaitacchrutam
]

`v 33 [
paśyaiṣa so'smadavalokanaśāntaśāpo vidyādharo viṭapitāmavamucya bālām |
kaṇṭhekaroti viṭapākṛtivipralambhaistaireva bāhubhiralaṃ sphuṭapuṣpahāsaḥ |
33 |
sa ca munirasmaddarśanameva śāpāntamakarodataḥ sa eṣa vṛkṣabhūto
vidyādharo'smadavalokanādeva śāntaśāpaḥ san viṭapitāmavamucya bālāṃ tāṃ
vidyādharīṃ viṭapākṛtivyājaistaireva bāhubhiḥ sphuṭapuṣpāṇyeva hāsatvena
saṃpannāni yasya tathāvidhaḥ san āliṅgya kaṇṭhekaroti paśya
]

`v 34 [
śikhariṇāṃ kariṇāṃ kusumotkaro viṭapiṣu sphuṭaromasu rājate |
gaganavicyutatārakalīlayā śikharameṣa tuṣārasamānayā
]

`v 35 [
mīnāvalīsarabhasaplutighaṭṭitāmbuvīcīvilolaviruvatkurarīkarālā |
kāveryaho kusumaśuklapaṭā'vabhāti niḥśaṅkaraṅkukulasaṃkulakūlakacchā |
35 |
aparaḥ kāverīṃ varṇayati - mīneti | mīnāvalīnāṃ
sarabhasaplutibhirghaṭṭitāsvambuvīciṣu vilolābhiḥ krīḍantībhirviruvatībhiḥ kurarībhiḥ
karālā kusumaśuklapaṭā niḥśaṅkairaṅkubhirmṛgabhedaiḥ saṃkulāḥ kūlāni
kacchā jalaprāyadeśāśca yasyāstathāvidhā kāverī avabhāti | aho ityāścarye
]

`v 36 [
bhātyatra paśya raviṇā kaṭake suvelaśailasya kāñcanaśilā sakalāmalaśrīḥ |
velāvalolavaruṇālayavīcibhaṅgaparyastavāḍavakṛśānukaṇopamānā
]

`v 37 [
āsannapīnajaladāvalitālayānāṃ gehopaśalyapariphullavanadrumāṇām |
lakṣmīḥ palāśapaṭalāvalitāmbarāṇāṃ ghoṣaukasāṃ samavalokaya parvateṣu | 37
|
tathā parvateṣu āsannaiḥ pīnairjaladairāvalitālayānāṃ gehopaśalyeṣu gṛhasīmānteṣu
pariphullavanadrumāṇāṃ tathā palāśapaṭalairāvalitāmbarāṇāṃ
ghoṣaukasāmābhīrapallīgṛhāṇāṃ lakṣmīḥ samavalokaya
]

`v 38 [
unnidrapuṣpapaṭupāṇḍurapuṣpakhaṇḍā
mandārabhāṇḍaviśikhaṇḍikaraṇḍakacchāḥ |
grāmāḥ prapātajalajālavilāsavādyā valgadguhāgahanagītajanā jayanti
]

`v 39 [
unnidrakandaladalāntaralīyamānakūjanmadāndhamadhuponmadapāmarāṇām |
manye na sā bhavati tuṣṭirihāmarāṇāṃ yā gokuleṣu girigahvariṇāṃ narāṇām
]

`v 40 [
bhṛṅgāvadolitalatākulakānanāntargāyatpulindadayitānanadattanetram |
līlākulā gataghṛṇaṃ girigahvareṣu kiṃ ghnanti śatrumiva mugdhamṛgaṃ
kirātāḥ
]

`v 41 [
nānāvikāsikusumotkarasāralabdhavallīdalāvalanaśītalitādhvagāṅgāḥ |
sāmbhaḥprathaprasaraṇena tarattaraṅgā grāmā girīndragahaneṣu jayanti candram
]

`v 42 [
kūjannirjaravārayaḥ parisaratpronnidratāladrumā
helollāsitapuṣpapallavavaladvallīvitānāmbarāḥ |
paryantonnatasālalambijaladā ramyā girigrāmakāścandrāśvatthamitāvaniṃ
śaśipurasyodyānabhāgā iva
]

`v 43 [
āsannapītaghanaghargharameghanādanṛtyacchikhaṇḍinavatāṇḍavaviprakīrṇaiḥ |
grāmāḥ kalāpikulakomalabarhakhaṇḍaiḥ proḍḍīnacandrakamaṇiprakarā jayanti |
43 |
kiṃcaite girigrāmā āsannāḥ pītā vidyuto yeṣāṃ tathāvidhānāṃ ghanaghargharāṇāṃ
meghānāṃ nādairnṛtyatāṃ śikhaṇḍināṃ navatāṇḍaveṣu viprakīrṇaiḥ
kalāpikulānāṃ komalairbarhakhaṇḍaiḥ proḍḍīnāścandrakalakṣaṇā maṇiprakarā yeṣu
tathāvidhāḥ santo jayanti prāguktamityarthaḥ
]

`v 44 [
pārśvasthacāruśaśimaṇḍalamaṇḍaneṣu viśrāntavāriguruvāridavāraṇeṣu |
grāmeṣu yā giritaṭeṣu vilāsalakṣmī rājyeṣu sā vibhavavatsu kuto viriṃce
]

`v 45 [
svāmodanandanavanāntarasundareṣu saṃtānakastabakahāsinikuñjakeṣu |
unnidramandramadhupākulapāribhadrasāndradrumeṣvabhirame girigahvareṣu
]

`v 46 [
hariṇīrāvaramyeṣu hārihārītahāriṣu |
girigrāmeṣu puṣpeṣupureṣviva ratirnṛṇām
]

`v 47 [
sphāṭikastambhasaṃbhāraramyanirjharavāriṇi |
nṛtyantyetāḥ śikhaṇḍinyaḥ paśyāsmingrāmagahvare
]

`v 48 [
śikhaṇḍinyo vilāsinyaḥ puṣpabhāranatā latāḥ |
atra nṛtyanti kuñjeṣu raṇanirjharapuṣkare
]

`v 49 [
raṇanti dhvananti nirjharapuṣkarāṇi nirjharajalāni yasmiṃstathāvidhe atra grāmagahvare |
48 |
hārītahāriharitopavanadrumāsu vāpīpramāṇaraṇitāmalakākalīṣu |
grāmasthalīṣu girigahvaragopitāsu manye mudaiṣa ramate svarasena kāmaḥ
]

`v 50 [
śrīmadvṛttamahāśayātapaharaproccairgabhīrākṛte bhūbhṛnmūrdhasu
bhūṣaṇaṃ bhavasi bho bhūme rasaikāspadam |
etattu kṣapayenmanāṃsi yadidaṃ megha tvayā varṣatā
harṣādūṣarapalvalasthalataruṣvambhovibhāgakramaḥ
]

`v 51 [
nityaṃ snāsi sutīrthavārivisarairuccaiḥpadastho'mbudaḥ
śuddhaḥ sanvipināvanau nivasasi prārabdhamaunavrataḥ |
riktasyāpyatikāntireva bhavataḥ kāyāśrayā lakṣyate protthāyāśanimātanoṣi
kimidaṃ tucchaṃn tavāceṣṭitam
]

`v 52 [
vastvasthānagataṃ sarvaṃ śubhamapyaśubhaṃ bhavet |
durmeghaṃ sthānamāsādya vāri tvasitatāṃ gatam
]

`v 53 [
aho nu meghena jalaṃ vimuktamaho nu toyena vipūritā bhūḥ |
aho nu bhūmau paripoṣitaśca jalairdhanāḍhyaiḥ praṇayīva dīnaḥ
]

`v 54 [
nairghṛṇyamasthairyamathāśucitvaṃ rathyācaratvaṃ parikutsitatvam |
śvabhyo gṛhītaṃ kimu nāma mūrkhairmūrkhebhya evātha śunā na jāne
]

`v 55 [
guṇaiḥ katipayaireva bahudoṣo'pi kasyacit |
upādeyo bhavatyeva śauryasaṃtoṣabhaktibhiḥ
]

`v 56 [
unmattamattapatanonmukhadhāvamānamānādhikānviṣayavīthiṣu dattamūrtiḥ
`note[atra muktamūrtiḥ iti pāṭhaḥ |] |
yanmanyate tṛṇalavāgra vilokayecchāsattvaṃ jaḍatvamuta vāsya vicāryatāṃ tat |
56 |
viṣayavīthiṣu bhogaparamparāsu dattamūrtiḥ prasaṃjitaśarīro viṣayalampaṭo mūrkho
dhattūrādibhakṣaṇenonmattānmadirādinā mattānpramādakrodhāveśādinā
kūpādipatanonmukhānpiśācādyāveśena dhāvamānāṃstattvajñānaprakarṣeṇa
dehādiparicchedavismaraṇādahaṃ brahmeti sarvotkṛṣṭapramāṇapratiṣṭhānācca
mānādhikānṣaṣṭhādibhūmikārūḍhāṃśca svābhijñatāropeṇa yattṛṇaṃ manyate | he
tṛṇalavāgra tat tvameva vilokaya | asya viṣayalampaṭasya icchāsattvamuta vā jaḍatvamiti
tadrahasyaṃ vicāryatām | yadīcchāsattvaṃ tarhi sa eva śvabhistulyaḥ | yadi jaḍatvaṃ tarhi
tṛṇalavāgrādapi viṣayalāmpaṭyādidoṣādhikyāttato'pi svayaṃ nīca iti tṛṇasāmyamapi
tasya durlabhataramiti vicāre phaliṣyatīti unmattādibhyo nīcatvaṃ tasya kiṃ
vācyamityarthaḥ
]

`v 57 [
kolāhalaḥ samāne'pi tiryaktve kṣubdhamānasaiḥ |
anyathā sahyate siṃhairmīlitairanyathā śvabhiḥ
]

`v 58 [
nityāśuce priyajane bhaṣaṇaikaniṣṭha rathyāntarabhramaṇanītasamastakāla |
kauleyakāśayasamānatayaiva manye mūrkheṇa kenacidaho bata śikṣitosi
]

`v 59 [
nityaṃ sarvaṃ jagadasadṛśaṃ kurvatoccairvidhātrā dauhitre'smiñchuni
samadṛśe nirmitaṃ sarvameva |
vāso'medhyāvakarakuhare bhojanaṃ gūthapūyaṃ sarvāloke kuratikuratiḥ
sarvanindyaṃ śarīram
]

`v 60 [
tvattaḥ ko'dhama ityudīritavate śvovāca hāsānvitaṃ matto
maurkhyamamedhyamāndhyamaśubhaṃ yaḥ sevate sodhikaḥ |
śauryaṃ bhaktirakṛtrimā dhṛtiriti śrīmānguṇo yosti me mūrkhādeṣa guṇaḥ
prayatnanicayairanviṣya no labhyate
]

`v 61 [
bhuṅkte'medhyamamedhya eva ramate nityaṃ mahāvaskare tūṣṇīmatti sacetanaṃ
kṛtaratirniścetanaṃ kṛntati |
sarvairetya rate śunīvivalite loṣṭairjanaistāḍyate dhātrā khelasamanvitasthitiralaṃ
loke kṛto neśvaraḥ
]

`v 62 [
liṅgasyordhvaṃ raṭatkāka ātmānaṃ darśayatyayam |
sarvādhaḥpātakottuṅgagataṃ paśyata māmiti
]

`v 63 [
kākaka kaṭukalkārava kabalitaguṇakardame bhramansarasi |
antarayasi madhuparavaṃ yadato me śirasi phalabhūtaḥ
]

`v 64 [
kavalayati narakanikaraṃ pariharati mṛṇālikāṃ dhvāṅkṣaḥ |
yadato'stu mā smayaste svabhyastaṃ sarvadā svadate
]

`v 65 [
vividhavanakusumakesaradhvalavapurhaṃsa iva dṛṣṭaḥ |
kākaḥ kṛmikulakavalaṃ klinnamatho kavalayan jñātaḥ
]

`v 66 [
tulyavarṇacchadaiḥ kṛṣṇaḥ saṃgataiḥ kila kokilaiḥ |
kena vijñāyate kākaḥ svayaṃ yadi na bhāṣate
]

`v 67 [
araṇyānyā mṛdaḥ sthāṇau sthitaḥ kāko nirīkṣate |
caityāddaśadiśaścoro niśi supte jane yathā
]

`v 68 [
sarabhasasārasavidalatpuṣkaramakarandasundare sarasi |
kathamiha viharati kākaḥ sphuradavakaranikaradhūsaraskandhaḥ
]

`v 69 [
hā kaṣṭamiṣṭavapuṣi sphuṭapuṇḍarīkakośe kaṣāhananayogyamukhaḥ piśācaḥ |
paśyaiṣa kāka upaviśya kupalvale'smin līlāḥ karoti vididhāḥ saha rājahaṃsaiḥ | 69
|
sphuṭānāṃ vikasitānāṃ puṇḍarīkaṇāṃ kośe iṣṭavapuṣi abhimatasvarūpe sarasi sthitai
rājahaṃsaiḥ saha eṣaḥ kaṣantīti kaṣāḥ śilāstābhirāhananayogyaṃ mukhaṃ yasya
tathāvidhaḥ kākaḥ piśācaḥ asmin kupalvale upaviśya rājahaṃsaviḍambanāya vividhā
līlāḥ karoti hā kaṣṭaṃ he rājan tvaṃ paśya
]

`v 70 [
he kāka karkaśarava krakacaikacihna tādṛksvaśaṅkanamapi kva nu te'dya yātam
|
kasmādanarthakamidaṃ pikapākamekaputrāśayā tadapi te hyupahāsasiddhyai
]

`v 71 [
ālokya paṅkajavane savilāsavantaṃ kākaṃ kalaṅkasadṛśaṃ
bhṛśamāraṭantam |
hā kaṣṭaśabdaśatanaṣṭaviceṣṭito yo no roditi krakacakena vidāryatāṃ saḥ
]

`v 72 [
viśarāruśarārumaye bakamadgughane ca palvale capalāḥ |
syuryadi kauśikakākāstatsyādeṣā samanvitā goṣṭhī
]

`v 73 [
kokilaḥ kākasaṃghātaiḥ samasaṃvaraṇākṛtiḥ `note[samavarṇānanākṛtiḥ iti
pāṭhaḥ |] |
gaditairvyaktatāmeti sabhāyāmiva paṇḍitaḥ
]

`v 74 [
mṛdukusumāṅkuradalanaṃ soḍhumalaṃ kokilasya kusumalatā |
na tu kaṅkagṛdhramadgukabakakukkuṭavāyasādīnām
]

`v 75 [
śrotrotsavaṃ tava kalaṃ kalakaṇṭha ko'tra nādaṃ śṛṇoti
rativigrahasaṃdhidūtam |
kākairulūkakalahairiha gulmakeṣu kreṃkāragharghararavaiḥ śrutirāgatāstam
]

`v 76 [
vācākomalayā sukokilaśiśuḥ kalyāṇakalpāṃ kathāṃ sarvāvarjanamārjavena
kurute yāvatpuro rāgiṇām |
tāvanmattanayo'yamityavirataṃ drāṃkārabhīmāravairdhvāṅkṣeṇopavane nipatya
nabhasaḥ sarve kṛtā nīrasāḥ
]

`v 77 [
kiṃ kiṃ kokila kūjasi drutaravaṃ harṣātsamullāsitaṃ grīvākoṭarataḥ praveśaya
punarmā bhūcciraṃ te bhramaḥ |
uhāmaiḥ kusumairnirantarataraṃ nedaṃ madhorjṛmbhitaṃ hemaṃtena
kṛtāstuṣāranikaraiḥ śuṣkā amī pādapāḥ
]

`v 78 [
kūjatkokila komalaṃ kalaravairnityaṃ praśastākṛte kenedaṃ bata śikṣitosi
vacanaṃ duḥkhapradaṃ durbhagam |
caitre citranavāṅkure virahiṇī vakti tvayā yātmanaḥ kasyāyaṃ madhurityatastava
tavetyuktaṃ tvaroccaistaroḥ
]

`v 79 [
maunaspandavihāravarṇavapuṣāṃ sāmye'pi kākavraje'kākaḥ kokila eṣa kāntiruciro
dūrātparijñāyate |
madhye mūrkhajanasya paṇḍita iva svākārabhavyakriyaḥ sarvo hi prathimānameti
sadṛśasvāntaścamatkārataḥ
]

`v 80 [
bhrātaḥ kokila kūjitairalamalaṃ nāyātyanarghyo guṇastūṣṇīmāsva
viśīrṇaparṇapaṭalacchanne kvacitkoṭare |
uddāmadrumakandare kaṭuraṭatkākāvalīsaṃkulaḥ kāloyaṃ śiśirasya saṃprati
sakhenāyaṃ vasaṃtotsavaḥ
]

`v 81 [
citraṃ mātarameṣa kokilaśiśuḥ saṃtyajya kākīṃ gataḥ saiṣenaṃ tudatīti
yāvadahamapyācintayāmi kṣaṇam |
tāvatso'pi tathāśu mātṛsadṛśaṃ śliṣṭo rasādvardhituṃ yāmāyāti diśaṃ
svabhāvasubhagaḥ saivāsya māhātmyadā
]