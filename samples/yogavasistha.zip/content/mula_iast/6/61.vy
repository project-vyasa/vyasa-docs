`v 1 [
ekaṣaṣṭitamaḥ sargaḥ 61
śrīvasiṣṭha uvāca |
cidākāśāccidākāśe payasīva payorayāḥ |
cittvājjīvāḥ sphurantyete eta `note[yata iti pāṭhaḥ |] eva manāṃsi naḥ
]

`v 2 [
viśadākāśarūpāṇi tānyeva ca manāṃsi naḥ |
jaganti tānyanantāni saṃpannānyabhitaḥ svayam
]

`v 3 [
śrīrāma uvāca |
sarvabhūtagaṇe mokṣaṃ mahākalpakṣaye gate |
punaḥ kasya kathaṃ sargasaṃvittirupajāyate
]

`v 4 [
śrīvasiṣṭha uvāca |
mahāpralayaparyante kṣitijalapavanahutāśākāśāśeṣaviśeṣavināśe
ābrahmasthāvarānteṣu muktau pariṇateṣu bhūyo yathedaṃn jagadanubhūyate tathā
śṛṇu | avyapadeśyaṃn yatparamārthaghanaṃn brahma cinmātramityācakṣate
munayaḥ tasya hṛdayamidaṃ jagattasmādavyatiriktameva sa eva ca
devastadātmīyaṃ hṛdayaṃ svabhāvaṃ jagadityavagacchati ca vinodenaiva na tu
vāstavena rūpeṇa jagaditi kiṃcidupalabhāmahe vicārayantastasmātkimiva naśyate
kimiva jāyate yathā paramakāraṇamavināśi tathā taddhṛdayamavināśyaṃ ca |
mahākalpādayaśca tadavayavā eva aparijñānamātramatra kevalaṃ bhedāyaiva
tadapi prekṣyamāṇaṃ na labhyata eva
]

`v 5 [
tasmānna kasyacitkiṃcitkadācinnaśyati kvacit |
na caiva jāyate brahma śāntaṃ dṛśyamajaṃ sthitam
]

`v 6 [
ākāśaparamāṇusahasrāṃśamātre'pi yā śuddhacinmātrasattā vidyate
]

`v 7 [
vapurjagadidaṃ tasyā nanu nāma mahāciteḥ |
kathaṃ naśyatyanaṣṭāyāṃ tasyāṃ sā ca na naśyati
]

`v 8 [
saṃvido hṛdayaṃ svapne yathā bhāti jagattayā |
vyomātmaiva tathaivādisargātprabhṛti bhāsate
]

`v 9 [
saṃviddhṛdayatvaṃ ca saṃvinmātrasāre svapne'pi prasiddhamityāha - saṃvida iti | 8
|
cidvyomāvayavaḥ sargaḥ sargasyaitādṛśāḥ kṣayāḥ |
udayāśceti khaṃ sarvaṃ kiṃ nāśi kimanāśi ca
]

`v 10 [
eṣā hi paramārthasaṃvidacchedyā adāhyā'kledyā'śoṣyatā sā
hyatadvidāmadṛśyā tasyā yaddhṛdayaṃ tattadeva bhavati yathāsau na naśyati
tadantarvartī jagadādyanubhavo na jāyate na naśyatyeveti kevalaṃ
smaraṇavismaraṇavaśena svabhāvarūpeṇānubhavānanubhavau kalpayatīva
]

`v 11 [
yadyadyadātmakaṃ tattvaṃ tadvināśaṃ vinā'kṣayi |
tasmādbrahmātmakaṃ dṛśyaṃ viddhi brahmavadakṣayam
]

`v 12 [
mahāpralayādayastadavayavā eva
]

`v 13 [
cinmātre parame vyomni kuta eva bhavābhavau |
kuto bhāvavikārādiḥ kathaṃ vyomni nirākṛte
]

`v 14 [
mahākalpādayo bhāvā nāmaitāni jaganti ca |
brahmātmakatayaivāsminsaṃvidbrahmaṇi saṃsthitam
]

`v 15 [
nirākṛtyacchacinmātraṃ dṛśyaṃ saṃkalpya tadvaśam |
yāti yenaiva ghaṭito yakṣastaddhṛdaye kila
]

`v 16 [
yathāvayavino vṛkṣasya śākhāviṭapaphalapallavapuṣpādayo'vayavāstathā
paramārthaghanasyākāśādapyaccharūpasyāvyapadeśyasya
pralayamahāpralayanāśodbhedabhāvābhāvasukhaduḥkhajananamaraṇasākāra##-
ta iti
]

`v 17 [
avayavāvayavinordṛśyayorvāpyadṛśyayoḥ |
ekātmanoreva sadā bhedo'sti na kadācana
]

`v 18 [
yathā taroḥ saṃvinmūlaṃ tathā paramārthaghanasya kvacitkiṃcittvaṃ
kvacitsargastambaḥ kvacillokāntaraviṭapāḥ kvacidvyavasthāḥ śākhāḥ
kvacitpadārthapallavāḥ kvacitprakāśakusumam kvacidandhakārakārṣṇyaṃ
kvacinnabhaḥkoṭaraṃ kvacitpralayagulmāḥ kvacinmahāpralayagulmāḥ
kvaciddhariharādigulucchakāḥ kvacijjāḍyatvak evamanākāraṃ vyomarūpameva
saṃvidātmani brahmaṇi brahmasadṛśabhāvādavyatiriktamevaitatsthitam
]

`v 19 [
ito bhāvya ito bhāva itaḥ sarga itaḥ kṣayaḥ |
svabhāva evānubhava iti brahmācalaṃ sthitam
]

`v 20 [
evaṃmaye'pi parame brahmākāśe na rañjanāḥ |
kāścidevāṅga santīndubimbe vimalatā yathā
]

`v 21 [
nirmale paramākāśe kva bhāvābhāvarañjanāḥ |
kvādimadhyāntakalanāḥ kva lokāntaravibhramāḥ
]

`v 22 [
aparijñānamevaikaṃ tatra doṣavadutthitam |
kevalaṃ tatparāvṛtya prekṣaṇātpariśāmyati
]

`v 23 [
ajñānaṃ jñaptibodhena parāmṛṣṭaṃ praṇaśyati |
yenaivābhyuditastena pavaneneva dīpakaḥ
]

`v 24 [
ajñānaṃ saṃparijñātaṃ nāsīdeveti budhyate |
abandhamokṣaṃ brahmaiva sarvamityavagamyate
]

`v 25 [
evaṃ bodhādayo rāma mokṣa uktāḥ svasaṃvidā |
vicārayatno labhate nātra kaścana saṃśayaḥ
]

`v 26 [
idaṃ jagajjālamanādyajātaṃ brahmārthamābhātamitīha dṛṣṭvā |
vicāradṛṣṭyā'ṣṭaguṇeśvaratvaṃ paśyaṃstṛṇaṃ svātmani jīva āste
]