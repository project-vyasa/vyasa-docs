`v 1 [
ṣaṇṇavtyadhikaśatatamaḥ sargaḥ 196
śrīvālmīkiruvāca |
evamuktvā mahābuddhe rāmo rājīvalocanaḥ |
muhūrtamātraṃ viśramya tūṣṇīṃ sthitvā pare pade
]

`v 2 [
paramāṃ tṛptimāpanno viśrāntaḥ paramātmani |
muniṃ punarapṛcchattaṃ jānannapi hi līlayā
]

`v 3 [
śrīrāma uvāca |
bhagavansaṃśayāmbhodaśaratkāla munīśvara |
idānīṃ saṃśayo'yaṃ me jāto manasi pelavaḥ
]

`v 4 [
evametanmahājñānaṃ saṃsārārṇavatāraṇam |
samastameva vāgjālaṃ samatītyāvatiṣṭhate
]

`v 5 [
yadidaṃ kila sadbrahma svasaṃvinmātraniścayam |
tadavācyaṃ kila girāṃ mahatāmapi mānada
]

`v 6 [
evaṃ sthite paraṃ jñeyaṃ sarvasaṃkalpanojjhitam |
svasaṃvitturyatanmātralabhyaṃ durgamatāṃ gatam
]

`v 7 [
pratiyogivyavacchedasaṃkhyābhedaiṣiṇāṃ kila |
kathaṃ śāstrapadaistucchaiḥ savikalpairavāpyate
]

`v 8 [
vikalpasāraśabdādyairjñānaṃ śāstrairna labhyate |
tatkimarthamanarthāya guruśāstrādi kalpitam
]

`v 9 [
guruśāstrādivijñāne kāraṇaṃ vāstyakāraṇam |
tadatra niścayaṃ brahmanbrūhi me vadatāṃ vara
]

`v 10 [
śrīvasiṣṭha uvāca |
evametanmahābāho na śāstraṃ jñānakāraṇam |
nānāśabdamayaṃ śāstramanāma ca paraṃ padam
]

`v 11 [
tathāpi rāghavaśreṣṭha yathaitaddhetutāṃ gatam |
śāstrādyuttamabodhasya tatsamāsena me śṛṇu
]

`v 12 [
santi kvacidvaivadhikāḥ kīrakāściradurbhagāḥ |
duḥkhenābhyāgatāḥ śoṣaṃ grīṣmeṇeva jaraddrumāḥ
]

`v 13 [
dāridryeṇa durantena kanthāsaṃsthānakāriṇā |
dīnānanāśayāḥ padmā nirgateneva vāriṇā
]

`v 14 [
daurgatyaparitaptāste jīvitārthamacintayan |
jaṭharasya kayā yuktyā vayaṃ kurmaḥ prapūraṇam
]

`v 15 [
iti saṃcintya vidhinā dināntena dinaṃ prati |
dārubhāreṇa jīvāmo vikrīteneti saṃsthitāḥ
]

`v 16 [
iti saṃcintya te jagmurdārvarthaṃ vipināntaram |
yayaivājīvyate yuktyā saivāpadi virājate
]

`v 17 [
iti te pratyahaṃ gatvā kānanaṃ bhavacāriṇaḥ |
dārūṇyānīya vikrīya cakrurdehasya dhāraṇam
]

`v 18 [
yatprayānti vanāntaṃ te tasminsantyakhilāni hi |
guptāguptāni ratnāni dārūṇi kanakāni ca
]

`v 19 [
teṣāṃ bhārabhṛtāṃ madhyātkecitkatipayairvanāt |
jātarūpāṇi ratnāni tāni saṃprāpnuvanti hi
]

`v 20 [
keciccandanadārūṇi kecitpuṣpāṇi mānada |
kecitphalāni vikrīya jīvanti cirakīrakāḥ
]

`v 21 [
kecitsarvamanāsādya durdāruṇyeva durdhiyaḥ |
nītvā vikrīya jīvanti vanavīthyupajīvinaḥ
]

`v 22 [
dārvarthamudyatāḥ sarve te saṃprāpya mahāvanam |
kecitprāpya sthitāḥ sarve jhaṭityevaṃ gatajvaram
]

`v 23 [
iti yāvadajasraṃ te sevante tanmahāvanam |
pradeśāttāvadekasmātprāptaścintāmaṇirmaṇiḥ
]

`v 24 [
tasmāccintāmaṇeḥ prāptāḥ samagrā vibhavaśriyāḥ |
paramaṃ sukhamāyātāstatra te saṃsthitāḥ sukham
]

`v 25 [
dārvarthamudyatāḥ santaḥ prāpya sarvārthadaṃ maṇim |
sukhaṃ tiṣṭhanti nirdvandvā divi devavarā iva
]

`v 26 [
sarvārthasāraparipūrṇatayā tayā te kāṣṭhodyamādhigatasanmaṇayo mahāntaḥ |
tiṣṭhanti śāntabhayamohaviṣādaduḥkhamānandamantharadhiyaḥ samatāmupetāḥ
]