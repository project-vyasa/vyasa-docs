`v 1 [
ekacatvāriṃśaḥ sargaḥ 41
śrīvasiṣṭha uvāca |
asvabhāvasvabhāvo'yaṃ sarvo'haṃtādivedanaḥ |
svabhāvaikasvabhāvena nirvāṇīkriyatāṃ svayam
]

`v 2 [
trijagatputrikānṛtyamasvabhāvasvabhāvataḥ |
svabhāvaikasvabhāvena nirvāṇaṃ cātra varṇyate |
asvabhāvo'vidyā tatsvabhāvo'yamātmā sarvajagadrūpaḥ
sannahaṃtādivakṣyamāṇatrijagatputrikānṛtyaṃn vettītyahaṃkārādivedanaḥ saṃpannaḥ
| evamanirvāṇo'yamātmā svayaṃ
śāstrīyopāyaprabhavavidyāvirbhūtenādvitīyasvaprakāśapūrṇānandalakṣaṇa##-
yatrādityo bhavettatra yathālokastathā bhavet |
paraṃ viṣayavairasyaṃn tatra yatra prabuddhadhīḥ
]

`v 3 [
akartṛkarmakaraṇamadṛśyadraṣṭṭadarśanam |
jagadagrāhyasaṃbhāramabhittau citramutthitam
]

`v 4 [
tatra vairāgyārthamavidyāsvabhāvācchuddhe jagaccitrādhyāsaṃ varṇayati - akartriti |
3 |
na cotthitaṃ kiṃca na vā śānte śāntaṃ yathāsthitam |
anāmayaṃ paraṃ brahma satyamavyayameva tat
]

`v 5 [
ciccamatkāramātrātmakalpanāraṅgarañjanāḥ |
saṃkhyātuṃ kena śakyante khe jagaccitraputrikāḥ
]

`v 6 [
rasabhāvavikārāḍhyaṃ nṛtyantyabhinayairnavaiḥ |
paramāṇuprati prāyaḥ khe sphurantyambarātmikāḥ
]

`v 7 [
rasaiḥ śṛṅgārādibhirbhāvaiḥ sthāyibhāvairvikāraiḥ kampasvedādisaṃcāribhāvaiḥ
āḍhyaṃ yathā syāttathā | abhinayaistattadvastvākāravyañjakaceṣṭābhiḥ | paramāṇuprati
paramāṇumātrāsvapi vidyamāne khe cidākāśe | prāya iti saṃbhāvitatvadyotanārthaḥ | 6
|
sarvartuśekharadharā digbāhulatikākulāḥ |
pātālapādalatikā brahmalokaśirodharāḥ
]

`v 8 [
candrārkalolanayanāstārotkaratanūruhāḥ |
saptalokāṅgalatikāḥ paritocchāmbarāmbarāḥ
]

`v 9 [
dvīpāmburāśivalayā lokālokādrimekhalāḥ |
bhūtabhāracalajjīvapravahatprāṇamārutāḥ
]

`v 10 [
vanopavanavinyāsahārakeyūrabhūṣitāḥ |
purāṇavedavacanāḥ kriyāphalavinodanāḥ
]

`v 11 [
trijagatputrikānṛtyaṃn yadidaṃ dṛśyate puraḥ |
brahmavāridravatvaṃ tattadbrahmānilavepanam
]

`v 12 [
asvabhāvasthitaivāsya kāraṇaṃ kāraṇātmakam |
asuṣuptaṃ sthitā svāpe svapnasyeva satīva sā
]

`v 13 [
asuṣuptasuṣuptasthaḥ svabhāvaṃ bhāvayanbhava |
jāgratyapi gatavyagro mā svapnamidamāśraya
]

`v 14 [
yajjāgrati suṣuptatvaṃ bodhādarasavāsanam |
taṃ svabhāvaṃ vidustajjñā muktistatpariṇāmitā
]

`v 15 [
akartṛkarmakaraṇamadṛśyadraṣṭṭadarśanam |
arūpālokamananaṃn sthitaṃ brahma jagattayā
]

`v 16 [
kānte kāntaṃ prakacati pūrṇe pūrṇaṃ vyavasthitam |
dvitvaikyarahite bhāti dvitvaikyaparivarjitam
]

`v 17 [
satyaṃ satye sthitaṃ śāntaṃn sargātmanyātmani svayam |
ākāśakośasadṛśaṃ śilājaṭharasaṃnibham
]

`v 18 [
suratnajaṭharākāraṃ ghanamapyambaropamam |
pratibimbamiva kṣubdhamapyakṣubdhamasacca sat
]

`v 19 [
bhaviṣyannavanirmāṇaṃ cetasīva sthitaṃ puram |
brahma bṛṃhitabhārūpamabhedīkṛtamānasam
]

`v 20 [
yathā saṃkalpanagaraṃ saṃkalpānnaiva bhidyate |
tathāyaṃn jagadābhāsaḥ paramārthānna bhidyate
]

`v 21 [
hemapīṭhamivānekabhaviṣyatsaṃniveśavat |
lakṣyamāṇamapi sphāraṃ śāntamavyayamāsthitam
]

`v 22 [
hemapīṭhaṃ pīṭhavaccaturasro hemapiṇḍaḥ | sphāraṃ nānāvistāraṃ lakṣyamāṇamapi |
21 |
ajasranāśotpādāḍhyamekarūpamanāmayam |
anāśotpādamajaramanekamiva kāntimat
]

`v 23 [
brahmaiva śāntighanabhāvagataṃ vibhāti sargodayena vigatāstamayodayena |
vyomeva śūnyavibhavena galatsvabhāvalābbhaṃn prati prasabhameva nanu
prabuddhe
]