`v 1 [
pañcāśaḥ sargaḥ 50
śrīvasiṣṭha uvāca |
ime ye jīvasaṃghātā dṛśyante daśa diggatāḥ |
naranāgasurāgendragandharvādyabhidhānakāḥ `note[(deva) (bhūta)
iti cedvaraṃ |]
]

`v 2 [
te svapnajāgarāḥ kecitkecitsaṃkalpajāgarāḥ |
kecitkevalajāgratsthāścirājjāgratsthitāḥ pare
]

`v 3 [
ghanajāgratsthitāścānye jāgratsvapnāstathetare |
kṣīṇajāgarakāḥ kecijjīvāḥ saptavidhāḥ smṛtāḥ
]

`v 4 [
śrīrāma uvāca |
eteṣāṃ bhagavanbhedo bodhāya mama kathyatām |
jīvānāṃ saptarūpāṇāṃ jalānāmarṇaveṣviva
]

`v 5 [
śrīvasiṣṭha uvāca |
kasmiṃścitprāktane kalpe kasmiṃścijjagati kvacit |
kecitsuptāḥ sthitā dehairjīvā jīvitadharmiṇaḥ
]

`v 6 [
ye svapnamabhipaśyanti teṣāṃ svapnamidaṃ jagat |
viddhi te hi khalūcyante jīvikāḥ svapnajāgarāḥ
]

`v 7 [
kvacideva prasuptānāṃ yaḥ svapnaḥ svayamutthitaḥ |
viṣayaḥ so'yamasmākaṃ teṣāṃ svapnanarā vayam
]

`v 8 [
teṣāṃ ciratayā svapnaḥ sa jāgrattvamupāgataḥ |
svapnajāgarakāste tu jīvāste tadgatāḥ sthitāḥ
]

`v 9 [
sarvajñatvātsarvagasya sarvaṃ sarvatra vidyate |
yena svapnavatāṃ teṣāṃ vayaṃ svapnanarāḥ sthitāḥ
]

`v 10 [
śrīrāma uvāca |
yeṣu kalpeṣu te jātāḥ kṣīyante kalpakalpanāḥ |
yadi tāstatkathaṃ teṣāṃ prabuddhānāmavasthitiḥ
]

`v 11 [
śrīvasiṣṭha uvāca |
iha svapnabhramānte te mucyante vā vinidratām |
prāpya saṃkalpato dehāṃstathaivānyānśrayantyalam
]

`v 12 [
tathaivānyaṃprapaśyanti jagatkalpaṃ ca kalpitam |
kalpanābhāsanabhaso na hi saṃkaṭatā bhavet
]

`v 13 [
saṃkalpanātmakajagajjīrṇodumbarakīṭakāḥ |
svapnajāgarakāḥ proktāḥ śṛṇu saṃkalpajāgarān
]

`v 14 [
kasmiṃścitprāktane kalpe kasmiṃścijjagati kvacit |
anidrālava evāntaḥ saṃkalpaikaparāḥ sthitāḥ
]

`v 15 [
dhyānādviluṭhitā vātha manorājyavaśānugāḥ |
saṃkalpadārḍhyamāpannā galitāgrānubhūtayaḥ
]

`v 16 [
saṃkalpa eva jāgrattvaṃ yeṣāṃ ciratayāṃśataḥ |
tatrāstamitaceṣṭānāṃ te hi saṃkalpajāgarāḥ
]

`v 17 [
saṃkalpopaśame bhūyastamanyaṃ vā śrayanti te |
dehe teṣāṃ vayamime saṃkalpapuruṣāḥ sthitāḥ
]

`v 18 [
saṃkalpajāgarāḥ proktā ete saṃkalpaśāyinaḥ |
jīvā jīvitagā lokāḥ śṛṇu kevalajāgarān
]

`v 19 [
prāthamyenāvatīrṇāste brahmaṇo bṛṃhitātmanaḥ |
proktāḥ kevalajāgaryāḥ prāgutpattyavikāsinaḥ
]

`v 20 [
bhūyo janmāntaragatāsta eva cirajāgarāḥ |
kathyante prauḍhimāyātāḥ kāryakāraṇacāriṇaḥ
]

`v 21 [
ta eva duṣkṛtāveśājjaḍasthāvaratāṃ gatāḥ |
ghanajāgrattayā proktā jāgratsu ghanatāṃ gatāḥ
]

`v 22 [
ye tu śāstrārthasatsaṅgabodhitā bodhamāgatāḥ |
paśyanti svapnavajjāgrajjāgratsvapnā bhavanti te
]

`v 23 [
ye tu saṃprāptasaṃbodhā viśrāntāḥ parame pade |
kṣīṇajāgratprabhṛtayaste turyāṃ bhūmikāṃ gatāḥ
]

`v 24 [
iti saptavidho bhedo jīvānāṃ kathitastava |
samudrāṇāmiva mayā buddhvā śreyaḥparo bhava
]

`v 25 [
bhrāntiṃ parityaja jagadgaṇanātmikāṃ tvaṃ bodhaikarūpaghanatāmalamāgato'si |
śūnyatvavarjitamaśūnyatayā ca muktaṃ tena dvayaikyakavimuktavapustvamādyam
]