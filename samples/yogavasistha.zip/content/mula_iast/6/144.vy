`v 1 [
catuścatvāriṃśadadhikaśatatamaḥ sargaḥ 144
muniruvāca |
sarvathābhāvabhāveṣu svapnasaṃvedanātmasu |
nityāpratigharūpeṣu kiṃ baddhaṃ kiṃ vimucyate
]

`v 2 [
khe dṛṣṭibhāsāṃ sphuraṇaṃ yādṛśaṃ tādṛśaṃ jagat |
viparyasyatyaviratamabodhāllakṣyate sthiram
]

`v 3 [
yadyathā purasaṃsthānaṃ ciraireti tadanyatām |
jagadapyevamaniśaṃ vāryāvartavivartavat
]

`v 4 [
bhūmyambvambaraśailādi bhavatyasadidaṃ kṣaṇāt |
tasminneva kṣaṇodantairyugakalpābhidhāḥ kṛtāḥ
]

`v 5 [
jagatsvapna ivāśeṣamasadapyanubhūyate |
yannāsti cettanniḥśeṣaṃ cidevetthaṃ kacatyalam
]

`v 6 [
yathedaṃ no jagattadvacchatānāṃ khe śatāni hi |
nṛṇāṃ paśyantu teṣāṃ tu nānyonyamanubhūtayaḥ
]

`v 7 [
sarobdhikūpabhekānāṃ dṛṣṭāḥ pratyekamāspade |
na te'nyonyaṃ vidantyanyāṃ dṛśyādiniyatiṃ kvacit
]

`v 8 [
yathā janaśatasvapnanagarāṇyekamandire |
tathā jaganti khe bhānti khāni no santyasanti no
]

`v 9 [
kacanti nṛśatasvāpnapurāṇyekagṛhe yathā |
na ca nāma kacantyevaṃ santyasanti jaganti khe
]

`v 10 [
ciccamatkāramātraṃ svaṃ svātmāṅgaṃ dṛśyamadvayam |
sarūpameva nīrūpaṃ sakāraṇamakāraṇam
]

`v 11 [
dadhatyāścitsvabhāvāyāḥ saṃskārādyabhidhāḥ kṛtāḥ |
pratimāyāḥ prabhāvinyā na saṃskārādayaḥ pṛthak
]

`v 12 [
apūrvatvātsmṛtiḥ svapnaḥ saṃkalpārthānubhūtiṣu |
svamṛtyanubhavādyāstu dṛṣṭārthasadṛśīṣu ca
]

`v 13 [
idaṃ sargātma sargādau pratimeva vijṛmbhate |
cidbhāmātrātmikā svacchā nānyannāmopapadyate
]

`v 14 [
brahmaiva bhāti jagadityuktamuktyānayā bhavet |
na ca bhātaṃ navaṃ tacca brahmaivedamataḥ sthitam
]

`v 15 [
kāraṇaṃ kāryamityuktaḥ sa pūrvaḥ sa viśiṣyate |
saṃskāra iti tenaiṣa saṃskāraḥ kṛtirucyate
]

`v 16 [
tatsvapnādāvapūrvo'rtho dṛṣṭānta iti bhāti yaḥ |
sa saṃskārādināmokto na bāhyo'rthosti cetasi
]

`v 17 [
vastu dṛṣṭaṃ na dṛṣṭaṃ ca saccāste cetaneva khe |
svabhāvādbhāti khātmāpi dṛṣṭavaccātijṛmbhate
]

`v 18 [
tacca saṃskārākhyaṃ vastu svapne dṛṣṭaṃ jāgare adṛṣṭam | na cādarśanamātreṇa
nāstīti mantavyam | yataścittākāśe cetaneva sadaivāste | tacca khātmāpi
sākṣisvabhāvātsvapne bhāti jāgraddṛṣṭapadārthavaccātitarāṃ jṛmbhate vistīryate |
17 |
vedāntārthātmakaṃ pūrvasargābhāvaṃ pravartate |
tato vedyavyavasthā jñaiḥ kriyate svārthasiddhaye
]

`v 19 [
svapne tu jāgratsaṃskāro yastajjāgratkṛtaṃ navam |
ajāgrajjāgradābhāsaṃ kṛtamityeva tadvidaḥ
]

`v 20 [
tato vāyāvivāspandāścitte bhāvāḥ sthitāḥ svataḥ |
te svataḥ saṃpravartante kātra saṃskārakartṛtā
]

`v 21 [
ekaṃ tathā ca cinmātraṃ svapne lakṣātma tiṣṭhati |
punarlakṣādyataḥ svapna ekamāste suṣuptakam
]

`v 22 [
cidvyomni svapnasaṃvittiryā saiva jagaducyate |
suṣuptaṃ pralayaḥ proktastasmānnyāyo'yameva san
]

`v 23 [
ekameva cidākāśaṃ sākāratvamanekakam |
svarūpamajahaddhatte yatsvapna iva tajjagat
]

`v 24 [
evaṃ citparamāṇvantarjagadbhāvamidaṃ sthitam |
tadananyātma cābhogi svapnādarśataleṣviva
]

`v 25 [
cidvyoma saṃvinmātraṃ yatparamāṇuvadātatam |
anādimadhyaparyantaṃ tadeva jagaducyate
]

`v 26 [
tasmādyatra cidākāśamanantaṃ satataṃ sthitam |
tatrāstīti jagadbhānaṃn tadaṅgānanyarūpi yat
]

`v 27 [
cinmātra eva bhuvanaṃ tvamahaṃ cinmayaṃ jagat |
iti nyāyājjagadyāti paramāṇūdare'pyajam
]

`v 28 [
tasmādahaṃ parāṇvātmā samastajagadākṛtiḥ |
sarvatraiva ca tiṣṭhāmi paramāṇūdare'pi ca
]

`v 29 [
kīdṛśaṃ tadguruśāstroktanyāyaiḥ parijñānaṃ tatsvānubhavābhilāpena darśayati ##-
cinmātraparamāṇuḥ sañjagadātmāpyayaṃ nabhaḥ |
yatra tiṣṭhāmyahaṃ tatra paśyāmi bhuvanatrayam
]

`v 30 [
ahaṃ citparamāṇvātmā tena citparamāṇunā |
ekatāmāgato vāri vāriṇeva tadīkṣaṇāt
]

`v 31 [
tadojaḥ saṃpraviśyāhaṃ sthitastadanubhūtivat |
antasthatrijagadrūpo yathābje bījamaṅkure
]

`v 32 [
tatra me trijagadrūpamantaḥ kacitamātmani |
tathā tanna tu tadbāhye vidyate kenacitkvacit
]

`v 33 [
yatra yatra yadā bhāti svapne jāgraditīha vā |
sabāhyābhyantaraṃ dṛśyaṃ nijaṃ cidbhānameva tat
]

`v 34 [
bhāti svapne yadā jantorjagadānandamātatam |
cidaṇoreva tadbhānamātmanastatpadātmanā
]

`v 35 [
vyādha uvāca |
akāraṇaṃ ceddṛśyaṃ tatkathametatprasidhyati |
sakāraṇaṃ ceddṛśyaṃ tatsvapne sargādidhīḥ kutaḥ
]

`v 36 [
muniruvāca |
akāraṇaka evāyaṃ sarga ādau pravartate |
samastakāraṇābhāvādyataḥ sargātmacinnabhaḥ
]

`v 37 [
akāraṇānāṃ bhāvānāmatyantāsaṃbhavādiha |
kvacitsapratighaḥ sargo na saṃbhavati kaścana
]

`v 38 [
brahmedamitthamābhāti bhāsvaraṃ citsvabhāvataḥ |
sargādiśabdaparyāyamādyantaparivarjitam
]

`v 39 [
ityakāraṇake sarge kacati brahmarūpiṇi |
parasyāvayavābhāse nityātmāvayavātmanā
]

`v 40 [
anānātve'pi nānātve brahmaṇyabrahmarūpiṇi |
anākāre'pi sākāre kacatyapratighaṃn prati
]

`v 41 [
tadbrahmaiva nirākāraṃ cidrūpatvātsphuradvapuḥ |
sākāramiva bhātātma bhūtvā sthāvarajaṃgamam
]

`v 42 [
devarṣimunibhārūpaṃ karoti niyatiṃ kramāt |
vidhīṃśca pratiṣedhāṃśca deśakālakriyādikān
]

`v 43 [
bhāvābhāvagrahotsargasthūlasūkṣmacarācarāḥ |
arthā vyabhicarantyete niyatirnākhilāstataḥ
]

`v 44 [
brahmakṛtatvādeva bhāvābhāvādyarthavyabhicāre'pi na tanniyatervyabhicāra ityāha ##-
tataḥ prabhṛti bhāvānāṃ sakāraṇakatāṃ vinā |
saikatādiva tailānāṃ na saṃbhavati saṃbhavaḥ
]

`v 45 [
niyatirnāyakaścaiva brahmataścāṅgamātmanā |
svāṅgena saṃyamayati kareṇeva nijaṃ karam
]

`v 46 [
abuddhipūrvaṃ cānicchamevameva pravartate |
kākatālīyavatspandādāvartā iva vāriṇi
]

`v 47 [
saṃniveśo hi niyatistāṃ vinā pratighodayam |
brahma sthātuṃ na śaknoti tacca sarvātmatākṣayam
]

`v 48 [
evaṃ sakāraṇaṃ sarvaṃ sarvadā dṛśyamaṇḍalam |
yasya sarge yataḥ kālāttataḥ prabhṛti taṃ prati
]

`v 49 [
evaṃ niyatikalpanātaḥ sarvaṃ sakāraṇaṃ yaṃ prati yataḥ kālātprabhṛti niyatiryasya
sarge pravṛttā taṃ pratyeva na puruṣāntaraṃ kālāntarabhāvipadārthaṃ ca pratītyarthaṃ |
48 |
bhātyakāraṇakaṃ brahma sargātmāpyabudhaṃ prati |
taṃ pratyeva ca bhātyeṣa kāryakāraṇadṛgbhramaḥ
]

`v 50 [
kākatālīyavatsarge sthite tvāvṛttivṛttivat |
idamitthamidaṃ netthamitīyaṃ niyatiḥ sthitā
]

`v 51 [
sakāraṇatvaṃ bhāvānāmavaśyaṃbhāvini krame |
jāgratsvapnadṛśo neha saṃbhavantyapakāraṇāḥ
]

`v 52 [
yathā svapne'khilāmambusaṃkṣobhātpralayabhramāḥ |
dṛśyate kāraṇaṃ tatra śrūyatāmanubhūyatām
]

`v 53 [
sarvavastuṣu kacanti sarvadā yuktayaḥ sphaṭikaśuktayo yathā |
bhāvanānubhava eva sa svayaṃ śaktimāñjayati jīvitātmakaḥ
]