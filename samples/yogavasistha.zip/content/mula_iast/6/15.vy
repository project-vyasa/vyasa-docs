`v 1 [
pañcadaśaḥ sargaḥ 15
bhuśuṇḍa uvāca |
yatrāhaṃtvaṃ jagattatra pūrvamāgatya tiṣṭhati |
parāṇvantarapīndrasya trasareṇūdare yathā
]

`v 2 [
bhramasya jāgatasyāsya jātasyākāśavarṇavat |
ahaṃbhāvo'bhimantātmā mūlamādyamudāhṛtam
]

`v 3 [
vāsanārasasaṃsiktādahaṃbījakaṇādayam |
brahmādrau vyomavipine jāyate trijagaddrumaḥ
]

`v 4 [
tārakāpuṣpanikaro vilīnācalapallavaḥ |
saritsāraśirāpūro vāsanāsāratatphalaḥ
]

`v 5 [
ahaṃtvasalilasyedaṃ jagatspanda udāhṛtaḥ |
ciccamatkaraṇasvādurvāsanāvisaradravaḥ
]

`v 6 [
tārakāsīkarāsāro nabhonantanikhātavān |
bhāvābhāvamahāvarto nānāgiritaraṅgakaḥ
]

`v 7 [
trilokīvililikhallekho vilolālokaphenilaḥ |
brahmāṇḍabudbudodbhedaḥ kavāṭāpīḍapīvaraḥ
]

`v 8 [
bhūpīṭhadṛḍhaḍiṇḍīrapiṇḍaścidghanamadgumān |
citrājavaṃ javībhāvamajjanonmajjanātmakaḥ
]

`v 9 [
jarāmaraṇamohādivīcīcayacamatkṛtiḥ |
utpannadhvaṃsidehādibinduvṛndaikabandhuraḥ
]

`v 10 [
ahaṃtvapavanaspando jagadityavagamyatām |
ahaṃtvapadmasaugandhyaṃ jagadityavabudhyatām
]

`v 11 [
nāhaṃtvajagatī bhinne pavanaspandavatsadā |
payo dravatvamiva ca vahnirauṣṇyamivāpi ca
]

`v 12 [
jagadastyahamarthe'ntarahamasti jagaddhṛdi |
anyonyabhāvinī tvete ādhārādheyavatsthite
]

`v 13 [
jagadbījamahaṃtvaṃ yo mārṣṭi bodhādavedanāt |
alaṃ citraṃ jaleneva tena dhautaṃ jaganmalam
]

`v 14 [
ahaṃtvaṃ nāma tatkiṃcidvidyādhara na vidyate |
akāraṇamavastutvācchaśaśṛṅgamivoditam
]

`v 15 [
brahmaṇyatitate'nante saṃkalpollekhavarjite |
ahaṃtvakāraṇābhāvānna kadācana sanmayam
]

`v 16 [
avastunyeti sargādau na saṃbhavati kāraṇam |
ato'haṃtvādi nāstyeva vandhyāsuta iva kvacit
]

`v 17 [
tadabhāvājjagannāsti cittvaṃ jagadabhāvataḥ |
śiṣṭaṃ nirvāṇamevātaḥ śāntamāssva yathāsukham
]

`v 18 [
abhāvādupapattisthādevaṃ jagadahaṃtvayoḥ |
rūpālokamanaskārāḥ śāntāstava na cetarat
]

`v 19 [
yannāsti tattu nāstyeva śeṣaṃ śāntamasi dhruvam |
saṃprabuddho'si mā bhūyo nirmūlāṃ bhrāntimāhara
]

`v 20 [
vyapagatakalanākalaṅkaśuddhaḥ śivamasi śāntamasīśvaro'si nityaḥ |
khamapi bhavati parvatopamānaṃ jagadapi vā paramāṇurūpameva
]