`v 1 [
saptādhikaśatatamaḥ sargaḥ 107
śrīvasiṣṭha uvāca |
acetyacinmayaṃ viśvaṃ viṣvagābhāti cinnabhaḥ |
atra ciccetanaṃ cedaṃ cetyamapyevamātmakam
]

`v 2 [
ato jīvannapi mṛta iva sarvo'vatiṣṭhate |
asāvahaṃ ca tvaṃ ceti jīvanto'pi mṛtā iva
]

`v 3 [
kāṣṭhamaunamṛtā eva vyavahāragatā api |
khagamā eva vā sarve bhāvāḥ sthāvarajaṅgamāḥ
]

`v 4 [
ākāśakācakacyātma yadidaṃ kiṃcidātatam |
na kiṃcideva tadviddhi kiṃcidvyomni kuto bhavet
]

`v 5 [
keśoṇḍrakanadīvāhadhūmālīmauktikādivat |
yatkhaṃ kacati tatrāsti nānubhūte'pi vastutā
]

`v 6 [
tathaivāsmiñjagannāmni cidvyomni kacate cite |
anubhūte'pi niḥśūnye kāsthāsthābhāvakaśca kaḥ
]

`v 7 [
cidbālakalpanājāle śūnyātmani nirarthake |
avastubhūte pṛthvyādau bhrāntimātrāmbarodaye
]

`v 8 [
kimāsthā bālakā brūta mamedamahamityalam |
ā jñātaṃ ramate bālasaṃkalpe bāla eva ca
]

`v 9 [
pṛthvyādyasadvicārairvā vyarthaṃ yāsyati jīvitam |
kiṃcicca na jñāsyati bhorākāśakṣālanodyataḥ
]

`v 10 [
sahakāryādipūrvāṇāṃ kāraṇānāmabhāvataḥ |
yadādāveva notpannaṃ tannāmādya bhavetkutaḥ
]

`v 11 [
ajātenāsatārthena khena vyavaharanti ye |
mūḍhā mṛtamajātaṃ vā tanayaṃ pālayanti te
]

`v 12 [
kutaḥ pṛthvyādayaḥ kena ke nāma kathamutthitāḥ |
cidvyometthamidaṃ śāntaṃ prakacatyātmanātmani
]

`v 13 [
tattvadṛṣṭau pṛthvyādīnāmatyantāsaṃbhavamanubhavamavalambyāha - kuta iti |
12 |
kāryakāraṇakālādikalpanākulacetasām |
evaṃ pṛthvyādayaḥ santi tairbālairalamastu naḥ
]

`v 14 [
apṛthvyādi jagannāma sapṛthvyādi ca khātmakam |
kacatītthaṃ nabhorūpaṃ svapnādiṣviva cinmaṇiḥ
]

`v 15 [
aṅgaṃ yadetasya cidambarasya nirākṛti svānubhavānumānam |
tadetadābhāti mahītalādirūpeṇa vedyetikṛtābhidhānam
]