`v 1 [
pañcasaptatyadhikaśatatamaḥ sargaḥ 175
śrīvasiṣṭha uvāca |
svapnābhamādyaṃ cidvyoma kāraṇaṃ dehasaṃvidām |
dṛśyānyatā'saṃbhavataścidvyomnastatkuto vapuḥ
]

`v 2 [
sargādau svapnasaṃvittirūpaṃ sarvaṃ vinānagha |
na sargo na paro loko dṛśyamāno'pi siddhyati
]

`v 3 [
asadevānubhūritthamevedaṃ bhāsate jagat |
svapnāṅganāsaṅga iva śāntaṃ cidvyoma kevalam
]

`v 4 [
evaṃnāmāsti ciddhāturanādinidhano'malaḥ |
śūnyātmaivāccharūpo'pi jagadityavabhāti yaḥ
]

`v 5 [
malastveṣo'parijñātaḥ parijñātaḥ paraṃ bhavet |
kutaḥ kila pare vyomanyanādinidhane malaḥ
]

`v 6 [
yadetadvedanaṃ śuddhaṃ tadeva svapnapattanam |
jagattadeva sargādau pṛthvyādeḥ saṃbhavaḥ kutaḥ
]

`v 7 [
cidvyomātmāvabhāsasya nabhasaḥ sargarūpiṇī |
kṛtā pṛthvyādikalanā manobuddhyāditā tathā
]

`v 8 [
vāryāvarta ivābhāti pavanaspandavacca yat |
abuddhipūrvaṃ cidvyomni jagadbhānamabhittimat
]

`v 9 [
paścāttasyaiva tenaiva svayamaiśvaryaśaṃsinā |
kṛtaṃ buddhyādipṛthvyādikalpanaṃ sadasanmayam
]

`v 10 [
svayameva kacatyacchācchā yeyaṃ svā mahācitiḥ |
sargābhidhānamasyaiva nabha eveha netarat
]

`v 11 [
na ca kiṃcana nāmāṅga kacatyacchaiva sā smṛtā |
cinmātraikaikakalanaṃ tatamevātmanātmani
]

`v 12 [
cidākāśaścidākāśe tadidaṃ svamalaṃ vapuḥ |
cittaṃ dṛśyamivābhāti yathā svapne tathā sthitam
]

`v 13 [
anyathānupapattyārthakāraṇābhāvataḥ `note[arthasya satyasya
kāraṇāntarasyābhāvataścetyarthaḥ |] svataḥ |
sargādāveva svātmaiva dṛśyaṃ cidvyoma paśyati
]

`v 14 [
anyathānupapattyā prakārāntareṇa vādisahasrairapi sargopapādanāsaṃbhavātpariśeṣāt |
13 |
svapnavattacca nirdharma manāgapi na bhidyate |
tasmāccidvyoma cidvyoma śūnyatvaṃ gaganādivat
]

`v 15 [
yadeva tatparaṃ brahma sarvarūpavivarjitam |
tadevaikaṃ tathārūpamevaṃ sarvatayā sthitam
]

`v 16 [
svapne'nubhūyate caitatsvapno hyātmaiva bhāsate |
nānābodhamanānaiva brahmaivāmalameva tat
]

`v 17 [
brahmaivātmani cidbhāvājjīvatvamiva kalpayat |
rūpamatyajadevācchaṃ manastāmiva gacchati
]

`v 18 [
idaṃ sarvaṃ tanotīva tacca khātmakameva kham |
bhavatīva jagadrūpaṃ vikārīvāvikāryapi
]

`v 19 [
mana eva svayaṃ brahmā sa sargasya hṛdi sthitaḥ |
karotyavirataṃ sarvamajasraṃ saṃharatyapi
]

`v 20 [
pṛthvyādirahito yasminmanohṛdyaṅgavarjite |
anyadvā trijagadbhāti yathā svapne nirākṛti
]

`v 21 [
deharūpajagadrūpairahamekamanākṛti |
manastiṣṭhāmyanantātma bodhābodhaṃ parābhavam
]

`v 22 [
neha pṛthvyādi no deho na caivānyāsti dṛśyatā |
jagattayā kevalaṃ khaṃ manaḥ kacakacāyate
]

`v 23 [
vicāryadṛṣṭyaitadapi na kiṃcidapi vidyate |
kevalaṃ bhāti cinmātramātmanātmani nirghanam
]

`v 24 [
yato vāco nivartante tūṣṇīṃbhāvo'vaśiṣyate |
vyavahāryapi khātmaiva tadvattiṣṭhati mūkavat
]

`v 25 [
anantāpāraparyantā cinmātraparameṣṭakā |
tūṣṇīṃbhūtvā bhavtyeṣa prabuddhaḥ puruṣottamaḥ
]

`v 26 [
abuddhipūrvaṃ dravato yathāvrtādayo'mbhasi |
kriyante brahmaṇā tadvaccittabuddhyādayo jaḍāḥ
]

`v 27 [
abuddhipūrvaṃ vātena kriyate spandanaṃ yathā |
ananyadevaṃ buddhyādi kriyate paramātmanā
]

`v 28 [
ananyadātmano vāyoryathā spandanamavyayam |
ananyadātmanastadvaccinmātraṃ paramātmanaḥ
]

`v 29 [
cidvyoma brahmacinmātramātmā citi mahāniti |
paramātmeti paryāyā jñeyā jñānavatāṃ vara
]

`v 30 [
brahmonmeṣanimeṣātma spandāspandātma vātavat |
nimeṣo yādṛgevāsya samunmeṣastathā jagat
]

`v 31 [
dṛśyasya samunmeṣo dṛśyābhāvo nimeṣaṇam |
ekametannirākāraṃ taddvyorapyupakṣayāt
]

`v 32 [
nimeṣonmeṣayorekarūpameva paraṃ matam |
ato'sti dṛśyaṃ nāstīti sadasacca sadā citiḥ
]

`v 33 [
nimeṣo nānya unmeṣānnonmeṣo'pi nimeṣataḥ |
brahmaṇaḥ sargavapuṣo nimeṣonmeṣarūpiṇaḥ
]

`v 34 [
tadyathāsthitamevedaṃ viddhi śāntamaśeṣataḥ |
ajātamajaraṃ vyoma saumyaṃ samasamaṃ jagat
]

`v 35 [
cidacityātmakaṃ vyoma rūpaṃ kacakacāyate |
cinnāma tadidaṃ bhāti jagadityeva tadvapuḥ
]

`v 36 [
na naśyati na cotpannaṃ dṛśyaṃ nāpyanubhūyate |
svaya camatkarotyantaḥ kevalaṃ kevalaiva cit
]

`v 37 [
mahācidvyomamaṇibhā dṛśyanāmnī nijākarāt |
ananyānyeva bhātāpi bhānubhāsa ivoṣṇatā
]

`v 38 [
suṣuptaṃ svapnavadbhāti bhāti brahmaiv sargavat |
sarvamekaṃ śivaṃ śāntaṃ nānevāpi sthitaṃ sphurat
]

`v 39 [
yadyatsaṃvedyate yādṛksadvā'sadvā yathā yadā |
tathānubhūyate tādṛktatsadastvasadastu vā
]

`v 40 [
anyathānupapattyā cetkāraṇaṃ parikalpyate |
tatsvapnābho jagadbhāvādanyathā nopapadyate
]

`v 41 [
pramātītātparādviśvamananyaduditaṃ yataḥ |
pramātītamidaṃ caiva kiṃcinnābhyuditaṃ tataḥ
]

`v 42 [
yasya yadrasikaṃ cittaṃ tattathā tasya gacchati |
brahmaikarasikaṃ tena manastattāṃ samaśrute
]

`v 43 [
yaccitto yadgataprāṇo jano bhavti sarvadā |
tattena vastviti jñātaṃ jānāti tadasau sphuṭam
]

`v 44 [
brahmaikarasikaṃ yatsyānmanastattadbhavetkṣaṇāt |
yasya yadrasikaṃ ceto buddhaṃ tena tadeva sat
]

`v 45 [
viśrāntaṃ yasya vai cittaṃ jantostatparamārthasat |
vyavahṛtyai karotyanyatsadācārādatadrasam
]

`v 46 [
dvitvaikatvādikalanā neha kācana vidyate |
sattāmātraṃ ca dṛgiyamitaścedalamīkṣyate
]

`v 47 [
adṛśyadṛśyasadasanmūrtāmūrtadṛśāmiha |
naivāsti na ca nāstyeva kartā bhoktā'thavā kvacit
]

`v 48 [
adṛśyaṃ brahmaiva dṛśyaṃ sadasanmūrtamamūrtaṃ ceti dṛgyeṣāṃ teṣāṃ iha
kartā bhoktā vā jīvo naivāsti nāpi nāstyeva | tasyaiva brahmatayā pariśeṣādityarthaḥ | 47
|
idamitthamanādyantaṃ jagatparyāyamātmani |
brahmaikaghanamāśāntaṃ sthitaṃ sthāṇurivādhvani
]

`v 49 [
ajñānāṃ pānthānāṃ corasaṃdehabhrāntyādiyogye kāntārādhvani sthāṇuriva sthitam |
48 |
yadeva brahma buddhyādi tadevaitannirañjanam |
yadeva gaganaṃ śāntaṃ śūnyaṃ viddhi tadeva tat
]

`v 50 [
keśoṇḍrakādayo vyomni yathā sadasadātmakāḥ |
dvitāmivāgatā bhānti pare buddhyādayastathā
]

`v 51 [
tathā buddhyādi dehādi vedanādi parāpare |
anekānyapyananyāni śūnyatvāni yathāmbare
]

`v 52 [
suṣuptādviśataḥ svapnamekanidrātmano yathā |
sargasthasyāpi na dvitvaṃ naikatvaṃ brahmaṇastathā
]

`v 53 [
sargasthasya svāpnasargasthasyāpi svasya na dvitvaṃ nāpyekatvaṃ vyāvartyāprasiddheḥ |
52 |
evameva kacatyacchā chāyeyaṃ svā mahāciteḥ |
na ca kiṃcana nāmāṅga kacatyacchaivamāsthitā
]

`v 54 [
cidvyomni hi cidākāśameva svamamalaṃ vapuḥ |
cetyaṃ dṛśyamivābhāti svapneṣviva yathasthitam
]

`v 55 [
anyathānupapattyārthakāraṇābhāvataḥ svtaḥ |
cidvyomātmānamevādau dṛśyamityeva paśyati
]

`v 56 [
sargādāveva khātmaiva dṛśyaṃ bhāti nirākṛti |
saṃbhramaḥ svapnasaṃkalpamithyājñāneṣvivābhitaḥ
]

`v 57 [
svapnavattacca nirdharma manāgapi na bhidyate |
vikāryapi sadharmāpi cidvyomno vastuno malāt
]

`v 58 [
tatsvapnanagarākāraṃ sadharmāpyasadhrmakam |
śivādananyamevetthaṃ sthitameva nirantaram
]

`v 59 [
dṛśyaṃ svapnādrivatsvacchaṃ manāgapi na bhidyate |
tasmāccidvyomacidvyomnaḥ śūnyatvaṃ gaganādiva
]

`v 60 [
yadeva tatparaṃ brahma sarvarūpavivarjitam |
tadevedaṃ tathābhūtameva sargatayā sthitam
]

`v 61 [
svapne'nubhūyate caitatsvapne hyātmaiva bhāsate |
purāditvena na tu satpurādiracitaṃ tadā
]

`v 62 [
svapne ca pratyabhijñāyāḥ saṃskārasya smṛtestathā |
na sattā tadidaṃ dṛṣṭamityarthasyātyasaṃbhavāt
]

`v 63 [
tasmādetattrayaṃ tyaktvā yadbhānaṃ brahmasaṃvidaḥ |
tasya dṛṣṭārthasādṛśyānmūḍhaiḥ smṛtyāditohitā
]

`v 64 [
yathā yatraiva laharī vāriṇyeti punaḥ punaḥ |
tatraivaiti tathā tadvadananyā khe pare jagat
]

`v 65 [
vidhayaḥ pratiṣedhāśca sarva eva sadaiva ca |
vibhaktāśca vimiśrāśca pare santi na santi ca
]

`v 66 [
tasmātsadbrahma sarvātma kimivātra na vidyate |
saiva sattaiva sarvātma caitadapyetadātmakam
]

`v 67 [
bhrāntasya bhramaṇaṃ bhūmerna bhūrbhrāntaiva vā gaṇaiḥ |
na śāmyati jñāturapi tathābhyāsaṃ vinātra dṛk
]

`v 68 [
śāstrasyāsya tu yannāma vādanaṃ tadvināparaḥ |
abhyāso dṛśyasaṃśāntyaina bhūto na bhaviṣyati
]

`v 69 [
na jīvanna mṛtaṃ cittaṃ rodhamāyāti saṃsṛteḥ |
avinābhāvidehatvādbodhāttvetanna paśyati
]

`v 70 [
sarvadaivāvinābhāvi cittaṃ dṛśyaśarīrayoḥ |
iha cāmutra caitasya bodhānte `note[bodhātte iti ṭīkānuguṇaḥ pāṭhaḥ |]
śāmyataḥ svayam
]

`v 71 [
cittadṛśyaśarīrāṇi trīṇi śāmyanti bodhataḥ |
pavanaspandasainyāni kāraṇābhāvato yathā
]

`v 72 [
kāraṇaṃ maurkhyamevāsya taccāsmādeva śāstrataḥ kiṃcitsaṃskṛtabuddhīnāṃ
vācitādeva śāmyati
]

`v 73 [
abuddhamuttaragranthātpūrvaṃ pūrvaṃ hi budhyate |
granthaṃ padapadārthajñaḥ khedavānna nivartate
]

`v 74 [
upāyamidamevāto viddhi śāstraṃ bhramakṣaye |
ananyasādhāraṇatāṃ gatamityanubhūyate
]

`v 75 [
tasmādasmānmahāśāstrādyathāśakti vicārayet |
bhāgau dvau bhāgamekaṃ vā tena duḥkhakṣayo bhavet
]

`v 76 [
āruṣeyamidamiti `note[bahupustakeṣu āṛṣeyamiti pāṭha upalabhyate |
ubhayatrāpyārṣatvaṃ samānam |] pramādāccenna rocate |
tadanyadātmavijñānaśāstraṃ kiṃcidvicārayet
]

`v 77 [
anarthenāvicāreṇa vayaḥ kuryānna bhasmasāt |
bodhena jñānasāreṇa dṛśyaṃ kartavyamātmasāt
]

`v 78 [
āyuṣaḥ kṣaṇa eko'pi sarvaratnairna labhyate |
nīyate tadvṛthā yena pramādaḥ sumahānaho
]

`v 79 [
anubhūtamapi ca no saddṛśyamidaṃ draṣṭṭasahitamapi |
svapnanijamaraṇabāndhavarodanamiva sadiva kacitamapi
]