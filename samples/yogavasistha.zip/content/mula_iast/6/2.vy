`v 1 [
sarvabhāvasvabhāvo'tra niyatiścopavarṇyate |
utpattirjīvatāprāptihetūnāṃ brahmaśuddhatā |
niyatiḥ kāryakāraṇabhāvādiniyamaḥ agnijalāderauṣṇyadravatvādiḥ svabhāvaśca acalaḥ
avyabhicaritaḥ kathaṃ kena hetunā jagati sthitaḥ |
svāpnamānorathikādimithyārthāntareṣvadarśanāditi bhāvaḥ
]

`v 2 [
satsvasaṃkhyeṣu deveṣu sūrya evograbhāḥ katham |
dīrghatvamatha hrasvatvaṃ divasānāṃ tu kiṃkṛtam
]

`v 3 [
śrīvasiṣṭha uvāca |
kākatālīyavadbhānaṃ yatpare niyataṃ svataḥ |
yathāsthitaṃ yathārūpaṃ sthite tajjagaducyate
]

`v 4 [
sarvaśakteryathā yadyadbhāti tattattathaiva sat |
saṃvitsāratayā yāyātkathaṃ bhātamabhātatām
]

`v 5 [
yathā sthitaṃ yathā bhāti cittvādbrahma cirāya yat |
tasya bhānamabhānābhaṃ niyatyabhidhameva tat
]

`v 6 [
idamitthamidaṃ cetthaṃ svayaṃ brahmeti bhāti yat |
tanniyatyabhidhaṃ proktaṃ sargasaṃhārarūpadhṛk
]

`v 7 [
jāgratsvapnasuṣuptākhyaṃ yatsvataḥ kacanaṃ citi |
tattato'nanyadekācchaṃ dravatvamiva vāriṇi
]

`v 8 [
yathā śūnyatvamākāśe karpūre saurabhaṃ yathā |
yathauṣṇyamātape nānyajjāgradādi tathā citi
]

`v 9 [
sargapralayanāmnyekapravāhānanyasattayā |
cinmātragaganātmaikabrahmātmanyeva saṃsthitam
]

`v 10 [
sargo'yamiti tadbuddhaṃ kṣaṇaṃ yatkacanaṃ citaḥ |
kalpo'yamiti tadbuddhaṃ kṣaṇaṃ tatkacanaṃ citaḥ
]

`v 11 [
tatkālastatkriyā tatkhaṃ deśadravyodayādi tat |
yatsvapna iva cinmātrakacanaṃ svasvabhāvataḥ
]

`v 12 [
rūpālokamanaskāradeśakālakriyādi tat |
cittvaṃ kacati cidvyomni yannāmānākṛti svataḥ
]

`v 13 [
yadyathā kacitaṃ kālaṃ yatkiṃcitkalpitaṃ tathā |
tenaiveyaṃ hi niyatirityaṣyākāśarūpakam
]

`v 14 [
ākalpākhyaṃ nimeṣaṃ yatkacanaṃ caikarūpakam |
svābhāvikāḥ svabhāvaṃ taṃ prāhuḥ prasṛtabuddhayaḥ
]

`v 15 [
ekasya saṃvinmātrasya padārthaśatatā tahā |
yathedaṃ saṃvidaṃśasya rūpaṃ svaṃ svamanujjhataḥ
]

`v 16 [
saṃvinmaye saṃvido yāḥ kacantīva pare tathā |
tābhisteṣāṃ svadehānāṃ yāsāṃ sā kalanā kṛtā
]

`v 17 [
cidurvī salilaṃ tejaḥ spandaḥ śūnyatvameva ca |
pratyekamākarastveṣāṃ tāni svapna ivāmbaram
]

`v 18 [
tatra sapratighasyāsya kaṭhinasyākaro mahān |
bhūpīṭhaṃ janatādhāro rājanrājena rājate
]

`v 19 [
apāmabdhiḥ pradhānānāṃ tejasāmeṣa bhāskaraḥ |
spandasya pavano vyoma śūnyatāyā jagadgatam
]

`v 20 [
pañcānāmiti bhūtānāmākaratvena saṃvidaḥ |
pañca tānyucitā brāhmyaḥ praśnaḥ kiṃ bhāskaraṃ prati
]

`v 21 [
budhā saṃviccidityuktā sarvagā sarvarūpiṇī |
sarvatra svamahimnaiṣā sarveṇaivānubhūyate
]

`v 22 [
brahmātmā brahmabālo'yaṃ svasaṃvitsphuraṇāmimām |
vyomātmakṣaumabhūnāmnīṃ sphārayatyambarākṛtiḥ
]

`v 23 [
sā yadaitattathaitacca niramattyajasaṃvidā `note[viramati iti pāṭhaḥ] |
tadā tadaṅgasyārkādernā'to notpādi cañcalam
]

`v 24 [
saṃkalpapūrvamaśakajālavaddhiṣṇyacakrakam |
āvartavrtinā bhāti cidvyomedaṃ ca dṛśyavat
]

`v 25 [
tatra prabhāsvarāḥ kecitkecidapyalpabhāsvarāḥ |
keciccābhāsvarā bhātāḥ padārthāścitrarūpiṇaḥ
]

`v 26 [
padārthajātaṃ tvetāvanna jātaṃ na ca dṛśyate |
jñasyājātamidaṃ bhāti khamātmā svapnadṛśyavat
]

`v 27 [
cinmātramātmā sarveśaḥ sarva evātidṛśyavat |
naśyatīva videhe sve na ca bhāti na naśyati
]

`v 28 [
svapnadarśanavadbhāti yaccidvyoma cidambare |
cidvyomatvādṛte rūpaṃ tadasya jagataḥ kutaḥ
]

`v 29 [
yadyathā sphuritaṃ tasya yāvatsattaṃ sphuradvapuḥ |
tatsvabhāvaniyatyākhyaiḥ śabdairiha nigadyate
]

`v 30 [
gaganāṅgasya sattāntaḥ śabdatanmātrakalpayā |
kusūlabījāṅkuravattiṣṭhatyāśāntarūpiṇī
]

`v 31 [
saṃpadyate tata idamitīyaṃ racanehayā |
kṛtā `note[kṛtā saṃmugdha iti ṭīkānuguṇaḥ pāṭhaḥ |] sā mugdhabodhāya
mūrkhairviracitā mudhā
]

`v 32 [
nāstametīha nodeti tatkadācana kiṃcana |
śilājaṭharavacchāntamidaṃ nityaṃ sadapyasat
]

`v 33 [
yathāvayavino nāntaḥ sadaivāvayavāṇavaḥ |
nāstaṃ yānti na codyanti jagantyātmapade tathā
]

`v 34 [
brahma vyomni jagadvyoma vyoma vyomnīva vidyate |
tatkathaṃ kila saṃśuddhamastamāyātyudeti vā
]

`v 35 [
tasyānantaprakāśātmarūpasyātatacinmaṇeḥ |
sattāmātrātmakacanaṃ yadajasraṃ svabhāvataḥ
]

`v 36 [
tadātmanā svayaṃ kiṃciccetyatāmiva gacchati |
agṛhītātmakaṃ saṃvidūhāmarśnasūcakam
]

`v 37 [
bhāvināmārthakalanaiḥ kiṃcidūhitarūpakam |
ākāśādaṇu śuddhaṃ ca sarvasminbhāvibodhanam
]

`v 38 [
tataḥ sā paramā sattā satī taccetanonmukhī |
cinnāmayogyā bhavati kiṃcillabhyatayā tayā
]

`v 39 [
ghanasaṃvedanātpaścādbhāvijīvādināmikā |
sā bhavatyātmakalanā yadbhavantī paraṃ padam
]

`v 40 [
garbhīkṛtya sthitā'nākhyā cidākāśāpidhānatām |
saṃprati tvatiśuddhasya padasyānanyarūpiṇī
]

`v 41 [
svataikabhāvanāmātrasārasaṃsaraṇonmukhī |
tadā vinābhāvakṛtā anutiṣṭhanti tāmimāḥ
]

`v 42 [
śūnyarūpā svasattaikā śabdādiguṇagarbhiṇī |
cidbhāvanābhisaṃpannā bhaviṣyadabhidhārthatā
]

`v 43 [
ahaṃtodeti tadanu saha vai kālasattayā |
bhaviṣyadabhidhārthe te bījaṃ mukhyaṃ jagatsthiteḥ
]

`v 44 [
citiśakteḥ parāyāstu svasaṃvedanamātrakam |
jagajjālamasadrūpaṃ cetanātsadiva sthitam
]

`v 45 [
evaṃprāyātmikā sā cidbījaṃ saṃkalpaśākhinaḥ |
ahaṭāṃ bhāvayatyantaḥ saiveha bhavati kṣaṇāt
]

`v 46 [
jīvābhidhānā saiṣādya bhāvābhāvaplavabhramaiḥ |
bhramatyātmapade vīcirūpairvārīva vāriṇi
]

`v 47 [
cidevaṃbhāvanavatī vyomatanmātrabhāvanām |
svato ghanībhūya śanaiḥ khatanmātraṃ pracetati
]

`v 48 [
bhāvināmārtharūpaṃ tadbījaṃ śabdaughaśākhinaḥ |
padavākyapramāṇāḍhyavedārthādivikāri ca
]

`v 49 [
tasmādudeṣyatyakhilā jagacchrīḥ śabdatattvataḥ |
śabdaughanirmitārthaughapariṇāmavisāriṇī
]

`v 50 [
cidevaṃvyavasāyā sā jīvaśabdena kathyate |
bhāviśabdārthajālena bījaṃ bhūtaughaśākhinaḥ
]

`v 51 [
caturdaśavidhaṃ bhūtajātamāvalitāmbaram |
jagajjaṭharakarṇaughaṃ tasmātsaṃprasariṣyati
]

`v 52 [
asaṃprāptābhidhācārā jīvatvāccetanena cit |
kākatālīyavatspandacinmātraṃ cetati svayam
]

`v 53 [
pavanaskandharūpasya bījaṃ tvaksparśaśākhinaḥ |
sarvabhūtakriyāspandastasmātsaṃprasariṣyati
]

`v 54 [
tatra yaccidvilāsasya prakāśānubhavo bhavet |
rūpatanmātrakaṃ tadvadbhaviṣyadabhidhārthadam
]

`v 55 [
prakāśacetanaṃ tejo na tejo'nyakṛtaṃ bhavet |
sparśasaṃvedanaṃ sparśo netarasparśasaṃbhavaḥ
]

`v 56 [
śabdasaṃvedanaṃ śabdaḥ svata evānubhūyate |
khaṃ kheneva svayaṃ kośe nānyacchabdakṛdasti hi
]

`v 57 [
yathā khaṃ khena svenaiva svātmake kośe avakāśaṃ prāpya tiṣṭhati nānyena tathā
saṃvedanamapi svātmakenaiva śabdena śabdakṛt śabdagrāhakaṃ nānyadastītyarthaḥ |
56 |
kila tasyāmavasthāyāṃ ko'paraḥ śabdakṛdbhavet |
yathā tathā tadādyāpi dvaitaikyasyātyasaṃbhavāt
]

`v 58 [
evaṃ hi rasatanmātraṃ gandhatanmātrameva ca |
asatyameva sadiva svapnābhamiva cetyate
]

`v 59 [
tejaḥ sūryādijṛmbhābhirbījamālokaśākhinaḥ |
tasmādrūpavibhedena saṃsāraḥ prasariṣyati
]

`v 60 [
bhaviṣyadabhidhasyātha khataḥ svata ivāsataḥ |
svadanaṃ tasya saṃghasya rasatanmātramucyate
]

`v 61 [
bhaviṣyadrūpasaṃkalpanāmāsau sakalo gaṇaḥ |
saṃkalpātmātha tanmātraṃ gandhādyamanucetati
]

`v 62 [
bhāvibhūgolakatvena bījamākṛtiśākhinaḥ |
sarvādhārātmanastasmātsaṃsāraḥ prasariṣyati
]

`v 63 [
ajāta eva saṃjātastanmātrāṇāṃ gaṇastviti |
anākāro'pi sākāraḥ saṃpannaḥ kalpanāvaśāt
]

`v 64 [
eṣa tanmātrakagaṇaḥ kākatālīyavatsvayam |
rūpaṃ yena pradeśena vettyakṣīti taducyate
]

`v 65 [
śabdaṃ yena pradeśena vetti śrotaṃ taducyate |
sparśaṃ yena pradeśena vetti tattu tvagindriyam
]

`v 66 [
rasaṃ yena pradeśena vetti tadrasanendriyam |
gandhaṃ yena pradeśena vetti ghrāṇendriyaṃ tu tat
]

`v 67 [
dikkālabhedāñjīvo'yaṃ `note[dikkālakalanāṃ jīvo niyatāmiti pāṭho
vyākhyānuguṇaḥ syāt |] niyatāmākṛtiṃ gataḥ |
sarveṇāṅgena no sarvaṃ vettyasarvātmatāvaśāt
]

`v 68 [
iti kalanamanantamātmanontargatamanumeyamananyadātmabhūtam |
na tadudayamupaiti nāstameti sthitamupalodaravadghanaṃ sumaunam
]