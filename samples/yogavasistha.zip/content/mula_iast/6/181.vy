`v 1 [
ekāśītyadhikaśatatamaḥ sargaḥ 181
kundadanta uvāca |
āvāsamantare gantuṃ pravṛttau muditākṛtī |
mathurānagarīṃ candrasūryāvindrapurīmiva
]

`v 2 [
prāpya rodhābhidhaṃ grāmaṃ viśramyāmravaṇācale |
uṣitau dve dine tasminsālīse nagare sukham
]

`v 3 [
adhvānanditacittābhyāmāvābhyāmativāhitaḥ |
dvitīye'hani śītāmbusnigdhacchāyāvanadrumāḥ
]

`v 4 [
nadītīralatonmuktapuṣpaprakarapāṇḍurāḥ |
tarattaraṅgajhāṃkāragāyanānanditādhvagāḥ
]

`v 5 [
tā evāvanīrviśinaṣṭi - nadītīretyādinā | gāyanamiti aśityātvākaraṇaṃ chāndasam |
4 |
snigdhadrumavanacchāyaraṇanmṛgavihaṃgamāḥ |
sthūlaśādvalaśākhāgraprotāvaśyāyamauktikāḥ
]

`v 6 [
jaṅgalādripuragrāmaśvabhrānūpasthalāvanīḥ |
samullaṅghya dine tasminsaritsrotaḥsarāṃsi ca
]

`v 7 [
nītavantau niśāmāvāṃ kadalīkānane ghane |
tuṣāraśiśire śrāntau kadalīdalatalpake
]

`v 8 [
prāptāvāvāṃ tṛtīye'hni ṣaṇḍaṣaṇḍakamaṇḍitam `note[abjaṣaṇḍaka iti
pāṭhaścintyaḥ |] |
jaṅgalaṃ janavicchedavibhaktaṃ khamivākṛtam
]

`v 9 [
tatra sa prakṛtaṃ mārgaṃ parityajya vanāntaram |
praviśansamuvācedamakāryakaraṇaṃ vacaḥ
]

`v 10 [
gacchāvo'trāśrame gauryā munimaṇḍalamaṇḍite |
bhrātaro me sthitāḥ sapta vaneṣvevamivārthinaḥ
]

`v 11 [
bhrātaro'ṣṭau vayamime jātānekatayā tayā |
ekasaṃvinmayā jātā ekasaṃkalpaniścayāḥ
]

`v 12 [
tena te'pyatra tapase svaniścayasamāśrayāḥ |
sthitā āgatya vividhaistapobhiḥ kṣapitainasaḥ
]

`v 13 [
taiḥ sārdhaṃ bhrātṛbhiḥ pūrvamāgatyāhamihāvasam |
ṣaṇmāsānāśrame gauryāstena dṛṣṭo mayaiṣa saḥ
]

`v 14 [
puṣpakhaṇḍatarucchāyāsuptamugdhamṛgārbhakaḥ |
parṇoṭajāgraviśrāntaśukodgrāhitaśāstradṛk
]

`v 15 [
tadbrahmalokasaṃkāśamehi munyāśramaṃ śriye |
gacchāvo'cchataraṃ tatra cetaḥ puṇyairbhaviṣyati
]

`v 16 [
viduṣāmapi dhīrāṇāmapi tattvavidāmapi |
tvarate hi manaḥ puṃsāmalaṃbuddhibilokane
]

`v 17 [
tenetyukte ca tāvāvāṃ prāptau munyāśramaṃ ca tam |
yāvattatra mahāraṇye paśyāśvaścāntarūpiṇam
]

`v 18 [
na vṛkṣaṃ noṭajaṃ kiṃcinna gulmaṃ na ca mānavam |
na muniṃ nārbhakaṃ nānyanna vediṃ na ca vā dvijam
]

`v 19 [
kevalaṃ śūnyamevāti tadaraṇyamanantakam |
tāpopataptamabhito bhūmau sthitamivāmbaram
]

`v 20 [
hā kaṣṭaṃ kimidaṃ jātamiti tasminvadatyatha |
āvābhyāṃ suciraṃ bhrāntvā dṛṣṭa ekatra vṛkṣakaḥ
]

`v 21 [
snigdhacchavirghanacchāyaḥ śītalo'mbudharopamaḥ |
tale tasya samādhāne saṃsthito vṛddhatāpasaḥ
]

`v 22 [
āvāmagre munestasya cchāyāyāṃ śādvalasthale |
upaviṣṭau ciraṃ yāvannāsau dhyānānnivartate
]

`v 23 [
tataścireṇa kālena mayodvegena cāpalāt |
uktaṃ mune prabudhyasva dhyānādityuccakairvacaḥ
]

`v 24 [
śabdenoccairmadīyena saṃprabuddho'bhavanmuniḥ |
siṃho'mbudaraveṇeva jṛmbhāṃ kṛtvābhyuvāca ca
]

`v 25 [
kau bhavantāvimau sādhū kvāsau gauryāśramo gataḥ |
kena vāhamihānītaḥ kālo'yaṃ kaśca vartate
]

`v 26 [
tenetyukte mayāpyuktaṃ bhagavanviddhi īdṛśam |
na kiṃcidāvāṃ buddho'pi kasmājjānāsi na svayam
]

`v 27 [
iti śrutvā sa bhagavānpunardhyānamayo'bhavat |
dadarśodantamakhilamasmākaṃ svātmanastathā
]

`v 28 [
muhūrtamātreṇovāca prabudhya dhyānato muniḥ |
śrūyatāmidamāścaryamāryau hi kāryavedinau
]

`v 29 [
yamimaṃ paśyathaḥ sādhū kadambataruputrakam |
madāspadamaraṇyānyā dhammillamiva puṣpitam
]

`v 30 [
kenāpi kāraṇenāsminsatī vāgīśvarī satī |
avasaddaśavarṣāṇi samastartuniṣevitā
]

`v 31 [
tadā teneha vistīrṇamabhavadghanakānanam |
gaurīvanamiti khyātaṃ bhūṣitaṃ kusumartubhiḥ
]

`v 32 [
kusumapradhānaiḥ sarvartubhirbhūṣitamalaṃkṛtam | tadā tasminkāle | tena kāraṇena | 31
|
bhṛṅgāṅganājanamanoharahārigītalīlāvilolakalakaṇṭhavihaṃgamaṅga
`note[viloka ityapi pāṭhaḥ |] |
puṣpāmbuvāhaśatacandranabhovitānaṃ rājīvareṇukaṇakīrṇadigantarālam
]

`v 33 [
mandārakundamakarandasugandhitāśaṃ
saṃsūcchvsatkusumarāśiśaśāṅkaniṣṭham |
saṃtānakastavakahāsavikāsakāntamāmodimārutasamastalatāṅganaugham
]

`v 34 [
puṣpākarasya nagaraṃ navagītabhṛṅgaṃ
bhṛṅgāṅganākusumakhaṇḍakamaṇḍapāḍhyam |
candrāṃśujālaparikomalapuṣpadolādolāyamānasurasiddhavadhūsamūham
]

`v 35 [
hārītahaṃsaśukakokilakokakākacakrāhvabhāsakalaviṅkakulākulāṅgam |
bheruṇḍakukkuṭakapiñjalahemacūḍarāḍhāmayūrabakakalpitakeliramyam
]

`v 36 [
hārītādipakṣikulairākulānyaṅgāni yasya | hemacūḍāstittirayaḥ | rāḍhāḥ pakṣibhedāḥ |
35 |
gandharvayakṣasurasiddhakirīṭaghṛṣṭapādābjakarṇikakadambasarasvatīkam |
vātāyanaṃ kanakakomalacampakaughatārāmbarāmbudharapūra gṛhītagandham |
36 |
gandharvayakṣādīnāṃ kirīṭairghṛṣṭe pādābjakarṇike yasyāstathāvidhā
kadambasarasvatī yasmin | surabhivātānāmayanamata eva kanakamiva
komalebhyaścampakaughebhyastārāmbudharābhyāṃ gṛhīto gandho yasya
]

`v 37 [
mandānilaskhalitapallavabālavallīvinyāsaguptadivasādhiparaśmiśītam |
pītaṃ kadambakaravīrakanālikeratālītamālakulapuṣpaparāgapūraiḥ
]

`v 38 [
kahlārakīrṇakumudotpalapadmakhaṇḍavalgaccakorabakakokakadambahaṃsam |
tālīsaguggulakacandanapāribhadrabhadradrumodaravihārivicitraśakti
]

`v 39 [
tasminvane ciramuvāsa harārdhadehā kenāpi kāraṇavaśena cirāya gaurī |
bhūtvā prasannaśaśibimbamukhī kadambavāgīśvarī śaśikaleva śivasya mūrdhni
]