`v 1 [
saptatriṃśaḥ sargaḥ 37
śrīvasiṣṭha uvāca |
icchāviṣavikārasya viyogaṃ yoganāmakam |
śāntaye śṛṇu bhūyo'pi pūrvamuktamapi sphuṭam
]

`v 2 [
ātmano vyatiriktaṃ cedvidyate tadihecchayā |
iṣyatāmasati tvetatsvātmānyatvaṃ krimiṣyate
]

`v 3 [
nirbhāgāvayavā sūkṣmā vyomnaḥ śūnyataraiva cit |
saivāhaṃjagadākārā satī kiṃ tattayeṣyate
]

`v 4 [
sā vyomarūpā vyomaiva vyomātmavedyavedikā |
vyomātmajagadābhāsamatrecchāviṣayo'sti kaḥ
]

`v 5 [
grāhyagrāhakasaṃbandhaḥ kutaściditi tanna naḥ |
vidyate'sau praśāntānāṃ yeṣāmasti na vedmi tān
]

`v 6 [
grāhyagrāhakasaṃbandhaḥ svaniṣṭho'pi na labhyate |
asatastu kathaṃ lābhaḥ kena labdho'sitaḥ śaśī
]

`v 7 [
eṣaiva grāhakādīnāṃ sattā yannātmaniṣṭhatā |
svabhāvāvekṣayā satyā na jāne kva prayānti te
]

`v 8 [
eṣa eva svabhāvo yaddraṣṭṭadṛśyakṣayo'khilaḥ |
jñātvā'satyā vinirvāṇamahaṃtātmani gacchati
]

`v 9 [
nirvāṇe nāsti dṛśyādi dṛśyādau nāsti nirvṛtiḥ |
mitho'nayoranubhavo na cchāyātapayoriva
]

`v 10 [
ubhe ete mitho'satye asatye ca na nirvṛtiḥ |
yato nirvāṇamajaramaduḥkhamanubhūyate
]

`v 11 [
bhramabhūtaṃ ca dṛśyādi nityaṃ nātra sukhapradam |
asacca tadbhāvyatāṃ mā nirvāṇe sthīyatāmaje
]

`v 12 [
śuktikārūpyasadṛśaṃ prekṣitaṃ yanna labhyate |
arthakāryapi tannāsti kimatrāpahnavena ca
]

`v 13 [
tatsadbhāvānmahaduḥkhamasadbhāvānmahatsukham |
abhāvaḥ sopapattistu dṛḍhatāṃ yāti bhāvanāt
]

`v 14 [
tatkimātmani bandhāya vidagdhaṃ na mudhādhamāḥ |
spaṣṭa evopacayādervastunyastamitā'pade
]

`v 15 [
kāryakāraṇabhāvādi brahmaiva sakalaṃ yadā |
tadā tu brahmatā hyasminsaṃvinmātrātmake tate
]

`v 16 [
mārgayanti prabodhāya tairmṛgairalamastu naḥ |
vyomarūpe kilaikasminsarvātmani tate sati
]

`v 17 [
kāryakāraṇatāḍhyānāmuktīnāmeva kaḥ kramaḥ |
yo hetuḥ spandane vāyordravatve salilasya ca
]

`v 18 [
śūnyatve nabhasaḥ saumya sargāditve cidātmanaḥ |
kāryakāraṇabhāvādi brahmaiva sakalaṃ yadā
]

`v 19 [
tadā brahmaṇi sargāṇāṃ kāraṇārthā vilajjatā |
na duḥkhamasti na sukhaṃ śāntaṃ śivamayaṃ jagat
]

`v 20 [
nāsti cinmātratānyatvamata icchodayaḥ kutaḥ |
mṛddehayodhasenāyāṃ na mṛnmātretaradyathā
]

`v 21 [
na sajjagadahaṃtādau dṛśye brahmetarattathā |
śrīrāma uvāca |
evaṃ cettadudetvicchā mā vodetu munīśvara
]

`v 22 [
sā tu brahmaiva ko'rthaḥ syādasyā vidhiniṣedhane |
śrīvasiṣṭha uvāca |
jñātāyāṃ saṃprabuddhāyāmicchā brahmaiva netarat
]

`v 23 [
yathā saṃbuddhavānrāma tatsatyaṃ kiṃ tvidaṃ śṛṇu |
yadā yadā jñatodeti śāmyatīcchā tadā tadā
]

`v 24 [
vastusvabhāvādudayatyāditye yāminī yathā |
śāmyatyeva na tūdeti jñaptāvicchādi tattathā
]

`v 25 [
yathā yathodayo jñapterdvaitaśāntistathā tathā |
vāsanāvilayaścaiva kathamicchodayo bhavet
]

`v 26 [
tasyā vidyopaśānteyaṃ nirmalā muktatoditā |
aśeṣadṛśyavairasyādyasyecchodeti na kvacit
]

`v 27 [
viraktatāsya no dṛśye nodetyatrāsya raktatā |
kevalaṃ draṣṭṭadṛśyaśrīḥ svadate na svabhāvataḥ
]

`v 28 [
kākatālīyayogena parapreraṇayānayā |
yadi kiṃcitkadācicca samyagicchati vā na vā
]

`v 29 [
tadasya secchā necchā vā brahmaivātra na saṃśayaḥ |
icchā na jāyate jñasyāvaśyamevānu vā navā
]

`v 30 [
jñatā ceduditā jantostadicchāsyopaśāmyati |
naitayoḥ sthitirekatra prakāśatamasoriva
]

`v 31 [
pratiṣedhavidhīnāṃ tu tajjño na viṣayaḥ kvacit |
śāntasarvaiṣaṇecchasya ko'sya kiṃ vakti kiṃkṛte
]

`v 32 [
etadeva jñatācihnaṃ yadicchāsvatitānavam |
hlādanaṃ sarvalokānāmathānubhava eva vā
]

`v 33 [
dṛśyaṃn virasatāṃ yātaṃ yadā na svadate kvacit |
tadā necchā prasarati tadaiva ca vimuktatā
]

`v 34 [
bodhādanaikyamadvaitaṃ yaḥ śāntamavatiṣṭhate |
icchānicchādayaḥ sarve bhāvāstasya śivātmakāḥ
]

`v 35 [
bodhādastamitadvaitamadvaitaikyavivarjitam |
yaḥ svaccho vigatavyagraḥ śānta ātmanyavasthitaḥ
]

`v 36 [
naiva tasya kṛtenārtho nākṛteneha kaścana |
na cāsya sarvabhūteṣu kaścidarthavyapāśrayaḥ
]

`v 37 [
nānicchayā necchayātha na satā nāsatā sadā |
naivātmanā na cānyena naitairmaraṇajīvitaiḥ
]

`v 38 [
icchā ca tasya nodeti nirvāṇasya prabodhinaḥ |
yadi codeti tasyecchā brahma śāśvatameva sā
]

`v 39 [
na duḥkhamasti na sukhaṃ śāntaṃ śvamajaṃ jagat |
iti yo'ntaḥ śilevāste taṃ prabuddhaṃ vidurbudhāḥ
]

`v 40 [
duḥkhaṃ sukhaṃ bhāvanayā kurvanviṣamivāmṛtam |
iti niścitya dhīrātmā `note[ghorātmā iti pāṭhaḥ |] prabuddha iti kathyate
]

`v 41 [
tatsthitaṃ vyomani vyoma śānte śāntaṃ śive śivam |
śūnye śūnyaṃ sati ca sadyadbrahmaṇi jagatsthitam
]

`v 42 [
asaṃvedanasaṃvitkhe tate'viśvamiti sthite |
saumye samasame śānte śive'haṃtābhramaḥ kṣayī
]

`v 43 [
yadidaṃ dṛśyate kiṃcijjagatsthāvarajaṅgamam |
tatsarvaṃ śāntamākāśaṃ paracintāpuropamam
]

`v 44 [
paracintāpuromadhye gatavighnaṃ gamāgamau |
yathāntastava śūnyatvāttathaivāsmiñjagadbhrame
]

`v 45 [
abdhidyūrvīnadīśailaśobhāśūnyatarātmani |
jṛmbhate draṣṭṭakaraṇaṃ mṛgatṛṣṇāmbuvīcivat
]

`v 46 [
svapnanirmāṇapuravadbālavetālatālavat |
yadidaṃ dṛśyate tatra kiṃ kilāsatyatetarat
]

`v 47 [
asatyamevāhamiti bhāsate satyameva ca |
bhrāntibhājaṃ vinaiveyaṃ bhrāntiḥ sphurati sā satī
]

`v 48 [
na sannāsanna sadasatkimapīdamatīndriyam |
avācyaṃ jagadityeva bhātyavakṣubhitaṃ khavat
]

`v 49 [
ihecchānicchate jñasya śāmyatāṃ yadalaṃ same |
tathāpi śreyase manye nanvanicchodayaṃ sphuṭam
]

`v 50 [
ahaṃ jagaditi jñaptiḥ khe khasyeveyamāsthitā |
cidātmano yathā vāyoḥ spando nātrāsti kāraṇaṃ
]

`v 51 [
citaścetyonmukhatvaṃ yattaccittaṃ saiva saṃsṛtiḥ |
secchā tanmuktatā muktiryuktiṃ jñātveti śāmyatām
]

`v 52 [
icchā bhavatvanicchā vā sargo vā pralayo'thavā |
kṣatirna kasyacitkācinna ca kiṃcidihāsti hi
]

`v 53 [
icchānicche sadasatī bhāvābhāvau sukhāsukhe |
ityatra kalanā vyomni saṃbhavanti na kāścana
]

`v 54 [
icchānāṃ tānavaṃ yasya dinānudinamāgatam |
vivekaśamatṛptasya tamāhurmokṣabhāginam
]

`v 55 [
icchākṣurikayā viddhe hṛdi śūlaṃ pravartate |
jayanti yatra naitāni maṇimantrauṣadhāni ca
]

`v 56 [
yānkāryakaraṇavyūhānkṛtavānpūrvameva tān |
saṃprekṣayā na paśyāmi mithyābhramabharādṛte
]

`v 57 [
bhramabhūtena kurmaścedvyavahāramavastunā |
tatkasmātparacittādriḥ kambalatvaṃ `note[kavalanaṃ iti pāṭhaḥ |] na nīyate | 57
|
nanu bhrāntisiddhenaiva kenacidupāyena taccikitsādivyavahāro'stu tatrāha -
bhramabhūteneti | bhramo bhrāntijñānaṃ tena bhūtena siddhena |
asmadbhrāntisiddhopāyena parabhrāntisiddhaduḥkhanivāraṇe
asmanmanorathakalpitabahuyojanavistṛtamukhena parakīyasvapnaśailādeḥ
kavalanaprasaṅga ityarthaḥ
]

`v 58 [
asatā vyavahāraścetprekṣāmātravināśinā |
kriyate śaśaśṛṅgeṇa tatkathaṃ chādyate na kham
]

`v 59 [
ahaṃbhāvāccidākāśo jāḍyātiśayataḥ kṣaṇāt |
pāṣāṇatāṃ jalamiva manastvādyāti dehatām
]

`v 60 [
cittvādanubhavatyetāmasatyāmeva dehitām |
avinaṣṭaiva cicchaktiḥ svapne svamaraṇaṃ yathā
]

`v 61 [
vyomnyasatyamavastutvātsatyaṃ cānubhavādyathā |
nīlatvaṃ tadvadīśe'sminsargo nāsanna sanmayaḥ
]

`v 62 [
prātibhāsikajaḍabhāvaḥ pratibhāsādhīnasattākatvādanirvacanīya ityāha - vyomnīti |
61 |
yathā śūnyatvanabhasoryathā spandanabhasvatoḥ |
bhedo nāsti tathā sargabrahmaṇorekarūpayoḥ
]

`v 63 [
neha saṃjāyate kiṃcijjagadādi na naśyati |
svapno nidrāgatasyeva kevalaṃ pratibhāsate
]

`v 64 [
prātibhāsikārthasya svāpnārthavatpratibhāsātiriktamutpattyādikamaprasiddhamityāha ##-
avidyamāne pṛthvyādau pratibhāmātrarūpiṇi |
sarge ka iva saṃrambhastyāgādānaiścidambare
]

`v 65 [
na dehaḥ pratibhāto'sti pṛthvyādikāraṇānvitaḥ |
kevalaṃ brahmacinmātramevātmanyeva saṃsthitam
]

`v 66 [
buddhyādeḥ kāraṇatvaṃ ca dvaitaikyāsaṃbhavānna sat |
anenedaṃ kriyata ityasyārthaṃ yāti saṃbhavāt
]

`v 67 [
aheturakramaṃ bhāti citi kalpakriyāgaṇaḥ |
kṣaṇenaiva yathā svapne mṛtijanmādi satvarāḥ
]

`v 68 [
khameva pṛthvī khaṃ śailāḥ khameva dṛḍhabhittayaḥ |
khameva lokāḥ spandaḥ khaṃ sargasaṃvedanaṃ citeḥ
]

`v 69 [
vyomabhittau jagaccitraṃ cidraṅgamayamātatam |
nodeti nāstamāyāti na śāmyati na tāmyati
]

`v 70 [
cidvāriṇi jagattuṅgataraṅgadravarūpiṇi |
kiṃ nu vā kathamutpannaṃ kiṃ śāntaṃ ca kadā katham
]

`v 71 [
śānte mahācidākāśe jagacchūnyatvaśālini |
cetyāsaṃbhavataḥ santi nodayāstamayau kutaḥ
]

`v 72 [
stāṃ tarhi cita eva jagadātmanā udayāstamayau netyāha - śānte iti | cetyāsaṃbhavato
yadā jagantyeva na santi tadātmanā cita udayāstamayau kutaḥ | kasmātsidhyata ityarthaḥ |
71 |
parvatā gaganāyante gaganaṃ parvatāyate |
saṃvedanaprayogeṇa brahmaṇaḥ sargatā sthitau
]

`v 73 [
saṃviccūrṇaprayogeṇa nimeṣārdhena yoginaḥ |
kurvanti jagadākāśamākāśaṃ trijaganti ca
]

`v 74 [
siddhasaṃkalpanagarāṇyasaṃkhyāni yathāmbare |
tathā sargasahasrāṇi santi tāni tu cinnabhaḥ
]

`v 75 [
mahārṇave yathāvartā anyonyamapi miśritāḥ |
pṛthagevāvatiṣṭhante payaso'nye ca naiva te
]

`v 76 [
mahāciti mahāsargā anyonyamapi miśritāḥ |
pṛthagevāvatiṣṭhante vyatiriktā na te tataḥ
]

`v 77 [
sargātsargāntarāloke yā prabuddhasya yoginaḥ |
siddhalokāntare prāptiḥ saiveti vibudhoktayaḥ
]

`v 78 [
avināśini bhūtāni sthitāni parame śive |
vyomnīva śūnyatollāsāḥ sargavargā nirargalam
]

`v 79 [
paramārthanijāmodāḥ sahajāḥ sargavibhramāḥ |
nodyanti nopaśāmyanti lekhā iva śilodare
]

`v 80 [
anyonyaṃn kusumāmodā militā `note[miśritā apyamiśritā iti pāṭhaḥ |]
apyamīlitāḥ |
vyomarūpāstathā sargā anyonyaṃn siddhabhūmayaḥ
]

`v 81 [
saṃkalpākāśarūpatvātsarvānubhavavatsthiteḥ |
tanusaṃkalpamohānāṃ satyāśca mananoktayaḥ
]

`v 82 [
na jñānavāditā satyā na bāhyānarthavāditā |
yathāvedanametāni vedanāni phalanti vaḥ
]

`v 83 [
citi cittvaṃ yadastyantarjagadityeva bhāvite |
bhedo dravatvapayasoriva nātropapadyate
]

`v 84 [
kālo jaganti bhuvanānyahamakṣavargastvaṃ tāni tatra ca tatheti ca sarvamekam |
cidvyoma śāntamajamavyayamīśvarātma rāgādayaḥ khalu na kecana saṃbhavanti |
84 |
uktamanūdya prakṛte yojayannupasaṃharati - kāla iti | sarvādhāraḥ
kālastadantargatāni jaganti brahmāṇḍāstadantargatāni caturdaśabhuvanāni tadantargatā
ahaṃtvamityādayo bhoktārasteṣāṃ bhogopakaraṇabhūto'kṣavargastāni
śabdasparśādibhogyāni tatra ca tathā vicitro bhogaścetyetatsarvamīśvarātma
māyikasārvajñyasarvaśaktyādisaṃpannaṃ paramārthataḥ śāntamekaṃ cidvyomaiva |
evaṃ khalu niścite kecana rāgādayo na saṃbhavantyevetyayamevecchādisarvadoṣajaye
mukhyopāya ityarthaḥ
]