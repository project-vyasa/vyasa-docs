`v 1 [
pdf 165, p. 1086
navamaḥ sargaḥ 9
bhuśuṇḍa uvāca |
abuddhyamānaścetyādicidrūpamapi cānagha |
śāntacidghana evāsva nirmalāpsvantaraṃśuvat
]

`v 2 [
acetanaṃ cetanāntaścetanādeva vidyate |
sve'sādṛśye'pi sadṛśaṃ payorāśau yathānalāḥ
]

`v 3 [
sacetanācetanayorhetuścittvāttathaiva cit |
vināśotpādayorvahnijvālāyāḥ pavano yathā
]

`v 4 [
nāhamastīti cidrūpaṃ citi viśrāntirastu te |
tato yathā yādṛśena bhūyate tādṛśo bhava
]

`v 5 [
cidrūpaḥ sarvabhāvānāmantarbahirasi sthitaḥ |
prasannāmbubharasyāntarbahiścaiva yathā payaḥ
]

`v 6 [
nāhamastīti cidrūpaṃ citau cellagnamaṅga te |
na cānyaccetitaṃ brahma rūpaṃ kenopamīyate
]

`v 7 [
sasurāsurapātālabhūviṣṭapamivoṣitam |
nānābhāvājavībhāvakriyākālamivākulam
]

`v 8 [
yathā raṅgamayaṃ kuḍye jaganmaunamiva sthitam |
tathā ciccitrakacitaṃ khe kuḍye cātmasaṃsthitam
]

`v 9 [
tenaiva bhūyate bhūri yaccittaṃ kacitaṃ svataḥ |
acetanaṃ cetanaṃ vā yathecchasi tathā kuru
]

`v 10 [
ciccamatkṛtayo vyomni sphurantyetā jagattayā |
arkāṃśuvadarodhinyaḥ svacchā viditavedinām
]

`v 11 [
timirākrāntadṛṣṭīnāṃ yathā keśoṇḍrakādi khe |
sphuratyevaṃ jagadrūpamanātmanyeva tiṣṭhatām
]

`v 12 [
evaṃ jagattvamahamityavabodharūpamābhāsamātramuditaṃ na ca noditaṃ ca |
arkāṃśujālaracanānagarābhamatra kuḍyādi satyamidamasti na khe lateva
]