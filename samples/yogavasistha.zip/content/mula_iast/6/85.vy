`v 1 [
pañcāśītitamaḥ sargaḥ 85
śrīvasiṣṭha uvāca |
iti nṛtyati sā devī dīrghadordaṇḍamaṇḍalaiḥ |
parispandātmakairvyoma kurvāṇā ghanakānanam
]

`v 2 [
kriyāsau nṛtyati tathā citiśaktiranāmayā |
asyā vibhūṣaṇaṃ śūrpakuddālapaṭalādikam
]

`v 3 [
śaraśaktigadāprāsamusalādi śilādi ca |
bhāvābhāvapadārthaughakalākālakramādi ca
]

`v 4 [
citspando'ntarjagaddhatte kalpaneva puraṃ hṛdi |
saiva vā jagadityeva kalpanaiva yathā puram
]

`v 5 [
pavanasya yathā spandastathaivecchā śivasya sā |
yathā spando'nilasyāntaḥ praśāntecchastathā śivaḥ
]

`v 6 [
amūrto mūrtamākāśe śabdāḍambaramānilaḥ |
yathā spandastanotyevaṃ śivecchā kurute jagat
]

`v 7 [
nṛtyantyātha yadā tatra tathā tasminparāmbare |
kākatālīyayogena saṃrambhavaśataḥ svayam
]

`v 8 [
nikaṭasthaḥ śivaḥ spṛṣṭaḥ sa manāgabhramantikam |
vāḍavo'gniḥ svanāśāya vahantyevāmbulekhayā
]

`v 9 [
spṛṣṭamātre śive tasmiṃstataḥ paramakāraṇe |
pravṛttā prakṛtiṃ gantuṃ sā śanaistanutāṃ tathā
]

`v 10 [
anantākāratāṃ tyaktvā saṃpannā girimātrikā |
tato nagaramātrāsau tataśca drumasundarī
]

`v 11 [
tato vyomasamākārā śivasyaivākṛtiṃ tataḥ |
sā praviṣṭā saricchāntasaṃrambheva mahārṇavam
]

`v 12 [
eka evābhavadatho śivayā parivarjitaḥ |
śiva eva śivaḥ śānta ākāśe śamano'bhitaḥ
]

`v 13 [
śrīrāma uvāca |
bhagavañchivasaṃspṛṣṭā sā śivā parameśvarī |
kimarthamāgatā śāntimiti me brūhi tattvataḥ
]

`v 14 [
śrīvasiṣṭha uvāca |
sā rāma prakṛtiḥ proktā śivecchā pārameśvarī |
jaganmāyeti vikhyātā spandaśaktirakṛtrimā
]

`v 15 [
sa paraḥ prakṛteḥ proktaḥ puruṣaḥ pavanākṛtiḥ |
śivarūpadharaḥ śāntaḥ śaradākāśaśāntimān
]

`v 16 [
bhramati prakṛtistāvatsaṃsāre bhramarūpiṇī |
spandamātrātmikā secchā cichaktiḥ pārameśvarī
]

`v 17 [
yāvanna paśyati śivaṃ nityatṛptamanāmayam |
ajaraṃ paramādyantavarjitaṃ varjitadvayam
]

`v 18 [
saṃvinmātraikadharmitvātkākatālīyayogataḥ |
saṃviddevī śivaṃ spṛṣṭvā tanmayīva bhavatyalam
]

`v 19 [
prakṛtiḥ puruṣaṃ spṛṣṭvā prakṛtitvaṃ samujjhati |
tadantarekatāṃ gatvā nadīrūpamivārṇave
]

`v 20 [
āpagā hi payomātraṃ saṅge arṇava eva sā |
yadā tadā tamevāśu prāpya tatraiva līyate
]

`v 21 [
citiḥ śivecchā sā devaṃ tamevāsādya śāmyati |
janmasthānaśilāṃ prāpya tīkṣṇadhārā yathāyasī
]

`v 22 [
puṃsaśchāyāṃ nijacchāyā praviṣṭasya śarīrakam |
yathāśu praviśatyeva prakṛtiḥ puruṣaṃ tathā
]

`v 23 [
vanādicchāyāṃ praviṣṭhasya puṃso nijacchāyā yathā taccharīrakaṃ praviśati tadvat |
22 |
cetitvā cinnijaṃ bhāvaṃ puruṣākhyaṃ sanātanam |
bhūyo bhramati saṃsāre neha tattāṃ prayāti hi
]

`v 24 [
sādhurvasati coraughe tāvadyāvadasau natam `note[natamiti mūlasthasyāyamarthaḥ |
] |
parijānāti vijñāya na tatra ramate punaḥ
]

`v 25 [
dvaite tāvadasadrūpe ramate bhramate citiḥ |
paraṃ paśyati no yāvattaṃ dṛṣṭvā tanmayī bhavet
]

`v 26 [
citinirvāṇarūpaṃ yatprakṛtiḥ paramaṃ padam |
prāpya tattāmavāpnoti saridabdhāvivābdhitām
]

`v 27 [
tāvadvimohavaśataścitirākuleṣu sargeṣu saṃsarati janmadaśāsu tāsu |
yāvanna paśyati paraṃ tamathāśu dṛṣṭvā tatraiva majjati ghanaṃ madhunīva
bhṛṅgī
]

`v 28 [
saṃprāpya kastyajati nāma tadātmatattvaṃ prāpyānubhūya ca jahāti rasāyanaṃ
kaḥ |
śāmyanti yena sakalāni nirantarāṇi duḥkhāni janmamṛtimohamayāni rāma
]