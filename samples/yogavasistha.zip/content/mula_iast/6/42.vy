`v 1 [
dvicatvāriṃśaḥ sargaḥ 42
śrīvasiṣṭha uvāca |
cittavatkacanaṃn śānte yattattasmānna bhidyate |
avyākṛtāmalatayā kvā'taḥ sargādisaṃbhavaḥ
]

`v 2 [
cittadīpe gate yānti bhrāntivadbhānti `note[bhrāntivadbhrāntikhe iti
mudritapāṭho'svarasaḥ ṭīkākartrasaṃmataśca |] khe sthite |
rūpālokamanaskārasaṃvido'mbudravormayaḥ
]

`v 3 [
nirastakaraṇāpekṣaṃ marutaḥ spandanaṃ yathā |
yathā visaraṇaṃ bhāsastathā jagadidaṃ pare
]

`v 4 [
dravatvamiva kīlāle śūnyatvamiva cāmbare |
spandatvaṃ marutīvedaṃ kimapyātmamayaṃ pare
]

`v 5 [
mahāciti mahākāśe yadidaṃ bhāsate jagat |
taccittvameva kacati nirmalatvaṃ maṇāviva
]

`v 6 [
yathā dravatvaṃ payasi yathā śūnyatvamambare |
yathā praspandanaṃ vāyau mahāciti tathā jagat
]

`v 7 [
vetti vāyuryathā spandaṃ tathā vetti jagaccitiḥ |
na dvaitaikyādibhedānāṃ manāgapyatra saṃbhavaḥ
]

`v 8 [
avivekavivekābhyāṃ bhāsuraṃ bhaṅguraṃ jagat |
bodhe sadaiva sadrūpamabhāsuramabhaṅguram
]

`v 9 [
jñaptimātrādṛte śuddhādādimadhyāntavarjitāt |
nānyadastīha nirṇītaṃ mahācinmātrarūpiṇaḥ
]

`v 10 [
tatkasyacicchivaṃ śāntaṃ kasyacidbrahma śāśvatam |
kasyacicchūnyatāmātraṃ kasyacijjñaptimātrakam
]

`v 11 [
tadanantātma cidrūpaṃ cetyatāmiva bhāvayat |
svasaṃsthameva jñeyatvamajñatvamiva gacchati
]

`v 12 [
cittayā nāsti sattā ca cittatā nāsti tāṃ vinā |
vinā vinā yathā vāyoryathā spandeṣu kāraṇam
]

`v 13 [
tathā mahācitocchāyāḥ sargasaṃvittivṛttiṣu |
nityaṃ sattvamasattvaṃ vā hetoranyānapekṣaṇāt
]

`v 14 [
ityatrārtho'bhaviṣyatsa dvitvaikatvāstitāvaśāt |
ko'tra kalpayitā dvitvamekatvaṃ vā mahāmbare
]

`v 15 [
viṣvagviśvamapāraikaparamākāśakośatā |
yathā spandāniladvitvaṃ śābdameva na vāstavam
]

`v 16 [
viśvaviśveśvaradvitvaṃ tathaivāsanmayātmakam |
sadevāsaṃbhavaddvitvaṃ mahācinmātrakaṃ ca yat
]

`v 17 [
viśvābhāsaṃ tadevedaṃ na viśvaṃ sanna viśvatā |
deśakālādimattvena kadāciddhemni satyatā
]

`v 18 [
kaṭakatvasya bhinnasya viśvasya ca tathā pare |
dvitvaikyāsaṃbhave cātra kāryakāraṇatā kutaḥ
]

`v 19 [
syāccettatkalpanāmātramevaitannānyavastutā |
śūnyatā nabhasīvātra dravatvamiva cāmbhasi
]

`v 20 [
khe khalekhāpyabhinneva kilāsti jagadāditā |
yadrūpaṃ brahma tadrūpaṃ jagatkvātra dvitaikate
]

`v 21 [
yadrūpaṃ vyoma tadrūpamevaṃ śūnyaṃn kilākhilam |
ekātmani tate svacche cinmātre sarvarūpiṇi
]

`v 22 [
śilāputrakasenāyāṃ pāṣāṇatva ivāsthite |
kāryakāraṇavaicitryaṃ kathaṃ saṃbhavati kva vā
]

`v 23 [
kathamavyomatā vyomni dvitīyāsaṃbhavādbhavet |
pratibhātmaiva bhārūpo bhāti sargo mahāciti
]

`v 24 [
putrikevopalotkīrṇā tanmayatvāttadātmikā |
sādho yathāsthitasyaivaṃ buddhvā `note[buddhā asya sthitasyeti śeṣaḥ |] viśvaṃ
pralīyate
]

`v 25 [
kāṣṭhamaunadaśābhāsaṃ saṃsāramavaśiṣyate |
yathā nimīlitākṣasya rūpālokamanobhramaḥ
]

`v 26 [
svapne jāgratyanagrastho'pyasannevāstibhāvanāt |
tathaivonmīlitākṣasya rūpālokamanobhramaḥ
]

`v 27 [
svapne jāgratyanagrastho'pyasannevāstibhāvanāt |
bhāvanopaśamaṃ kṛtvā śilībhūya yathāsthitam
]

`v 28 [
aśilībhūtamevāntaḥ svabhāvaṃ samamāsyatām |
āvivekopahāreṇa yathāprāptārthapūjanaiḥ
]

`v 29 [
bodhāya pūjyatāṃ buddhyā svabhāvaḥ parameśvaraḥ |
vivekapūjitaḥ svātmā sadyaḥ sphāravarapradaḥ
]

`v 31 [
rudropendrādipūjātra jarattṛṇalavāyate |
vicāraśamasatsaṅgabalipuṣpaikapūjitaḥ `note[puṣpaughapūjita iti pāṭhaḥ |] |
30 |
sadyomokṣaphalaḥ sādho svātmaiva parameśvaraḥ |
satyālokanamātraikapūjito'nuttamārthadaḥ
]

`v 32 [
yatrāstyātmeśvarastatra mūḍhaḥ ko'nyaṃ samāśrayet |
satsaṅgaśamasaṃtoṣavivekāpūjitātmanaḥ
]

`v 33 [
śirīṣakusumāyante śastrāhiviṣavahnayaḥ |
devārcanatapastīrthadānānyatikṛtānyapi
]

`v 34 [
bhasmāyante nirarthatvādavivekāmahātmanām |
etānyapi vivekena kriyante saphalāni cet
]

`v 35 [
viveka eva tatkasmātsphuṭamantarna sādhyate |
yathābhūtārthavijñānādvāsanoparame pare
]

`v 36 [
yatno vivekaśabdākhyo bhavatyātmaprasādataḥ |
tathā tathā viveko'ntarvṛddhiṃ neyaḥ śamāmṛtaiḥ
]

`v 37 [
yathā yathā punaḥ śoṣamupayāti na vibhramaiḥ |
dehasattāmanādṛtya yathā bhūtārthadarśanāt
]

`v 38 [
lajjāṃ bhayaṃ viṣāderṣye sukhaṃ duḥkhaṃ jayetsamam |
jagadādi śarīrādi nāstyevādau kuto'dya tat
]

`v 39 [
kāryaṃ cetkāraṇasyaitattathāpi brahmamātrakam |
pratibhāmātramevācchaṃ na tu jñapterghaṭādi sat
]

`v 40 [
jñānātmikaiva pratibhā jñaptirevākhilaṃ jagat |
jñaptirapyātmatattvaśrīḥ parijñātopaśāmyati
]

`v 41 [
jñeyābhāve tvanirvācyā śiṣyate śāśvataṃ śivam |
aśarīrādyaviśvātma sarvaṃ śāntamidaṃ tatam
]

`v 42 [
jñānajñeyajñaptimuktaṃ dṛṣanmaunamiva sthitam |
śāntāntaḥkaraṇāḥ svasthāḥ śilāputrakakośavat
]

`v 43 [
calantaścālayantaśca jñarūpā eva tiṣṭhata |
ajñeyajñatvasadrūpāḥ sadasatsārarūpiṇaḥ
]

`v 44 [
ākāśakośaviśadā bhavatā bhavabhūmayaḥ |
yathāsthitaṃ ca tiṣṭhanti gacchantaśca yathāgatam
]

`v 45 [
yathāprāptaikakarmāṇaḥ saṃpadyante budhāḥ param |
athavā sarvasaṃtyāgaśāntāntaḥkaraṇojjvalāḥ
]

`v 46 [
ekānteṣveva tiṣṭhantu citrakarmārpitā iva |
saṃkalpaśāntau saṃkalpapuravatsarvadākhilam
]

`v 47 [
svapnavacca prabuddhasya sadaivāstaṃ gataṃ jagat |
sanetrarūpānubhavaṃ jātito'ndha iva bhramaiḥ
]

`v 48 [
nirvāṇaṃ varṇayannajñastāpyate'ntarna śāmyati |
kalpanāṃśopadeśena loko'vidyāmayātmanā
]

`v 49 [
yena kenacidajñatvātkṛtārtho'smīti manyate |
akṛtārthaḥ kṛtārthatvaṃ jānanmaurkhyavimohitaḥ
]

`v 50 [
vijñāsyatyakṛtārthatvaṃ kṣaṇāntarakadarthanaiḥ |
upāyaṃ kalpanātmānamanupāyaṃ vidurbudhāḥ
]

`v 51 [
duḥkhadatvānnimeṣeṇa bhāvābhāvaiṣaṇabhramaiḥ |
jagadbhramaṃ parijñāya yadavāsanamāsitam |
virasāśeṣaviṣayaṃ taddhi nirvāṇamucyate
]

`v 52 [
ākhyāyikārthapratibhānametya saṃvetsyacidvāri bharāddravātmā |
avedyacidrūpamaśeṣamacchaṃ paśyanvinirvāsi jagatsvarūpam
]

`v 53 [
jātyandharūpānubhavānurūpaṃ yadāgamairbuddhamabodharūpam |
adhaspadīkṛtya tadāntare'sminbodhe nipatyānubhavo bhavābhūḥ
]