`v 1 [
aṣṭāśītyadhikaśatatamaḥ sargaḥ 188
śrīvasiṣṭha uvāca |
ādimattvamidaṃ proktametasya kalanasya yat |
parasmādadvitīyaṃ tattvadbodhāya na vāstavam
]

`v 2 [
evaṃvidhaṃ tatkalanamātmano'ṅgamakṛtrimam |
cetyonmukhacidābhāsaṃ jīvaśabdena kathyate
]

`v 3 [
kalanasyāsya nāmāni bahūni raghunandana |
śṛṇu tāni vicitrāṇi cetyonmukhacidātmanaḥ
]

`v 4 [
jīvanāccetanājjīvo jīva ityeva kathyate |
cetyonmukhatayā cittaṃ cidityeva nigadyate
]

`v 5 [
idamitthamiti spaṣṭabodhādbuddhirihocyate |
kalpanānmananajñatvānmana ityabhidhīyate
]

`v 6 [
asmīti pratyayādantarahaṃkāraśca kathyate |
cetanāḍhyamṛtaṃ cittamiti śāstravicāribhiḥ
]

`v 7 [
prauḍhasaṃkalpajālātsa puryaṣṭakamiti smṛtam |
saṃsṛteḥ prakṛtatvena prāthamyātprakṛtiḥ smṛtā
]

`v 8 [
bodhādavidyamānatvādavidyetyucyate budhaiḥ |
ityādikalanasyāsya nāmāni kathitāni te
]

`v 9 [
etatkalanamādyantamanākāramanāmayam |
ātivāhikadehoktyā samudāhriyate budhaiḥ
]

`v 10 [
ityevaṃ svapnasaṃkalpapuravattrijagadbhramaḥ |
bhātyarthakāryapyavapuḥ śūnyamapratighātmakam
]

`v 11 [
ityātivāhikaḥ prokto deho dehabhṛtāṃ vara |
cinnabhaścittadeho'sau śūnya ākāśatopi ca
]

`v 12 [
nāstameti na codeti jagatyāmokṣasaṃvidaḥ |
caturdaśavidhasyaikā bhūtasargasya cittabhūḥ
]

`v 13 [
atra saṃsāralakṣāṇi bhaviṣyanti bhavanti ca |
bhūtāni ca phalānīva yathā kālavyavasthayā
]

`v 14 [
eṣa cittamayo deho jagantyantarbahistvapi |
pratibimbamivādarśaḥ śūnya eva nabho yathā
]

`v 15 [
antarbahirapi jaganti ādarśaḥ pratibimbamiva dhatte tathāpi khaṃ śūnyaṃ evetyarthaḥ | 14
|
mahākalpasya paryante sarvanāśe sthire sthite |
mahāśūnyapade prauḍhe brahmātmani nirāmaye
]

`v 16 [
svataścitighano'cittvāccidbhānamidamātmanaḥ |
ātivāhikadehābhaṃ krameṇānena cetati
]

`v 17 [
sa ātivāhiko dehastadālokapravartitaḥ |
kaiścidbrahmeti kathitaḥ smṛtaḥ kaiścidvirāḍiti
]

`v 18 [
kaścitsanātanābhikhyaḥ kaścinnārāyaṇābhidhaḥ |
kaścidīśa iti khyātaḥ kaściduktaḥ prajāpatiḥ
]

`v 19 [
kākatālīyavadbhātāḥ pañca svendriyasaṃvidaḥ |
yatra yatra yathā teṣāṃ sthitāstatra tathā sthitāḥ
]

`v 20 [
evamatyantavitate saṃpanne dṛśyavibhrame |
na kiṃcidapi saṃpannaṃ sarvaśūnyaṃ tataṃ yataḥ
]

`v 21 [
anādimatparaṃ brahma na sadyannāsaducyate |
tadevedamanādyantaṃ tathāsthitamavedanam
]

`v 22 [
ātivāhikadehasya tasyānubhavataḥ svayam |
yāti vyasaninaḥ svapnaḥ kānteva paripuṣṭatām
]

`v 23 [
śūnyo'pyanākṛtirapi ghaṭākāro'nubhūyate |
svapnasaṃkalpayoḥ svasya dehasya jagato yathā
]

`v 24 [
bhavatyarthakaro'tyuccaistaccitkhasvapnavastuvat |
ākāśātmaka evograḥ padārtha iva bhāsate
]

`v 25 [
ātivāhikadeho'sau svato'nubhavati kramāt |
anākāropi śūnyopi svapnābho'sannapi sthitaḥ
]

`v 26 [
cetatyasthigaṇaḥ sthūlaṃ karādyavayavāvalim |
trikalomaśirāsnāyusaṃniveśatayā sthitam
]

`v 27 [
janmakarmehitasthānaṃ pariṇāmavayaḥsthitam |
deśakālakramābhogabhāvārthāyodbhavabhramam
]

`v 28 [
jarāmaraṇamādhānadaśadiṅmaṇḍalakramam |
jñānajñeyajñātṛbhāvamādimadhyāntavedanam
]

`v 29 [
kṣitijalagaganadivākarajanatāvyavahāranagaraśikharātmā |
svādhārādheyamayaṃ paśyati vapuṣaḥ purātanaḥ puruṣaḥ
]