`v 1 [
tripañcāśaḥ sargaḥ 53
śrīrāma uvāca |
yathā cetye cetanatā yathā kāle ca kālatā |
yathā ca vyomatā vyomni yathā ca jaḍatā jaḍe
]

`v 2 [
yathā vāyau ca vāyutvamabhūtādāvabhūtatā |
yathā spandātmani spando yathā mūrte ca mūrtatā
]

`v 3 [
yathā bhinne ca bhinnatvaṃ yathā'nante hyanantatā |
yathā dṛśye ca dṛśyatvaṃ yathā sargeṣu sargatā
]

`v 4 [
etatkrameṇa he brahman vada me vadatā vara |
āditaḥ pratipādyaiva bodhyante hyalpabodhinaḥ
]

`v 5 [
śrīvasiṣṭha uvāca |
tadanantaṃ mahākāśaṃ mahācidghanamucyate |
avedyacidrūpamayaṃ śāntamekaṃ samasthiti
]

`v 6 [
brahmaviṣṇvīśvarādyante mahāpralayanāmani |
śabdārthe rūḍhimāpanne yacchuddhamavaśiṣyate
]

`v 7 [
sargasya kāraṇaṃ tatra na kiṃcidupapadyate |
malamākārabījādi māyāmohabhramādikam
]

`v 8 [
kevalaṃ śāntamatyacchamādyantaparivarjitam |
tadvidyate yatra kila khamapi sthūlamaśmavat
]

`v 9 [
na ca nāstīti tadvaktuṃ yujyate cidvapuryadā |
na caivāstīti tadvaktuṃ yuktaṃ śāntamalaṃ tadā
]

`v 10 [
nimeṣe yojanaśate prāptāyāmātmasaṃvidi |
madhye tasyāstu yadrūpaṃ rūpaṃ tasya padasya tat
]

`v 11 [
sabāhyābhyantare śānte vāsanāviṣayabhrame |
sarvacintāvihīnasya prabuddhasyārdharātrataḥ
]

`v 12 [
śāntaṃ niḥsukhaduḥkhasya puruṣasyaiva tiṣṭhataḥ |
yadaspandi manorūpaṃ rūpaṃ tasya padasya tat
]

`v 13 [
tṛṇagulmāṅkurādīnāṃ sattāsāmānyamātatam |
yadudbhavodbhavaṃ rūpaṃ rūpaṃ tasya padasya tat
]

`v 14 [
tasminpade jagadrūpaṃ yadidaṃ dṛśyate sphuṭam |
sakāraṇamivākārakarālamiva bhedavat
]

`v 15 [
tatsarvaṃ kāraṇābhāvānna jātaṃ na ca vidyate |
nākārayuktaṃ na jaganna ca dvaitaikyasaṃyutam
]

`v 16 [
yadakāraṇakaṃ tasya sattā nehopapadyate |
svayaṃ nityānubhūte'rthe ko'trāpahnavaśaktimān
]

`v 17 [
na ca śūnyamanādyantaṃ jagataḥ kāraṇaṃ bhavet |
brahmāmūrtaṃ samūrtasya dṛśyasyābrahmarūpiṇaḥ
]

`v 18 [
astu tarhyasato jagataḥ śūnyameva kāraṇaṃ tatrāha - na ceti | śūnyasya kāraṇatve
tasya deśādiparicchedābhāvātsarvaṃ sarvatra sadā syādityāśayena viśinaṣṭi -
anādyantamiti | ata eva na brahmāpi kāraṇam | amūrtasya
mūrtākārapariṇāmāyogāccetyāha - brahmeti | tathā ca śrutiḥ
tadetadbrahmāpūrvamanaparamanantaramabāhyamayamātmā brahma sarvānubhūḥ iti | 17
|
tasmāttatra jagadrūpaṃ yadā bhātaṃ tadeva tat |
svayameva tadā bhāti cidākāśamiti sthitam
]

`v 19 [
jagaccidbrahmabhāvācca tathā bhāvo bhramādiva |
sarvamekamajaṃ śāntamadvaitaikyamanāmayam
]

`v 20 [
pūrṇātpūrṇaṃ visarati pūrṇe pūrṇaṃ virājate |
pūrṇamevoditaṃ pūrṇe pūrṇameva vyavasthitam
]

`v 21 [
śāntaṃ samaṃ samudayāstamayairvihīnamākāramuktamajamambaramacchamekam
|
sarvaṃ sadā sadasadekatayoditātma nirvāṇamādyamidamuttamabodharūpam
]