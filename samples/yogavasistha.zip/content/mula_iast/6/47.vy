`v 1 [
saptacatvāriṃśaḥ sargaḥ 47
śrīvasiṣṭha uvāca |
saṃsārabhārasuśrāntaḥ saṃkaṭeṣu luṭhattanuḥ |
yo'bhivāñchati viśrāntiṃ tasya kramamimaṃ śṛṇu
]

`v 2 [
pūrvaṃ vivekakaṇikā yadā svahṛdi jāyate |
saṃsāranirvedamayī kāraṇādvāpyakāraṇāt
]

`v 3 [
tadā śrayanti sacchāyānsādhutvasuviśālinaḥ |
adhvaśramaharāṃstāpataptā mārgatarūniva
]

`v 4 [
dūre pariharatyajñānyajñayūpānivādhvagaḥ |
snānadānatapoyajñānkaroti vibudhānugaḥ
]

`v 5 [
peśalaṃ cānurūpaṃ ca vyavahāramakṛtrimam |
lokyamāhlādanaṃ dhatte candrabimbamivāmṛtam
]

`v 6 [
paraprajñānugo bhavyaḥ parārthaparipūrakaḥ |
pavitrakarmarasikaḥ ko'pi saumyaḥ pravartate
]

`v 7 [
navanītasthalīvā'cchā snigdhā mṛdvī manoharā |
janaṃ sukhayati svādvī tadīyā navasaṃgatiḥ
]

`v 8 [
śītalāni pavitrāṇi caritāni vivekinaḥ |
indorivāṃśujālāni janaṃ śītalayantyalam
]

`v 9 [
na tathodyānakhaṇḍeṣu puṣpaprakarahāriṣu |
viśrāmyate vītabhayaṃ yathā sādhusamāgame
]

`v 10 [
mandākinīpayāṃsīva saṃgatāni vivekinām |
prakṣālayanti pāpāni prayacchanti viśuddhatām
]

`v 11 [
vivekiṣu virakteṣu saṃsārottaraṇārthiṣu |
janaḥ śītalatāmeti himahāragṛheṣviva
]

`v 12 [
nanu nāmaratodārā yā vivekini vidyate |
suragandharvakanyāsu mānavīṣu na vidyate
]

`v 13 [
prajñā prasādamāyāti kramāducitakarmaṇaḥ |
antaḥkaroti śāstrārthamarthaṃ mukurabhūriva
]

`v 14 [
satprajñonnatimāyāti śāstrārtharasaśālinī |
vivekini vilāsena kadalīva mahāvane
]

`v 15 [
antarevānubhavati sarvārthānpratibimbitān |
ādarśavadaśeṣeṇa prajñā nairmalyaśālinī
]

`v 16 [
sādhusaṃgamaśuddhātmā śāstrārthaparimārjitaḥ |
prājño bhātyuddhṛtaṃ vahneragniśaucamivāṃśukam
]

`v 17 [
kacatkāñcanakāntena vimalālokakāriṇā |
bhuvanaṃ bhāskareṇeva bhāti sādhuḥ svatejasā
]

`v 18 [
tathānugacchati prājñaḥ śāstrasādhusamāgamau |
yathātyantānuṣaṅgeṇa tāvevānubhavatyasau
]

`v 19 [
śāstramabhyāsena sādhorguroḥ samāgamaṃ ca sevādinā tathā anugacchati
nirantaramanusarati yathā atyantaṃn tadupadiṣṭārthābhiniveśalakṣaṇena tadanuṣaṅgeṇa
svapne'pi taccintanatacchuśrūṣāparastāvevānubhavati na tadanuṣaṅgeṇa svapne'pi
taccintanatacchuśrūṣāparastāvevānubhavati na tadatiriktaṃ svaśarīrādikamapītyarthaḥ |
18 |
kramātsajjanatāmetya śāstrārthabharabhāvitaḥ |
bhāti bhogānadhaḥkurvanpañjarādiva nirgataḥ
]

`v 20 [
bhogābhigamadaurbhāgyaṃ dinānudinamujjhatā |
tena tatkulamābhāti tārācakramivendunā
]

`v 21 [
abhogakṛpaṇā kāpi na caivāsya pravartate |
mukhe kāntirapūrvaiva candre rāhumṛte yathā
]

`v 22 [
tṛṇīkṛtatrijagatāṃ mahatāmabhidheyatām |
sa yāti kalpaviṭapī nabhasīva divaukasām
]

`v 23 [
bhogānāṃ dveṣaṇenāntarlajjamāno manasyapi |
bhogānāmapyasaṃpattyā paramaṃ parituṣyati
]

`v 24 [
svā evopahasatyantastaruṇīstaralakriyāḥ |
khedasmeramukho jātīrjātismara ivādhamaḥ
]

`v 25 [
prāktanīstaruṇīḥ rāgādiprauḍhāḥ svāḥ svīyā eva bhogautsukyataralāḥ kriyāḥ
sāṃprataṃ smaran khedena smeramukhaḥ sannantarupahasati yathā
adhamaścāṇḍālādirdaivājjātismaraḥ san svā eva jātīrantarupahasati tadvadityarthaḥ | 24
|
atha taṃ draṣṭumāyānti sauhārdenaiva sādhavaḥ |
bhūmāvivoditaṃ candraṃ vismayotphullalocanāḥ
]

`v 26 [
nityānādṛtabhogo'sau tato'pyucitayā dhiyā |
prāptamapyucitārambhaṃ bhogaṃ na bahumanyate
]

`v 27 [
pūrvaṃ saṃsṛtivairasyamantarevoditātmanaḥ |
jāyate jīrṇajāḍyasya pākādiva śarattaroḥ
]

`v 28 [
tataḥ sajjanasaṃparkamudarkaśreyase svayam |
karoti svasthatāgṛdhrurbhiṣagāśrayaṇaṃ yathā
]

`v 29 [
tenodāramatirbhūtvā śāstrārtheṣu nimajjati |
mahānmahāprasanneṣu saraḥsviva mahāgajaḥ
]

`v 30 [
sajjano hi samuttārya vipadbhyo nikaṭasthitam |
niyojayati saṃpatsu svālokeṣviva bhāskaraḥ
]

`v 31 [
parasvādānaviratiḥ pūrvameva pravartate |
vivekino nijārtheṣu saṃtoṣaścopajāyate
]

`v 32 [
parasvādānavirataḥ saṃtoṣāmṛtanirbharaḥ |
vivekī kramaśaḥ svārthānapyupekṣitumicchati
]

`v 33 [
dadāti kaṇapiṇyākaśākādyapi hi yācate |
tenaivābhyāsayogena svamāṃsāni dadātyasau
]

`v 34 [
nūnaṃ vilayacittānāṃ vivekamanudhāvatām |
maurkhyaṃn laghutvamāyāti dhāvatāmiva goṣpadam
]

`v 35 [
vivekānusaraṇakrameṇa vilīyamānacittānāṃ dine dine jñānapracayenājñānaṃn kṣīyata
ityāha - nūnamiti | maurkhyamajñānam | laghutvamapakṣayeṇālpatām | yathā
dhāvatāmaśvādīnāṃ goṣpadamanāyāsollaṅghyatvalakṣaṇaṃ kṣudratvamāyāti tadvat |
34 |
parārthādānaviratiṃ `note[parasvādāna iti ṭīkānuguṇaḥ pāṭhaḥ |]
pūrvamabhyasya yatnataḥ |
āhartavyā vivekena tataḥ svārtheṣvaraktatā
]

`v 36 [
tato bhoganirāsena saha svārthanirākṛtiḥ |
paramāyai suviśrāntyai kriyate kṛtibhiḥ kramāt
]

`v 37 [
na tādṛśaṃ jagatyasminduḥkhaṃn narakakoṭiṣu |
yādṛśaṃ yāvadāyuṣkamarthopārjanaśāsanam
]

`v 38 [
āsane śayane yāne gamane ramaṇe jane |
ādhicintāparā `note[arthacintā iti pāṭhaḥ |] eva nanu mūḍhā vidantu tām
]

`v 39 [
nanvarthā vitatānarthāḥ saṃpadaḥ saṃtatāpadaḥ |
bhogā bhavamahārogā viparītena bhāvitāḥ
]

`v 40 [
tāvannāyāti vairasyaṃ cintāviṣayajṛmbhaṇaiḥ |
yāvadarthamahānartho na kadarthārthamarthyate
]

`v 41 [
anuttamasukhaṃ yasmai cirāya parirocate |
jagattṛṇaśikhādṛṣṭyā so'rthaṃ paśyatu śāmyatu
]

`v 42 [
bhūribhāvavikārāṇāṃ jarāmaraṇakarmaṇām |
dainyadaurātmyadāhānāmarthaḥ sārtha iti smṛtaḥ
]

`v 43 [
asmiñjagati jantūnāṃ jarāmaraṇaśālinām |
ajarāmaraṇaṃ kartuṃ saṃtoṣo'sti rasāyanam
]

`v 44 [
saṃtoṣa eva vairāgyapratiṣṭhāpanena sarvaduḥkhahārīti taṃ praśaṃsati - asminniti |
43 |
vasanto nandannodyānamindurapsarasaḥ smṛtāḥ |
ityekataḥ samuditaṃ saṃtoṣāmṛtamekataḥ
]

`v 45 [
sarasaḥ prāvṛṣevāntaḥ saṃtoṣeṇaiva pūrṇatā |
gambhīrāṃ śītalāṃ hṛdyāṃ prasannāṃ rasaśālinīm
]

`v 46 [
sādhurojasvitāmetya saṃtoṣeṇaiva rājate |
supuṣpitavanākāro vasanteneva pādapaḥ
]

`v 47 [
pādapīṭhaparāmarśapiṣṭakīṭavadīhate |
dīnaprakṛtirarthārthī duḥkhādduḥkhāntaraṃ vrajet
]

`v 48 [
kallolavikalāḥ kṣubdhasamudrapatitā iva |
nāpnuvanti sthitiṃ svasthāṃ vikṛtākṛtayo'rthinaḥ
]

`v 49 [
saṃpadaḥ pramadāścaiva taraṅgottuṅgabhaṅgurāḥ |
kastāsvahiphaṇacchatracchāyāsu ramate budhaḥ
]

`v 50 [
arthopārjanarakṣāṇāṃ jānannapi kadarthanām |
yaḥ karoti spṛhāṃ mūḍho nṛpaśuṃ taṃ na saṃspṛśet
]

`v 51 [
manaso bāhyamārambhamāntaraṃ ca lunāti yaḥ |
samaṃ vaitṛṣṇyadātreṇa tasya kṣetraṃ prakāśate
]

`v 52 [
jagattvamajñasaṃbuddhaṃ jño vidannasadeva yat |
satīva tatra sphurati tadanabhyāsajṛmbhitam
]

`v 53 [
saṃsāranirvedadaśāmupetya satsaṃgamaṃ śāstramupetya tena |
śāstrārthabhāvena nirasya bhogānvaitṛṣṇyadārḍhyātparamārthameti
]