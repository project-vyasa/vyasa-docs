`v 1 [
triṣaṣṭyadhikaśatatamaḥ sargaḥ 163
śrīrāma uvāca |
vinendriyajayenedaṃ nājñatvamupaśāmyati |
tadindriyāṇi jīyante kathaṃ kathaya me mune
]

`v 2 [
śrīvasiṣṭha uvāca |
na ca prabhūtabhogeṣu na puṃstve na ca jīvite |
na cendriyajayonmuktau dīpastanudṛśo yathā
]

`v 3 [
tadindriyajaye yuktimimāmavikalāṃ śṛṇu |
siddhimeti svayatnena sukhena tanuretayā
]

`v 4 [
cinmātraṃ puruṣaṃ viddhi cetanājjīvanāmakam |
yaccetati sa jīvo'ntastanmayo bhavati kṣaṇāt
]

`v 5 [
saṃvitprayatnasaṃbodhaniśitāṅkuśakarṣaṇaiḥ |
manomataṅgajaṃ mattaṃ jitvā jayati nānyathā
]

`v 6 [
cittamindriyasenāyā nāyakaṃ tajjayājjayaḥ |
upānadgūḍhapādasya nanu carmāvṛtaiva bhūḥ
]

`v 7 [
saṃvidaṃ saṃvidākāśe saṃropya hṛdi tiṣṭhataḥ |
svayameva manaḥ śāmyennīhāra iva śāradaḥ
]

`v 8 [
svasaṃvidyatnasaṃrodhādyathā cetaḥ praśāmyati |
na tathāṅga tapastīrthavidyāyajñakriyāgaṇaiḥ
]

`v 9 [
yacca saṃvedyate kiṃcittattatsaṃvidi saṃvidā |
nūnaṃ vismāryate yatnādbhogānāmiti tajjayaḥ
]

`v 10 [
svasaṃvedanayatnena viṣayāmiṣato'niśam |
kiṃcitsaṃrodhitā saṃvittatprāptaṃ vaibudhaṃ padam
]

`v 11 [
svadharmavyavahāreṇa yadāyāti tadeva me |
rocate nānyadityeva pade vajradṛḍhībhava
]

`v 12 [
saṃvitpravṛttimartheṣu viruddheṣu vivarjayan |
arjayañchamasaṃtoṣau yaḥ sthitaḥ sa jitendriyaḥ
]

`v 13 [
saṃvidrasikatāsvantastathā nīrasatāsu ca |
yasya nodvegamāyāti manastasyopaśāmyati
]

`v 14 [
saṃvitprayatnasaṃrodhānmanaḥ svāyanamujjhati |
cetaścapalatonmuktaṃ vivekamanudhāvati
]

`v 15 [
vivekavānudārātmā vijitendriya ucyate |
vāsanāvīcivegena bhavābdhau na sa muhyate
]

`v 16 [
sādhusaṃparkasacchāstrasamālokanato'niśam |
jitendriyo yathāvastu jagatsatyaṃ prapaśyati
]

`v 17 [
satyāvalokanācchāntimeti saṃsārasaṃbhramaḥ |
marāviva jalajñānaṃ mithyāpatanaduḥkhadam
]

`v 18 [
acetyameva cinmātramidaṃ jagaditi sthitam |
ityeva satyabodhasya bandhamokṣadṛśau kutaḥ
]

`v 19 [
anākāraṃ yathā vāri kṣīṇaṃ vahati no punaḥ |
akāraṇaṃ tathā dṛśyaṃ jñānacchinnaṃ na rohati
]

`v 20 [
vedanaṃ vyomamātraṃ tvamahamityādirūpadhṛk |
varjayitvaitadanyatsyādahamityādikaṃ jagat
]

`v 21 [
avidyāmātramevedamahamityādikaṃ jagat |
cidvyomnyeva sthitaṃ śāntaṃ śūnyamātraśarīrakam
]

`v 22 [
idaṃ cidvyomni cicchāyā jagadityeva bhāsate |
śūnyaśūnyaiva ciccāsau śūnyā cetyeva niścayaḥ
]

`v 23 [
svapnadarśanadṛṣṭāntaḥ kena nāmātra khaṇḍyate |
asanmayo'nubhūtaśca svānubhūto'pyasanmayaḥ
]

`v 24 [
so'ṅga saṃvittimātrātmā yadyadrājyaṃ mahīyate |
nakartṛkarmakaraṇaṃ rūpaṃ tadvajjagacciteḥ
]

`v 25 [
akartṛkarmakaraṇamahaṃ cidghanamātrakam |
jagaccedamanirdeśyaṃ svasaṃvedanalakṣaṇam
]

`v 26 [
yathā svapneṣu maraṇamanubhūtaṃ na vidyate |
marau jalecchā'vidyeyaṃ vidyamānā na vidyate
]

`v 27 [
cidvyomnā kācakacyaṃ svaṃ sargādau vyomni cetitam |
jagadityeva nirmūlaṃ kākatālīyavatsvayam
]

`v 28 [
nirmūlameva bhātīdamabhātamapi bhātavat |
tasmādyadbhāsuramidaṃ tattadeva padaṃ viduḥ
]

`v 29 [
jīvādikacanaṃ tvatra yadbhātīdaṃ tadeva tat |
śūnyataiva bhavedvyoma vāryevāvartavṛttayaḥ
]

`v 30 [
yathāvayavino rūpamekaṃ sāvayavaṃ bhavet |
ekaṃ jīvādyavayavaṃ brahmānavayavaṃ tathā
]

`v 31 [
ābhāsamātraṃ dṛśyātma cinmātraṃ śāntamavyayam |
sthitamāsthāḥ `note[sthitamacchamiti pāṭho yuktaḥ |] kimetasminsvabhāve sve
vicāryate
]

`v 32 [
nādyantamantaḥkalanāḥ kāścitsanti pare pade |
tadrūpamevāvidyeyaṃ nāvidyā tviha vidyate
]

`v 33 [
jīvaḥ svapnādviśañjāgrajjāgrataḥ svapnamāviśan |
prabuddho vāstvabuddho vāpyekarūpatayā sthitaḥ
]

`v 34 [
sthite suṣuptaturye dve sadā svapne'tha jāgrati |
jāgratsvapnāvekameva turyaṃ vetti tu buddhadhīḥ
]

`v 35 [
jāgratsvapnaḥ suṣuptaṃ ca sarvaṃ turyaṃ prabodhinaḥ |
nāvidyā vidyate tasya dvayastho'pyeva so'dvayaḥ
]

`v 36 [
dvaitamadvaitamityetadahaṃtvamidamityapi |
niravidyasya kalanā kutaḥ kāpyambaraṃ kutaḥ
]

`v 37 [
dvaitādvaitasamudbhedairvākyasaṃdarbhavibhramaiḥ |
krīḍantyabuddhāḥ śiśavo bodhavṛddhā hasanti tān
]

`v 38 [
dvaitādvaitavivādehā hṛdayākāśamañjarī |
vinaitayeha nodeti prabodhākāśamārjanam
]

`v 39 [
suhṛdbhūtvā vivādena dvaitādvaitavicāraṇā |
kṛtā hṛdayagehe'ntaravidyābhasmamārjanī
]

`v 40 [
taccittāstadgataprāṇā bodhayantaḥ parasparam |
kathayantaśca tannityaṃ tuṣyanti ca ramanti ca
]

`v 41 [
teṣāṃ satatayuktānāṃ bhajatāṃ prītipūrvakam |
jāyate buddhiyogo'sau yena `note[yenāsau yāti tatpadaṃ iti
pāṭho'pekṣitaṣṭīkānurodhena |] te yānti tatpadam
]

`v 42 [
kilopakurute yatnāttṛṇamātrāvagopane |
kathaṃ sidhyatyayatnena trailokyagaṇagopanam
]

`v 43 [
adhyātmavyasanonmuktaṃ tataṃ hṛtsthā'dhamā'prabhu |
upahāsāspadaṃ yasyā jagadapyuttamasthiteḥ
]

`v 44 [
kiṃ nāmedaṃ kila sukhaṃ yadrājyādimanoṅkuram |
tattvajñānaikaviśrāntau devarājapadaṃ tṛṇam
]

`v 45 [
suptāḥ prabuddhāḥ paśyanti dṛśyaṃ dṛśye ratā yathā |
tathā dṛśye'ratāḥ śāntāḥ santaḥ paśyanti tatpadam
]

`v 46 [
vinā yatnabhareṇedaṃ na kadācana siddhyati |
mahato'bhyāsavṛkṣasya phalaṃ viddhi paraṃ padam
]

`v 47 [
idaṃ bahūktametena kimeteneti durmatiḥ |
na grāhyaitāvatāpyukte nādatte nedamajñadhīḥ
]

`v 48 [
bhūyobhūyaḥ parāvṛttyā ciramāsvādyate yadi |
śrūyate kathyate cedaṃ tajjñenājñena bhūyate
]

`v 49 [
yastvekavāramālokya dṛṣṭamityeva saṃtyajet |
idaṃ sa nāma śāstrebhyo bhasmāpyāpnoti nādhamaḥ
]

`v 50 [
idamuttamamākhyānamadhyeyaṃ vedavatsadā |
vyākhyeyaṃ pūjanīyaṃ ca puruṣārthaphalapradam
]

`v 51 [
yadasmātprāpyate śāstrāttattadvedādavāpyate |
asminjñāte kriyā jñānaṃ dvayaṃ yāti pavitratām
]

`v 52 [
vedāntatarkasiddhāntastvasminjñāte ca budhyate |
idamuttamamākhyānaṃ vyākhyātaṃ śāstradṛṣṭiṣu
]

`v 53 [
kāruṇyādbhavatāmetadahaṃ vacmi na māyayā |
bhavantastvavagacchanti māyāmetadvicāryatām
]

`v 54 [
asmācchāstravarādbodhā jāyante ye vicāritāt |
lavaṇairvyañjanānīva bhānti śāstrāntarāṇi taiḥ
]

`v 55 [
anāryamidamākhyānamityanādṛtya dṛśyadhīḥ |
mā bhavaṃtvātmahantāro bbhavanto bhavabhāginaḥ
]

`v 56 [
tātasya kūpo'yamiti bruvāṇāḥ kṣāraṃ jalaṃ kāpuruṣāḥ pibanti |
yathā bhavanto vivicāravantastathāniśaṃ mā bhavatājñatāptyai
]