`v 1 [
tripañcāśadadhikaśatatamaḥ sargaḥ 153
anyamuniruvāca |
āvayoścaratostasminvane cirataraṃ tapaḥ |
mṛgānusaraṇaśrānto mṛgavyādha upaiṣyati
]

`v 2 [
taṃ tvaṃ svabhāvapuṇyābhiḥ kathābhirbodhayiṣyasi |
tapastatraiva vipine sa viraktaścariṣyati
]

`v 3 [
tatastapasvicaryāṇāmātmajñānabubhutsayā |
madhye sa svapnajijñāsuḥ prakṣyati svapnasaṃkathām
]

`v 4 [
kathayiṣyasi tasmai tvamātmajñānamakhaṇḍitam |
svapnākhyena prasaṅgena so'to yogyo bhaviṣyati
]

`v 5 [
ityanena prakāreṇa gurustasya bhaviṣyasi |
tena tāta mayokto'si girā vyādhaguro iti
]

`v 6 [
iti te sarvamākhyātaṃ yathāyaṃ saṃsṛtibhramaḥ |
yathāhaṃ yādṛśaśca tvamiha yatte bhaviṣyati
]

`v 7 [
iti tenāhamuktaḥ sanvismayākulayā dhiyā |
tena sārdhaṃ vimṛśyaitatparaṃ vismayamāgataḥ
]

`v 8 [
atha rātryāṃ vyatītāyāṃ sa prabhāte mahāmuniḥ |
tathā saṃpūjito yena tatraiva ratimāptavān
]

`v 9 [
anantaraṃ gṛhe tasmiṃstasmingrāmagṛhe tathā |
sthitāvāvāṃ sthiramatī kṛtabhāvau parasparam
]

`v 10 [
tato vahati kālo'yamṛtusaṃvatsarātmakaḥ |
sthito'hamāgatānbhāvāṃstyajangṛhṇangiriryathā
]

`v 11 [
nābhivāñchāmi maraṇaṃ nābhivāñchāmi jīvitam |
yathā sthito'smi tiṣṭhāmi tathaiva vigatajvaram
]

`v 12 [
tato vicāritaṃ tatra tanmayā dṛśyamaṇḍalam |
kiṃ kāraṇamidaṃ tu syātkimayaṃ vetti cetasā
]

`v 13 [
ko'yaṃ padārthasaṃghātaḥ kiṃ nāmaitasya kāraṇam |
astyasminsvapnasaṃdarśe cidvyomaikasvarūpiṇi
]

`v 14 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
cinmātranabha evaite kacantyātmanyavasthitam
]

`v 15 [
ciccandrikācaturdikkamavabhāsaṃ tanoti yat |
tadidaṃ jagadābhāti citramapratighātma khe
]

`v 16 [
neme'drayo na ceyaṃ bhūrnedaṃ khaṃ nāyamapyaham |
cinmātravyomakacanamidamābhāti kevalam
]

`v 17 [
padārthajātasyāsya syātkiṃ nāma bata kāraṇam |
piṇḍagrahe hetunā tu vinā ko'pyarthasaṃbhavaḥ
]

`v 18 [
yadā cinmātrakacanaṃ tarhi kāraṇameva nāsti piṇḍagrahataddhetvoraprasiddherityāha ##-
bhrāntimātramidaṃ cetsyādbhrānteḥ kiṃ nāma kāraṇam |
draṣṭā mantā ca ko bhrānteḥ kāraṇaṃ vā kva kīdṛśam
]

`v 19 [
yasyāhamavasaṃ saṃvinmātrakaṃ hṛdayaujasi |
asau mayā saha gataḥ kilāśeṣeṇa bhasmasāt
]

`v 20 [
tasmādidamanādyantaṃ cidābhāmātramambaram |
akartṛkarmakaraṇaṃ rūpaṃ cidghanamakramam
]

`v 21 [
idaṃ cidvyomakacanaṃ ghaṭāvaṭapaṭādikam |
sphuṭaṃ kuta ivākāri ghaṭāvaṭapaṭādyataḥ
]

`v 22 [
nāpi cinmātrakacanaṃ cinmātraṃ vyoma kevalam |
tasya kiṃ kacanaṃ kīdṛk kathaṃ kacati kiṃ nabhaḥ
]

`v 23 [
cinmātrakacanamiti buddhirapi rāhoḥ śira itivadvikalpamātram |
ṣaṣṭhītatpuruṣaprayojakayorbhedasaṃbandhayoraprasiddherityāśayenāha - nāpīti | 22
|
ayaṃ phenaścidambhodheḥ kimasya kacanaṃ navam |
kacatsvabhāva evāyamanantaścidghanaḥ sthitaḥ
]

`v 24 [
cinmātrakacanaṃ śuddhaṃ brahma bṛṃhitacidghanam |
idaṃ jagadivābhāti kva dṛśyaṃ draṣṭṭatā kutaḥ
]

`v 25 [
ādyantavarjitamameyamanādimadhyamekaṃ vibhuṃ `note[vibhumiti puṃstvamārṣam
|] vigatakāraṇakāryasattvam |
sattāmayaṃ bhuvanaśailadigantanānā'nānātmakaṃ kimapi cetanameva sarvam
]