`v 1 [
catuḥṣaṣṭyadhikaśatatamaḥ sargaḥ 164
śrīvasiṣṭha uvāca |
jīvāṇavo jagatyantaścidādityāṃśumaṇḍale |
yatra te'vayavāstulyāstenānavayavātmatā
]

`v 2 [
sarvaṃ prāpya paraṃ bodhaṃ vastu svaṃ rūpamujjhati |
punastadekavākyatvānna kiṃcidvāparaṃ bhavet
]

`v 3 [
sarvāsvevāsvavasthāsu tattvajñaviṣayaṃ tu tat |
paramevāmalaṃ brahma nānyatkiṃcitkadācana
]

`v 4 [
yaccātattvajñaviṣayaṃ tajjānāti sa eva tat |
vayaṃ tu vidmo nāhaṃ tvaṃ nātattvajñaṃ na vastu tat
]

`v 5 [
ayaṃ sohamayaṃ cājñaḥ satyo'yamiti buddhayaḥ |
saṃbhavanti na tattvajñe kva merau mṛgatṛṣṇikā
]

`v 6 [
yathaikadravyaniṣṭhe hi citte'nyadravyasaṃvidaḥ |
na bhavanti pare tadvannānyāstiṣṭhanti saṃvidaḥ
]

`v 7 [
idaṃ nāsīnna cotpannaṃ na cāsti na bhaviṣyati |
jagadbrahmaiva sadrūpamidamitthamavasthitam
]

`v 8 [
cinnabhaḥ kācakacyaṃ ca svātmanyevāvatiṣṭhate |
jagadityeva tattatra tajjñānenaiva cetyate
]

`v 9 [
svapneṣu kalpanapureṣu yathānyadasti cinmātramacchagaganaṃ nanu varjayitvā |
no kiṃcanāpi na ca rūpamarūpakeṣu rūpaṃ tathā jagati saṃprati jāgradākhye
]

`v 10 [
pūrvaṃ kilodbhavati kiṃcana nāma nedaṃ taccāvabhāti tadanādi khameva cittvāt |
no kāraṇaṃ na sahakāri kilāsti yatra tasmātsvayaṃ bhavati vastviti keyamuktiḥ
]

`v 11 [
tasmātsvayaṃ bhavati neha hi kaścidādau brahmādayo'jñaviditā na ca nāma santi |
vyomedamātatamayaṃ sa itaḥ svayṃbhūrityādi cidgaganameva citā vibhāti
]