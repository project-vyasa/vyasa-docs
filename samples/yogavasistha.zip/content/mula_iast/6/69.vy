`v 1 [
ekonasaptatitamaḥ sargaḥ 69
śrīvasiṣṭha uvāca |
jagadaṅgamanābhāsamadṛśyaṃ dṛśyavatsthitam |
parayā dṛśyate dṛṣṭyā tadbrahmaiva nirāmayam
]

`v 2 [
tatra śailasaritsrotolokālokāntarabhramāḥ |
bhānti te paramādarśe mahāvyomani bimbitāḥ
]

`v 3 [
sā praviṣṭā tataḥ sargaṃ tamanargalaceṣṭitā |
ahamapyaviśaṃ tatra saṃkalpātmā tayā saha
]

`v 4 [
yāvatsā tatra vairiñcaṃ lokamāsādya sodyamā |
upaviṣṭā viriñcasya puraḥ paramaśobhanā
]

`v 5 [
vaktyayaṃ muniśārdūla patirme pāti māmimām |
vivāhārthamanenāhaṃ janitā manasā purā
]

`v 6 [
purāṇaḥ puruṣo'pyeṣa māmapyadya jarāgatām |
na vivāhitavāṃstena virāgamahamāgatā
]

`v 7 [
virāgameṣo'pyāyāto gantumicchati tatpadam |
yatra na draṣṭṭatā naiva dṛśyatā na tu śūnyatā
]

`v 8 [
mahāpralaya āsanno jagatyasmiṃśca saṃprati |
dhyānānna ca calatyeṣu śailamaunādivācalaḥ
]

`v 9 [
tasmānmāmenamapi ca bodhayitvā munīśvara |
āmahākalpasargādau parame pathi yojaya
]

`v 10 [
ityuktvā māmasau tasya bodhāyedamuvāca ha |
nāthāyaṃ muninātho'dya sadma saṃprāptavānidam
]

`v 11 [
eṣo'nyasmiñjagadgehe brahmaṇastanayo muniḥ |
pūjayainaṃ gṛhāyātaṃ gṛhasthagṛhapūjayā
]

`v 12 [
budhyatāmarghyapādyena pūjyatāṃ munipuṅgavaḥ |
mahanmahatsaparyābhirmahātmabhyo hi rocate
]

`v 13 [
tayetyukte mahābuddhirbubudhe sa samādhitaḥ |
svasaṃvittidravātmatvādāvarta iva vāridhau
]

`v 14 [
śanairunmīlayāmāsa nayane nayakovidaḥ |
madhuḥ śiśirasaṃśāntāvavanau kusume yathā
]

`v 15 [
śanaiḥ prakaṭayāmāsustānyaṅgānyasya saṃvidam |
madhupallavajālāni javānīva navaṃ rasam
]

`v 16 [
surasiddhāpsaraḥsaṅghāḥ samājagmuḥ samaṃtataḥ |
yathā haṃsālayo lolāḥ prātarvikasitaṃ saraḥ
]

`v 17 [
dadarśāsau puraḥprāptaṃ māṃ ca tāṃ ca vilāsinīm |
uvācātha vaco vedhāḥ praṇavasvarasundaram
]

`v 18 [
anyajagadbrahmovāca |
karāmalakavaddṛṣṭasaṃsārāsārasāra he |
jñānāmṛtamahāmbhoda mune svāgatamastu te
]

`v 19 [
padavīmasi saṃprāpta imāmatidavīyasīm |
dūrādhvasupariśrānta idamāsanamāsyatām
]

`v 20 [
ityukte tena bhagavannabhivādaya ityaham |
vadanmaṇimaye pīṭhe niviṣṭo dṛṣṭidarśite
]

`v 21 [
athāmararṣigandharvamunividyādharoditāḥ |
prastutāḥ stutayaḥ pūjā natayaḥ sthitinītayaḥ
]

`v 22 [
tato muhūrtamātreṇa sarvabhūtagaṇodite |
śānte praṇatisaṃrambhe tasyoktaṃ brahmaṇo mayā
]

`v 23 [
sarvairbhūtagaṇairgandharvādibhirudite vāgādibhiḥ kṛte praṇatisaṃrambhe śānte sati |
22 |
kimidaṃ `note[atra muniruvāca ityapekṣitam |] bhūtabhavyeśa yadiyaṃ
māmupāgatā |
vakti jñānagirāsmāṃstvaṃ bodhayeti prayatnataḥ
]

`v 24 [
bhavānbhūteśvaro deva sakalajñānapāragaḥ |
iyaṃ tu kāmamūrkhā kiṃ brūte brūhi jagatpate
]

`v 25 [
kathameṣā tvayā deva jāyārthaṃ janitā satī |
neha jāyāpadaṃ nītā nītā virasatāṃ katham
]

`v 26 [
anyajagadbrahmovāca |
mune śṛṇu yathāvṛttamidaṃ te kathayāmyaham |
yathāvṛttamaśeṣeṇa kathanīyaṃ yataḥ satām
]

`v 27 [
asti tāvadajaṃ śāntamajaraṃ kiṃcideva sat |
tataścitkacanaikāntarūpiṇaḥ kacito'smyaham
]

`v 28 [
ākāśarūpa evāhaṃn sthita ātmani sarvadā |
bhaviṣyati sthite sarge svayaṃbhūriti nāma me
]

`v 29 [
vastutastu na jāto'smi na ca paśyāmi kiṃcana |
cidākāśaścidākāśe tiṣṭhāmyahamanāvṛtaḥ
]

`v 30 [
yadayaṃ tvaṃ mamāhaṃ te yadidaṃ kathanaṃ mithaḥ |
tattaraṅgastaraṅgāgre raṇatīveti me matiḥ
]

`v 31 [
evaṃrūpasya me kālavaśato'viśadākṛteḥ |
sā kumāryāścidābhāsamātrasyāntaḥ svabhāvataḥ
]

`v 32 [
mamānanyā tavānyasya cānyeveha vibhāti yā |
soditānuditevāntarmamāhamiti vāsanā
]

`v 33 [
anāśasattānuditastvahamātmātmani sthitaḥ |
svabhāvādacyutākāraḥ svātmārāmaḥ svayaṃ prabhuḥ
]

`v 34 [
tvaṃ tarhi svadṛśā kīdṛk tatrāha - anāśeti | ahaṃ tu anāśasattā yato'nuditaḥ |
33 |
tasyā ahamiti bhrāntervāsanāyā jagatsthiteḥ |
saṃpanneyamadhiṣṭhātṛdevatā deharūpiṇī
]

`v 35 [
vāsanāyā adhiṣṭhātṛdevataivamiyaṃ sthitā |
na tu me gṛhiṇī nāpi gṛhiṇyarthena satkṛtā
]

`v 36 [
svavāsanāveśavaśena bhāvaṃ gṛhiṇyahaṃ brahmaṇa ityupetya |
eṣā svayaṃ vyarthamitātiduḥkhaṃ yasmātkilaiṣaiva hi vāsanāntaḥ
]