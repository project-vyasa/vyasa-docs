`v 1 [
ṣaḍviṃśaḥ sargaḥ 26
śrīvasiṣṭha uvāca |
saṃsāramārgagahane patitasyāpatanti hi |
vṛttavṛttāntalakṣāṇi kīṭā iva ghanāgame
]

`v 2 [
sarva eva tvime bhāvāḥ parasparamasaṅginaḥ |
aṭavyāmupalānīva bhāvanaiteṣu śṛṅkhalā
]

`v 3 [
cittamāndhyāya vṛttāntadrumairgahanavatsthitam |
rasarañjanayā loke vasanta iva kānanam
]

`v 4 [
aho bata vicitrāṇi vāsanāvaśato'vaśaiḥ |
bhūtakairanubhūyante sukhaduḥkhāni janmasu
]

`v 5 [
aho batātiviṣamā vāsanā yadvaśājjanaiḥ |
avidyamānairevāyaṃ bhramo'ntaranubhūyate
]

`v 6 [
āhlādino mṛtavataḥ śuddhasyālokakāriṇaḥ |
śītalasyākhilārtheṣu jñasyendośca kimantaram
]

`v 7 [
pūrvāparamanālocya yatkiṃcidabhivāñchataḥ |
nirmaryādasya mūḍhasya bālasya ca kimantaram
]

`v 8 [
labdhamāprāṇaparyantaṃ śubhāśubhamanujjhatoḥ |
āmiṣaṃ ko viśeṣo'sti vada mākaramūḍhayoḥ
]

`v 9 [
sarva eva tvime bhāvā dehadāradhanādayaḥ |
kṣipramāśuṣkasikatāśarāvaviśarāravaḥ
]

`v 10 [
ābrahmastambaparyantamapi yoniśateṣu te |
ākalpaṃ bhramataścittaśāntirnāsti śamādṛte
]

`v 11 [
paryālocanamātreṇa bandhagandho na bādhate |
gacchato mārgavaiṣamyamivālokanakāriṇaḥ
]

`v 12 [
tava nāvahitaṃ cittaṃ kāmaḥ kavalayiṣyati |
sāvadhānasya buddhasya piśācaḥ kiṃ kariṣyati
]

`v 13 [
yathekṣaṇaprasaraṇaṃ rūpālokanamātrakam |
saṃvitprasṛtimātrātma tathā sāhaṃjagatsthitam
]

`v 14 [
yathākṣisaṃvṛtiḥ sarvarūpālokaśamo'rihan |
saṃvitsaṃvaraṇaṃ nāma sarvadṛśyaśamastathā
]

`v 15 [
asadeva jagatsāhaṃn śuddhā saṃvittanoti khe |
īṣatprasaraṇenāśu spandanaṃn pavano yathā
]

`v 16 [
sadivāsatyamevedamakurvatyanyamedhate |
mṛdā hemneva kumbhatvamapṛthaglabhyamātmagam
]

`v 17 [
śūnyamātraṃ yathā vyoma spandamātraṃ yathānilaḥ |
jalamātraṃ yathormyādi saṃvinmātraṃ tathā jagat
]

`v 18 [
avyavacchinnanirbhāgasaṃvinmātraṃ jagattrayam |
viddhi śāntaṃ tathā vyoma yathā vāriṇi parvatam
]

`v 19 [
nirvāṇasyopaśāntasya jñasya sodeti śītatā |
antaryatrendavo'pyete dīptajvalanabindavaḥ
]

`v 20 [
itthaṃ jagattattvaṃ jānato na sāṃsārikatāpaprasaktirityāśayenāha - nirvāṇasyeti | sā
sarvotkṛṣṭā śītatā sarvatāpopaśāntyupalakṣitā''hlādatā | yatra yaddṛṣṭyeti yāvat |
19 |
kiṃ kena kathamekāntaśāntātataśivātmani |
nirāloko'parālokaḥ śūnye jagati janyate
]

`v 21 [
yā sattā brahmaśabdākhyā rūpaṃ sarvasya tannijam |
na yatra kācidbādhāsti sarvaṃ tanmayamavyayam
]

`v 22 [
yadidaṃ tu padārthatvaṃ yatra bādhānubhūyate |
yadyacca bādhanaṃ prekṣya tanna vidmaḥ khapuṣpavat
]

`v 23 [
jña evāpagatasvāntaṃ śāntamāsva mahāśmavat |
asau na mananaṃ mānamanantamajamavyayam
]

`v 24 [
ākāśakalpe sve bhāve tiṣṭhato'ṅgānivedanam |
bhavatyabhyāsadārḍhyena vinā svapnavikāravat
]

`v 25 [
he aṅga ākāśakalpe sve ātmabhāve manobādhena tiṣṭhato jñasya
nāmarūpayoranivedanamapratītireva bhavati
yatastatsvarūpāvasthityabhyāsadārḍhyābhāvādeva svapnavikāravanmanasyudetītyarthaḥ |
24 |
nirupādānasaṃbhāramabhittāveva cetati |
brāhmaṃ kartṛ jagaccitraṃ na kaścidvā na kiṃcana
]

`v 26 [
tanoti yattadātmaiva tasya tatra tathā sthitam |
dṛśyābhāvādasaddṛśyaṃ tena kaḥ kva karoti kim
]

`v 27 [
ahaṃ sukhīti sukhitā ahaṃ duḥkhīti duḥkhitā |
sarva eva svarūpasthā vyomātmāno'pi pārthivāḥ
]

`v 28 [
sarveṣāmeva bhāvānāṃ cidākāśātmanāmapi |
mithyaiva svapnaśailānāmiva `note[svapnaśīlānāṃ iti pāṭhaścintyaḥ |]
pārthivatā sthitā
]

`v 29 [
ahaṃtvollekhataḥ sattā bhramabhāvavikāriṇī |
tadabhāvātsvabhāvaikaniṣṭhatā śamaśālinī
]

`v 30 [
hemnaḥ kaṭakaśabdārtho vyatirikto yathāsti te |
vyatiriktā tathā satyā nāhaṃtāsti śamātmanaḥ
]

`v 31 [
nirvāṇo nirmanā maunī kartā'kartā ca śītalaḥ |
jña eva śānta evāste śūnya evābhipūritaḥ
]

`v 32 [
nirvāsanāspandaparo yantraputrakagātravat |
sa yathāsthitamevāste jñaḥ saṃvyavaharannapi
]

`v 33 [
yathā mañcakasaṃsthasya spandante naiva vā śiśoḥ |
aṅgāni svānusaṃdhānaṃ vinaivaṃviditātmanaḥ
]

`v 34 [
niḥsaṃbodhaikabodhasya nirāśehaiṣaṇāśiṣaḥ |
śāntānantātmarūpatvādanusaṃdhānatā kutaḥ
]

`v 35 [
adraṣṭurapadṛśyasyādṛgrūpasyāparūpiṇaḥ |
kutaḥ kilānusaṃdhānamanapekṣasya paśyataḥ
]

`v 36 [
apekṣaiva ghano bandha upekṣaiva vimuktatā |
sarvaśabdānvitā tasyāṃ viśrāntena kimīkṣyate
]

`v 37 [
pārthivatve śarīre'sminsvasvapnāṅga ivāsati |
bhramamātrātmani kutaḥ kva kasya kimapekṣaṇam
]

`v 38 [
upaśāntasamastehaṃ vigatākhilakautukam |
nirastavedanaṃ jñena vidā kevalamāsyate
]

`v 39 [
maṅkineti śrutavatā tato moho mahānapi |
aśeṣeṇa parityaktastatraiva tvagivāhinā
]

`v 40 [
pravāhāpatitaṃ kāryaṃ kurvatāpāstavāsanam |
tena varṣaśatasyānte sthitamadrau samādhinā
]

`v 41 [
tatrādyayāvatpāṣāṇasamadharmā sa tiṣṭhati |
saṃśāntakaraṇo yogī bodhyamānaḥ prabudhyate
]

`v 42 [
etena rāghava vivekapadena śāntimāsādayodayavatā manasā vihartum |
mā dīnatāṃ vrajatu rāgamayī matiste kṣīṇā kṣaṇādasalileva śaradghanālī
]