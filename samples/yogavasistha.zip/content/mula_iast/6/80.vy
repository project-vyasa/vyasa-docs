`v 1 [
aśītitamaḥ sargaḥ 80
śrīvasiṣṭha uvāca |
iti te sarva āyātā brahmalokanivāsinaḥ |
adṛśyatāmeva gatā dīpāḥ kṣīṇadaśā iva
]

`v 2 [
atha te dvādaśādityā brahmaṇi brahmatāṃ gate |
jagadvadbrahmalokaṃ tamadahanbhāsvarārciṣaḥ
]

`v 3 [
vairiñcanagaraṃ dagdhvā dhyānaṃ kṛtvā virañcivat |
te'pi nirvāṇamājagmurniḥsnehadaśadīpavat
]

`v 4 [
tata ekārṇavāpūro viriñcanagarāntaram |
rātrau bhuvamiva dhvāntaṃ pūrayāmāsa sūrmimān
]

`v 5 [
ābrahmalokamabhavajjagadāpūrṇamarṇasā |
tulyaṃ rasaikapūrṇena pakvadrākṣāphalena tat
]

`v 6 [
tattadūrmigirivrātakhagairāvalitāḥ khilāḥ |
vicchinnāḥ kapajaladā jala eva nililyire
]

`v 7 [
etasminnantare tatra dṛṣṭavānahamambarāt |
yāvadabhyuditaṃ bhīmaṃ bhītaḥ kiṃcinnabhontarāt
]

`v 8 [
kalpāntajagadākāraṃ kṛṣṇamāpūritāmbaram |
ākalpaṃ saṃbhṛtaṃ naiśaṃ dehenevotthitaṃ tamaḥ
]

`v 9 [
taruṇādityalakṣāṇāṃ teja ābhāsvaraṃ dadhat |
ādityatrayasaṃkāśaiḥ sthiravidyuccayolbaṇaiḥ
]

`v 10 [
netrairābhāsvaramukhaṃ jvālāpuñnjasamudgiram |
pañcānanaṃ daśabhujaṃ trinetraṃ śūlapāṇikam
]

`v 11 [
āyāntamantamukte'pi vyomnīva vitatākṛtim |
khamivāsi ghanaśyāmaṃ dehamāsādya saṃsthitam
]

`v 12 [
sthitamekārṇavāpūrṇādbrahmāṇḍādbahirambare |
vyomeva hastapādādisaṃniveśena lakṣitam
]

`v 13 [
ghoṇānilaparāvṛttividhūtaikamahārṇavam |
govindamiva dordaṇḍakṣobhitakṣīrasāgaram
]

`v 14 [
kalpārṇavajalāpūraṃ puṃstveneva samutthitam |
mūrtiyuktamahaṃkāramastakāraṇamāgatam
]

`v 15 [
kulācalabṛhadvṛndamivoḍḍayanaḍambaraiḥ |
pakṣaughairutthitaṃ vyoma samastamabhipūrayat
]

`v 16 [
tatastriśūlanayanairmayā rudro'yamityasau |
dūrādeva parijñāya parameśo namaskṛtaḥ
]

`v 17 [
śrīrāma uvāca |
kiṃ sa tādṛgvidho rudraḥ kiṃ kṛṣṇaḥ kiṃ mahākṛtiḥ |
kiṃ pañcavadanaḥ kasmāddaśabāhuḥ sa tiṣṭhati
]

`v 18 [
kiṃ trinetraḥ kimugrātmā kimekaḥ kiṃprayojanaḥ |
keneritaḥ kimakarocchāyāsīdvada kā mune
]

`v 19 [
śrīvasiṣṭha uvāca |
kākutstha rudranāmāsāvahaṃkāratayotthitaḥ |
viṣamaikābhimānātmā mūrtirasyāmalaṃ nabhaḥ
]

`v 20 [
vyomākṛtiḥ sa bhagavānvyomavarṇo mahādyutiḥ |
cidvyomamātrasāratvādākāśātmā sa ucyate
]

`v 21 [
sarvabhūtātmabhūtatvātsarvagatvānmahākṛtiḥ |
yāni tasyānuṣaktāni pañca khānīndriyāṇyalam
]

`v 22 [
tāni tasya mukhānyāhustapadrūpāṇi sarvataḥ |
karmendriyāṇi viṣayāste hi tasya bhujā daśa
]

`v 23 [
sarvabhūtanaraiḥ sārdhaṃ brahmaṇā parameyuṣā |
yadāsau saṃparityaktastadā svāṃ mūrtimāgataḥ
]

`v 24 [
sa caikāṃśaikarūpātmā nāsti tasya hi sākṛtiḥ |
tathā dṛśyata evāsau bhrāntimātreṇa mūrtimān
]

`v 25 [
cidākāśagate sphāre bhūtākāśe sa tiṣṭhati |
dehe ca sarvabhūtānāṃ nityaṃ vāyuriveśvaraḥ
]

`v 26 [
praśneṣu sa tiṣṭhatītyatra kvetyadhyāhṛtya ādhārapraśno yo varṇitastasyottaramāha ##-
25 |
sarvabhūtaparityaktastasminkāle khamūrtimān |
kṣobhayansa kṣaṇaṃ kṣīṇaḥ paramāṃ śāntimeṣyati
]

`v 27 [
ye guṇākṛtayaḥ kālāścittāhaṃkārabuddhayaḥ |
praṇavasya ca ye varṇā ye ca vedāstathā trayaḥ
]

`v 28 [
rudrasya tasya te netrasaṃniveśena saṃsthitāḥ |
triśūlaṃ tena trailokyaṃ gṛhītaṃ karakoṭare
]

`v 29 [
yasmāttadvyatirekeṇa sarvabhūtagaṇeṣvapi |
anyanna vidyate kiṃciddehātmaiva tataḥ sthitaḥ
]

`v 30 [
sarvasattvopalambhātmā svabhāvo'sya prayojanam |
īritaḥ śivarūpeṇa cinmātrākāśarūpiṇā
]

`v 31 [
tenaiva ca nigīrṇaḥ sanparamāṃ śāntimetyasau |
nirmalākāśarūpātmā kṛṣṇa ityeṣa īśvaraḥ
]

`v 32 [
pralayārthamīritaśca sargakramaviparītakrameṇa jagannigīryākāśabhāvena sthitaḥ
svayamapi tenaiva śivarūpeṇa svātmanā nigīrṇaḥ san ākāśabhāvamapi vihāya paramāṃ
bhūmānandasvarūpapratiṣṭhālakṣaṇāṃ śāntimetītyarthaḥ | kiṃ kṛṣṇa
ityādipraśnānāṃ sarveṣāṃ sopapattikaṃ samādhānamuktaṃ smārayannupasaṃharati ##-
kṛtvā kalpaṃ jagatsarvaṃ tatpītvaikārṇavaṃ tadā |
sa prayāti parāṃ śāntimabhūyaḥsaṃnivṛttaye
]

`v 33 [
anantaraṃ mayā dṛṣṭastatrāsau yāvadudyamāt |
pravṛttaḥ prāṇavegena tamākraṣṭuṃ mahārṇavam
]

`v 34 [
atha tasya mukhaṃ sphāraṃ jvālāmālākulāntaram `note[jvālāmālāsamākulam iti
ṭīkākṛdabhimataḥ pāṭhaḥ |] |
prāṇākṛṣṭo mahāmbhodhirvāḍavāgnimivāviśat
]

`v 35 [
sa eva vāḍavo bhūtvā vahnirākalpamarṇave |
ahaṃkāraḥ pibatyambu rudraḥ sarvaṃ tu tattadā
]

`v 36 [
pātālamiva pānīyaṃ sarpo bilamiva kṣaṇāt |
pañcavāyurivākāśamaviśattanmukhaṃ javāt
]

`v 37 [
samupetyāpibadrudraḥ sa muhūrtena tatpayaḥ |
kṛṣṇāṅgo'rka iva dhvāntaṃ satsaṃparka ivāguṇam
]

`v 38 [
ābrahmalokapātālaṃ śāntaṃ śūnyamathābhavat |
rajodhūmānilāmbhodhibhūtamuktaṃ samaṃ nabhaḥ
]

`v 39 [
kevalaṃ tatra dṛśyante catvāro vyomanirmalāḥ |
ime padārthā nispandāḥ śṛṇu tānraghunandana
]

`v 40 [
ekastāvadasau madhye rudraḥ kṛṣṇāmbarākṛtiḥ |
nirādhāraḥ sthito vyomni nispandāmodabimbavat
]

`v 41 [
dvitīyo'vasthito dūre pṛthvyākāśatalopamaḥ |
bhāgo brahmāṇḍasadanasyādhaḥ pātālasaptakāt
]

`v 42 [
pātālabhūtaladivāṃ saśailendradivaukasām |
vyāptaḥ pārthivabhāgena paṅkamātrātmanātmabhak
]

`v 43 [
tṛtīyo'tra padārtho'bhūdūrdhvaṃ brahmāṇḍabhāgabhūḥ |
dṛṣṭikṣayātsudūratvāddurlakṣyagaganāsitaḥ
]

`v 44 [
dūraviśliṣṭayormadhyaṃ yattadbrahmāṇḍakhaṇḍayoḥ |
tadākāśamanādyantaṃ brahma nirmalamātatam
]

`v 45 [
caturthaḥ padārthastadubhayāntarālākāśamevetyāha - dūreti | brahmeva nirmalam |
44 |
caturtho'sau padārthastu tadā saṃlakṣito mayā |
catuṣṭayādatra nānyadetasmādeva kiṃcana
]

`v 46 [
śrīrāma uvāca |
bahiḥ kiṃ vidyate brahmanbrahmasadmakaṭāhataḥ |
kāstatrāvaraṇā brūhi kiyatyaḥ saṃsthitāḥ katham
]

`v 47 [
śrīvasiṣṭha uvāca |
brahmāṇḍakhaṇḍayoḥ pāre tato daśaguṇaṃ jalam |
saṃdhyākāśamanantaṃ tadvarjayitvā tataḥ sthitam
]

`v 48 [
tatastathaiva jvālātma tejo daśaguṇaṃ sthitam |
tatastathaiva pavanaḥ pavano nirmalaḥ sthitaḥ
]

`v 49 [
tatastathaiva vimalaṃ nabho daśaguṇaṃ smṛtam |
tataḥ paramamatyacchaṃ brahmākāśamanantakam
]

`v 50 [
anyatrānyatra tasyātha dṛṣṭayo'nyāstathaiva khe |
kacantyanantā dūrasthā mitho dṛṣṭātmasṛṣṭayaḥ
]

`v 51 [
śrīrāma uvāca |
ūrdhve brahmāṇḍakhaṇḍasya tathādhastānmunīśvara |
tajjalādimahākāraṃ kva kathaṃ kena dhāryate
]

`v 52 [
śrīvasiṣṭha uvāca |
sa pārthivapadārthānāṃ sthitaḥ puṣkarapatravat |
bhāgastamevādhāvanti te sutā mātaraṃ yathā
]

`v 53 [
atp yadeva nedīyo brahmāṇḍākhyaṃ mahāvapuḥ |
tatpadārthāḥ pradhāvanti tṛṣitāḥ salilaṃ yathā
]

`v 54 [
avalambya tadevāntaḥ saṃsthitāstaijasādayaḥ |
na sthitiṃ pravimuñcanti svāṃ yathāvayavā iva
]

`v 55 [
śrīrāma uvāca |
brahmanbrahmāṇḍakhaṇḍe te tiṣṭhataḥ kathamucyatām |
kimākṛtīṃ dhṛte kena kathaṃ vā parinaśyataḥ
]

`v 56 [
itarāvaraṇādhārayorbhrahmāṇḍakharparayoratigurutvādavaśyaṃ pipatiṣatoḥ
kastarhyādhāra iti rāmaḥ pṛcchati - brahmanniti | kathaṃ kenādhāreṇa tiṣṭhataḥ |
55 |
śrīvasiṣṭha uvāca |
adhṛtaṃ dhṛtamevoccairapataccaiva vā patat |
anākṛtyeva sākāraṃ jagatsvapnapuraṃ yathā
]

`v 57 [
kimasya nāma patati kiṃ vā kenāsya dhāryate |
yathā saṃvitti kacanaṃ tathaitadavatiṣṭhate
]

`v 58 [
yathā keśoṇḍrakaṃ vyomni yathā ca vyomni śūnyatā |
yathā vā pavane spando jagaccidgagane tathā
]

`v 59 [
citau saṃkalpanagaraṃ brahmāṇḍākhyaṃ jagadgṛham |
khe khamevāpyanākāraṃ pratyākāramiva sthitam
]

`v 60 [
pātasaṃvitsamudbhūtaṃ etadāste divāniśam |
gacchantyā saṃvidodbhūtaṃ gacchadāste divāniśam
]

`v 61 [
sthitasaṃvitsamudbhūtaṃ tiṣṭhadāste divāniśam |
utpatantyā citodbhūtamutpataccaiva tiṣṭhati
]

`v 62 [
eti nāśavidā nāśaṃ mahākalpādivedanaiḥ |
jāyate janmasaṃvittyā vyomni sarvādivedanaiḥ
]

`v 63 [
ābhāti mauktikagaṇaḥ śaradambarāntardṛṣṭāvasatya udito'pyatisatyarūpaḥ |
bhrāntyā yathā nabhasi ca sphuratāṃ tathaiṣāṃ saṃkhyāṃ vidhātumiha ko jagatāṃ
samarthaḥ
]