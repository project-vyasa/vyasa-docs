`v 1 [
pañcādhikaśatatamaḥ sargaḥ 105
śrīvasiṣṭha uvāca |
svabhāvaṃ jagadākāraṃ cidbhāvo'nubhavansthitaḥ |
svataḥ svapnamivānanyamātmanaḥ kalpanābhidham
]

`v 2 [
jāgratsuṣuptamevedaṃ śilājaṭharamevavā |
ākāśameva vā śūnyaṃ jagattvena ca nojjhitam
]

`v 3 [
svapna evātra dṛṣṭāntaḥ puramaṇḍalamaṇḍitaḥ |
svapne jaganna kiṃcitsaditthamābhāti bhāsuram
]

`v 4 [
trailokyamasadevedaṃ yathā svapne'vabhāsate |
jāgratyasmiṃstathaivedaṃ manāgapyatra nānyathā
]

`v 5 [
na jāgrati na ca svapne jagacchabdārthasaṃbhavaḥ |
svaṃ vastutastu cidvyomno bhānaṃ buddhaṃ jagattayā
]

`v 6 [
cidvyomnā svacamatkāro vyomanyadryādirūpabhṛt |
jagadityeva buddho'ntarjāgratsvapne svayaṃbhuvā
]

`v 7 [
jaganna kiṃcidevedaṃ cidrūpaṃ ca na kiṃcana |
ete kiṃcidivābhāto nabhaścijjagatī mudhā
]

`v 8 [
ābhātameva trailokyaṃ yathā svapne na kiṃcana |
śūnyameva bhavedevamevaṃ jāgrati nirvapuḥ
]

`v 9 [
svapne kila mahābuddhe nānānirmāṇaśālini |
ārambhā eva nārambhā asatsadiva cātatam
]

`v 10 [
avyomaivātivitataṃ vyomāntaparivarjitam |
vyomaivācalasaṃghāto nānāpuragaṇotkaraḥ
]

`v 11 [
apyabdābdhyadrinirghoṣo maunameva yathā tathā |
na śṛṇotyeva pārśvasthaḥ saṃprabudhyāpi kiṃcana
]

`v 12 [
prajāyate vā'jāto'pi vandhyāyāstanayo yathā |
jāto'pyajāta evāste yathātmamṛtivismṛtau
]

`v 13 [
sadasadbhavati kṣipraṃ bhuvo'nanubhavo yathā |
viparyasyati sarvaṃ ca rātrireva yathā dinam
]

`v 14 [
asadyatsaṃbhavatyāśu dinameva yathā niśā |
asaṃbhavaḥ saṃbhavati yathā svamṛtidarśanam
]

`v 15 [
asambhavaḥ saṃbhavati jagadbhānamivāmbare |
tama eva mahāloko yaḥ sanidraḥ savāsaraḥ
]

`v 16 [
āloka evati tamo yannidrā svapnavāsarā |
vasudhaiva bhavedvyoma śvabhrādipatane yathā
]

`v 17 [
asatyarūpameveti bhāti svapne jagadyathā |
tathaiva jāgradābhāti manāgapyatra nānyatā
]

`v 18 [
yathā dvau sadṛśau sūryau yathā dvau sadṛśau narau |
jāgratsvapnau tathaivaitau manāgapyatra nānyatā
]

`v 19 [
śrīrāma uvāca |
naitadevamapi kṣiprātpratyayo yatra bādhakaḥ |
svapne taddarśanenāntaḥ kathaṃ jāgratsamaṃ bhavet
]

`v 20 [
śrīvasiṣṭha uvāca |
vihṛtya svapnajagati svapnabandhujanaiḥ samam |
mṛtimāpnoti tatrāsau draṣṭā svapnasya rāghava
]

`v 21 [
mṛtaḥ sansvapnajagati svapnajantuviyogavān |
iha prabudhyate janturnidrāmuktaśca kathyate
]

`v 22 [
sukhaduḥkhadaśāmohāndinarātriviparyayān |
anubhūya bahūndraṣṭā mriyate svapnasaṃsṛtau
]

`v 23 [
gatanidratayā paścānnidrānta iha jāyate |
na satyametadityevaṃ tataḥ pratyayavānbhavet
]

`v 24 [
svapnadraṣṭā yathā svapnasaṃsāre mṛtimāptavān |
anyaṃ jāgranmayaṃ svapnaṃ draṣṭuṃ bhūyaḥ prajāyate
]

`v 25 [
jāgraddraṣṭā tathā jāgratsaṃsāre mṛtimāptavān |
anyaṃ jāgranmayaṃ svapnaṃ draṣṭuṃ bhūyaḥ sa jāyate
]

`v 26 [
na svapnamasadityevaṃ pūrvasmiñjāgradātmani |
punaḥ pratyayamādatte svapnātsvapnāntaraṃ gataḥ
]

`v 27 [
sa jāgratpratyayaṃ tatra punargṛhṇāti mugdhadhīḥ |
svapnasaṃdarśanaṃ tvanyattatrāpyanubhavatyatha
]

`v 28 [
svapnaṃ jāgrattayā jāgratsvapnatvaṃ ceti nāmani |
na jāyate na mriyate jāyate mriyate'pi ca
]

`v 29 [
svapnadraṣṭā svapnamṛtaḥ prabuddha iha kathyate |
iha jāgranmṛto jantuḥ prabuddho'nyatra kathyate
]

`v 30 [
svapnātsvapnasthitau jāgrajjāgratsvapnapradarśanam |
mṛtvānyatraprabuddhasya jāgratsvapno bhavatyalam
]

`v 31 [
itihāsamayāveva jāgratsvapnāvubhāvapi |
parasparaṃ gatāvetāvupamānopameyatām
]

`v 32 [
svapno jāgradivābhāti jāgratsvapnamivoditam |
vastutastu dvayamasaccitkhaṃ kacati kevalam
]

`v 33 [
sthāvaraṃ jaṃgamaṃ caiva bhūtajātamaśeṣataḥ |
cinmātravyatirekeṇa kimanyadupapadyate
]

`v 34 [
mṛnmayaṃ tu yathā bhāṇḍaṃ mṛcchūnyaṃ nopalabhyate |
ciccamatkāramātrātma tathā kāṣṭhopalādyapi
]

`v 35 [
vastujātamidaṃ svapne jāgratyapi tathaiva naḥ |
dṛṣṭo ya upalaḥ svapne ciccamatkaraṇādṛte
]

`v 36 [
kimanyatsaṃvada prājña kilāvaśyaṃ cideva sā |
nanu yādṛgvapuḥ svapne jāgrattādṛgakhaṇḍitam
]

`v 37 [
jagajjātamataḥ sarvaṃ cinmātraṃ brahmakhaṇḍitam |
jagajjātamataḥ sarvaṃ cinmātraṃ brahmakuṭṭimam
]

`v 38 [
mṛnmayaṃ tu yathā bhāṇḍaṃ mṛcchūnyaṃ nopalabhyate |
cinmayaṃ tu tathā cetyaṃ cicchūnyaṃ nopalabhyate
]

`v 39 [
cidvyatirekeṇa jagadanupalambhādapi cinmātratvamevetyāha - mṛnmayamityādinā |
38 |
śailātmakaṃ yathā bhāṇḍaṃ śailaśūnyaṃ na labhyate |
cinmayaṃ tu tathā cetyaṃ cicchūnyaṃ nopalabhyate
]

`v 40 [
dravarūpaṃ yathā vāri dravariktaṃ na labhyate |
cinmayaṃ tu tathā cetyaṃn cicchūnyaṃ nopalabhyate
]

`v 41 [
ūṣmarūpo yathā vahnirnirūṣmā nopalabhyate |
cinmayaṃ tu tathā cetyaṃ cicchūnyaṃ nopalabhyate
]

`v 42 [
yathā spandamayo vāyuraspando nopalabhyate |
cinmayaṃ tu tathā cetyaṃ cicchūnyaṃ nopalabhyate
]

`v 43 [
yadyanmayaṃ tadvinā tu tatkathaṃ kila labhyate |
kvāśūnyaṃ labhyate vyoma kvāghanā labhyate mahī
]

`v 44 [
cidvyomamayamevedaṃ yathā ghaṭapaṭādikam |
svapne tathedaṃ śailādi cidvyomābhāsamātrakam
]

`v 45 [
svapne yathā gaganameva purācalādi saṃvinmayaṃ subhaga jāgrati tadvadeva |
svapno'tha jāgraditi śāntamanantamekaṃ cinmātramatra nanu nāma vināstu vādaḥ
]