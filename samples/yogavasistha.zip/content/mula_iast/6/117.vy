`v 1 [
saptadaśādhikaśatatamaḥ sargaḥ 117
sahacarā ūcuḥ |
paśyādrisānāviva bimbitaṃ khaṃ puraḥsaro mārapuraḥsaro yaḥ |
kahlārapadmotpalajālanālalaladvicitrāravapakṣivītam
]

`v 2 [
vikāsitoddaṇḍasahasrapatrakośasthalasthoddhurarājahaṃsam |
pīṭhadvirephadvijalokajuṣṭaṃ bhuvīva gehaṃ kamalāsanasya
]

`v 3 [
ākīrṇasīkarakarāladigantarāle phullotpalābjapaṭalodarareṇugauram |
āmodamattamadhupadvijagītigītaṃ yātaṃ vitānakamivāmbaragaṃ vahantam
]

`v 4 [
kvacittarattārataraṅgabhaṅgaṃ kvaciddviṣadbhūrivirāvibhṛṅgam |
kvacidgabhīrāmalavārisuptaṃ kvacitsarojojjvalapuṣpaguptam
]

`v 5 [
kaṇāṇumuktājalatāpaṭālaṃ tīreṣu siṃhe sulatāsuṭālam |
taraṅganirdhūtaśilograkacchaṃ mahītalākāśamanantakaccham
]

`v 6 [
taḍitprakāśodaramasyameghanunnābjajātottharajaḥprabhābhiḥ |
pṛṣadbharadhvāntamayaikadeśaṃ saṃdhyāmbarābhogamivāprakāśam
]

`v 7 [
vātāvakīrṇaśaradambudakhaṇḍakhaṇḍaṃ vyomeva
kevalasamīraṇamāvṛtāṅgam |
haṃsairlasadbisalatākavalālasāṃsaiḥ kālena saṃcayakṛtairiva candrabimbaiḥ
]

`v 8 [
āmodamandamakarandakarālavātavyādhūtapaṅkapuṭapāṭanapāṭavena |
udyanmahāpaṭapaṭā vayatīva lekhā kṣubhyatkhagāśritalatojjhitapuṣpavarṣam
]

`v 9 [
vellanmahākamalapallavatālavṛntasaṃvījitaṃ valitacāmaracāruphenam |
rājāyamānamalikokilagītagītaṃ sadvṛttapaṅkajalatālalitāṅganaugham
]

`v 10 [
bhṛṅgāgrabhājanamanoharahārigītaṃ rājīvareṇuraṇakīrṇapiśaṅgatoyam |
ḍiṇḍīrapiṇḍaparipāṇḍurapuṇḍarīkakhaṇḍopamaṇḍitataṭopavanāvataṃsam
]

`v 11 [
viviktahṛdayāmbhojaṃ hṛdayāhlādanaṃ param |
rasavatsvādu bhātīdaṃ saraḥ satsaṃgamopamam
]

`v 12 [
bimbitena maruvyomnā bhātīdaṃ saumya nirmalam |
śāstrārthapariṇāmena mahatāmiva mānasam
]

`v 13 [
kiṃcillakṣyamapaśyāmaṃ pṛṣatparuṣamārutam |
himābhramiva bhātīdaṃ saraḥ sarasasārasam
]

`v 14 [
yathedaṃ brahmaṇo dṛśyamavikārādi netarat |
yathāmbhasi taraṅgādi rājanpṛthagiva sthitam
]

`v 15 [
ātmanaivohyamānānāṃ cakrāvartavidhāyinām |
jaḍāśayānāṃ viṣamā hā kallolaparamparā
]

`v 16 [
kūpavāpīsarobdhīnāṃ dṛśyate yādṛgantaram |
nārīpuruṣatoyānāṃ vijñeyaṃ tādṛgantaram
]

`v 17 [
jantorivāsya manaso jalajātibandhajīrṇasya jarjaradaśālaharībhrameṇa |
āvartavṛttivalitānyatisaṃtatāni ko nāma saṃkalayituṃ kamalāni śaktaḥ
]

`v 18 [
citraṃ vijṛmbhitamaho jaḍasaṃgamasya padmopi yannijaguṇānaguṇānivaiṣaḥ |
antaḥ pragopayati kaṇṭhatale niveśya sarvasya darśayati durbhagakaṇṭakaugham |
18 |
padmāni varṇayituṃ prastauti - citramityādinā | itaḥ paraṃ prāyeṇānyāpadeśāḥ |
jaḍasaṃgamasya jalasaṃbandhasya mūrkhasamāgamasya ca vijṛmbitaṃ
citramāścaryabhūtaṃ aho | tatkutaḥ | yadyata eṣa sadguṇanidhitvena prasiddhatamaḥ
padmo'pi nijān saurabhyasaundaryamakarandādīn guṇānaguṇān doṣāniva mukulitaḥ san
kaṇṭhatale niveśya antaḥ pragopayati | durbhagaṃ kaṇṭhakaughaṃ ca bahiḥ sarvasya
janasya darśayati
]

`v 19 [
saccidrairadṛḍhaiḥ sūkṣmairgopitairjāḍyasaṃyutaiḥ |
analpairapi niḥsāraiḥ padmasyeva guṇairalam
]

`v 20 [
mahatāṃ kulapadmānāṃ guṇasaundaryaśālinām |
prabhāvaṃ nāsti saṃkhyātuṃ vāsukerapi śaktatā
]

`v 21 [
harivakṣogatā lakṣmīrapi śobhārthameva yat |
bibharti kamalaṃ haste kānyāśaṃsādhikā bhavet
]

`v 22 [
sitāsitābhyāṃ rūpābhyāṃ kamalotpalakhaṇḍayoḥ |
vaisādṛśyaṃ bhavetkiṃtu samā jaḍajaḍaitayoḥ
]

`v 23 [
sāmyaṃ na phullavipinena saraḥsu yāti vyomnā na tārakayutena na cenduvṛndaiḥ
`note[indubiṃbaiḥ iti ṭīkākṛdabhimataḥ pāṭhaḥ |] |
nṛtyadvadhūvihasitānanaśobhayaiti phullasya paṅkajavanasya navoditā śrīḥ | 23
|
saraḥ su phullasya paṅkajavanasya navoditā śrīḥ śobhā phullena mandārādivipinena
sāmyaṃ na yāti | tārakayutena vyomnāpi sāmyaṃ na yāti | evamindubimbairapyekatra
militaiḥ sāmyaṃ na yāti | kiṃtu nṛtyantīnāṃ vadhūnāṃ vihasitayuktayā
ānanaśobhayā sāmyameti labhate ityetadvidhyarthāpūrvopamānanirākriyā
]

`v 24 [
yeṣāṃ puṣpalatāsvādairananyamanasāṃ gatam |
bhṛṅgāṇāmāyurāyāmi ta eva subhagottamāḥ
]

`v 25 [
cūtacārucamatkāraṃ cañcarīkāścaranti ye |
ta eva sacamatkārā itare jātipūraṇam
]

`v 26 [
mattā madhumadāmodaiḥ puṣkareṣu raṇanti ye |
tuṣṭānāmitarasvādairbhramarāṇāṃ hasanti te
]

`v 27 [
yenoṣitaṃ virutamullasitaṃ prasuptaṃ padmodareṣu śaśikoṭarakomaleṣu |
bhṛṅgaḥ sa eṣa śiśire viraseṣu bhāvaṃ kaṣṭaṃ kariṣyati kathaṃ tarupuṣpakeṣu
]

`v 28 [
aphullamallikoddāmamukulopari ṣaṭpadaḥ |
dṛśyate kālarudreṇa śūle prota ivāndhakaḥ
]

`v 29 [
āsvādayanvividhapuṣpamadhūni bhṛṅga nityaṃ bhramansakalaśailalatāgṛheṣu
|
nādyāpi tuṣyasi kimaṅga durāśayo'si manye na sāramupagacchasi vā vanebhyaḥ |
29 |
aṅga he bhṛṅga tvaṃ vididhapuṣpamadhūni āsvādayansan sakalaśailalatāgṛheṣu
nityaṃ bhramannadyāpi kiṃ na tu tuṣyasi | madhulampaṭatvāddurāśayo'si adyāpi
vanebhyaḥ sāraṃ nopagacchasi vā | kaṣṭamiti khede | manye iti vitarke | na hi sāralābhe
aparitoṣo bhramaṇaṃ vā saṃbhāvayitumapi śakyamiti bhāvaḥ
]

`v 30 [
kamalakulakavalakovida gaccha saro madhupa mā rūḍham |
badaradarīṣu vidīrṇaṃ dehaṃ kuru kaṇṭakakrakacaiḥ
]

`v 31 [
atasīkusume kuvalayadalavalaye vikasite ca tāpicche |
parabhāgamehi madhunā tāsu visadṛśīva paṇḍitaḥ puruṣaḥ
]

`v 32 [
paśyaiṣā nābhinalinīkesaraiḥ pālitā śriyā |
haṃsamālāmalāvallī sāmagāyanakūjitā
]

`v 33 [
dolākamalanīḍasthāṃ dṛṣṭvā khe pratibimbitām |
haṃso haṃsīmanusaranmaṇḍale neha cetati
]

`v 34 [
iha saromaṇḍale khe haṃsīmanusaran haṃsaḥ pratibimbitāṃ dolāsadṛśe kamalanīḍe
sthitāṃ haṃsī dṛṣṭvā tatpatanamajjanaśaṅkayā na cetati | mūrcchito'bhūdityarthaḥ |
33 |
mā bhūtkasyacidevaiṣā rājanvyasanitā bhṛśam |
paśyaitāṃ bimbitāṃ haṃso haṃsīmanusaranmṛtaḥ
]

`v 35 [
helayā rājahaṃsena yatkṛtaṃ kalakūjitam |
na tadvarṣaśatenāpi jānātyāśikṣituṃ bakaḥ
]

`v 36 [
samāneṣvākarākārajāticeṣṭāśanādiṣu |
haṃsasya rājahaṃsasya dūramatyantamantaram
]

`v 37 [
śuklapakṣasthito vyomni kumudākarabhāsakaḥ |
āhlādayati cetāṃsi haṃsaścandra ivotthitaḥ
]

`v 38 [
unnālanalinīnālakadalīstambhasaṃkule |
vane viharatāṃ lakṣmīṃ haṃsānāmeti kaḥ khagaḥ
]

`v 39 [
taraṅgavalayā lolasīkarotkarahāriṇī |
kumudotpalakahlārapuṣpasaṃbhārasundarī
]

`v 40 [
bhṛṅgalolālakalatā raṇatsārasanūpurā |
vartulāvartanābhīkā caladvīcivilocanā
]

`v 41 [
pratīkṣamāṇā dayitaṃ rasapūrakaraṃ dharam |
nārīva sarasī cāruhaṃsakābhyāṃ virājate
]

`v 42 [
he haṃsa madgubakakākaśarārusāre mā tvaṃ sarasyavirataṃ kuru vāsamekaḥ |
āpadyapīha samaśīlavayovacobhiḥ śreyaḥphalā bhavati saṃgatirātmavargaiḥ
]

`v 43 [
pādākrāntamahebhamastakataṭaḥ padmākaraikālayaḥ
kahlārotpalakundacampakalatāsaṃbhogasaubhāgyavān |
bhṛṅgo'pyeṣa vidhervaśena śiśire loṣṭaṃ tṛṇaṃ svādayan śīte
śuṣkabakatyaho nu vipadā dainye mano dīyate
]

`v 44 [
putrasyeha dalodare dyuti tarattāraṃ ciraṃ saṃsmṛtaṃ
haṃsasyāṃsavinunnanālagahane saṃcāriṇā bho mayā |
śuklāsāramivābjinī vikirati svaṃ vārivindūtkaraṃ madhyāhne śiśiraṃ vikāsi
sahasā mūrdhni sphuṭaṃ dṛśyatām
]

`v 45 [
vyomnīndoriva saumyavāriṇi ciraṃ niḥśabdakaṃ sarpato
haṃsasyāṃsahatābjanālavalanāniṣkampaṭaṅkakṣataiḥ |
gaṅgāvārivadatra puṣkarapuṭādbrāhmādivāsyopari bhraṣṭā ye jalabindavo
jalacarā hṛṣṭāḥ pibantyāśu tān
]