`v 1 [
ekonāśītitamaḥ sargaḥ 79
śrīvasiṣṭha uvāca |
etasminnantare cakṣurvyomastho'hamathātyajam |
brahmaloke mahāloke prabhāte'rkaprabhāmiva
]

`v 2 [
yāvaddṛṣṭo mayā tatra śailādiva vinirmitaḥ |
parameṣṭhī samādhisthaḥ pradhānaparivāravān
]

`v 3 [
samūhaścaiva devānāṃ munīnāṃ bhāvitātmanām |
śukro bṛhaspatiścaiva śakro vaiśravaṇo yamaḥ
]

`v 4 [
somo'tha varuṇo'gniśca tathānye'pi surarṣayaḥ |
devagandharvasiddhānāṃ sādhyānāṃ ca vināyakāḥ
]

`v 5 [
lipikarmārpitākārāḥ sarve dhyānaparāyaṇāḥ |
baddhapadmāsanāstatra nirjīvā iva saṃsthitāḥ
]

`v 6 [
atha te dvādaśādityāstamevoddeśamāgatāḥ |
baddhapadmāsanāstasthustathaivāśu yathaiva te
]

`v 7 [
tato muhūrtamātreṇa dṛṣṭavānahamabjajam |
puro vinidratāṃ yātaḥ svapnadṛṣṭamivāgragam
]

`v 8 [
brahmalokajanaṃ sarvaṃ mahatāmiva vāsanām |
nāpaśyaṃ svapnanagaraṃ budhyamāna ivāgragam
]

`v 9 [
araṇyaśūnyamevāsīttadbrahmamananaṃ `note[brahmasaṃkalpasiddham |] tadā |
kaṭhinākāṇḍavidhvastaṃ pṛthivyāmiva pattanam
]

`v 10 [
sarva eva na ca kvāpi te tathā tādṛśāstadā |
ṛṣayo munayo devā vedā `note[siddhā iti pāṭhaḥ |] vidyādharādayaḥ
]

`v 11 [
jñātaṃ tato'vadhānena mayā nabhasi tiṣṭhatā |
yāvannirvāṇamāpannā brahmavatsarva eva te
]

`v 12 [
vāsanāyāṃ vilīnāyāmadarśanamupāgatāḥ |
svapnalokāḥ prabuddhānāmiva svaṃ rūpamāgatāḥ
]

`v 13 [
ākāśātmaiva deho'yaṃ bhāti vāsanayā sphuṭaḥ |
tadabhāvāttu no bhāti svapno bodhavato yathā
]

`v 14 [
antarikṣagato deho yathā svapne vilokyate |
bodhe tadvāsanāśāntau na kiṃcidapi lakṣyate
]

`v 15 [
jāgratyapi tathaivāyaṃ vāsanāyāḥ parikṣaye |
naivātivāhiko naiva lakṣyate'trādhibhautikaḥ
]

`v 16 [
svapnājjāgare svāpnādhibhautikamātrabādhaḥ tattvabodhe
tvādhibhautikādidehatrayasyāpi bādha iti viśeṣa ityāśayenāha - jāgratyapīti |
vāsanākṣayahetutattvaprabodhasya pramāṇajasya jāgratyeva saṃbhavājjāgratyapītyuktiḥ |
15 |
svapnānubhava eṣo'tra dṛṣṭāntatvena lakṣyate |
ābālametatsaṃsiddhamanubhūtaṃ śrutaṃ smṛtam
]

`v 17 [
apahnute ca vā yo'pi svamevānubhavaṃ śaṭhaḥ |
sa tyājyaḥ ko hyalīkena suptamudbodhayetkila
]

`v 18 [
dehakāraṇakaḥ svapno dehābhāvānna dṛśyate |
iti cettadadehānāṃ paraloko'pi nāsti ca
]

`v 19 [
ityetadabhaviṣyaccettaccharīrakasaṃkṣaye |
nābhaviṣyadayaṃ sargaḥ sa cāstyeva ca sarvadā
]

`v 20 [
avayavavibhāgātmanyavaśyaṃbhāvini kṣaye |
na kadācidanitthaṃ tajjagadityapyasaṃsthitam
]

`v 21 [
na kadācijjagannāśo dehodbhūtaguṇādikam |
madaśaktiriva jñaptirudetīti ca vakṣi cet
]

`v 22 [
tatpurāṇetihāsānāṃ sarvasaṃkṣayavādinām |
smṛtyādīnāṃ savedānāṃ vaiyarthyamupajāyate
]

`v 23 [
apramāṇatayaitasminnarthe teṣāṃ mahāmate |
anyatrāpi pramāṇatvaṃ vandhyādāvapi kiṃ bhavet
]

`v 24 [
na caitadiṣyate loke jagaducchedakāraṇāt |
anyaccāstāmetadaṅga mamedamaparaṃ śṛṇu
]

`v 25 [
madaśaktyātmani jñāne dṛṣṭā deśāntareṣu yā |
pramṛtānāṃ piśācādidehatā sā na sidhyati
]

`v 26 [
atha sāpi mudhā bhrāntiryāvaddehaṃ pradṛśyate |
iti cettanmudhā nāma satyamityeva vo bhavet
]

`v 27 [
evaṃ cettatparo lokaḥ satsvarganarakādikam |
ityeṣāpi na saṃvitkiṃ satyatāmupagacchati
]

`v 28 [
na piśācapramā satyā madaśaktimato'pi hi |
pratibhāsya na satyā syātparalokātmikā katham
]

`v 29 [
piśāco'stīti cetsaṃvitsatyārthā tena saṃvidaḥ |
mṛtasyāsti paro loka ityasyāṃ kiṃ na satyatā
]

`v 30 [
kākatālīyavaddehātpaiśācī jñaptirasti cet |
paralokārthasaṃvittiḥ kathaṃ nāsti sakāraṇā
]

`v 31 [
yāntarvetti yathā saṃvitsā tathānubhavatyalam |
astu satyamasatyaṃ vā siddhamityanubhūtitaḥ
]

`v 32 [
mṛtasyāsti paro loko vidityevaṃmayī bhavet |
sati vā'sati dehe'smiṃstena kiṃ sadasacca kim
]

`v 33 [
tasmātsvabhāvaḥ prathamaṃ prasphuranvetti saṃvidam |
vāsanākāraṇaṃ paścādbuddhvā saṃpaśyati bhramam
]

`v 34 [
sa yadi brūyātkāyākārapariṇatebhyo bhūtebhyaḥ saṃvidudbhavānna mṛtasya
kāyanāśe pāralaukikī saṃvidudbhaviṣyatīti tarhi sa saṃvidaḥ
śāśvatatvātsvataḥsiddhatvātpratyuta tatsiddhibalenaiva vāsanāmayasyātivāhikadehasya
tatkalpitasthūladehasya bāhyaprapañcasya ca paścātsiddhestadanyasya
dṛśyasiddhihetoraprasiddherna dehādīnaṃ saṃvijanmeti prativaktavya iti
sūcayaṃstatprativacanamupasaṃhṛtya vāsanāyāṃ vilīnāyāmadarśanamupāgatā
ityādinā prāganukrāntaṃ vāsanākṣayādeva sarvadṛśyocchedaṃ samarthayituṃ
prastauti - tasmādityādinā | tasmādvedādipramāṇasya jñānānāṃ
svataḥprāmāṇyasya ca siddhatvājjñānasvabhāvaḥ paramātmā
svaprakāśatvātsarvavyavahārātprathamaṃ svarūpāṃ saṃvidaṃ svata eva nityasiddhāṃ
vetti na tadvedanaphalamanyato'pekṣate svauṣṇyaprakāśātmatāmiva vahnirityarthaḥ |
vāsanānāṃ kāraṇamudbhavopādānaṃ sarvajagadvāsanāmayam ātivāhikadehaṃ tu tataḥ
paścātsṛṣṭijāgradārambhakṣaṇe svarūpacitsvabhāvabalādeva buddhvā tato
dehādibhramaṃ saṃpaśyatīti na sarvataḥ pūrvasiddhasaṃvitsiddhirdehādhīneti bhāvaḥ |
33 |
tatkṣayācchamamāyāti draṣṭṭadṛśyadṛgāmayaḥ |
tatsattāyāmudetīyaṃ saṃsṛtyākhyā piśācikā
]

`v 35 [
upalambha udetyādau brahmaṇo vāsanā tataḥ |
tacchāntiṃ viddhi nirvāṇaṃ tatsattāṃ saṃsṛtibhramam
]

`v 36 [
utpannaiva ca sānādau parabrahmaṇyasaṃbhavāt |
utpannā samayādyāsau brahmaiva parameva sat
]

`v 37 [
etāvadyatparijñānaṃ tannirvāṇaṃ vidurbudhāḥ |
yadatraivāparijñānaṃ taṃ bandhaṃ viddhi rāghava
]

`v 38 [
vijñānaghana evāyaṃ kacanākacanātmakaḥ |
svayameva kacatyantarna kacatyeva vā svayam
]

`v 39 [
saṃvidaṃśaparāvṛttimātre pelavarūpiṇi |
bandhadṛṅmokṣadṛk ceti kleśastatsādhanaṃ kiyat
]

`v 40 [
saṃvidudbodhane bandhastadanudbodhane śivam |
asatsadvajjagadbhāti saṃvidudbodhanodaram
]

`v 41 [
ajaḍaṃ vedanaṃ suptaṃ mokṣa ityabhidhīyate |
prabuddhaṃ ityāhuryadicchasi tadāhara
]

`v 42 [
nirvāṇavāsanamanantamanādyamacchabodhaikatānamapayantraṇamastaśaṅkam |
advaitamaikyarahitaṃ ca nirastaśūnyamākāśakośaviśadāśayaśāntamāsva
]