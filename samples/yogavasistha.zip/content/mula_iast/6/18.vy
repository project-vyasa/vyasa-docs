`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīvasiṣṭha uvāca |
maraṇaṃ sarvanāśātma na kadācana vidyate |
svasaṃkalpāntarasthairyaṃn mṛtirityabhidhīyate
]

`v 2 [
paśyeme pura uhyanta iva mandarameravaḥ |
arūḍhā api digvātaiḥ saridbimbitaśailavat
]

`v 3 [
uparyuparyantarataḥ kadalīdalapīṭhavat |
śliṣṭāśliṣṭasvarūpāḥ khe mithaḥ saṃsṛtayaḥ sthitāḥ
]

`v 4 [
śrīrāma uvāca |
paśya me pura uhyanta iti vākyārthamakṣatam |
na kiṃcidavagacchāmi yathāvanmunināyaka
]

`v 5 [
uktamarthamasaṃbhāvayan rāmaḥ pṛcchati - paśyeti | yathāvatkathayeti śeṣaḥ | 4
|
śrīvasiṣṭha uvāca |
prāṇasyābhyantare cittaṃ cittasyābhyantare jagat |
vidyate vividhākāraṃ bījasyāntariva drumaḥ
]

`v 6 [
mṛte puṃsi nabhovātairmilanti prāṇavāyavaḥ |
sarijjalairivāmbhodhijalānyātmadrutāni hi
]

`v 7 [
itaścetaśca yāntīva teṣāmantarjagantyalam |
vyomavātavinunnānāṃ saṃkalpaikātmakānyapi
]

`v 8 [
saprāṇavātaiḥ pavanaiḥ sphuratsaṃkalpagarbhitaiḥ |
sarvā eva diśaḥ pūrṇāḥ paśyāmīmāḥ samantataḥ
]

`v 9 [
atraite paśya paśyāmi saṃkalpajagatāṅgaṇe |
buddhidṛṣṭyā samuhyante puro mandarameravaḥ
]

`v 10 [
khavāte'ntarmṛtaprāṇāḥ prāṇānāmantare manaḥ |
manaso'ntarjagadviddhi tile tailamiva sthitam
]

`v 11 [
khavātaiḥ khasamāḥ prāṇā yathohyante manomayāḥ |
uhyante vai tathaitāni tadaṅgāni jagantyapi
]

`v 12 [
sabhūtānyambarorvyādivṛndāni trijagantyapi |
uhyante cāpyarūḍhāni puraḥ sarvatra gandhavat
]

`v 13 [
tāni buddhyaiva dṛśyante na dṛṣṭyā raghunandana |
puraḥ saṃkalparūpāṇi svasvapnapurapūravat
]

`v 14 [
sarvatra sarvadā santi susūkṣmāṇyeva khādapi |
kalpanāmātrasāratvānna cohyante manāgapi
]

`v 15 [
tānyeva dṛḍhabhāvatvātsveṣu lokeṣu teṣvalam |
satyānyeva cidaṃśasya sarvagatvādbhavāniva
]

`v 16 [
pratibimbaṃ purāṇīva puraḥprāṇasaridraye |
arūḍhānyapi cohyante rūḍhānyapi ca naiva ca
]

`v 17 [
saurabhāṇi samuhyante vātāṅgasthāni rāghava |
jaganti prāṇasaṃsthāni vyomātmakamayāni tu
]

`v 18 [
kumbhe deśāntaraṃ nīte yathāntarvyomni nānyatā |
spandanādimaye citte tathaiva trijagadbhrame
]

`v 19 [
itthaṃ na sajjagadbhrāntirasatyaivoditeva te |
na vinaśyati nodeti kevalaṃ brahmarūpiṇī
]

`v 20 [
yadi vāpyudite vātaistattadasyā na lakṣyate |
tadantaḥsaṃsthitaiḥ spando nāvi kośagatairiva
]

`v 21 [
yathā spando'ṅgalagnāyāṃ nābyantaḥsaṃsthitairapi |
na lakṣyate yathā pṛthvyāṃ `note[yadyapi tathā brahmaṃstatsaṃsthaiḥ iti pāṭho
dṛśyate tathāpi brahmanniti saṃbodhanasya rāmaṃ pratyayogyatvānna
sadhrīcīnaḥ |] tatsaṃsthaistanmayairapi
]

`v 22 [
yathā yojanavistīrṇaṃ laghau sadmānubhūyate |
yattasya pādapastambhe paramāṇau yathā jagat
]

`v 23 [
vastvalpamapyatibṛhallaghusattvo hi manyate |
mūṣikāḥ svāñjalidravyaṃn navapaṅkamivārbhakāḥ
]

`v 24 [
paramāṇvāderbṛhattamatvakalpayā na vā tatra bṛhato jagataḥ samāveśo'nubhavitavya
ityāśayenāha - vastviti | tadyathā ratnakośāgāre praviṣṭā asvā
dhanasaṃbandhaśūnyā mūṣikā na ratnāni bahu manyante kiṃtvañjalimātramitamapi
dhānyadravyameva tatra daivāllabdhaṃ bahu manyante yathā vā arbhakā bahumūlyānyapi
svābharaṇāni nityamanubhūyamānāni na bahu manyante kiṃtu navamapūrvaṃ
mṛgapakṣyākāraṃ varṇakādipariṣkṛtaṃ paṅkaṃ mṛtpiṇḍameva krīḍanāya bahu
manyante yena taddānena vañcitāḥ svābharaṇānyapi vinimayena prayacchantītyarthaḥ | 23
|
asatyeva svarūpe'smiñjagadākhye vido bhrame |
lokāntarādharmamayī `note[atrādharmapadamupalakṣaṇaṃ dharmasyetyapīti
dharmādharmaphalānīti vyākhyātam |] sā bṛhaṃgasya bhāvanā
]

`v 25 [
idaṃ heyamupādeyamidamityantarajñatā |
yasya tasya bhavāyāsti sarvajñasyāpi mūḍhatā
]

`v 26 [
sacetano hyavayavī cetatyavayavānyathā |
svāntareva tataṃ jīvastrijagadbudhyate tathā
]

`v 27 [
saṃvidātmaparākāśamanantamajamavyayam |
vyomno'vayavarūpāṇi tasyemāni jaganti bhoḥ
]

`v 28 [
sacetano'yaḥpiṇḍo'ntaḥ kṣurasūcyādikaṃ yathā |
buddhyate buddhyate tadvajjīvo'jñastrijagadbhramam
]

`v 29 [
aciccidvāpi mṛtpiṇḍaḥ śarāvodañcanādikam |
yathāṅga manute jīvastathāṅga manute jagat
]

`v 30 [
cidacidvāṅkuro dehe vṛkṣatvaṃ manyate yathā |
vṛkṣaśabdārtharahitaṃ brahmedaṃ trijagattathā
]

`v 31 [
cidvācidvā yathādarśo bimbitaṃ vāpyabimbitam |
nagaraṃ vetti no vāpi tathā brahma jagattrayam
]

`v 32 [
deśakālakriyādravyamātrameva jagattrayam |
ahaṃtvajagatostena bhedo nāstyetadātmanoḥ
]

`v 33 [
evaṃ rāmapraśnānsamādhāya prāsaṅgikaṃ ca sarvaṃ samāpya nāhaṃtvajagatī bhinne
pavanaspandane yathā | iti prākprastutārthaṃn prakārāntareṇa samarthayitumanusaṃdhatte
- deśeti | ahaṃtvamapi
deśakālakriyādravyatādātmyasaṃsargābhimānātmakatvāttadrūpamevetye##-
kalpitenopamānena yadetadupadiśyate |
tatropamaikadeśena upameyasadharmatā
]

`v 34 [
yadidaṃ dṛśyate kiṃcijjagatsthāvarajaṅgamam |
amuñcataḥ parāṇutvaṃ jīvasyaitatsmṛtaṃ vapuḥ
]

`v 35 [
sarvasaṃvedanatyāge śuddhasaṃspandade pade |
na manāgapi bhedo'sti niḥsaṅgopalakośavat
]

`v 36 [
yo yo nāma vikalpāṃśo yatra yatra yathā yathā |
yadā yadā yena yena dīyate sa tathaiva cit
]

`v 37 [
acittvānnāsti manasi saṃkalpaḥ kha ivāṅkuraḥ |
cittvāttu cetaso viddhi citireveha kalpanam
]

`v 38 [
yā yodeti vikalpaśrīraprabuddhāśayaṃ prati |
sarvagatvādanantatvāccidvyomnaḥ sā na sanmayī
]

`v 39 [
yathodeti vikalpaśrīḥ prabuddhe noditaiva sā |
sarvagatvādanantatvāccidvyomnaḥ sā na sanmayī
]

`v 40 [
sarvasaṃkalpakalanā satyetyābālamakṣatam |
svapnādāvanubhūtontararthaḥ kenāpi labhyate
]

`v 41 [
saṃkalpo vāsanā jīvastrayo'rthā likhitāścitā |
sonubhūto'pyasatyaḥ syādasattvasyaiva no sataḥ
]

`v 42 [
asatyatābhidhaṃ satyaṃn mukta eva bhavecchivaḥ |
sātivāhikadehaikaparikṣayavikāsavān
]

`v 43 [
jaganti vātairuhyante vyomni śālmalitūlavat |
nohyante copalānīva na ca santyeva kalpanāt
]

`v 44 [
ityasminnakhilapadārthasārthakośe vyomanyapyativitate jaganti santi |
anyonyaṃ parimilitāni kānicicca nānyonyaṃ parimilitāni kāninicca
]

`v 45 [
iti varṇitarītyā asminnakhilapadārthasamūhānāṃ kośabhūte ajñāte
pratīciparamārthato'tivitate vyomani śūnyākāśakalpe'pyavidyayā anantāni jaganti santi |
tāni ca katipayānāṃ jīvānāṃ bhojakādṛṣṭasāmye jāgare brahmāṇḍaikye ca anyonyaṃ
parimilitāni | tadvaiṣamye tu brahmāṇḍabhede svapne ca nānyonyaṃ parimilitānītyarthaḥ |
44 |
sarvatvātparamaciteranantarūpāṇyārambhapracuradigantasaṃbhṛtāni |
lolāmbūdarapurabimbabhaṅgurāṇi svāntaḥsthāviralamahāpuropamāni
]

`v 46 [
sasthairyāṇyapi satataṃ kṣaṇakṣayā.in vyaktākṣāṇyapi satataṃ nimīlitāni |
sālokānyapi paritastamovṛtāni cidrūpārṇavalaharīvivartanāni
]

`v 47 [
pṛthaksthitāni vyatimiśritāni jalāni caivāmbunudhau nadīnām |
tārārkacandragrahamaṇḍalānāṃ samoditānāṃ nabhasīva bhāsaḥ
]