`v 1 [
ekapañcāśadadhikaśatatamaḥ sargaḥ 151
anyamuniruvāca |
tatra te nagaraṃ tāni gṛhāṇi taravaśca te |
kṣipreṇa śuṣkatṛṇavatsarvaṃ bhasmatvamāgatam
]

`v 2 [
tatraivaṃ bhasmatāṃ prāpte supte te bhavatastava |
tanū tathātisaṃtāpavidāritamahāśile
]

`v 3 [
sa śaśāma śanairvahnirniḥśeṣīkṛtakānanaḥ |
paripītārṇavo'gastya ivāstaṃ samupāyayau
]

`v 4 [
tasminnastaṃ gate vahnau tadbhasmeddhaṃ suśītalam |
dudhāva kaṇaśo vāyuraśeṣaṃ puṣparāśivat
]

`v 5 [
tato na jñāyate nāsītkvāśramaḥ kva tanū tathā |
kva peṭakaṃ bahūnāṃ tatsvapnapūrjāgrato yathā
]

`v 6 [
abhāvamupayāte te yadaivaṃ bhavatastanū |
svapataste bhramavataḥ saṃvideva vijṛmbhate
]

`v 7 [
tasmātkva tadgalabilaṃ virāḍātmā sa ca kva te |
dagdho dagdhasya saujaskaḥ saujaskasyaiva dehakaḥ
]

`v 8 [
labdhavānasi no tasmāddhetordehadvayaṃ mune |
anante svapnasaṃsārajāgratīhāvatiṣṭhase
]

`v 9 [
tadevaṃ svapna evāyaṃ jāgradbhāvamupāgataḥ |
sarve vayamiha svapnapuruṣāstava suvrata
]

`v 10 [
asmākaṃ tvaṃ svapnarastava svapnanarā vayam |
ayameva cidākāśaḥ sarvadātmātmani sthitaḥ
]

`v 11 [
tataḥ prabhṛti saṃpanno bhavānsvapnanaro bhavan |
jāgratpratyayavāñjāgrannaro gārhasthyasusthitaḥ
]

`v 12 [
etatte kathitaṃ sarvaṃ yathāvṛttamaśeṣaḥ |
anubhūtaṃ sudṛśyaṃ ca dhyānenaitacca paśyasi
]

`v 13 [
ityādimadhyarahito'yamanantarūpaḥ saṃvidghanaḥ kacati kāñcanatāpavatkhe |
tatphālalolavapurātmani cinmayātmā sargātmabhirvikasitairasitaiḥ sitaiśca
]