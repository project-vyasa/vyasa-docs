`v 1 [
dvātriṃśādhikaśatatamaḥ sargaḥ 132
bhāsa uvāca |
mandare mṛdumandāramandire mandarābhidhām |
āliṅgyāpsarasaṃ suptaṃ sarittṛṇamivānayat
]

`v 2 [
māmathāsau mayā pṛṣṭā samāśvāsya jalākulā |
bāle kimidamityuktaṃ tayā capalanetrayā
]

`v 3 [
iha candrodayeṣvetāścandrakāntakaṭaprajāḥ |
nadyo mādyanti vanitāḥ seṣṭā iva niśāgame
]

`v 4 [
tvatsaṃgamarasāveśavaśāttannanu vismṛtam |
ityuktvā māmupādāya soḍḍīnā vihagīva kham
]

`v 5 [
bhṛṅgaṃ śṛṅgavataḥ śṛṅge gaṅgākanakapaṅkaje |
ahamāsaṃ samāḥ sapta tatklinno'kardamāplute
]

`v 6 [
anyanmayā jagaddṛṣṭamṛkṣacakravivarjitam |
garbhagarbhasthaikajātisvaprakāśajanāvṛtam
]

`v 7 [
na digvibhāgo na dināni yatra na caiva śāstrāṇi na vedavādāḥ |
na caiva daityādisurādibhedo jaganmayā tādṛgathātmadīptam
]

`v 8 [
vidyādharāmaravihāravimānabhūmāvabhraṃlihācalanitambakadambakacche |
āsaṃ samāḥ samaraso'marasomanāmā saptānyasapta sasamudrataṭe tapasvī
]

`v 9 [
pavanavahanasaṃniveśanānāsuhayapayodharadehakairanekaiḥ |
gajahariṇamṛgendravṛkṣavallīmṛganagapannagapakṣibhiḥ parītam
]

`v 10 [
gaganamavanitaḥ sametya vahnervaravibhavena jagatyanantakośam |
kvacidahamabhito didṛkṣuragre sṛta uragāśanavadbalādavidyām
]

`v 11 [
kvacidahaṃ jagataḥ parinirgataḥ patita ekamahārṇavavistṛte |
nabhasi tatra nivāsinibhe sitaḥ samayamanvabhavaṃ patanaṃ tathā
]

`v 12 [
ākāśakośapatanānubhavaikavṛtteḥ śrāntasya me padamakāryatha nidrayāntaḥ
|
tādṛksuṣuptavapuṣātha mayopalabdhaṃ svapnātmajāgrati tadātmani tatra viśvam
]

`v 13 [
bhūyo digantabhuvanāmaramandarādrisaṃsāracañcalatayā latayeva pakṣī |
akṣīṇavātabalayā paricālyamānastanmāsu tāsu patito hi jagadguhāsu
]

`v 14 [
viṣayāśā dṛśo yāvattāvadyātaḥ kṣaṇādaham |
punastathaiva paśyaṃstu dṛśyaṃ yātaḥ punaḥ punaḥ
]

`v 15 [
iti dṛśyamadṛśyaṃ ca gamyaṃ cāgamyameva ca |
vegāllaṅghayato deśaṃ mama varṣagaṇā gatāḥ
]

`v 16 [
dṛśyākhyāyā avidyāyā na tvantaṃ prāptavānaham |
mithyaiva hṛdi rūḍhāyāḥ piśācyā iva bālakaḥ
]

`v 17 [
nedaṃ nedaṃ sadityeva vicārānubhave sthitam |
tathāpīdamidaṃ ceti durdṛṣṭirna nivartate
]

`v 18 [
pratikṣaṇaṃ sukhairduḥkhairdeśakālaiḥ samāgamaiḥ |
saridvārivadālolā navamāyānti yānti ca
]

`v 19 [
tālītamālabakulātulatuṅgaśṛṅgamunnādavātajavamekamahaṃ smarāmi |
sūryādibhirvirahitaṃ prakaṭaṃ svakāntyā sasthāvarādritaṭajaṅgamameva viśvam
]

`v 20 [
yadetadekāntavihārahāri svacchandamekāmitamastaśaṅkam |
kvacinmayā cārujagatsu dṛṣṭaṃ tulyā na tasyāmararājalakṣmīḥ
]