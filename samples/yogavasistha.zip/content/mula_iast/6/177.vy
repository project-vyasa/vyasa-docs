`v 1 [
saptasaptatyadhikaśatatamaḥ sargaḥ 177
śrīrāma uvāca |
akāraṇakamevedaṃ jagadbrahma parātpadāt |
yadi pravartate nāma svapnasaṃkalpanādivat
]

`v 2 [
tadakāraṇataḥ siddheḥ saṃbhave'nyadakāraṇam |
kathaṃ na jāyate vastu kvacitkiṃcitkadācana
]

`v 3 [
śrīvasiṣṭha uvāca |
yadyathā kalpitaṃ yena sa saṃpaśyati tattathā |
kalpanaivānyathā na syāttādṛkkāraṇavicyuteḥ
]

`v 4 [
yathedaṃ kalpitaṃ dṛśyaṃ manasā yena tattathā |
vettyasau yādṛganyena kalpitaṃ vettyasau tathā
]

`v 5 [
kalpanākalpanātmaikaṃ tacca brahma svabhāvataḥ |
kalpanātmedṛśaṃ janturyathā keśanakhādimān
]

`v 6 [
akāraṇapadārthatvaṃ sakāraṇapadārthatā |
brahmaṇi dvayamapyasti sarvaśaktyātma tadyataḥ
]

`v 7 [
yataḥ syādbrahmaṇastvanyatkvacitkiṃcitkadācana |
tatkāraṇavikalpena saṃyogastasya yujyate
]

`v 8 [
yatra sarvamanādyantaṃ nānānānātma bhāsate |
brahmaiva śāntamekātma tatra kiṃ kasya kāraṇam
]

`v 9 [
neha pravartate kiṃcinna ca nāma nivartate |
sthitamekamanādyantaṃ brahmaiva brahma khātmakam
]

`v 10 [
kiṃ kasya kāraṇaṃ kena kimarthaṃ bhavatu kva vā |
kiṃ kasya kāraṇaṃ kena kimarthaṃ māstu vā kvacit
]

`v 11 [
neha śūnyaṃ na vā śūnyaṃ na sannāsanna madhyatā |
vidyate na mahāśūnye na neti na na neti ca
]

`v 12 [
idaṃ na kiṃcitkiṃcidvā yannāmāstyatha nāsti vā |
sarvaṃ brahmaiva tadviddhi yattathaivātathaiva tat
]

`v 13 [
śrīrāma uvāca |
atajjñaviṣaye brahmankārye kāraṇasaṃbhave |
kimakāraṇatātma syātkathaṃ veti vada prabho
]

`v 14 [
śrīvasiṣṭha uvāca |
atajjño nāma nāstyeva tāvattajjñajanaṃ prati |
asato vyomavṛkṣasya vicāraḥ kīdṛśastataḥ
]

`v 15 [
ekabodhamayāḥ śāntavijñānaghanarūpiṇaḥ |
tajjñāsteṣāmasadrūpe kathamarthe vicāraṇā
]

`v 16 [
atajjñatvaṃ ca bodhe'ntaravabhāti tadaṅgatā |
gate svapnasuṣupte'ntarivanidrātma kevalam
]

`v 17 [
nanu brahmātiriktaḥ atajjño nāstīti kathaṃ saṃbhāvyate | tārkikaiḥ pāmaraiśca nāhaṃ
brahma nāhaṃ brahmajñaśceti svātmanyatattvajñatvābrahmatvayoḥ
pratyakṣamanubhavādityāśaṅkya tādṛśānubhavabalenaiva tadātmanāmapi
brahmatvaṃ samarthayati - atajjñatvamiti |
ajñānādisarvajagadāropādhiṣṭhānacinmātratvaṃ hi brahmatvam | taccāhamajña
ityanubhavitari tārkikātmani durvāram | yataḥ ajñatvaṃ prabodharūpe
ātmanyantaravabhāti | yadi ca vaiśeṣikakalpito jaḍo'yamātmā syāt
kathamātmanyajñānamanubhavet | ataḥ
ajñānādhiṣṭhānacidrūpatvamasmādevānubhavātsiddham | jagacca
kevalamajñānātmaiva yatastadaṅgatāṃ gatam | yathā svapnasuṣupte
nidrāntarnidrāṅgatāṃ gate kevalaṃ nidraiva na nidrāvyatiriktaṃ tayoḥ svarūpamasti
tadvat | na ca jñānasvabhāve ātmani svabhāvaviruddhamajñānamāropamantareṇa
bhavitumarhatītyajñānādijagadāropādhiṣṭhānatvasyāsmādevānubhavāt##-
tathāpyabhyupagamyāpi mūrkhaniścaya ucyate |
mayedamaṇu sarvātma yasmādbrahma nirāmayam
]

`v 18 [
santyakāraṇakā eva santi kāraṇajāstathā |
bhāvāḥ saṃvidyathā yasmātkalpyate labhyate tathā
]

`v 19 [
sarvakāraṇasaṃśāntau sarvānubhavaśālinām |
sargasya kāraṇaṃ nāsti tena sargastvakāraṇaḥ
]

`v 20 [
hṛdayaṃgamatātyaktamīśvarādi prakalpyate |
yadatra kiṃcidduḥsvādu vyarthaṃ vāgjālameva tat
]

`v 21 [
anyathānupapattyaiva svapnābhākalanādṛte |
sthūlākārātmikā kācinnāsti dṛśyasya dṛśyatā
]

`v 22 [
svapnapṛthvyādyanubhave kimabuddhasya kāraṇam |
citsvabhāvādṛte brūi svapnārtho nāma kīdṛśaḥ
]

`v 23 [
svapnārtho hyaparijñāto mahāmohabharapradaḥ |
parijñāto na mohāya yathā sargāstathaiva ca
]

`v 24 [
śuṣkatarkahaṭhāveśādyadvāpyanubhavojjhitam |
kalpyate kāraṇaṃ kiṃcitsā maurkhyābhiniveśitā
]

`v 25 [
agnerauṣṇyamapāṃ śaityaṃ prākāśyaṃ sarvatejasām |
svabhāvo vākhilārthānāṃ kimabuddhasya kāraṇam
]

`v 26 [
kiṃ dhyātṛśatalabdhasya dhyeyasyaikasya kāraṇam |
kiṃ ca gandharvanagare pure bhittiṣu kāraṇam
]

`v 27 [
dharmādyamutrāmūrtatvānmūrte dehe na kāraṇam |
dehasya kāraṇaṃ kiṃ syāttatra sargādibhoginaḥ
]

`v 28 [
bhittyabhittyādirūpāṇāṃ jñānasya jñānavādinaḥ |
kiṃ kāraṇamanantānāmutpannadhvaṃsināṃ muhuḥ
]

`v 29 [
svabhāvasya svabhāvo'sau kila kāraṇamityapi |
yaducyate svabhāvasya sā paryāyoktikalpanā
]

`v 30 [
svabhāvavādinaścārvākasya mataṃ nirasyati - svabhāvasyeti | aṅkurādisvabhāvasya
kālakṣetrajalādisahitabījādisvabhāvo'sau kāraṇamiti cārvākairyaducyate sā uktirapi
bījasvabhāvapadayorarthabhedānirūpaṇādaṅkurasvabhāvasyetyatratyasvabhāvapade
ṣaṣṭhyarthasaṃbandhasyāpi daurlabhyānnānārthatve ubhayatrāpi paryāyatayā
sahaprayogānāpatteḥ sakalasādhāraṇasvabhāvatvasāmānyāprasiddheḥ
prātisvikarūpāparāmarśaprasaṅgāccaikārthyāghaṭanācca nirarthikoktiḥ setyarthaḥ | 29
|
tasmādakāraṇā bhrāntirbhāvā bhānti ca kāraṇam |
ajñe jñe tvakhilaṃ kāryaṃ kāraṇādbhavati sthitam
]

`v 31 [
yadvatsvapnaparijñānātsvapne dravyāpahāribhiḥ |
na duḥkhākaraṇaṃ tadvajjīvitaṃ tattvadarśanāt
]

`v 32 [
sargādāveva notpannaṃ dṛśyaṃn cidgaganaṃ tvidam |
svarūpaṃ svapnavadbhāti nānyadatropapadyate
]

`v 33 [
anyā na kācitkalanā dṛśyate sopapattikā |
asmānnyāyādṛte kasmādbrahmaivaiṣānubhūtibhūḥ
]

`v 34 [
ūrmyāvartadravatvādi śuddhe jalaghane yathā |
tathedaṃ sargaparyāyaṃ brahmaṇi brahma bhāsate
]

`v 35 [
spandāvartavivartādi nirmale pavane yathā |
tathāyaṃ brahmapavane sargaspando'vabhāsate
]

`v 36 [
yathānantatvasauṣiryaśūnyatvādi mahāmbare |
sa sannāsannabodhātma tathā sargaḥ prāparaḥ
]

`v 37 [
eṣu nidrādikeṣvete sūpalabdhā api sphuṭam |
bhāvā asanmayā evamete'nanyātmakā yataḥ
]

`v 38 [
sargapralayasaṃsthānānyevamātmani cidghane |
saumye svapnasuṣuptābhā śuddhe nidrāghane yathā
]

`v 39 [
svapnātsvapnāntarāṇyāste nidrāyāṃ mānavo yathā |
sargātsargāntarātmāste `note[antarāṇyāste iti pāṭhaḥ |] svasattāyāmajastathā |
39 |
ajaḥ janmādiśūnyaḥ paramātmā svayameva sargātsargāntarātmanā āste
]

`v 40 [
pṛthvyādirahito'pyeṣa brahmākāśo nirāmayaḥ |
atadvāṃstadvadābhāti yathā svapnānubhūtiṣu
]

`v 41 [
sthitā yathāsyāṃ paśyantyāṃ śabdā ghaṭapaṭādayaḥ |
jātājātāḥ sthitāḥ sargāstathānanye mahāciti
]

`v 42 [
paśyantyāmeva paśyantī yathā bhāti tathaiva ca |
yathā śabdāstathā sargāścitaiva citi cinmayāḥ
]

`v 43 [
kiṃ śāstrakaṃ tatrakathāvicārairnnirvāsanaṃ jīvitameva mokṣaḥ |
sarge tvasatyevamakāraṇatvātsatyeva nāstyeva na nāma kācit
]

`v 44 [
eṣā ca siddheha hi vāsaneti sā bodhasattaiva nirantaraikā |
nānātvanānārahitaiva bhāti svapne cideveha purādirūpā
]