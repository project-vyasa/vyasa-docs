`v 1 [
trisaptatyadhikaśatatamaḥ sargaḥ 173
śrīrāma uvāca |
sarvānubhavarūpasya tathā sarvātmano'pyayam |
anantasyātmatattvasya dehe'pi kimahaṃgrahaḥ
]

`v 2 [
citaḥ pāṣāṇakāṣṭhatvaṃ svapnādiṣu kathaṃ bhavet |
idaṃ pāṣāṇakāṣṭhādi kathaṃ nāstyasti vā katham
]

`v 3 [
śrīvasiṣṭha uvāca |
śarīriṇo yathā haste hastatāyāṃ yathāgrahaḥ |
sarvātmanastathā dehe dehatāyāṃ tathāgrahaḥ
]

`v 4 [
pādapasya yathā patre patratāyāṃ yathāgrahaḥ |
sarvātmanastathā vṛkṣe vṛkṣatāyāṃ tathāgrahaḥ
]

`v 5 [
ākāśasya yathā śūnye śūnyatāyāṃ yathāgrahaḥ |
sarvātmanastathā dravye dravyatāyāṃ tathāgrahaḥ
]

`v 6 [
dravye maṇimuktāsvarnādidhane | dravyatāyāṃ prayatnopārjyatālakṣaṇabhavyatāyām | 5
|
svapnocitaḥ svapnapure rūpatāyāṃ yathāgrahaḥ |
sarvātmanastathā svapnajāgradādau tathāgrahaḥ
]

`v 7 [
yathāgendre dṛṣadvṛkṣavāryādau sa tathāgrahaḥ |
tathā sarvātmano'gendrapuratāyāṃ tathāgrahaḥ
]

`v 8 [
śarīrasya yathā keśanakhādiṣu yathāgrahaḥ |
sarvātmanastathā kāṣṭhadṛṣadādau tathāgrahaḥ
]

`v 9 [
cita eva yathā svapne bhavetkāṣṭhopalāditā |
cidākāśasya sargādau tathaivāvayavāditā
]

`v 10 [
cetanācetanātmaikaṃ puruṣasya yathā vapuḥ |
nakhakeśajalākāśadharmamākārabhāsuram
]

`v 11 [
cetanācetanātmaikaṃ tathā sarvātmano vapuḥ |
jaṅgamaṃ sthāvaramayaṃ kiṃtu nityamanākṛti
]

`v 12 [
yathāsthitaṃ śāmyatīdaṃ samyagjñānavato jagat |
svapne svapnaparijñāturyathā dṛṣṭārthasaṃbhramaḥ
]

`v 13 [
ata eva tattvatastajjñānātsarve viruddhadharmāḥ śāmyantītyāha - yathāsthitamiti | 12
|
cinmātrākāśamevedaṃ na draṣṭāsti na dṛśyatā |
iti maunamalaṃ svapnadraṣṭuryatsā prabuddhatā
]

`v 14 [
kalpakoṭisahasrāṇi sargā āyānti yānti ca |
ta evānye ca cidvyomni jalāvartā ivārṇave
]

`v 15 [
karotyabdhau yathormyādau nānā kacakacaṃ vapuḥ |
citkaroti tathā saṃjñāḥ sargādyāścetane nije
]

`v 16 [
yathāsthitamidaṃ viśvaṃ brahmaivānāmayaṃ sadā |
tattvajñaṃ pratyatattvajñajanatāniścayādṛte
]

`v 17 [
nāhaṃ taraṅgaḥ salilamahamityeva yuktitaḥ |
buddhaṃ yena taraṅgena kutastasya taraṅgatā
]

`v 18 [
brahmaṇo'sya taraṅgatvamivābhānaṃ yatastataḥ |
taraṅgatvātaraṅgatve brāhmyau śaktī sthitiṃ gate
]

`v 19 [
cidvyomno'tyajato rūpaṃ svapnavadvyastavedanam |
tadidaṃ hi mano rāma brahmetyuktaḥ pitāmahaḥ
]

`v 20 [
evamādyaḥ prajānātho nirākāro nirāmayaḥ |
cinmātrarūpasaṃkalpapuravtkāraṇojjhitaḥ
]

`v 21 [
yenāṅgadatvaṃ nāstīti buddhaṃ hemāṅgadena vai |
aṅgadatvaṃ kutastasya tasya śuddhaiva hematā
]

`v 22 [
aje saṃkalpamātrātma cinmātravyomadehini |
ahaṃ tvaṃ jagadityādi yadvibhātaṃ tadeva tat
]

`v 23 [
ciccamatkṛayo bhānti yāścidvyomani śūnyatāḥ |
etāstāḥ sargasaṃhārasthitisaṃrambhasaṃvidaḥ
]

`v 24 [
acchaṃ cinmātranabhasaḥ kacanaṃ svayameva tat |
svapnābhaṃ cittatāmātraṃ sa eṣa pratipāmahaḥ
]

`v 25 [
yathā taraṅgastenaiva rūpeṇānyena vā'niśam |
sphuratyevamanādyantaḥ sargapralayavibhramaḥ
]

`v 26 [
cidvyomnaḥ kacanaṃ kāntaṃ yadvirāḍiti śabditam |
bhavetsaṃkalpapuravattasya kuryānmano'pi vai
]

`v 27 [
sargaḥ svapnaḥ svapna ev jāgraddehaḥ sa eva ca |
ghanaṃ suṣuptaṃ taimiryādyathā saṃvedanaṃ bhavet
]

`v 28 [
tasya kalpāntarajanī śiroruhatayoditā |
prakāśatamasī kālakriyākhyāḥ svāṅgasaṃdhayaḥ
]

`v 29 [
tasyāgnirāsyaṃ dyaurmūrdhāṃ khaṃ nābhiścaraṇau kṣitiḥ |
candrārkau dṛgū diśau śrotre kalpaneti vijṛmbhitā
]

`v 30 [
diśau prācīpratīcyau śrotre ityanayā rītyā manaḥkalpanaiva virāḍākāreṇa vijṛmbhitā |
29 |
evaṃ samyagdṛśyamāno vyomātmā vitatākṛtiḥ |
asmatsaṃkalpaśailābho virāḍ svapnākṛtisthitaḥ
]

`v 31 [
yacca cetaccidākāśe svayaṃ kacakacāyate |
tadetajjagadityevaṃ tenātmaivānubhūyate
]

`v 32 [
virāḍātmaivamākāśaṃ bhāti cinmayamātatam |
svabhāvasvapnanagaraṃ naganāgamayātmakam
]

`v 33 [
anubhavitaivānubhavaṃ satyaṃ svātmānamapyasantamiva |
anubhavatīyattvena svapnanaṭaḥ svapnadeśamiva
]

`v 34 [
vedāntārhatasāṃkhyasaugatagurutryakṣādisūktā dṛśo brahmaiva sphuritaṃ
tathātmakalayā stādātmanityaṃ yataḥ |
teṣāṃ cātmavido'nurūpamakhilaṃ svargaṃ phalaṃ tadbhavatyasya brahmaṇa
īdṛgeva mahimā sarvātma yattadvapuḥ
]