`v 1 [
dvisaptatyadhikaśatatamaḥ sargaḥ 172
śrīvasiṣṭha uvāca |
evaṃ pṛthvyādirahitaḥ khamevādyaḥ prajāpatiḥ |
manomātramahaṃ manye saṃkalpaviṭapī yathā
]

`v 2 [
mana ityabhidhānena paścādāsthā prakalpitā |
vāryāvartavivartena protthāyāvartatā yathā
]

`v 3 [
sattāmātrātmanastasya kuto buddhyādayaḥ kila |
avidyamāne pṛthvyādau khasyānantasya kiṃ rajaḥ
]

`v 4 [
na tasya dehacittādi nendriyāṇi na vāsanāḥ |
sadapyetatsadā tasya na kiṃcidapi vidyate
]

`v 5 [
prāktanasya prajeśasya muktatvātkathameva ca |
bhūyaḥ saṃbhavati prājña na smṛtirna ca saṃbhavaḥ
]

`v 6 [
na bhavatyeva muktānāṃ smṛtirdehodayaḥ punaḥ |
saṃsāre satāmāvartānāṃ parivṛttiparāṇāṃ jīvānāmiva muktānāṃ videhamuktānāṃ
saṃsārasmṛtiḥ punardehodayaśca na bhavatyeva | deśāntare kālāntare vā
punarāvartatvaṃ yato nāsti | imaṃ mānavamāvartaṃ nāvartante na sa punarāvartate
ityādiśruteriti bhāvaḥ
]

`v 7 [
yadi vāpi bhavetkiṃcitsmṛtyā dehādi tasya tat |
tadapṛthvyādibhiḥ śāntaṃ saṃkalpanagaraṃ tanu
]

`v 8 [
yathā saṃkalpaśailasya dṛśyamānamapi sphuṭam |
pṛthvyādirahitaṃ rūpaṃ tadvirāḍvapuṣastathā
]

`v 9 [
smṛtiśca saṃbhavatyeva na kadācana kācana |
eṣā laukikabuddhyā yā sā sadbuddhyā na vidyate
]

`v 10 [
śrīrāma uvāca |
kathaṃ na saṃbhavatyeṣāṃ smṛtiḥ smṛtimatāṃ vara |
smṛteścāsaṃbhave kasmādguṇo guṇagaṇākara
]

`v 11 [
śrīvasiṣṭha uvāca |
dṛśye hi saṃbhavatyeṣā kāryakāraṇatātmani |
tadbhāvābhāvasaṃpannā na tu saṃbhavati smṛtiḥ
]

`v 12 [
ābrahmastambaparyantaṃ dṛśyaṃ kiṃcinna vidyate |
yatra tatra kathaṃ kīdṛk kutaḥ syātsaṃbhavaḥ smṛteḥ
]

`v 13 [
bhūtvā bhāve hi dṛśyasya smaraṇaṃ smṛtirucyate |
dṛśyameva na yatrāsti tatraitāḥ kalanāḥ kutaḥ
]

`v 14 [
atyantābhāva evāsya dṛśyasya kila sarvadā |
sarvaṃ brahmeti satyārthāstatsmṛteḥ kalanāḥ kutaḥ
]

`v 15 [
smṛtirna saṃbhavatyeva tasmādādyā prajāpateḥ |
ākāravattvamevāsya śuddhajñānātmanaḥ kutaḥ
]

`v 16 [
smartavyaṃ bhāvavaśataḥ smṛtirnāstyeva laukikī |
smṛtyarthastvanyadīyo'sti satyātmā tvamimaṃ śṛṇu
]

`v 17 [
bhūtasyāntaḥ padārthasya smaraṇaṃ smṛtirucyate |
padārthastu na caivāsti na bhūto na bhaviṣyati
]

`v 18 [
evaṃ hi khalvidaṃ brahma paramevācalaṃ yataḥ |
anādimadhyaparyantaṃ kutaḥ smṛtyādayastataḥ
]

`v 19 [
sarvātmatvātpadārthātma cidvyomakcanaṃ tu yat |
vyavahāre'pyalaṃ śāntaṃ smṛtyā tacchabditaṃ mayā
]

`v 20 [
tadetatsmaraṇaṃ nāma svabhāvakacanaṃ hi tat `note[sadityatra taditi pāṭha
āvaśyakaḥ |] |
tenābhyasto'tha bāhyārthaḥ sādṛśyādavabhāsate
]

`v 21 [
yadyatsaṃvedyate kiṃcittatsvabhāvaṃ svabhāvayat |
tenāvabhāsate yo'rthastasya smṛtyabhidhā kṛtā
]

`v 22 [
avidyamānaṃ bhātīva yathā dṛśyaṃ tathā sthitiḥ |
bhātaivāvidyamānaiva mṛgatṛṣṇā yathodyatā
]

`v 23 [
yathā bhrāntānubhave avidyamānaṃ dṛśyaṃ bhātīva tathā smṛtāvapi sthitirbodhyā |
22 |
sarvātmani sthitāḥ satye yāḥ kacanti susaṃvidaḥ |
tā evābhyāsarūḍhārthāḥ sādṛśyātsmṛtayaḥ smṛtāḥ
]

`v 24 [
kākatālīyavadbhānti sarvātmani susaṃvidaḥ |
svāṅgabhūtāḥ svataḥ svasthāstā eva smṛtayaḥ kṛtāḥ
]

`v 25 [
yadyatkacati sadrūpaṃ `note[cidrūpamiti pāṭhaḥ |] svāṅgaṃ sarvātmanaḥ
svataḥ |
tadabhyastārthasādṛśyātsmṛtirityucyate budhaiḥ
]

`v 26 [
hetau labdhe'pyalabdhe vā pavanaspandavadvidaḥ |
tā evābhyāsarūḍhārthāḥ sādṛśyātsmṛtayaḥ kṛtāḥ
]

`v 27 [
kākatālīyavadbhānti yāstāḥ smṛtyabhidhāḥ kṛtāḥ |
yathā tavaite'vayavāḥ kacanti na kacanti ca
]

`v 28 [
sthitā evātmani tathā sarvāḥ sarvātmikā vidaḥ |
mithyājñānamayā yadvadarthā ghaṭapaṭādayaḥ
]

`v 29 [
tadvatsmṛtipadārthasya kiṃ bhramasya vicāryate |
dṛśyasyāsaṃbhavājjñasya smṛtirnāstyeva tattvataḥ
]

`v 30 [
sa tathaikaghanatvācca cidvyomatvājjagatsthiteḥ |
yathāsthitamidaṃ dṛśyamastyevājñasya saṃprati
]

`v 31 [
na mokṣopāyakathanaṃ ca na jānāmi tatsthitim |
saṃdehādiva jijñāsustāvanmokṣakathocyate
]

`v 32 [
yāvaddṛśyaṃ smṛtiścaiva saṃsmṛtiścāsya śāmyati |
avidyāyāstu maurkhyasya vimohasyātyasaṃbhavāt
]

`v 33 [
ajñastho niścayo'smākaṃ na kadācana gocaraḥ |
yacca yadviṣaye nāsti tannaivānubhavatyasau
]

`v 34 [
rajanyanubhavo bhānorbhavatyaṅga kathaṃ vada |
bhātaṃ vastusvarūpātma cinmātre kiṃcideva yat
]

`v 35 [
tadabhyastārthasādṛśyāttatsaṃskāra iti smṛtam |
ātmasvabhāvabhūtānāmapi cidvyomarūpiṇām
]

`v 36 [
sarveṣāṃ parikalpyānāmābhāse'pyanavasthiteḥ |
evaṃ na saṃbhavatyeva jagatkiṃcitkadācana
]

`v 37 [
dṛṣṭaṃ mṛgatṛṣevāmbu na tu tatparamārthataḥ |
yadā tvayaṃ tadā svapne sargādau cāvabhāsate
]

`v 38 [
cidvyomaiva paraṃ sargaparyāyaṃ svātmani sthitam |
cidvyomaivetthamābhātaṃ na cyutaṃ satsvarūpataḥ
]

`v 39 [
ātmanātmani rūpaṃ vā sadrūpamiva saṃsthitam |
sargādāveva kacite mithyā kacadapi sthitam
]

`v 40 [
ataḥ kutaḥ kvacinnāma heyādeyādibhāsanam |
nedamākāravatkimcinnāpi smṛtyātmakaṃ kvacit
]

`v 41 [
kāraṇābhāvato bhāti svarūpaṃ paramātmanaḥ |
ākāravattve yadduḥkhaṃ bhavetsmṛtyāṃ tadeva ca
]

`v 42 [
dvayametadasattasmādbandho nāma na vidyate |
cidvyomni bhūtavyomābhe śūnya eva yathāsthitam
]

`v 43 [
yathāsthitaṃ jīvanmuktānāṃ yāvajjīvaṃ vyavahārakṣamaṃ sthitamityuttaratrānvayaḥ | 42
|
sthitaṃ svarūpamajahadbhuvanārkācalādikam |
yathāsthitogradikkālaṃ jagatsvaṃ rūpamatyajat
]

`v 44 [
svamevātyajato rūpaṃ cidvyomna udare sthitam |
svānubhūtyekamātrātma pramātṛsvāpnapattanam
]

`v 45 [
apṛthvyādi kutastatra kila pṛthvyādayo vada |
tadbhāti kevalaṃ śāntaṃ cidākāśaṃ tathātmani
]

`v 46 [
sarvādau svapnakāle ca pṛthvyādeḥ saṃbhavaḥ kutaḥ |
udbhūyeva jagadrūpādbrahmasattātmanātmani
]

`v 47 [
karoti pṛthvyādyabhidhāḥ paścātsatyārthadā iva |
na smṛtyātma na sākāraṃ pṛthvyādīnāmasaṃbhavāt |
na bhrāntirna vivartādi jagadbrahmātma kevalam
]

`v 48 [
brahmedamākacati cārujagatsvarūpaṃ taccaikameva kacanākacanātmaniṣṭham |
dṛśyābhamapyamalameva nabhaḥ praśāntaṃ nityoditaṃ
pralayasargamayodayātma
]