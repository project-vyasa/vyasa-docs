`v 1 [
dvyadhikaśatatamaḥ sargaḥ 102
śrīrāma uvāca |
parijñāte pare vastunyanādinidhanātmani |
saṃpadyate vada brahmankīdṛśaḥ puruṣottamaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
śṛṇu saṃpadyate kīdṛgjñātajñeyo narottamaḥ |
yāvajjīvaṃ kathaṃ caiṣa kimācāro'vatiṣṭhate
]

`v 3 [
upalā api mitrāṇi bandhavo vanapādapāḥ |
vanamadhye sthitasyāpi svajanā mṛgapotakāḥ
]

`v 4 [
ākīrṇaṃ śūnyamevāsya vipadaścātisaṃpadaḥ |
sthitasyāpi mahārājye vyasanānyeva sūtsavāḥ
]

`v 5 [
asamādhiḥ samādhānaṃ duḥkhameva mahatsukham |
vyavahāro'pi sanmaunaṃ karmāṇyevātyakarmatā
]

`v 6 [
jāgradeva suṣuptastho jīvanneva mṛtopamaḥ |
karoti sarvamācāraṃ na karoti ca kiṃcana
]

`v 7 [
rasiko'tyantaviraso nirghṛṇo bandhuvatsalaḥ |
nirdayo'tyantakaruṇo vitṛṣṇastṛṣṇayānvitaḥ
]

`v 8 [
sarvābhinanditācāraḥ sarvācārabahiṣkṛtaḥ |
avītaśokabhayāyāsaḥ saśoka iva lakṣyate
]

`v 9 [
tasmānnodvijate loko lokānnodvijatetu saḥ |
paramudvegamāpannaḥ saṃsṛtau rasiko'pi san
]

`v 10 [
nābhinandati saṃprāptaṃ nāprāptamabhivāñchati |
āste'nubhūyamāne'rthe na ca harṣaviṣādayoḥ
]

`v 11 [
duḥkhite duḥkhitakathaḥ sukhite sukhasaṃkathaḥ |
āste sarvāsvavasthāsu hṛdayenāparājitaḥ
]

`v 12 [
karmaṇaḥ sukṛtādanyadasmai kiṃcinna rocate |
svabhāva eva mahatāṃ nanu yanna viceṣṭitam
]

`v 13 [
nālambate rasikatāṃ na ca nīrasatāṃ kvacit |
anārtheṣu vicaratyarthī vītarāgaḥ sarāgavat
]

`v 14 [
yathā śāstravyavahṛteḥ sukhaduḥkhaiḥ kramāgataiḥ |
anāgato'pi cāyāti na harṣaṃ na viṣāditām
]

`v 15 [
saṃprahṛṣṭāśca lakṣyante lakṣyante duḥkhitāstathā |
na svabhāvaṃ tyajantyantaḥ saṃsārārabhaṭīnaṭāḥ
]

`v 16 [
ātmīyeṣvarthajāteṣu mithyātmasu sutādiṣu |
budbudeṣviva toyānāṃ na snehastattvadarśinām
]

`v 17 [
asneha eva sughanasnehārdrahṛdayo yathā |
vatsalāṃ darśayanvṛttiṃ jñastiṣṭhati yathākramam
]

`v 18 [
vāyūniva pravāhasthāḥ spṛśanti viṣayānmudhā |
dehasattāviṣānmūḍhā līyante viṣayodare
]

`v 19 [
bahiḥ sarvasamācāramantaḥ sarvārthaśītalam |
nityamantaranāviṣṭa āviṣṭa iva tiṣṭhati
]

`v 20 [
śrīrāma uvāca |
svarūpamīdṛśaṃ tasya ko vetti munināyaka |
vada satyamasatyaṃ vā bhavatyajño hyapīdṛśaḥ
]

`v 21 [
aśvavadbrahmacaryeṇa caranto'cārucetasaḥ |
mithyātapasvidārḍhyāya bhavantyevaṃvidhā mune
]

`v 22 [
śrīvasiṣṭha uvāca |
asatyaṃ vāstu satyaṃ vā svarūpaṃ varamīdṛśam |
viddhi vedavidāṃ tveṣa svabhāvānubhavasthitaḥ
]

`v 23 [
anāviṣṭā viceṣṭante vītarāgāḥ sarāgavat |
gatahāsā hasantyajñānsahasā karuṇākulāḥ
]

`v 24 [
cittādarśagataṃ dṛśyaṃ sarvaṃ kapaṭakuṭṭimam |
paśyantyasatparijñātaṃ svapne hemeva hastagam
]

`v 25 [
antaḥśītalatāmeṣāṃ tāṃ na jānanti kecana |
dūrāccandanadārūṇāmāmodamiva jantavaḥ
]

`v 26 [
ye tu vijñātavijñeyāstādṛśāḥ pāvanāśayāḥ |
jānanti tāṃstathaivāntaraheḥ pādānivāhayaḥ
]

`v 27 [
bhāvaṃ nigūhayantyete tamuttamamanuttamāḥ |
grāmyairdhanaiḥ kilānarghyaḥ kaścintāmaṇirāpaṇe
]

`v 28 [
tasminnigūhane bhāvo yatasteṣāṃ na darśane |
nirvāsanā gatadvaitā gatamānāḥ kilāṅga te
]

`v 29 [
ekāntāmānadaurgatyajanāvajñaptayastu tān |
sukhayanti yathā rāma na tathaiva maharddhayaḥ
]

`v 30 [
svasaṃvedanasaṃvedyasārā viditavedyatā |
naiṣā darśayituṃ śakyā dṛśyate na ca tadvidā
]

`v 31 [
guṇaṃ mamemaṃ jānātu janaḥ pūjāṃ karotu me |
ityahaṃkāriṇāmīhā na tu tanmuktacetasām
]

`v 32 [
kriyāphalāni cidvyomagamanādīni rāghava |
ajñānāmapi sidhyanti mantrauṣadhivaśādiha
]

`v 33 [
yo yādṛk kleśamādhātuṃ samarthastādṛgeva saḥ |
avaśyaṃ phalamāpnoti prabuddho'stvajña eva vā
]

`v 34 [
āmodaścandanasyeva spandanasya phalaṃ hṛdi |
sarvasyaivāsti tannūnaṃ tadvatā samavāpyate
]

`v 35 [
ahaṃtāvāsanādvaitaṃ vastutā dṛśyavastuṣu |
yasyāstyasau sādhayati khagamādikriyāphalam
]

`v 36 [
idaṃ na kiṃcidbhrāntirvā khaṃ ceti jñastu vetti yaḥ |
so'vāsanaḥ karmavātyāḥ kathaṃ sādhayati kriyāḥ
]

`v 37 [
naiva tasya kṛtenārtho nā'kṛteneha kaścana |
na cāsya sarvabhūteṣu kaścidarthavyapāśrayaḥ
]

`v 38 [
na tadasti pṛthivyāṃ vā divi deveṣu vā kvacit |
yadudāramanovṛtterlobhāya viditātmanaḥ
]

`v 39 [
jagadeva tṛṇaṃ yasyana kiṃcidraja eva vā |
kiṃ nāma tasya bhavatu anyadādeyatāṃ gatam
]

`v 40 [
nirvāhitajagadyātraḥ paripūrṇamanā muniḥ |
yathāsthitamasāvāste saṃprayāti yathāgatam
]

`v 41 [
nityāntaḥśītalo maunī sattvībhūtamanovaniḥ |
paripūrṇārṇavākāro gambhīraprakaṭāśayaḥ
]

`v 42 [
rasāyanaparāpūrṇahradavat hlādamātmani |
dhatte karoti vānyasya sakalendurivāmalaḥ
]

`v 43 [
mandāramañjarīkuñjapiñjarā devabhūmayaḥ |
na tathā hlādayantyetā yathā paṇḍitabuddhayaḥ
]

`v 44 [
candrabimbairvasantaiśca mahatāmahtāśayaiḥ |
sāraṃ saubhāgyasaugandhyasaurabhālokabhogiṣu
]

`v 45 [
bhrāntimātramidaṃ viśvamindrajālamasanmayam |
tyajatīti viniścitya dinānudinameṣaṇāḥ
]

`v 46 [
śītātapādiduḥkhāni nijadehagatānyapi |
anyadehagatānīva jñaḥ paśyatyavahelayā
]

`v 47 [
karuṇodārayā vṛttyā vṛttyā vratatidhīrayā |
nīraso nīrasārāṃ tu sāratāṃ sarati sthitim
]

`v 48 [
tadanantaraṃ sarvabhūtānukampāsvarūpadṛḍhāvalambanaṃ yathāprāptena
jalamātreṇāpi saṃtoṣa ityādiguṇasāramādatte ityāha - karuṇeti | itthaṃ nīraso
viraktaḥ saḥ karuṇayā udārā vṛttiḥ sarvasvavyayenāpyārtaparipālanavrataṃ tayā |
vratatirlatā tadvaddhīrayā vṛttyā parārthaikaprayojanacchāyāphalapuṣpādisaṃgrahaḥ
svatarudṛḍhāvalambo jalamātreṇāpi yathāprāptena saṃtoṣa ityevaṃrūpayā vṛttyā
nīramātramapi sāraḥ saṃtoṣaheturyasyāṃ sthitau tādṛśasthitirūpāṃ sāratāṃ sarati |
47 |
vyavahāraṃ yathāprāptaṃ lokasāmānyamācaran |
carācarāṇāṃ bhūtānāmuparyevāvatiṣṭhate
]

`v 49 [
prajñāprāsādamārūḍhastvaśocyaḥ śocate janān |
bhūmiṣṭhāniva śailasthaḥ sarvānprajño'nupaśyati
]

`v 50 [
ciraṃ kallolavalitaḥ sumanā jaladhau bhrame |
paraṃ pāramupāgatya parāṃ viśrāntimeti saḥ
]

`v 51 [
hasansa śāntayā vṛttyā prāktanīrjāgatīrgatīḥ |
smayamāna ivāste'ntarjanatāśca ghanabhramāḥ
]

`v 52 [
etāḥ kāntāranirmagnamitāḥ saṃsāradṛṣṭayaḥ |
asatyo hṛtavatyo māmityantaryāti vismayam
]

`v 53 [
dṛṣṭyāṣṭaguṇamaiśvaryamaniṣṭaṃ me tṛṇāyate |
ityupaityupaśāntatvātsmayamāno'pi na smayam
]

`v 54 [
kaścidgiriguhāgehaḥ kaścitpuṇyāśramāśrayaḥ |
kaścidgṛhasthāśramavānkaścidbahuraṭansthitaḥ
]

`v 55 [
kaścidbhikṣācarācāraḥ kaścidekāntatāpasaḥ |
kaścinmaunavratadharaḥ kaścidvyānaparāyaṇaḥ
]

`v 56 [
kaścidvipaścidvikhyātaḥ kaścicchrotā śruteḥ smṛteḥ |
kaścidrājā dvijaḥ kaścitkaścidajña iva sthitaḥ
]

`v 57 [
guṭikāñjanakhaṭgādisiddhaḥ kaścinnabhogataḥ |
kaścicchilpakalājīvī kaścitpāmararūpabhṛt
]

`v 58 [
kaścityaktasamācāraḥ kaścicchrotriyanāyakaḥ |
kaścidunmattacaritaḥ pravrajyāṃ kaścidāśritaḥ
]

`v 59 [
puruṣo na śarīrādi na ca cittādi kiṃcana |
puruṣaścetanaṃ nāma na sa naśyati karhicit
]

`v 60 [
acchedyo'sāvadāhyo'sāvakledyo'śoṣya eva ca |
nityaḥ sarvagataḥ sthāṇuracalo'sau sanātanaḥ
]

`v 61 [
iti samyakprabuddho yaḥ sa yathā yatra tiṣṭhati |
tathā tiṣṭhatu tatrātra sthānāsthāniyamena kim
]

`v 62 [
pātālamāviśatu yātu nabho vilaṅghya diṅmaṇḍalaṃ bhramatu peṣaṇameva yena |
cinmātrametadajaraṃ na tu yātu nāśamākāśakośa iva śāntamajaṃ śivaṃ tat |
62 |
tasyāvināśipuruṣatvameva draḍhayannupasaṃharati - pātālamiti |
tattvavidbalātsvanāśacikīrṣayā pātālamāviśatu nabho vilaṅghyordhva vā yātu
diṅmaṇḍalaṃ vā bhramatu yena bhramaṇena
mānasottaralokālokādigiriśilāsahasragharṣaṇātpeṣaṇaṃ saṃcūrṇanameva saṃbhāvyate |
peṣaṇameva yātu iti pāṭhe giriśilāsahasraiḥ svasya peṣaṇaṃ kārayatu vetyarthaḥ |
tathāpyetattattvavitsvarūpamasaṅgādvayaṃn cinmātramajarameveti nāśaṃ na tu yāti |
yatastadākāśakośa iva śivaṃ nirupallavanityaniratiśayānandarūpamevetyarthaḥ
]