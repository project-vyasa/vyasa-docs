`v 1 [
catuḥpañcāśaḥ sargaḥ 54
śrīvasiṣṭha uvāca |
jagannāma nabhaḥ svacchaṃn sadbrahma nabhasi sthitam |
nabho nabhasi bhātīdaṃ jagacchabdārtha ityajam
]

`v 2 [
tvamahaṃ jagadityādi śabdārtho brahma brahmaṇi |
śāntaṃ samasamābhāsaṃ sthitamasthitameva sat
]

`v 3 [
samudragirimeghorvīvisphoṭamayamapyajam |
kāṣṭhamaunavadevedaṃ jagadbrahmāvatiṣṭhate
]

`v 4 [
draṣṭā draṣṭaiva dṛśyasya svabhāvātsvātmani sthitaḥ |
kartā kartaiva kartavyābhāvataḥ kāraṇādṛte
]

`v 5 [
na jñatvaṃ na ca kartṛtvaṃ na jaḍatvaṃ na bhoktṛtā |
na śūnyatā na cārthatvamiha nāpi nabhorthatā
]

`v 6 [
śilājaṭharavatsatyaṃ ghanamekamajaṃ tatam |
sarvaṃ śāntamanādyantameka vidhiniṣedhayoḥ
]

`v 7 [
maraṇaṃ jīvitaṃ satyamasatyaṃ ca śubhāśubham |
sarvamekamajaṃ vyoma vīcijālajalaṃ yathā
]

`v 8 [
vibhāga eva dṛśyatvaṃ draṣṭṭatvaṃ caiva gacchati |
etacca kalpanaṃ svapnapurādiṣvanubhūyate
]

`v 9 [
evamacchaṃ parākāśe svapnapattanavajjagat |
bhāti prathamamevedaṃ brahmaivetthamataḥ sthitam
]

`v 10 [
tadidaṃ tādṛśaṃ viddhi sarvaṃ sarvātmakaṃ ca yat |
deśāddeśāntaraprāptau vido madhyamanaṅkitam
]

`v 11 [
cidvyomnaḥ śāntaśāntasya madhyame caivamāsthitam |
jagattathaiva salilamevormyāditayā yathā
]

`v 12 [
yadudetyuditaṃ yacca yacca nodeti noditam |
deśāddeśāntaraprāptau vido madhyānna bheditam
]

`v 13 [
ataḥ kilāsya sargasya kāraṇaṃ śaśaśṛṅgavat |
prayatnenāpi cānviṣṭaṃ na kiṃcidupalabhyate
]

`v 14 [
yadakāraṇakaṃ bhāti tadabhātaṃ bhramātmakam |
bhramasyāsatyarūpasya satyatā kathamucyate
]

`v 15 [
kāraṇena vinā kāryaṃ kila kiṃ nāma vidyate |
yadaputrasya satputradarśanaṃ sa bhramo na sat
]

`v 16 [
yastvakāraṇako bhāti sa svabhāvo vijṛmbhate |
sarvarūpeṇa saṃkalpagandharvanagarādivat
]

`v 17 [
deśāddeśāntaraprāptau kṣaṇānmadhyaṃ vido vapuḥ |
svarūpamajahattveva rājate'rthavivartavat
]

`v 18 [
bodha eva kacatyartharūpeṇa sa ca svādaṇuḥ |
dṛṣṭānto'trānubhūto'ntaḥ svapnasaṃkalpaparvataḥ
]

`v 19 [
śrīrāma uvāca |
vidyate vaṭabījāntaryathā bhāvimahādrumaḥ |
paramāṇau tathā sargo brahmankasmānna vidyate
]

`v 20 [
śrīvasiṣṭha uvāca |
yatrāsti bījaṃ tatra syācchākhā vitatarūpiṇī |
janyate kāraṇaiḥ sā ca vitatā sahakāribhiḥ
]

`v 21 [
samastabhūtapralaye bījamākāri kiṃ bhavet |
sahakāryatha kiṃ tasya jāyate yadvaśājjagat
]

`v 22 [
yattu brahma paraṃ śāntaṃ kā tatrākārakalpanā |
paramāṇutvayogo'pi nātra kevātra bījatā
]

`v 23 [
kāraṇasyeti bījasya satyāsatyaikakāriṇaḥ |
asaṃbhavājjagatsattā kathaṃ kena kutaḥ kva kā
]

`v 24 [
jagadāste parasyāṇorantarityapi nocitam |
sārṣape kaṇake merurāsta ityajñakalpanā
]

`v 25 [
sati bīje pravartante kāryakāraṇadṛṣṭayaḥ |
nirākārasya kiṃ bījaṃ kva janyajanakakramaḥ
]

`v 26 [
ato yatparamaṃ tattvaṃ tadevedaṃ jagatsthitam |
neha prathayate kiṃcinna ca kiṃcidvinaśyati
]

`v 27 [
cidākāśaścidākāśe hṛdi cittvājjagadbhramam |
aśuddhavadivāśuddhe śuddhaṃ śuddhe prapaśyati
]

`v 28 [
svamevābhāsate tasya rūpaṃ spanda ivānile |
sargaśabdārthakalanā neha kāścana santi naḥ
]

`v 29 [
yathā śūnyatvamākāśe dravatvaṃ ca yathā jale |
anyatātmamayī śuddhā sargateya tathātmani
]

`v 30 [
bhārūpamidamāśāntaṃ jagadbrahmaiva nastatam |
anādinidhanaṃ satyaṃ nodeti na ca śāmyati
]

`v 31 [
deśāddeśāntaraprāptau kṣaṇānmadhye vido vapuḥ |
yattajjagaditīvedaṃ vyomātmani vyavasthitam
]

`v 32 [
yathā spando'nile toye dravatvaṃ vyomni śūnyatā |
tathā jagadidaṃ bhātamananyāśleṣamātmani
]

`v 33 [
saṃvinnabho nanu jagannabha ityanarkamātmanyavasthitamanastamayodayaṃ kva |
tattvaṅgabhūtamakhilaṃ tadananyadeva dṛśyaṃ nirastakalano'mbaramātramāsva
]