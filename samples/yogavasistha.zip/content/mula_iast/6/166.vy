`v 1 [
ṣaṭṣaṣṭyadhikaśatatamaḥ sargaḥ 166
śrīvasiṣṭha uvāca |
sārthakenātmaśabdena khyātiśabdena cojjhitām |
ātmakhyātimimāṃ viddhi śilājaṭharanirghanām
]

`v 2 [
ādisargātprabhṛtyeva cidvyomaivetthamātatam |
kacatyātmani yattasya buddhā tenaiva sargatā
]

`v 3 [
na vahantīha sarito nehonmajjanamajjane |
vyoma vyomnyeva cidrūpaṃ kacatyevamaniṅgitam
]

`v 4 [
kacanoktyā tu rahitāṃ samagreṇāstakalpanām |
vinottarapadārthena tvātmakhyātimimāṃ viduḥ
]

`v 5 [
ātmaivedaṃ jagatsarvaṃ khyātiryatra na kiṃcana |
akhyāto nāma na khyātyā kadācitkhyāpitaḥ kvacit
]

`v 6 [
khyātirakhyātirityatra vācoyuktiravāstavī |
kiṃ tatra khyāpanaṃ nāma syādvāpyakhyāpanaṃ ca kim
]

`v 7 [
akhyātiranyathākhyātirasatkhyātiritītarā |
dṛśyāścinmātrarūpasya bhāsaścittvacamatkṛtāḥ
]

`v 8 [
yathā yathā yadā ye ye cinmātravyomabhāsvataḥ |
cidaṃśavaḥ kacantyacchāstadā te te tathā tathā
]

`v 9 [
ātmakhyātirasatkhyātirakhyātiḥ khyātiranyathā |
ityetāściccamatkṛtyā ātmakhyātervibhūtayaḥ
]

`v 10 [
tathā sati bhavadabhimatāste madīyātmakhyātervibhūtaya evetyāha - ātmakhyātiriti |
9 |
ātmakhyātipadasyārtha ātmakhyātipadojjhitaḥ |
anādyanto nirullekhaḥ so'yamekaghanaḥ sthitaḥ
]

`v 11 [
tatredaṃ mahadākhyānaṃ śṛṇu śravaṇabhūṣaṇam |
dūṣaṇaṃ dvaitadṛṣṭīnāṃ dyotanaṃ bodhabhāsvataḥ
]

`v 12 [
asti yojanakoṭīnāṃ sahasrāṇi pramāṇataḥ |
ānīlakuḍyakaṭhinā vimalā vipulā śilā
]

`v 13 [
na saṃdhibandhā nibiḍā vajrasārā visāriṇī |
atyantapuṣṭakaṭhinajaṭharākāśanirmalā
]

`v 14 [
asaṃkhyakalpanicayamavināśā ghanāṅgikā |
kāntāṅgī nirmalatvena vyomarūpaiva lakṣyate
]

`v 15 [
jātistu jñāyate tasyā viśiṣṭā naiva kenacit |
kathaṃ kutra kadā ceti na vijñātā sadaiva sā
]

`v 16 [
antastasyāstu hṛdaye bhūtadhātuvivarjite |
nibiḍānantakaṭhinā vajrasārā'vināśinī
]

`v 17 [
bhūtadhātubhirmahābhūtaiścaturvidhabhūtagrāmaiśca vivarjite tasyā antarjaṭhare
lekhāmayāni sphaṭikaśilāntarlekhāprāyāṇi padmajālādīni vidyanta iti pareṇānvayaḥ |
16 |
lekhāmayāni vidyante svāṅgabhūtāni bhūriśaḥ |
padmajālāni śaṅkhāśca gadāścakrādayastathā
]

`v 18 [
khaṃ vāyuḥ salilaṃ tejo vasudhetyabhidhā kṛtā |
nāsīttatra svalekhānāṃ jīva ityeva vai tatyā
]

`v 19 [
śrīrāma uvāca |
śilāsau cetanaṃ tasyāḥ kuta ityucyatāṃ mama |
acetanā śilā nāma kathaṃ nāma karoti ca
]

`v 20 [
śrīvasiṣṭha uvāca |
na cetanā na ca jaḍā sā śilā vipulojjvalā |
jātiṃ jānāti kastasyāḥ kastatrānyaśca vidyate
]

`v 21 [
jātistu jñāyate tasyā viśiṣṭā naiva kenacit iti prāktanoktyaivāyaṃ praśno dattottara iti
vasiṣṭhaḥ samādhatte - netyādinā | anyaśca ko vidyate yastajjātiṃ jānīyādityarthaḥ |
20 |
śrīrāma uvāca |
tasyāḥ paśyati tā lekhāḥ kaḥ kathaṃ jaṭharasthitāḥ |
kathaṃ vā kena sā bhagnā kadā nāmeti me vada
]

`v 22 [
śrīvasiṣṭha uvāca |
na bhettuṃ yujyate sogrā na ca bhettā ca vidyate |
tathaivāpāraparyantadehinyā sarvamāvṛtam
]

`v 23 [
pṛṣṭānāmapahnavenaivottaramāha - yetyādinā | ugrā atidṛḍhā | āvṛtaṃ
vyāptam | nainena kiṃcanānāvṛtaṃnainena kiṃcanāsaṃvṛtam iti śruteriti bhāvaḥ |
22 |
lekhāmayāni vidyante tatrānantāni koṭare |
vṛkṣaparvatajālāni nagarāṇi purāṇi ca
]

`v 24 [
tatra lekhāmayāḥ santi devadānavanāmakāḥ |
sūkṣmāsūkṣmā nirākārāḥ sākārā iva putrikāḥ
]

`v 25 [
ākāśanāmnī tatrāsti lekhā vaipulyaśālinī |
upalekhāśca santyasyā madhye candrārkanāmikāḥ
]

`v 26 [
śrīrāma uvāca |
kena dṛṣṭā vada brahmaṁllekhāstāstatra kiṃvidhāḥ |
kathaṃ vā vada dṛśyante nipiṇḍopalakośagāḥ
]

`v 27 [
śrīvasiṣṭha uvāca |
mayā rāghava tā dṛṣṭāstādṛśyastatra lekhikāḥ |
tavāpīcchā yadi bhavettattāstvamapi paśyasi
]

`v 28 [
śrīrāma uvāca |
tādṛśī vajrasārā sā śilā bhaṅktuṃ na yujyate |
tathāpi bhavatā dṛṣṭā lekhāstatkośagāḥ katham
]

`v 29 [
śrīvasiṣṭha uvāca |
etasyā jaṭhare rāma lekhāhaṃ jaṭhare sthitaḥ |
tena paśyāmi tatrastho lekhājālaṃ tadakṣatam
]

`v 30 [
ko'sau śakto'nyathā bhaṅktuṃ tāṃ śilāmahamantare |
tatsarvaṃ dṛṣṭavāṃstasyā ahaṃ tatrāntarasthitaḥ
]

`v 31 [
śrīrāma uvāca |
kāsau śilātha kaśca tvaṃ vada me kvāsi saṃsthitaḥ |
kimetadvadasi brūhi kimetaddṛṣṭavānasi
]

`v 32 [
śrīvasiṣṭha uvāca |
paramātmamahāsattā kathitaiṣā mayā tava |
anayaiva vacobhaṅgyā na tveṣā vipulā śilā
]

`v 33 [
paramātmamahāsattāśilāyā jaṭhare vayam |
tacchilāmāṃsameveme sauṣiryaparivarjite
]

`v 34 [
tacchilāṅgaṃ nabho viddhi tacchilāṅgaṃ sadāgatiḥ |
tacchilāṅgaṃ kriyāśabdā vāsanā kālakalpanā
]

`v 35 [
sarvaṃ jagattacchilāṅgameveti prapañcayati - tacchilāṅgamiti | sadāgatirvāyuḥ |
pañcabhūtopalakṣaṇametat | evaṃ kriyāśabdagrahaṇamapi
vāyvākāśādisarvabhūtabhautikadharmopalakṣaṇam | vāsanā manodharmopalakṣaṇam |
34 |
bhūmirāpo'nalo vāyuḥ khaṃ mano buddhireva ca |
ahaṃkāra itīdaṃ tattacchilāṅgamudāhṛtam
]

`v 36 [
paramātmamahāsattā śilā māṃsamime vayam |
sarva eva tato'nanye'pyanye tviti ca vidmahe
]

`v 37 [
cinmātraikātmikā yeyaṃ kilātimahatī śilā |
etasyā vyatirekeṇa kva tadasti kimucyatām
]

`v 38 [
śuddhaṃ vedanamevedaṃ ghaṭāvaṭapaṭādikam |
yathā svapne tathā bhāti jalamūrmitayā yathā
]

`v 39 [
idaṃ brahma ghanaṃ sarvaṃ cinmātraghanamātatam |
paramārthaghanaṃ śāntaṃ sarvamekaghanaṃ viduḥ
]

`v 40 [
ekaṃ mahāciti śilodarameva sarvaṃ sauṣiryavarjitamapāramanādimadhyam |
tenātmanaiva kalitā kalanātmaneyaṃ sargo jagadbhuvanamityapi dṛśyanāmnī | 40
|
sarvaṃ jagadekaṃ brahmaśilodarameva | tacca sauṣiryeṇa cchidrabhāvena
varjitamapāramanantaṃ tathā anādimadhyaṃ ca | tena tathāvidhena brahmātmanā ātmanā
svenaiva sargo jagadbhuvanamityapi paryāyanāmabhiḥ prasiddhā dṛśyanāmnī kalanā
kalitā svīkṛtetyarthaḥ
]