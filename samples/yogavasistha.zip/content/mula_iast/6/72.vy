`v 1 [
dvisaptatitamaḥ sargaḥ 72
śrīvasiṣṭha uvāca |
athākṛṣṭavati prāṇānsvayaṃbhuvi nabhobhavaḥ `note[nabhobhuvaḥ iti
mudritapustake pāṭhaḥ |] |
virāḍātmani tatyāja vātaskandhasthitaḥ sthitim
]

`v 2 [
te hi tasya kila prāṇāstena krānteṣu teṣvapi |
ṛkṣacakre sthitiṃ ko'nyo dhatte bhūtaikadhāriṇīm
]

`v 3 [
vātaskandhe samākrānte brahmaṇā prāṇamārute |
samaṃ gantuṃ parityajya saṃsthitiṃ kṣobhamāgate
]

`v 4 [
sthitiṃ prāguktāṃ tyaktvā samupasaṃhāreṇa sāmyāvasthāṃ gantuṃ kṣobhamāgate sati |
3 |
nirādhārāḥ savātāgnidāholmukavadāpatan |
vyomnastārāstaroḥ puṣpanikarā iva bhūtale
]

`v 5 [
kālapākacalanmūlā jagatkhaṇḍaphalālayāḥ |
praśāntapavanādhārā vimānāvalayo'patan
]

`v 6 [
pralayonmukhatāṃ yāte brāhme saṃkalpanendhane |
siddhānāṃ gatayaḥ śemuriddhānāmarciṣāmiva
]

`v 7 [
prabhramantyo'mbare kapamārutaistanutūlavat |
svaśaktyapacaye mūkāḥ siddhasaṃtatayo'patan
]

`v 8 [
saṃkalpadrumajālāni sendrādinagarāṇi ca |
peturbhūkampalolasya śirāṃsyamarabhūbhṛtaḥ
]

`v 9 [
śrīrāma uvāca |
citi saṃkalpamātrātmā virāḍ brahmā jagadvapuḥ |
kimaṅgaṃ tasya bhūlokaḥ kiṃ svargaḥ kiṃ rasātalam
]

`v 10 [
kathametāni cāṅgāni brahmaṃstasya sthitāni ca |
kathaṃ vā so'ntare tasya svasyaiva vapuṣaḥ sthitaḥ
]

`v 11 [
astu vā caturmukhadeho'pi mūrtastathāpyalpaparimāṇasyaitasyaitānyativistṛtāni
bhūrādīnyaṅgāni kathaṃ sthitāni | tasyāpi vistṛtatvakapanena brahmāṇḍātmatā
yadyucyeta tarhi sa svasyaiva vapuṣa etasya brahmāṇḍasyāntaḥ satyaloke kathaṃ sthitaḥ |
10 |
brahmā saṃkalpamātrātmā nirākṛtiridaṃ sthitam |
jagadityeva jāto me niścayaḥ kathayetarat
]

`v 12 [
śrīvasiṣṭha uvāca |
ādau tāvadidaṃ nāsanna sadāste nirāmayam |
cinmātraparamākāśamāśākośaikapūrakam
]

`v 13 [
tatsvāmākaśatāṃ caitaccetyamityavabudhyate `note[caitatparamityababudhyate iti
ṭīkānuguṇaḥ pāṭhaḥ |] |
svarūpamatyajannityaṃ cittvādbhavati cetanam
]

`v 14 [
viddhi taccetanaṃ jīvaṃ saghanatvānmanaḥ sthitam |
etāvati sthitijāle na kiṃcitsākṛti sthitam
]

`v 15 [
śuddhaṃ vyomaiva cidvyoma sthitamātmani pūrvavat |
yadetatpratibhātaṃ tu tadanyanna śivāttataḥ
]

`v 16 [
atha tanmana ābhogi bhāvitāhaṃkṛti sphurat |
saṃkalpātmakamākāśamāste stimitamakṣayam
]

`v 17 [
tatsaṃkalpacidābhāsanabho'hamiti bhāvitam |
asattamevānubhavatsaṃniveśaṃ khameva khe
]

`v 18 [
ahaṃkarakalpanottaraṃ sthūladehakalpanāpi tasyāvastubhūtaivetyāha - tadityādinā |
17 |
vetti bhāvitamākāraṃ paśyatyanubhavatyapi |
saṃkalpakātmakaṃ śūnyameva deha iti sthitam
]

`v 19 [
śūnyameva yathākāri saṃkalpanagaraṃ bhavān |
paśyatyevamajo dehaṃ khe khamevānubhūtavān
]

`v 20 [
saṃvido nirmalatvātsa yāvaditthaṃ tahāvidham |
anubhūyānubhavanaṃ svecchayaivopaśāmyati
]

`v 21 [
yadā tattvaparijñānamasmadādestadā''tatam |
idaṃ saṃsaṃraṇaṃ viddhi śūnyaṃ satyamiva sthitam
]

`v 22 [
yathābhūtaparijñānādatra śāmyati vāsanā |
advaitānnirahaṃkārāttato mokṣo'vaśiṣyate
]

`v 23 [
evameṣa sa yo brahmā sa evedaṃ jagatsthitam |
virajo brahmaṇo rāma deho yastadidaṃ jagat
]

`v 24 [
saṃkalpākāśarūpasya tasya yā bhrāntirutthitā |
tadidaṃ jagadābhāti tadbrahmāṇḍamudāhṛtam
]

`v 25 [
sarvamākāśamevedaṃ saṃkalpakalanātmakam |
vastutastvasti na jagattvattāmatte na ca kvacit
]

`v 26 [
kvacinmātre'male vyomni kathaṃ vā kena vā jagat |
kiṃ jāyate kimatrāsti kāraṇaṃ sahakāri yat
]

`v 27 [
avāstavatvaṃ kathaṃ jñeyamiti cedasaṃbhāvyatvādityāśayenāha - kveti |
kiṃvṛttapañcakaṃ deśakālādisarvaprakārairapyasaṃbhāvyatvasya samarthanārtham |
26 |
ato'līkamidaṃ jātamalīkaṃ paridṛśyate |
alīkaṃ svadate'lokamevaṃ paśyati śūnyakam
]

`v 28 [
jagadādikayā bhāsā cinmātraṃ svadate svataḥ |
ātmanātmāmbare dvaite spandaneneva mārutaḥ
]

`v 29 [
idaṃ kiṃcinna kiṃcidvā dvaitādvaitavivarjitam |
cidākāśaṃ jagadviddhi śūnyamacchaṃ nirāmayam
]

`v 30 [
śāntāśeṣaviśeṣo'haṃ tena rāghava saṃsthitaḥ |
sannevāsannivātastvamevamevāsva nirmamaḥ
]

`v 31 [
nirvāsanaḥ śāntamanā maunī vigatacāpalaḥ |
sarvaṃ kuru yathāprāptaṃ kuru mā vātra kiṃ grahaḥ
]

`v 32 [
anādinityānubhavo ya ekaḥ sa eva dṛśyaṃ na tu dṛśyamanyat |
satyānubhūte'nanubhūtayo yāḥ suvistṛtā dṛśyamahādṛśastāḥ
]