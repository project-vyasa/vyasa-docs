`v 1 [
ekonacatvāriṃśaḥ sargaḥ 39
śrīvasiṣṭha uvāca |
saṃjātākṛtrimakṣīṇasaṃsṛtipratyayaḥ pumān |
asaṃkalpo na saṃkalpaṃ vetti tenāsadeva saḥ
]

`v 2 [
śvāsānmlānirivādarśe kuto'pyahamiti sthitā |
vidi sā'kāraṇaṃn dṛṣṭā naśyantyāśu na labhyate
]

`v 3 [
yasya kṣīṇāvaraṇatā śāntasarvehatoditā |
paramāmṛtapūrṇātmā sattayaiva sa rājate
]

`v 4 [
sarvasaṃdehadurdhvāntamihikāmātariśvanā |
bhāti bhāsvaddhiyā deśastena pūrṇenduneva kham
]

`v 5 [
visaṃsṛtirvisaṃdeho labdhajyotirnirāvṛtiḥ |
śaradākāśaviśado jñeyo vijñāyate budhaḥ
]

`v 6 [
niḥsaṃkalpo nirādhāraḥ śāntaḥ sparśātpavitratām |
antaḥśītala ādhatte brahmalokādivānilaḥ
]

`v 7 [
asadrūpopalambhānāmiyaṃn vastusvabhāvatā |
yatsvargavedanaṃn svapnabandhyāputropalambhavat
]

`v 8 [
avidyamānamevedaṃ jagadyadanubhūyate |
asadrūpopalambhasya saiṣā vastusvabhāvatā
]

`v 9 [
asatyeṣveva saṃsāreṣvāstāmarthaḥ kuto bhavet |
sargāpavargayoḥ śabdāveva vandhyāsutopamau
]

`v 10 [
jagadbrahmatayā satyamanirmitamabhāvitam |
aniṣṭhitaṃ cānyathā tu nāhaṃ nāvagataṃ ca tat
]

`v 11 [
ātmasvabhāvaviśrānteriyaṃ vastusvabhāvatā |
yadahaṃtādisargādiduḥkhādyanupalambhatā
]

`v 12 [
kṣaṇādyojanalakṣāntaṃ prāpte deśāntare citaḥ |
cetane'yasya tadrūpaṃ mārgamadhye nirañjanam
]

`v 13 [
cito nirviṣayatāyā aprasiddhimāśaṅkamānaṃ prati deśāddeśāntaraprāptau iti śloke
darśitāṃ tatprasiddhiṃ smārayati - kṣaṇāditi | śākhādideśāccandrādideśāntare
yojanalakṣāntaṃ cakṣurdvārā prāpte cetane cākṣuṣavṛttyavacchinnacaitanye
mārgamadhye ayate vyāpnotītyayasya caitanyasya yadacetyaṃ khakośābhāsacinmayaṃ
rūpaṃ sarvasya jantujātasya prasiddhaṃ tatsvabhāvaṃ viduriti vyavahitena saṃbandhaḥ | 12
|
aspandavātasadṛśaṃ khakośābhāsacinmayam |
acetyaṃ śāntamuditaṃ latāvikasanopamam
]

`v 14 [
sarvasya jantujātasya tatsvabhāvaṃ vidurbudhāḥ |
sargopalambho galati tatrasthasya vivekinaḥ
]

`v 15 [
suṣupte svapnadhīrnāsti svapne nāsti suṣuptadhīḥ |
sarganirvāṇayorbhrāntī suṣuptasvapnayoriva
]

`v 16 [
bhrāntivastusvabhāvo'sau na svapno na suṣuptatā |
na sargo na ca nirvāṇaṃ satyaṃ śāntamaśeṣataḥ
]

`v 17 [
bhrāntistvasanmātramayī prekṣitā cenna labhyate |
śuktirūpyamivāsatyaṃ kila saṃprāpyate katham
]

`v 18 [
yanna labdhaṃ ca tannāsti tena bhrānterasaṃbhavaḥ |
svabhāvādupalambhonyo nāsti kasya na kasyacit
]

`v 19 [
svabhāva eva sarvasmai svadatte kila sarvadā |
anānaiva hi nāneva kiṃ vādaiḥ saṃvibhāvyatām
]

`v 20 [
asvabhāve mahadduḥkhaṃ svabhāve kevalaṃ śamaḥ |
iti buddhyā vicāryāntaryadiṣṭaṃ tadvidhīyatām
]

`v 21 [
sūkṣme bīje'styagaḥ sthūlo dṛṣṭamityupapadyate |
śive mūrte jaganmūrtamastītyuttamasaṃkathā
]

`v 22 [
rūpālokamanaskārabuddhyahantādayaḥ pare |
svarūpabhūtāḥ salile dravatvamiva khātmakāḥ
]

`v 23 [
mūrto yathā svasadṛśaiḥ karotyavayavaiḥ kriyāḥ |
ātmabhūtaistathā bhūtaiścidākāśamakartṛ sat
]

`v 24 [
ātmasthādahamityādirasmadāderasaṃsṛteḥ |
śabdo'rthabhāvamukto yaḥ paṭahādiṣu jāyate
]

`v 25 [
yadbhātaṃ prekṣayā nāsti tannāstyeva nirantaram |
jagadrūpamarūpātma brahma brahmaṇi saṃsthitam
]

`v 26 [
yeṣāmasti jagatsvapnaste svapnapuruṣā mithaḥ |
na santi hyātmani mitho nāsmāsvambarapuṣpavat
]

`v 27 [
mayi brahmaikarūpaṃ te śāntamākāśakośavat |
vāyoḥ spandairivābhinnairvyavahāraiśca tanmayi
]

`v 28 [
asmāsu jaḍāṃśe eva te tadvyavahārāśca khapuṣpavat saccidaṃśe tu mayi
brahmaikarūpatvātsantyevetyāha - mayīti | te puruṣāḥ
vāyuspandavatsvābhinnaistaistaiḥ svavyavahāraiḥ saha mayi santyeva | yatastadubhayaṃ
śāntaṃn sadbrahmātmaikarūpaṃ tacca brahma mayi pratyagātmasvabhāve'stītyarthaḥ | 27
|
ahaṃ tu sanmayasteṣāṃ svapnaḥ svapnavatāmiva |
te tu nūnamasanto me suṣuptasvapnakā iva
]

`v 29 [
taistu yo vyavahāro me tadbrahma brahmaṇi sthitam |
te yatpaśyanti paśyantu tattairalamalaṃ mama
]

`v 30 [
ahamātmani naivāsmi brahmasatteyamātatā |
tvadarthaṃn samudetīva tathārūpaiva vāgiyam
]

`v 31 [
aviruddhaviruddhasya śuddhasaṃvinmayātmanaḥ |
na bhogecchā na mokṣecchā hṛdi sphurati tadvidaḥ
]

`v 32 [
svabhāvamātrāyatte'sminbandhamokṣakrame nṛṇām |
kadarthanetyaho mohādgoṣpade'pyudadhibhramaḥ
]

`v 33 [
svabhāvasādhane mokṣe'bhāvopaśamarūpiṇi |
na dhanānyupakurvanti na mitrāṇi na ca kriyāḥ
]

`v 34 [
tailabindurbhavatyuccaiścakramappatito yathā |
tathāśu cetyasaṃkalpe sthitā bhavati cijjagat
]

`v 35 [
jāgrati svapnavṛttāntasthitiryādṛgrasā smṛtau |
tādṛgrasāhaṃtvajagajjālasaṃsthā vivekinaḥ
]

`v 36 [
tenaivābhyāsayogena yāti tattanutāṃ tathā |
yathā nāhaṃ na saṃsāraḥ śāntamevāvaśiṣyate
]

`v 37 [
yadā yadā svabhāvārkaḥ sthitimeti tadā tadā |
bhogāndhakāro galati na sannapyanubhūyate
]

`v 38 [
mohamahattārahitaḥ sphurati mṛtau bhavati bhāsate ca tathā |
buddhyādikaraṇanikaro yasmāddīpādivālokaḥ
]