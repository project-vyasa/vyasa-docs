`v 1 [
ṣaḍadhikadviśatatamaḥ sargah 206
śrīvasiṣṭha uvāca |
yadakāraṇakaṃ bhāti bhānaṃ tannaiva kiṃcana |
tattathā paramārthena paramārthaḥ sthito'nagha
]

`v 2 [
atremaṃ kenacitpṛṣṭo'yamahaṃ taṃ mahāmate |
samyagbodhasya puṣṭyarthaṃ  mahāpraśnaṃ paraṃ śṛṇu
]

`v 3 [
astyabdhibhyāmubhayato vyāptaṃ khyātaṃ jagattraye |
kuśadvīpamiti dvīpaṃ bhūmau valayavatsthitam
]

`v 4 [
tatrāstīlāvatī nāma haimī pūrvottare purī |
dīptijvālāmayastambhaprotāvaninabhastalā
]

`v 5 [
pūrve tasyāmabhūdrājā prajñaptiriti viśrutaḥ |
anuraktajagadbhūtaḥ śakraḥ svarga `note[sarga iti pāṭhaḥ |] ivāparaḥ
]

`v 6 [
kenacitkāraṇenāhaṃ kadācittasya bhūpateḥ |
prāptaḥ samīpaṃ nabhasaḥ pralayārka iva cyutaḥ
]

`v 7 [
puṣpārghyācamanīyairmāṃ pūjayitvopaviśya saḥ |
madhye kathāyāṃ kasyāṃcidapṛcchatpraṇayādidam
]

`v 8 [
bhagavansarvasaṃhāre jāte śūnyatate sthite |
avācye parame vyomni sarvakāraṇasaṃkṣaye
]

`v 9 [
sargārambhasya bhūyaḥ syādvada kiṃ mūlakāraṇam |
kāni vā sahakārīṇi kāraṇāni kutaḥ katham
]

`v 10 [
kiṃ jagatkiṃ ca sargādi kāścinnityaṃ tamodharāḥ |
vyomasaṃsthārṇavāḥ kāścitkāścitkṛmikulākulāḥ
]

`v 11 [
kāścidākāśakośasthāḥ kāściccopalakośagāḥ |
kiṃ ca vā bhūtabhūtādi kuto buddhyādayaḥ katham
]

`v 12 [
kaḥ kartā ko'tha vā draṣṭā kādhārādheyatā katham |
na kadācinmahānāśo jagatāmiti niścayaḥ
]

`v 13 [
samastavedaśāstrārthāvirodhāya samarthitaḥ |
yathā saṃvedanaṃ nāma tathā nāmānubhūtayaḥ
]

`v 14 [
yatastato vedanaṃ syātkimanāśamasanmayam |
anyacca jambūdvīpādau deśe'dya munināyaka
]

`v 15 [
mṛtānāmagnidagdhānāmiha vā dehanāśinām |
narakasvargabhogāya videhe dehakāraṇam
]

`v 16 [
kiṃ tasyātsahakārīṇi kāraṇānyatha kāni vā |
dharmādharmāvamūrtau dvau tasyāmūrtasya mūrtatā
]

`v 17 [
nirdravyaṃ kurute dravyairyuktirityasamañjasā |
mātāpitrādyabhāvo hi bījaṃ kiṃ tatra kāraṇam
]

`v 18 [
anye vā hetavaḥ ke syuḥ kathaṃ dravyādisaṃbhavaḥ |
paraloko'sya nāstīti yathāsaṃvedanaṃ sthiteḥ
]

`v 19 [
samastalokavedādivirodhāccāsamañjasam |
anicchitehitairdūradeśāntaragataiḥ phalam
]

`v 20 [
prajā prāpnotyasaṃbandhairamūrtairatra kaḥ kramaḥ |
stambho vareṇa sauvarṇo vinā hemagamāgamaiḥ
]

`v 21 [
kṣaṇātsaṃpadyate tatra saṃpattiḥ kathamucyatām |
vidhīnāṃ pratiṣedhānāṃ nirnimittaṃ vivalgatām
]

`v 22 [
rūḍhānāmapyarūḍhānāṃ kiṃ prayojanamucyatām |
asadāsījjagatpūrvaṃ satsaṃpannamanantaram
]

`v 23 [
iti śruteḥ kathaṃ brahmankathyatāṃ saṃgatārthatā |
ayaṃ bhavetkathaṃ brahmā bhaveccettanmahāmune
]

`v 24 [
kiṃ ca sargādau śūnyānnabhasaḥ sakāśādayaṃ brahmā hiraṇyagarbhaḥ kathaṃ bhavet |
yadi nabhasa evaṃprabhāvatā astītyucyeta
tarhyevaṃprabhāvātsarvasmātsarvapradeśabhinnātsarvatra brahmā kuto'nyo na jāyate | 23
|
evaṃprabhāvānnabhasaḥ kiṃ sarvasmānna jāyate |
oṣadhīnāmathārthānāṃ sarveṣāṃ vā sthitiṃ gatāḥ
]

`v 25 [
kathaṃ svabhāvāḥ kathaya yathābodhaṃ munīśvara |
ekasya jīvitaṃ puṃsaḥ suhṛdā maraṇaṃ dviṣā
]

`v 26 [
mṛtvārthitaṃ prayāgādau kṣetre tatkathamucyatām |
khe syāmakṣayapūrṇenduriti dhyāyicitaiḥ phalaiḥ
]

`v 27 [
tulyakālamanuprāptaiḥ sahasrendu na kiṃ nabhaḥ |
anyacca dhyāyināṃ lakṣairdhyātaikā strī yathākramam
]

`v 28 [
jāyātvena samaṃ kālaṃ labdhaṃ dhyānaphalaṃ ca taiḥ |
sādhvyasādhvī gṛhe bhartuḥ saṃsthitā tapasā parā
]

`v 29 [
teṣāṃ ca jāyā saṃpannā kathametanmahāmune |
gṛhānirgacchamākalpaṃ nṛpaḥ sa dvīpasaptake
]

`v 30 [
varatvaṃ varaśāpābhyāmiti antaḥ kva tiṣṭhati |
dānadharmāditapasāmaurdhvadehikakarmaṇām
]

`v 31 [
ihasthānāmamūrtānāṃ mūrtaṃ prītyāsti satphalam |
vyavahartā na mūrto'tra vidyate lokayordvayoḥ
]

`v 32 [
deśāntare bhṛśaṃ jīvo bhṛśaṃ kālāntare'pi vā |
phalaṃ saṃbhavatīyattadvinānubhavanaṃ mune
]

`v 33 [
asamañjasamevāti kathaṃ syātsusamañjasam |
ityādisaṃśayagaṇaṃ girā śītāvadātayā |
chindhi me'bhyuditaṃ bhāsā sāndhyamāndhyamivoḍupah
]

`v 34 [
paramavastuni saṃśayanāśanādubhayalokahitaṃ bhavati sphuṭam |
tadiha me kuru sādhusamāgamastanuphalo bhavatīha na kasyacit
]