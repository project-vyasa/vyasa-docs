`v 1 [
ekoviṃśādhikaśatatamaḥ sargaḥ 119
sahacarā ūcuḥ |
kathayatyeṣa pathikaḥ paśya mandaragulmake |
priyāyāściralabdhāyā vṛttāṃ virahasaṃkathām
]

`v 2 [
ekatra śṛṇu kiṃvṛttamāścaryamidamuttamam |
dātuṃ tvannikaṭe dūtamahaṃ cintānvito'vadam
]

`v 3 [
asminmahāpralayakālasame viyoge yo māṃ tayeha mama yāti gṛhaṃ sa kaḥ syāt |
naivāstyasau jagati yaḥ paraduḥkhaśāntyai prītyā nirantarataraṃ saralaṃ yateta | 3
|
kimavadattadāha - asminniti | asminmahāpralayakālasame viyoge viyogalakṣaṇāyāṃ
mahāpadi ihasthaṃ māṃ vṛttāntaprāpaṇena tayā sabhājayituṃ yo mama gṛhaṃ yāti
sa tādṛśo dayālurdūtaḥ kaḥ syāt | yaḥ paraduḥkhaśāntyai prītyā saralaṃ yathā
syāttathā nirantaraṃ yateta | asau tādṛśaḥ puruṣo jagati naivāsti
]

`v 4 [
ā eṣa śikhare meghaḥ smarāśva iva saṃyutaḥ |
vidyullatāvilāsinyā valito rasikaḥ sthitaḥ
]

`v 5 [
bhrātarmegha mahendracāpamucitaṃ vyālambya kaṇṭheguṇaṃ nīcairgarjaṃ
muhūrtakaṃ kuru dayāṃ sā bāṣpapūrṇekṣaṇā |
bālā bālamṛṇālakomalatanustanvī na soḍhuṃ kṣamā tāṃ gatvā sugate
galajjalalavairāśvāsayātmānilaiḥ
]

`v 6 [
cittatūlikayā vyomni likhitvāliṅgitā satī |
na jāne kvādhunaivetaḥ payoda dayitā gatāḥ
]

`v 7 [
itthaṃ cintāparavaśamatestanvi sārdhaṃ tvayā'sāvantarlīnaprasaramanasaḥ kvāpi
yātā smṛtirme |
saṃpanno'haṃ paravaśavapuḥ kāṣṭhakuḍyopamāṅgo bhaṅgaṃ soḍhuṃ ka iva
virahakleśajaṃ nāma śaktaḥ
]

`v 8 [
paścājjātaḥ kalakalaravaḥ saṃtate pānthasārthe
dīnālāpairvyasanavidhurairālapante ca megham |
kaṣṭaṃ pāntho mṛta iti mahārambhasaṃpannahāhāśabdaḥ
prodyatpathikavanitāvistṛtoraḥprahāraḥ
]

`v 9 [
lokenāyaṃ mṛta iti tato bāṣpasaṃpūritākṣaṃ śāvīṃ pūjāṃ viracitavatā
saṃcayīkṛtya dāru |
dagdhuṃ nīto'smyatibhayamahaṃ
prajvalaccityantaprodyatsphoṭasphuṭapaṭapaṭārāvaraudraṃ śmaśānam
]

`v 10 [
tatrāhaṃ taiḥ kamalavadane bāṣpapūrṇākṣipakṣairnyastaḥ kaiściccitiśayanake
baddhalokālilekhe |
dhūmodgārāviralajaṭile mastake mattamṛtyoścūḍāratnottama iva
kalāmātradṛśye'gnihemni
]

`v 11 [
asminkāle kuvalayalatākomalā dhūmalekhā nāsārandhraṃ mṛdugalabilaṃ me
pravṛttā niyātum |
uṣṇā kṛṣṇā nakulakalitā satvaraṃ bālasarpī bhūme randhraṃ tanumiva
darāddairghyasaṃkocakubjā
]

`v 12 [
tvatsaṃkalpāmṛtakavacito nāpaviddhastayāhaṃ kuntaśreṇyā dṛḍhapatanayā
vajrakāyo yathājaḥ |
tvāmāsannāṃ madanasaritaṃ hṛdgṛhe gāhamāno marmacchedeṣvapi vilasitā
nāvidaṃ vedanāstāḥ
]

`v 13 [
etāvantaṃ samayamucitaṃ tanvi sārdhaṃ tvayāntarlīlālolaṃ hṛdi cirataraṃ
tanmayātrānubhūtam |
yasmindṛṣṭe'mṛtahrada ivonmajjanaurghairyathāsau rājyābhogo
viśasanamivālpālpameveti buddhiḥ
]

`v 14 [
sā līlā te vilāsā vacanamapi ca tatsasmitaṃ te kaṭākṣāḥ sānandānantarasya
prasarasamucitā dūramaṇyekabhūṣā |
tānīhārāvasārāvahasanacalanāvegavikṣobhitāni kiṃvā tattanna
yatsaṃsmṛtamamṛtarasāhlādamaṃtaḥ karoti
]

`v 15 [
tvatsaṃgame suratasaukhyarasāyanena bāle tato'hamatitṛptatayā śramārtaḥ |
tatra sthito mṛduni talpatale śaśāṅkabimbe śaracchiśiranirmalaśociṣīva
]

`v 16 [
atrāntare jhaṭiti candanapaṅkaśītāddīrghādivenduśakalādaśaniḥ saśabdaḥ |
dṛṣṭo mayā cititalajvalito hutāśaḥ kṣīrābdhivāḍavanibhoṅgataḥ svatalpāt
]

`v 17 [
sahacarā ūcuḥ |
ityuktavati kānte'smin hā hatāsmīti vādinī |
mugdhā maugdhyādvarāvartaśaṅkayā mūrcchitā sthitā
]

`v 18 [
tāmenāmeṣa nalinīdalavījena vāribhiḥ |
āśvāsayaṃstathāvasthāṃ kaṇṭhekṛtvātra saṃsthitaḥ |
]

`v 19 [
punaḥ pṛṣṭo'nayā vakti paśya tāmeva saṃkathām |
eṣa pārśvagatāmenāṃ gṛhītvā cibuke priyām
]

`v 20 [
hā hā hutāśa iti kiṃcidivopajātakhedo vadāmi khalu yāvadahaṃ tvarāvān |
tāvaccitirjhaṭiti tairavaluṇṭhitā sā pānthaiḥ kṣaṇātkharakharākulitā lasadbhiḥ | 20
|
tamevāha - hāheti | he priye ahaṃ kiṃcidivopajātakhedaḥ san hā hā hutāśa iti
yāvadvadāmi tāvajjhaṭiti tairlasadbhiḥ prahṛṣṭaiḥ pānthaiḥ
kharakharadhvanibhirākulitā sā citiḥ sarvolmukāpahāreṇāvaluṇṭhitā
]

`v 21 [
pānthāstatastaralatālavilāsavādyamāliṅgya māmatanuśekharapūritāṅgam |
utthāpitasthitimalaṃ parivārya sarve nedurjagurjahasurānanṛturvavalguḥ
]

`v 22 [
viṣamavināyakasukhadaṃ valitaṃ bhasmāhiśavaśiraḥprakaraiḥ |
śaśidhavalāsthikapālaṃ vapuriva raudraṃ śmaśānamatha dṛṣṭam
]

`v 23 [
pārśvacchāyāṃ haranto vicalitavidalatklinnakaṅkālagandhā stanvanto
bhūribhasmapravitatamihikāmādhunānāḥ śavānām |
keśānākāśakośe śaśigalitaśarākāriṇaḥ śāṃkarāṇāmasthīnāṃ
ṭāṃkṛtenāracitakharagirastatra vātāvahanti
]

`v 24 [
jvaladanalacitipravāhaniryatpavanahatoṣmaviśuṣkaparṇavṛkṣā |
jvalanapavanabhāskarātmajānāṃ ramaṇagṛhānukṛtiṃ bibharti sā bhūḥ
]

`v 25 [
dṛṣṭaṃ śmaśānaṃ tadanantabhīmakaraṅkakaṃkālaghanāmagandhi |
mādyacchivāvāyasakaṅkagṛdhrapiśācavetālavirāvaraudram
]

`v 26 [
ānītanānāśavabandhusārthasaṃrodanāhrādidigantakuñjam |
khagāvakṛṣṭārdraśirāntratantrīnibaddhadagdhadrumakhaṇḍajālam
]

`v 27 [
kvaciccitikṣobhakṛtaprakāśaṃ kvacinmahākeśakṛtābdavṛndam |
kvacicca raktāktadharāvitānaṃ naktaṃ stanattvabhramivāstaśailam
]