`v 1 [
aṣṭādhikaśatatamaḥ sargaḥ 108
śrīrāma uvāca |
avidyā dṛśyarūpeyaṃ kacantī yasya vidyate |
cinnabhaḥsvapnanagarī dṛśyamānāpi śūnyakam
]

`v 2 [
tasyājñasya kiyatkālaṃ kṃrūpā syātkimātmikā |
kiyatī sā ca vetyevaṃ mune me kathyatāṃ punaḥ
]

`v 3 [
tasminvipaściccarite caturdikṣuvipaścitaḥ |
iha dviṣatsamutthānodantaśrutyantamucyate |
śrīvasiṣṭha uvāca |
avidyā vidyate yeṣāmajñānāṃ bhūtalādikā |
teṣāmasyāṃ brahmaṇīva nāstyanto'tra kathāṃ śṛṇu
]

`v 4 [
sadṛśaṃ jagato'syāsti kvacidambarakoṇake |
kasmiṃścittrijagatkiṃcidanayaiva vyavasthayā
]

`v 5 [
asti kaścidbhuvo bhāgo bhūṣaṇaṃ tatra bhūsthiteḥ |
purī tatamitirnāmnā suvyaktakalanā'vanau
]

`v 6 [
tatrāsītpārthivaḥ kaścidvipaściditi viśrutaḥ |
yaḥ sabhāyāṃ susabhyāyāṃ vipaścittvādvirājate
]

`v 7 [
rājahaṃsa ivābjinyāmṛkṣacakra ivoḍurāṭ |
sumeruriva śailaughe yaḥ sabhāyāmarājata
]

`v 8 [
nivartate yato'śaktyā vacanaṃ guṇavarṇanāt |
kabīnāmacalākārā bhavedbhā bhūdharo yathā
]

`v 9 [
prātaḥprātarvikasitātsarvāśābhāsanodyatāt |
yataḥ pratāpajanitaśrīrudetyambujādiva
]

`v 10 [
sa brahmaṇyamatirmānī vahnimevādhidaivatam |
apūjayatsamaṃ bhaktyā devaṃ vetti sma netaram
]

`v 11 [
samatsyamakaravyūhā gajavājigaṇānvitāḥ |
āvartacakravyūhāḍhyāḥ kallolabalamālitāḥ
]

`v 12 [
maryādāpālane yuktā akampanabalādhikāḥ |
mantriṣvapyasya catvāro dikṣu satsāgarā iva
]

`v 13 [
tairaśeṣakakupcakranābhirābhāsitāvaniḥ |
āsītsudurjayo jetā sa dudarśanacakravat
]

`v 14 [
tamekadā yayau pūrvadiṅmukhāccaturaścaraḥ |
sa uvāca raho raṃhogatighorākṣaraṃ vacaḥ
]

`v 15 [
deva durdrumaviśrāntadharāgobandhanācyuta |
śrūyatāṃ manmukhātpaścādyathāprāptaṃ vidhīyatām
]

`v 16 [
pūrvadiṅmukhasāmanto jvareṇāstamupāgataḥ |
manye jetuṃ yamaṃ yātastvayārabdho jitāriṇā
]

`v 17 [
tasminsamantato jetuṃ dakṣiṇāpathanāyakaḥ |
pūrvāparābhyāmākramya balābhyāmariṇā''hataḥ
]

`v 18 [
tasminmṛte samāgamya yāvadvāruṇadikpatiḥ |
balenāyāti kakubhau te samādātumādṛtaḥ
]

`v 19 [
pūrvadeśanṛpaiḥ sārdhaṃ dakṣiṇāpathapārthivaiḥ |
tāvadevāribhirasāvardhamārge raṇe hataḥ
]

`v 20 [
śrīvasiṣṭha uvāca |
athāsminkathayatyevaṃ tvarārtamaparaścaraḥ |
upaplavajaḍotpīḍa `note[upaplavo jaḍotpīḍa iti pāṭhaścintyaḥ |] iva harmyaṃ
viveśa ha
]

`v 21 [
cara uvāca |
uttarāśābalādhyakṣo devāribhirupadrutaḥ |
ita āyāti sabalo bhagnasetvambupūravat
]

`v 22 [
śrīvasiṣṭha uvāca |
iti śrutvā mahīpālaḥ kālakṣepamavāstavam |
manyamāna uvācedaṃ nirgacchanvaramandirāt
]

`v 23 [
rājñaḥ sannahya sāmantānānīyantāṃ ca mantriṇaḥ |
udghāṭyantāṃ hetiśālā dīyantāṃ ghorahetayaḥ
]

`v 24 [
śleṣyantāṃ kaṃkaṭā deheṣvāgacchantu padātayaḥ |
gaṇyantāmāśu sainyāni kriyantāṃ varakalpanāḥ
]

`v 25 [
kalpyantāṃ ca balādhyakṣāḥ preṣyantāmabhitaścarāḥ |
śrīvasiṣṭha uvāca |
vadatyevaṃ tvarāyuktaṃ saṃrambhavati rājani
]

`v 26 [
pratīhāra uvācedaṃ praviśyākulamānataḥ |
pratīhāra uvāca |
uttarāśābalādhyakṣo deva dvāryavatiṣṭhati |
kāṅkṣatyabjamivārkasya devadevasya darśanam
]

`v 27 [
rājovāca |
gacchāvilambitaṃ tāvadenameva praveśaya |
jānīmaḥ kiṃ diganteṣu vṛttaṃ vṛttāntasaṃśravāt
]

`v 28 [
śrīvasiṣṭha uvāca |
ityukta uttarāśeśaṃ pratihārapraveśitam |
praṇāmaparamagre'sau rājā'paśyadbalādhipam
]

`v 29 [
iti rājñā ukte sati pratihārapraveśitamuttarāśeśamagre praṇāmaparaṃ rājā apaśyat |
28 |
kṣatavikṣatasarvāṅgamaṅgamaṅgeṣusaṃtatam |
śvāsākulaṃ vamadraktaṃ dhairyeṇābalanirjitam
]

`v 30 [
sa praṇamya tvarāyuktamuvācedamupakramam |
saṃstabhyāṅgavyathāmāśu saṃtatocchvāsamucchvasan
]

`v 31 [
balādhyakṣa uvāca |
deva trayo'pi dikpālā balena bahunā saha |
tvadājñayeva nirjetuṃ yamaṃ yamapuraṃ gatāḥ
]

`v 32 [
taddeśapālanādyarthamaśaktaṃ māmimaṃ tataḥ |
anudravanto bahavo bhūpāḥ prāptā balādiha
]

`v 33 [
mahatparabalaṃ prāptamidaṃ devasya maṇḍalam |
vidhīyatāṃ tathāprāptaṃ na devasyāsti durjayam
]

`v 34 [
śrīvasiṣṭha uvāca |
atha tasminvadatyevamārtimatyājivikṣate |
sahasaivābhyuvācedaṃ praviśya puruṣo'paraḥ
]

`v 35 [
puruṣā maṇḍalasyāsya vipulā dalalīlayā |
sthitānyaribalānyuccaiścaturdikkaṃ nareśvara
]

`v 36 [
kacaccakragadāprāsakuntakānanakāntibhiḥ |
valitā no'ribhirbhūmirlokālokataṭairiva
]

`v 37 [
patākāyudhayodhraṅgāścalatparikarākulāḥ |
visaranti rathāstatra proḍḍīnatripuraughavat
]

`v 38 [
karānunnāmayantaḥ khe māṃsavṛkṣavanopamāḥ |
bṛṃhanti vāraṇavyūhā varṣāvāridavṛndavat
]

`v 39 [
natonnatāni kurvantaḥ spandenorvīnatonnataiḥ |
heṣante hayasaṃghātā vātaspandamahābdhivat
]

`v 40 [
rasanti turagāpurāḥ phenilāvartapātinaḥ |
sarvato balayākārā lavaṇārṇavavārivat
]

`v 41 [
ākāśakāntisannāhairdiśaṃ prati balaṃ balam |
udetyalaghukallolaiḥ pralayārṇavapūravat
]

`v 42 [
śarāstraśastrasannāhamukuṭābharaṇatviṣaḥ |
kacanti tvatpratāpāgnerjvālā iva tadaṅgagāḥ
]

`v 43 [
samatsyamakaravyūhāḥ sacakrāvartavṛttayaḥ |
udyanti sainyasaṃghaṭṭaiḥ kallolā jaladheriva
]

`v 44 [
parasparaparāmarśātkuntādyāyudhapaṅktayaḥ |
kopādivograhuṃkārairjvalanti viraṭanti ca
]

`v 45 [
iti kartumahaṃ deva vijñaptiṃ svāmineritaḥ |
tasmānmaṇḍalasīmāntagulmādyuddhāya gacchatā
]

`v 46 [
tamahaṃ deva gacchāmi śaktyṛṣṭiśarasaṃgataḥ |
mayehāveditaṃ sarvaṃ devo jānātyataḥ param
]

`v 47 [
śrīvasiṣṭha uvāca |
ityuktvātha praṇāmaṃ ca sa kṛtvā tvarayā yayau |
kṛtvā gulugulārāvaṃ śānto vīcirivāmbudheḥ
]

`v 48 [
saṃbhrāntamantrinṛpayodhaniyogināganārīrathāśvaparicārakanāgaraugham |
rājño gṛhaṃ svabhayatolitahetisārthaṃ caṇḍānilākulamahāvanatulyamāsīt
]