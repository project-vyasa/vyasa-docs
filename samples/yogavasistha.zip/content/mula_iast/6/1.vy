`v 1 [
gajavadanaṃ śubharadanaṃ sajjanabharaṇaṃ samastaguṇasadanam |
saccitsukhasāraghanaṃ sadayaṃ hṛdaye sadā vande
]

`v 2 [
nimajjyāntarbhaktyāmṛtarasavasiṣṭhoktijaladhau sadrthā unnītā iha
gurukaṭākṣātkatipaye |
vicinvāno hyantarjaladhijaṭharaṃ ko nu kalayediyattāṃ ratnānāṃ pracuratarayatnairapi
kṛtī
]

`v 3 [
nirupamanijavistāraṃ niḥsaṃsāraṃ nitāntagambhīram |
nityasukhāmṛtapūraṃ pārāvāraṃ paraṃ svameva bhaje
]

`v 4 [
ṛturasaturagamahī 1766 śakavikāriśubhavatsarasya śiśirartoḥ |
phālgunasitasaptamyāṃ bhṛgurauhiṇavṛṣabhalagnake siddham
]

`v 5 [
vākyapuṣpāñjaliḥ so'yaṃ mayā bhaktyā samarpitaḥ |
dhiyaḥ prerakayoḥ śrīmacchivayoḥ śrīpadābjayoḥ
]