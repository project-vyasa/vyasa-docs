`v 1 [
pdf 279, p. 1313
ṣaḍadhikaśatatamaḥ sargaḥ 106
śrīrāma uvāca |
kīdṛśaṃ syāccidākāśaṃ tadbrahmanbrahma yatparam |
bhūyaḥ kathaya tṛptirhi śṛṇvato nāsti me'mṛtam
]

`v 2 [
śrīvasiṣṭha uvāca |
samayoryamayorbhrātrorvyavahārāya nāmanī |
yadvatkriyete dve tadvajjāgratsvapnaśilāmaye
]

`v 3 [
vastutastvanayorbhedo na dvayoḥ payasoriva |
dvayamapyekamevaitaccinmātraṃ vyoma nirmalam
]

`v 4 [
deśāddeśāntaraṃ dūraṃ prāptāyāḥ saṃvido vapuḥ |
nimiṣeṇaiva tanmadhye cidākāśaṃ taducyate
]

`v 5 [
yādṛśastiṣṭhataḥ svacchaṃ rasamākarṣatastaroḥ |
bhavedbhāvo nabhaḥsvacchastādṛśaṃ cinnabhaḥ smṛtam
]

`v 6 [
vinivṛttākhilecchasya puṃsaḥ saṃśāntacetasaḥ |
yādṛśaḥ syātsamo bhāvastādṛśaṃ cinnabhaḥ smṛtam
]

`v 7 [
anāgatāyāṃ nidrāyāṃ manoviṣayasaṃkṣaye |
puṃsaḥ svasthasya yo bhāvaḥ sa cidākāśa ucyate
]

`v 8 [
tṛṇagulmalatādīnāṃ vṛddhimāgacchatāmṛtau |
yaḥ syādunmamato bhāvaḥ sa cidākāśa ucyate
]

`v 9 [
rūpālokamanaskāravimuktasyāmṛtasya yaḥ |
bhāvaḥ puṃsaḥ śaradvyomaviśadastaccidambaram
]

`v 10 [
yadetadāsanaṃ sṛṣṭaṃ kāṣṭhapāṣāṇabhūbhṛtām |
cetanānāṃ ca sattātma cidākāśaḥ sa ucyate
]

`v 11 [
draṣṭṭadarśanadṛśyānāṃ trayāṇāmudayo yataḥ |
yatra vāstamayaścitkhaṃ tadviddhi vigatāmayam
]

`v 12 [
yata udyanti yasmiṃśca citrāḥ pariṇamantyalam |
padārthānubhavāḥ sarve cidākāśaḥ sa ucyate
]

`v 13 [
yasminsarvaṃ yataḥ sarvaṃ yaḥ sarvaṃ sarvataśca yaḥ |
yaśca sarvamayo nityaṃ ca cidākāśa ucyate
]

`v 14 [
divi bhūmau bahiścāntastathānyasya samābhidhaḥ |
yo vibhātyavabhāsātmā cidākāśaḥ sa ucyate
]

`v 15 [
yasminnitye tate tantau dṛḍhe sragiva tiṣṭhati |
sadasadutthitaṃ viśvaṃ viśvāṅge taccidambaram
]

`v 16 [
viśvāṅge yasminnutthitaṃ sanmūrtamasadamūrtaṃ ca viśvaṃ tantau sragiva tiṣṭhati tat |
15 |
yasmātsarvāḥ prasūyante sargapralayavikriyāḥ |
yasmiṃścaiva pralīyante yanmayāstaccidambaram
]

`v 17 [
nidrāyāṃ vinivṛttāyāṃ yato viśvaṃ pravartate |
nivartate ca yacchāntau taccidambaramucyate
]

`v 18 [
yasyonmeṣanimeṣābhyāṃ jagatsattālayodayau |
svānubhūtyātmakaṃ svāntaḥ sthitaṃ tadviddhi cinnabhaḥ
]

`v 19 [
nedaṃ nedaṃ tadityevaṃ sarvaṃ nirṇīya sarvathā |
yanna kiṃcitsadā sarvaṃ taccidvyometi kathyate
]

`v 20 [
deśāddeśāntaraprāptau yanmadhye saṃvido vapuḥ |
dūrato'rdhanimeṣeṇa taccinmātravapuḥ smṛtam
]

`v 21 [
viśvaṃ tanmayamevedaṃ yathā bhūtaṃ yathā sthitam |
rūpālokamanaskārairyuktamapyevamīdṛśam
]

`v 22 [
īṣadunmeṣaṇādetadanyatāmiva gacchati |
ananyarūpamapi saccidvyoma vimalākṛti
]

`v 23 [
paśyannevendriyairarthānnūnaṃ nirvāsanāśayaḥ |
prabuddha evaikaghanaḥ suṣuptāvasthito bhava
]

`v 24 [
nirvāsanaḥ śāntamanā vada vraja pibāhara |
pāṣāṇa iva saṃjīvo nityaṃn sughanamaunavān
]

`v 25 [
idaṃ na saṃbhavatyeva dṛśyaṃ paśyasi yatpuraḥ |
mṛgatṛṣṇājalamiva dvaitamindāvivoditam
]

`v 26 [
anyatāmiveti ivakāreṇānyatāyā mithyātvamuktaṃ tatkuta iti cedasaṃbhavādevetyāha ##-
idamādāvanutpannaṃn kāraṇābhāvataḥ kila |
kāraṇena vinā kāryaṃ na hi nāmopapadyate
]

`v 27 [
yadvopapadyate kiṃcittadakāraṇakodbhavam |
yathāsthitaṃ paraṃ rūpamudbhūtamiva lakṣyate
]

`v 28 [
tadyathāsthitamevāṅga pūrvarūpamavasthitam |
bhavatyadvayamevācchaṃ dvayenāpyupalakṣitam
]

`v 29 [
tatredaṃpratyayaḥ prauḍho bhavatyanubhavo hi yaḥ |
samāyātamidaṃ bhrāntaṃ tatsvapnastrīsamaṃ viduḥ
]

`v 30 [
tasmāddṛśyaṃ na cotpannaṃ naivāsti na bhaviṣyati |
na ca naśyati yannāsti tasya kiṃ nāma naśyati
]

`v 31 [
tattadeva paraṃ śāntaṃ cidvyomaiva tathā sthitam |
svarūpādacyutaṃ svasthaṃ saumyaṃ jagadivoditam
]

`v 32 [
na hīdamagre yaddṛṣṭaṃ dṛśyaṃ tatsatkadācana |
na cāpi draṣṭā dṛṣṭārthābhāve kva draṣṭṭatā kila
]

`v 33 [
śrīrāma uvāca |
evaṃ cettadvada brahmandraṣṭṭadṛśyāvabhāsanam |
kimidaṃ kathamābhāti bhūyo'pi vadatāṃvara
]

`v 34 [
śrīvasiṣṭha uvāca |
asadrūpasya dṛśyasya kāraṇābhāvataḥ sadā |
dṛśyatāsyetyapi prauḍhinirdeśasyātyasaṃbhavāt
]

`v 35 [
yadidaṃ bhāsate kiṃciddraṣṭṭadṛśyabhramātmakam |
jagadādi paraṃ rūpaṃ tadviddhi paramātmanaḥ
]

`v 36 [
ata evedaṃ draṣṭṭadṛśyaṃ na asato rūpaṃ kiṃ tu paramārthasato brahmaṇa ityāha ##-
svapne cinmātra evāste yathā gaganakānanam |
tathā jagattayā bhāti svayaṃ cinmātramātmani
]

`v 37 [
ihādisargātprabhṛti nāstyupādānakāraṇam |
kiṃcanāpi kvacidapi bhātītthaṃ brahma kevalam
]

`v 38 [
yaccidākāśakacanaṃ svayamātmani jṛmbhate |
tadidaṃ bhāti tasyaiva jagadityuditaṃ vapuḥ
]

`v 39 [
yathā bhāvasya bhāvatvaṃ yathā śūnyasya śūnyatā |
ākāriṇo yathākārastathā cinnabhaso jagat
]

`v 40 [
idaṃ viddhi cidābhāsaṃ paramārthaghanaṃ ghanam |
itthaṃ viddhi cidābhāsaṃ paramārthaghanaṃ ghanam |
itthaṃ sthitaṃ svayaṃ bhātaṃ draṣṭṭadṛśyadṛgātmakam
]

`v 41 [
vastutastu dvayābhāvānnābhāsi na ca bhāsanam |
kimapīdamanirdeśyaṃ sadvā'sadveti vetti kaḥ
]

`v 42 [
śrīrāma uvāca |
evaṃ cettadvada brahmankāryakāraṇatādikaḥ |
kathaṃ bhedaḥ kimāyātaḥ kathaṃ satyatvamāgataḥ
]

`v 43 [
śrīvasiṣṭha uvāca |
citprakāśo yathābhānaṃ yadā bhāvayati svayam |
svātmā tathā tadevāśu paśyasītyasi dṛṣṭavān
]

`v 44 [
cidvyomaivāyamākāraḥ sve vyomnyeva na muhyati |
svayameva yathā svapne ko'sya paryanuyogakṛt
]

`v 45 [
bhāvādbhāvāntaraprāptau madhye yatsaṃvido vapuḥ |
taccidvyoma tadevedaṃ sarvaṃ ca `note[atra sarvaṃ vastviti netarat iti pāṭho yuktaḥ |
] sthiti netarat
]

`v 46 [
kāryakāraṇabhāvādidṛśo'vidyāvijṛmbhikāḥ |
jagadvatkalpayatyeṣa ko'sya paryanuyogakṛt
]

`v 47 [
draṣṭā bhoktātha kartā vā kaścitsyāditaro yadi |
tatkathaṃ kimidaṃ dṛśyamiti yujyeta nānyathā
]

`v 48 [
yatra svapne nirābhāsaṃ cidvyomaiva virājate |
śuddhamekamanekātma tatra kiṃ kva vikalpyate
]

`v 49 [
āsvayaṃbhuva eveyaṃn cinmātre bhāti sargabhāḥ |
parijñātā satī sā tu brahmaiva bhavati kṣaṇāt
]

`v 50 [
eṣaiva tvaparijñātā bhrāntirmāyeti kathyate |
jagadityucyate vidyā dṛśyamityupavarṇyate
]

`v 51 [
cidākāśaprakāśena cittā dṛśyapiśācakaḥ |
vetālo bālakeneva buddho'sanneva sanniva
]

`v 52 [
jagattātmanyasatyāpi cidvyomnaivānubhūyate |
satyeva sāṅgalekheva svapne'dripuratā yathā
]

`v 53 [
ahamadrirahaṃ rudraḥ samudro'hamahaṃ virāṭ |
cetyate khe citaiveti svapne'dripuratāyathā
]

`v 54 [
ākāri kāraṇābhāvājjātaṃ kāryaṃ na kiṃcana |
mahāpralayacidvyomni citsthitetthamidantayā
]

`v 55 [
akāraṇakamevedaṃ vyoma vyomnānubhūyate |
jagadityeva śūnyāṅgaṃ cinmātrātma cidātmani
]

`v 56 [
sarva eva jaḍā jīrṇā darpaṇā iva jantavaḥ |
samīpagata evāntaḥ kurvatastu vicāraṇam
]

`v 57 [
tattatsvarūpamutsṛjya buddhvā cinmātrakhaṃ jagat |
aśmanā cetanenaiva stheyaṃn nāsthetarottamā
]

`v 58 [
yathāste calayaddehaṃ vāryāvartajagaddravaḥ |
cetatīti tathā cittvaṃ sthitā cittajjagaddṛśā
]

`v 59 [
yathā kalpadrumo'bhīṣṭaṃ kuryāccintāmaṇiryathā |
tathā yadbhāvitaṃ svāntastatpūrayati citkṣaṇāt
]

`v 60 [
citiścintāmaṇiriva kalpadruma ivepsitam |
āśu saṃpādayatyantarātmanātmani khātmikā
]

`v 61 [
deśāddeśāntaraprāptau madhyadeśe citervapuḥ |
yattanmayamidaṃ dṛśyaṃ kuto dvaitaikyavibhramaḥ
]

`v 62 [
cicchāyaivaṃ kacatyacchamanantā bhāsvarodarā `note[bhāsvarodayā iti pāṭhaḥ |
] |
aṅgariktāpi dṛśyāntaḥśūnyatā nīlateva khe
]

`v 63 [
visadṛśakāryānubhavo na bhavati sahakārikāraṇābhāvāt |
sargādāvata ādyā cideva dṛśyaṃ yathā svapne
]