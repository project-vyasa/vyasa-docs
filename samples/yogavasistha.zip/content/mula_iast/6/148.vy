`v 1 [
pdf 336, p. 1422
aṣṭacatvāriṃśadadhikaśatatamaḥ sargaḥ 148
vyādha uvāca |
evaṃ cettanmuniśreṣṭha satyatāsatyatā katham |
sthitaḥ svapnadṛśā caiṣa sumahānsaṃśayo mama
]

`v 2 [
muniruvāca |
deśakālakriyādravyairyā saṃvinniścitoditā |
kākatālīyavadbhāti sā satyasvapnanāmikā
]

`v 3 [
maṇimantrauṣadhidravyaiḥ kvacidavyabhicāriṇī |
kvacitsavyabhicārā citsatyasvapnābhidhā smṛtā
]

`v 4 [
satyasvapnasthitirlokeṣvīdṛgrūpā yadā sthitā |
tadaiṣā kākatālīyanyāyādanyā na labhyate
]

`v 5 [
yaṃ yaṃ niścayamādatte saṃvitsvadṛḍhaniścayā |
tathā tathā bhavatyeṣā phalayuktasvabhāvataḥ
]

`v 6 [
tameva niścayaṃ tvasyā anyaḥ pratinihanti cet |
tatrāsau niścayaḥ prauḍhaḥ sa kathaṃ lakṣyabhāgbhavet
]

`v 7 [
na bahirnāntare santi padārthāḥ kecana kvacit |
saṃvidekā jagadrūpairyathecchati tathā sthitā
]

`v 8 [
svapno'yaṃ satya ityantarniścayena tathoditā |
tathaivāśu bhavatyeṣā saṃśayātsaṃśayaṃ vrajet
]

`v 9 [
anyato'pi phalaṃ prāptaṃ asvapnasatyatvakalpanāt |
svapnena sūcitamidaṃ phalamityeva vettyayam
]

`v 10 [
sarva eva nijayā jagattraye saṃvidātiśayitā dṛḍhā api |
kālato vyabhicaranti deśato yatnataśca cirato'cireṇa vā
]

`v 11 [
sargādāveva cidvyoma bhānamapratighaṃ jagat |
vastusattāṃ cidevāto yatheṣṭaṃ tanute tanuḥ
]

`v 12 [
cinmātraṃ varjayitvaikaṃ brahmānyatsarvadākhilam |
viddhi satyamasatyaṃ ca niyatāniyataṃ sthitam
]

`v 13 [
yasmādbrahmaiva sarvātma sadekameva netarat |
tasmātkiṃ nāma tatsatyaṃ kimasatyaṃ ca vā bhavet
]

`v 14 [
ataḥ svapnaḥ kvacitsatyaḥ kvaciccāsatya eva vā |
abuddhānāṃ prabuddhānāṃ nāsadrūpo na sanmayaḥ
]

`v 15 [
saṃvidbhrāntiriyaṃ bhāti jagannāmnī svarūpiṇī |
svayaṃ ca bhrāntirasmīti vādinī kātra niścitā
]

`v 16 [
citireva cirāyedaṃ cittaṃ cimacimāyate |
yadātmanyeva salilaṃ dravavattadidaṃ jagat
]

`v 17 [
yathā svapnaṃ samālokya suṣuptamanubhūyate |
tathā jāgratsamālokya nidrā samanubhūyate
]

`v 18 [
atastvaṃ jāgradevedaṃ svapnaṃ viddhi mahāmate |
svapnaṃ ca viddhi jāgrattvamekametadajaṃ dvayam
]

`v 19 [
vyomaivācetyacinmātrabhānamekamidaṃ tatam |
jāgratsvapnasuṣuptyākhyāḥ paryāyaracanā iha
]

`v 20 [
neha nāmāsti niyatirna cāniyatirasti ca |
niyatyaniyatī brūhi kīdṛśe svapnasaṃvidi
]

`v 21 [
yāvadbhānaṃ kila svapne tāvatsaiva niyantraṇā |
sa eva saṃvidbhānasya kuryānniyamanaṃ muniḥ
]

`v 22 [
svacchandaṃ vātalekhāyāḥ sphurantyāḥ saṃvidastathā |
akāraṇakamevāṅga niyatiḥ keva kīdṛśī
]

`v 23 [
athākārādi yannāma kalpyate kāraṇaṃ vidaḥ |
tadakāraṇakaṃ sargaḥ syādananyanna vai citeḥ
]

`v 24 [
etāvatyeva niyatiratra yannāma yadyathā |
yāvatprasphuritaṃ bhānaṃ tattathā na tadanyathā
]

`v 25 [
kadācitsatyatā svapne kadāciccāpyasatyatā |
abhāvānniyatereva kākatālīyameva tat
]

`v 26 [
yatsvenaivātmanā bhāti maṇimantrauṣadhātmanā |
yannāma niyataṃ tattu jāgratyapi hi dṛśyate
]

`v 27 [
maṇimantrauṣadhātmanā prayuktasatyatāniyatistu jāgratpratyaye'pi sametyāha - yaditi |
26 |
jāgratsvapnaśca cidbhānamātramevānyatātra kā |
jāgrati svapnanagare vedanātsadṛśātmakam
]

`v 28 [
jāgranna saṃbhavatyeva yajjāgraditi śabditam |
svapna eva jagadrūpaṃ nirnidrasyaiva cātmanaḥ
]

`v 29 [
ata eva nirnidra ātmani dvayorapi vyabhicārādasattvamevetyāha - jāgraditi dvābhyām |
28 |
svapno vā nāma nāstyeva yaḥ svapna iva śabditaḥ |
suptāsuptaikarūpasya brahmaṇo bodharūpatā
]

`v 30 [
jāgratsvapnādayo vaite na kecana kadācana |
dṛśyaṃ paśyati sattāśu mṛtibhrānteranantaram
]

`v 31 [
evaṃ sati nirnidrasya suṣuptirapi nāstyevetyāśayenāha - jāgraditi |
evamātyantikadṛśyādarśanarūpā ātmocchedādirūpā vā mṛtirapi nāstyevetyāha ##-
yathānavarataṃ kālamanantaṃ sīkarormayaḥ |
ta evānyavadabhrāśāvadananyāḥ sphurantyalam
]

`v 32 [
tathānanye pare sargāḥ sphurantyasphuritā api |
śilākośāntalekhāvajjāgratsvāpādi tatra kim
]

`v 33 [
jāgratsvapnasuṣuptaturyakavapuḥ sākāratāvarjitaṃ sarvākāramapi vyatītakalanaṃ
sargaṃ śarīraṃ dadhat |
vyāptaṃ cidvapuṣā tathāpi suṣiraṃ śūnyena dṛśyātmanā cinmātraṃ khamidaṃ
manāgapi nabhomātrānna bhinnaṃ punaḥ
]

`v 34 [
sākāśānilavahnivāridharaṇīlokāntarāmbhodharaṃ sargādāvapi
kāraṇānanubhavāccittātmakaṃ kevalam |
nāmnā varjitameva bodhavapuṣā saṃyuktamevāntataḥ śuddhaṃ vedanamātrameva
sakalaṃ dṛśyaṃ na vastvantaram
]