`v 1 [
ṣaṭṣaṣṭitamaḥ sargaḥ 66
śrīvasiṣṭha uvāca |
athetyuktavatī pṛṣṭā sā mayā kalpitāsanā |
saṃkalpitāsanasthena sthitena nabhasi sthitā
]

`v 2 [
kathaṃ śilodare bāle tvadvidhānāṃ bhavetsthitiḥ |
kathaṃ saṃcalanaṃ tatra kimarthaṃ tatra cāspadam
]

`v 3 [
vidyādharyuvāca |
mune yathedaṃ bhavatāṃ jagatsphāraṃ virājate |
tathāsmākaṃ jagattatra sargasaṃsārayuk sthitam
]

`v 4 [
sphuranti nāgāḥ pātāle tiṣṭhanti bhuvi parvatā |
āpaśchalachalāyante vahanti vyomni vāyavaḥ
]

`v 5 [
arṇavā arṇasā bhānti yāntyantaḥ śanakaiḥ prajāḥ |
bhūtānyajasraṃ jāyante mriyante'virataṃ yathā
]

`v 6 [
vānti vātā vahantyāpo bhānti cābhānti khe surāḥ |
tiṣṭhantyagāḥ samudyanti grahā yānti mahīṃ nṛpāḥ
]

`v 7 [
devāsuramanuṣyāṇāṃ vyavahāraparamparāḥ |
lolāḥ pravṛttā ākalpamāsamudramivāpagāḥ
]

`v 8 [
dinapadmāni bhūlokasarasyākalpamānabhaḥ |
lolābhrālīni phullāni mīlitonmīlitānyalam
]

`v 9 [
candracarcāścaturdikkaṃ candanenātmatejasā |
racayanrātrirohiṇyostamo hantyapi hṛdgatam
]

`v 10 [
svadaśāsvādanaratā vātayantrasucāritā |
rodaḥsadmani sūryākhyā dīpyate divi dīpikā
]

`v 11 [
brahmasaṃkalpito ruddho vātasaṃcāracāribhiḥ |
khe'niśaṃ cakramṛkṣāṇāṃ guṇāvarto vivartate
]

`v 12 [
bhūtataṇḍulamāsṛṣṭeḥ pinaṣṭi dhruvakīlakaḥ |
niyatyācalito rodaḥkapāṭāmbhodaghargharaḥ
]

`v 13 [
dvīpābdhiśailairbhūpīṭhaṃ vimānanagarairnabhaḥ |
daityadānavanāgaughaiḥ pūrṇaṃ pātālamaṇḍalam
]

`v 14 [
kuṇḍalaṃ trijagallakṣmyā nīlaṃ bhūtalamaṇḍalam |
sthitaṃ cañcalamācāracañcalāyāḥ sphuranmaṇi
]

`v 15 [
buddhyādirahitāṃ spandasaṃvidaṃ vāyavīmiva |
sthāvaraṃ jaṃgamaṃ caiva sūkṣmamādāya jāyate
]

`v 16 [
munirmaunairdharā vārbhirmārutaiḥ kapicāpalam |
ākāśairavakāśitvaṃ tejobhirbhāsanaṃ śritam
]

`v 17 [
vṛkṣorvyabdhyadrikhacarāḥ prāṇinontaḥ sphurantyalam |
mṛtijanmonmukhāḥ kīṭasurāsurajalaukasaḥ
]

`v 18 [
sasurāsuragandharvāḥ kālaḥ kalayati prajāḥ |
dorbhiḥ kalpayugābdaiśca svapaśūniva pālakaḥ
]

`v 19 [
anantavipulāgādhagambhīre kālasāgare |
utpattyotpattya līyante te tvāvartavivartayā
]

`v 20 [
caturdaśavidhā vātavellitā bhūtapāṃsavaḥ |
nāśākāśe vilīyante śaradambhodalīlayā
]

`v 21 [
bhuvanaṃ bodhayantī dyauścandrārkakaracāmaraiḥ |
sthitākāśāṃśukākalpatārakotkaraśekharā
]

`v 22 [
sthitāḥ pavanabhūkampameghatāpasahiṣṇavaḥ |
svaṃ pradeśamanujjhantyaḥ kakubhaḥ stambhitā iva
]

`v 23 [
utpātameghanirhrādabhūmikampagrahagrahaiḥ |
ajñātairapi vijñātairbhūtānāṃ jāyate gatiḥ
]

`v 24 [
saptānāṃ jalamabdhīnāmaurvāgniḥ pibati jvalan |
lokāntarāṇāmākalpaṃ kālo bhūtagaṇaṃ yathā
]

`v 25 [
pātālamāviśati yāti nabhobilaṃ ca diṅmaṇḍalaṃ bhramati bhūtagaṇaḥ samantāt |
paryeti parvatamahārṇavamaṇḍalani dvīpāntarāṇi ca marutsaraṇakrameṇa
]