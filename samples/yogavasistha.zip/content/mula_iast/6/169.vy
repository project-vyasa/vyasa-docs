`v 1 [
ekonasaptatyadhikaśatatamaḥ sargaḥ 169
śrīvasiṣṭha uvāca |
na sukhāya sukhaṃ yasya duḥkhaṃ duḥkhāya yasya no |
antarmukhamaternityaṃ sa mukta iti kathyate
]

`v 2 [
yasya na sphurati prajñā cidvyomanyacalasthiteḥ |
prasṛteṣviva bhogeṣu sa mukta iti kathyate
]

`v 3 [
cinmātrātmani viśrāntaṃ yasya cittamacañcalam |
tatraiva ratimāyātaṃ sa jīvanmukta ucyate
]

`v 4 [
paramātmani viśrāntaṃ yasya vyāvṛttya no manaḥ |
ramate'sminpunardṛśye sa jīvanmukta ucyate
]

`v 5 [
śrīrāma uvāca |
na sukhāya sukhaṃ yasya duḥkhaṃ duḥkhāya yasya no |
jaḍameva mune manye mānavaṃ tamacetanam
]

`v 6 [
śrīvasiṣṭha uvāca |
cidvyomaikāntaniṣṭhatvātprayatnena vinā sukham |
na vetti śuddhabodhātmā yaḥ sa viśrānta ucyate
]

`v 7 [
sarva eva parikṣīṇāḥ saṃdehā yasya vastutaḥ |
sarvārtheṣu vivekena sa viśrāntaḥ pare pade
]

`v 8 [
yasya kasmiṃścidapyarthe kvacidrasikatāsti no |
vyavahāravato'pyantaḥ sa viśrānta udāhṛtaḥ
]

`v 9 [
yasya sarve samārambhāḥ kāmasaṃkalpavarjitāḥ |
yathāprāptaṃ viharataḥ sa viśrānta iti smṛtaḥ
]

`v 10 [
aviśrāme nirālambe dīrghe saṃsāravartmani |
cittvādātmani viśrāntiḥ prāptā yena jayatyasau
]

`v 11 [
dhāvitvā ye ciraṃ kālaṃ prāptaviśrāntayaḥ sthitāḥ |
te suptā iva lakṣyante vyavahāraparā api
]

`v 12 [
te hi cetyacidābhāsanabhasyābhānti bhāmayāḥ |
bhāskarā uditā nityaṃ neha tiṣṭhanti te kvacit
]

`v 13 [
sadehā vyavahārasthā api suptā ivottamāḥ |
prakṣīṇā iva lakṣyante jaḍābhā na tu te jaḍāḥ
]

`v 14 [
suptā iveha śayyāsu ye svapnanagare sthitāḥ |
suptā iti ta ucyante na tu te jaḍatāṃ gatāḥ
]

`v 15 [
dīrghādhvapariviśrānto viśrānto na dadāti yaḥ |
vākyaṃ sa sukhamaunasthaḥ procyate na jaḍākṛtiḥ
]

`v 16 [
yā niśā sarvabhūtānāmavidyāstamayātmikā |
paro bodhaḥ parā śāntistatrāsau samamāsthitaḥ
]

`v 17 [
yasmiñjāgrati bhūtāni dṛśye'sminduḥkhadāyini |
tatrāsau satataṃ suptastanna paśyatyasau sukhī
]

`v 18 [
yaḥ karmaughamanādṛtya svātmanyevāvatiṣṭhate |
sa ātmārāma ityukto na jaḍo'sau raghūdvaha
]

`v 19 [
duḥkhādatigataḥ so'smātprāptaḥ pāraṃ bhavāmbudheḥ |
tiṣṭhatyanubhavanbhavyo viśrāntisukhamātmani
]

`v 20 [
dīrghādhvani pariśrānto viṣayaiścaturaiściram |
bhogabhāvāturaḥ krūraiḥ protthitaḥ pathi ḍāmaraiḥ
]

`v 21 [
jarātuṣārāśanibhirbhūyobhūyo jaḍīkṛtaḥ |
janmajaṅgalasāraṅgo vyarthavyagravihāravān
]

`v 22 [
paramātmaparikrānto duḥkhakaṇṭakasaṃkaṭe |
suduṣprāpasukhacchāye pānthaḥ saṃsāravartmani
]

`v 23 [
duṣkṛtaiḥ kṛtapātheyo luṭhankṣīṇaḥ pade pade |
arthānarthamayairmārgaiḥ saṃkaṭairvivaśīkṛtaḥ
]

`v 24 [
saṃsārajaladheḥ pāraṃ prāpya bhūtavivarjitam |
aśayyo'tipramābuddhaḥ sa śete sukhamātmavān
]

`v 25 [
apasarpaṃ nirastehamasvapnamasuṣuptakam |
prabuddhamabahirnidraṃ hā śete sukhamātmavān
]

`v 26 [
śayanārthibhiḥ sarpyante apasṛpyante iti sarpāṇi gṛhāpavarakaprāsādaparyaṅkādīni
tadrahitaṃ yathā syāttathā nirastehaṃ prāṇādiceṣṭārahitaṃ yathā syāttathā
prabuddhamātmasvarūpe jāgarūkatā yathā syāttathā
svarūpabahirbhūtanidrākhyavastvantararahitaṃ ca yathā syāttathā śete | hā ityāścarye |
25 |
jātyaśvavadihājātiraśnangacchanśvasanvadan |
lokamadhye mahāraṇye hā śete sukhamātmavān
]

`v 27 [
apūrvaiva ghanā nidrā kāpi sā tattvadarśinām |
yā na śāmyati kalpābhraravairnāṅgavikartanaiḥ
]

`v 28 [
apūrvaiva ghanā nidrā kāpi sā tattvadarśinām |
prabuddhānāmapi hi yā nimīlayati dṛgdṛśau
]

`v 29 [
animīlitanetrasya yasya viśvaṃ pralīyate |
sa kṣīvaḥ paramārthena hā śete sukhamātmavān
]

`v 30 [
vinigīrya jagatsarvaṃ paramāṃ pūrṇatāṃ gataḥ |
ātṛpteramṛtaṃ pītvā hā śete sukhamātmavān
]

`v 31 [
nirānandamahānandī sukhamadvaitamakṣayam |
nirālokamahāloko hā śete sukhamātmavān
]

`v 32 [
lobhāndhakāroparamo lokalampaṭatāṃ gataḥ |
aghanatvaghanābhogo hā śete sukhamātmavān
]

`v 33 [
anantaduḥkhamāśāntamaśāntaṃ janatāsthitau |
abahirmukhamābhogi hā śete sukhamātmavān
]

`v 34 [
aṇīyasāmaṇīyāṃsaṃ sthaviṣṭhaṃ ca sthavīyasām |
kṛtvātmānaṃ nabhaḥśayyaṃ hā śete sukhamātmavān
]

`v 35 [
paramāṇau paramāṇau jagatkoṭiśatānyapi |
aṇau sthūle dadhaddehe hā śete sukhamātmavān
]

`v 36 [
kurvansaṃhārasargaughānakurvaṃśca kathaṃcana |
paramālokaśayyāyāṃ hā śete sukhamātmavān
]

`v 37 [
saṃsāranicayasvapnaṃ parijñāya suṣuptatām |
nayanprakaṭadigdīrghāṃ hā śete sukhamātmavān
]

`v 38 [
sarveṣāṃ jagadarthānāṃ sattāsāmānyatāṃ gataḥ |
ākāśādadhiko vyāpī hā śete sukhamātmavān
]

`v 39 [
acchācchamambaraṃ kṛtvā jagadapyambarīkṛtam |
śāntaśabdaparaśvāsaṃ hā śete sukhamātmavān
]

`v 40 [
idamasmajjagatpaśyansvayamākāśakoṇake |
viśadākāśakośātmā hā śete sukhamātmavān
]

`v 41 [
yathā pravāhasaṃprāptavyavahāramanorame |
tṛṇyāstaraṇaviśrānto hā śete sukhamātmavān
]

`v 42 [
parameṇa svayatnena parijñānātsvarūpiṇā |
svapnasaṃdarśanenaiva jīvam khamiva khena khe
]

`v 43 [
jñānenākāśakalpena dharmān gaganasaṃnibhān |
jñena yatnena saṃbuddhaḥ paramāmbaratāṃ gataḥ
]

`v 44 [
prabuddhaḥ suptaḥ supto'pi prabuddho ramate'niśam |
suṣuptobhūttato jāgratsvapnārthasuhṛdā saha
]

`v 45 [
janmāntaraikasahavāsasamāśayena citrānuvṛttimadhureṇa ciraṃtanena |
mitreṇa sārdhamakhilāni dināni nītvā viśrāntimeṣyati pade parame ciraṃ saḥ
]