`v 1 [
saptaṣaṣṭyadhikaśatatamaḥ sargaḥ 167
śrīvasiṣṭha uvāca |
ātmakhyātirasatkhyātiḥ khyātirakhyātiranyathā |
śabdārthadṛṣṭayastajjñaṃ pratyetāḥ śaśaśṛṅgavat
]

`v 2 [
kadācanāpi nāmāṅga saṃbhavanti na kāścana |
śāntamavyapadeśyātmā jña āste'staṅgateṅganaḥ
]

`v 3 [
etā udyanti cinmātrādātmakhyātyādikā dṛśaḥ |
tacca śuddhataraṃ vyoma tanmayyeva ca dṛśyate
]

`v 4 [
ayamātmā tviyaṃ khyātirityantaḥkalanābhramaḥ |
na saṃbhavatyataścainaṃ śabdaṃ tyaktvā bhavārthabhāk
]

`v 5 [
gacchaṃstiṣṭhannadadapi sarvaṃ śāntamato jagat |
ākāśamaunamevācchamacchinnaṃ vā'pravṛttimat
]

`v 6 [
nānāmahāśabdamapi śilāmaunamavasthitam |
anārataṃ gacchadapi vyomavacchailavatsthitam
]

`v 7 [
nānāvidhārambhamapi mahāśūnyamanaṅkitam |
pañcabhūtātmakamapi khamivālabdhapañcakam
]

`v 8 [
padārthasaṃkulamapi śūnyaṃ saṃvittimātrakam |
svapne mahāpuramiva dṛṣṭamapyacchacinmayam
]

`v 9 [
sārambhamapyanārambhaṃ saṃkalpanagaraṃ yathā |
ākāśamātraṃ bhrāntyātma svapnastrīsaṃgamopamam
]

`v 10 [
anubhūtamapi vyarthaṃ pratibimbāṅganāsamam |
nānānubhavanirmāṇaṃ vastu śūnyaṃ tu vastutaḥ
]

`v 11 [
śrīrāma uvāca |
jāgratsvapnātmakamidaṃ manye smṛtyaiva dṛśyate |
sadrūpabāhyārthakṛtā smṛtireveha kāraṇam
]

`v 12 [
śrīvasiṣṭha uvāca |
yattaccitkācakacyena kākatālīyavadvapuḥ |
vyomātmā''bhāti bhāvānāṃ sattāmātramabhittimat
]

`v 13 [
tadetadavināśātma sarvatra paramātmani |
sarvadā vidyate śānte payasīva taraṅgakāḥ
]

`v 14 [
nirnimittaṃ svarūpātma tadetatparamātmani |
sarvātmanyapi nirvāṇe vyomātmani nirātmani
]

`v 15 [
yadā yadāvabhātyantaryena tena yathā tathā |
sarvadā na kadācidvā yatra tatra na kiṃcana
]

`v 16 [
tasyaiva brahmabhānasya tenaivaṃ brahmaṇātmanā |
svacchasyaiva svabhāvasya svasvabhāvamanujjhatā
]

`v 17 [
tarhi asyeyaṃ bhrāntiḥ kena jagadādināmāni kṛtāni tatrāha - tasyaiveti dvābhyām |
16 |
idaṃ jāgradayaṃ svapnaḥ suṣuptaṃ turyamityapi |
kṛtaṃ nāma svayaṃ cittvādbrahma vātmeti cātmani
]

`v 18 [
vastutastvastina svapno na jāgranna suṣuptatā |
na turyaṃ na tato'tītaṃsarvaṃ śāntaṃ paraṃ nabhaḥ
]

`v 19 [
athavā sarvamevedaṃ jāgradrūpaṃ sadaiva ca |
sarvadaiva ca vā svapnaḥ suṣuptaṃ sarvadaiva ca
]

`v 20 [
sarvadaiva ca vā turyaṃ tadantaḥ sarvadaiva vā |
tadidaṃ vā na yadvidmo vayamāśāntarūpiṇaḥ
]

`v 21 [
idaṃ pheno na kiṃcidvā badbudo vā na kaścana |
śūnyatāmbhasi cidvyoma mahārṇavamahodare
]

`v 22 [
yathā saṃvedyate yadyattathā tadanubhūyate |
sadvāsadvā bhavatsvapne vyomnīva sadasacca tat
]

`v 23 [
saṃvitkacanamevedaṃ yathā bhānaṃ vibhāsate |
vyoma vyomani cidrūpaṃ cidrūpe vitatātmani
]

`v 24 [
saṃvicca cinnabhomajjā saivaṃrūpaiva sarvadā |
nāstameti na codeti tasyāḥ svāṅgamidaṃ jagat
]

`v 25 [
mahāpralayasargādyā mahāpralayarātrayaḥ |
tasyā evāvayavatāṃ yātāḥ keśanakhādivat
]

`v 26 [
tasyā bhānamabhānaṃ tadbhāsvaraṃ jihmameva vā |
nānyatsvabhāvavatspanda iva vāyormahāciteḥ
]

`v 27 [
tasmātkiṃ nāma jāgratsyātkaḥ svapnaḥ kā suṣuptatā |
kiṃ turyaṃ kā smṛtiḥ kecchā tucchā etāḥ kudṛṣṭayaḥ
]

`v 28 [
antaḥsaṃvedanaṃ bhāti svaṃ bāhyārthatayā yataḥ |
kva dvaitaṃ kva ca vārthaśrīḥ smṛtirevamataḥ kutaḥ
]

`v 29 [
tadidaṃ bhāti nirbhitti tatsvabhānaṃ yadātmanā |
bhānornabhasi bhārūpameva bhūtavivarjitam
]

`v 30 [
sadrūpo yadi bāhyo'rtho vidyate tattadutthitā |
smṛtiḥ kāraṇatāmetu nāmādyajagataḥ sthiteḥ
]

`v 31 [
kiṃtu nāstyeṣa bāhyo'rtho bhūtānāmatyasaṃbhavāt |
pañcānāmādisargādau kāraṇānāmabhāvataḥ
]

`v 32 [
śaśaśṛṅgaṃ yathā nāsti yathā nāsti khapādapaḥ |
yathā vandhyāsuto nāsti yathā nāstyasitaḥ śaśī
]

`v 33 [
tathā'jñapratibhāto'rtho jagadādyahamādikaḥ |
aprekṣito'sti nāstyeva prekṣitaḥ sanna kaścana
]

`v 34 [
yathāstīdaṃ mahākāraṃ na kiṃcidrūpameva vā |
tattvajñaviṣayaṃ rāma tathāstīdamakhaṇḍitam
]

`v 35 [
saṃvidghananabhomajjā yathodeti yadā yadā |
nityoditopacāreṇa kalpitāstamayodayā
]

`v 36 [
mudhā vyomnyeva pṛthvyāditayā vetti tadā tadā |
svasyaiva tasya bhānasya dhatte pṛthvyādikalpanām
]

`v 37 [
svameva bhānamākāśamātrameva mahācitiḥ |
pṛthvyādivyapadeśena paścādvyapadiśatyajā
]

`v 38 [
ākāśa eva pṛthvīyamiti dhatte svasaṃvidam |
manorājyapuraṃ bāla iva cinmātramavyayam
]

`v 39 [
kiṃ bhānaṃ kimabhānaṃ syāttasyeti na vikalpyate |
spandāspandasvabhāvaṃ tadviddhi vātamivāmbare
]

`v 40 [
yathā bhāti cidākāśaṃ tathedamavabhāsate |
vyoma vyomnyeva nīrūpaṃ nedaṃ pṛthvyādi satkvacit
]

`v 41 [
yathā bhāti cidākāśarūpatvādbhātamapyalam |
na sannāsaditi kiṃcittanna kiṃcinna kiṃcana
]

`v 42 [
idamitthamanitthaṃ ca sadvā'sadvā yathāsthitam |
lokaparyāyavṛttāntaṃ prājño jānāti netaraḥ
]

`v 43 [
sa eva hṛdayākāśe kacantyā dṛśyasaṃvidā |
bāhyaṃ brahmāṇḍamitthaṃ ca sadvā'sadvā yathāsthitam
]

`v 44 [
kimatra bāhyaṃ kiṃ vāntaḥ kiṃ dṛśyaṃ kāsya dṛśyatā |
śivaṃ śāntamaśāntaṃ ca sarvamomiti śāmyatām
]

`v 46 [
no vācyavācakadṛśā rahito vicāraḥ saṃpadyate sa ca vikalpamayena siddhyai |
siddhiśca saṃbhavati tena vinā na kāciddīpaṃ vinā niśi yathā nayanopalambhaḥ |
45 |
yāvadvicāraṃ tvasadapi vācyavācakavikalpaṃ yathālokamabhyupagamyaiva
śravaṇādividhayaḥ pravartanta ityāśayenāha - no iti | vācyavācakadṛśā rahitaḥ
śāstrārthavicāro no saṃpadyate | sa ca vicāro vikalpamayena viṣayo viśayaścaiva
pūrvapakṣastathottaram | prayojanaṃ ca pañcāṅgaṃ śāstre'dhikaraṇaṃ viduḥ | iti
prasiddhena pañcāṅgena kṛtaḥ siddhyai bhavati | tena vicāreṇa vinā siddhirna
saṃbhavatyeva | yathā dīpaṃ vinā cākṣuṣapratyakṣaṃ niśi na bhavati tadvadityarthaḥ | 45
|
tasmādapāsya parayā'malayā dhiyāntaḥsaṃkalpakalpanamanalpavikalpajālam |
kṛtvā manaḥ sakalaśāstramahārthaniṣṭhamuḍḍīya gaccha
padamuttamamekaniṣṭhaḥ
]