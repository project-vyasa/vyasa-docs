`v 1 [
aṣṭāviṃśaḥ sargaḥ 28
śrīrāma uvāca |
bījāṅkurāṇāṃ puruṣakarmaṇāṃ janmakāriṇām |
daivaśabdārthayuktānāṃ tattvaṃ vada vibho punaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
daivakarmādiparyāyaṃn ghaṭādi ghaṭatāvadhi |
saṃvitspandanamevedaṃ loke puruṣatāṃ gatam
]

`v 3 [
saṃvitspandādṛte puṃstvaṃ karma vā kīdṛśaṃ bhavet |
ghaṭāvaṭapaṭādyātma hyetenaiva jagat kṛtam
]

`v 4 [
pravartate jagallakṣmīḥ saṃvitspandātsavāsanāt |
nivartate hi saṃsāraḥ saṃvitspandādavāsanāt
]

`v 5 [
avāsanaṃ hi saṃvitteḥ spandamaspandanaṃ viduḥ |
saspando'pyasphuratspando yenāvartādinohyate
]

`v 6 [
manāgapi na bhedo'sti saṃvitspandamayātmanoḥ |
kalpanāṃśādṛte rāma sṛṣṭau puruṣakarmaṇoḥ
]

`v 7 [
jalavīcyoryathā dvitvaṃ saṃkalpotthaṃ na vāstavam |
tatheha citparispandarūpayorjantukarmaṇoḥ
]

`v 8 [
karmaiva puruṣo rāma puruṣasyaiva karmatā |
ete hyabhinne viddhi tvaṃ yathā tuhinaśītate
]

`v 9 [
himaṃ yattadyathā śaityaṃ yacchaityaṃn tadyathā himam |
yatkarmāsau tathā janturyo jantuḥ karma tattathā
]

`v 10 [
saṃvitspandarasasyaiva daivakarmanarādayaḥ |
paryāyaśabdā `note[śabdāstu iti pāṭhaḥ |] na punaḥ pṛthakkarmādayaḥ
sthitāḥ
]

`v 11 [
spandātsaṃvijjagadbījamaspandādyātyabījatām |
aṅkuraśca tadevāntaḥ sthitatvādaṅkuraśriyaḥ
]

`v 12 [
cittvaṃ ca kvacidaspandaṃ kvacitspandaṃ svabhāvataḥ |
anantamekārṇavavaddikkālakramasaṃsthitam
]

`v 13 [
saṃvitspando vāsanāvāniha bījamakāraṇam |
bhūtvā kāraṇatāmeti dehāderaṅkurāvaleḥ
]

`v 14 [
tṛṇavallīlatāgulmabījāntaragaterapi |
bījaṃn saṃvitspanda eva tasya bījaṃ na vidyate
]

`v 15 [
na bījāṅkurayorbhedo vidyate'gnyauṣṇyayoriva |
bījamevāṅkuraṃ viddhi viddhi karmaiva mānavam
]

`v 16 [
citsphurantī bhūmikośe karoti sthāvarāṅkuram |
sthūlānsūkṣmānmṛdukrūrānpayobudbudakāniva
]

`v 17 [
citā vinā dharākośādatyantaparipelavāt |
aṅkurānvajrasārāṃśca `note[aṅkurāt iti pāṭhaḥ sādhuḥ |] ka ullāsayituṃ
kṣamaḥ
]

`v 18 [
vajrasārāniti | dṛḍhānpravālādīnmṛdutarādaṅkurāt ka ullāsayituṃ niḥsārayitum |
17 |
prāṇivīryarasāntasthā saṃvijjaṃgamamātatam |
tanoti latikāntastho rasaḥ puṣpaphalaṃ yathā
]

`v 19 [
yadi sarvagatā saṃvidbhavennātibalīyasī |
tatka ullāsane śaktaḥ syāddevāsurabhūbhṛtām
]

`v 20 [
jaṅgamānāṃ sthāvarāṇāmetadādyaṃ ca bījakam |
saṃvidvisphuraṇāmātramasya bījaṃ na vidyate
]

`v 21 [
bījāṅkuravikalpānāṃ kriyāpuruṣakarmaṇām |
ūrmivīcitaraṅgāṇāṃ nāsti bhedo na vastuni
]

`v 22 [
dvitvaṃ nṛkarmaṇoryasya bījāṅkuratayā tayoḥ |
vipaścitpaśave tasmai mahate'stu sadā namaḥ
]

`v 23 [
saṃvitterjanmabījasya yo'ntastho vāsanārasaḥ |
sa karotyaṅkurollāsaṃ tamasaṅgāgninā daha
]

`v 24 [
kurvato'kurvataścaiva manasā yadamajjanam |
śubhāśubheṣu kāryeṣu tadasaṅgaṃ vidurbudhāḥ
]

`v 25 [
athavā vāsanotsāda evāsaṅga iti smṛtaḥ |
yayā kayācidyuktyāntaḥ saṃpādaya tameva hi
]

`v 26 [
yayaiva vetsi tatayā yuktyā puruṣayatnataḥ |
vāsanāṅkuranirmūlametadeva paraṃ śivam
]

`v 27 [
pauruṣeṇa prayatnena yathā jānāsi vā tathā |
nivārayāhaṃbhāvāṃśameṣo'sau vāsanākṣayaḥ
]

`v 28 [
nāstyeva pauruṣādanyā saṃsārottaraṇe gatiḥ |
nirahaṃbhāvarūpe'sminvāsanākṣayanāmani
]

`v 29 [
ādyaiva saṃvidastīha so'ṅkuro bījamasti tat |
tatkarma tacca puruṣastaddaivaṃ tacchubhāśubham
]

`v 30 [
na bījamādāvastyanyannāṅkuro na ca vā naraḥ |
na karma na ca daivādi kevalaṃ cidudeti hi
]

`v 31 [
no bījamasti na kilāṅkurako'pi vāsti nāpyasti karma puruṣaśca na vāsti sādho |
ekaṃ tu cittvamuditaṃ hyanayābhidhānalakṣmyā naṭaḥ suranarāsuraśobhayeva | 31
|
bījādeḥ svataḥ sattāśūnyatve ekaścidātmaivānṛtairbījādiveṣairjagadbhūtvā nṛtyatīti
phalitamityāha - no bījamiti | cittvaṃ citsvarūpam | abhidhānagrahaṇaṃn
vācārambhaṇaśrutismāraṇārtham
]

`v 32 [
ityeva niścayamanāmaya bhāvayitvā tyaktvā bhṛśaṃ
puruṣakarmavicāraśaṅkām |
nirvāsanaḥ sakalasaṃkalanāvimuktaḥ saṃvidvapurnanu yathābhimatecchamāsva |
32 |
nanu he anāmaya rāma tvaṃ iti evaṃrūpameva niścayasaṃdigdhaṃ bhāvayitvā
puruṣakarmādyanṛtavicāraśaṅkāṃ tyaktvā nirvāsanaḥ san yathābhimatecchaṃ
samāhito vyavaharanvā āsvetyarthaḥ
]

`v 33 [
praśāntasarvecchamaśaṅkamacchacinmātrasaṃstho'khilakāryakārī |
ātmaikarāmaḥ paripūrṇakāmo bhavābhayo rāma śamābhirāmaḥ
]