`v 1 [
pañcadaśādhikadviśatatamaḥ sargaḥ 215
śrīvālmīkiruvāca |
bharadvāja mahābuddhe mama śiṣyādhināyaka |
iti rāmādayo jñātajñeyā niḥśokatāṃ gatāḥ
]

`v 2 [
etāmeva dṛśaṃ kāntāmavaṣṭabhya yathāsukham |
nīrāgastiṣṭha niḥśaṅko jīvanmuktaḥ praśāntadhīḥ
]

`v 3 [
dhīranabhyastasaṅgā hi rāmādīnāmivānagha |
ghanamohanimagnāpi vimūḍhāpi na muhyati
]

`v 4 [
evamete mahāsattvā jīvanmuktapadaṃ gatāḥ |
rājaputrā rāghavādyā rājā daśarathādayaḥ
]

`v 5 [
tvaṃ ca putra bharadvāja svayamevāsi muktadhīḥ |
satyaṃ muktataro'syadya śrutvemāṃ mokṣasaṃhitām
]

`v 6 [
mokṣopāyānimānpuṇyānpratyakṣānubhavārthadān |
bālopyākarṇya tajjñatvaṃ yāti kā tvādṛśe kathā
]

`v 7 [
yathā padaṃ puṇyamanuprayātā mahānubhāvā rāghavo viśokāḥ |
vasiṣṭhavākyaprasareṇa sādhogantavyamādyaṃ padamevameva
]

`v 8 [
satāṃ nayenottamasevayā ca praśnena codārakathāgatena |
vindanti vedyaṃ sudhiyo'pramattā vasiṣṭhasaṅgādiva rāghavādyāḥ
]

`v 9 [
tṛṣṇāvaratrādṛḍhabandhabaddhā ye granthayo'jñasya hṛdi prarūḍhāḥ |
sarve hi te mokṣakathāvicārādbālā hyabālā iva yāntyabhedam
]

`v 10 [
mokṣābhyupāyānsumahānubhāvān jñāsyanti ye tattvavidāṃ variṣṭhāḥ |
punaḥ sameṣyanti na saṃsṛtiṃ te ko'rthaḥ sutā'nyena bahūditena
]

`v 11 [
bahuśrutā ye pravicārya samyakprabodhitārthe kathayā janāya |
santo vadiṣyanti punaḥ śiśutvaṃ na te prayāsyanti kimanyavākyaiḥ
]

`v 12 [
ye vācayiṣyantyanapekṣitārthā ye lekhayiṣyanti ca pustakaṃ vā |
ye kārayiṣyantyapi vācakaṃ vā vyākhyātṛyuktaṃ śubhamāryadeśe
]

`v 13 [
te rājasūyasya phalena yuktā muhurmuhuḥ svargamudārasattvāḥ |
mokṣaṃ prayāsyanti tṛtīyajanmalābhena lakṣmīmiva puṇyavantaḥ
]

`v 14 [
imāṃ purā mokṣamayīṃ vicārya susaṃhitāṃ sadvacanādviriñcaḥ |
prayuktavānetadacintyarūpo bhavantyasatyāśca na tasya `note[satyavāca iti
pāṭhaṣṭīkānuguṇaḥ sa eva sādhuḥ |] vācaḥ
]

`v 15 [
mokṣābhyupāyākhyakathāprabandhe yāte samāptiṃ sudhiyā prayatnāt |
suveśma dattvābhimatānnapānadānena viprāḥ paripūjanīyāḥ
]

`v 16 [
deyaṃ ca tebhyaḥ khalu dakṣiṇādi cittepsitaṃ svasya dhanasya śaktyā |
matvānurūpaṃ kṛtameva saṅgapuṇyaṃ yathāśāstramupaityasau tat
]

`v 17 [
etatte kathitaṃ kathākramaśatairvodhāya buddhairbṛhacchāstraṃ
bṛṃhitabrahmatattvamamalaṃ dṛṣṭāntayuktyāñcitam |
śrutvaitacciranirvṛtiṃ bhaja bhṛśaṃ jīvadvimuktāśayo lakṣmīṃ
jñānatapaḥkriyākramayutāṃ bhuktvā'kṣayāmakṣayaḥ
]