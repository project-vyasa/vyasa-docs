`v 1 [
dvātriṃśaḥ sargaḥ 32
śrīvasiṣṭha uvāca |
yadā citiḥ prasarati tadāhaṃtājagadbhramaḥ |
asadevābhyudetīva spandādapi ca vāyutā
]

`v 2 [
udito'pi na khedāya brahmarūpatvavedanāt |
paramāya tvanarthāya jagacchabdārthabhāvanāt
]

`v 3 [
rūpānubhavamādatte cakṣuḥprasaraṇādyathā |
citiḥ prasaraṇāttadvajjagadvibhramamāsthitā
]

`v 4 [
yāsau prasarati vyarthaṃn cetyābhāvānna sā satī |
asatkathaṃ prasarati vandhyāputraḥ kva nṛtyati
]

`v 5 [
ayaṃn tvanubhavādeva mudhaivānubhavansthitaḥ |
asadevānanubhavansvayamarbhakayakṣavat
]

`v 6 [
ayaṃ citprasaro'nubhavādeva siddhyet | sa cānubhavo vidyayā
bādhyamāno'sadarthamananubhavannevarbhakayakṣānubhavavanmudhaiva sthita ityarthaḥ |
5 |
ahaṃbhāvo'pi duḥkhārthamahamityeva vedanāt |
avedanānnāhamataḥ svāyatte bandhamuktate
]

`v 7 [
taddhyānaṃ sa samādhirvā yadavedanamāsitam |
ajaḍānāṃ jaḍamiva samaṃ śāntamanāmayam
]

`v 8 [
dvaitādvaitasamudbhedairvākyasaṃdarbhavibhramaiḥ |
mā viṣīdata duḥkhāya vibudhā abudhā iva
]

`v 9 [
asadāśrayate duḥkhaṃ svapnavadghanavāsanaḥ |
rūpālokamanaskārānsaṃkalparacitāniva
]

`v 10 [
duḥkhaṃ sadeva nāśnāti suptavattanuvāsanaḥ |
rūpālokamanaskārānsaṃkalparahitāniva
]

`v 11 [
apyarthe evakāraḥ | sat prārabdhaprasaṃjitamapi duḥkhaṃ nāśnāti na bhuṅkte | supto
nidrāsukhaparavaśacitto yathā maśakamatkuṇādidaṃśanaduḥkhaṃ nānubhavati tadvat |
10 |
atyantatanutāmesya vāsanaivaiti muktatām |
deśakālakriyāyogātpadārthe bhāvanāmiva
]

`v 12 [
atyantatanutāṃ yātā vāsanaivaiti muktatām |
parāṇupariṇāmena khatāṃ khe'bhrādikā yathā
]

`v 13 [
ahaṃbhāvanayā bodhe vāsanā ghanatānavā |
vipaścitsaṃgamābhyāsātpāṇḍityamiva mūḍhatā
]

`v 14 [
nāhamastīha madyuktyā niścayo'ntaḥ śamātmakaḥ |
jīvato'jīvataścāsti rūḍhabodha iti smṛtaḥ
]

`v 15 [
kiyatkālaṃ bodho vardhanīya iti cedrūḍhabodhatāparyantamityāśayena
rūḍhabodhalakṣaṇamāhanāhamiti | madyuktyā ahaṃbrahmeti bhāvanālakṣaṇena
pratyagātmayogenābhyasyamāneneha jīvato yogino'jīvataḥ paralokaṃ gatasya vā
ahaṃśabdārtho jīvo nāstīti śamātmako niścayo'ntaryasyāsti sa rūḍhabodha ityarthaḥ | 14
|
vāyau dvandvamivātredaṃ jagadādi ca bhāsate |
ko'haṃ kathamidaṃ ceti vicāreṇaiva śāmyati
]

`v 16 [
nāhamityeva nirvāṇaṃ kimetāvati mūḍhatā |
satsaṃgamavicārābhyāmetadāśvavagamyate
]

`v 17 [
kṣīyate tattvavitsaṅgādahamityeva bandhanam |
ālokeneva timiraṃ divaseneva yāminī
]

`v 18 [
ko'haṃ kathamidaṃ dṛśyaṃ ko jīvaḥ kiṃ ca jīvanam |
iti tattvajñasaṃyogādyāvajjīvaṃ vicārayet
]

`v 19 [
jīvitaṃ bhuvanaṃ bhāti tato'hamiti naśyati |
tattvamekena tajjñārkasevanātsa niṣevyatām
]

`v 20 [
yo yo bodhātiśayavāṃstaṃ taṃ pṛthagupāsva bho |
saṃgame kathayodeti teṣāṃ vādapiśācikā
]

`v 21 [
vādayakṣe'pyabhyudite bālasyeva vipaścitaḥ |
yuktiyuktamalaṃ mukhyamudetyahamiti bhramaḥ
]

`v 22 [
ataḥ pratyekamekānte prājñaḥ seveta paṇḍitam |
ekīkṛtya taduktāṃstānarthānbuddhyā vicārayet
]

`v 23 [
vicārayettaduktyarthaṃn buddhyā buddhivivṛddhaye `note[viśuddhaye iti pāṭhaḥ
sādhuḥ |] |
sarvasaṃkalpamuktaṃ yattatsattanmayatāṃ vrajet
]

`v 24 [
vipaścitsaṃgamairbuddhiṃ nītvā paramatīkṣṇatām |
ajñānalatikā saikā kaṇaśaḥ kriyatāmalam
]

`v 25 [
eṣo'rthaḥ saṃbhavatyeva tenedaṃ kathayāmyaham |
svānubhūtaṃ vayaṃn bālā nāsamañjasavādinaḥ
]

`v 26 [
vyomno'mbuvāhādivijṛmbhayeva taraṅgabhaṅgyeva mahājalasya |
na yujyate nāpi ca naśyatīha nāśodayau nirmananasya kiṃcit
]

`v 27 [
idaṃ hi sarvaṃ mṛgatṛṣṇikāmbuvannirāmaye brahmaṇi śānta ātate |
vicārite nāhamitīha vidyate kutaḥ kva kasmānmananādivibhramaḥ
]