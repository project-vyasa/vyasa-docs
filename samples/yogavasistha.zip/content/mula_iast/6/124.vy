`v 1 [
caturviṃśatyadhikaśatatamaḥ sargaḥ 124
śrīrāma uvāca |
ekasaṃvinmayāḥ sarva evaikavapuṣo'pi te |
vividhecchāḥ kathaṃ brahmansaṃpannā ekadehinaḥ
]

`v 2 [
śrīvasiṣṭha uvāca |
ekasaṃvidghanākāśamapyanānaiva sarvagam |
svayaṃ nāneva saṃpannaṃ supte cittamivātmani
]

`v 3 [
ekasyāpi jīvasyāvidyayā svapne nānādehādikalpanadarśanātteṣu ca
śatrumirtodāsīnabhāvakalpane nānecchatvadarśanācca sargādau brahmaṇi jīve jāgratyapi
tādṛśakarmasattve sarvasaṃbhava ityāśayena vasiṣṭha uttaramāha - ekasaṃviditi |
2 |
tasyācchatvāttathābhūtamātmaivātmani bimbati |
tādṛśasya tathābhūtau mukurasyeva nirmalā
]

`v 4 [
ekalohamayā eva yathādarśāḥ parasparam |
tathaite pratibimbanti padārthāḥ pāramarthikāḥ
]

`v 5 [
tena yasya yadā yadyatpuro bhavati vastvasau |
yadarthaṃ `note[tadarthaṃ iti ṭīkānuguṇaḥ pāṭhaḥ |] yujyate tena
cidghanaikasvabhāvataḥ
]

`v 6 [
ityanānaiva nānedaṃ nānānānā ca vastutaḥ |
na ca nānā ca cānānā nānānānātmakaṃ tataḥ
]

`v 7 [
tena yasya yadāyātaṃ puro vastu vipaścitaḥ |
sa tena saṃvinmayatāmetya tadvaśamāgataḥ
]

`v 8 [
ekadeśagatā viṣvagvyāpya karmāṇi kurvate |
yoginastriṣu kāleṣu sarvāṇyanubhavantyapi
]

`v 9 [
abdo'pi vyāptimānekastulyakālaṃ pṛthakkriyāḥ |
āhlādastena pādena karotyanubhavatyapi
]

`v 10 [
tulyakālamasaṃkhyātamīśvarapratiyoginaḥ |
karmajālaṃ jagajjātaṃ kurvantyanubhavanti ca
]

`v 11 [
eko viṣṇuścaturbhiḥ svairbāhubhirvā śarīrakaiḥ |
pṛthakkurvankriyāḥ pāti jagadbhuṅkte varāṅganāḥ
]

`v 12 [
bahubāhuryadā dvābhyāṃ hastābhyāṃ dvyarthasaṃgraham |
karoti bahubhirbhūyaḥ saṃgrāmaṃ satataṃ karaiḥ
]

`v 13 [
tathaiva tairvipaścidbhiḥ sarvadikkaṃ tathā sthitaiḥ |
tathā vyavahṛtaṃ prāptamekasaṃvinmayairapi
]

`v 14 [
dṛṣṭāntānprakṛte yojayati - tathaiveti | prāptaṃ sukhaduḥkhādikamiti śeṣaḥ | 13
|
suptaṃ tairbhūmiśayyāsu bhuktaṃ dvīpāntareṣu ca |
vihṛtaṃ vanalekhāsu prakrāntaṃ marubhūmiṣu
]

`v 15 [
uṣitaṃ girimālāsu bhrāntaṃ sāgarakukṣiṣu |
viśrāntaṃ dvīpalekhāsu nilīnaṃ ghanamāliṣu
]

`v 16 [
rūḍhamarṇavamālāsu vātyāsu jalavīciṣu |
krīḍitaṃ bhūbhṛdabdhīnāṃ taṭīṣu nagarīṣu ca
]

`v 17 [
śākadvīpodayagiritaṭe saptavarṣāṇi suptaṃ pūrveṇāntarvidalagahane
yakṣasaṃmohitena |
pāṣāṇāmbu prasabhamamunaivātra pītvā dṛṣattāmāgatyāntaḥ sthitamatha
samāḥ sapta jātyena bhūmeḥ
]

`v 18 [
śākadvīpe'staśailasya śirasyabhraguhāgṛhe |
piśācāpsarasā māsaṃ pāścātyaḥ kāmukīkṛtaḥ
]

`v 19 [
yatra śāntabhaye varṣe jaladhāre mahāgirau |
harītakīvane varṣaṃ pūrvo'ntardhānamāyayau
]

`v 20 [
atra raivatake śaile varṣe śiśiranāmani |
daśarātramabhūtsiṃhaḥ pūrvo yakṣavaśīkṛtaḥ
]

`v 21 [
atra kāñcanaśailādidarīdarduratāṃ gataḥ |
piśācamāyāchalito daśavarṣāṇyuvāsa saḥ
]

`v 22 [
kaumāraṃ varṣamāsādya śyāmādreruttarastaṭam |
śākadvīpe'ndhakūpe'ndho nyavasaccharadāṃ śatam
]

`v 23 [
marībake'karodvarṣe varṣāṇyatra caturdaśa |
vidyādharatvaṃ pāścātyaḥ sa vidyādharavidyayā
]

`v 24 [
rataklamaklāntapurārilakṣmīcalāṅgalekhākramaśīkarāktam |
elālatāliṅganalabdhagandhamālambya velāvanagandhavāham
]