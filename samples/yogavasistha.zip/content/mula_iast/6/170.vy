`v 1 [
saptatyadhikaśatatamaḥ sargaḥ 170
śrīrāma uvāca |
brahmanko'sya suhṛdbrūhi yenāsau ramate saha |
ramaṇaṃ kiṃsvabhāvaṃ syāduta ratyātma vāsya tat
]

`v 2 [
śrīvasiṣṭha uvāca |
svapravāhehitaṃ nāma svaprāyehitanāma ca |
svakarma nāma cāsyāste mitramekamakṛtrimam
]

`v 3 [
pitṛvadvihitāśvāsaṃ dārā iva niyantraṇam |
saṃkaṭeṣu duranteṣu nityamavyabhicāri ca
]

`v 4 [
aśaṅkitopacaraṇaṃ susaṃpāditanirvṛti |
kopeṣvakopanatayā vitīrṇāvarjanāmṛtam
]

`v 5 [
durgadurgamadurvāradoṣoddharaṇatatparam |
sarvaviśvāsaratnānāṃ kośa āśaiśavoṣitam
]

`v 6 [
sahapāṃsukṛtākrīḍamābālyādeva saṃgatam |
vinivāritaduśceṣṭaṃ pitṛvadrakṣaṇonmukham
]

`v 7 [
vahnerivauṣṇyaṃ saugandhyaṃ kusumasyeva sarvadā |
avinābhāvi vimalaṃ raveriva ca vāsaram
]

`v 8 [
lālanaikarataṃ nityaṃ pālanaikaparāyaṇam |
sarvasaṃkaṭasaṃghaṭṭarakṣaṇaikasamudyatam
]

`v 9 [
hemno'gniriva dehasya sarvāvasthasya śuddhidam |
idaṃ heyamupādeyamiti darśanatatparam
]

`v 10 [
āhlādakamanindyābhiḥ kathābhiriva nāgaram |
sacceṣṭāmaṇimāṇikyabhāṇḍasaṃbhāramandiram
]

`v 11 [
sūryastama ivājasramapradarśayadapriyam |
anuraktā maheleva priyamevāpradarśayat
]

`v 12 [
janaṃ priyaṃvadaṃ kurvatpriyameva samācarat |
peśalaṃ madhuraṃ snigdhamakṣubdhamuditāśayam
]

`v 13 [
lokopacārakaṃ pūjyaṃ smitapūrvābhibhāṣaṇam |
kāmopaśāntaṃ sadrūpaṃ paramārthaikakāraṇam
]

`v 14 [
raṇe'jñānasamudbhūte pūrvaṃ praharaṇodyatam |
apūrvanarmanirmāṇalīlālalanalālakam
]

`v 15 [
pālakaṃ śīlasārāṇāṃ dārāṇāṃ ca kulasya ca |
ādhivyādhiparītasya cetaso'mṛtamauṣadham
]

`v 16 [
viśeṣavidyāvaidagdhyavādavandyavinodanam |
samānakulaśīlatvāddvidhābhāva iva sthitam
]

`v 17 [
anuraktānnṛpānsādhūnvadānyānkārayatsadā |
yajñadānatapastīrthanyāyārthapreraṇonmukham
]

`v 18 [
putradāradvijātistrībhṛtyabandhujanaiḥ saha |
śubhabhojanapānārhamuttamaślāghyasaṃgati
]

`v 19 [
bhogādibaddhatṛṣṇatvaṃ duḥkhadaṃ vinivārayat |
susnigdhasaṃkathodāraṃ samāśvāsottamāspadam
]

`v 20 [
īdṛśenātmamitreṇa sa kalatreṇa saṃyutaḥ |
svakarmanāmnā ramate svabhāvenaiva neritaḥ
]

`v 21 [
śrīrāma uvāca |
kalatramasya mitrasya tadīyasya munīśvara |
kiṃ tatkiṃrūpameva syātsamāsenaiva me vada
]

`v 22 [
śrīvasiṣṭha uvāca |
snānadānatapodhyānanāmāno'sya mahāmate |
santi putrā mahātmānaḥ svanuraktākhilaprajāḥ
]

`v 23 [
candralekheva lokasya dṛṣṭyaivāhlādadāyinī |
avinābhāvinī bhāryā muditāsyānurāgiṇī
]

`v 24 [
karuṇākāraṇākīrṇadhanā hṛdayahāriṇī |
ānandajananī cāsya vayasyā'vyabhicāriṇī
]

`v 25 [
samatāsya matā nityamāste hṛdayavallabhā |
pratīhārī puraḥ prahvā saṃmukhaṃ sukhadāyinī
]

`v 26 [
dhairye dharme ca dhīḥ sādho nityamādhīyate ca yā |
sāsya dhīrasya dhuryasya puro dhanyasya dhāvati
]

`v 27 [
asya sannā samaṃ skandhe sarvadaiva mahaujasaḥ |
viṣayārijaye rājño maitrī mantrapradāyinī
]

`v 28 [
kāryāṇāmāryamaryādācāryā cāturyaśālinī |
sarveṣāmasya mānyasya satyatā svārthadāyinī
]

`v 29 [
ityevaṃparivāreṇa mitreṇa saha mantriṇā |
svakarmaṇā vyavaharanna hṛṣyati na kupyati
]

`v 30 [
sa yathāsthitamevāste vinirvāṇamanā muniḥ |
citrārpita ivājasraṃ loke vyavaharannapi
]

`v 31 [
vastuśūnyeṣu vādeṣu mūkaḥ śailamayo yathā |
niṣprayojanaśabdeṣu paraṃ bādhiryamāgataḥ
]

`v 32 [
lokācāraviruddheṣu śavaṃ sakalakarmasu |
āryācāravicāreṣu vāsukirvā bṛhaspatiḥ
]

`v 33 [
pravṛttavākpuṇyakatho jihmānāṃ pratibhānavān |
nimeṣeṇaiva nirṇetā vaktāśu bahu vastunaḥ
]

`v 34 [
samadṛṣṭirudārātmā vadānyaḥ saṃvibhāgavān |
peśalasnigdhamadhuraḥ sundaraḥ puṇyakīrtanaḥ
]

`v 35 [
svabhāva eṣaiva bhavetprabuddhadhiyāṃ prayatnena tu nedṛśāste |
bhavanti nendvarkahutāśanādyāḥ kvacitparapreraṇayā prakāśāḥ
]

`v 335 [
eṣa varṇito guṇagaṇaḥ prabuddhadhiyāṃ svabhāva eva bhavet | te prayatnena īdṛśā
īdṛgguṇā na bhavanti | indvarkahutāśanādyāḥ parapreraṇayā prakāśanta iti prakāśā
na bhavanti kiṃtu svabhāvata eva tadvadityarthaḥ
]