`v 1 [
ekādaśādhikaśatatamaḥ sargaḥ 111
śrīvasiṣṭha uvāca |
iti kalpāntasadṛśe yatte samarasaṃbhrame |
patantīṣūtpatantīṣu senāsu samarejire
]

`v 2 [
tūryabherīmahāśaṅkhakhaḍgeṣu khe nadatsu ca |
dhanurdhvaniṣu vīrāṇāṃ tārakreṃkārakāriṣu
]

`v 3 [
anyonyakaṭhināsphoṭavikaṭe bhaṭapeṭake |
kavatkaṭakaṭāṭope kaṭukuṭṭitakaṅkaṭe
]

`v 4 [
kiṃcitprabhajyamānāsu viśatkaśmāsu saṃgare |
vipaścitpakṣasenāsu lūyamānalatāsviva
]

`v 5 [
udabhūtpūrayannāśā nṛpaniryāṇadundubhiḥ |
caturdhāśanisaṃpūrṇakalpābhraravamāṃsalaḥ
]

`v 6 [
sphuṭatāṃ kulaśailānāṃ tulyakālamivotkaṭaḥ |
sphuṭaccaṭacaṭāsphoṭairjaḍitākhiladiktaṭaḥ
]

`v 7 [
lokapālairivākārairnārāyaṇabhujairiva |
sa caturbhiścaturdikkaṃ nirjagāma mahīpatiḥ
]

`v 8 [
caturaṅgeṇa mahatā sainyena parivāritaḥ |
aṭṭālavalayātkṛcchrānnirgatya nagarādbahiḥ
]

`v 9 [
dadarśātmabalaṃ riktaṃ balavadripumaṇḍalam |
garjantaṃ ca layākṛtyā bhīmaṃ yuddhoddhatārṇavam
]

`v 10 [
śarasīkaranīrandhraṃ makaravyūhasaṃkulam |
vāraṇavyūhavalitaṃ taraṅgavyūhavistṛtam
]

`v 11 [
cakrāvartavahadvyūhakallolakalitāntaram |
caladrathaśatāvartaṃ patākālaharīgaṇam
]

`v 12 [
prasphuracchatraphenāḍhyaṃn hayaheṣitaphītkṛtam |
samullasaddhetijalaṃ kacaddhārākaraṃ param
]

`v 13 [
hayānāṃ heṣitameva yādasāṃ phītkāraśabdo yatra | kacantīnāṃ dhārāṇāmākaram | 12
|
tarattaralamātaṅgaturaṅgaughataraṅgakam |
hetyambhasi kacatpāpamudyadgulugulodaram
]

`v 14 [
darīdalanasaṃkṣubdhamarujjanitaghuṃghumam |
natonnatakṛtādrīndramahāspandaśarīrakam
]

`v 15 [
majjanmātaṅgaturagahelāhatamahīdharam |
apāravicaratpūrakallolālamahājalam
]

`v 16 [
akālakalpāntadaśāsamutthānaghanākṛtim |
ākrāntarodasīrandhrarudhiraikamahārṇavam
]

`v 17 [
kacadāyudhakhaṇḍaughaḍīnaratnāvṛtodaram |
caladvyūhacaladvyastayantrāśmakṣepaṇāśmakam
]

`v 18 [
ratnasīkaranīhārasaṃdhyābhrapaṭalānatam |
kvacitpāṃsupayovāhapītahetipayodharam
]

`v 19 [
tamālokya raṇāmbhodhimagastyo'sya bhavāmyaham |
iti saṃcintya mansā sa pātuṃ taṃ praṇārṇavam
]

`v 20 [
astraṃ sasmāra vāyavyaṃ caturdikkaṃ ca saṃdadhe |
dhanuṣi śikharādhāre tripurānta ivodyataḥ
]

`v 21 [
ātmīyadeśasainyānāṃ śreyorthaṃ śāntaye'nalam |
namaskṛtyātha japtvāśu sa tattatyāja dāruṇam
]

`v 22 [
yathā tatraiva tatyāja tasya sāhāyakāya saḥ |
parjanyāstraṃ mahāstreśaṃ dviṣadātapaśāntaye
]

`v 23 [
tasmādastrajuṣo ghorāddhanuṣaḥ parinirgatāḥ |
aṣṭamūrteścaturdikkamāśākuharapūrakāḥ
]

`v 24 [
niryayurbāṇasaritastriśūlasaritastathā |
śaktīnāmugrasarito bhuśuṇḍīsaritastathā
]

`v 25 [
mudgarāṇāṃ ca saritaḥ prāsānāṃ sarito rayāt |
cakrāṇāṃ caiva saritaḥ paraśvadhanadīrayāḥ
]

`v 26 [
tomarāṇāṃ ca sarito bhindipālamahāpagāḥ |
pāṣāṇānāṃ ca sarito vātāḥ kalpāntaśaṃsinaḥ
]

`v 27 [
aśanīnāṃ ca sarito vidyutāṃ saritastathā |
jaladhārāsaritpūrāḥ khaḍgavarṣasamanvitāḥ
]

`v 28 [
sanārācā mahāvarṣaharṣalotpātapīvarāḥ |
nāgāśca yugaparyantasphuṭitādrīndrajā iva
]

`v 29 [
tenāstravarṣavegena dhutaḥ so'ribalārṇavaḥ |
jhaṭityeva na kālena pāṃsurāśirivābhitaḥ
]

`v 30 [
salilāśaniśastrāṇāmāsāraiścaṇḍamārutaiḥ |
sarāṃsīva visetūni sainyāni paridudruvuḥ
]

`v 31 [
caturaṅgaścaturdikkaṃ balaughaḥ sa parāṅmukhaḥ |
yayau prāvṛṅgiriṇadīmahāvāha iva drutaḥ
]

`v 32 [
vahatsvinnabṛhacchinnapatākāketupādapaḥ |
marīcipuṣpaśabalavilolāsilatāvanaḥ
]

`v 33 [
viluṭhatpuṣṭapāṣāṇapṛṣadraktadravāvacaḥ |
ghorairghuraghurārāvairalaṃ hṛdayabhaṅgadaḥ
]

`v 34 [
uhyamānabṛhaddantidantadrumavighaṭṭanaiḥ |
sphūrjaccaṭacaṭārāvatarjitodgarjitāmbudaḥ
]

`v 35 [
hetivṛttograsaṃghaṭṭapuṣpajātajhaṇajjhaṇaḥ |
tarattaralasārāvaturaṅgamataraṅgakaḥ
]

`v 36 [
rathādibhaṭacakraughaśilārkrekārapīvaraḥ |
padātirathahastyaśvaśilāsaṃghaṭṭasaṃkaṭaḥ
]

`v 37 [
kaṭucaṃkāracītkārakreṃkāraparipīvaraḥ `note[ṭaṃkāretyapi pāṭhaḥ |] |
mṛtā mṛtā vayamiti ghanakolāhalākulaḥ
]

`v 38 [
senāvārimahāvartacaladgulugulāravaḥ |
raktasīkaranīhārasaṃdhyāmbudavitānakaḥ
]

`v 39 [
hetivīcivaṭācchinnavārivāmanavāridaḥ |
varṣapaṅkilabhūpīṭhataṭakhaṇḍanamaṇḍitaḥ
]

`v 40 [
kuntaśūlagadāprāsavahattālatalādbhutaḥ |
sākrandabhīrujanatāpratapanmṛgapotakaḥ
]

`v 41 [
mṛtahastyaśvayodhaughajīrṇaparṇanirantaraḥ |
piṣṭadehavasāmāṃsapaṅkasaṃjātakardamaḥ
]

`v 42 [
cūrṇīkṛtakhurāpiṣṭamahāsthighanasaikataḥ |
uhyamānaśilāpūrakāṣṭhakoṭikaṭaṅkaṭaḥ
]

`v 43 [
udgarjatpralayāmbhodairvahatpralayavāyubhiḥ |
prapatatpralayāsāraiḥ pralayāśanisaṃkaṭaiḥ
]

`v 44 [
paṅkilākhilabhūpīṭhaiḥ salilopaplutasthalaiḥ |
sitaśaityavaśāśyānadhārākṛtakhapañjaraiḥ
]

`v 45 [
samagranagaragrāmagṛhajvalitavahnibhiḥ |
prajāśvebhapadātīnāmākrandenāpi ghargharaiḥ
]

`v 46 [
rathāmbbhodharanirhrādairdivi bhūmau ghanāravaiḥ |
caturdikkaṃ ghanaṃ tārakreṃkārasya catuṣṭayaiḥ
]

`v 47 [
vidyudvalayavistārakārisaṃghaṭṭagharṣaṇaiḥ |
śaraśaktigadāprāsabhindipālādivarṣaṇaiḥ
]

`v 48 [
sarvadikkamasaṃkhyāni balāni valaśālinām |
bhūbhṛtāṃ vidravantyāśu vineśurmaśakaughavat
]

`v 49 [
uddāmapāvakavanopamahetisārthameghānalākulajanāśanivarṣapātaiḥ |
āsanbalāni capalābdhijalābalāni paryākulāni vaḍavāgnimivāviśanti
]