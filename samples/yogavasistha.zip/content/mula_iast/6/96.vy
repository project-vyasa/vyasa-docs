`v 1 [
ṣaṇṇavatitamaḥ sargaḥ 96
śrīvasiṣṭha uvāca |
pāṣāṇākhyānametatte kathitaṃ kāryakovida |
anayemāḥ sphuraddṛṣṭyā sṛṣṭayo nabhasi sthitāḥ
]

`v 2 [
na ca sthitaṃ kiṃcanāpi kvacanāpi kadācana |
sthitaṃ brahmaghane brahma yathāsthitamakhaṇḍitam
]

`v 3 [
brahma cinmātrakaṃ viddhi tadyathā svapnadṛṣṭiṣu |
puraṃ bhavannijādrūpānna kadācana bhidyate
]

`v 4 [
svayaṃbhūtvasamāpattau tathā dṛśyavyavasthitau |
svarūpamajahattveva cidākāśamajaṃ sthitam
]

`v 5 [
na svayaṃbhūrna ca jaganna svapnapuramastyalam |
sthitaṃ saṃvinmahādṛṣṭyā brahma cinmātrametayā
]

`v 6 [
yathā puraṃ bhavatsvapne cidrūpaṃ svātmani sthitam |
akhaṇḍamevamāsṛṣṭerāmahāpralayasthiteḥ
]

`v 7 [
hemahemāśmanoḥ svapnapuracetanayoryathā |
bhedo na saṃbhavatyeva na bhedaścitisargayoḥ
]

`v 8 [
citirekāsti no sargo hemāsti na tadūrmikā |
svapnācale cidevāsti na tu kācana śailatā
]

`v 9 [
cideva śailavadbhāti yathā svapne nirāmayā |
tathā brahma nirākāraṃ sargavadbhāti netarat
]

`v 10 [
cinmātramidamākāśamanantamajamavyayam |
mahākalpasahasreṣu nodeti na ca śāmyati
]

`v 11 [
cidākāśo hhi puruṣaścidākāśo bhavānayam |
cidākāśo'hamajaraścidākāśo jagattrayam
]

`v 12 [
cidākāśaṃ varjayitvā śavameva śarīrakam |
acchedyo'sāvadāhyo'sau cidākāśo na śāmyati
]

`v 13 [
ato na kiṃcinmriyate na ca kiṃcana jāyate |
cittvāttataścitkacanaṃ jagadityanubhūyate
]

`v 14 [
cinmātrapuruṣo janturmriyate yadi nāma vā |
tato mariṣyattatputro niḥsaṃdehaṃ piturmṛtau
]

`v 15 [
ekasminpramṛte jantāvamariṣyaṃstu sarvadā |
sarva eva janāḥ śūnyamabhaviṣyanmahītalam
]

`v 16 [
na cādyāpi mṛtaṃ rāma cinmātraṃ kasyacitkvacit |
na ca śūnyā sthitā bhūmistasmāccitpuruṣo'kṣayaḥ
]

`v 17 [
ekaṃ cinmātramevāhaṃ na śarīrādayo mama |
iti satyanusaṃdhāne kva janmamaraṇādayaḥ
]

`v 18 [
ahaṃ cinmātramamalamityātmānubhavaṃ svayam |
apahantyātmahantāro nimajjantyāpadarṇave
]

`v 19 [
cidahaṃ gaganādacchā nityānantā nirāmayā |
kiṃ jīvitaṃ me kiṃ vāpi maraṇaṃ vā sukhāsukhe
]

`v 20 [
vyomātmacetanamahaṃ ke śarīrādayo mama |
ityātmahāpahnute'ntaryo'nubhūtaṃ dhigastu tam
]

`v 21 [
iti vidvadbhirantaranubhūtamanubhavaṃ yaḥ kutarkairapahnute sa ātmahā taṃ dhigastu | 20
|
cidākāśamahaṃ svacchamanubhūtiriti sphuṭā |
yasyāstamāgatā mūḍhaṃ taṃ jīvantaṃ śavaṃ viduḥ
]

`v 22 [
ahaṃ vedanamātrātmā kāni dehendriyāṇi me |
labdhātmānamiti svacchaṃ pravilumpanti nāpadaḥ
]

`v 23 [
cinmātraṃ śuddhamātmānaṃ yo'valambya sthiraḥ sthitaḥ |
nādhayastaṃ vilumpanti mahopalamiveṣavaḥ
]

`v 24 [
cittvaṃ svabhāvaṃ vismṛtya baddhāsthā ye śarīrake |
taiḥ suvarṇaṃ parityajya gṛhītaṃ bhasma vastutaḥ
]

`v 25 [
balaṃ buddhiśca tejaśca deho'hamiti bhāvanāt |
naśyatyudetyetadeva cidevāhamiti sthiteḥ
]

`v 26 [
cidākāśamahaṃ śuddhaṃ ke me maraṇajanmanī |
evaṃ sthite syuḥ kiṃniṣṭhā lobhamohamadādayaḥ
]

`v 27 [
cidākāśādṛte dehānyo'nyatsāramavāpnuyāt |
tasmai tadyujyate vaktuṃ santi lobhādayastviti
]

`v 28 [
dehān sthūlasūkṣmakāraṇākhyān | sāramātmānamavāpnuyātpaśyet | tasmai mūḍhāya |
27 |
na cchidye na ca dahye'haṃ cinmātraṃ vajravacciti |
na dehī niścayo yasya taṃ pratyantakarastṛṇam
]

`v 29 [
aho nu mugdhatā jñānadṛṣṭīnāṃ yadvidantyalam |
śarīraśakalābhāve naśyāma iti mohitāḥ
]

`v 30 [
ahaṃ cinnabha eveti satye bhāve sthire sati |
vajrapātayugāntāgnidāhāḥ puṣpotkaropamāḥ
]

`v 31 [
cinmātramamaraṃ nāhaṃ yannaśyāmīti roditi |
anaṣṭa eva taddeho jātāpūrvā kharolikā
]

`v 32 [
idaṃ cetanamevāhaṃ nāhaṃ dehādidṛṣṭayaḥ |
iti niścayavānyo'ntarna sa muhyati karhicit
]

`v 33 [
ahaṃ cetanamākāśo nāśo me nopapadyate |
cetanena jagatpūrṇaṃ keva saṃdehitātra vaḥ
]

`v 34 [
cetanaṃ varjayitvānyatkiṃcidyūyaṃ janā yadi |
yaducyatāṃ mahāmūḍhāḥ svātmā kimapalapyate
]

`v 35 [
taccetanaṃ cenmriyate tajjanāḥ pratyahaṃ mṛtāḥ |
brūta kiṃ na mṛtā yūyaṃ tanmṛtaṃ kila cetanam
]

`v 36 [
tasmānna mriyate kiṃcinna ca jīvati kiṃcana |
jīvāmīti mṛto'smīti ciccetati na naśyati
]

`v 37 [
ciccetati yathā vā yattattathā sāśu paśyati |
ābālameṣo'nubhavo na kvacitsā ca naśyati
]

`v 38 [
sarveṣāmavināśiciccetanānusāreṇevārthānubhavaḥ prasiddho na tadvaiparītyenetyāha ##-
paripaśyati saṃsāraṃ paripaśyati muktatām |
sukhaduḥkhāni jānāti svarūpāttanna bhidyate
]

`v 39 [
aparijñātadehāttu dhatte mohābhidhāṃ svayam |
parijñātasvarūpāttu dhatte mokṣābhidhāṃ svayam
]

`v 40 [
nāstameti na codeti na kadācana kiṃcana |
sarvameva ca cinmātramākāśaviśadaṃ yataḥ
]

`v 41 [
na tadasti na yatsatyaṃ na tadasti na yanmṛṣā |
yadyathā yena nirṇītaṃ tattathā taṃ prati sthitam
]

`v 42 [
yadyadyathā jagati cetati cetanātmā tattattathānubhavatītyanubhūtisiddham |
dṛṣṭaṃ viṣāmṛtadṛśeva padārthajātaṃ nātosti saṃvidavidheyamiti
prasiddham
]