`v 7 [
acitprasaraṇaṃn śāntamaspandīva jaladravaḥ |
niḥspandapavanākāramākāśahṛdayopamam
]

`v 8 [
na deśakālādijagatprasareṣu ca yujyate |
ghanācchūnyānnirābhāsāccinmātravisarādṛte
]

`v 9 [
cinmātre prasṛte kāle `note[kāṣṭhe iti pāṭhaḥ |] vyomni nāvi jale sthale |
nidrāyāṃ jāgrati svapne bhavejjagadivoditam
]

`v 10 [
prasaraṇāprasaraṇe na ca saṃbhavato vidaḥ |
khādapyatyantasvacchatvādakṣobhādeḥ sadaiva hi
]

`v 11 [
jñaścetati na bhogādi na caivātmanyasāvaham |
dravatvamambhasīvāntaradvitīyaḥ pare sthitaḥ
]

`v 12 [
dhīrhrīḥ śrīrbhīḥ smṛtiḥ kīrtiḥ kāntirityādikaṃ gaṇaṃ |
na paśyati visaṃkalpastamasīva padānyaheḥ
]

`v 13 [
brahmendubimbasphuritacijjyotsnāṃśāmṛtadravaḥ |
dikkālāsaṃbhavātsargo neśvarādatiricyate
]

`v 14 [
ādhimānyaḥ sphuratyevaṃ pare sphurati bhāsuram |
jagadādyātmakaṃ cittaṃ cakraughatvamivāmbhasi
]

`v 15 [
majjanonmajjanārāvairvivartāvartaveṣṭanaiḥ |
acchinnānupadaṃ kṣīṇā bhāti sargasaricciram
]

`v 16 [
yathāvartaiḥ payo bhāti dhūmo bhāti yathā ghanaḥ |
tathā jaḍātmakatayā tṛtīyaḥ sarga etayoḥ
]

`v 17 [
dūrāddhūmarāśiryathā ghano nibiḍo megho vā bhāti | etayorbrahmamanasostṛtīyaḥ
sargo viṣayatvājjaḍātmakatayā satyatayā sphuraṇādajaḍātmakatayā ca bhātīti śeṣaḥ |
16 |
dāruṇi krakacacchede yathāvartādikaṃ tathā |
adigādau pare sargastadatadrūpavānayam
]

`v 18 [
saṃsārakadalīstambhādvinā saṃkalpapallavam |
mṛduno'pi dṛṣatkrūrānna kiṃcillabhate'ntaram
]

`v 19 [
sahasrakhuramūrdhākṣikaravaktrehitohitam |
nānādritanudigdeśasaritprādeśamātrakam
]

`v 20 [
antaḥśūnyamasārātma bahurāgoparañjitam |
sphuradvirāgavihitamārjanāmātratarjanam
]

`v 21 [
sasurāsuragandharvavidyādharamahoragam |
jaḍātmapavanaspandi paracetanacetitam
]

`v 22 [
paṭe citramahārājyamiva bhāsurasundaram |
parāmarśāsahaṃ cāru vikalpasphūrjitaṃ jagat
]

`v 23 [
spandātmani vikalpāṃśe patitā'satyarūpiṇi |
saṃvitprasarati bhrāntau tailabindurivāmbhasi
]

`v 24 [
hṛllekhājālavisaraiḥ sarvāvartavivartanaiḥ |
visaratsnehasaṃmiśrajaḍānudayacarvaṇaiḥ
]

`v 25 [
ahamityādicidrūpe vikalpenonmukhī satī |
na parādvyatiriktaiṣā jalatvādiva toyatā
]

`v 26 [
cidādityaḥ sva ātmaiva sarga ityabhidhīyate |
bhūtvāhamiti tenānyo na na sargo'sti na sarjakaḥ
]

`v 27 [
spandātmikāyāṃn sattāyāṃ yathā spando jaladravaḥ |
tathā cidātmā vyomatve na vyomatvādi vetti hi
]

`v 28 [
deśakālādinirmāṇapūrvakaṃ vedanaṃ vidaḥ |
sargātmakatvāttenāmbudravasāmyaṃ na dūragam
]

`v 29 [
manohaṃbhāvabuddhyādi yatkiṃcinnāma vedanam |
avidyāṃ viddhi yatnena pauruṣeṇāśu naśyati
]

`v 30 [
ardhaṃ mithaḥsaṃkathayā bhāgaḥ śāstravicāraṇaiḥ |
ātmapratyayataḥ śiṣṭamavidyāyā nivartate
]

`v 31 [
kena kena pauruṣeṇa kiyatī sā naśyati tadāha - ardhamiti |
vinayapraṇatidānasanmānādivaśīkṛtaistattvavidbhiḥ saha
saṃkathanātprathamabhūmikāpratiṣṭhāparyantamabhyastayotkaṭavairāgyādi##-
naśyatītyarthaḥ | śāstravicāraṇaiḥ śravaṇādibhiḥ pramāṇaprameyāsaṃbhāvanādirūpo
dehādiṣvahaṃtārūpaścāvidyāyā vikṣepaśaktirūpo bhāgaścaturthāṃśo naśyati |
ātmapratyayato
brahmātmabhāvasākṣātkārāccaturthabhūmikāmārabhyottarottaramupacīyamānāt śiṣṭa
āvaraṇaśaktirūpaścaturthabhāgaścāruṇodayottaraṃ tama iva kramānivartata ityarthaḥ |
30 |
caturbhāgātmani kṛte ityavidyākṣaye kramāt |
samakālācca yacchiṣṭaṃ tadanāmārthasanmayam
]

`v 32 [
śrīrāma uvāca |
ardhaṃ mithaḥsaṃkathayā bhāgaḥ śāstravicāraṇaiḥ |
ātmapratyayato bhāgaḥ kathaṃ tasyā nivartate
]

`v 33 [
samakāle kramācceti muninātha kimucyate |
tadanāmārthasacceti saccāsacceti kiṃ vada
]

`v 34 [
śrīvasiṣṭha uvāca |
sujanena viraktena saṃsārottaraṇārthinā |
saha cāpyātmaviduṣāṃ saṃsṛtiṃ pravicārayet
]

`v 35 [
yataḥ kutaścidanviṣya savirāgamamatsaram |
janaṃ sajjanamātmajñaṃ yatnenārādhayedbudhaḥ
]

`v 36 [
saṃpanne saṃgame sādhoravidyārthaṃ kṣayaṃ gatam |
viddhi vedyavidāṃ śreṣṭha jyeṣṭhaśreṣṭhadaśodayāt
]

`v 37 [
ardhaṃ sajjanasaṃparkādavidyāyā vinaśyati |
caturbhāgastu śāstrārthaiścaturbhāgaṃ svayatnataḥ
]

`v 38 [
eko'bhilāṣa utpanno bhogebhyaśca nivāryate |
tatkṣaye yātyavidyāyāścaturthāṃśaḥ svayatnataḥ
]

`v 39 [
sādhusaṅgamaśāstrārthasvayatnaiḥ kṣīyate malam |
ekaikenātha sarvaiśca tulyakālaṃ kramādapi
]

`v 40 [
yadavidyākṣayaikātma na kiṃcitkiṃcideva ca |
śiṣyate tatparaṃ prāhuranāmārthamasacca sat
]

`v 41 [
brahmedaṃ ghanamajarādyanantamekaṃ saṃkalpasphuraṇamavidyamānameva |
buddhvaivaṃ vyapagatamānameyamoho nirvāṇaṃ pariviharanviśokamāssva
]