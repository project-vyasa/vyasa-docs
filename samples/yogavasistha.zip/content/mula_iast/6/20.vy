`v 1 [
viṃśaḥ sargaḥ 20
śrīvasiṣṭha uvāca |
saṃkalpapuruṣastveṣa yadyatkapayati svayam |
tattathā tādṛśaṃ pañcabhūtātmā bhavatīva kham
]

`v 2 [
sarvaṃ rāma jagajjātaṃ tatsaṃkalpaṃ vidurbudhāḥ |
tādṛgrūpaṃ pañcakātmaviṣayonmukhamātatam
]

`v 3 [
jagatpadārthasārthasya virāṭ sarvasya kāraṇam |
kāraṇena samānyeva kāryāṇi ca bhavantyataḥ
]

`v 4 [
yathaiṣa sa virāḍeva virāṭ pratyekamātmani |
svasaṃvidi prasarati bodhavānna tvabodhavān
]

`v 5 [
āsarīsṛpamārudramevamabhyudito bhramaḥ |
aṇāvapyadrivistāro bījakośa iva drumaḥ
]

`v 6 [
āsarīsṛpamārudraṃ virāṭ pratyekamātmani |
parāṇāvapyanantātmabodhato na tvabodhataḥ
]

`v 7 [
yādṛgeva virāḍātmanyeṣa vistāra āgataḥ |
tādṛgeveha sarvasminnaṇumātre'pi bhūtake
]

`v 8 [
paramārthena na sthūlaṃ na sūkṣmaṃ kiṃcana kvacit |
yadyathā vitataṃ yatra tattathāśvanubhūyate
]

`v 9 [
manaścandramaso jātaṃ manasaścandra utthitaḥ |
jīvājjīvo'thavaikaiṣā sattā dravajalāṅgavat
]

`v 10 [
śukrasāraṃ vidurjīvaṃ prāleyakaṇasaṃnibham |
ānando'calasaṃdohastata eva pravartate
]

`v 11 [
taṃ cetasi tadābhāsaṃ pūrṇamātmasthamātmanā |
tatra tanmayatāṃ dhatte tena tanmayarūpiṇī
]

`v 12 [
jīvasaṃvidathaiṣāntaryadupāyāti pañcatām |
na tatra kāraṇaṃn kiṃcidvidyate na ca kāryatā
]

`v 13 [
pratiyogivyavacchitterabhāvātsvasvabhāvayoḥ |
svabhāvoktirna caivātra bhavatyarthānusāriṇī
]

`v 14 [
jīvo jīvatvameva svajīvatvādeva ca svataḥ |
antastvena bahiṣṭvena dṛśyate na ca vāyuvat
]

`v 15 [
nīhāreṇeva saṃvītaścetyavastuparāyaṇaḥ |
jātyandha iva panthānaṃ mārutātmā na paśyati
]

`v 16 [
jagajjṛmbhikayā jīvaḥ svamaikyaṃ dvitvamāsthitaḥ |
spandaśaktyeva pavana āvṛtātmā na paśyati
]

`v 17 [
ajñānasya mahāgranthermithyāvedyātmano'sataḥ |
ahamityartharūpasya bhedo mokṣa iti smṛtaḥ
]

`v 18 [
vyapagataghanacetanaḥ samantādahamiti nūnamabudhyamāna āsva |
anabhidhaghanacetanaikarūpaḥ kṣitasadasatsadasatsadoditaśca
]