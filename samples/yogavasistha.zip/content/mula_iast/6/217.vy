`v 1 [
śrīvālmīkiruvāca |
etatte kathitaṃ rājankumbhayoneḥ subhāṣitam |
amunā tattvamārgeṇa tatpadaṃ prāpsyasi dhruvam
]

`v 2 [
rājovāca |
bhagavanbhavato dṛṣṭirbhavabandhavināśanī |
ālokito yayā cāhamuttīrṇo'smi bhavāmbudheḥ
]

`v 3 [
devadūta uvāca |
ityuktvāsau tato rājā vismayotphullalocanaḥ |
uvāca vacanaṃ māṃ tu madhuraṃ ślakṣṇayā girā
]

`v 4 [
rājovāca |
devadūta namastubhyaṃ kuśalaṃ cāstu te vibho |
satāṃ sāptapadaṃ maitramityuktaṃ tattvayā kṛtam
]

`v 5 [
idānīṃ gaccha bhadraṃ te devarājaniveśanam |
anena śravaṇenāhaṃ nirvṛto mudito'pi ca
]

`v 6 [
śrutārthaṃ cintayannatra sthāsyāmi vigatajvaraḥ |
ityukto'haṃ tato bhadre paraṃ vismayamāgataḥ
]

`v 7 [
na śrutaṃ pūrvamevaitajjñānasāraṃ śrutaṃ mayā |
tenaiva muditaścāntaḥ pītāmṛta ivādhunā
]

`v 8 [
tato vālmīkimāpṛcchya āgato'smi tvadantike |
etatte sarvamākhyātaṃ tvayā pṛṣṭaṃ mamānaghe |
itaḥ paraṃ gamiṣyāmi śakrasya sadanaṃ prati
]

`v 9 [
apsarā uvāca |
namo'stu te mahābhāga devadūta tvayā mama |
śrāvitādarthavijñānātparāṃ nirvṛtimāgatā
]

`v 10 [
kṛtārthā vītaśokāsmi sthāsyāmi vigatajvarā |
idānīṃ gaccha bhadraṃ te yathecchaṃ śakrasaṃnidhau
]

`v 11 [
agniveśya uvāca |
tataḥ sā suruciḥ śreṣṭhā tamevārthamacintayat |
sthitā sā himavatpṛṣṭhe samīpe gandhamādane
]

`v 12 [
kaccidetacchrutaṃ putra vasiṣṭhasyopadeśanam |
tatsarvmavadhāryātha yathecchasi tathā kuru
]

`v 13 [
kāruṇya uvāca |
smṛtirvāgdṛṣṭisattā ca svapne vandhyāsute'jale |
marīcikā yathā tadvajjñānātsāṃsārikī sthitiḥ
]

`v 14 [
mama nāsti kṛtenārtho nākṛteneha kaścana |
yathāprāptena tiṣṭhāmi hyakarmaṇi ka āgrahaḥ
]

`v 15 [
agastiruvāca |
ityuktvā nāma kāruṇya agniveśyasutaḥ kṛtī |
prāptakarmā yathānyāyaṃ kāle kāle hyupāharat
]

`v 16 [
prāptakarmā vivāhena prāptakarmādhikāraḥ san kāle kāle yathocitakāle
snānadānāgnihotrātithisaparyādikarma upāharat anuṣṭhitavānityarthaḥ | nāmeti kilārthe |
15 |
saṃdeho'tra na kartavyaḥ sutīkṣṇa jñānakarmaṇi |
saṃśayādbhraśyate svārthātsaṃśayātmā vinaśyati
]

`v 17 [
etacchrutvā munervākyamanekārthaikyabodhanam |
namaskṛtya guruṃ prāha antike vinayānvitaḥ
]

`v 18 [
sutīkṣṇa uvāca |
naṣṭamajñānatatkāryaṃ prāptaṃ jñānamanuttamam |
sākṣiṇi sphuritābhāse dhruve dīpa iva kriyāḥ
]

`v 19 [
sati yasminpravartante cittehāḥ spandapūrvikāḥ |
kaṭakāṅgadakeyūranūpurairiva kāñcanam
]

`v 20 [
payasīva taraṅgālī yasmātsphurati dṛśyabhūḥ |
tadevedaṃ jagatsarvaṃ pūrṇe pūrṇaṃ vyavasthitam
]

`v 21 [
yathāprāpto'nuvartāmi ko laṅghayati sadvacaḥ |
bhagavaṃstvatprasādena jñātajñeyo'smi saṃsthitaḥ
]

`v 22 [
kṛtārtho'haṃ namaste'stu daṇḍavatpatito bhuvi |
guroruttīrṇatā kena śiṣyāṇāmasti karmaṇā
]

`v 23 [
kāyavāṅmanasā tasmācchiṣyairātmanivedanam |
guroruttīrṇatā saiva nānyā kenāpi karmaṇā
]

`v 24 [
svāmiṃstava prasādena uttīrṇo'haṃ bhavāmbudheḥ |
āpūritajagajjālaṃ sthitosmi gatasaṃśayaḥ
]

`v 25 [
yatsarvaṃ khalvidaṃ brahma tajjalāniti ca sphuṭam |
śrutvā hyudīryate sāmni tasmai brahmātmane namaḥ
]

`v 26 [
brahmānandaṃ paramasukhadaṃ kevalaṃ jñānamūrtiṃ dvandvātītaṃ
gaganasadṛśaṃ tattvamasyādilakṣyam |
ekaṃ nityaṃ vimalamacalaṃ sarvadhīsākṣibhūtaṃ bhāvātītaṃ triguṇarahitaṃ
śrīvasiṣṭhaṃ natāḥ smaḥ
]