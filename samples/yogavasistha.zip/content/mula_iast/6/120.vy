`v 1 [
viṃśādhikaśatatamaḥ sargaḥ 120
sahacarā ūcuḥ |
evaṃprāyāḥ kathāḥ kurvatpaśyainanmithunaṃ mahat |
pānaṃ pravṛttavatsāraṃ pātuṃ padmanibhekṣaṇa
]

`v 2 [
kadalīkandalīsvacchagucchācchoṭanapaṇḍitāḥ |
vividhā vāyavo vānti puṣpakesaramaṇḍitāḥ
]

`v 3 [
vāyūnkaścidvarṇayati - kadalītyādinā | gucchānāmācchoṭane vikāsane paṇḍitāḥ |
2 |
vānti vātā vanodvāntavividhāmodamāṃsalāḥ |
pītagharmakaṇāḥ krāntalalanālakalālakāḥ
]

`v 4 [
kulācalaguhāgehavalanodyanmṛgādhipāḥ |
sarantyasurasaṃrambhairlavaṇārṇavamārutāḥ
]

`v 5 [
tamālatālataralalīlāndolanalālitāḥ |
anilājalakallolotkrāntakomalapallavāḥ
]

`v 6 [
lalannavalatāvāntapuṣpadhūlividnūsarāḥ |
saranti maruto madamudyāneṣu nṛpā iva
]

`v 7 [
madhuraṃ vaṃśaviśrānto gātumeṣa vanānilaḥ |
pravṛttaḥ pāṇḍunagaranārībhiriva śikṣitaḥ
]

`v 8 [
nikāraḥ karṇikāreṇa pavanasya yadā kṛtaḥ |
tadā pariharantyenaṃ bhramarā api dūrataḥ
]

`v 9 [
na dadāti phalaṃ kiṃcidarthine na ca pallavam |
tālaḥ stambhatayā''rambhaṃn hyarūpaiva vinā''kṛtiḥ
]

`v 10 [
rāga eva hi śobhāyai nirguṇānāṃ jaḍātmanām |
rājeva rājate rājanrāgeṇaivaiṣa kiṃśukaḥ
]

`v 11 [
audāryādiguṇaśūnyānāṃ jaḍātmanāṃ mūrkhāṇāṃ vastrālaṃkārādyāḍambareṇa
rāgaḥ śarīrarañjanameva śobhāyai nānyadityarthaḥ | kiṃśukaḥ puṣpitaḥ palāśaḥ | 10
|
āgaccha karṇikāro'yaṃ vikārasyaiva bhājanam |
nirāmodaḥ kimetena nirguṇeneva jantunā
]

`v 12 [
vilolamañjarījālataḍitsaṅgasthito'sitaḥ |
cātakasyāmbudabhrāntiṃ tamālaḥ kurute mudhā
]

`v 13 [
patrālā ghanasaṃghātāḥ sacchāyāvṛtabhūbhṛtaḥ |
guṇānāṃ mahatāṃ yogyā vaṃśā vaṃśā ivonnatāḥ
]

`v 14 [
hemasānvāsanastho'gryo vātavyādhitaṭo'mbudaḥ |
taḍitpītāmbaraṃ dhatte kṣubdhaṃ `note[kṣubdhamityatra ākāśapakṣe taḍidbhireva
kṣubdham | vastrapakṣe saṃcalitaṃ sphurat |] haririvodbhavaḥ `note[udbhava
ūrdhvabhavaḥ pakṣe utkṛṣṭaiścaryaḥ |]
]

`v 15 [
praveśanirgamavyagrataratkhagaśilīmukhaḥ |
praphullakiṃśuko bhāti vīro rakta ivāsṛjā
]

`v 16 [
mandāramañjarīpuñjapiñjarāmbhodamandire |
mahendramastake mattāḥ suptā gandharvakāminaḥ
]

`v 17 [
kalpadrumavanacchāyā viśrāntā vitatānvitāḥ |
paśya pārthiva gāyanti siddhavidyādharādhvagāḥ
]

`v 18 [
paśya kalpadrumasyāsya pallave pallave vane |
viśrāntāḥ surasundaryo gāyanti ca hasanti ca
]

`v 19 [
mandiraṃ mandapālasya mandare mṛdumandire |
muneridamudārasya bhāryā sā yasya pakṣiṇī
]

`v 20 [
anyonyāmatasiṃhebhanakuloragakelikām |
paśya munyāśramaśreṇiṃ sarvartukusumadrumām
]

`v 21 [
vidrumadrumamiśrāṇāmbhodhitaṭavīrudhām |
bimbitārkāḥ kacantyete pallaveṣūdabindavaḥ
]

`v 22 [
vīcayo ratnamāṇikyapadeṣvāvartavṛttibhiḥ |
vilasanti vilāsinyo vakṣaḥsviva vilāsinām
]

`v 23 [
ratnamāṇikyānāṃ padeṣvākarasthāneṣu vīcaya āvartavṛttibhirmuhurmuhuḥ
parivartanairvilasanti krīḍanti | vilāsinyastaruṇyo vilāsināṃ svakāntānāṃ vakṣaḥsviva |
22 |
nāgalokendralokastrīgamanāgamanodbhavaḥ |
divyo bhūṣaṇajhāṃkāraḥ śrūyate nabhasaḥ śṛṇu
]

`v 24 [
śravaṇopāntavibhraṣṭamadamattālinīsvaraiḥ |
airāvaṇasnānabhuvo gāyantīva guhā gireḥ
]

`v 25 [
hrasato'nudinaṃ kṛṣṇapakṣe kṛṣṇāntalekhikāḥ |
dṛśyante kṛśagātrasya vāstukāvalayo'mbudheḥ
]

`v 26 [
āmodagandhaśvasanā sacchāyā śītalāṅgikā |
ekāntadarśitākārā nānākusumapūritā
]

`v 27 [
vanavinyāsavasanā nirjharāmalahāsinī |
āstīrṇapuṣpāstaraṇā dhanyā vanavilāsinī
]

`v 28 [
ramante nandanodyāne na tathodārabuddhayaḥ |
yathopaśāntaśabdāsu śuddhāsu vanabhūmiṣu
]

`v 29 [
suviraktaṃ muneśceto raktaṃ ca viṣayārthinaḥ |
ramayanti samaṃ ramyā vijanā vanabhūmayaḥ
]

`v 30 [
munerviraktaṃ ceto viṣayārthinaḥ kāmino raktaṃ ca cetaḥ samaṃ tulyatayā ramayanti | 29
|
salilādhautavaprāṇāmambhodhitaṭabhūbhṛtām |
nūpurairiva ratnaughaiḥ pādā bhānti dhvananti ca
]

`v 31 [
puṃnāganagaviśrāntāḥ kāntakāñcanakāntayaḥ |
hemacūḍāḥ khagā bhānti divi devagaṇā iva
]

`v 32 [
bhramarāmbhodadhūmāḍhyāḥ phullacampakakānanāḥ |
kampante paśya vātena jvalitā iva parvatāḥ
]

`v 33 [
kurvantaṃ karavīrāgralatāndolāvadolakam |
kokilaṃ kokilāliṅgya lolālāpayati priyam
]

`v 34 [
lasatkalakalārāvametā lāvaṇasaindhavīḥ |
pūrṇāstaṭabhuvo bhūpaiḥ paśyopāyanapāṇibhiḥ
]

`v 35 [
ā pūrvādā'parasmāllavaṇajalanidherottarāddakṣiṇādvā devodagrājiśiṣṭā
ihanarapatayaḥ pādapīṭhīkriyantāṃ |
dīyantāṃ maṇḍalānāṃ diśi diśi ca yathāśāstramastrāṇyavanyā rakṣāyai
kṣāntipūrvaṃ ciramatulabalaṃ śāntayā śāsanāni
]