`v 1 [
ekonapañcāśaḥ sargaḥ 49
śrīvasiṣṭha uvāca |
paripuṣṭavivekānāṃ vāsanāmalamujjhatām |
mahattā mahatāmantaḥ kāpyapūrvaiva jāyate
]

`v 2 [
audāryodāramaryādāṃ matiṃ gāmbhīryasundarīm |
mahatāṃ nāvagāhante bhuvanāni caturdaśa
]

`v 3 [
cittabhrāntirjagaditi prarūḍhe pratyaye satām |
bāhyaścāntaścarannakragraho mohaśca śāmyati
]

`v 4 [
dvīnduvattāpajalavatkeśoṇḍrakavadambare |
visphurantyāṃ jagadbhrāntau vāsanāpratyayaḥ kutaḥ
]

`v 5 [
vāsanāpratyaye śūnye śūnyaṃ vyomaiva śiṣyate |
sāpyavasthā mano'sattve kutastyājyā vivekinā
]

`v 6 [
trayametattu yāvasthātrayeṇānena varjitā |
paśyantīvāpyapaśyantī sāvasthā paramocyate
]

`v 7 [
vicitraratnaraśmyogha iva nānātmakaṃ jagat |
ābhāsamātraṃ na tvātmā na ghanaṃ na ca pārthivam
]

`v 8 [
rūpālokanamātraṃ hi śūnyameva jagatsthitam |
khe vicitramaṇivyūhakarajālamivotthitam
]

`v 9 [
neha satyāni bhūtāni na jagattā na śūnyatā |
idaṃ brahmākhyaratneśaprabhājālaṃ vijṛmbhitam
]

`v 10 [
sṛṣṭayo'sṛṣṭayo brāhmyo nānātā ca na nāśatāḥ |
amūrtā eva bhāsante kalpanārkagaṇā ghanāḥ
]

`v 11 [
evaṃ tāvaddhanībhūtaḥ piṇḍagrāho na vidyate |
saṃkalpite ca vyomnīva śūnyataivāvagamyate
]

`v 12 [
tasyāmavastubhūtāyāṃ kathaṃ bhāvanibandhanam |
bhaviṣyadākāśatarau viśrāntaḥ ko vihaṃgamaḥ
]

`v 13 [
piṇḍatvaṃ nāsti bhūtānāṃ śūnyatā ca na vidyate |
cittamapyata evāstaṃ śeṣaṃ sattanna cāsthiti
]

`v 14 [
anānāsamamevāste nānārūpo vibodhavān |
antarālīnanānārtho yathā kanakapiṇḍakaḥ
]

`v 15 [
yathāsthitasya sāhaṃtvaṃ viśvaṃ cittaṃ vilīyate |
jñasyāvācyamacittvaṃ satsvarūpamavaśiṣyate
]

`v 16 [
nanu jñasya tatsanmātramavaśiṣṭacidrūpameva kiṃ na syāt | sati hi citte cidabhivyaktiḥ
prasiddhā tadvilaye tadasaṃbhavādityāśaṅkyāha - yathāsthitasyeti | yadi
ayathāsvabhāve jāḍye sthitasyāsya sāhaṃtvaṃ viśvaṃ cittaṃ ca vilīyeta tadā
jaḍasanmātrapariśeṣo bhavet | na tvevaṃ kiṃtu jñasya yathābhūtacidekasvabhāve
sthitasya sāhaṃtvaṃ viśvaṃ cittaṃ ca tattvadarśanādvilīyate tadā tu
pariśiṣṭacidekarasasyā'cittvaṃ vaktumaśakyamiti cidekarasasatpariśeṣasiddhirityarthaḥ |
15 |
kliśyate kevalaṃ buddhiruttarādharadarśanaiḥ |
stokayābhyastayā yuktyā satyo'rthohyavagamyate
]

`v 17 [
virāḍojovirahitaṃ kāryakāraṇatādibhiḥ |
bhūtabhavyabhaviṣyasya jagadaṅgasya saṃbhavam
]

`v 18 [
yena bodhātmanā buddhaṃ sa jña ityabhidhīyate |
advaitasyopaśāntasya tasya viśvaṃ na vidyate
]

`v 19 [
pūrvoktāḥ sarva evaite upadeśā viśeṣaṇāḥ |
jñasyānubhavamāyānti svataḥ sādhukathā iva
]

`v 20 [
piṇḍatvaṃ nāsti bhūtānāṃ śūnyatvaṃ cāpyasaṃbhavāt |
ata eva mano nāsti śeṣaṃ sattattava sthitiḥ
]

`v 21 [
cetyonmukhatvamevāntaścetanasyāsya cetanam |
uditaṃ tadanarthāya śreyase'nuditaṃ bhavet
]

`v 22 [
uditaṃ bāhyatāmeti tatra gacchati piṇḍatām |
svayaṃ saṃvedanādeva jāḍyādambviva śailatām
]

`v 23 [
svapnādyarthavadādatte bodho'bodhena piṇḍatām |
tadgrāhakatayā cittaṃ bhūtvā badhnāti dehakam
]

`v 24 [
etāvatīṣvavasthāsu bodhasyodeti nānyatā |
śabdakalpanayā bhedaḥ kevalaṃ parikalpitaḥ
]

`v 25 [
bahirantaśca bodhasya bhātyātmaivārthadṛṣṭibhiḥ |
antastvena bahiṣṭvena naivāsya manaso yathā
]

`v 26 [
bodhasyākāśakalpatvātkālākāśādi tadvapuḥ |
padārthāścaiva svātmānaḥ svapnavannārtharūpi kham
]

`v 27 [
bāhyārthatā nāntaratvaṃ tadvadbodhavaśādvrajet |
nāsādṛśyaṃ hi bodhatvaṃ gantuṃn śaktaṃ jaḍaṃ kvacit
]

`v 28 [
bodho dṛśyadaśāṃ naiti prāpto vāpi ca tāṃ sthitim |
sa yathāsthitamevāste manāgapyeti nānyatām
]

`v 29 [
atyarthaṃ śuddhabodhaikapariṇāme kṛtodaye |
bodhābodhārthaśabdānāṃ śrutirapyastameṣyati
]

`v 30 [
ātivāhikadehānāṃ cittānāmeva jāyate |
ādhibhautikatābodho dṛḍhabhāvanayā svayā
]

`v 31 [
ākā'saviśadaiścittairbhāvitaiṣātivāhikaiḥ |
ādhibhautikatā mithyā naṭairiva piśācatā
]

`v 32 [
bhrāntirabhramaṇābhyāsātprajñātaiṣopaśāmyati |
nonmatto'smīti saṃbodhācchāmyatyunmattatā kila
]

`v 33 [
bhrānteḥ svayaṃ parijñānādvāsanā vinivartate |
svapne svapnatayā buddhe kasya syātkila bhāvanā
]

`v 34 [
vāsanātānavenaiva saṃsāra upaśāmyati |
vāsanaiva mahāyakṣiṇyetacchedaparā budhāḥ
]

`v 35 [
ajñānonmattatā puṃsāṃ yathābhyāsena bhāvitā |
tathaiva bodhātsvabhyāsātsā kālenopaśāmyati
]

`v 36 [
ātivāhikadeho'yamādhibhautikatāṃ yathā |
nīyate bhāvanāṃ tajjñairbodhasattāprasādataḥ
]

`v 37 [
ātivāhikadeho'pi nītvā jīvapadaṃ tathā |
dṛḍhena bodhābhyāsena netavyo brahmatāmapi
]

`v 38 [
svavastuvaccedutpattirbudhyate bodharūpiṇī |
tadātivāhikī buddhiḥ kathamityapi budhyate
]

`v 39 [
no cettatprativākyārthāttadgranthirvinnivartate |
bhūtotsādanasūtrasya pratipattṛpadaṃ yathā
]

`v 40 [
jagadbodhaikatāṃ buddhvā boddhavyā tāvadavraṇam |
atyantapariṇāmena yāvatsāpi na budhyate
]

`v 41 [
sabāhyābhyantare citte śānte bhāti svabhāvatā |
śītalāṃ vyomanirbhāsāṃ tāmevāśrityaśāmyatām
]

`v 42 [
jñānavānjñānayajñastho dhyānayūpaṃ viropayan |
jagadvijitya jayati sarvatyāgaikadakṣiṇaḥ
]

`v 43 [
patatyaṅgāravarṣe ca vāti vā pralayānile |
bhūtale vrajati vyomni samamāste jña ātmani
]

`v 44 [
vaitṛṣṇyaśāntamanaso nirodhamalamīyuṣaḥ |
sthitirvajrasamādhānaṃ vinā nānyopapadyate
]

`v 45 [
yathā bāhyārthavaitṛṣṇye nopaśāmyatyalaṃ manaḥ |
na tathā śāstrasaṃdarbhairnopadeśatapodamaiḥ
]

`v 46 [
manastṛṇasya sarvārthavaitṛṣṇyāgnirvibodhitaḥ |
sarvatyāgānilaiḥ saṃpadatyāpaditi bhāvanāt
]

`v 47 [
saṃpatsarvāpyatyāpaditi bhāvanānmanolakṣaṇasya tṛṇoccayasya madhye
sarvatyāgalakṣaṇairanilairvibodhitaḥ sarvārthavaitṛṣṇyalakṣaṇo'gnirjñātvā
caramasākṣātkārajvālātmanā prabudhya bahirantaśca prasiddho yo mohāndhakāro yaśca
tatprayuktaścorayakṣādikalpanātulyo brahmāṇḍabhūtabhautikamūrtalakṣaṇapiṇḍagrāho
yacca tatprayuktaṃ cakṣurādinā śabdārthavedanaṃn tatsarvaṃ
jñaptiścidātmaivetyakhaṇḍādvayasvabhāvenaiva kacati | yathā vajrādimaṇiḥ
svapratibimbitavastujātaṃ svaikarasyena prathayansvata eva kacati tadvaditi dvayoranvayaḥ |
46 |
bahirantaśca mohaśca piṇḍagrāho'rthavedanam |
jñaptireveti kacati jñātvā maṇirivātmani
]

`v 48 [
naranāgāsurāgāragirigahvaradṛṣṭibhiḥ |
citireveti visṛtā dhūmo'mbudatayeva khe
]

`v 49 [
vepante ciddravatvena brahmāṇḍajaḍabhāṇḍagāḥ |
svavivartataraṅgiṇyo jīvaśaktyā''patadrasāḥ
]

`v 50 [
jīvakājīrṇaśapharī vyomavārivihāriṇī |
mohajālena valitā na smaratyātmani sthitim
]

`v 51 [
ghanībhūtā ghanatvena cidghanā gaganāṅgaṇe |
nānāpadārtharūpeṇa sphurati svātmanātmani
]

`v 52 [
sarva eva samā jīvā vāsanāmantareṇa ca |
śuṣkaparṇavaduḍḍīnā jaḍāḥ śvasanaveṇavaḥ
]

`v 53 [
āhṛtya pauruṣabalānyavajitya tandrīmutthāya tarjitasamarjitavāsanaugham |
saṃsārapāśaghanapañjaramañjasaiva bhaṅktvābhyudeyamabhito'jñasamena
bhāvyam
]