`v 1 [
dvyaśītitamaḥ sargaḥ 82
śrīrāma uvāca |
kimetadbhagavansarvanāśe nṛtyati kena sā |
kiṃ śūrpaphalakumbhādyastasyāḥ sragdāmadhāraṇam
]

`v 2 [
kiṃ naṣṭaṃ trijagadbhūyaḥ kiṃ kālyā dehasaṃsthitam |
parinṛtyati nirvāṇaṃ kathaṃ punarupāgatam
]

`v 3 [
śrīvasiṣṭha uvāca |
nāsau pumānna cāsau strī na tannṛttaṃ na tāvubhau |
tathābhṛte tathācāre ākṛtī na ca te tayoḥ
]

`v 4 [
anādicinmātranabho yattatkāraṇakāraṇam |
anantaṃ śāntamābhāsamātramavyayamātatam
]

`v 5 [
śivaṃ tatsacchivaṃ sākṣāllakṣyate bhairavākṛti |
tathāsthito jagacchāntau paramākāśa eva saḥ |
]

`v 6 [
cetanatvāttathābhūtasvabhāvavibhavādṛte |
sthātuṃ na yujyate tasya yathā hemno nirākṛti
]

`v 7 [
kathamāstāṃ vada prājña cinmātraṃ cetanaṃ vinā |
kathamāstāṃ vada prājña maricaṃ tiktatāṃ vinā
]

`v 8 [
kaṭakādi vinā hema kathamāstāṃ vilocyatām |
kathaṃ svabhāvena vinā padārthasya bhavetsthitiḥ
]

`v 9 [
vinā tiṣṭhati mādhuryaṃ kathayekṣurasaḥ katham |
nirmādhuryaśca yastvikṣuraso na hi sa tadrasaḥ
]

`v 10 [
acetanaṃ yaccinmātraṃ na taccinmātramucyate |
na ca cinmātranabhaso naṣṭaṃ kvacana yujyate
]

`v 11 [
svasattāmātrakādanyatkiṃcittasya na yujyate |
anyatvamurarīkartuṃ vyomānanyamasau kila
]

`v 12 [
tasmāttasya yadakṣubdhaṃ sattāmātraṃ svabhāsanam |
anādimadhyaparyantaṃ sarvaśaktimayātmakam
]

`v 13 [
kiṃ tarhi jagadrūpamiti cedbrahmasattaiva | sā hi tattvāvabodhakamānaṃ vinā
laukikadṛśā jagattatpralayādyākāreṇa sarpātmaneva rajjurbhāsate |
tattvāvabodhakamānena tu yathārtharūpeṇeti niṣkarṣa ityupasaṃharati - tasmāditi | 12
|
tadetattrijagatsargakalpāntau vyoma bhūrdiśaḥ |
nāśa utpādanaṃ nāma vinānābhāsanaṃ nabhaḥ
]

`v 14 [
jananaṃ maraṇaṃ māyāmohaṃ māndyamavastutā |
vastutā ca vivekaśca bandho mokṣaḥ śubhāśubhe
]

`v 15 [
vidyā'vidyā videhatvaṃ sadehatvaṃ kṣaṇaściram |
cañcalatvaṃ sthiratvaṃ vā tvaṃ cāhaṃ cetaraśca tat
]

`v 16 [
sadasaccātha sadasanmaurkhyaṃ pāṇḍityameva ca |
deśakālakriyādravyakalanākelikalpanam
]

`v 17 [
rūpālokamanaskārakarmabuddhīndriyātmakam |
tejovāryanilākāśapṛthvyādikamidaṃ tatam
]

`v 18 [
etatsarvamasau śuddhacidākāśo nirāmayaḥ |
ajahadvyomatāmeva sarvātmaivaivamāsthitaḥ
]

`v 19 [
etatsarvaṃ ca vimalaṃ khamevātra na saṃśayaḥ |
asmādananyatsvapnādirdṛṣṭānto'trāvikhaṇḍitaḥ
]

`v 20 [
cinmayaḥ paramākāśo ya eva kathito mayā |
eṣo'sau śiva ityukto bhavatyeṣa sanātanaḥ
]

`v 21 [
sa eṣa harirityāste bhavatyeṣa pitāmahaḥ |
candro'rka indro varuṇo yamo vaiśravaṇo'nalaḥ
]

`v 22 [
anilo jaladombhodhirhyo yadvastvasi nāsti ca |
ityete cinmayākāśakośaleśāḥ sphurantyalam
]

`v 23 [
evaṃvidhābhiḥ saṃjñābhirmudhābhāvanayedṛśāḥ |
svabhāvamātrabodhena bhavantyete tu tādṛśāḥ
]

`v 24 [
abodho bodha ityevaṃ cidvyomaivātmani sthitam |
tasmādbhedo dvaitamaikyaṃ nāstyeveti praśāmyatām
]

`v 25 [
tāvattaraṅgatvamayaṃ karoti jīvaḥ svasaṃsāramahāsamudre |
jīvaḥ jānāti paraṃ svabhāvaṃ nirāmayaṃ tanmayatāmupetaḥ
]

`v 26 [
jñāne tu śāntiṃ sa tathopayāti yathā na so'bdhirna taraṅgako'sau |
yathāsthitaṃ sarvamidaṃ ca śāntaṃ bhavatyanantaṃ parameva tasya
]