`v 1 [
pañcamaḥ sargaḥ 5
śrīvasiṣṭha uvāca |
svabhāvaṃ svaṃ vijityādāvindriyāṇāṃ sacetasām |
pravartate viveke yaḥ sarvaṃ tasyāśu sidhyati
]

`v 2 [
svabhāvamātraṃ yenāntarna jitaṃ dagdhabuddhinā |
tasyottamapadapraptiḥ sikatātailadurlabhā
]

`v 3 [
śuddhe'lpo'pyupadeśo hi nirmale tailabinduvat |
lagatyuttānacitteṣu nādarśa iva mauktikam
]

`v 4 [
atraivodāharantīmamitihāsaṃ purātanam |
mama pūrvaṃ bhuśuṇḍena kathitaṃ merumūrdhani
]

`v 5 [
purā bhuśuṇḍaḥ kasmiṃścitpṛṣṭa āsītkathāntare |
mayā kadācidekānte meroḥ śikharakoṭare
]

`v 6 [
mugdhabuddhimanātmajñaṃ kaṃ tvaṃ sucirajīvitam |
smarasīti mayā pṛṣṭenoktaṃ tenedamaṅga me
]

`v 7 [
bhuśuṇḍa uvāca |
āsīdvidyādharaḥ pūrvamanātmajñaḥ sukheditaḥ |
lokālokāntaraśṛṅge śuṣka āryo vicāravān
]

`v 8 [
tapasā bahurūpeṇa yamena niyamena ca |
akṣīṇāyuratiṣṭhatsa purā kalpacatuṣṭayam
]

`v 9 [
tataścaturthe kalpānte vivekastasya codabhūt |
vidūrasyeva vaidūryamaucityājjaladodayāt
]

`v 10 [
punarmṛtiḥ punarjanma jarā meti vibhāvayan |
lajje'haṃ tatkimekaṃ syātsthiramityavamṛśya saḥ
]

`v 11 [
māmājagāma saṃpraṣṭumaṣṭādaśamayīṃ purīm |
svāmupohya viraktātmā saṃsārārasatāṃ gataḥ
]

`v 12 [
sa matsamīpamāgasya kṛtodāranamaskṛtiḥ |
matpūjito'vasarata uvācedamaninditam
]

`v 13 [
vidyādhara uvāca |
mṛdūni paritāpīni dṛṣadvṛḍhabalāni ca |
chede bhede ca dakṣāṇi svaśastrāṇīndriyāṇi ca
]

`v 14 [
paryākulāni malināni vipatpradāni duḥkhormimanti guṇakānanapāvakatvāt |
hārdāndhakāragahanāni tamomayāni jitvendriyāṇi sukhameti ca kiṃ mamārthaiḥ |
14 |
imānīndriyāṇi hārdāni hṛdi rūḍhānyandhakāragahanāni sāndhakārāraṇyāni |
kāmādimarkaṭaiḥ paryākulāni | prāṇamanodehahṛdayeṣvaśanāyādiṣaḍūrmimanti |
daivātkvacidaṅkuritasya śamadamādiguṇakānanasya
pāvakatvāddāhakatvādūrmimattvepi na śītalāni | īdṛśānīndriyāṇi
cakārāttadupāśrayaṃ manaśca jitvā sukhameti na bhogaiḥ | ato mama
vaidyādharabhogalakṣaṇairarthaiḥ kiṃ prayojanam | tadvirakto jijñāsuḥ
śaraṇāgato'smītyarthaḥ
]