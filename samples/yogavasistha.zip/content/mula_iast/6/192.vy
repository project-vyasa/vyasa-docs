`v 1 [
dvinavatyadhikaśatatamaḥ sargaḥ 192
śrīrāma uvāca |
aho nu suciraṃ kālaṃ saṃbhrāntā vayamantare |
aparijñātamātreṇa saṃsāraparamāmbare
]

`v 2 [
buddhe yāvadiyaṃ nāma jagadbhrāntirna kiṃcana |
na cābhūnna ca vāstīyaṃ na ca nāma bhaviṣyati
]

`v 3 [
sarvaṃ śāntaṃ nirālambaṃ vijñānaṃ kevalaṃ sthitam |
anantaṃ cidghanaṃ vyoma nīrāgamapakalpanam
]

`v 4 [
paramākāśamevedamaparijñātamātrakam |
saṃsāratāmivāsmākaṃ gataṃ citramaho nu bhoḥ
]

`v 5 [
itthaṃ dvaitamidaṃ bhātamime lokā ime'drayaḥ |
paramākāśamityacchamevānacchamiva sthitam
]

`v 6 [
sargādau paralokādau svapnādau kalpanādike |
cideva cetyavadbhāti kuto'nyā kila dṛśyadhīḥ
]

`v 7 [
svarge vā narake vāpi sthito'smīti matiryadi |
tattasyā narakasyānto dṛśyaṃ saṃvinmayātmakam
]

`v 8 [
nedaṃ dṛśyaṃ na ca draṣṭā na sargo na jaganna cit |
na jāgratsvapnasiddhādi kimapīdaṃ tadapyasat
]

`v 9 [
kuto'syāḥ saṃbhavo bhrānteriti ceddṛśyate mune |
tadetadapi no yuktaṃ bhrāntyabhāvānubhūtitaḥ
]

`v 10 [
bhrānterasadrūpatvāttatkāraṇacintāpyayuktaivetyāha - kuta iti | dṛśyate ālocyate | 9
|
bhrāntirna saṃbhavtyeva nirvikāre jñatāpade |
yattvidaṃ bhrāntitājñānaṃ tattadevetaranna tat
]

`v 11 [
nirantare nirādyante vyomni śailodare'thavā |
kuto'nyatākalpakaṃ syājjñapade cāvikāriṇi
]

`v 12 [
mithyaivānubhavo bhrānteḥ svapne svamaraṇopamaḥ |
yadanālokanaṃ nāma śāmyatīdaṃ vilokanāt
]

`v 13 [
mṛgatṛṣṇāmbugandharvanagaradvīnduvibhramaḥ |
tathā'vidyābhramaścāyaṃ vicārānnopalabhyate
]

`v 14 [
bālavetālavadbhrāntirna vidyā jāgragāpi hi |
avicāreṇa saṃrūḍhā vicāreṇopaśāmyati
]

`v 15 [
jāgaraṇaṃ jāgraḥ ghañarthe kaḥ | jāgare pratyakṣadṛṣṭāpi na vidyā na yathārthā | 14
|
kuta āsīditimune nātra praśno virājate |
sata eva vicāreṇa lābho bhavati nāsataḥ
]

`v 16 [
prāmāṇikavicāreṇa prekṣitaṃ yanna labhyate |
tadetadasadevādi tattarhyanubhavo bhramaḥ
]

`v 17 [
yannāstīti paricchinnaṃ pramāṇaiḥ suvicāritam |
khapuṣpaśaśaśṛṅgābhaṃ tatkathaṃ labhyate sataḥ
]

`v 18 [
sarvataḥ prekṣyamāṇo'pi yaḥ kutaścinna labhyate |
tasya syātkīdṛśī sattā vandhyātanayarūpiṇaḥ
]

`v 19 [
tarhi jagadapi sadeva kiṃ na syāttatrāha - sarvata iti | kutaścitkāraṇāt pramāṇācca |
18 |
bhrāntirna saṃbhavatyeva tasmātkācitkadācana |
nirāvaraṇavijñānaghanamevedamātatam
]

`v 20 [
yatkiṃcijjagadadyātra bhātīdaṃ parameva tat |
paraṃ pare parāpūrṇe pūrṇamevāvatiṣṭhate
]

`v 21 [
na bhātaṃ na ca nābhātamiha kiṃcitkadācana |
idamitthaṃ sthitaṃ svacchaṃ śāntameva jagadvapuḥ
]

`v 22 [
kīdṛśaṃ tatpadamavatiṣṭhate tadāha - ajamiti | ahārya parairapahartumaśakyam |
āryairvidvadbhirjuṣṭaṃ samantātpūrṇamahameva nirahaṃ sat bodhāduditam |
āvaraṇaparicchedabhaṅgātsarvatovikāsi
]

`v 23 [
ajamamaramahāryamāryajuṣṭaṃ paramavikāri nirāmayaṃ samantāt |
padmahamuditaṃ tataṃ hi śuddhaṃ nirahamanekamathādvayaṃ vikāsi
]