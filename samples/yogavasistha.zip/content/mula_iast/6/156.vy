`v 1 [
ṣaṭpañcāśadadhikaśatatamaḥ sargaḥ 156
vyādha uvāca |
anantaraṃ he bhagavanvitatākāśavāsinaḥ |
kiṃ bhaviṣyati me tatra dehe'dhaḥpātini kṣitau
]

`v 2 [
muniruvāca |
śṛṇuṣvāvahitastasmindehe tava parikṣate |
kiṃ bhaviṣyati bhavyātmaṃstasminparamakāmbare
]

`v 3 [
dehe tasminparibhraṣṭe jīvastu prāṇasaṃyutaḥ |
bhaviṣyatyambare vātalavo vyātatarūpiṇi
]

`v 4 [
tasminvātalave ceto dṛśyaṃ hṛtsthaṃ sthitaṃ puraḥ |
asphāraṃ drakṣyati bhūpīṭhaṃ bhavānsvapne jagadyathā
]

`v 5 [
mahattvāccittavṛttestu jīvo drakṣyati te tataḥ |
rājāhamasmi bhūpīṭha iti saṃkalpitārthabhāk
]

`v 6 [
tatrāsya sahasaivāśu pratibhodeṣyati svayam |
ahamasmi nṛpaḥ śrīmānsindhurnāmnātimānitaḥ
]

`v 7 [
aṣṭavarṣāya me rājyaṃ gate pitari kānanam |
bhuvaścatuḥsamudrāyāḥ pitrā dattamupāgatam
]

`v 8 [
sīmānte bhūpatiḥ śatrurvidūratha iti śrutaḥ |
vidyate yaḥ prayatnena vinā nāma na jīyate
]

`v 9 [
idaṃ me kurvato rājyaṃ saṃvatsaraśataṃ gatam |
aho bhṛtyakalatraughaiḥ saha bhuktaṃ mayā sukham
]

`v 10 [
kaṣṭameṣa pravṛddho me sīmāntavasudhādhipaḥ |
anena saha saṃgrāmo dāruṇaḥ samupasthitaḥ
]

`v 11 [
iti cintayatastatra vidūrathamahībhujā |
bhaviṣyati mahadyuddhaṃ caturaṅgabalakṣayi
]

`v 12 [
mahatā tena yuddhena haniṣyasi vidūratham |
karavālalatālūnajaṅghaṃ tvaṃ viratho'pi san
]

`v 13 [
catuḥsāgaraparyante bhūtale bhūpatistataḥ |
bhaviṣyasi bhayākrāntadikpālādṛtaśāsanaḥ
]

`v 14 [
sa tvaṃ sindhurbhavanprāptasakalāvanimaṇḍalaḥ |
paṇḍitairmantribhiḥ sārdhaṃ kariṣyasi kathā imāḥ
]

`v 15 [
mantrī vadiṣyati |
atyāścaryamidaṃ deva yadevaṃ sa vidūrathaḥ |
devena vijito yuddhe nītaśca yamasādanam
]

`v 16 [
tvaṃ vakṣyasi |
bhoḥ sādho sadhanasyāsya kalpāntārṇavaraṃhasaḥ |
vairī vidūratho rājā kimarthaṃ vada duḥsahaḥ
]

`v 17 [
mantrī vadiṣyati |
līlā nāmāsya bhāryāsti tayātitapasārjitā |
mātā sarasvatīdevī jagaddhātrī nirañjanā
]

`v 18 [
gṛhītāyāḥ sutātvena sāsyā bhuvanabhāvinī |
saṃsādhayati kāryāṇi mokṣādīnyapi helayā
]

`v 19 [
vareṇa śabdamātreṇa jagadapyajagatkṣaṇāt |
karoti sā bhavannāśe tasyāḥ kaiva kadarthanā
]

`v 20 [
sindhurvadiṣyati |
tvayā vai yuktaṃ kathitaṃ yadyevaṃ tadvidūrathaḥ |
aśakyo jetumāścarya etasya samare vadhaḥ
]

`v 21 [
tadevaṃ saṃprasādena bhagavatyā samanvitaḥ |
kimityasminraṇe `note[tasminnasmin raṇe iti saṃbandhaḥ |] tasmiñjayaṃ rājā na
labdhavān
]

`v 22 [
mantrī vadiṣyati |
tena saṃprārthitā devī sarvakālamakhedinā |
mokṣo'stu mama saṃsārāditi tāmarasekṣaṇa
]

`v 23 [
tayā tena `note[hetunā |] vibho tasya sa evāvandhyasaṃvidā |
saṃpāditastena `note[rājñā vidūrathena |] tadāśrita ājau parājayaḥ
]

`v 24 [
sindhurvadiṣyati |
yadyevaṃ tanmayā devī sadaivaiṣā prapūjyate |
mokṣaṃ kimiti me naiṣā dadāti parameśvarī
]

`v 25 [
mantrī vadiṣyati |
eṣā hi jñaptirāste'ntaḥ sarvasya hṛdaye sadā |
saṃvidrūpā bhagavatī saiva proktā sarasvatī
]

`v 26 [
yena yena yathātmīyā prārthyate svayameva sā |
prayacchati tathaivāśu tasmāccidanubhūyate
]

`v 27 [
na prārthitaiṣā bhavatā mokṣārthamarimardana |
prārthitaiva tvayā saṃvidātmīyā śatruśāntaye
]

`v 28 [
sindhurvadiṣyati |
na prārthitā mayā kasmādanenaiṣā sarasvatī |
saṃvicchuddhā mayā kasmātprārthitā neha muktaye
]

`v 29 [
madāśayagatāpyeṣā jñaptiṃ dattvā sarasvatī |
manmokṣāya kimityaṅga sadrūpāpi na ceṣṭate
]

`v 30 [
mantrī vadiṣyati |
aśubhaḥ prāktamo'bhyāsastavāsti ripughātinaḥ |
tenaiṣā muktaye natvā tvayā na prārthitā vibho
]

`v 31 [
yaccittastanmayo janturbhavatītyājagatsthiteḥ |
ābālameva saṃsiddhaṃ kartuṃ śaknoti ko'nyathā
]

`v 32 [
yadeva yenāmalayāmalātma saṃvedyate'bhyāsamayaṃ vidāntaḥ |
sarvopamardena tadeva so'ṅga sadastvasadvāstu bhavatyavighnam
]