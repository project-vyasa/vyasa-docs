`v 1 [
pañcacatvāriṃśaḥ sargaḥ 45
śrīvasiṣṭha uvāca |
iti viśrāntavāneṣa manohariṇako'rihan |
tatraiva ratimāyāti na yāti viṭapāntaram
]

`v 2 [
etāvatātha kālena sa vivekadrumaḥ phalam |
antasthaṃn paramārthātma śanaiḥ prakaṭayatyalam
]

`v 3 [
dhyānadrumaphalaṃ puṇyau tadasau svamanomṛgaḥ |
adhaḥsthitaḥ prāntagataṃ tasya paśyati sattaroḥ
]

`v 4 [
ārohati naro vṛkṣaṃ tadāsvādayituṃ phalam |
anyavargaparityāgo vitatādhyavasāyavān
]

`v 5 [
vivekavṛkṣapānnāma vṛttīstyajati bhūgatāḥ |
unnataṃ padamāsādya bhūyo nādhaḥ samīhate
]

`v 6 [
tenottamaphalārthena saṃskārānprāktanānasau |
vivekapādapārūḍhastyajatyahiriva tvacam
]

`v 7 [
hasatyuccaiḥ padārūḍhamātmānamavalokayan |
etāvantamahaṃ kālaṃ kṛpaṇaḥ ko'bhavaṃ tviti
]

`v 8 [
karuṇādiṣu teṣvasya bhramañchākhāntareṣu saḥ |
lobhavyālamadhaḥ kurvansamrāḍiva virājate
]

`v 9 [
hṛdayendorgalaśreṇī duḥkhābjatimirāvaliḥ |
kṛṣṇāyaḥśṛṅkhalātṛṣṇā dinānudinamujjhati
]

`v 10 [
upekṣate na saṃprāptaṃ nāprāptamabhivāñchati |
somasaumyo bhavatyantaḥ śītalaḥ sarvavṛttiṣu
]

`v 11 [
śāstrārthapallaveṣveva niṣaṇṇātmāvatiṣṭhate |
unnatāvanatāyātāadhaḥ paśyañjagadgatīḥ
]

`v 12 [
bhīmadrumalatotkīrṇapuṣpaprakaradanturāḥ |
prāktanīḥ svāḥ sthalīḥ paśyanhasatyantarvarākatām
]

`v 13 [
teṣu tatskandhadeśeṣu tathoḍḍīnaviḍīnayā |
hāriṇyā viharañjātyā rājeva parirājate
]

`v 14 [
putradārasamagrāṇi mitrāṇi ca dhanāni ca |
janmāntarakṛtānīva svapnajānīva paśyati
]

`v 15 [
rāgadveṣabhayonmādamānamohamahattayā |
naṭasyevāsya dṛśyante śītalāmalacetasaḥ
]

`v 16 [
unmattaceṣṭitākārā hasatyapi purogatāḥ |
taraṅgabhaṅgurādhārāḥ saṃsārasarito gatīḥ
]

`v 17 [
na sa cetayate kāścillokadāradhanaiṣaṇāḥ |
apūrvapadaviśrānto jīvanneva yathā śavaḥ
]

`v 18 [
kevalaṃ kevale śuddhe bodhātmani mahonnate |
dattadṛṣṭiḥ phale tasminparaṃ samadhirohati
]

`v 19 [
smṛtvā smṛtvāpadaḥ pūrvaṃ saṃtoṣāmṛtapoṣitaḥ |
arthānāmapyanarthānāṃ nāśeṣu parituṣyati
]

`v 20 [
vyavahāreṣu kāryeṣu bhogasaṃpādakeṣvapi |
paramudvegamāyāti sanidra iva bodhitaḥ
]

`v 21 [
dīrghādhvaga ivodārāmanāratamabādhitām |
ciraṃ maurkhyaśramākrānto viśrāntimabhivāñchati
]

`v 22 [
niḥśvāsabodhito'pyagniranindhana ivātmani |
śvāsamātrasamo'pyantaratiṣṭhanneva śāmyati
]

`v 23 [
āpatantīṃ balādeva padārtheṣvaratiṃ śanaiḥ |
na śaknoti nirākartuṃ dṛṣṭimatra cyutāmiva
]

`v 24 [
tāṃ mahāpadavīṃ gacchanparamārthaphalapradām |
bhūmikāmapyupāyāti vacasāmapyagocarām
]

`v 25 [
kuto'pyaceṣṭiteṣveva saṃprāpteṣu vidhervaśāt |
bhogeṣvaratimāyāti pāntho marumahīṣviva
]

`v 26 [
ghūrṇaḥ kṣīṇa ivānandī suptaḥ saṃsāravṛttiṣu |
antaḥpūrṇamanā maunī kāmapi sthitimṛcchati
]

`v 27 [
sa tādṛgrūpatāmetya paramārthaphalasya tat |
kramānnikaṭamāpnoti khago'gapadavīmiva
]

`v 28 [
tatastadakhilāṃ buddhiṃ vihāya viyatā samaḥ |
gṛhṇātyathāsvādayati bhuṅkte'tha paritṛpyati
]

`v 29 [
saṃkalpārthaparityāgāddinānudinamātatā |
śuddhasvabhāvaviśrāntiḥ paramārthāptirucyate
]

`v 30 [
bhedabuddhirvilīnārthā'bheda evāvaśiṣyate |
śuddhamekamanādyantaṃ tadbrahmeti vidurbudhāḥ
]

`v 31 [
lokaiṣaṇāviraktena tyaktadāraiṣaṇena ca |
dhanaiṣaṇāvimuktena tasminviśramyate pade
]

`v 32 [
pareṇa pariṇāmena mithaścitparamārthayoḥ |
tāpena himalekheva bhedabuddhirvilīyate
]

`v 33 [
tajjñasyākṛṣṭamuktasya svabhāveṣūpamāṃ vinā |
sthitiḥ sragdāmakasyeva na saṃbhavati kācana
]

`v 34 [
yathā'prakaṭitāṅgāntaḥsaṃsthitā śālabhañjikā |
na satī nāsatī stambhe tathā viśvasthitiḥ pare
]

`v 35 [
dhyānaṃ na śakyate kartuṃ na caitadupayujyate |
abodhena vibuddhastu svayamatraiva tiṣṭhati
]

`v 36 [
ātyantikī virasatā yasya dṛśyeṣu dṛśyate |
sa buddho nā prabuddhasya dṛśyatyāge `note[dṛśyatyāge hi śakratā iti pāṭhaḥ
|] hi śaktatā
]

`v 37 [
dṛśyasya bodhatābodho yo bodhādaparikṣayaḥ |
sa samādhānaśabdena procyate susamāhiteḥ
]

`v 38 [
draṣṭṭadṛśyaikatārūpaḥ pratyayo manaso yadā |
sa tadekasamādhāne tadā viśrāmyati svayam
]

`v 39 [
svabhāvo dṛśyavairasyameva tattvavido nijaḥ |
dṛśyaspandanamevāhuratattvajñatvamuttamāḥ
]

`v 40 [
atajjñāyaiva viṣayāḥ svadante na tu tadvidaḥ |
na hi pītāmṛtāyāntaḥ svadate kaṭu kāñjikam
]

`v 41 [
vitṛṣṇasyātmaniṣṭhatvādeṣaṇātrayamujjhataḥ |
jñasyāpyanicchato dhyānamarthāyātaṃ pravartate
]

`v 42 [
bodhaḥ sphurati tṛṣṇāvāḥ saiva yasya na vidyate |
tasya svarūpamutsṛjya kvāsau tiṣṭhati kaḥ katham
]

`v 43 [
jñasyānārādhako dhyeyabodho nayatu yo bhavet |
anantā sā vitṛṣṇasya nnirvibhāgoditaḥ svayam
]

`v 44 [
anantamapatṛṣṇasya svayameva pravartate |
dhyānaṃn galitapakṣasya saṃsthānamiva bhūbhṛtaḥ
]

`v 45 [
śuddhabodhātmani jñatvādasamāhitatoditā |
na jātu susamiddhe'gnau ghṛtabindoravasthitiḥ
]

`v 46 [
paraṃ viṣayavaitṛṣṇyaṃn samādhānamudāhṛtam |
āhṛtaṃ yena tannūnaṃ tasmai nṛbrahmaṇe namaḥ
]

`v 47 [
nūnaṃ viṣayavaitṛṣṇye pariprauḍhimupāgate |
na śaknuvanti nirhartuṃ dhyānaṃ sendrāḥ surāsurāḥ
]

`v 48 [
paraṃ viṣayavaitṛṣṇyaṃ vajradhyānaṃ prasādhyatām |
bhede vigalite jñānādanyadhyānatṛṇena kim
]

`v 49 [
mūrkhastho viśvaśabdārtho nāmūrkhaviṣayastathā |
tajjñājñayostayoścaiva viśvaviśveśayostathā
]

`v 50 [
yatraikībhūya kacanaṃ tatra viśrāmyatāṃ budhāḥ |
bodhabhūmiṣu siddhānāmarthānāṃ vā vivekinām
]

`v 51 [
sattāsatte dvayaikye ca nirṇīte neha kenacit |
upāya ekaḥ śāstrārtho dvitīyo jñasamāgamaḥ
]

`v 52 [
dhyānaṃ tṛtīyaṃ nirvāṇe śreṣṭhastatrottarottaraḥ |
jīvādarśānmitho rūpaṃ gṛhṇātyeṣā mahadvapuḥ
]

`v 53 [
jagatyudeti saṃghaṭṭādāviśeṣaṃ same same |
jñātapūrvāparāśeṣajagadaṣṭāpadasthiteḥ
]

`v 54 [
ekasiddhau dvayoḥ siddhirbodhavaitṛṣṇyadīpayoḥ |
mativātyādhuto vyomni dagdho jñānāgninākhilaḥ
]

`v 55 [
jagattūlaḥ pare śānte na jāne kvāśu gacchati |
citrāgnineva bodhena tena jāḍyaṃ na śāmyati
]

`v 56 [
nirmūlāpi jagadbhrāntiryenāśu na vilīyate |
yathā'jñasya jagajjñaptirapajñānātpradīpyate
]

`v 57 [
tathā jñasya parijñānāttadajñaptiḥ pradīpyate |
tajjñasyājñajagajjñaptiśabdārtharahitā sthitā
]

`v 58 [
yathāsthitaiva trijagajjñaptiścitra ivoditā |
śūnyatvenaiva racitā suptatveneva nirmitā
]

`v 59 [
bhāsate bhāmayī vāñchā jagajjñaptirjñacetasi |
nūnaṃ bodhe'vimūḍhasya nāhaṃtā na jagatsthitiḥ
]

`v 60 [
bhāsate paramābhāsarūpiṇaḥ kāpyavasthitiḥ |
bodhābodhātmakaṃ cittaṃ bhāti śuṣkārdrakāṣṭhavat
]

`v 61 [
bodhādekaṃ jagadbhāvairjāḍyānnātmatvamāgatam |
mitho bodhāddvivadatimaitrīṃ bhajati bodhataḥ
]

`v 62 [
ya evāsyādhiko bhāgastanmayatvena tiṣṭhati |
budhaḥ satattvaṃ nāvaiti jagato'bhāvabhāvayoḥ
]

`v 63 [
jāgratsvapnasuṣuptānāṃ svabhāvamiva turyagaḥ |
vāsanaiva manaḥ seyaṃn svavicāreṇa naśyati
]

`v 64 [
avastutvādato mokṣo nātmanāśe pravartate
]

`v 65 [
dhyānadrumātsvayamupoḍhamanalpapākātkālena bodhamupayātavataḥ krameṇa |
bhuktvā rasāyanaphalaṃ parabodhamādyamicchanmanohariṇako nigaḍādvimuktaḥ |
65 |
tathā cāyaṃ manonāśo manohariṇaveṣeṇa varṇitasyātmano nigaḍamokṣaprāyaḥ phalita
ityupasaṃharati - dhyāneti | icchanmumukṣuḥ prastuto manohariṇako
varṇitarūpādaṅkurakāṇḍaśākhāpallavapuṣpaphalāntapariṇāmalakṣaṇānalpa##-
dhyānadrumādādyaṃ parabodho'khaṇḍākāravṛttyabhivyaktaḥ
paramānandastallakṣaṇaṃ rasāyanaphalaṃ bhuktvā saṃsāranigaḍādvimukto
bhavatītyarthaḥ
]