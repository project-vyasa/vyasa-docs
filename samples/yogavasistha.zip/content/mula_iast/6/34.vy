`v 1 [
catustriṃśaḥ sargaḥ 34
śrīvasiṣṭha uvāca |
prāpteṣu sukhaduḥkheṣu yo naśyati sa naśyati |
yo na naśyatyanāśo'sāvalaṃ śāstropadeśanaiḥ
]

`v 2 [
dṛṣṭasṛṣṭirjagattasyādarśanādeva saṃkṣayaḥ |
iti yatprastutaṃ tasya varṇyante'tropapattayaḥ |
vedanotthaṃ jagadahaṃ citi śāmyatyavedanāt iti yaduktaṃ
tatropapattīrvivakṣurbhagavānvasiṣṭhaḥ prathamaṃ naśvarībhyaḥ
sukhaduḥkhānubhavatripuṭībhyaḥ pṛthakkṛtyānaśvaramātmānaṃ
darśayaṃstaddarśanādeva sarvaśāstropadeśānāṃ caritārthatetyāha - prāpteṣviti |
1 |
yasya cecchodayastasya santyavaśyaṃ sukhādayaḥ |
te cetsamyakcikitsyante pūrvamicchaiva mucyatām
]

`v 3 [
ahaṃ jagadidaṃ bhrāntirnāstyeva parame pade |
idaṃ śāntamanālambaṃ sarvaṃ nirvāṇamavyayam
]

`v 4 [
ahaṃ brahma jagacceti śabdasaṃbhramavibhramaḥ |
sarvasmiñchānta ākāśe kena nāmopakalpitaḥ
]

`v 5 [
nehāstyahaṃ na ca jaganna ca brahmādiśabdakāḥ |
śāntasyaikasya sarvatvātkartā bhokteha kaḥ kutaḥ
]

`v 6 [
upadeśyātiśāyitvātsarvāpahnava eva ca |
kṛto'yaṃ sa ca satyātmā ta evāhaṃ viśiṣyate
]

`v 7 [
agrasthasiddhasaṃcāro jñāyate nāpi dāruṇaḥ |
yathaikapārśvasaṃsuptanaraḥ svapnābhragarjitam
]

`v 8 [
jñaptau nāsti yatastena siddhācāro na lakṣyate |
svabhāva iti sarveṇa jñaptistho hyanubhūyate
]

`v 9 [
jñaptirapyātmabhūtaiva sarvaṃ bhāti hi tanmayam |
tasmātsāhaṃ jagatsarvamabhinnaṃ paramātmanaḥ
]

`v 10 [
jñaptirjagattayā bhāti saṃkalpasvapnayoriva |
anānāvayavodeti jalamūrmitayā yathā
]

`v 11 [
ekātmaivodaye jñapternānātāmiva cāgataḥ |
ajñānātsa tvavastutvātprekṣito nopalabhyate
]

`v 12 [
yathā svāvayavāneva sarvānavayavī bhavet |
nityānavayavaṃ śāntaṃ brahmaivedaṃ tathā jagat
]

`v 13 [
bhāṇḍalakṣāṇi dhatte'ntaścidrūpakanakeṣṭikā |
yadeva sā cetayate jagadādīva vetti tat
]

`v 14 [
brahmaiva kacatīvedaṃ sattayācchajagattayā |
cidrūpatvāddravātmatvāttaraṅgāditayābdhivat
]

`v 15 [
yadyaccetayate'ntastu jagadādīva paśyati |
arūpamapi rūpaṃ svaṃ yanna cetayate na tat
]

`v 16 [
cetanācetanatvoktī tasyeśatvātsvadehage |
upadeśārthamevokte na sadviṣayamarthataḥ
]

`v 17 [
na jagatsanna caivāsadbhāsate cetanācciti |
acetanānna kacati ka ivārthagraho'tra naḥ
]

`v 18 [
acetanaṃ cetanaṃ ca spandāspandavadātmanaḥ |
svāyatte na kadarthasthe svasthapāṣāṇavatsthite
]

`v 19 [
yasyekṣitasya no sattā nādhāro na ca kāraṇam |
so'hamityeva yo yakṣo na jāne kuta utthitaḥ
]

`v 20 [
yasyāhamiti yakṣasya sattaivāsti na satyataḥ |
aho nu citraṃ teneme bhavanto vivaśīkṛtāḥ
]

`v 21 [
kākatālīyavadbhrāntamahaṃ brahmaṇi bhāsate |
svameva rūpaṃ dṛgbhrāntau keśoṇḍrakamivāmbare
]

`v 22 [
brahmaivāhaṃ jagaccātra kuto nāśasamudbhavau |
ato harṣaviṣādānāṃ kiṃtveva kathamāspadam
]

`v 23 [
sarveśvaratvādīśasya vibhātīdaṃ pracetitam |
acetitaṃ ca no bhāti tenācetitamastu te
]

`v 24 [
varṇitāṃ dṛṣṭasṛṣṭikalpanāmamūdya tatphalamāha - sarveśvaratvāditi | te tava
acetitaṃ jagadadarśanamastu | tadeva sarvadṛśyamārjanarūpā muktiḥ phalamityarthaḥ |
23 |
kākatālīyavaccittvājjagato bhāti brahma kham |
svapnasaṃkalpapuravattattasmādbhidyate katham
]

`v 25 [
varṇitarītyā jagato'pi cittvādbrahma khameva
svapnasaṃkalpapuravatkākatālīyavadakasmādanyathā bhāti | vastutastu
tajjagattasmātkathaṃ bhidyate tadbhede sattāsphūrtyalābhenālīkatvaprasaṅgādityarthaḥ |
24 |
yathormyādi jale vṛkṣe yathā vā śālabhañjikā |
yathā ghaṭādayo bhūmau tathā brahmaṇi sargatā
]

`v 26 [
anākṛtāvasaṃsthāne svacche yadanubhūyate |
tattadevāta uditaṃ kiṃnāmāhaṃ jaganti kim
]

`v 27 [
marutaḥ spandavaicitryaṃ sattayaiva yathā tathā |
brahmaṇo niḥsvabhāvasya jagadādyahamādi ca
]

`v 28 [
yathābhre lakṣyate vṛkṣagajavājimṛgāditā |
asanniveśākṛtini sargāhante tathāpare
]

`v 29 [
sargo'vayavavadbhāti sarva eva pare śive |
evaṃ tadupamāṃ viddhi kāryakāraṇavadyathā
]

`v 30 [
antaḥśāntamanāyāsamanupādhi gatabhramam |
jagatyasaṃbhavādeva vyomavatsamamāsyatām
]

`v 31 [
na bhavanto na ca vayaṃ na jaganti na khādayaḥ |
santi śāntamaśeṣeṇa brahmedaṃ nirbharaṃ sthitam
]

`v 32 [
aśeṣeṣvaviśeṣeṣu śāntāśeṣaviśeṣatā |
satyā saivāhamityāśutyaktvā mokṣāya bhāvyatām
]

`v 33 [
vedanaṃ bandhanaṃ viddhi viddhi mokṣamavedanam |
yathāsthitaṃ yathācāraṃ bhava śāntamavedanam
]

`v 34 [
draṣṭā na dṛśyatāṃ yāti citirnāyāti cetyatām |
cetyābhāvādajagati kaḥ kiṃ cetayate katham
]

`v 35 [
draṣṭṭadṛśyadaśābhāvājjāgratyeva suṣuptivat |
śaradākāśakośābhamasattopamamāsyatām
]

`v 36 [
tathaikabrahmacidrūpe pavanaspandane yathā |
atrācidbodhatā sargo mokṣo brahmaikabodhatā
]

`v 37 [
citspando brahmamaruto yatra sarga iti smṛtaḥ |
nātra citspandanaṃn yatsyānnirvāṇaṃ tadudāhṛtam
]

`v 38 [
bījamantaryathā vetti svarūpaṃ pallavādikam |
tathā mahācidantasthaṃ svarūpaṃ vetti sargatām
]

`v 39 [
patrādivedanādbījaṃ yathā patrādi tiṣṭhati |
parā citsargasaṃvittistathā bhavati sargatā
]

`v 40 [
yathā bhāvavikārābhāścitparāḥ sargatāstathā |
sarve bījāni dṛṣṭāntāstadrūpā eva tanmayāḥ
]

`v 41 [
nirvikāraparabrahmamayaṃ sarvamidaṃ jagat |
nirvikāramanādyantamevaṃ viddhi nirāmayam
]

`v 42 [
nijasaṃkalpamātrātmā nijasaṃkalpanātkṣayī |
dvaitādvaitavikāro'yaṃ saṃkalpanagaraṃ yathā
]

`v 43 [
śūnyatvākāśayorbhedo yādṛśo'vagatastvayā |
bhedaṃ nirātmakaṃ viddhi tādṛśaṃ brahmasargayoḥ
]

`v 44 [
mahācidrūpiṇī śāntā yā sattā brahmaṇaḥ purā |
svataḥ seyamahaṃtvaṃ ca mānavo'smītyabodhataḥ
]

`v 45 [
brahmaṇyasmiñjagadrūpe na kiṃcidapi jāyate |
jātamapyatha naṣṭaṃ ca na naśyatyambuvīcivat
]

`v 46 [
padārthabrahmarūpeṇa brahmaivātmani tiṣṭhati |
avayavīvāvayave khe khaṃ vārīva vāriṇi
]

`v 47 [
nimeṣādardhabhāgena deśāddeśāntarasthitau |
yadrūpaṃ saṃvido madhye sa svabhāva upāsyatām
]

`v 48 [
saṃkṣubdhamakṣubdhamiti dvirūpaṃ saṃvitsvarūpaṃ pravadanti santaḥ |
śreyaḥ paraṃ yena samīhase tvaṃ tadekaniṣṭho bhava mā'matirbhūḥ
]