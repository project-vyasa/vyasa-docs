`v 1 [
trinavatyadhikaśatatamaḥ sargaḥ 193
śrīrāma uvāca |
anādimadhyaparyantaṃ na devā narṣayo viduḥ |
yatpadaṃ tadidaṃ bhāti kva jagatkva ca dṛśyatā
]

`v 2 [
dvaitādvaitasamudbhedavākyasaṃdehavibhramaiḥ |
alamasmākamāśāntamādyaṃ rūpamanāmayam
]

`v 3 [
vyomani vyomabhāvānāṃ praśāntaṃ yādṛgāsitam |
tādṛkcidvyomani sphāratrijagadvyomabhāsanam
]

`v 4 [
yathā vyomani vyomatvaṃ dṛṣattvaṃ dṛṣadi sthitam |
jalatvaṃ ca jalasyāntarjagattvaṃ cidghane tathā
]

`v 5 [
sāhaṃtādijagaddṛśyamāśākāśavisāryapi |
mahācidudaraṃ viddhi khaṃ śāntaṃ śūnyatoditam
]

`v 6 [
jīvasyāsminvimūḍhasya pare'parimitodaye |
prasphuraṃścāpi saṃsārapiśāca upaśāmyati
]

`v 7 [
bhedopalabdhirgalati vyavahāravato'pyalam |
jaḍasyevājaḍasyaiva vīceriva jalodare
]

`v 8 [
kvāpyajñānaravau yāte pratāpādyākare bhṛśam |
saṃsārasattādivaso yātyastaṃ sa niśāgamaḥ
]

`v 9 [
bhāvābhāveṣu kāryeṣu jarāmaraṇajanmasu |
jña ājavaṃ javībhāve tiṣṭhannapi na tiṣṭhati
]

`v 10 [
nāvidyāsti ha na bhrāntirna duḥkhaṃ na sukhodayaḥ |
vidyā'vidyā sukhaṃ duḥkhamiti brahmaiva nirmalam
]

`v 11 [
parijñātaṃ sadetattu yāvadbrahmaiva nirmalam |
aparijñātamasmākamabrahmātma na vidyate
]

`v 12 [
prabuddho'smi praśāntā me sarvā eva kudṛṣṭayaḥ |
śāntaṃ samaṃ sohamidaṃ khaṃ paśyāmi jagattrayam
]

`v 13 [
samyagjñātaṃ yāvadidaṃ jagadbrahmaiva kevalam |
ajñātātmābhavadbrahma jñātātmanyadhunā sthitam
]

`v 14 [
jñātājñātamanirbhāsaṃ brahmaikamajaraṃ tathā |
śūnyatvaikatvanīlatvarūpamekaṃ nabho yathā
]

`v 15 [
nirvāṇabhāse gataśaṅkamāse nirīhamāse susukhe'hamāse |
yathāsthitaṃ nityamanantamāse tadevamāse na kathaṃ samāse
]

`v 16 [
sarvaṃ sadaivāhamanantamekaṃ na kiṃcidevāpyathavātiśāntaḥ |
sarvaṃ na kiṃcicca sadekamasmi na cāsmi cetīyamaho nu śāntiḥ
]

`v 17 [
adhigatamadhigamyaṃ prāptamaprāptamanyairgatamidamalamastaṃ vastujātaṃ
samastam |
uditamuditabodhaṃ tādṛśaṃ yatra bhūṣo'stamayasamudayānāṃ nāma nāmāpi
nāsti
]