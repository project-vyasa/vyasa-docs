`v 1 [
dvāviṃśatyadhikaśatatamaḥ sargaḥ 122
śrīvasiṣṭha uvāca |
tataḥ prabhāte prasabhaṃ pṛthivyāḥ kṛtvā yathāśāstramalaṃ vyavasthām |
āviṣṭadehā iva te rasena niṣedhyamānā iva mantrimukhyaiḥ
]

`v 2 [
nivārya sarvaṃ parivāramātramākrandamānaṃ vadanai rudadbhiḥ |
nirasya cāsnehatayābhimānamātsaryalobhābhibhavaiṣaṇādi
]

`v 3 [
digantamālokya samudrapāre kṣaṇātsamāyāma iti bruvantaḥ |
svamantraśaktyottamatāṃ gataistairabdhiḥ `note[adbhiḥ iti mudritapāṭhaścintyaḥ |
] padaireva tadā praviṣṭaḥ
]

`v 4 [
vipaścitaste diśi diśyanalpairbhṛtyaiḥ samudraṃ praviśadbhireva |
bhṛtyaiśca kaiścittvanugamyamānā yayuryathā vāriṇi padbhireva
]

`v 5 [
taraṅgajāleṣu padāni kṛtvā pṛṣṭhe sthalasyeva jalasya cāntaḥ |
catvāra ekaikatayaiva yuktā bhṛśaṃ viyuktā nijasenayā te
]

`v 6 [
padakrameṇaiva mahārṇavāntastāvatpraviṣṭā avalokitāste |
taṭasthitairyāvadadṛśyabhāvaṃ śarannabhomeghalavā ivāpuḥ
]

`v 7 [
tamadhvānamathohuste jaladhau pādacāriṇaḥ |
vitatādhyavasāyena baddhakakṣāharā iva
]

`v 8 [
vitatenādhyavasāyena dṛḍhaniścayena | hastipakasthānīyena preryamāṇāste vipaścito
baddhāṃ kakṣāṃ haranti tathāvidhā gajā iva taṃ jalādhvānaṃ ūhuḥ ativāhayāmāsuḥ |
7 |
unnatāvanatāmadrisamārohāvarohaṇaiḥ |
śriyaṃ vāritaraṅgāṇāṃ haranto harimūrtayaḥ
]

`v 9 [
āvarteṣu tṛṇānīva bhrāntā vigatasaṃbhramam |
ciraṃ cañcalamattābhracandramaṇḍalaśobhiṣu
]

`v 10 [
mantravidyābalaujobhirdurjayāḥ śastrapāṇayaḥ |
kvacitpramattairmakarairnigīrṇodgīrṇadehakāḥ
]

`v 11 [
jalakallolaviśrāntavātotsāritamūrtayaḥ |
nītānītāḥ kṣaṇenaiva yojanānāṃ śataṃ śatam
]

`v 12 [
jalakallolamātaṅgatuṅgitāṅgatayā tayā |
dadhānā nijarājyebhapṛṣṭharohasthitiśriyam
]

`v 13 [
jalakallolalakṣaṇairmātaṃgaistuṃgitāṅgatayā ārohitāṅgatayā apūrvacamatkāriṇyā |
12 |
vistīrṇormighaṭāpaṭṭapāṭapaṭṭanapāṭavaiḥ |
darśayanto jalāmbhodaniṣkrāntiṃ mārutā iva
]

`v 14 [
tarattaralamātaṅgataraṅgaughavighaṭṭitāḥ |
atyajanto nijaṃ dhairyaṃ velāvarataṭā iva
]

`v 15 [
mahormimuktāmāṇikyamaṇḍalapratibimbitāḥ |
ekākino'pi paritaḥ pauruṣeyavṛtā iva
]

`v 16 [
pāṇḍuḍiṇḍīrapiṇḍeṣu kurvanto lāghavātpadam |
śvetapadmaparikrāntarājahaṃsaśriyaṃ dadhuḥ
]

`v 17 [
ghananirghātanirghoṣabhīṣaṇārṇavaghuṃghumāt |
na bhītā bhūbhṛtastatra velāvalanajṛmbhitāt
]

`v 18 [
abhraṃlihajalādrīndrapātotpātavighaṭṭitāḥ |
kṣaṇaṃ pātālamājagmuḥ kṣaṇamarkāspadaṃ yayuḥ
]

`v 19 [
aśaṅkitotpatadvāripūrapātapaṭāvṛtāḥ |
utpātapātanipatadvitānakavṛtā iva
]

`v 20 [
prakrāntāstemburāśau sahacaramakarāḥ śūranakraiḥ
kulīrairvyāptāvartāvivṛttāḥ salilatarulatāsīkarairantarālaiḥ |
kurvaṃtaḥ kāntiyuktaṃ vapuriva
kusumairbhrāṃtamāṇikyamuktairvyaktāvyaktāṃśujālaiḥ
pratipadamitarairabhrarūpairadabhraiḥ
]