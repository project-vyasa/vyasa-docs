`v 1 [
trayastriṃśaḥ sargaḥ 33
śrīvasiṣṭha uvāca |
svapauruṣeṇa svadhiyā satsaṃgamavikāsayā |
yadi nā nīyate jñatvaṃ tadupāyo'sti netaraḥ
]

`v 2 [
svaṃ kalitaṃ kalpitaṃ ca pratikalpanayā svayā |
tadevānyatvamādatte viṣatvamamṛtaṃ yathā
]

`v 3 [
kalpanā cākalpanāntā muktatā yadakalpanam |
etacca bhogasaṃtyāgapūrvaṃ sidhyati nānyathā
]

`v 4 [
vacasā manasā cāntaḥ śabdārthāvavibhāvayan |
ya āste vardhate tasya kalpanopaśamaḥ śanaiḥ
]

`v 5 [
varjayitvāhamityeva nāvidyāstītarātmikā |
śānte tvabhāvanādasminnānyo mokṣo'sti kaścana
]

`v 6 [
tato'nahaṃbhāvalakṣaṇā sā kāryetyāha - varjayitveti |
abhāvanātsarvabhāvanānivartakatattvasākṣātkārāt | asminnahaṃkāre śānte bādhite sati |
5 |
ahaṃbhāvamathādehaṃ kiṃcicchrayasi naśyati |
jagadādirucistasmiṃstyakte śāmyasi sidhyasi
]

`v 7 [
acetanādidaṃ sarvaṃ sadevāsadiva sthitam |
śāntaṃ yasyopalasyeva namastasmai mahātmane
]

`v 8 [
acetanādidaṃ sarvamupalasyeva śāmyati |
śūnyākhyātaḥ parālīnacittasya cittvabhāvanāt
]

`v 9 [
idamastvathavā māstu cetitaṃ duḥkhavṛddhaye |
acetitaṃ sukhāyāntaracetanamacetanāt
]

`v 10 [
dvau vyādhī dehino ghorāvayaṃ lokastathā paraḥ |
yābhyāṃ ghorāṇi duḥkhāni bhuṅkte sarvairhi pīḍitaḥ
]

`v 11 [
ihaloke yatante jñā vyādhau bhogairdurauṣadhaiḥ |
ājīvitaṃ yathāśakti cikitsā nāparāmaye
]

`v 12 [
paralokamahāvyādhau prayatante cikitsanam |
śamasatsaṅgabodhākhyairamṛtaiḥ puruṣottamāḥ
]

`v 13 [
paralokacikitsāyāṃ sāvadhānā bhavanti ye |
mokṣamārgamahecchāyāṃ śamaśaktyā jayanti te
]

`v 14 [
ihaiva narakavyādheścikitsāṃ na karoti yaḥ |
gatvā nirauṣadhaṃ sthānaṃ sarujaḥ kiṃ kariṣyati
]

`v 15 [
nanu paralokavyādhestatraiva cikitsā kariṣyate kimatra taccintayā tatrāha - ihaiveti |
nirauṣadhaṃ sādhusaṃgamasacchāstrādyauṣadhaśūnyaṃ narakasthāvarādisthānam | 14
|
ihalokacikitsābhirjīvitaṃ yātu mā kṣayam |
ātmajñānauṣadhairajñāḥ paralokaścikitsyatām
]

`v 16 [
āyurvāyucalatpatralavāmbukaṇabhaṅguram |
paralokamahāvyādhiryatnenāśu cikitsyatām
]

`v 17 [
paralokamahāvyādhau yatnenāśu cikitsite |
ihalokamayo vyādhiḥ svayamāśūpaśāmyati
]

`v 18 [
saṃvinmātraṃ vidurjantuṃ tasya prasaraṇaṃ jagat |
paramāṇūdare'pyasti tacchailaśatavistaram
]

`v 19 [
yatsaṃvidaḥ prasaraṇaṃ rūpālokamanāṃsi tat |
vyomanyevānubhūyante nātaḥ satyo jagadbhramaḥ
]

`v 20 [
pralayeṣvapi dṛṣṭeṣu jagaddṛśyākhyavibhramaḥ |
na naśyati na jāyeta bhrāntimātraikarūpiṇaḥ
]

`v 21 [
bhogapaṅkārṇave magna ātmā nottāryate yadi |
svapauruṣacamatkṛtyā tadupāyo'sti netaraḥ
]

`v 22 [
ajitātmā jano mūḍho rūḍho bhogaikakardame |
āpadāṃ pātratāmeti payasāmiva sāgaraḥ
]

`v 23 [
jīvitasya yathā bālyaṃ dṛṣṭaṃ prāthamakalpikam |
nirvāṇasya tathā bhogasaṃtyāgo rāgaśāntidaḥ
]

`v 24 [
tajjñasya jīvitanadī sakallolāpyasaṃbhramā |
samaṃ vahati saumyaiva citrasaṃsthena nīrasā
]

`v 25 [
ajñajīvitanadyāstu `note[nadyastu iti pāṭhaḥ |] rasanātyantabhīṣaṇāḥ |
āvartā vṛttivikṣobhakallolāḥ sahavāhinaḥ
]

`v 26 [
sargavargāḥ pravalganti saṃvitprasaraleśakāḥ |
dvicandrabālavetālamṛgāmbusvapnamohavat
]

`v 27 [
saṃvidvāritaraṅgaughā bhānti sargāḥ sahasraśaḥ |
vicāritāstvasatyāste satyāstvanubhavabhramāt
]

`v 28 [
jagantyākāśakośe'pi saṃvitprasaraṇabhramāt |
santīvāpyanubhūyante na tu satyāni tāni tu
]

`v 29 [
saṃvidvikāsapayaso budbudaḥ sargavibhramaḥ |
ahamityādisadbhāvavikārākārarūpavān
]

`v 30 [
saṃvinnirvāṇamajagatsaṃvidunmīlanaṃ jagat |
nāntarna bāhyaṃ nāsatyaṃ na satyaṃ sarvameva tat
]

`v 31 [
cidrūpamajamavyaktamekamavyayamīśvaraḥ |
svatvabhāvatvarahitaṃ brahma śāntātmakhādapi
]

`v 32 [
brahmaṇo niḥsvabhāvasya sargasaṃvedane svataḥ |
spandane pavanasyeva kāraṇaṃ nopayujyate
]

`v 33 [
svapnānubhavavadbhrāntirbrahmābdhau brahmavīcayaḥ |
sargatā vastutastvatra na svapno na ca sargatā
]

`v 34 [
ekameva nirābhāsamacittvamajaḍaṃ samam |
na sannāsanna sadasadidamavyayamadvayam
]

`v 35 [
yathāsthitasyaiva sato yasyāsaṃvedanātmakam |
saṃvitpraśamanaṃ jātaṃ tamāhurmunisattamam
]

`v 36 [
sato'pi mṛnmayasyeva yasyāsaṃvedanātmakam |
sāhaṃ jagadvigalitaṃ tamāhurmunisattamam
]

`v 37 [
yathā śāmyatyasaṃkalpātsaṃkalpanagaraṃ tathā |
vedanotthaṃn jagadahaṃ citi śāmyatyavedanāt
]

`v 38 [
saṃkalpasṛṣṭerasaṃkalpanamiva dṛṣṭasṛṣṭerasyā adṛṣṭireva nivṛttirityāha ##-
svabhāvavarjaṃ śabdārthāḥ sarva eva sahetukāḥ |
svabhāvasya tu yo heturmuktistadanubhāvanam
]

`v 39 [
na kasyacitpadārthasya svabhāvo'stīha kaścana |
mahācidambudravatāḥ sarvā evānubhūtayaḥ
]

`v 40 [
mahācidanilaspandā etā evānubhūtayaḥ |
etāstā brahmagaganaśūnyatā iti budhyatām
]

`v 41 [
vātaspandāvibhābhinnau brahmasargau vibhinnatā |
tayostvasatyā svabhrāntau svapne svamaraṇopamā
]

`v 42 [
bhrāntistu tāvattattvārthavicāro yāvadasphuṭaḥ |
vicāre tu sphuṭe bhrāntirbrahmatāmeva gacchati
]

`v 43 [
bhrāntistvasatyā vastveva prekṣayāto na labhyate |
śaśaśṛṅgavadatyacchamato brahmaiva śiṣyate
]

`v 44 [
anādimadhyāntamanantamacchaṃ samaṃ śivaṃ śāśvatamekameva |
sarvāṃ jarāmohavikārabhārabhrāntiṃ vimucyāmbarabhāvamehi
]