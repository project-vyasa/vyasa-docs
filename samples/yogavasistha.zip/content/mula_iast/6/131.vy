`v 1 [
ekatriṃśadadhikaśatatamaḥ sargaḥ 131
daśaratha uvāca |
kliṣṭo'yaṃ yadavidyārthaṃ vipaścidavipaścitaḥ |
tadahaṃ ceṣṭitaṃ manye kaṣṭo'vastuni kiṃgrahaḥ
]

`v 2 [
śrīvālmīkiruvāca |
asminnavasare tatra rājñaḥ pārśve vyavasthitaḥ |
prasaṅgapatitaṃ vākyaṃ viśvāmitro'bhyuvāca ha
]

`v 3 [
aprāptottamabodhānāṃ bodhavedyā vilakṣaṇāḥ |
bhavantyevaṃvidhā rājanbahūnāṃ bahavo bhṛśam
]

`v 4 [
adya saptadaśaṃ varṣalakṣamakṣīṇaniścayāḥ |
evameva bhramanto'syāṃ vaṭadhānā bhuvi sthitāḥ
]

`v 5 [
bhūmerantāvalokārthamadyāpyudvegavarjitam |
pravṛttā na nivartante vahanātsarito yathā
]

`v 6 [
ayaṃ khalu mahāloko vartulo vyomni saṃsthitaḥ |
bālasaṃkalpataruvadbrāhmasaṃkalpaniścayaḥ
]

`v 7 [
kanduke vyomni saṃruddhe daśadikkaṃ pipīlikāḥ |
itthaṃ bhramanti bhūtāni tadādhārāṇi nityadā
]

`v 8 [
bhūgolakādhobhāgāni tadaṅgānyūrdhvavanti ca |
tadā bhūtāni tiṣṭhanti tānyāviśya bhramanti ca
]

`v 9 [
tamevāviśya dūreṇa saritaścarkṣamaṇḍalam |
asaṃsparśā bhramantyuccaiḥ sacandrārkādi saṃtatam
]

`v 10 [
ihaiva sarvadikkaṃ dyaustāmāveṣṭya vyavasthitā |
sarvadikkaṃ khamatyūrdhvaṃ tasyādhastānmahītalam
]

`v 11 [
bhāvāḥ patanto dhāvanti tasyādhaḥ sarvatoṅgakam |
yatrotpatanto gacchanti tadūrdhvamiti śabditam
]

`v 12 [
tatraikadeśe vidyante vaṭadhānābhidhānakāḥ |
jātāsteṣāṃ trayo rājan rājaputrāḥ purābhavan
]

`v 13 [
te hyevamekasaṃkalpā bhūmyāderdṛśyavartmanaḥ |
ko'ntaḥ syāditi niryātā vihartuṃ dṛḍhaniścayāḥ
]

`v 14 [
punarvāri punarbhūmisteṣāmākramatāṃ ciram |
navalabdhaśarīrāṇāṃ dīrghakālo vyavartata
]

`v 15 [
svacchakandukavamrīkanyāyenāniśamatra te |
bhramanto nāpnuvantyantamanyatvaṃ saṃvidanti ca
]

`v 16 [
svacche kanduke saṃlagnā ye vamrīkīṭāstannyāyena bhramantaste | valmīkanyāyena iti
pāṭhe valmīkapadena tannirmātāro vamrīkīṭā eva lakṣyante | anyatvaṃ deśāntaratvam |
15 |
vyomasthakandukabhrāntapipīlikavadākulam |
adyāpi saṃsthitā rājanna ca khedaṃ vrajanti te
]

`v 17 [
deśaṃ bhūgolakasyāsya yaṃ yamāsādayanti ca |
iheva tatra tatroccairadhaścordhvaṃ tathā diśaḥ
]

`v 18 [
te vadanti mahārāja yadyasmābhiritodyataiḥ |
na tāvadantaḥ saṃprāptaḥ saṃcarāma itaḥ param
]

`v 19 [
itthaṃ na kiṃcidevedaṃ brahmasaṃkalpaḍambaram |
kiṃcitsaṃkalpamajñānamanantaṃ svapnadṛśyavat
]

`v 20 [
kalpanaṃ tatparaṃ brahma paraṃ brahmaiva kalpanam |
cidrūpaṃ nānyorbhedaḥ śūnyatvākāśayoriva
]

`v 21 [
saṃkalpakalpanasya cidadhiṣṭhānakatvāccinmātraṃ tattvamiti vyatihāreṇa draḍhayati ##-
cinmātraṃ yadyadābhātaṃ jalavāhavivartavat |
tattādṛkkathamanyābhamanyasyāsaṃbhavādbhavet
]

`v 22 [
abhāvaḥ khe ca khamidaṃ sargādau paramāmbaram |
svayaṃ jagadivābhāti nānyatpralayasargakau
]

`v 23 [
yathā kaṣati cidrūpaṃ tathaiva ratimetya tat |
dṛṣṭādṛṣṭaiḥ svasaṃsāraiściramāste yathā ciram
]

`v 24 [
dṛśyātmakaṃ rūpamekamekamasyaivamakṣayam |
svayamevamajaṃ bhāti yanna bhātīva kiṃcana
]

`v 25 [
cidaṇorudare santi samastānubhavāṇavaḥ `note[anubhavārṇavāḥ iti pāṭhaścintyaḥ
|] |
śilāḥ śailodara iva svacchāḥ khātmani khātmikāḥ
]

`v 26 [
svabhāvaniṣṭhāstiṣṭhanti `note[atra svabhāvabhūtā iti pāṭho vyākhyānukūlaḥ syāt
|] te yadavyākṛtātmani |
mā tiṣṭhanti tu vai te yadavyāvṛttāḥ pare pade
]

`v 27 [
tadeva jagadityuktaṃ brahma bhārūpamātatam |
pūrvāparaparāmarśānnipuṇaṃ nipuṇāśayāḥ
]

`v 28 [
atyāścaryamanaṣṭo'yaṃ paramātsadanātsvayam |
nānātvabuddhyā nānaiva jīvo'hamiti tāmyati
]

`v 29 [
ucyatāṃ bhāsa bho rājanvipaścidaparākhya he |
kiyaddṛṣṭaṃ kiyadbhrāntaṃ dṛśyaṃ smarasi kiṃ ca vā
]

`v 30 [
bhāsa uvāca |
bahu dṛṣṭaṃ mayā dṛśyaṃ bahu bhrāntamakhedinā |
bahveva bahudhā nūnamanubhūtaṃ smarāmyaham
]

`v 31 [
mayāanubhūtāni mahānti rājaṃściraṃ sudūre vividhaiḥ śarīraiḥ |
sukhāni duḥkhāni jagantyanantānyanantamāsādya mahāmbaraṃ tat
]

`v 32 [
vicitradehairvaraśāpayogāddṛśyānyanantāni mayā mahātman |
janmāntarāvartavivartanāni dṛḍhaikacittena varātkṛśānoḥ
]

`v 33 [
dṛśyātmakorvīvapuṣastvavidyādṛśo javenāntaparīkṣaṇāya |
dehena dehena jagatprati prāk smṛteḥ sadāhaṃ ghanayatnamāsam
]

`v 34 [
samāḥ sahasraṃ viṭapo'hamāsamantarmanāścetanabhuktaduḥkhaḥ |
cittaṃ vinā puṣpaphalapratāne vā kandavattattarasāṅgarāgaḥ
]

`v 35 [
samāḥ śataṃ merumṛgo'hamāsaṃ suvarṇavarṇastaruparṇakarṇaḥ |
dūrvāṅkurāsvādanagītiniṣṭha ahankaniṣṭho vanavāsimadhye
]

`v 36 [
pādāṣṭakairāvalitātmapṛṣṭho mṛte'mbhasaḥ kleśakṛtātmamṛtyuḥ |
samāḥ śatārdhaṃ śarabho'hamāsaṃ krauñcācale kāñcanakandarāsu
]

`v 37 [
kālāgurudrumalatāvalitānilena vidyādharīsuratadharmakalāmṛtāni |
pītāni me malayasānuni mandare ca mandāracandanakadambalatāgṛheṣu
]

`v 38 [
tato me iti kartuḥ śeṣatve ṣaṣṭhī | vidyādharajanma prāptena mayā malayasānuni mandare
ca kālāgurudrumāṇāṃ latābhirvalitenāliṅgitena ata eva śītamandasurabhiṇā anilena
saha vidyādharīṇāṃ suratadharmeṣu tadīyakalālakṣaṇānyamṛtāni pītānyanubhūtāni |
37 |
hemāravindamakarandapiśaṅgitāni pītāni pañcadaśavarṣaśatāni merau |
vairiñcahaṃsatanayena mayā payāṃsi tīrāntareṣu ramatopari nirjhariṇyāḥ
]

`v 39 [
kṣīrodavelāvanagandhavāhavilolanīlālakavallarīṇām |
samāḥ śataṃ śokajarāpahāri gītaṃ śrutaṃ mādhavasundarīṇām
]

`v 40 [
kālañjare mañjarite karañjaguñjāvane jambukatāṃ gato'ham |
gajena piṣṭe hariṇā hato'sau hastī mayātrārthamṛtena dṛṣṭaḥ
]

`v 41 [
saṃtānakaprakarahāsini sahyasānau kasmiṃścidanyajagatīndumukhī surastrī |
ekākinī kṛtayugārdhamathāhamāsaṃ kalpadrumastabakasadmani siddhaśāpāt |
41 |
atha saṃtānakānāṃ kalpavṛkṣabhedānāṃ prakarairhāsini hāsavatīva śobhamāne
sahyagireḥ sānau ahamindumukhī surastrī kṛtayugasyārtha siddhaśāpādāsam
]

`v 42 [
adrīndrakacchakaravīralatālayeṣu nītaṃ samāśatamaśaṅkadhiyā mayānyat |
anyatra dūrajagatīndragirau virāvivālmīkapakṣivapuṣā'niśamekakena
]

`v 43 [
anyatra sānuni mayā parilambamānāḥ sacchāyacandanavanāvalite latānām |
dṛṣṭāḥ striyaḥ phalamivāvalitā vilāsairbhuktāśca tā apahṛtā api
siddhapānthaiḥ
]

`v 44 [
evaṃ janmadvayena siddhaśāpamokṣānantaraṃ siddhānugrahādeva siddhabhūtena mayā
mahendragirereva sacchāyacandanavanāvalite anyatra sānuni latānāṃ dolāsu tatphalamiva
parilambanāvilāsairāvalitāḥ striyo dṛṣṭāḥ siddhapānthairapahṛtā api tā bhuktāśca |
43 |
anyatra parvatanitambakadambakacche nītāni tāpasatayottamayā dināni |
prāpyaikavastvabhiniveśaviṣūcikāttacittena tāntamatinā'matinā mayāntaḥ
]

`v 45 [
brahmāṇḍasaṃpūritamanyadasti jalecarāśeṣadigantabhūtam |
saṃdigdhatejombaravātasattaṃ jalasthabhūtākṛtimātrabhūmi
]

`v 46 [
ekatra dṛṣṭā vanitā mayaikā tasyāḥ śarīre trijaganti bhānti |
pratibimbitānīva sudarpaṇe'ntarākāśaśailādidigādimanti
]

`v 47 [
pṛṣṭā mayāsau varagātri kāsi śarīrametacca kimīdṛśaṃ te |
tayoktamaṅgeha cidasmi śuddhā mamāṅgametāni mahājaganti
]

`v 48 [
yathāhamevaṃ smayadehikeyaṃ sarvaṃ tathaivāṅga na citrametat |
anyaiḥ svabhāvo vidito na śuddho yadā na paśyanti tadetthamaṅga
]

`v 49 [
avedaśāstreṇa jagatyaśeṣairbhūtaiḥ svadehālayabhittibhāgāt |
etadvidheyaṃ na vidheyametaddhvaniḥ svataḥ śrūyata eva nityam
]

`v 50 [
īdṛksvabhāvaiva padārthasattā sā te'tra yadbhittyacalādayo'pi |
svapnādimāyāsviva me vadanti vācaṃ na yuṣmāsvasamañjasaṃ tat
]

`v 51 [
astrīkasaṃsāragatena dṛṣṭaṃ mayā kvacidyāvadananyakāmam |
bhūtāni niryānti bahūni bhūtādviśanti bhūtāni bahūni bhūtam
]

`v 52 [
āekāni dṛṣṭāni mayāñjasāni khe'bhrāṇyadabhrāṅga jhaṇajjhaṇāni |
vṛṣṭyā samantānnipatanti khaṇḍairbhavanti tīkṣṇāni janāyudhāni
]

`v 53 [
anyatra dṛṣṭaṃ gaganena yāvadihāndhayā grāmagṛhāṇi yānti |
viśantyamutrānta ihābhavadvo grāmaḥ sa evānyata eva labdhaḥ
]

`v 54 [
narāmarā'hipravibhāgamuktānyanyatra bhūtāni samāni santi |
khādeva sarvāṇi samudbhavanti tatraiva kāle na layaṃ prayānti
]

`v 55 [
acandratārārkamanandhakāraṃ svayaṃprakāśākhilabhūtajātam |
smarāmi kiṃcijjagadekakāntaṃ jvālodarābhaṃ dinarātrimuktam
]

`v 56 [
anyatrāścaryāntaramāha - acandreti | anandhakāratve hetuḥ - svayaṃprakāśeti |
55 |
apūrvadaityāhinarāmarādibhūtānyapūrvadrumapattanāni |
apūrvalokāntarakāryavanti smarāmyanantāni mahājaganti
]

`v 57 [
āścaryāntaramāha - apūrveti | prasiddhasaṃsthānavyavahāravailakṣaṇyamapūrvatā |
56 |
digasti sā no vihṛtaṃ na yasyāṃ na so'sti deśaḥ khalu yo na dṛṣṭaḥ |
yannānubhūtaṃ na tadasti kāryamanyāśrayaṃ nāparamasti marśāt
]

`v 58 [
kiṃ bahunā | mayā yasyāṃ diśi na vihṛtaṃ sā diṅnāsti | yo deśo na dṛṣṭaḥ so'pi
nāsti | yatkārya kautukaṃ nānubhūtaṃ tadapi nāsti |
madīyānmarśādvimarśādanubhavarūpātsarvasākṣiṇaḥ
sakāśādanyāśrayamanyādhiṣṭhānakamaparaṃ tadvyatiriktaṃ ca yatsyāttadapi nāsti | 57
|
kṣīrodakabhramitamandararatnaśṛṅgadhārāgranirdalanajātajhaṇajjhaṇānām |
ekatra saṃyutamupendrabhujāṅgadānāṃ śabdaṃ smarāmi
ghanagarjitaśaṅkitena
]