`v 1 [
ṣoḍaśaḥ sargaḥ 16
śrīvasiṣṭha uvāca |
athākṣipya vacastasya tanayasya tathā bhṛgoḥ |
uvāca bhagavānkālo vaco gambhīraniḥsvanaḥ
]

`v 2 [
kāla uvāca |
samaṅgātāpasīmetāṃ tanuṃ saṃtyajya bhārgava |
praviśemāṃ tanuṃ sādho nagarīmiva pārthivaḥ
]

`v 3 [
kāle pūrvajayā tanvā tapaḥ kṛtvā tayā punaḥ |
gurutvamasurendrāṇāṃ kartavyaṃ bhavatānagha
]

`v 4 [
mahākalpānta āyāte bhavatā bhārgavī tanuḥ |
apunargrahaṇāyaiṣā tyājyā pramlānapuṣpavat
]

`v 5 [
jīvanmuktapadaṃ prāptastanvā prāktanarūpayā |
mahāsurendragurutāṃ kurvaṃstiṣṭha mahāmate
]

`v 6 [
kalyāṇamastu vāṃ yāmo vayaṃ tvabhimatāṃ diśam |
na kiṃcidapi yaccittaṃ yasya nābhimataṃ bhavet
]

`v 7 [
ityuktvā muñcatorbāṣpaṃ tayoḥ so'ntaradhīyata |
taptāṅgyoriva rodasyoḥ samamaṃśubhiraṃśumān
]

`v 8 [
gate tasminbhagavati kṛtānte bhavitavyatām |
vicārya bhārgavo'bhedyāṃ niyaterniyatāṃ gatim
]

`v 9 [
kālakāraṇasaṃśuṣkāṃ bhāvipuṣpaśubhodayām `note[phalodayāmiti
pāṭhaḥ] |
viveśa tāṃ tanuṃ bālāṃ sulatāmiva mādhavaḥ
]

`v 10 [
sā brāhmaṇītanurbhūmau vivarṇavadanāṅgikā |
papāta kampitā tūrṇaṃ chinnamūlā latā yathā
]

`v 11 [
tasyāṃ praviṣṭajīvāyāṃ putratanvāṃ mahāmuniḥ |
cakārāpyāyanaṃ mantraiḥ sa kamaṇḍaluvāribhiḥ
]

`v 12 [
sarvā nāḍyastatastanvāstasyāḥ pūrṇā virejire |
saritaḥ prāvṛṣīvāmbupūrapūritakoṭarāḥ
]

`v 13 [
nalinī prāvṛṣīvāsau madhāviva navā latā |
yadā pūrṇā tadā tasyāḥ prāntāḥ pallavitā babhuḥ
]

`v 14 [
atha śukraḥ samuttasthau vahatprāṇasamīraṇaḥ |
rasamārutasaṃyogādāpūrṇa iva vāridaḥ
]

`v 15 [
puro'bhivādayāmāsa pitaraṃ pāvanākṛtim |
prathamollāsito meghaḥ staniteneva parvatam
]

`v 16 [
pitātha prāktanīṃ tanvā āliliṅgākṛtiṃ tataḥ |
snehārdravṛttirjaladaścirādadritaṭīmiva
]

`v 17 [
bhṛgurdadarśa sasnehaṃ prāktanīṃ tānavīṃ tanum |
matto jāteyamityāsthāṃ hasannapi mahāmatiḥ
]

`v 18 [
matputro'yamiti sneho bhṛgumapyaharattadā |
paramātmīyatā dehe yāvadākṛtibhāvinī
]

`v 19 [
babhūvatuḥ pitāputrau tāvathānyonyaśobhitau |
niśāvasānamuditāvarkapadmākarāviva
]

`v 20 [
cirasaṃgamasaṃbaddhāviva cakrāhvadampatī |
ghanāgamanasasnehau mayūrajaladāviva
]

`v 21 [
cirakāladṛḍhotkaṇṭhau tulyayogyatayā tayā |
sthitvā tatra muhūrtaṃ tāvathotthāya mahāmatī
]

`v 22 [
samaṅgādvijadehaṃ taṃ bhasmasāttatra cakratuḥ |
ko hi nāma jagajjātamācāraṃ nānutiṣṭhati
]

`v 23 [
evaṃ tau kānane tasminpāvane bhṛgubhārgavau |
saṃsthitau tāpasau dīptau divīva śaśibhāskarau
]

`v 24 [
ceraturjñātavijñeyau jīvanmuktau jagadgurū |
deśakāladaśaugheṣu susamau susthirau tataḥ
]

`v 25 [
athāsuragurutvaṃ sa śukraḥ kālena labdhavān |
bhṛgurapyātmano yogye pade'tiṣṭhadanāmaye
]

`v 26 [
asuragurutvagrahaṇaṃ grahādhikārasyāpyupalakṣaṇam | pade prājāpatyādhikāre |
25 |
śukro'sau prathamamiti krameṇa jāta-
stasmātsatparamapadādudārakīrtiḥ |
svenāśu smṛtipadavibhrameṇa paścā-
danyeṣu pravilulito daśāntareṣu
]