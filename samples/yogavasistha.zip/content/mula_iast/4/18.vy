`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīvasiṣṭha uvāca |
sarvasaṃsṛtikhaṇḍeṣu bhūtabījakalātmanaḥ |
tanmātrapratibhāsasya pratibhāsena bhinnatā
]

`v 2 [
pravṛttirvā nivṛttirvā tanmātrāvṛttipūrvakam |
sarvasya jīvajātasya suṣuptatvādanantaram
]

`v 3 [
pravṛttibhājo ye jīvāste tanmātrapradarśinaḥ |
tanmātraikatayā sargānmithaḥ paśyanti kalpitān
]

`v 4 [
tanmātraikyapraṇālena citrāḥ sargajalāśayāḥ |
parasparaṃ saṃmilanti ghanatāṃ yānti cābhitaḥ
]

`v 5 [
kecitpṛthaksthitigatāḥ pṛthageva layaṃ gatāḥ |
kecinmithaḥ saṃmilitā jagadguñjā sthitākṣatā
]

`v 6 [
jagadguñjāsahasrāṇi yatrāsaṃkhyānyaṇāvaṇau |
aparasparalagnāni kānanaṃ brahma nāma tat
]

`v 7 [
mithaḥ saṃmilanenaitā ghanatāṃ samupāgatāḥ |
yadyadyatra yathā rūḍhaṃ tattatpaśyati netarat
]

`v 8 [
vartamānaṃ manorājyaṃ naiṣphalyaṃ samupāgatā |
sā kṛttirmanaso jñeyā tasya jīvaparamparā
]

`v 9 [
parasparaṃ saṃmilatāṃ sargāṇāṃ rūḍhabhāvinām |
dehasattā bhṛśaṃ rūḍhā dehābhāvastu vismṛtiḥ
]

`v 10 [
dehatvaparirūḍhatvācciddhemnā vismṛtātmanā |
mithyānubhūtā'vidyā tu śuddhā kaṭakatāmitā
]

`v 11 [
yathā śuddhaḥ prāṇamarutparaprāṇādivedanāt |
vetti vedyaṃ manorājyaṃ tathā sargāntarāśrayam
]

`v 12 [
sarveṣāṃ jīvarāśīnāmātmāvasthātrayaṃ śritaḥ |
jāgratsvapnasuṣuptyākhyamatra deho na kāraṇam
]

`v 13 [
evamātmani jīvatve satyavasthātrayātmani |
nacāmbhasīva vīcitvamasminkacati dehatā
]

`v 14 [
citkalāpadamāsādya suṣuptāntapadasthitam |
buddho nivartate jīvo mūḍhaḥ sarge pravartate
]

`v 15 [
dvayorekasvarūpaiva svasauhārdanidarśanāt |
ajñaḥ suṣupto'saṃbuddho jīvaḥ kaścitsa sargabhāk
]

`v 16 [
sarvagatvāccitaḥ `note[1] kaścitparasargeṇa nīyate |
sarge sarge pṛthagrūpaṃ santi sargāntarāṇyapi
]

`v 17 [
teṣvapyantasthasargaughāḥ kadalīdalapīṭhavat |
sarvasargāntarādūraṃ patrapīvaravṛttimat
]

`v 18 [
svabhāvaśītalaṃ brahma kadalīdalamaṇḍapaḥ |
kadalyāmanyatā nāsti yathā patraśateṣvapi
]

`v 19 [
brahmatattve'nyatā nāsti tathā sargaśateṣvapi |
bījameva rasātphullaṃ bhūtvā bījaṃ punarbhavet
]

`v 20 [
tathā brahma mano bhūtvā bodhādbrahma paraṃ bhavet |
rasakāraṇakaṃ bījaṃ phalabhāvena jṛmbhate
]

`v 21 [
brahmakāraṇako jīvo jagadrūpeṇa jṛmbhate |
rasasya kāraṇaṃ kiṃ syāditi vaktuṃ na yujyate
]

`v 22 [
brahmaṇaḥ kāraṇaṃ kiṃ syāditi vaktuṃ na yujyate |
svabhāvo nirviśeṣatvātparo vaktuṃ na yujyate
]

`v 23 [
nanu patrakāṇḍavṛkṣapuṣpaphalādīnāṃ sarasatādarśanāttatsvabhāvabhūto
rasasteṣāṃ kāraṇamiva jagatkāraṇaṃ brahmāpi jagaddharmasvabhāvaviśeṣa eva
syāttathāca brahmakāraṇatāsādhanaṃ svabhāvakāraṇatāvādenārthāntaritaṃ
syādityāśaṅkyāha - svabhāva iti | na yujyate | kutaḥ |
nirviśeṣatvātkāraṇasya
kāryasahotpattikāsādhāraṇadharmaviśeṣarūpatatsvabhāvarūpatvā##-
nākāraṇe kāraṇādi pare vastvādikāraṇe |
vicāraṇīyaḥ sāro hi kimasāravicāraṇaiḥ
]

`v 24 [
bījaṃ jahadbījavapuḥ phalībhūtaṃ vilokyate |
brahmājahannijavapuḥ phalaṃ bīje ca saṃsthitam
]

`v 25 [
bījasyākṛtimatsarvaṃ tenānākṛtimatpadam |
na yujyate samīkartuṃ tasmānnāstyupamā śive
]

`v 26 [
svameva jāyate'svābhaṃ na ca tajjāyate'nyadṛk |
ato na jātaṃ nājātaṃ viddhi brahma nabho jagat
]

`v 27 [
dṛśyaṃ paśyansvamātmānaṃ na draṣṭā saṃprapaśyati |
prapañcākrāntasaṃvitteḥ kasyodeti nijā sthitiḥ
]

`v 28 [
mṛgatṛṣṇājalabhrāntau satyāṃ kaiva vidagdhatā |
vidagdhatāyāṃ satyāṃ tu kaivāsau mṛgatṛṣṇikā
]

`v 29 [
ākāśaviśado draṣṭā sarvāṅgo'pi na paśyati |
netraṃ nijamivātmānaṃ dṛśībhūtamaho bhramaḥ
]

`v 30 [
ākāśaviśado draṣṭā sarvāṅgo'pi na paśyati |
teṣāṃ nijamivātmānaṃ dṛśībhūtamivābhramaḥ
]

`v 31 [
ākāśaviśadaṃ brahma yatnenāpi na labhyate |
dṛśye dṛśyatayā dṛṣṭe tvasya lābhaḥ sudūrataḥ
]

`v 32 [
tathāca dṛśyaṃ dṛśyatayā na draṣṭavyaṃ kiṃtu dṛṅmātratayeti bhāvaḥ |
31 |
tādṛgbhāvasvarūpeṇa vinā yatra na dṛśyate |
tatrāpi dūrodastaiva draṣṭuḥ sūkṣmasya dṛśyatā
]

`v 33 [
dṛśyaṃ ca dṛśyate tena draṣṭā rāma na dṛśyate |
draṣṭaiva saṃbhavatyeko natu dṛśyamihāsti hi
]

`v 34 [
yadi sarvathā draṣṭā na dṛśyate tarhi kathaṃ tanmātrayuktyā
tallābhasiddhirityāśaṅkya tadupāyamāha - draṣṭaiva saṃbhavatītyādinā | 33
|
draṣṭā sarvātmako dṛśye sthitaścetkaiva draṣṭṛtā |
sarvaśaktimatā rājñā yadyatsaṃpadyate yathā
]

`v 35 [
tattathānubhavatyāśu sa evodeti tattathā |
yathā madhurasollāsaḥ khaṇḍo bhavati bhāsuraḥ
]

`v 36 [
rasatāmajahaccaiva phalapuṣpalatonnataḥ |
cidullāsastathā jīvo bhūyo bhavati dehakaḥ
]

`v 37 [
cinmātratāṃ tāmajahadeva darśanadṛṅmayam |
antaḥsvānubhavaścaiva jagatsvapnaṃ prapaśyati
]

`v 38 [
ahaṃtādirase bhaume khaṇḍakatvamivātmani |
nānākhaṇḍasahasraughairadvitīyairnijātmanaḥ
]

`v 39 [
yathodeti raso bhaumaścittathodetyasaṃbhramam |
cidrasollāsavṛkṣāṇāṃ kacatāmātmanātmani
]

`v 40 [
dṛśyaśākhāśatāḍhyānāmiha nānto'vagamyate |
khaṇḍaḥ pratyekamevāyaṃ yathā rasacamatkṛtim
]

`v 41 [
svādayatyevameṣā citpṛthakpaśyati saṃsthitim |
yā yodeti yathā yasyā jīvaśakteḥ svasaṃsṛtiḥ
]

`v 42 [
tāṃ tāṃ tathaiti sā svātmacidrūpabhuvanasthitim |
jīvasaṃsṛtayaḥ kāścitpramilanti parasparam
]

`v 43 [
svayaṃ vihṛtya saṃsāre śāmyanti cirakālataḥ |
sūkṣmayā parayā dṛṣṭyā tvaṃ paśya jñānacetasā
]

`v 44 [
jagajjvālasahasrāṇi paramāṇvantareṣvapi |
citte nabhasi pāṣāṇe jvālāyāmanile jale
]

`v 45 [
santi saṃsāralakṣāṇi tile tailamivākhile |
siddhimeti yadā cetastadā jīvo bhaveccitiḥ
]

`v 46 [
śuddhā ca sā sarvagatā tena tanmelanaṃ mithaḥ |
sarveṣāṃ padmajādīnāṃ svasattābhramarūpakaḥ
]

`v 47 [
jagaddīrghamahāsvapnaḥ so'yamantaḥ samutthitaḥ |
svapnātsvapnāntaraṃ yānti kāścidbhūtaparamparāḥ
]

`v 48 [
tenopalambhaḥ kuḍyādāvasau dṛḍhataraḥ sthitaḥ |
yadyatra cidbhāvayati tattatrāśu bhavatyalam
]

`v 49 [
tena svapnaparamaparābhramaṇena | tadvāsanādārḍhyāddṛḍhataraḥ | cito
vāsanodbhavānurūpavivartasāmarthyaṃ sārvatrikamiti darśayati - yadyatreti |
48 |
tayā svapne'pi yaddṛṣṭaṃ tatkāle satyameva tat |
cidaṇorantare santi samastānubhavāṇavaḥ
]

`v 50 [
(yathā `note[koṣṭhakavinyasto'yaṃ pāṭhaḥ prakṣipta iti bhāti
ādarśāntareṣvadarśanāṭṭīkākartrasaṃmatatvācca] bījāntare
patralatāpuṣpaphalāṇavaḥ) |
paramāṇujagatyantarmanye citparamāṇavaḥ |
līnamākāśamākāśe dvaitaikyabhramamutsṛja
]

`v 51 [
deśakālakriyādravyaiḥ svairevāṇubhireva cit |
aṇūnanubhavatyantaritarāṇi nasaṃbhavāt
]

`v 52 [
svayaṃ sargasya kacitaḥ svapne cidaṇukhaṇḍakaḥ |
brahmādeḥ kīṭaniṣṭhasya dehadṛṣṭyānubhāvitaḥ
]

`v 53 [
kacitaṃ kiṃcideveha vastutastu na kiṃcana |
svayaṃ satyaṃ svādayante dvaitaṃ citparamāṇavaḥ
]

`v 54 [
yadanubhūyate kiṃ taditi tatrāha - kacitamiti |
kiṃcidevetyanirvacanīyamityarthaḥ | tarhi tatkiṃ tatrāha - svayaṃ satyamiti |
yathā kaścidbhrāntaḥ svayaṃ svaskandhamārurukṣati tadvaccitparamāṇavo jīvāḥ
svayaṃ satyamātmarūpameva dvaitaṃ manyamānā bhrāntyā svādayantītyarthaḥ |
53 |
svayaṃ prakacati sphāradehaścidaṇukhaṇḍakaḥ |
netrādikusumadvāraiḥ saṃvidāmodamudgiran
]

`v 55 [
saṃpaśyatitarāṃ kaścidbahīrūpeṇa cidghaṭaḥ |
sarvagatvādanāśitvāddṛśyabījasya vai citeḥ
]

`v 56 [
antarevākhilaṃ kaścitpaśyatya vimalaṃ jagat |
tatrātikālakalanādunmajjati nimajjati
]

`v 57 [
svapnātsvapnāntaraṃ tatra tathā paśyanpunaḥ punaḥ |
mithyā vaṭeṣu luṭhati śileva śikharacyutā
]

`v 58 [
kecitsaṃmilitāḥ kecidātmanyevābhrame sthitāḥ |
magnāḥ svasaṃvitprasare sphuranto dehakhaṇḍakāḥ
]

`v 59 [
svayamantaḥ prapaśyanti ye jagajjīvavibhramam |
taistaiḥ kaiścittataṃ dṛśyamasatsvapnavadāśritam
]

`v 60 [
sarvātmatvātsvabhāvasya taddṛśyaṃ satyamātmani |
sarvagaṃ vidyate yatra tatra sarvamudeti hi
]

`v 61 [
jīvāntaḥ pratibhāsasya sarvasya punarantare |
jīvakhaṇḍa udetyuccaistasyāntaritaro'pi ca
]

`v 62 [
jīvāntarjāyate jīvastasyāntarapi jīvakaḥ |
sarvatra rambhādalavajjīvo jīvantareva hi
]

`v 63 [
dṛśyabuddhiparāvṛttau samametadanantaram |
hemnīva kaṭakāditvaṃ parijñātaṃ vinaśyati
]

`v 64 [
vicāro yasya nodeti ko'haṃ kimidamityalam |
tasyāntarna vimukto'sau dīrgho jīvajvarabhramaḥ
]

`v 65 [
vicāraḥ saphalastasya vijñeyo yasya sanmateḥ |
dinānudinamāyāti tānavaṃ bhogagṛdhnutā
]

`v 66 [
vairāgyapūrvakavicāra eva phalaparyavasāyī na rāgīkṛta ityāha - saphala iti |
65 |
yathā dehopayuktaṃ hi karotyārogyamauṣadham |
tathendriyajaye'bhyaste vivekaḥ phalito bhavet
]

`v 67 [
viveko'sti vacasyeva citre'gniriva bhāsvaraḥ |
yasya tenāparityaktā duḥkhāyaivāvivekitā
]

`v 68 [
yathā sparśena pavanaḥ sattāmāyāti no girā |
tathecchātānavenaiva viveko'sya vibudhyate
]

`v 69 [
citrāmṛtaṃ nāmṛtameva viddhi
citrānalaṃ nānalameva viddhi |
citrāṅganā nūnamanaṅganeti
vācā vivekastvaviveka eva
]

`v 70 [
pūrvaṃ vivekena tanutvameti
rāgo'tha vairaṃ ca samūlameva |
paścātparikṣīyata eva yatnaḥ
sa pāvano yatra vivekitāsti
]