`v 1 [
ekacatvāriṃśaḥ sargaḥ 41
śrīrāma uvāca |
kṣīrodakukṣitulyābhiḥ śītalāmaladīptibhiḥ |
tavoktibhirvicitrābhirgambhīrābhirivābhitaḥ
]

`v 2 [
kṣaṇamāndhyamivāpnomi kṣaṇaṃ yāmi prakāśatām |
śāntātapalavaḥ prāvṛḍlolābhra iva vāsaraḥ
]

`v 3 [
anantasyāprameyasya sarvasyaikasya bhāsvataḥ |
anastamitasārasya kalanā kathamāgatā
]

`v 4 [
śrīvasiṣṭha uvāca |
yathābhūtārthavākyārthāḥ sarvā eva mamoktayaḥ |
nāsamarthā virūpārthāḥ pūrvāparavirodhadāḥ
]

`v 5 [
jñānadṛṣṭau prasannāyāṃ prabodhe vitatodaye |
yathāvajjñāsyasi svastho madvāgdṛṣṭibalābalam
]

`v 6 [
upadeśyopadeśārthaṃ śāstrārthapratipattaye |
śabdārthavākyaracanābhramo mā tanmayo bhava
]

`v 7 [
yadā purā jñāsyasi tatsatyamatyantanirmalam |
vācyavācakaśabdārthabhedaṃ tyakṣyasi vai tadā
]

`v 8 [
bhedakṛdvākprapañco'yamupadeśyeṣu kalpitaḥ |
upadeśyopadeśārthaṃ śāstrārthapratipattaye
]

`v 9 [
śabdārthavākprapañco'yamupadeśeṣu kalpitaḥ |
sadā'jñeṣu na tajjñeṣu vidyate pāramārthikaḥ
]

`v 10 [
kalanāmalamohādi kiṃcinnātmani vidyate |
nīrāgaṃ brahma paramaṃ tadevedaṃ jagatsthitam
]

`v 11 [
etadvicitrarūpābhiryuktibhirbahuśaḥ punaḥ |
vistareṇaiva vaktavyaṃ siddhāntāvasare'nagha
]

`v 12 [
vākprapañcaṃ vinā tvetadajñānamatulaṃ tamaḥ |
bhettumanyonyamuditaṃ yatnaṃ kartuṃ na śakyate
]

`v 13 [
avidyayaivottamayā svātmanāśodyamecchayā |
vidyā sā prārthyate rāma sarvadoṣāpahāriṇī
]

`v 14 [
śāmyati hyastramastreṇa malena kṣālyate malaḥ |
śamaṃ viṣaṃ viṣeṇaiti ripuṇā hanyate ripuḥ
]

`v 15 [
īdṛśī rāma māyeyaṃ yāṃ svanāśena harṣadā |
na lakṣyate svabhāvo'syāḥ prekṣyamāṇaiva naśyati
]

`v 16 [
vivekamācchādayati jaganti janayatyalam |
naca vijñāyate kaiṣā paśyāścaryamidaṃ jagat
]

`v 17 [
tasyā asaṃbhāvitānantakāryadarśanādapi na virodhasaṃbhāvanetyāśayenāha ##-
aprekṣyamāṇā sphurati prekṣitā tu vinaśyati |
māyeyamaparijñāyamānarūpaiva valgati
]

`v 18 [
aho nu khalu citreyaṃ māyā saṃsārabandhanī |
asatyevātisatyeva svajñānaṃ vihitaṃ tayā
]

`v 19 [
atyabhinnapade tasmiṃstanvānā bhedamātatam |
saṃsāramāyā yenāsau tenāsau puruṣottamaḥ
]

`v 20 [
nāstyeṣā paramārthe na tvevaṃ bhāvanayeddhayā |
jño bhūtvā jñeyasaṃprāpto jñāsyasyasyāstvamāśayam
]

`v 21 [
yāvattu na prabuddhastvaṃ tāvanmadvacasaiva te |
niścayo bhavatūddāmo nāstyavidyeti niścalaḥ
]

`v 22 [
yadidaṃ dṛśyatāṃ yātaṃ mānasaṃ mananaṃ mahat |
asanmātramidaṃ yasmānmanomātravijṛmbhitam
]

`v 23 [
sattadbrahmeti yasyāntarniścayaḥ so'pi mokṣabhāk |
calācalākṛtiryā yā dṛṣṭirābaddhabhāvanā
]

`v 24 [
sā samagrajagadbhūtakhagabandhanavāgurā |
yaḥ svapnabhūmivadbhrāntamasatsadvyekaniścayaḥ
]

`v 25 [
jagatpaśyatyasaktātmā na sa duḥkhe nimajjati |
yasyaitāsvasvarūpāsu bhāvanā svātmabhāvanā
]

`v 26 [
asvarūpasya tasyāpi sā hyavidyaiva vidyate |
vikāritādayo doṣā na kecana mahātmani
]

`v 27 [
paramātmani vidyante payasīveha pāṃsavaḥ |
bhāvanāśabdaśabdārtharañjaneyaṃ jagadgatā
]

`v 28 [
vyavahārārthamutpannā vyatiriktā ca nātmanaḥ |
anena vyavahāreṇa vinaitāḥ śāstradṛṣṭayaḥ
]

`v 29 [
saṃsthitiṃ nādhigacchanti paṭā iva vitantavaḥ |
uhyamāno hyavidyāyāmātmā nehopalakṣyate
]

`v 30 [
ātmajñānādṛte tacca śāstrārthātsamavāpyate |
avidyāsaritaḥ pāramātmalābhādṛte kila
]

`v 31 [
rāma nāsādyate taddhi padamakṣayamucyate |
yataḥkutaścijjāteyamavidyā maladāyinī
]

`v 32 [
nūnaṃ sthitimupāyātā samāsādya padaṃ sthitā |
kuto jāteyamiti te rāma māstu vicāraṇā
]

`v 33 [
imāṃ kathamahaṃ hanmītyeṣā te'stu vicāraṇā |
astaṃ gatāyāṃ kṣīṇāyāmasyāṃ jñāsyasi rāghava
]

`v 34 [
yata eṣā yathā caiṣā yathā naṣṭetyakhaṇḍitam |
vastutaḥ kila nāstyeṣā vibhātyeṣā na vekṣitā
]

`v 35 [
asato bhrāntatāṃ satyarūpāṃ jānātu kaḥ kutaḥ |
jāteyaṃ prauḍhimāpannā doṣāyaivātatākṛtiḥ
]

`v 36 [
balātpraṇāśaya tvenāṃ parijñāsyasi vai tataḥ |
api śūrā atiprājñāste na santi jagattraye
]

`v 37 [
avidyayā ye puruṣā na nāma vivaśīkṛtāḥ |
tadasyā rogaśīlāyā yatnaṃ kuru vināśane
]

`v 38 [
yathaiṣā janmaduḥkheṣu na bhūyastvāṃ niyokṣyati |
sarvāpadāmekasakhīmajñānatarumañjarīm |
anarthasārthajananīmavidyāmalamuddhara
]

`v 39 [
bhayaviṣādadurādhivipatpradāṃ
hṛdayamohamahāpaṭalāṅkurām |
bhṛśamapāsya kudṛṣṭimimāṃ balā-
dbhava bhavārṇavapāramupāgataḥ
]