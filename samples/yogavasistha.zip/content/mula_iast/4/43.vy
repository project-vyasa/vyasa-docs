`v 1 [
tricatvāriṃśaḥ sargaḥ 43
śrīvasiṣṭha uvāca |
evaṃ jīvāścito bhāvā bhavabhāvanayohitāḥ |
brahmaṇaḥ kalpitākārāllakṣaśo'pyatha koṭiśaḥ
]

`v 2 [
asaṃkhyātāḥ purā jātā jāyante cāpi vādya bhoḥ |
utpatiṣyanti caivāmbukaṇaughā iva nirjharāt
]

`v 3 [
svavāsanādaśāveśādāśāvivaśatāṃ gatā |
daśāsvativicitrāsu svayaṃ nigaḍitāśayāḥ
]

`v 4 [
anārataṃ pratidiśaṃ deśe deśe jale sthale |
jāyante vā mriyante vā budbudā iva vāriṇi
]

`v 5 [
kecitprathamajanmānaḥ kecijjanmaśatādhikāḥ |
kecidvā'jnmasaṃkhyākāḥ keciddvitribhavāntarāḥ
]

`v 6 [
bhaviṣyajjātayaḥ kecitkecidbhūtabhavodbhavāḥ |
vartamānabhavāḥ kecitkecittvabhavatāṃ gatāḥ
]

`v 7 [
kecitkalpasahasrāṇi jāyamānāḥ punaḥ punaḥ |
ekāmevāsthitā yoniṃ kecidyonyantaraṃ śritāḥ
]

`v 8 [
kecinmahāduḥkhasahāḥ kecidalpodayāḥ sthitāḥ |
kecidatyantamuditāḥ kecidarkādivoditāḥ
]

`v 9 [
kecitkiṃnaragandharvavidyādharamahoragāḥ |
kecidarkendravaruṇāstryakṣādhokṣajapadmajāḥ
]

`v 10 [
kecitkūśmāṇḍavetālayakṣarakṣaḥpiśācakāḥ |
kecidbrāhmaṇabhūpālā vaiśyaśūdragaṇāḥ sthitāḥ
]

`v 11 [
kecicchvapacacāṇḍālakirātāveśapuṣkasāḥ |
kecittṛṇauṣadhī kecitphalamūlapataṅgakāḥ
]

`v 12 [
keciccitralatāgulmatṛṇopaladṛśo'bhitaḥ |
kecitkadambajambīraśālatālatamālakāḥ
]

`v 13 [
kecidvibhavasaṃsāramantrisāmantabhūmipāḥ |
keciccīrāmbarācchannā munimaunamupasthitāḥ
]

`v 14 [
kecidbhujaṅgagonāsakṛmikīṭapipīlikāḥ |
kecinmṛgendramahiṣamṛgājacamaraiṇakāḥ
]

`v 15 [
kecitsārasacakrāhvabalākābakakokilāḥ |
kecitkamalakahlārakumudotpalatāṃ gatāḥ
]

`v 16 [
kecitkalabhamātaṅgavarāhavṛṣagardabhāḥ |
keciddvirephamaśakāḥ puttikādaṃśavaṃśajāḥ
]

`v 17 [
kecidāpadbalākrāntāḥ kecitsaṃpadamāgatāḥ |
kecitsthitāḥ svargapure kecinnarakamāsthitāḥ
]

`v 18 [
ṛkṣacakragatāḥ kecidvṛkṣarandhragatāḥ pare |
vātabhūtāḥ sthitāḥ kecitkecidvyomapade sthitāḥ
]

`v 19 [
sūryāṃśuṣu sthitāḥ kecitkecidindvaṃśuṣu sthitāḥ |
kecittṛṇalatāgulmarasasvāduṣvavasthitāḥ
]

`v 20 [
jīvanmuktā bhramantīha kecitkalyāṇabhājanāḥ |
ciramuktāḥ sthitāḥ kecinnūnaṃ pariṇatāḥ pare
]

`v 21 [
keciccireṇa kālena bhaviṣyanmuktayaḥ śivāḥ |
keciddviṣanti cidbhāvāḥ kevalībhāvamātmanaḥ
]

`v 22 [
kecidviśālāḥ kakubhaḥ kecinnadyo mahārayāḥ |
kecitstriyaḥ kāntadṛśaḥ kecitpaṇḍanapuṃsakāḥ
]

`v 23 [
kecitprabuddhamatayaḥ kecijjaḍatarāśayāḥ |
kecijjñānopadeṣṭāraḥ kecidāttasamādhayaḥ
]

`v 24 [
ete sarve'pi saṃsaraṇānarthavāsanāvaśādeveti saiva
samūlamucchedyetyāśayenopasaṃharati - jīvā iti |
uktānuktasarvasaṃgrahārthametāsvetāsviti vīpsā
]

`v 25 [
viharanti bhuvi | nipatanti narake | utpatanti svarge | ata eva kandukā iva
]

`v 26 [
āśāpāśaśatābaddhā vāsanābhāvadhāriṇaḥ |
kāyātkāyamupāyānti vṛkṣādvṛkṣamivāṇḍajāḥ
]

`v 27 [
anantānantasaṃkalpakalpanotpādamāyayā |
indrajālaṃ vitanvānā jaganmayamidaṃ mahat
]

`v 28 [
ananteṣu viṣayeṣu anantasaṃkalpakalpanotpādanahetubhūtayā māyayā avidyayā |
27 |
tāvadbhramanti saṃsāre vāriṇyāvartarāśayaḥ |
yāvanmūḍhā na paśyanti svamātmānamaninditam
]

`v 29 [
dṛṣṭvātmānamasattyaktvā satyāmāsādya saṃvidam |
kālena padamāgatya jāyante neha te punaḥ
]

`v 30 [
bhuktvā janmasahasrāṇi bhūyaḥ saṃsārasaṃkaṭe |
patanti kecidabudhāḥ saṃprāpyāpi vivekitām
]

`v 31 [
kecicchaktatvamapyuccaiḥ prāpya tucchatayā dhiyā |
punastiryaktvamāyānti tiryaktvānnarakānapi
]

`v 32 [
kecinmahādhiyaḥ santa utpadya brahmaṇaḥ padāt |
tadaiva janmanaikena tatraivāśu viśantyalam
]

`v 33 [
mahādhiyaḥ sanakādayaḥ | tadaiva tasminneva kalpe | tatra mokṣākhye brahmapade |
32 |
brahmāṇḍeṣvitareṣvanye teṣvanye jīvarāśayaḥ |
prayānti padmodbhavatāmanye ca haratāmapi
]

`v 34 [
anye prayānti tiryaktvamanye ca suratāmapi |
anye'pi jāgatāṃ rāma yathaiveha tathaiva hi
]

`v 35 [
yathedaṃ hi jagatsphāraṃ tathānyāni jagantyapi |
vidyante samatītāni bhaviṣyanti ca bhūriśaḥ
]

`v 36 [
anyenānyena citreṇa krameṇānyena hetunā |
vicitrāḥ sṛṣṭayasteṣāmāpatanti patanti ca
]

`v 37 [
kaścidgandharvatāṃ yāti kaścidgacchati yakṣatām |
kaścitprayāti suratāṃ kaścidāyāti daityatām
]

`v 38 [
yenaiva vyavahāreṇa brahmāṇḍe'sminjanāḥ sthitāḥ |
tenaivānyeṣu tiṣṭhanti sanniveśavilakṣaṇāḥ
]

`v 39 [
svasvabhāvavaśāveśādanyonyaparighaṭṭanaiḥ |
sṛṣṭayaḥ parivartante taraṅgiṇyā ivormayaḥ
]

`v 40 [
astvevaṃ tathāpi kathaṃ teṣāmuttamādhamādibhāvena parasparasnehavirodhādinā
ca sṛṣṭiparivṛttistatrāha - svasvabhāveti |
sāttvikarājasatāmasādisvasvabhāvavaśāttattadanukūlavyavahārābhiniveśātpravṛ
^ittānāmekaviṣaye spardhayā anyonyaparighaṭṭanaiḥ sṛṣṭiparivṛttirityarthaḥ |
39 |
āvirbhāvatirobhāvairunmajjananimajjanaiḥ |
sṛṣṭayaḥ parivartante taraṅgiṇyā ivormayaḥ
]

`v 41 [
niryāntyavirataṃ tasmātparasmājjivarāśayaḥ |
anirdeśyāḥ svasaṃvedyāstatraivāśu sphuranti ca
]

`v 42 [
dīpādivālokadṛśaḥ sūryādiva marīcayaḥ |
kaṇāstaptāyasa iva sphuliṅgā iva pāvakāt
]

`v 43 [
kālādivartavaścitrā āmodāḥ kusumādiva |
śītalā iva varṣāṇupūrādabdherivormayaḥ
]

`v 44 [
utpattyotpattya kālena bhuktvā dehaparamparām |
svata eva pade yānti nilayaṃ jīvarāśayaḥ
]

`v 45 [
aviratamiyamātatā tathoccai-
rbhavati vinaśyati vardhate mudhaiva |
tribhuvanaracanādimohamāyā
paramapade laharīva vārirāśau
]