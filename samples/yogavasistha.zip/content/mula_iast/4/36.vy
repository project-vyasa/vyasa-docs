`v 1 [
ṣaṭtriṃśaḥ sargaḥ 36
śrīrāma uvāca |
yathedṛśaṃ sthitaṃ viśvaṃ viśvātīte cidātmani |
tanme kathaya he brahman punarbodhavivṛddhaye
]

`v 2 [
śrīvasiṣṭha uvāca |
yathormayo'nabhivyaktā bhāvinaḥ payasi sthitāḥ |
na sthitāścātmano'nyatvāccittatve sṛṣṭayastathā
]

`v 3 [
yathā sarvagataḥ saukṣmyādākāśo nopalakṣyate |
tathā niraṃśaścidbhāvaḥ sarvago'pi na lakṣyate
]

`v 4 [
susthitevāsthitevāntaḥ pratibhāsti maṇau yathā |
na satyabhūtā nāsatyā tatheyaṃ sṛṣṭirātmani
]

`v 5 [
svādhārairambudaiḥ svasthairna spṛṣṭaṃ gaganaṃ yathā |
citsthaiḥ sargaiścidādhārairna spṛṣṭā citparā tathā
]

`v 6 [
jaladhiṣṭhitatattejo yathāṅga pratibimbati |
tathā puryaṣṭakeṣveva ciddhi deheṣu lakṣyate
]

`v 7 [
sarvasaṃkalparahitā sarvasaṃjñāvivarjitā |
saiṣā cidavināśātmā taccetyādikṛtābhidhā
]

`v 8 [
ākāśaśatabhāgācchā jñeṣu niṣkalarūpiṇī |
sakalākalasaṃsārasvarūpaikātmyadarśinī
]

`v 9 [
taraṅgādimayī sphārā nānātā salilārṇave |
tasmānna vyatirekeṇa yathā bhāvavikāriṇī
]

`v 10 [
tvattāmattāmayi sphārā nānāteyaṃ cidarṇave |
cinmātravyatirekeṇa tathā naiva prakāśate
]

`v 11 [
ciccinoti citaṃ cetyaṃ tenedaṃ sthitamātmani |
ajñe'jñe tvanyadāyātamanyadastīti kalpanā
]

`v 12 [
yadi cit cetyaṃ cinoti upacinotīti manyase tarhi ciccitameva cinotīti
manyasvanacetyamanyadastīti | evaṃ manane tena citaḥ svātmani vyāpārāyogena
hetunā idaṃ citsvarūpamātmanyeva sthitaṃ na kiṃciccinotīti phalatītyarthaḥ | seyaṃ
paramārthadṛṣṭiḥ | yastvajña eva san jño'smītyabhimanyate tasyaiva
cidvyatiriktaṃ sargeṣvanyadāyātamastīti ca kalpanetyarthaḥ | ajñe'jñe iti vīpsā vā |
11 |
ajñeṣvasatsvabhāvograsaṃsāragaṇagarbhiṇī |
jñeṣu prakāśarūpaiva sakalaikātmikā satī
]

`v 13 [
anubhūtivaśānnityamarkādīnāṃ prakāśinī |
svādinī sarvabhūtānāṃ bhāvinī bhavabhoginām
]

`v 14 [
nāstameti na codeti nottiṣṭhati na tiṣṭhati |
na cāyāti na vā yāti na ceha naca neha cit
]

`v 15 [
saiṣā cidamalākārā svayamātmani saṃsthitā |
rāghavetthaṃ prapañcena jagannāmnā vijṛmbhate
]

`v 16 [
tejaḥpuñjairyathā tejaḥ payaḥpūrairyathā payaḥ |
parisphurati saṃspandaistathā citsargavibhramaiḥ
]

`v 17 [
tatsvabhāvena cinnāmnā sarvagenoditātmanā |
prakāśenāprakāśena niraṃśenāṃśadhāriṇā
]

`v 18 [
svayaṃ svakalanābhogādanantaṃ padamujjhatā |
ahamasmīti bhāvena gacchatā jñapadaṃ śanaiḥ
]

`v 19 [
nānātāyāṃ prarūḍhāyāmasyāṃ saṃsṛtipūrvakam |
bhāvābhāvagrahotsargapade sthitimupāgate
]

`v 20 [
puryaṣṭakaspandaśataiḥ karoti na karoti ca |
utsedhameti bhūkośakoṭarastho'ṅkurotkaraḥ
]

`v 21 [
vyoma sauṣiryamādatte sarvamūrtyavirodhi yat |
spandaikadharmavānvāto rasarūpatayā jalam
]

`v 22 [
dṛḍhorvī prakaṭaṃ tejaḥ sthitimanti jaganti ca |
pratibandhābhyanujñāsu kālaḥ kalanayā sthitaḥ
]

`v 23 [
puṣpeṣu gandhatāṃ yāti śanaiḥ saṃcitakesaram |
mṛtkoṭararasollāsaḥ sthāṇutāmeti bhūtale
]

`v 24 [
mūlasthāḥ phalamāyānti pelavā rasaleśakāḥ |
saṃniveśaṃ vrajantyetā rekhāḥ pallavapāliṣu
]

`v 25 [
navatāmanugṛhṇāti śakrabāṇāsanena ca |
yo `note[yoyo nūtanatāsaṃpādanapūrvako'nugrahaḥ] yo bhavatyavirataṃ
saṃsthānena vanena ca
]

`v 26 [
vasantamupatiṣṭhanti puṣpapallavarāśayaḥ |
nidāghavidhimāyānti daivadāhavibhūtayaḥ
]

`v 27 [
prāvṛṭsamayamīhante nīlā jaladarāśayaḥ |
śaradaṃ cānudhāvanti samagrāḥ phalarāśayaḥ
]

`v 28 [
hemante himahāsinyo bhavanti kakubho daśa |
nayantyupalatāmambu śiśire śītalānilāḥ
]

`v 29 [
na jahāti svamaryādāṃ kālo yugamayīmimām |
taraṅgiṇītaraṅgaughalīlayā yānti sṛṣṭayaḥ
]

`v 30 [
niyatiḥ sthitimāyāti sthairyacāturyakāriṇī |
tiṣṭhatyāpralayaṃ dhīrā dharādharaṇadharmiṇī
]

`v 31 [
caturdaśavidhānīha bhūtāni bhuvanāntare |
nānācāravihārāṇi nānāviracanāni ca
]

`v 32 [
punaḥpunarvilīyante jāyante ca punaḥpunaḥ |
dhārāparamparā yāti vinā vārīva budbudāḥ
]

`v 33 [
āyāti yāti paritiṣṭhati līlayāṭi-
svārthānupārjayati dhāvati janmanāśaiḥ |
unmattavadvihitabhāvanamāhitehā
mugdhā kṛtāntavivaśā janatā varākī
]