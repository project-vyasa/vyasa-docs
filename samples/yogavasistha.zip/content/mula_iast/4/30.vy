`v 1 [
triṃśaḥ sargaḥ 30
śrīvasiṣṭha uvāca |
iti tuṣṭeṣu deveṣu dānaveṣu hateṣu ca |
dāmavyālakaṭā `note[dāmavyālakaṭādīnāṃ iti ṣaṣṭhībahuvanvanāntaḥ
pāṭhaḥ prāṅmudrite ādarśāntare ca labhyate tatsvārasyaṃ tu
dhīdhiṣaṇebhya eva samadhigantavyam] dīnā babhūvurbhayavihvalāḥ
]

`v 2 [
jajvāla kupitaḥ kveti kalpāntāgniriva jvalan |
śambaraḥ śamitānīko dāmavyālakaṭānprati
]

`v 3 [
śambarasya bhayādgatvā pātālamatha saptamam |
dāmavyālakaṭāstasthustyaktvātha nijamaṇḍalam
]

`v 4 [
saptamaṃ pātālameva viśinaṣṭi - yamasyeti | tatrāpi śambarādbhayaṃ kiṃ na
syāditi śaṅkāṃ vārayituṃ kālatrāsanakṣamā iti | kālo mṛtyurivānyeṣāṃ
trāsanakṣamā ityarthaḥ
]

`v 5 [
te teṣāmatha yātānāṃ dattvā bhayamabhīravaḥ |
cintā iva ghanākārāḥ kumārīśca daduḥ kramāt
]

`v 6 [
taiḥ sārdhaṃ nītavantaste tatra dāmādayo'vadhim |
daśavarṣasahasrāntamāntānantakuvāsanāḥ
]

`v 7 [
iyaṃ me kāminī kanyā mameyaṃ prabhuteti ca |
durūḍhasnehabandhānāṃ kālasteṣāṃ vyavartata
]

`v 8 [
dharmarājo'tha taṃ deśaṃ kadācitsamupāyayau |
mahānarakakāryāṇāṃ vicārārthaṃ yadṛcchayā
]

`v 9 [
aparijñātamenaṃ te dharmarājaṃ trayo'surāḥ |
na praṇemurvināśāya sāmānyamiva kiṅkaram
]

`v 10 [
atha vaivasvatenaite jvalitāsūgrabhūmiṣu |
vihitabhrūparispandamātreṇaiva niveśitāḥ
]

`v 11 [
tatra te karuṇākrandāḥ sasuhṛddārabandhavaḥ |
pradagdhāḥ parṇaviṭapā vṛkṣā iva vanānilaiḥ
]

`v 12 [
svayā vāsanayā jātāstayaiva krūrayā punaḥ |
bandhakarmakarākārāḥ kirātā rājakiṅkarāḥ
]

`v 13 [
tajjanmātha parityajya jātāḥ śvabhreṣu vāyasāḥ |
tadante gṛdhratāṃ yātāstato'pi śukatāṃ gatāḥ
]

`v 14 [
sūkaratvaṃ trigarteṣu meṣatvaṃ parvateṣu ca |
magadheṣvatha kīṭatvaṃ babhruste `note[te vakrabuddhaya iti pāṭhaḥ] ca
kubuddhayaḥ
]

`v 15 [
anubhūyetarāmanyāṃ citrāṃ yoniparamparām |
adya matsyāḥ sthitā rāma kāśmīrāraṇyapalvale
]

`v 16 [
dāvāgnikvathitālpālpapaṅkakalpāmbupāyinaḥ |
na mriyante na jīvanti jarajjambālajarjarāḥ
]

`v 17 [
vicitrayonisaṃrambhamanubhūya punaḥpunaḥ |
bhūtvā bhūtvā punarnaṣṭāstaraṅgā jaladhāviva
]

`v 18 [
bhavajaladhigatāste vāsanātantununnā-
stṛṇamiva ciramūḍhā deharūpaistaraṅgaiḥ |
upaśamamupayātā rāma nādyāpyanantaṃ
parikalaya mahattvaṃ dāruṇaṃ vāsanāyāḥ
]