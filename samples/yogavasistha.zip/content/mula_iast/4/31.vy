`v 1 [
ekatriṃśaḥ sargaḥ 31
śrīvasiṣṭha uvāca |
ataḥ prabodhāya tava vacmi rāma mahāmate |
dāmavyālakaṭanyāyo mā te'stviti tu līlayā
]

`v 2 [
avivekānusaṃdhānāccittamāpadamīdṛśīm |
anantabhavaduḥkhāya parigṛhṇāti helayā
]

`v 3 [
kva kilāmaravidhvaṃsiśambarānīkanāthatā |
kva tāpataptajambālajālajarjaramīnatā
]

`v 4 [
kva dhairyamamarānīkavidrāvaṇakaraṃ mahat |
kva kirātamahīpālakṣudrakiṅkararūpatā
]

`v 5 [
kva nāma nirahaṅkāracitsattvodāradhīratā |
kva mithyāvāsanāveśādahaṅkārakukalpanā
]

`v 6 [
śākhāpratānagahanā saṃsāraviṣamañjarī |
ahaṅkārāṅkurā deva samudetīyamātatā
]

`v 7 [
ahaṅkāramato rāma mārjayāntaḥ prayatnataḥ |
ahaṃ na kiṃcideveti bhāvayitvā sukhī bhava
]

`v 8 [
ahaṅkārāmbudacchannaṃ paramārthendumaṇḍalam |
rasāyanamayaṃ śītamadṛśyatvamupāgatam
]

`v 9 [
ahaṅkārapiśācārtā dāmavyālakaṭāstrayaḥ |
gatāḥ sattāmasanto'pi māyāmāhātmyadānavāḥ
]

`v 10 [
kāśmīreṣu mahāraṇyasarasīvanapalvale |
adya matsyāḥ sthitā rāma śaivālalavalālasāḥ
]

`v 11 [
śrīrāma uvāca |
nāsato vidyate bhāvo nābhāvo vidyate sataḥ |
te hyasantaḥ kathaṃ sattāṃ saṃpannā iti me vada
]

`v 12 [
śrīvasiṣṭha uvāca |
evametanmahābāho nāsatsaṃbhavati kvacit |
kadācitkiṃcidapyeva bṛhatsaṃpadyate tanu
]

`v 13 [
kimasatsaṃsthitaṃ brūhi kiṃ tatsadvātha saṃsthitam |
samyaṅgidarśanenaiva kariṣye tava bodhanam
]

`v 14 [
śrīrāma uvāca |
santa eva sthitāḥ santo brahmanvayamime kila |
dāmādayastvasanto'pi vakṣi santaḥ sthitā iti
]

`v 15 [
śrīvasiṣṭha uvāca |
yathā dāmādayo rāma sthitā māyāmayā iti |
asatyā eva satyābhā mṛgatṛṣṇāmbupūravat
]

`v 16 [
tathaiveme vayamapi sasurāsuradānavāḥ |
asatyā eva valgāmo yāma āyāma eva ca
]

`v 17 [
alīkameva tvadbhāvo madbhāvo'līkameva ca |
anubhūto'pyasadrūpaḥ svapne svamaraṇaṃ yathā
]

`v 18 [
mṛto bandhuryathā svapne'pyanubhūto'pyasanmayaḥ |
mṛto'yamiti cejjñaptirbhavedevamidaṃ jagat
]

`v 19 [
eṣātimūḍhaviṣaya uktireva na rājate |
abhyāsena vinodeti nānubhūterapahnavaḥ
]

`v 20 [
niścayo'ntaḥprarūḍho yaḥ saṃpanno'bhyasanaṃ vinā |
nāśamāyāti loke'sminna kadācana kasyacit
]

`v 21 [
idaṃ jagadasadbrahma satyamityeva vakti yaḥ |
tamunmattamivonmatto vimūḍho'pi hasatyalam
]

`v 22 [
ata eva hyanadhikāriṇyupadeśavākyamunmattapralapitaprāyatvāda##-
akṣībakṣībayoraikyaṃ kva kilehājñatajjñayoḥ |
andhaprakāśayorbodhe syācchāyātapayoriva
]

`v 23 [
yatnenāpyanubhūto'rthaḥ satye kartumapahnavam |
ajño'ntaśca na śaknoti śavamākramaṇaṃ yathā
]

`v 24 [
brahma sarvaṃ jagaditi vaktuṃ nājñasya yujyate |
tapovidyānanubhave sa tadevānubhūtavān
]

`v 25 [
abuddhaviṣaye hyeṣā rāma vākpravirājate |
buddhasyāsmīti rūpeṇa kila nāstyeva kiṃcana
]

`v 26 [
brahmaivedaṃ paraṃ śāntamityevānubhavansudhīḥ |
apahnavaḥ svānubhūteḥ kartuṃ tasya kva yujyate
]

`v 27 [
parasmādvyatirekeṇa nāhamātmani kiṃcana |
hemanīvormikāditvaṃ na mayyasti viśiṣṭatā
]

`v 28 [
bhūtatā vyatirekeṇa mūḍhe nātmani kiṃcana |
ūrmyādibuddhau hemeva jñe nāsti paramārthatā
]

`v 29 [
mithyāhaṃtāmayo mūḍhaḥ satyaikātmamayaḥ sudhīḥ |
yujyate na kvacinnāma svabhāvāpahnavo'nayoḥ
]

`v 30 [
yo yanmayastasya tasminyujyate'pahnavaḥ katham |
puruṣasya ghaṭo'smīti vākyamunmattameva hi
]

`v 31 [
tasmānneme vayaṃ satyā naca dāmādayaḥ kvacit |
asatyāste vayaṃ ceme nāsti naḥ khalu saṃbhavaḥ
]

`v 32 [
satyaṃ saṃvedanaṃ śuddhaṃ bodhākāśaṃ nirañjanam |
satyaṃ sarvagataṃ śāntamastyanastamayodayam
]

`v 33 [
sarvaṃ śāntaṃ ca niḥśūnyaṃ na kiṃcidiva saṃsthitam |
tatra vyomni vibhāntīmā nijā bhāso'ṅga sṛṣṭayaḥ
]

`v 34 [
yathā taimirikākṣasya sahajā eva dṛṣṭayaḥ |
keśoṇḍrakādivadbhānti tathemāstatra dṛṣṭayaḥ
]

`v 35 [
sa ātmānaṃ yathā vetti tathānubhavati kṣaṇāt |
cidākāśastato'satyamapi satyaṃ tadīkṣaṇāt
]

`v 36 [
na satyamasti nāsatyamiti tasmājjagattraye |
yadyathā vetti cidrūpaṃ tattathodetyasaṃśayam
]

`v 37 [
yadi satyekṣaṇātsatyaṃ svatastarhi jagatkiṃrūpamasti tatrāha - na satyamiti | 36
|
yathā dāmādayastadvadevamabhyuditā vayam |
satyāsatyāḥ kimatrāṅga tānpratyapi vikalpanā
]

`v 38 [
asyānantasya cidbyomnaḥ sarvagasya nirākṛteḥ |
cidudeti yathā yāntastathā sā tatra bhātyalam
]

`v 39 [
yatra dāmādirūpeṇa saṃvitprakacitā svayam |
tathā sā tatra saṃpannā tathākārānubhūtitaḥ
]

`v 40 [
asmadādisvarūpeṇa saṃvidyatroditā svayam |
tathāsau tatra saṃpannā tathākārānubhūtitaḥ
]

`v 41 [
svasvapnapratibhāsasya jagadityabhidhā kṛtā |
cidvyomno vyomavapuṣastāpasyeva mṛgāmbutā
]

`v 42 [
yatra prabuddhaṃ cidvyoma tatra dṛśyābhidhā kṛtā |
yatra suptaṃ tu tenaiva tatra mokṣābhidhā kṛtā
]

`v 43 [
naca tatkvacidāsuptaṃ na prabuddhaṃ kadācana |
cidvyoma kevalaṃ dṛśyaṃ jagadityavagamyatām
]

`v 44 [
idaṃ tu bodhanāyāvasthādvayaṃ sādṛśyakalpanayoktaṃ paramārthatastvāha ##-
nirvāṇameva sargaśrīḥ sargaśrīreva nirvṛtiḥ |
nānayoḥ śabdayorarthabhedaḥ paryāyayoriva
]

`v 45 [
paramārtho jagaditi rūpaṃ vetti svayaṃ svakam |
yathā taimirikaṃ cakṣuḥ keśoṇḍrakamivekṣate
]

`v 46 [
uktamupapādayati - paramārtha iti dvābhyām | svayaṃ ajñānopahita ātmā | 45
|
na tatkeśoṇḍrakaṃ kiṃcitsā hi dṛṣṭistathā sthitā |
nedaṃ dṛśyamidaṃ kiṃciditthaṃ cidvyoma saṃsthitam
]

`v 47 [
sarvatra sarvamidamasti yathānubhūtaṃ
no kiṃcana kvacidihāsti na cānubhūtam |
śāntaṃ sadekamidamātatamitthamāste
saṃtyaktaśokabhayabhedamatastvamāssva
]

`v 48 [
śilodarākāraghanaṃ praśāntaṃ
mahācite rūpamidaṃ svamaccham |
naivāsti nāstīti dṛśau kvacittu
yaccāsti tatsādhu tadeva bhāti
]