`v 1 [
pañcacatvāriṃśaḥ sargaḥ 45
śrīvasiṣṭha uvāca |
jagatsaṃpannamevedaṃ saṃpannaṃ kiṃcideva na |
śūnyameva ca bhāmātraṃ manovilasitaṃ sthitam
]

`v 2 [
na deśakālāvetena brahmāṇḍenāvṛtau sthitau |
manāgapi mahārūpavatāpyākāśarūpiṇā
]

`v 3 [
etatsaṃkalpamātrātma svapnadṛṣṭapuropamam |
yatraiva tatra tacchūnyaṃ kevalaṃ vyoma saṃsthitam
]

`v 4 [
abhittirāgaracanamapi dṛṣṭamasanmayam |
akṛtaṃ kṛtamevaitadvyomni citraṃ vicitrakam
]

`v 5 [
manasā kalpitaṃ sarvaṃ dehādibhuvanatrayam |
saṃsmṛtau kāraṇaṃ caitaccakṣurālokane yathā
]

`v 6 [
ābhāsamātraṃ hi jagadghaṭāvaṭapaṭabhramaiḥ |
āvartate na sadrūpātpṛthakkuḍyādayaḥ sthitāḥ
]

`v 7 [
manasedaṃ śarīraṃ hi vāsanārthaṃ prakalpitam |
kṛmikośaprakāreṇa svātmakośa iva svayam
]

`v 8 [
yathā svātmanaḥ svayaṃ kośa iva prakalpitaṃ tathaiva idaṃ śarīraṃ svasya
vāsanārthaṃ sthityarthaṃ kṛmikośaprakāreṇa nīḍabhūtaṃ kalpitamityarthaḥ | 7
|
na tadasti ca yannāma cetaḥsaṃkalpamambaram |
na karoti na cāpnoti durgamapyatiduṣkaram
]

`v 9 [
sarvaśaktidhare deve kā nāma nanu śaktayaḥ |
na saṃbhavantyāśriyante yābhirantarmanoguhāḥ
]

`v 10 [
sattāsatte padārthānāṃ sarveṣāṃ sarvadaiva hi |
mahābāho saṃbhavataḥ sarvaśaktau vibhau sati
]

`v 11 [
paśya bhāvanayā prāptaṃ manasaivātmajaṃ vapuḥ |
tasmāttatkalanāṃ rāma sarvaśaktiyutāṃ viduḥ
]

`v 12 [
seyamaiśvarī sarvaśaktiḥ svamanasyeva pratyakṣaṃ dṛśyatāmityāha -
paśyeti | jagati vicitrapadārthaśaktayo'pi sarvaśaktimanmanaḥkalpanādevetyāha ##-
svasaṃkalpakṛtāḥ sarve devāsuranarādayaḥ |
svasaṃkalpopaśamane śāmyantyasnehadīpavat
]

`v 13 [
ākāśasadṛśaṃ sarvaṃ kalanāmātrajṛmbhitam |
jagatpaśya mahābuddhe sudīrghaṃ svapnamutthitam
]

`v 14 [
na jāyate na mriyate iha kiṃcitkadācana |
paramārthena sumate mithyā sarvaṃ tu vidyate
]

`v 15 [
na vṛddhimeti no hrāsaṃ yanna kiṃcitkadācana |
kiṃ vā tanu bhavettatra kasya kā nāma khaṇḍanā
]

`v 16 [
bhūmabhūtaṃ svakāyotthamapaśyannipuṇaṃ dṛśā |
rāghavā'mahatā svāntaḥ kimajña iva muhyasi
]

`v 17 [
mṛgatṛṣṇā yathā tāpānmanaso niścayāttathā |
asanta iva dṛśyante sarve brahmādayo'pyamī
]

`v 18 [
dvicandravibhramaprakhyā manorathavadutthitāḥ |
mithyājñānaghanāḥ sarve jagatyākārarāśayaḥ
]

`v 19 [
yathā nauyāyino mithyā sthāṇuspandamatistathā |
asatyaivotthitā nityamākārāṇāṃ paramparā
]

`v 20 [
indrajālamidaṃ viddhi māyāracitapañjaram |
manomanananirmāṇaṃ na sannāsadiva sthitam
]

`v 21 [
brahmaivedaṃ jagatsarvamanyatāyāstataḥ kutaḥ |
prasaṅgaḥ kīdṛśaḥ ko'sau kva vā sā paritiṣṭhati
]

`v 22 [
ayaṃ girirayaṃ sthāṇurityāḍambaravibhramaḥ |
manaso bhāvanādārḍhyādasansanniva lakṣyate
]

`v 23 [
prapañcapatanārambhaṃ pramattasya idaṃ jagat |
sakāmatṛṣnāmananaṃ tyaktvānyadrāma bhāvaya
]

`v 24 [
yathā svapno mahārambho bhrāntireva na vastutaḥ |
dīrghasvapnaṃ tathaivedaṃ viddhi cittopapāditam
]

`v 25 [
dṛśyamānamahābhogaṃ gṛhyamāṇamavastukam |
kośamāśābhujaṅgānāṃ saṃsārāḍambaraṃ tyaja
]

`v 26 [
asadetaditi jñātvā mā'tra bhāvaṃ niveśaya |
anudhāvati na prājño vijñāya mṛgatṣṇikām
]

`v 27 [
svasaṃkalpātsvarūpāḍhyāṃ manorathamayīṃ śriyam |
yo'nugacchati mūḍhātmā duḥkhasyaiva sa bhājanam
]

`v 28 [
vastunyasati loko'yaṃ yātu kāmamavastuni |
yastu vastu parityajya yātyavastu sa naśyati
]

`v 29 [
manovyāmoha evedaṃ rajjvāmahibhayaṃ yathā |
bhāvanāmātravaicitryācciramāvartate jagat
]

`v 30 [
asadbhyuditairbhāvairjalāntaścandravaccalaiḥ |
vañcayate bāla eveha na tattvajño bhavādṛśaḥ
]

`v 31 [
ya imaṃ guṇasaṃghātaṃ bhāvayansukhamīhate |
pramārṣṭi sa jaḍo jāḍyaṃ vahnibhāvanayā svayā
]

`v 32 [
asadevedamābhogi dṛśyate jalapañjaram |
manomanananirmāṇahṛdaye nagaraṃ yathā
]

`v 33 [
idaṃ cittecchayodeti līyate tadanicchayā |
mithyaivaṃ dṛśyate sphītaṃ gandharvanagaraṃ yathā
]

`v 34 [
rāma naṣṭe jagatyasminna kiṃcidapi naśyati |
yukte'pi ca jagatyasminna kiṃcidapi yujyate
]

`v 35 [
manaḥprakalpite bhagne hṛdi vistīrṇapattane |
vṛddhiṃ copagate brūhi kiṃ vṛddhaṃ kasya kiṃ kṣatam
]

`v 36 [
krīḍārthena yathodeti bālānāṃ hṛdi vartanam |
manasā tadvadevedamudetyavirataṃ jagat
]

`v 37 [
na kiṃcitkasyacinnaṣṭamindrajālajale yathā |
bhraṣṭe naṣṭe tathaivāsminsaṃsāre vitathotthite
]

`v 38 [
yadasattadasatsyāccenna kiṃ kasya kila kṣatam |
tato harṣaviṣādānāṃ saṃsāre nāma nāspadam
]

`v 39 [
asadeva yadatyantaṃ tasmātkiṃ nāma naśyati |
nāśābhāve hi duḥkhasya kaḥ prasaṅgo mahāmate
]

`v 40 [
sadeva vā yadatyantaṃ tasya kiṃ nāma naśyati |
brahmaivedaṃ jagatsarvaṃ sukhaduḥkhe kimutthite
]

`v 41 [
asadvāpi yadatyantaṃ vṛddhiḥ syāttasya kīdṛśī |
vṛddherabhāve harṣasya kaḥ prasaṅgo mahāmate
]

`v 42 [
sarvatrāsatyabhūte'sminprapañcaikāntakāriṇi |
saṃsāre kimupādeyaṃ prājño yadabhivāñchatu
]

`v 43 [
sarvatra satyabhūte'sminbrahmatattvamaye'pi ca |
kiṃ syāttribhuvane heyaṃ prājñāḥ pariharantu yat
]

`v 44 [
asatsadvā jagadvyasya tenāsau sukhaduḥkhayoḥ |
agamya eva mūrkhastu tadvināśena duḥkhitaḥ
]

`v 45 [
ādāvante ca yannāsit vartamāne'pi tattathā |
yo'bhivāñchatyasadrāma tasyāsattaiva dṛśyate
]

`v 46 [
ādāvante ca yatsatyaṃ vartamāne sadeva tat |
yasya sarvaṃ sadeva syāttasya sattaiva dṛśyate
]

`v 47 [
asatyabhūtaṃ toyāntaścandravyomatalādikam |
bālā evābhivāñchanti manomohāya nottamāḥ
]

`v 48 [
bālo hi vitatākārairvasturiktaiḥ prayojanaiḥ |
saṃtoṣametyanantāya duḥkhāya na sukhāya tu
]

`v 49 [
tasmānmā tvaṃ bhavo bālo rāma rājīvalocana |
avināśamihālokya nityamāśraya susthiram
]

`v 50 [
asadidamakhilaṃ mayā sametaṃ
tviti vigaṇayya viṣāditāstu mā te |
sadiha hi sakalaṃ mayā sametaṃ
tviti ca vilokya viṣāditāstu mā te
]

`v 51 [
śrīvālmīkiruvāca |
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]