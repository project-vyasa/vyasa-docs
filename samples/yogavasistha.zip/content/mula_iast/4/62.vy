`v 1 [
dviṣaṣṭitamaḥ sargaḥ 62
śrīvasiṣṭha uvāca |
dhīro vicāravānsākṣādādāveva mahādhiyā |
śāstreṇa viduṣā śāstraṃ sujanena vicārayet
]

`v 2 [
sujanena vitṛṣṇena viduṣā mahatā saha |
pravicārya mahāyogātpadamāsādyate param
]

`v 3 [
śāstrārthasujanāsaṅgavairāgyābhyāsasatkṛtaḥ |
puruṣastvamivābhāti nijavijñānabhājanam
]

`v 4 [
tvamudāranijācāro dhīro guṇagaṇākaraḥ |
adhitiṣṭhasi nirduḥkhaṃ vītasargamanomalaḥ
]

`v 5 [
nūnamutsarjitābhreṇa śaradvyomnā samo bhavān |
bhava bhāvanayā mukto yukta uttamasaṃvidā
]

`v 6 [
cintāmuktakalāvatyā muktakalpanayā sthitam |
mano muktavibhāgaṃ ca muktameva na saṃśayaḥ
]

`v 7 [
tavottamānubhāvasya ta idānīṃ narā bhuvi |
ceṣṭāmanusariṣyanti rāgadveṣavihīnayā
]

`v 8 [
vahirlokocitācārā vihariṣyanti ye janāḥ |
bhavārṇavaṃ tariṣyanti dhīmantaḥ potakānvitāḥ
]

`v 9 [
tava tulyamatiryaḥ syātsujanaḥ samadarśanaḥ |
yogyo'sau jñānadṛṣṭīnāṃ mayoktānāṃ sudṛṣṭimān
]

`v 10 [
yāvaddehaṃ dhiyā tiṣṭha rāgadveṣavihīnayā |
bahirlokocitācārastvantastyaktākhilaiṣaṇaḥ
]

`v 11 [
parāṃ śāntimupāgaccha yathānye guṇaśālinaḥ |
avicāryāsta eveha gomāyuśiśudharmakāḥ
]

`v 12 [
ye svabhāvā mahāsatyā nṛṇā sāttvikajanmanām |
tānbhajanpuruṣo yāti pāścātyodārajanmatām
]

`v 13 [
yāneva sevate tanturiha jātiguṇānsadā |
athānyajātijāto'pi `note[1] jātiṃ bhajati tāṃ kṣaṇāt
]

`v 14 [
prāktanānakhilānbhāvānyānti karmavaśaṃ gatāḥ |
pauruṣeṇāvajīyante dharādharamahākulāḥ
]

`v 15 [
dhairyeṇābhyuddharedbuddhiṃ paṅkānmugdhagavīmiva |
tāmasīṃ rājasīṃ caiva jātimanyāmapi śritaḥ
]

`v 16 [
svavivekavaśādyānti santaḥ sāttvikajātitām |
ataścittamaṇau svacche yadrāghava niyojyate
]

`v 17 [
tanmayo vibhavatyevaṃ tasmādbhavati pauruṣam |
pauruṣeṇa prayatnena mahārhaguṇaśālinaḥ
]

`v 18 [
mumukṣavo bhavantīha pāścātyaśubhajātayaḥ |
na tadasti pṛthivyāṃ vā divi deveṣu vā kvacit
]

`v 19 [
pauruṣeṇa prayatnena yannāpnoti guṇānvitaḥ |
brahmacaryeṇa dhairyeṇa vīryavairāgyaraṃhasā |
yuktyā yuktena hi vinā na prāpnoṣi tadīhitam
]

`v 20 [
hitaṃ mahāsattvatayātmatattvaṃ
vidhāya buddhyā bhava vītaśokaḥ |
tava krameṇaiva tato jano'yaṃ
mukto bhaviṣyatyatha vītaśokaḥ
]

`v 21 [
pāścātyajanmani vivekamahāmahimnā
yukte tvayi prasṛtasarvaguṇābhirāme |
sattvasthakarmaṇi padaṃ kuru rāmabhadra
maiṣā karotu bhavasaṅgavimohacintā
]