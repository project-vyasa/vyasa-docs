`v 1 [
aṣṭamaḥ sargaḥ 8
śrīvasiṣtha uvāca |
iti cittavilāsena ciramutprekṣitaiḥ priyaiḥ |
praṇayairbhārgavasyāsīttuṣṭaye susamāgamaḥ
]

`v 2 [
mandāramālākalayā vibudhāsavamattayā |
tadā tena tayā sārdhaṃ dvitīyenāmalendunā
]

`v 3 [
vihṛtaṃ mattahaṃsāsu hemapaṅkajinīṣu ca |
taṭīṣvamaravāhinyāḥ saha cāraṇakiṃnaraiḥ
]

`v 4 [
pītamindudalasyandairdevaiḥ saha rasāyanam |
pārijātalatājālanilayeṣu vilāsinā
]

`v 5 [
cārucaitrarathodyānalatālolāsudolayā |
ciraṃ vilasitaṃ vyagraiḥ saha vidyādharīgaṇaiḥ
]

`v 6 [
nandanopavanābhogo mandareṇeva vāridhiḥ |
bhṛśamāloḍyatāṃ nītaḥ prathamaiḥ saha śāmbhavaiḥ
]

`v 7 [
bālahemalatājālajaṭālāsu nadīṣu ca |
bhrāntamunmattanāgena mairavīṣvabjinīṣviva
]

`v 8 [
kailāsavanakuñjeṣu tayā saha vilāsinā |
harendudhavalā rātryaḥ kṣipitā gaṇagītibhiḥ
]

`v 9 [
gandhamādanaśailasya viśramyopari sānuṣu |
sā tena kanakāmbhojairāpādamabhimaṇḍitā
]

`v 10 [
lokālokataṭānteṣu vicitrāścaryahāriṣu |
krīḍitaṃ kṛtahāsena rāma tena tayā saha
]

`v 11 [
mandarāntarakaccheṣu sārdhaṃ hariṇaśāvakaiḥ |
avasatsa samāḥ ṣaṣṭiṃ kalpitāmaramandire
]

`v 12 [
kṣīrārṇavataṭīṣvasya vanitāsahacāriṇaḥ |
kṣīṇaṃ kṛtayugādardhaṃ śvetadvīpajanaiḥ saha
]

`v 13 [
gandharvanagarodyānalīlāviracanairasau |
sraṣṭānantajagatsṛṣṭeḥ kālasyānukṛtiṃ gataḥ
]

`v 14 [
athāvasadasau śukraḥ purandarapure punaḥ |
sukhaṃ caturyugānyaṣṭau hariṇekṣaṇayā saha
]

`v 15 [
puṇyakṣayānusaṃdhānāttataścāvanimaṇḍale |
tayaiva saha māninyā papātopahatākṛtiḥ
]

`v 16 [
parālūnasamastāṅgo hṛtasyandananandanaḥ |
cintāparavaśo dhvastaḥ samitīva hato bhaṭaḥ
]

`v 17 [
patitasyāvanau tasya cintayā saha dīrghayā |
śarīraṃ śatadhā jātaṃ śilāpātīva nirjharaḥ
]

`v 18 [
saṃśīrṇayordehakayościttake vyasanāvile |
viceratustayorvyomni nirnīḍau vihagau yathā
]

`v 19 [
tatrāviviśatuścāndraṃ te citte raśmijālakam |
prāleyatāmupetyāśu śālitāmatha jagmatuḥ
]

`v 20 [
śālīṃstānbhuktavānpakvāndaśārṇeṣu dvijottamaḥ |
sa śukraḥ śukratāmetya tadbhāryātanayo'bhavat
]

`v 21 [
tato munīnāṃ saṃsargāttapasyugre vyavasthitaḥ |
avasanmerugahane manvantaramaninditaḥ
]

`v 22 [
tatra tasya samutpanno mṛgyāḥ putro narākṛtiḥ |
tatsnehena paraṃ mohaṃ punarapyāyayau kṣaṇāt
]

`v 23 [
putrasyāsya dhanaṃ me'stu guṇāścāyuśca śāśvatam |
ityanāratacintābhirjahau satyāmavasthitim
]

`v 24 [
dharmacintāparibhraṃśātputrārthaṃ bhogacintayā |
kṣīṇāyuṣaṃ tamaharanmṛtyuḥ sarpa ivānilam
]

`v 25 [
bhogaikacintayā sārdhaṃ samamutkrāntacetanaḥ |
prāpya madreśaputratvamāsīnmadramahīpatiḥ
]

`v 26 [
madradeśe ciraṃ kṛtvā rājyamutsannaśātravam |
jarāmabhyājagāmātra himāśanirivāmbujam
]

`v 27 [
madrarājatanuṃ cāruṃ tapovāsanayā saha |
tatyāja tena jāto'sau tapasvī tāpasātmajaḥ
]

`v 28 [
samaṅgāyā mahānadyāstaṭamāsādya tāpasaḥ |
tapastepe mahābuddhiḥ sa rāma vigatajvaraḥ
]

`v 29 [
vividhajanmadaśāṃ vividhāśayaḥ
samanubhūya śarīraparamparāḥ |
sukhamatiṣṭhadasau bhṛgunandano
varanadīsutaṭe dṛḍhavṛkṣavat
]