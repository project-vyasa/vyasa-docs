`v 1 [
pañcatriṃśaḥ sargaḥ 35
śrīvasiṣṭha uvāca |
jayanti te mahāśūrāḥ sādhavo yairvinirjitam |
avidyāmedurollāsaiḥ svamano viṣayonmukham
]

`v 2 [
saṃsārasyāsya duḥkhasya sarvopadravadāyinaḥ |
upāya eka evāsti manasaḥ svasya nigrahaḥ
]

`v 3 [
śrūyatāṃ jñānasarvasvaṃ śrutvā caivāvadhāryatām |
bhogecchāmātrako bandhastattyāgo mokṣa ucyate
]

`v 4 [
kimanyaiḥ śāstrasaṃdarbhaiḥ kriyatāmidameva tu |
yadyatsvādviha tatsarvaṃ dṛśyatāṃ viṣavahnivat
]

`v 5 [
viṣamā viṣayābhogāḥ pravicārya punaḥpunaḥ |
upariṣṭātparityajya sevyamānāḥ sukhāvahāḥ
]

`v 6 [
doṣānprasavati sphārānvāsanāvalitā matiḥ |
kīrṇakaṇṭakabījā bhūḥ kaṇṭakaprasaraṃ yathā
]

`v 7 [
alagnavāsanājālā matiḥ prasaravarjitā |
adṛṣṭarāgadveṣā yā śamameti śanaiḥ param
]

`v 8 [
śubhāśubhānasadglānīnprasūte suguṇānsadā |
phaladānaṅkurānkāle śreṣṭhabījavatīva bhūḥ
]

`v 9 [
śubhabhāvānusaṃdhānātprasanne manasi sthite |
śanaiḥ śanaiḥ praśānte ca mithyājñānaghanāmbude
]

`v 10 [
vṛddhiṃ yāte ca saujanye yakṣe śukla ivoḍupe |
viveke prasṛte puṇye nabhasīvārkatejasi
]

`v 11 [
dhṛtāvantarvivṛddhāyāṃ muktāyāmiva kīcake |
sthitāvantaḥ kṛtārthāyāṃ madhāviva niśākare
]

`v 12 [
phalite śītalacchāye satsaṅgasaphaladrume |
sravatyānandasurase samādhisaraladrume
]

`v 13 [
mano bhavati nirdvandvaṃ niṣkāmaṃ nirupadravam |
praśāntacāpalānarthaśokamohabhayāmayam
]

`v 14 [
kṣīṇaśāstrārthasaṃdehaṃ vigatāśeṣakautukam |
nirastakalpanājālaṃ mohamuktamalepakam
]

`v 15 [
nirīhaṃ nirupākrośaṃ nirapekṣaṃ nirādhikam |
saṃśāntaśokanīhāramasaktaṃ granthivarjitam
]

`v 16 [
saṃdehograsutaṃ sāgraṃ satṛṣṇādārapañjaram |
nāśayitvā svamātmānaṃ sādhayatyarthamaiśvaram
]

`v 17 [
ātmapīvaratāhetūnvikalpāṃścāyamujjhati |
saṃsmṛtya prabhutāmeṣu jahāti tṛṇavattanum
]

`v 18 [
manaso'bhyudayo nāśo manonāśo mahodayaḥ |
jñamano nāśamabhyeti mano'jñasya vivardhate
]

`v 19 [
manomātraṃ jagaccakraṃ manaḥ parvatamaṇḍalam |
mano vyoma mano devo mano mitraṃ mano ripuḥ
]

`v 20 [
vikalpakaluṣā yā syāccittattvasyātmavismṛtiḥ |
mana ityucyate seyaṃ vāsanā bhavabhāginī
]

`v 21 [
cetyānupātakalitacinmātre tiṣṭhatābhidham |
manāgvikalpakaluṣaṃ cittattvaṃ jīva ucyate
]

`v 22 [
cetyaprapatitaṃ rūḍhasaṃjñamajñatvamāgatam |
tadevādhikaniḥsāraṃ kalpyate'ntarmanastayā
]

`v 23 [
yataścetye prapatitaṃ tatraiva cirābhyāsādrūḍhā saṃjñā ātmatvābhimāno yasya
tathāvidhaṃ yadajñatvaṃ svarūpavismaraṇamāgataṃ yajjīvarūpaṃ tadeva
vikalpasahasrairmomuhyamānatayā sārabhūtasukhasvabhāvatāpahārādyadā
adhikaniḥsāraṃ bhavati tadā jīvopakaraṇamanastayā bhedena kalpyata ityarthaḥ | 22
|
nātmā saṃsāripuruṣo na śarīraṃ na śoṇitam |
jaḍaṃ sarvaṃ śarīrādi dehī khavadalepakaḥ
]

`v 24 [
śarīre kaṇaśaḥ kṛtte nāstyanyadrudhirādikāt |
nirbhinne kadalīstambhe nāstyanyatpallavādṛte
]

`v 25 [
mano jīvo naraṃ viddhi tadevākāramāgatam |
ātmanātmānamādatte svavikalpātmakalpitam
]

`v 26 [
svavikalpānnarastatra prasārya racayatyalam |
jālamātmanibandhāya kośakārakṛmiryathā
]

`v 27 [
imaṃ dehabhramaṃ tyaktvā deśakālāntare punaḥ |
śarīratvamathādatte pallavatvamivāṅkuraḥ
]

`v 28 [
taddehātmakatvābhāve yuktimāha - imamiti | śarīratvaṃ dehāntarabhāvam |
27 |
yādṛgvāsanametatsyānmanastādṛkprajāyate |
jātaṃ svapiti yaccittaṃ tatsvapne niśi tiṣṭhati
]

`v 29 [
amlaṃ madhurasāsiktaṃ madhuraṃ madhurañjitam |
bījaṃ prativiṣākalkasiktaṃ ca kaṭu jāyate
]

`v 30 [
śubhavāsanayā ceto mahatyā jāyate mahat |
bhavatīndramanorājya indratā svapnabhāṅnaraḥ `note[svapnabhāṅkuraḥ iti
kvacit]
]

`v 31 [
kṣudravāsanayā cetaḥkṣudratāmapi pelavām |
piśācavibhramātsvapne piśācānniśi paśyati
]

`v 32 [
sarasi sphāranairmalye kāluṣyaṃ yāti na sthitim |
tathaiva sphārakāluṣye prasādo yāti na sthitim
]

`v 33 [
manasi sphārakāluṣye tadrūpaṃ jāyate phalam |
tathaiva sphāranairmalye tadrūpaṃ jāyate phalam
]

`v 34 [
tyajatyudārāṃ na gatiṃ kṣīṇo'pyaniśamuttamaḥ |
udyogavānavirataṃ pūraṇāśāmivoḍupaḥ
]

`v 35 [
neha bandho na mokṣo'sti nābandho'sti `note[na bodhyo na ca bandhanaṃ iti
pāṭhaḥ | ādye na bandhatetyatra bandhaśabdādarśa ādyatvi
bandhavattetyarthaḥ] na bandhatā |
mithyotthitaiva māyeyamindrajālalatā yathā
]

`v 36 [
gandharvanagarākārā mṛgatṛṣṇā ivotthitā |
dvicandravibhramābhāsā dvaitaikatvavivarjitā
]

`v 37 [
sarvaiva brahmasatteyamityeṣā paramārthatā |
parisphurati niḥsāraḥ saṃsāro'yamasanmayaḥ
]

`v 38 [
nānanto'haṃ varāko'hamiti durniścayoditaḥ |
ananto'smīśvaro'smīti niścayena vilīyate
]

`v 39 [
sarvage svātmani svacche eṣo'hamiti bhāvanā |
etattadbandhanaṃ loke svavikalpopakalpitam
]

`v 40 [
bandhamokṣadaśāhīnā dvitvaikatvavivarjitā |
sarvaiva brahmasatteyamityeṣā paramārthatā
]

`v 41 [
nairmalyaprāptamaraṇamasaktaṃ sarvadṛṣṭiṣu |
amanastvamihāpannaṃ brahma paśyati nānyathā
]

`v 42 [
mano nirmalatāṃ yātaṃ śubhasaṃtānavāribhiḥ |
brāhmīṃ dṛṣṭimupādatte rāgaṃ śuklapaṭo yathā
]

`v 43 [
sarvameva mamātmeti sarvabhāvanayānagha |
heyādeyabale kṣīṇe bandhamokṣo vimucyatām
]

`v 44 [
śuddhasya manasaḥ kāyaśāstravairāgyabuddhibhiḥ |
abhijātopalasyeva jagattasyeti `note[jagattasyaiveti pāṭhaḥ] vidyutiḥ
]

`v 45 [
padārthenaikatāmetya manaso naikatānatā |
asatyajñānadṛṣṭiṃ tāṃ viddhi kṣaṇavināśinīm
]

`v 46 [
sabāhyābhyantaraṃ tyaktvā sarvāṃ dṛśyadṛśaṃ yadā |
manastiṣṭhati tallīnaṃ saṃprāptaṃ tatpadaṃ tadā
]

`v 47 [
dṛśyadṛṣṭiḥ sphuṭā yeyaṃ sā hyavaśyamasanmayī |
tanmayatvaṃ ca manasaḥ svarūpaṃ viddhi netarat
]

`v 48 [
ādyantayorvināśitvānmadhye'pi tadasanmayam |
ajñātamanasastena duḥkhitā hastasaṃsthitā
]

`v 49 [
ātmaivedaṃ jagaditi vinā bhāvena duḥkhadā |
dṛśyaśrīranyathā tveṣā bhogamokṣapradāyinī
]

`v 50 [
jalamanyattaraṅgo'nya iti nānātayā'jñatā |
jalameva taraṅgo'yamityekatvātkila jñatā
]

`v 51 [
duḥkhamāyātyasaditi heyopādeyarūpi yat |
tadabhāvena tu jñānādānantyamavaśiṣyate
]

`v 52 [
saṃkalpakalpitatvācca manorūpamasanmayam |
asanmayavināśe tu kaḥ śoko vada rāghava
]

`v 53 [
avatsalo yathā bandhurarāgadveṣayā dhiyā |
dṛśyate paśya tadvattvaṃ tattvaṃ pañjaramātmanaḥ
]

`v 54 [
avatsalādyathā bandhoḥ sukhaduḥkhairna lipyate |
tattvena `note[jñāneneti pāṭhāntaram] saṃparijñānāttathā
tattvacayātmanaḥ
]

`v 55 [
tadanādi śivaṃ jñānaṃ yanmadhyaṃ draṣṭṛdṛśyayoḥ |
tasminsatye manaḥ śāntaṃ pāṃsurvāyukṣaye yathā
]

`v 56 [
yasminnadhiṣṭhāne manaḥkṣayastatsvarūpamāha - taditi | śivaṃ
nityaniratiśayānandarūpam | draṣṭṛdṛśyayormadhyaṃ dṛgrūpamityarthaḥ |
55 |
upaśānte manovāyau dehapāṃsuḥ praśāmyati |
punaḥ saṃsāranagare na nīhāraḥ pravartate
]

`v 57 [
vāsanāprāvṛṣi kṣīṇe saṃsthitau rāmamāgate |
jāḍye janitahṛtkampe paṅke śoṣamupāgate
]

`v 58 [
śuṣke tṛṣnāvaṭe śānte mande hṛdayakānane |
kṣīṇeṣvakṣakadambeṣu mithyājñānaghane kṣate
]

`v 59 [
kṣīyate mohamihikā prabhāta iva śarvarī |
kvāpi gacchati tajjāḍyaṃ viṣaṃ mantrahataṃ yathā
]

`v 60 [
dehādrau na bhayakṣudrāḥ saritaḥ prasarantyalam |
nollasanti lasatpakṣāḥ saṃkalpograkalāpinaḥ
]

`v 61 [
parāṃ nirmalatāmeti saṃvidākāśagocaraḥ |
rājate'titarāmaccho jīvādityo mahodayaḥ
]

`v 62 [
ghanamohabharonmuktā viviktatvaṃ paraṃ gatāḥ |
samaye hyatiśobhante dhautā āśā mahādiśaḥ
]

`v 63 [
bhṛśamābhāti vimalā muditākāśamañjarī |
śītalīkṛtadikcakrā śaradvyomnīva candrikā
]

`v 64 [
sarvasaṃpatprakāśena paramānandadāyinā |
bhṛśaṃ saphalatāmeti suviviktā vivekabhūḥ
]

`v 65 [
saparvatavanābhogaṃ paramālokasundaram |
acchācchaṃ śitalacchāyaṃ jāyate bhuvanāntaram
]

`v 66 [
paramālokenātmaprakāśena sūryacandrajyotiṣā ca tattvapakṣe śītalā
trividhatāpaśūnyā chāyā cidābhāso yasminnityarthaḥ | śaratpakṣe spaṣṭam | 65
|
vistāritaṃ susumatāṃ sphāritaṃ sphaṭikākṛtim |
upaiti hṛtsaraḥ svacchaṃ nīrajombujakośakam
]

`v 67 [
hṛtpadmakośānmalinaḥ svāhaṃkāramadhuvrataḥ |
apunardarśanāyaiva cañcalaḥ kvāpi gacchati
]

`v 68 [
bhavatyapagatākṣepaḥ sarvagaḥ sarvanāyakaḥ |
nirvāsanaḥ śāntamanāḥ svadehanagareśvaraḥ
]

`v 69 [
vicāraṇāsamadhigatātmadīpako
manasyalaṃ parigaliteva dhīradhīḥ |
vilokayankṣyabhavanīrasā gatī-
rgatajvaro vilasati dehapattane
]