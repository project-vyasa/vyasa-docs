`v 1 [
saptatriṃśaḥ sargaḥ 37
śrīvasiṣṭha uvāca |
itthaṃ sthiratarākārāḥ saṃsārāvalayo'bhitaḥ |
svabhāvādbrahmaṇaḥ sarvāḥ punarāyānti yānti ca
]

`v 2 [
svataḥ sarvamidaṃ jātamanyonyaṃ hetutāṃ gatam |
anyonyamabhinaśyattatsvata eva vilīyate
]

`v 3 [
svato'spando'pi tu spando yathā'gādhajalodare |
tathaiveyamasatsacca cideva paridṛśyate
]

`v 4 [
vyomanyeva nirākāre nidāghātsarito yathā |
lakṣyante tadvadevemāścittattve sṛṣṭidṛṣṭayaḥ
]

`v 5 [
yathā madavaśādātmā so'nyavatpratibhāsate |
tathaiva cittvācciddhātuḥ sa evā'sa iva sthitaḥ
]

`v 6 [
na cedaṃ sadasannedaṃ tatsthātatsthatayā citaḥ |
nātiriktātiriktā ca kaṭakādiṣu hematā
]

`v 7 [
yena śabdaṃ rasaṃ rūpaṃ gandhaṃ jānāsi rāghava |
so'yamātmā paraṃ brahma sarvamāpūrya saṃsthitaḥ
]

`v 8 [
nānaikatvādatītāttu sarvagādamalātmanaḥ |
dvitīyā kalanā nāsti kācinnetarathā kvacit
]

`v 9 [
nanu pratīcāṃ nānātvādbrahmaṇaścaikatvātkathamaikyamityāśaṅkya
nānaikatvayormithyātvānnāyaṃ doṣa ityāśayenāha - nānaikatvādatītāditi | 8
|
rāma bhāvanādanyasya bhāvābhāvāḥ śubhāśubhāḥ |
sṛṣṭayaḥ parikalpyante'nātmanyevāthavātmani
]

`v 10 [
yasmādātmano vyatirikte vastuni siddhe sati tatrecchā pravartate | yatra
svātmano vyatiriktaṃ na kiṃcidapi saṃbhavati tatrātmā kimiva
vāñchankimanusmarandhāvatu kimupaitu
]

`v 11 [
ata idamīhitamidamanīhitamityātmānaṃ na spṛśanti vikalpāḥ | ato
niricchatāyāmātmā na kiṃcidapi karoti kartṛkaraṇakarmaṇāmekatvāt na
kvacittiṣṭhatyādhārādheyayorekatvāt naca niricchasyātmano `note[1]
naiṣkarmyamabhimatam dvitīyāyāḥ kalpanāyā abhāvāt
]

`v 12 [
netarā jānāsi rāma tvamiyaṃ brahmasaṃsthitiḥ |
sarvadvandvavinirmuktaḥ kartā bhava gatajvaraḥ
]

`v 13 [
anyacca rāghava punaḥ
punaḥ kṛtvā kṛtvā bahuvidhamidaṃ karma tarasā
tvayā prāpyaṃ kiṃ tadvada yaducitaṃ bhūtakaraṇāt |
akartṛtve vāsthā bhavatu tava cāpyāgamavato
bhava svasthaḥ svacchaḥ stimita iva nirvātajaladhiḥ
]

`v 14 [
gatvā sudūramapi yatnavatā javena
nāsādyate tadiha yena supūrṇataiti |
matveti mā vraja padārthagaṇāndhiyā tvaṃ
na tvaṃ tvameva paramārthatayā cidātmā
]