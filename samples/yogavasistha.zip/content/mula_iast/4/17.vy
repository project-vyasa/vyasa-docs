`v 1 [
saptadaśaḥ sargaḥ 17
śrīrāma uvāca |
bhagavanbhṛguputrasya pratibhāsānubhūtitaḥ |
yathaiṣā saphalā jātā tathānyasya na kiṃ bhavet
]

`v 2 [
śrīvasiṣṭha uvāca |
iyaṃ prathamamutpannā sā tanurbrahmaṇaḥ padāt |
śuddhā jātirbhārgavasya nānyajanmakalaṅkitā
]

`v 3 [
sarvaiṣaṇānāṃ saṃśāntau śuddhacittasya yā sthitiḥ |
tatsatyamucyate saiṣā vimalā cidudāhṛtā
]

`v 4 [
manonirmalasattvātma yadbhāvayati yādṛśam |
tattathāśu bhavatyeva yathāvarto bhavetpayaḥ
]

`v 5 [
yathā bhṛgusutasyaiva bibhramaḥ protthitaḥ `note[sotthitaḥ iti pāṭhaḥ]
svayam |
pratyekamapyevameva dṛṣṭānto'tra bhṛgoḥ sutaḥ
]

`v 6 [
bījasthāṅkurapatrādi svaṃ camatkurute yathā |
sarveṣāṃ bhūtasaṅghānāṃ bhramakhaṇḍāstathaiva hi
]

`v 7 [
yadidaṃ dṛśyate viśvamevamevākhilaṃ jagat |
pratyekamuditaṃ mithyā mithyaivāstamupaiti ca
]

`v 8 [
nāstameti nacodeti jagatkiṃcana kasyacit |
bhrāntimātramidaṃ māyāmugdheva parijṛmbhate
]

`v 9 [
yathā saṃpratibhāsasthaḥ svayaṃ saṃsārakhaṇḍakaḥ |
tathā teṣāṃ sahasrāṇi mithyā dṛṣṭāni santi hi
]

`v 10 [
svapnasaṃkalpanagaravyavahārāḥ parasparam |
pṛthagyathā na dṛśyante tathaite saṃsṛtibhramāḥ
]

`v 11 [
evaṃ nagaravṛndāni nabhassaṃkalparūpiṇi |
santi tāni na dṛśyante mithyājñānadṛśaṃ vinā
]

`v 12 [
piśācayakṣarakṣāṃsi santyevaṃrūpakāṇi ha |
saṃkalpamātradehāni sukhaduḥkhamayāni ca
]

`v 13 [
evameva vayaṃ ceme saṃpannā raghunandana |
svasaṃkalpātmakākārā mithyāsatyatvabhāvinaḥ
]

`v 14 [
evaṃrūpaiva hi pare vidyate sargasaṃtatiḥ |
na vāstavī vastutā tu saṃsthitaivamavastuni
]

`v 15 [
pratyekamuditaṃ viśvamevameva mughaiva hi |
vanagulmakarūpeṇa vasantaikaraso yathā
]

`v 16 [
prathamo'yaṃ svasaṃkalpaḥ prathāmabhyāgato yathā |
tathātiparamārthena dṛṣṭenetthaṃ vibhāvyate
]

`v 17 [
pratyekamuditaṃ cittaṃ svasvabhāvodarasthitam |
idamitthaṃ samārambhaṃ jagatpaśyanvinaśyati
]

`v 18 [
pratibhāsavaśādasti nāsti vastvavalokanāt |
dīrghasvapno jagajjālamālānaṃ cittadantinaḥ
]

`v 19 [
citsattaiva jagatsattā jagatsattaiva cittakam |
ekābhāvāddvayornāśaḥ sa ca satyavicāraṇāt
]

`v 20 [
śuddhasya pratibhāso hi satyo bhavati cetasaḥ |
pramārjanādiva maṇermalinasyeha yuktitaḥ
]

`v 21 [
ciramekadṛḍhābhyāsācchuddhirbhavati cetasaḥ |
anākrāntasya saṃkalpaiḥ pratibhodeti cetasaḥ
]

`v 22 [
suvarṇaṃ na sthitiṃ yāti malavatyaṃśuke yathā |
ekā dṛṣṭiḥ sthitiṃ yāti na mlāne cittake tathā
]

`v 23 [
suvarṇaṃ śobhanavarṇaṃ rañjakadravyaṃ drutasvarṇaṃ vā | malavatyaṃśuke
malinavastre | ekā dṛṣṭiradvaitātmajñānam | 22 |
śrīrāma uvāca |
pratibhāsātmani jagatyete kālakriyākramāḥ |
sodayāstamayā jātāḥ kathaṃ śukrasya cetasaḥ
]

`v 24 [
śrīvasiṣṭha uvāca |
yādṛgjagadidaṃ dṛṣṭaṃ śukreṇa pitṛśāstrataḥ |
tādṛkkasya sthitaṃ citte mayūrāṇḍe mayūravat
]

`v 25 [
svabhāvakośasthamidaṃ tadetena kramoditam |
bījenāṅkurapatrādilatāpuṣpaphalaṃ yathā
]

`v 26 [
jīvo yadvāsanābaddhastadevāntaḥ prapaśyati |
svarūpaṃ cātra dṛṣṭānto dīrghasvapnastvidaṃ jagat
]

`v 27 [
svarūpaṃ svapne svakalpitaṃ śarīram | nanu nāyaṃ svapno netyāha - dīrgheti |
26 |
pratyekamudito rāma nūnaṃ saṃsṛtikhaṇḍakaḥ |
rātrau sainyanarasvapnajālavatsvātmani sphuṭaḥ
]

`v 28 [
yathā sainyasthā narā divā sainyavāsanāvāsitā rātrau svapne pratyekaṃ sainyaṃ
svasvavāsanākalpitaṃ nānāsainyaṃ paśyanto'pi aikyaṃ manyante tadvadityarthaḥ |
27 |
śrīrāma uvāca |
eṣa saṃsṛtikhaṇḍottho mithaḥ sa milati svayam |
no vā milati tanme tvaṃ yathāvadvaktumarhasi
]

`v 29 [
śrīvasiṣṭha uvāca |
malinaṃ hi mano'vīryaṃ na mithaḥ śleṣamarhati |
ayo'yasi ca saṃtapte śuddhe taptaṃ tu līyate
]

`v 30 [
cittatattvāni śuddhāni saṃmilanti parasparam |
ekarūpāṇi toyāni yāntyaikyaṃ nāvilāni hi
]

`v 31 [
śuddhirhi cittasya vivāsanatva-
mabhūtasaṃvedanamekarūpam |
tasyāśu śuddhyāṃ bhavati prabuddha-
stanmātrayuktyā parasaṃgameti
]