`v 1 [
ekaviṃśaḥ sargaḥ 21
śrīrāma uvāca |
bhagavansarvadharmajña saṃśayo yo mahānayam |
hṛdi vyāvartate lolaḥ kallola iva sāgare
]

`v 2 [
dikkālādyanavacchinne tate nitye nirāmaye |
mlānā saṃvinmanonāmnī kutaḥ keyamupasthitā
]

`v 3 [
yasmādanyanna nāmāsti na bhūtaṃ na bhaviṣyati |
kutaḥ kīdṛkkathaṃ tatra kalaṅkastasya vidyate
]

`v 4 [
śrīvasiṣṭha uvāca |
sādhu rāma tvayā proktaṃ jātā te mokṣabhāginī |
matiruttamaniṣyandā nandanasyeva mañjarī
]

`v 5 [
pūrvāparavicārārthatatpareyaṃ matistava |
saṃprāpsyasi padaṃ proccairyatprāptaṃ śaṃkarādibhiḥ
]

`v 6 [
praśnasyāsya tu he rāma na kālastava saṃprati |
siddhāntaḥ kathyate yatra tatrāyaṃ praśna ucyate
]

`v 7 [
siddhāntakāle bhavatā praṣṭavyo'hamidaṃ param |
karāmalakavattena siddhāntaste bhaviṣyati
]

`v 8 [
siddhāntakāle praśnoktireṣā tava virājate |
prāvṛṣīva hi kekoktiryuktā śaradi haṃsagīḥ
]

`v 9 [
sahajo nīlimā vyomni śobhate prāvṛṣaḥ kṣaye |
prāvṛṣi tvatanūdagrapayodapaṭalotthitaḥ
]

`v 10 [
sāṃprataṃ tvayaṃ praśnaḥ prāvṛṣi nabhasaḥ sahajanīlimavarṇanavadityāha ##-
ayaṃ prakṛta ārabdho manonirṇaya uttamaḥ |
yadvaśājjanatājanma tadākarṇaya suvrata
]

`v 11 [
evaṃ prakṛtirūpeyaṃ manomananadharmiṇī |
karmeti rāma nirṇītaṃ sarvaireva mumukṣubhiḥ
]

`v 12 [
śṛṇu darśanabhedena tannāmābhimatākṛtim |
vāgmināṃ vadatāṃ yātaṃ citrābhiḥ śāstradṛṣṭibhiḥ
]

`v 13 [
yaṃ yaṃ bhāvamupādatte mano mananacañcalam |
tattāmeti ghanāmodamantaḥsthaḥ pavano yathā
]

`v 14 [
tatastameva nirṇīya tameva ca vikalpayan |
antaḥsthayā rañjanayā rañjayansvāmahaṃkṛtim
]

`v 15 [
tanniścayamupādāya tatraiva rasamṛcchati |
yanmayatvaṃ śarīre tu tato buddhīndriyeṣu ca
]

`v 16 [
yanmayaṃ hi mano rāma dehastadanu tadvaśaḥ |
tattāmāyāti gandhāntaḥ pavano gandhatāmiva
]

`v 17 [
buddhīndriyeṣu valgatsu karmendriyagaṇastataḥ |
sphurati svata evorvī rajolola ivānile
]

`v 18 [
karmendriyagaṇe kṣubdhe svaśaktiṃ praṇayatyalam |
karma niṣpadyate sphāraṃ pāṃsujālamivānile
]

`v 19 [
evaṃ hi manasaḥ karma karmabījaṃ manaḥ smṛtam |
abhinnaiva tayoḥ sattā yathā kusumagandhayoḥ
]

`v 20 [
yādṛśaṃ bhāvamādatte dṛḍhābhyāsavaśānmanaḥ |
tathā spandākhyakarmākhyaprathāśākhā vimuñcati
]

`v 21 [
tathā kriyāṃ tatphalatāṃ niṣpādayati cādarāt |
tatastameva cāsvādamanubhūyāśu badhyate
]

`v 22 [
yaṃ yaṃ bhāvamupādatte taṃ taṃ vastviti vindati |
tattacchreyo'nyannāstīti niścayo'sya ca jāyate
]

`v 23 [
dharmārthakāmamokṣārthaṃ prayatante sadaiva hi |
manāṃsi dṛḍhabhinnāni pratipattyā svayaiva ca
]

`v 24 [
mano vai kāpilānāṃ tu pratipattinijāmalam |
urarīkṛtya nirṇīya kalpitāḥ śāstradṛṣṭayaḥ
]

`v 25 [
mokṣe tu nānyathā prāptiriti bhāvitacetasaḥ |
svāṃ dṛṣṭiṃ pratibimbanti sthitāḥ svaniyamabhramaiḥ
]

`v 26 [
vedāntavādino buddhyā brahmedamiti rūḍhayā |
muktiḥ śamadamopetā nirṇīya parikalpitā
]

`v 27 [
muktau tu nānyathā prāptiriti bhāvitacetasaḥ |
svāṃ dṛṣṭiṃ pravivṛṇvanti svaireva niyamabhramaiḥ
]

`v 28 [
vijñānavādino buddhyā sphuratsvabhramapūrayā |
muktiḥ śamadamopetā nirṇīya parikalpitā
]

`v 29 [
muktau tu nānyathā prāptiriti bhāvitacetasaḥ |
svāṃ dṛṣṭiṃ pravivṛṇvanti svaireva niyamabhramaiḥ
]

`v 30 [
ārhatādibhiranyaiśca svayābhimatayecchayā |
citrāścitrasamācāraiḥ kalpitāḥ śāstradṛṣṭayaḥ
]

`v 31 [
nirnimittotthasaumyāmbubudbudaughairivotthitaiḥ |
svaniścitairiti prauḍhā nānākārā hi rītayaḥ
]

`v 32 [
sarvāsāmeva caitāsāṃ rītīnāmevamākaraḥ |
mano nāma mahābāho maṇīnāmiva sāgaraḥ
]

`v 33 [
na nimbekṣū kaṭusvādū śītoṣṇau nendupāvakau |
yadyathā paramābhyastamupalabdhaṃ tathaiva tat
]

`v 34 [
yastvakṛtrima ānandastadarthaṃ prayatairnaraiḥ |
manastanmayatāṃ neyaṃ yenāsau samavāpyate
]

`v 35 [
dṛśyaṃ saṃpariḍimbhaṃ svaṃ tucchaṃ pariharanmanaḥ |
tajjābhyāṃ sukhaduḥkhābhyāṃ nāvaśyaṃ parikṛṣyate
]

`v 36 [
apavitramasadrūpaṃ mohanaṃ bhayakāraṇam |
dṛśyamābhāsamābhogi bandhamābhāvayānagha `note[bandhaṃ
mābhāvaya iti pāṭhaḥ]
]

`v 37 [
māyaiṣā sā hyavidyaiṣā bhāvanaiṣā bhayāvahā |
saṃvidastanmayatvaṃ yattatkarmeti vidurbudhāḥ
]

`v 38 [
dṛṣṭvā dṛśyaikatānatvaṃ viddhi tvaṃ mohanaṃ manaḥ |
pramārjayaiva tanmithyā mahāmalinakardamam
]

`v 39 [
dṛśyatanmayatā yaiṣā svabhāvasthānubhūyate |
saṃsāramadirā seyamavidyetyucyate budhaiḥ
]

`v 40 [
anayopahato lokaḥ kalyāṇaṃ nādhigacchati |
bhāsvaraṃ tāpanālokaṃ paṭalāndhekṣaṇo yathā
]

`v 41 [
svayamutpadyate sā ca saṃkalpādvyomavṛkṣavat |
asaṃkalpanamātreṇa bhāvanāyāṃ mahāmate
]

`v 42 [
kṣīṇāyāṃ svarasādeva vimarśena vilāsinā |
asaṃsaṅgaḥ padārtheṣu sarveṣu sthiratāṃ gataḥ
]

`v 43 [
satyadṛṣṭau prapannāyāmasatye kṣayamāgate |
nirvikalpacidacchātmā sa ātmā samavāpyate
]

`v 44 [
na sattā yasya nāsattā na sukhaṃ nāpi duḥkhitā |
kevalaṃ kevalībhāvo yasyāntarupalabhyate
]

`v 45 [
abhavyayā bhāvanayā na cittendriyadṛṣṭibhiḥ |
ātmano'nanyabhūtābhirapi yaḥ parivarjitaḥ
]

`v 46 [
vāsanābhiranantābhirvyomeva ghanarājibhiḥ |
saṃdigdhāyāṃ yathā rajjvāṃ sarpatattvaṃ tathaiva hi
]

`v 47 [
cidākāśātmanā bandhastvabandhenaiva kalpitaḥ |
kalpitaṃ kalpitaṃ vastu pratikalpanayānyathā
]

`v 48 [
tadevānyatvamādatte svamahorātrayoriva |
yadatucchamanāyāsamanupādhi gatabhramam
]

`v 49 [
tattatkalpanayātītaṃ tatsukhāyaiva kalpate |
śūnya eva kusūle tu siṃho'stīti bhayaṃ yathā
]

`v 50 [
śūnya eva śarīre'ntarbaddho'smīti bhayaṃ tathā |
śūnya eva kusūle tu prekṣya siṃho na labhyate
]

`v 51 [
tathā saṃsārabandhārthaḥ prekṣito'sau na labhyate |
idaṃ jagadayaṃ cāhamiti saṃbhrāntamutthitam
]

`v 52 [
bālānāṃ madhyame kāle chāyā vaitālikī yathā |
kalpanāvaśato jantorbhāvābhāvaśubhāśubhāḥ
]

`v 53 [
kṣaṇādasattāmāyānti sattamapi punaḥ kṣaṇāt |
mātaiva gṛhiṇībhāvagṛhītā kaṇṭhalambinī
]

`v 54 [
karoti gṛhiṇīkāryaṃ suratānandadā satī |
kāntaiva mātṛbhāvena gṛhītā kaṇṭhalambinī
]

`v 55 [
nūnaṃ vismārayatyeva manmathaṃ mātṛbhāvanāt |
bhāvānusāriphaladaṃ padārthaughamavekṣya ca
]

`v 56 [
na jñeneha padārtheṣu rūpamekamudīryate |
dṛḍhabhāvanayā ceto yadyathā bhāvayatyalam
]

`v 57 [
tattatphalaṃ tadākāraṃ tāvatkālaṃ prapaśyati |
na tadasti na yatsatyaṃ na tadasti na yanmṛṣā
]

`v 58 [
yadyathā yena nirṇītaṃ tattathā tena lakṣyate |
bhāvitākāśamātaṅgaṃ vyomahastitayā manaḥ
]

`v 59 [
vyomakānanamātaṅgīṃ vyomasthāmanudhāvati |
tasmātsaṃkalpameva tvaṃ sarvabhāvamayātmakam
]

`v 60 [
tyaja rāma suṣuptasthaḥ svātmanaiva bhavātmanaḥ |
maṇirhi pratibimbānāṃ pratiṣedhakriyāṃ prati
]

`v 61 [
na śakto jaḍabhāvena natu rāma bhavādṛśaḥ |
yadātmani jagadrāma taveha pratibimbati
]

`v 62 [
tadavastviti nirṇīya mā tenāgaccha rañjanam |
tadeva satyamiti vāpyabhinnaṃ paramātmanaḥ
]

`v 63 [
matvāntastvamanādyantaṃ bhāvayātmānamātmanā |
cetasi pratibimbanti ye bhāvāstava rāghava |
rañjayantvanyasaktatvānmā te tvāṃ sphaṭikaṃ yathā
]

`v 64 [
sphaṭikamamananaṃ yathā viśanti
prakaṭatayā na ca rañjanā vicitrā |
iha hi vimananaṃ tathā viśantu
prakaṭatayā bhuvanaiṣaṇā bhavantam
]