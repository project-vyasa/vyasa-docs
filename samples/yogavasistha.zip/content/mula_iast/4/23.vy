`v 1 [
trayoviṃśaḥ sargaḥ 23
śrīvasiṣṭha uvāca |
ya uttamapadālambī cakrabhramavadāsthitaḥ |
śarīranagarīrājyaṃ kurvannapi na lipyate
]

`v 2 [
tasyeyaṃ bhogamokṣārthaṃ tajjñasyopavanopamā |
sukhāyaiva na duḥkhāya svaśarīramahāpurī
]

`v 3 [
śrīrāma uvāca |
nagarītvaṃ śarīrasya kathaṃ nāma mahāmune |
etāṃ cādhivasanyogī kathaṃ rājasukhaikabhāk
]

`v 4 [
etāṃ tvaduktāṃ śarīranagarīmadhivasannadhiṣṭhāya pālayan |
ekapadasvārasyātsukhameva bhajate natu rājāna iva tadduḥkhaleśamapītyarthaḥ | 3
|
śrīvasiṣṭha uvāca |
ramyeyaṃ dehanagarī rāma sarvaguṇānvitā |
jñasyānantavilāsāḍhyā svālokārkaprakāśitā
]

`v 5 [
netravātāyanoddyotaprakāśabhuvanāntarā |
karapratolīvistāraprāptapādopajāṅgalā
]

`v 6 [
romarājīlatāgulmā tvacājālakamālitā |
gulphāṅgulyāṃ praviśrāntajaṅghorustambhamaṇḍalā
]

`v 7 [
rekhāvibhaktapādāgraśilāprathamanirmitā |
carmamarmaśirāsārasaṃdhisīmāmanoramā
]

`v 8 [
urūrutanubhāgāgranirmitopasthanimnagā |
kacatkeśāvalīkācadalaprasthavanāvṛtā
]

`v 9 [
bhrūlalāṭoṣṭhasacchāyavadanodyānaśobhitā |
dṛṣṭipātotpalākīrṇakapolavipulasthalī
]

`v 10 [
nīlacchadasadṛśābhyāṃ bhrūbhyāṃ pāṇḍunavacchadasadṛśena lalāṭena
puṣpasadṛśābhyāmoṣṭhābhyāṃ ca sacchāyaṃ
kāntimadyadvadanalakṣaṇamudyānaṃ kadalīvanaṃ tena śobhitā | dṛṣṭipātāḥ
kaṭākṣāstallakṣaṇairutpalairākīrṇau yau kapolau tallakṣaṇe vihārasthalyau yatra | 9
|
vakṣaḥsthalasaraḥsyūtakucapaṅkajakorakā |
ghanaromāvalīcchannaskandhakrīḍāśiloccayā
]

`v 11 [
udaraśvabhranikṣiptasvānneṣṭā bhakṣyatatparā |
dīrghakaṇṭhabilodgīrṇavātasaṃrambhaśabditā
]

`v 12 [
udaralakṣaṇe kośāgāraśvabhre nikṣiptāni yāni svaprārabdhaprāpitānyannāni
tānyeva svāni dhanāni annāni dhānyādīnīṣṭāni priyāṇi vasanābharaṇādīni ca
yasyām | bhakṣyamaniṣiddhaviṣayopabhogaṃ tanvantīti bhakṣyatato
rasanaśrotrādayaḥ parāḥ śiraḥsaudhavātāyanopaviṣṭanāgarasthānīyā yasyām |
dīrghamūrdhvamukhaṃ yatkaṇṭhabilaṃ taddvārā udgīrṇo yaḥ
prāṇavātastatkṛtena saṃrambheṇa kaṇṭhadvārakapāṭodghāṭanena śabditā | 11
|
hṛdayāpaṇanirṇītayathāprāptārthabhūṣitā |
anāratanavadvārapravahatprāṇanāgarā
]

`v 13 [
āsyasphāravadādṛṣṭadantāsthiśakalākulā |
mukhāspadābhramajjihvācaṇḍīcarvitabhojanā
]

`v 14 [
romaśaṣpataracchannā karṇakoṭarakūpakā |
sphikśṛṅkhalāsthitopāntapṛṣṭhavistīrṇajaṅgalā
]

`v 15 [
gudotthānāraghaṭṭāntapradrutānantakardamā |
cittodyānamahīvalgadātmacintāvarāṅganā
]

`v 16 [
dhīvaratrādṛḍhāvaddhacapalendriyamarkaṭā |
vadanodyānahasanapuṣpodgamamanoramā
]

`v 17 [
svaśarīramanojñasya sarvasaubhāgyasundarī |
sukhāyaiva na duḥkhāya paramāya hitāya ca
]

`v 18 [
ajñasyeyamanantānāṃ duḥkhānāṃ kośamālikā |
jñasya tviyamanantānāṃ sukhānāṃ kośamālikā
]

`v 19 [
kiṃcidasyāṃ pranaṣṭāyāṃ jñasya naṣṭamarindama |
sthitāyāṃ saṃsthitaṃ sarvaṃ teneyaṃ jñasukhāvahā
]

`v 20 [
yadenāṃ jñaḥ samāruhya saṃsāre viharatyalam |
aśeṣabhogamokṣārthaṃ teneyaṃ jñarathaḥ smṛtaḥ
]

`v 21 [
śabdarūparasasparśagandhabandhuśriyo yataḥ |
anayaiva hi labhyante teneyaṃ jñasya lābhadā
]

`v 22 [
sukhaduḥkhakriyājālaṃ yadeṣodvahati svayam |
tadeṣā rāma sarvajñasarvavastubharakṣamā
]

`v 23 [
tasyāṃ śarīrapuryāṃ hi rājyaṃ kurvangatajvaraḥ |
jñastiṣṭhati gatavyagraḥ svapuryāmiva vāsavaḥ
]

`v 24 [
na kṣipatyavaṭāṭope manomattaturaṅgamam |
na lobhadurdrumādāya prajñāputrīṃ prayacchati
]

`v 25 [
ajñānapararāṣṭraṃ ca na randhraṃ tvasya paśyati |
saṃsārāribhayasyāntarmūlānyeva nikṛntati
]

`v 26 [
tṛṣṇāsāraparāvartaṃ kāmasaṃbhogadurgrahe |
na nimajjati paryastaḥ sukhaduḥkhapradevane
]

`v 27 [
karotyavirataṃ snānaṃ bahirantaravīkṣaṇāt |
saritsaṃgamatīrtheṣu manorathagataḥ kramāt
]

`v 28 [
sakalākṣajanādṛśyasukhaprekṣāparāṅmukhaḥ |
dhyānanāmni sukhaṃ nityaṃ tiṣṭhatyantaḥpurāntare
]

`v 29 [
sukhāvahaiṣā nagarī nityaṃ vai viditātmanaḥ |
bhogamokṣapradā caiṣā śakrasyevāmarāvatī
]

`v 30 [
sthitayā saṃsthitaṃ sarvaṃ kiṃcinnaṣṭaṃ na naṣṭayā |
yayā puryā mahīyasyā sā kathaṃ na sukhāvahā
]

`v 31 [
vinaṣṭe dehanagare jñasya naṣṭaṃ na kiṃcana |
ākrāntakumbhākāśasya svasya kumbhakṣaye yathā
]

`v 32 [
vidyamānaṃ ghaṭaṃ vāyuḥ kiṃcitspṛśati nāsthitam |
yathā tathaiva dehī svāṃ śarīranagarīmimām
]

`v 33 [
atrasthaḥ puruṣo bhogānātmā sarvagato'pi san |
viśvakalpakṛtānbhuktvā puṃsāmadhigatārthabhāk
]

`v 34 [
kurvannapi na kurvāṇaḥ samastārthakriyonmukhaḥ |
kadācitprakṛtānsarvānkāryārthānanutiṣṭhati
]

`v 35 [
kadācillīlayā lolaṃ vimānamadhirohati |
anāhatagatiḥ kāntaṃ vihartumamalaṃ manaḥ
]

`v 36 [
tatrastho lokasundaryā satataṃ śītalāṅgayā |
ramate rāmayā maitryā nityaṃ hṛdayasaṃsthitaḥ
]

`v 37 [
dve kānte tiṣṭhataḥ samyak pārśvayoḥ satyataikate |
indoriva viśākhe dve samāhlāditacetasī
]

`v 38 [
kṣapitānakhilāṁllokānduḥkhakrakacadāritān |
vallīvanasthānnabhasaḥ pṛṣṭhādarka ivekṣate
]

`v 39 [
ciraṃ pūritasarvāśaḥ sarvasaṃpatīsundaraḥ |
apunaḥkhaṇḍanāyenduḥ pūrṇāṅga iva rājate
]

`v 40 [
sevyāmāno'pi bhogaugho na khedāyāsya jāyate |
kālakūṭaḥ kileśasya kaṇṭhe pratyuta rājate
]

`v 41 [
bhogaughaḥ srakcandranādibhogaughaḥ | khedāya punarjanmādiduḥkhāya | athavā
bhogaugho duṣprārabdhaḥ bhogaughaḥ khedāya tātkālikaduḥkhāya | pratyuteti |
tattvavido'pi tapa ādikleśaḥ pratyutājñajanaśikṣāmahāphalo rājate iti bhāvaḥ |
40 |
parijñātopabhukto hi bhogo bhavati tuṣṭaye |
vijñāya sevito maitrīmeti coro na śatrutām
]

`v 42 [
naranārī naṭaughānāṃ `note[nadaughānāṃ iti pāṭhaḥ] virahe
dūragāminām |
jñena yātreva subhagā bhogaśrīravalokyate
]

`v 43 [
aśaṅkitopasaṃprāptā grāmayātrā yathādhvagaiḥ |
prekṣyante tadvadeva jñairvyavahāramayāḥ `note[ṅīybhāva ārṣaḥ]
kriyāḥ
]

`v 44 [
ayatnopanate'pyakṣi padārtheṣu yathā punaḥ |
nīrāgameva patati tadvatkāryeṣu dhīradhīḥ
]

`v 45 [
indriyāṇāṃ na harai prāptamarthaṃ kadācana |
nādadāti tathā'prāptaṃ saṃpūrṇo jño'vatiṣṭhate
]

`v 46 [
aprāptacintāḥ saṃprāptasamupekṣāśca sanmatim |
na kampayanti taralāḥ picchāghātā ivācalam
]

`v 47 [
saṃśāntasarvasaṃdeho galitākhilakautukaḥ |
saṃkṣīṇakalpanādeho jñaḥ samrāḍiva rājate
]

`v 48 [
ātmanyeva na mātyantaḥ svātmanātmani jṛmbhate |
saṃpūrṇo'pāraparyantaḥ kṣīrārṇava ivārṇave
]

`v 49 [
pāmaradṛśā svārājyadṛṣṭāntastattvadṛśā tu nāsti dṛṣṭāntaḥ
paricchedābhāvādityāśayenāha - ātmanyeveti | arṇave svātmanītyarthaḥ | 48
|
bhogecchākṛpaṇāñjantūndīnāndīnendriyāṇi ca |
anunmattamanāḥ śānto hasatyunmattkāniva
]

`v 50 [
icchato'nyojjhitāṃ jāyāṃ yathaivānyena hasyate |
indriyasyecchato bhogaṃ tadvajjñena vihasyate
]

`v 51 [
tattvavidojjhitaṃ bhogamicchata indriyasya | hasyate pravṛttirityubhayatra śeṣaḥ |
50 |
tyajatsvātmasukhaṃ saumyaṃ mano viṣayavidrutam |
aṅkuśeneva nāgendraṃ vicāreṇa vaśaṃ nayet
]

`v 52 [
bhogeṣu prasaro yasyā manovṛtteśca dīyate |
sāpyādāveva hantavyā viṣasyevāṅkurodgatiḥ
]

`v 53 [
tāḍitasya hi yaḥ paścātsaṃmānaḥ so'pyanantakaḥ |
śālergrīṣmābhitaptasya kuseko'pyamṛtāyate
]

`v 54 [
anārtena hi sanmāno bahumāno na budhyate |
pūrṇānāṃ saritāṃ prāvṛṭpūraḥ svalpo na rājate
]

`v 55 [
pūrṇastu prākṛto'pyanyatpunarapyabhivāñchate |
jagatpūraṇayogyāmburgṛhṇātyevārṇavo jalam
]

`v 56 [
manaso'bhigṛhītasya yā paścādbhogamaṇḍanā |
tāmevālabdhavistārāṃ `note[tāmeva labdhavistārāt iti ṭīkānuguṇaḥ pāṭha iti
bhāti] kliṣṭatvādbahu manyate
]

`v 57 [
bandhamukto mahīpālo grāsamātreṇa tuṣyati |
parairabaddho nākrānto na rājyaṃ bahu manyate
]

`v 58 [
hastaṃ hastena saṃpīḍya dantairdantānvicūrṇya ca |
aṅgānyaṅgairivākramya jayeccendriyaśātravān
]

`v 59 [
jetumanyaṃ kṛtotsāhaiḥ puruṣairiha paṇḍitaiḥ |
pūrvaṃ hṛdayaśatrutvājjetavyānīndriyāṇyalam
]

`v 60 [
etāvati dharaṇitale
subhagāste sādhucetanāḥ puruṣāḥ |
puruṣakalāsu ca gaṇyā
na jitā ye cetasā svena
]

`v 61 [
hṛdayabile kṛtakuṇḍala-
kalanāvivaśo manomahābhujagaḥ |
yasyopaśāntimāgata-
malamuditaṃ taṃ sunirmalaṃ vande
]