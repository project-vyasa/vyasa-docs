`v 1 [
catustriṃśaḥ sargaḥ 34
śrīvasiṣṭha uvāca |
atra te śṛṇu vakṣyāmi dāmādiṣu gateṣvatha |
yadvṛttaṃ śambarasyaiva nagare nagasaṃnibhe
]

`v 2 [
tathā gaganavibhraṣṭe samaste dhvastasaṃsthitau |
vinaṣṭe śambarānīke śaradīvābdamaṇḍale
]

`v 3 [
devanirjitasainyo'sau nītvā katipayāḥ samāḥ |
punardevavadhodyuktaścintayāmāsa dānavaḥ
]

`v 4 [
dāmādayastu racitā ye mayā māyayā'surāḥ |
maurkhyāttairbhāvitā yuddhe mithyaiva durahaṃkṛtiḥ
]

`v 5 [
idānīṃ saṃsṛjāmyanyāndānavānmāyayoditān |
tānapyadhyātmaśāstrajñānsavivekānkaromyaham
]

`v 6 [
tatastattvaparijñānānmithyābhāvanayojjhitāḥ |
nāhaṃkāraṃ prayāsyanti vijeṣyanti ca tānsurān
]

`v 7 [
iti saṃcintya daityendrastādṛśāndānavāndhiyā |
māyayotpādayāmāsa budbudāniva vāridhiḥ
]

`v 8 [
sarvajñā vedyavettāro vītarāgā gatainasaḥ |
yathāprāptaikakartāro bhāvitātmāna uttamāḥ
]

`v 9 [
bhīmo bhāso dṛḍha iti nāmabhiḥ parilāñchitāḥ |
jagattṛṇamivāśeṣaṃ paśyantaḥ pāvanāśayāḥ
]

`v 10 [
te daityā bhuvanaṃ prāpya cchādayāmāsurambaram |
garjanto hetitaḍitaḥ prāvṛṣīva payodharāḥ
]

`v 11 [
bhuvanamūrdhvabhuvanam | hetitaḍita ityupamānapakṣe ivārthagarbho bahuvrīhiḥ |
10 |
ayudhyanta samaṃ devairapi varṣagaṇānbahūn |
vivekavaśato jagmurnāhaṃkāraṃ kadācana
]

`v 12 [
teṣāṃ yāvadudetyantarmamedamiti vāsanā |
tāvatko'yamahaṃ ceti vicārādyātyasatyatām
]

`v 13 [
asaccharīraṃ vibudhāḥ ko'sāvahamiti sthitiḥ |
vicārāditthameteṣāṃ prodagurna bhayādayaḥ
]

`v 14 [
asaccharīraṃ nāstīdaṃ cicchuddhaivātmani sthitā |
ahaṃnāma na cānyo'sti niścityaivāsurā yayuḥ
]

`v 15 [
tatastairnirahaṃkārairjarāmaraṇanirbhayaiḥ |
prāptārthakāribhirdhīrairvartamānānusāribhiḥ
]

`v 16 [
asaktabuddhibhirnityaṃ hatānyairapyahantṛbhiḥ |
vāsanājālanirmuktaiḥ kṛtakāryairakartṛbhiḥ
]

`v 17 [
prabhoḥ kāryamidaṃ kāryamiti saṃgaratatparaiḥ |
vītarāgairgatadveṣaiḥ sarvadā samadṛṣṭibhiḥ
]

`v 18 [
sā daivī dānavaiḥ senā bhīmabhāsadṛḍhādibhiḥ |
hatā bhuktā hṛtā pluṣṭā svānnaśrīriva bhoktṛbhiḥ
]

`v 19 [
bhīmabhāsadṛḍhakṣuṇṇā jātā gīrvāṇavāhinī |
paridudrāva vegena gaṅgeva himavaccyutā
]

`v 20 [
sā surānīkinī devaṃ kṣīrodārṇavaśāyinam |
jagāma śaraṇaṃ śailaṃ vātārtevābdamālikā
]

`v 21 [
harirāśvāsayāmāsa tāṃ bhītāṃ devavāhinīm |
bhujaṅgābhivṛtāmekāṃ ramaṇīmiva nāyakaḥ
]

`v 22 [
atha kṣīrodakuhare tāvatsā suravāhinī |
uvāsa yāvadbhagavāṃstannirāsārthamudyayau
]

`v 23 [
babhūva dāruṇaṃ yuddhaṃ śauriśambarayostataḥ |
akāla iva kalpānte samuḍḍīnakulācalam
]

`v 24 [
śaśāma samare tasmindaityaḥ sabalavāhanaḥ |
nārāyaṇahato yātaḥ śambaro vaiṣṇavīṃ purīm
]

`v 25 [
bhīmabhāsadṛḍhāste tu tasminviṣamasaṃgare |
viṣṇunaiva śamaṃ nītāḥ pavaneneva dīpikāḥ
]

`v 26 [
te hi nirvāsanā eva yadā śāntimupāgatāḥ |
na tadaiṣāṃ gatirjñātā dīpānāmiva śāmyatām
]

`v 27 [
tasmādvāsanayā baddhaṃ muktaṃ nirvāsanaṃ manaḥ |
rāma nirvāsanībhāvamāharasva vivekataḥ
]

`v 28 [
samyagālokanātsatyādvāsanā pravilīyate |
vāsanāvilaye cetaḥ śamamāyāti dīpavat
]

`v 29 [
na satyaṃ kiṃcideveha sadbhāvo bhāvayatyalam |
nāstyeva bhāvanā tasmādityetatsamyagīkṣaṇam
]

`v 30 [
ātmaivedaṃ jagatsarvaṃ kaḥ kiṃ bhāvayatu kva vā |
bhāvanā nāma nāstyeva tadetatsamyagīkṣaṇam
]

`v 31 [
vāsanācittanāmānau śabdāvarthasamanvitau |
satyāvalokanādyatra vilīnau tatparaṃ padam
]

`v 32 [
vāsanā cittamitiśabdāvapi rāhoḥ śira itivadvaikalpikabhedakalpanāttannāmānau |
31 |
vāsanāvalitaṃ cittamiha sthitimupāgatam |
tadeva tadvinirmuktaṃ vimuktamiti kathyate
]

`v 33 [
nānāghaṭapaṭākāraiścetaḥsthitimupāgatam |
tadevāśu śamaṃ neyaṃ mithyāyakṣa ivotthitaḥ
]

`v 34 [
dāmavyālakaṭākāraiścetaḥ pariṇataṃ yathā |
bhīmabhāsadṛḍhanyāyo rāghavāstvacalastava
]

`v 35 [
dāmavyālakaṭanyāyo mā te bhavatu rāghava |
etadrāma purā proktaṃ pitrā kamalajena me
]

`v 36 [
bhavate yanmayā proktaṃ śiṣyāyātyantadhīmate |
dāmavyālakaṭanyāyastasmānmā te'stu rāghava |
bhīmabhāsadṛḍhanyāyo nityamastu tavānagha
]

`v 37 [
aviralasukhaduḥkhasaṃkaṭeyaṃ
bhavapadavī bhavatāpanopayātā |
vyavaharaṇavato vibhūtiyātau
satatamasaktatayaiva naśyatīti
]