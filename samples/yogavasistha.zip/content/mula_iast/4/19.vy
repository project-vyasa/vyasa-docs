`v 1 [
ekonaviṃśaḥ sargaḥ 19
śrīvasiṣṭha uvāca |
jīvabījaṃ paraṃ brahma sarvatra khamiva sthitam |
tena jīvodarajagatyapi jīvo'styanekadhā
]

`v 2 [
cidghanaikaghanātmatvājjīvāntarjīvajātayaḥ |
kadalīdalavatsanti kītā iva dharodare
]

`v 3 [
yo yo nāma yathā grīṣme kalpasvedādbhavetkṛmiḥ |
yadyaddṛśyaṃ śudhacitkhaṃ tajjīvo bhavati svataḥ
]

`v 4 [
yathā yathā yatante te jīvakāḥ svāmtasiddhaye |
tathā tathā bhavantyāśu vicitropāsanakramaiḥ
]

`v 5 [
prāktanapuruṣaprayatnarūpakarmavaśādvā sarvavyavasthāsiddhirityāśayenāha ##-
devāndevayajo yānti yakṣā yakṣānvrajanti hi |
brahma brahmayajo yānti yadatucchaṃ tadāśrayet
]

`v 6 [
karmopāsanātāratamyānusāridevatājīvasāyujyeṣvapi tattaddevāntastāratamyena
bhogaprasiddhiḥ śāstraprāmāṇyātsiddhetyāśayenāha - devāniti | brahma
hiraṇyagarbhākhyaṃ paraṃ ca | teṣu kiṃ heyaṃ kimupādeyaṃ tadāha - yaditi |
5 |
sa mukto bhṛguputro hi nirmalatvātsvasaṃvidaḥ |
baddhaḥ prathamadṛṣṭena dṛśyenāśu svabhāvataḥ
]

`v 7 [
bhuvi jātā parimlānā bālā yatprathamaṃ puraḥ |
tathaivāvyutpannā bālā saṃvidyathaiva vyutpādyate tathaiva bhavatīti
vāstavabrahmātmabhāvenaiva sā vyutpādyā na
mithyājīvādibhāvenetyāśayenopasaṃharati - bhuvīti |
sāṃsārikavyasanatāpairyāvadaparimlānetyarthaḥ
]

`v 8 [
śrīrāma uvāca |
jāgratsvapnadaśābhedaṃ bhagavanvaktumarhasi |
kathaṃ ca jāgrajjāgratsyātsvapno jāgradbhramaḥ katham
]

`v 9 [
saṃvitkadā bālā kadā vā prauḍheti viśeṣaṃ jñātuṃ
jāgratsvapnadaśāvailakṣaṇyahetuṃ śrīrāmaḥ pṛcchati - jāgraditi |
aparokṣāvabhāsatvāviśeṣe'pi jāgratkathaṃ kena hetunā
jāgratsatyatāvyavahārahetuḥ | svapnastu jāgradākāro bhrama iti kathamityarthaḥ | 8
|
śrīvasiṣṭha uvāca |
sthirapratyayayuktaṃ yattajjāgraditi kathyate |
asthirapratyayaṃ yatsyāttatsvapnaḥ samudāhṛtaḥ
]

`v 10 [
jāgrattve kṣaṇadṛṣṭaḥ syātsvapnaḥ kālāntare sthitaḥ |
tajjāgratsvapnatāmeti svapno jāgrattvamṛcchati
]

`v 11 [
jāgratsvapnadaśābhedo na sthirāsthirate vinā |
samaḥ sadaiva sarvatra samasto'nubhavo'nayoḥ
]

`v 12 [
svapno'pi svapnasamaye sthairyājjāgrattvamṛcchati |
asthairyājjāgradevāste svapnastādṛśabodhataḥ
]

`v 13 [
svapno'pi jāgradbuddhyaṃśo jāgrattvamanugacchati |
svapnatā svapnabuddhyā tu yathāsaṃvedanaṃ sthitam
]

`v 14 [
yattu yāvatsthiraṃ buddhaṃ tattāvajjāgraducyate |
kṣaṇabhaṅgāttu tatsvapno yathā bhavati tacchṛṇu
]

`v 15 [
jīvadhātuḥ śarīre'ntarvidyate yena jīvyate |
tejo vīryaṃ jīvadhāturityādyabhidhamaṅga yat
]

`v 16 [
vyavahārī yadā kāyo manasā karmaṇā girā |
bhavettadā marunnunno jīvadhātuḥ prasarpati
]

`v 17 [
tasminprasarpatyaṅgeṣu sarvā saṃvidudeti hi |
dṛṣṭatvātpraiti cittākhyamantarlīnajagadbhramam
]

`v 18 [
īkṣaṇādiṣu randhreṣu prasarantī bahirmayam |
nānākāravikārāḍhyaṃ rūpamātmani paśyati
]

`v 19 [
sthiratvāttattathaivātha jāgradityavagamyate |
jāgratkrama iti proktaḥ suṣuptādikramaṃ śṛṇu
]

`v 20 [
manasā karmaṇā vācā yadā kṣubhyati no vapuḥ |
śāntātmā tiṣṭhati svastho jīvadhātustadā tvasau
]

`v 21 [
samatāmāgatairvātaiḥ kṣobhyate na hṛdambare |
nirvātasadane dīpo yathā'lokaikakārakaḥ
]

`v 22 [
tataḥ sarati nāṅgeṣu saṃvitkṣubhyati tena no |
na cekṣaṇādīnyāyāti randhrāṇyāyāti no bahiḥ
]

`v 23 [
jīvo'ntareva sphurati tailasaṃvidyathā tile |
śītasaṃviddhima iva snehasaṃvidyathā ghṛte
]

`v 24 [
jīvākārā kalā kāciccitiḥ svacchatayātmani |
daśāmāyāti sauṣuptiṃ saumyavātāṃ vicetanām
]

`v 25 [
jñātvā vaicityuparate `note[1] sāmyaṃ vyavaharannapi |
jāgratsvapnasuṣupteṣu saṃbuddhasturyavānsmṛtaḥ
]

`v 26 [
suṣupte saumyatāṃ yātaiḥ prāṇaiḥ saṃcālyate yadā |
sa jīvadhātuḥ sā saṃvittataścittatayoditā
]

`v 27 [
svāntaḥsaṃsthajagajjālaṃ bhāvābhāvaiḥ kramabhramaiḥ |
paśyati svāntarevāśu sphāraṃ bīja iva drumam
]

`v 28 [
jīvadhāturyadā vātaiḥ kiṃcitsaṃkṣubhyate bhṛśam |
tato'smyahaṃ supta iti paśyatyātmani khe gatim
]

`v 29 [
uktameva sphuṭamanūdya cittādahaṃkārotpattiṃ bhrāntibhedanimitāni cāha -
jīveti | suptaḥ puruṣo yadā vātaiḥ kiṃcitsaṃkṣubhyate tadā ahamasmīti paśyati |
yadā tu bhṛśaṃ saṃkṣubhyate tadā khe gatimākāśagamanaṃ paśyatītyarthaḥ |
28 |
yadāmbhasā plāvyate'sau tadā vāryādisaṃbhramam |
antarevānubhavati svāmodaṃ kusumaṃ yathā
]

`v 30 [
yadā pittādinākrāntastadā grīṣmādisaṃbhramam |
antarevānubhavati sphāraṃ bahirivākhilam
]

`v 31 [
raktāpūrṇo raktavarṇāndeśānkālānbahiryathā `note[deśakālān iti
pāṭhaḥ] |
paśyatyanubhavātmatvāttatraiva ca nimajjati
]

`v 32 [
sevate vāsanāṃ yāṃ tāṃ so'ntaḥ paśyati nidritaḥ |
pavanakṣobhito randhrairbhairakṣādibhiryathā
]

`v 33 [
anākrāntendriyacchidro yataḥ kṣubdho'ntareva saḥ |
saṃvidānubhavatyāśu sa svapna iti kathyate
]

`v 34 [
samākrāntendriyacchidro yaḥ kṣubdho vāyunā yadā |
paripaśyati tajjāgradityāhurmunisattamāḥ
]

`v 35 [
iti viditavatā tvayādhunāntaḥ
prathitamahāmatineha satyatākhyā |
asati jagati naiva bhavanīyā
mṛtihatisaṃhṛtidoṣabhāvanī yā
]