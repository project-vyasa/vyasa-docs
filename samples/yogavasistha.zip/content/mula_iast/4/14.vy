`v 1 [
aṣṭamo divasaḥ |
caturdaśaḥ sargaḥ 14
śrīvasiṣṭha uvāca |
atha kālabhṛgū devau mandarācalakandarāt |
gantuṃ pravṛttāvavanau samaṅgāsaritastaṭam
]

`v 2 [
tau śailādavarohantau dṛṣṭavantau mahādyutī |
navahaimalatājālakuñjasuptanabhaścarān
]

`v 3 [
vallīvalayadolābhiḥ krīḍato gaganāṅgaṇe |
hariṇīmugdhamugdhākṣiprekṣitasmāritotpalān
]

`v 4 [
siddhānadhyāsitottuṅgasilāśakalaviṣṭarān |
dhṛtākārānivotsāhānhelādṛṣṭajagattrayān
]

`v 5 [
kṛtājasrapatatpuṣpadhārāsāranimajjanān |
tālottālakṛtoddhastahastānhastighaṭāpatīn
]

`v 6 [
madāvalepanidrālūnmadānmūrtāniva sthitān |
puṣpakesararaktāṅgapavanāruṇavāladhīn
]

`v 7 [
cañcalāṃścamarāṃścārūnbhūbhṛnmaṇḍalacāmarān |
kṛtājasrapatatpuṣpadhārāsāranimajjanān
]

`v 8 [
kinnarānbhūmakharjūrāñśākhāsaralatāṃ gatān |
parasparaphalāghātakṣveḍāvarjitakīcakān
]

`v 9 [
dhātupāṭaladurvaktrānmarkaṭānnaṭanotkaṭān |
latāvitānasaṃchannasānūpavanamandirān
]

`v 10 [
siddhānamaranārībhirmandārakusumāhatān |
dhātupāṭalanirdvārapayodapaṭasaṃvṛtān
]

`v 11 [
taṭānajanasaṃsargānbauddhānpravrajitāniva |
saritaḥ kundamandārapinaddhalaharīghaṭāḥ |
sāgarotkatayevāttamadhumāsaprasādhanāḥ
]

`v 12 [
puṣpabhārapinaddhāṅgānvṛkṣānpavanakampitān |
kṣībāniva madhuprāptau ghūrṇānmadhukarekṣaṇān
]

`v 13 [
śailarājaśriyaṃ sphītāṃ paśyantau tāvitastataḥ |
prāptavantau vasumatīṃ purapattanamaṇḍitām
]

`v 14 [
kṣaṇādavāpatustatra puṣpalolataraṅgiṇīm |
samaṅgāṃ saritaṃ sādhu sarvapuṣpamayīmiva
]

`v 15 [
dadarśātha taṭe tasminkasmiṃścittanayaṃ bhṛguḥ |
dehāntaraparāvṛttaṃ bhāvamanyamupāgatam
]

`v 16 [
śāntendriyaṃ samādhisthamacañcalamanomṛgam |
sucirādiva viśrāntaṃ suciraśramaśāntaye
]

`v 17 [
cintayantamivānantāścirabhuktā'cirojjhitāḥ |
saṃsārasāgaragatīrharṣaśokanirantarāḥ
]

`v 18 [
nūnaṃ niścalatāṃ yātamatibhramitacakravat |
anantajagadāvartavivartātiśayādiva
]

`v 19 [
ekāntasaṃsthitaṃ kāntaṃ kāntyaikākinamāśritam |
upaśāntehasaṃbhagnacittasaṃbhramasaṃgamam
]

`v 20 [
nirvikalpasamādhisthaṃ virataṃ dvandvavṛttitaḥ |
hasantamakhilāṃ lokagatiṃ śītalyā dhiyā
]

`v 21 [
vigatākhilavṛttāntaṃ vigatāśeṣabhoktṛtam |
nirastakalpanājālamālambitamahāpadam
]

`v 22 [
anantaviśrāntitate pade viśrāntamātmani |
pratibimbamagṛhṇantaṃ sitaṃ maṇimivāsthitam
]

`v 23 [
heyopādeyasaṃkalpavikalpābhyāṃ samujjhitam |
saṃprabuddhamatiṃ dhīraṃ dadarśa tanayaṃ bhṛguḥ
]

`v 24 [
tamālokya bhṛgoḥ putraṃ kālo bhṛgumuvāca ha |
vākyamabdhidhvaninibhaṃ tava putrastvasāviti
]

`v 25 [
śikhaṇḍabhṛt mayūraḥ
]

`v 26 [
unmīlya netre so'paśyadante kālabhṛgū prabhū |
samodayāvivāyātau devau śaśidivākarau
]

`v 27 [
kadambalatikāpīṭhādathotthāya nanāma tau |
samau samāgatau kāntau viprau hariharāviva
]

`v 28 [
mithaḥkṛtasamācārāḥ śilāyāṃ samupāviśan |
merupṛṣṭhe jagatpūjyā brahmaviṣṇuharā iva
]

`v 29 [
atha śāntajapo rāma sa samaṅgātaṭe dvijaḥ |
tāvuvāca vacaḥ śāntamamṛtasyandasundaram
]

`v 30 [
bhavatordarśanenāhamadya nirvṛtimāgataḥ |
samamāgatayorloke śītaloṣṇarucoriva
]

`v 31 [
yo na śāstreṇa tapasā na jñānenāpi vidyayā |
vinaṣṭo me manomohaḥ kṣīṇo'sau darśanena vām
]

`v 32 [
na tathā sukhayantyantarnirmalāmṛtavṛṣṭayaḥ |
yathā praharṣayantyetā mahatāmeva dṛṣṭayaḥ
]

`v 33 [
caraṇābhyāmimaṃ deśaṃ bhavantau bhūritejasau |
kau pavitritavantau naḥ śaśāṅkārkāvivāmbaram
]

`v 34 [
ityuktavantaṃ provāca bhṛgurjanmāntarātmajam |
smarātmānaṃ prabuddho'si nājño'sīti raghūdvaha
]

`v 35 [
prabodhito'sau bhṛguṇā janmāntaradaśāṃ nijām |
muhūrtamātraṃ sasmāra dhyānonmīlitalocanaḥ
]

`v 36 [
athāsau vismayātsmeramukho muditamānasaḥ |
vitarkamantharāṃ vācamuvāca vadatāṃ varaḥ
]

`v 37 [
jagatyaviditārambhā niyatiḥ paramātmanaḥ |
yadvaśādidamābhogi jagaccakraṃ pravartate
]

`v 38 [
mamānantānyatītāni janmānyaviditānyapi |
daśāphalānyanantāni kalpāntakalitādiva
]

`v 39 [
dṛṣṭāḥ kaṭhinasaṃrambhā vibhavo'pyarjanabhramāḥ |
vihṛtaṃ vītaśokāsu ciraṃ merusthalīṣu ca
]

`v 40 [
pītamāmodi mandārakesarāruṇitaṃ payaḥ |
mandākinyāḥ sakahlāraṃ taṭīṣvamarabhūbhṛtaḥ
]

`v 41 [
bhrāntaṃ mandarakuñjeṣu phullahemalatāliṣu |
meroḥ kalpatarucchāyāpuṣpasundarasānuṣu
]

`v 42 [
na tadasti na yadbhuktaṃ na tadasti na yatkṛtam |
na tadasti na yaddṛṣṭamiṣṭāniṣṭāsu vṛttiṣu
]

`v 43 [
jñātaṃ jñātavyamadhunā dṛṣṭaṃ draṣṭavyamakṣatam |
viśrānto'tha ciraṃ śrānto gato me sakalo bhramaḥ
]

`v 44 [
uttiṣṭha tāta gacchāmaḥ paśyāmo mandarasthitām |
tāṃ tanuṃ tāvadāśuṣkāṃ śuṣkāṃ vanalatāmiva
]

`v 45 [
na samīhitamastīha nāsamīhitamasti me |
niyate racanāṃ draṣṭuṃ kevalaṃ viharāmyaham
]

`v 46 [
yadatisubhagamāryasevitaṃ ta-
tsthiramanuyāmi yadekabhāvabuddhyā |
tadalamabhimatā matirmamāstu
prakṛtamimaṃ vyavahāramācarāmi
]