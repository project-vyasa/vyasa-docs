`v 1 [
pañcaviṃśaḥ sargaḥ 25
śrīvasiṣṭha uvāca |
asminviharato loke lokārāmasya dhīmataḥ |
śreyase tiṣṭhato yatnamuttamārthābhidhāyinaḥ
]

`v 2 [
dāmavyālakaṭanyāyo mā te bhavatu rāghava |
bhīmabhāsadṛḍhasthityā tvaṃ viśoko bhaveti ca
]

`v 3 [
śrīrāma uvāca |
dāmavyālakaṭanyāyo mā te bhūdityudāhṛtam |
brahman kimetadbhavatā bhavatāpāpahāriṇā
]

`v 4 [
bhīmabhāsadṛḍhasthityā tvaṃ viśoko bhaveti ca |
prabho kimuktaṃ bhavatā bhavatāpāpahāriṇā
]

`v 5 [
udārayaitayā śuddhaṃ saṃprabodhaya māṃ girā |
ghanastāpāpahāriṇyā prāvṛṣīva kalāpinam
]

`v 6 [
śrīvasiṣṭha uvāca |
dāmavyālakaṭanyāyaṃ bhīmabhāsadṛḍhasthitim |
śṛṇu rāghava tacchrutvā yadiṣṭaṃ tatsamācara
]

`v 7 [
āsītpātālakuhare sarvāścaryamanorame |
śambaro nāma daityendro māyāmaṇimahārṇavaḥ
]

`v 8 [
ākāśanagarodyānaracitāsuramandiraḥ |
kṛtrimottamacandrārkabhūṣitātmīyamaṇḍalaḥ
]

`v 9 [
śilāśakalasaṃbhūtapadmādyairamarācalaḥ |
anantavibhavārambhaparipūritadānavaḥ
]

`v 10 [
gṛharatnāṅganāgeyajitāmaravadhūdhvaniḥ |
candrabimbakalāpūrṇakrīḍopavanapādapaḥ
]

`v 11 [
phullanīlotpalavyūhakarālaramaṇālayaḥ |
ratnahaṃsadhvanāhūtahemāmburuhasārasaḥ
]

`v 12 [
hemapādapaśākhāgrakṛtāmbhoruhakuḍmalaḥ |
karañjajālaprapatanmandārakusumākaraḥ
]

`v 13 [
tarkuyantramayānantadaityanirjitavāsavaḥ |
himaśītānalajvālānirmitodyānamaṇḍapaḥ
]

`v 14 [
sarvatra kusumodyānajitānandananadanaḥ |
māyāsarvahṛtavyālamalayācalacandanaḥ
]

`v 15 [
hemaśrīlokalāvaṇyanirjitāntaḥpurāṅganaḥ |
nānākusumasaṃbhārajānudaghnagṛhāṅgaṇaḥ
]

`v 16 [
krīḍārthamṛnmayeśānajitacakragadādharaḥ |
ajasroḍḍīnaratnaughatārāḍhyakhapurāntaraḥ
]

`v 17 [
niśīthākhilapātālaśatacandranabhastalaḥ |
svaśālabhañjikālokagītagītiraṇotkaṭaḥ
]

`v 18 [
māyairāvaṇanāgendravidrutāmaravāraṇaḥ |
trailokyavibhavotkarṣapūritāntaḥpurāntaraḥ
]

`v 19 [
sarvasaṃpattisubhagaḥ sarvaiśvaryanamaskṛtaḥ |
samastadaityasāmantavanditogrānuśāsanaḥ
]

`v 20 [
mahābhujavanacchāyāviśrāntāsuramaṇḍalaḥ |
sarvabudhigaṇādhāraratnamaṇḍalamaṇḍitaḥ
]

`v 21 [
tasyotsāditadevasya kaṭhinoḍḍāmarākṛteḥ |
babhūva vipulaṃ sainyamāsuraṃ suranāśanam
]

`v 22 [
tasminmāyābale supte deśāntaragate tathā |
tatsainyaṃ tarasā jaghnuścidraṃ prāpya kilāmarāḥ
]

`v 23 [
atha śambaradaityena muṇḍikrodhadrumādayaḥ |
rakṣārthamatha sāmantāḥ svasenāsu niyojitāḥ
]

`v 24 [
tānapyantaramāsādya jaghnurdevā bhayānakāḥ |
vyomāntaragatāḥ śyenāḥ kalaviṅkānivākulān
]

`v 25 [
senāpatīnpunaścānyāṃścakārāsurasattamaḥ |
capalānudbhaṭārāvāṃstaraṅgāniva sāgaraḥ
]

`v 26 [
devāstānapi tasyāśu jaghnustena `note[jagmuḥ iti pāṭhaḥ] sa kopavān |
jagāmāmaranāśāya paripūrṇaṃ triviṣṭapam
]

`v 27 [
tasmāttanmāyayā bhītāḥ surāste'ntardhimāyayuḥ |
merukānanakuñjeṣu mṛgā gaurīhareriva
]

`v 28 [
krandatkṣudrāmaragaṇaṃ bāṣpaklinnāpsaromukham |
śūnyaṃ dadarśa sa svargaṃ kalpakṣīṇajagatsamam
]

`v 29 [
viharankupitastatra labdhamāhṛtya sundaram |
lokapālapurīṃ dagdhvā jagāmātmīyamālayam
]

`v 30 [
evaṃ dṛḍhatarībhūte dveṣe dānavadevayoḥ |
devāḥ svargaṃ parityajya dikṣu jagmuradarśanam
]

`v 31 [
atha śambaradaityena ye ye senādhināyakāḥ |
kriyante yatnatastāṃstu jaghnuryatnaparāḥ surāḥ
]

`v 32 [
yāvadudvegamāyātaḥ śambaraḥ kopavānbhṛśam |
tārṇo'timātramanala iva jajvāla socchvasan
]

`v 33 [
trailokyamapi cānviṣyanna devāṁllabdhavānatha |
pareṇāpi prayatnena nidhānamiva duṣkṛtī
]

`v 34 [
sasarja māyayā ghorānasurāṃstrīnmahābalān |
balarakṣārthamuditānkālānmūrtimiva sthitān
]

`v 35 [
nirvṛttā māyayā bhīmā balapādapavāhinaḥ |
udaguste mahāmāyāḥ pakṣakṣubdhā ivādrayaḥ
]

`v 36 [
dāmo vyālaḥ kaṭaśceti nāmabhiḥ parilāñchitāḥ |
yathāprāptaikakartāraścetanāmātradharmiṇaḥ
]

`v 37 [
abhāvātkarmaṇāṃ te ca prāktanā naca vāsanāḥ |
nirvikalpakacinmātraparispandaikadharmakāḥ
]

`v 38 [
karmajīvakalāṃ tanvīmasārāṃ ca manobhidām |
apuṣṭāṃ kṛtrimāmantaścodayaodayamāgatāḥ
]

`v 39 [
te hyandhapāramparyeṇa kākatālīyavadbhaṭāḥ |
prakṛtāmanuvartante kriyāmujjhitavāsanāḥ
]

`v 40 [
ardhasuptā yathā bālāḥ svāṅgai riṅganti kevalam |
vāsanātmābhimānābhyāṃ hīnāste tadvadeva hi
]

`v 41 [
nābhipātaṃ na cāpātaṃ na viduste palāyanam |
na jīvitaṃ na maraṇaṃ na raṇaṃ na jayājayau
]

`v 42 [
kevalaṃ sainikānagre dṛṣṭānāhananodyatān |
abhijagmuḥ parānājau prahāradalitādrayaḥ
]

`v 43 [
yadi na vidustarhi svayaṃ kathaṃ śatrūnabhipetustatrāha - kevalamiti | abhipatya
prahartavyamityetādṛśaśambarasaṃkalpavāsanāmātraśarīratvādabhimukha##-
śambaraścintayāmāsa parituṣṭamanāḥ param |
vijeṣyate hi me senā māyāsurasurakṣitā
]

`v 44 [
atibalāsuradordrumapālitā
mama camūḥ sthiratāmalameṣyati |
amaravāraṇadantavighaṭṭane-
ṣvamaraparvatahemaśilā yathā
]