`v 1 [
dvādaśaḥ sargaḥ 12
kāla uvāca |
surāsuranarākārā imā yāḥ saṃvido mune |
brahmārṇavādabhinnāstāḥ satyametanmṛṣetarat
]

`v 2 [
mithyābhāvanayā brahmansvavikalpakalaṅkitāḥ |
na brahma vayamityantarniścayena hyadhogatāḥ
]

`v 3 [
brahmaṇo vyatiriktatvaṃ brahmārṇavagatā api |
bhāvayantyo vimuhyanti bhīmāsu bhavabhūmiṣu
]

`v 4 [
yā etāḥ saṃvido brāhmyo mananaikakalaṅkitāḥ |
etattatkarmaṇāṃ bījamapyakarmaiva viddhi tāḥ
]

`v 5 [
saṃkalparūpayaivāntarmune kalanayaitayā |
karmajālakarañjānāṃ bījamuṣṭyā karālayā
]

`v 6 [
imā jagati vistīrṇāḥ śariropalapaṅktayaḥ |
tiṣṭhanti parivalganti rudanti ca hasanti ca
]

`v 7 [
ābrahmastambaparyantaṃ spandanaiḥ pavano yathā |
ullasanti nilīyante mlāyanti vihasanti ca
]

`v 8 [
tā etāḥ kāścidatyacchā yathā hariharādayaḥ |
kāścidalpavimohasthā yathoraganarāmarāḥ
]

`v 9 [
kāścidatyantamohasthā yathā tarutṛṇādayaḥ |
kāścidajñānasaṃmūḍhāḥ kṛmikīṭatvamāgatāḥ
]

`v 10 [
kāścittṛṇavaduhyante dūre brahmamahodadheḥ |
aprāptabhūmikā etā yathoraganagādayaḥ
]

`v 11 [
sattvamātraṃ samālokya kāścidevamupāgatāḥ |
jātājātā nikhanyante kṛtāntajaraṭhākhunā
]

`v 12 [
kāścidantaramāsādya brahmatattvamahāmbudheḥ |
gatāstattāṃ samaṃ kāyairharibrahmaharādikāḥ
]

`v 13 [
alpamohātmikāḥ kāścittameva brahmavāridhim |
adṛṣṭapārabhūmyaughamavalambya vyavasthitāḥ
]

`v 14 [
kāścidbhoktavyajanmaughabhuktajanmaughakoṭayaḥ |
vandhyāḥ prakāśatāmasyaḥ saṃsthitā bhūtajātayaḥ
]

`v 15 [
kāścidūrdhvādadho yānti yathā hastānmahatphalam |
ūrdhvādūrdhvataraṃ kāścidadhastātkāścidapyadhaḥ
]

`v 16 [
bahusukhaduḥkhakarākarākṣayeyaṃ
paramapadāsmaraṇātsamāgateha |
paramapadāvagamātprayāti nāśaṃ
vihagapatismaraṇāddviṣavyatheva
]