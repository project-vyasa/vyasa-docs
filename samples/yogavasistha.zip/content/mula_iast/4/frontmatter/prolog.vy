`set { scope="paratext" }

`v 1 [
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
Vasudeva ḻaxmana ṣharma Pansikar
1918
sthitiprakaraṇaṃ caturtham |
prathamaḥ sargaḥ 1
athotpattiprakaraṇādanantaramidaṃ śṛṇu |
sthitiprakaraṇaṃ rāma jñātaṃ nirvāṇakāri yat
]

`v 2 [
evaṃ tāvadidaṃ viddhi dṛśyaṃ jagaditi sthitam |
ahaṃ cetyādyanākāraṃ bhrāntimātramasanmayam
]

`v 3 [
akartṛkamaraṅgaṃ ca gagane citramutthitam |
adraṣṭṛkaṃ cānubhavamanidraṃ svapnadarśanam
]

`v 4 [
bhaviṣyatpuranirmāṇaṃ cittasaṃsthamivoditam |
markaṭānalatāpāntamasadevārthasādhakam
]

`v 5 [
brahmaṇyananyadanyābhamambvāvartavadāsthitam |
sadrūpamapi `note[tadrūpam iti pāṭhaḥ] niḥśūnyaṃ tejaḥ
sauramivāmbare
]

`v 6 [
ratnābhāpuñjamiva khe dṛśyamānamabhittimat |
gandharvāṇāṃ puramiva dṛśyaṃ `note[dṛśyamānaṃ iti pāṭhaḥ]
nityamabhittimat
]

`v 7 [
mṛgatṛṣṇāmbvivāsatyaṃ satyavatpratyayapradam |
saṃkalpapuravatprauḍhamanubhūtamasanmayam
]

`v 8 [
kathārthapratibhānātma na kvacitsthitamasthitam |
niḥsāramapyatīvāntaḥsāraṃ svapnācalopamam
]

`v 9 [
bhūtākāśamivākarabhāsuraṃ śūnyamātrakam |
śaradabhramivāgrasthamalamakṣayamakṣatam
]

`v 10 [
varṇo vyomamalasyeva dṛśyamānamavastukam |
svapnāṅganāratākāramarthaniṣṭhamanarthakam
]

`v 11 [
citrodyānamivotphullamarasaṃ sarasākṛti |
prakāśamapi nistejaścitrārkānalavatsthitam
]

`v 12 [
anubhūtaṃ manorājyamivāsatyamavāstavam |
citrapadmākara iva sārasaugandhyavarjitam
]

`v 13 [
śūnye prakacitaṃ nānāvarṇamākāritātmakam |
apiṇḍagrahamāśunyamindracāpamivotthitam
]

`v 14 [
parāmarśena śuṣyadbhirbhūtapelavapallavaiḥ |
kṛtaṃ jaḍamasārātma kadalīstambhabhāsuram
]

`v 15 [
parasya paramātmana āmarśeneṣadvicāreṇāpi | parasyānyasya
vāyvātapajanāderāmarśeneṣadabhighātenāpi ca | kadalīstambhaḥ kadalītaruḥ | 14
|
sphuritekṣaṇadṛṣṭāndhakāracakrakavartanam |
atyantamabhavadrūpamapi pratyakṣavatsthitam
]

`v 16 [
vārbudbudamivābhogi śūnyamantaḥsphuradvapuḥ |
rasātmakaṃ cāpyarasamavicchinnakṣayodayam
]

`v 17 [
nīhāra iva vistāri gṛhītaṃ sanna kiṃcana |
jaḍaśūnyāspadaṃ śūnyaṃ keṣāṃcitparamāṇuvat
]

`v 18 [
kiṃcidbhūtamayo'smīti sthitaṃ śūnyamabhūtakam |
gṛhyamāṇo'pyasadrūpo niśācara ivāsthitam
]

`v 19 [
śrīrāma uvāca |
mahākalpakṣaye dṛśyamāste bīja ivāṅkuraḥ |
pare bhūya udetyetattata eveti kiṃ vada
]

`v 20 [
evaṃbodhāḥ kimajñāḥ syuruta jñā iti ca sphuṭam |
yathāvadbhagavanbrūhi sarvasaṃśayaśāntaye
]

`v 21 [
evaṃ pralaye svasattayā kāraṇe jagadastīti prakāreṇa bodho yeṣāṃ te kapilādayaḥ |
20 |
śrīvasiṣṭha uvāca |
idaṃ bīje'ṅkura iva dṛśyamāste mahāśaye |
brūte ya evamajñatvametattasyāsti śaiśavam
]

`v 22 [
śṛṇvetatkimasaṃbandhaṃ kathametadavāstavam |
viparīto bodha eṣa vaktuḥ śrotuśca mohakṛt
]

`v 23 [
bīje kilāṅkura iva jagadāsta itīha yā |
buddhiḥ sā satpralāpārthaṃ mūḍhā śṛṇu kathaṃ kila
]

`v 24 [
bījaṃ bhavetsvayaṃ dṛśyaṃ cittādīndriyagocaram |
yavadhānādidhānyāni yuktaḥ `note[yuktastatrāṅkurodbhava iti pāṭhaḥ]
patrāṅkurodbhavaḥ
]

`v 25 [
manaḥṣaṣṭhendriyātītaṃ yatsyādatitarāmaṇu |
bījaṃ tadbhavituṃ śaktaṃ `note[śakya iti pāṭhaḥ] svayaṃbhūrjagatāṃ
katham
]

`v 26 [
ākāśādapi sūkṣmasya parasya paramātmanaḥ |
sarvākhyānupalambhasya kīdṛśī bījatā katham
]

`v 27 [
tatsūkṣmamasadābhāsamasadeva hyatādṛśam |
kīdṛśī bījatā tatra bījābhāve kuto'ṅkuraḥ
]

`v 28 [
gaganāṅgādapi svacche śūnye tatra pare pade |
kathaṃ santi jaganmerusamudragaganādayaḥ
]

`v 29 [
na kiṃcidyatkathaṃ kiṃcittatrāste vastu vastuni |
asti cettatkathaṃ tatra vidyamānaṃ na dṛśyate
]

`v 30 [
na kiṃcidātmanaḥ kiṃcitkathameti kuto'thavā |
śūnyarūpādghaṭākāśājjāto'driḥ kva kutaḥ kadā
]

`v 31 [
pratipakṣe kathaṃ kiṃcidāste cchāyātape yathā |
kathamāste tamo bhānau kathamāste himo'nale
]

`v 32 [
merurāste kathamaṇau kutaḥ kiṃcidanākṛtau |
tadatadrūpayoraikyaṃ kva cchāyātapayoriva
]

`v 33 [
sākāravaṭadhānādāvaṅkurāḥ santi yuktimat |
nākāre tanmahākāraṃ jagadastītyayuktikam
]

`v 34 [
nākāre anākāre | nāyaṃ nañ kiṃtu naśabdo'nyaḥ pratiṣedhārthaḥ samasyate | 33
|
deśāntare yacca narāntare ca
buddhyādisarvendriyaśakti dṛśyam |
nāstyeva tattadvidhabuddhibodhe
na kiṃcidityeva taducyate ca
]

`v 35 [
kāryasya tatkāraṇatāṃ prayātaṃ
vaktīti yastasya vimūḍhabodhaḥ |
kairnāma tatkāryamudeti tasmā-
tsvaiḥ kāraṇādyaiḥ sahakārirūpaiḥ
]

`v 36 [
na dvitīyo'pītyāha - kāryasyeti | sadeva somyedamagra āsīt ityādiśrutiṣu na
kāryakāraṇayorddhe satte pratīyete | ekamevādvitīyam iti vākyaśeṣavirodhāt |
tatraitadvimṛśyatām - kiṃ kāryameva sat tatkāryasattvameva kāraṇatāṃ
prayātaṃ kāraṇe āropitaṃ śrutirvaktīti vā kāraṇameva sattatsattvameva kārye
āropitamiti śrutirvaktīti vā | athavā sadeva sat satsattaiva kāryakāraṇayorāropiteti |
tatra tasya sāṃkhyasya bodhaḥ sa ādyapakṣānusārī cet sa vimūḍhabodho bhrama
eva | vācārambhaṇaṃ vikāro nāmadheyam
ityādikāryānṛtatvaparaśrutyananuguṇatvātkāraṇānṛtatvāpādakatvena
svasiddhāntabādhakatvāccetyāśayenāha - kairnāmeti | kāraṇānāṃ
guṇānāmevānṛtatve tanmahadādikāryaṃ kaiḥ kāraṇairudetyautpadyate nāma |
kāraṇe asati kāryasyotpattumevāśakterityarthaḥ | ata eva na dvitīyo'pi | kārye asati
tattatkāraṇatāyā api tadghaṭitāyā nirūpayitumaśakteriti pariśeṣāttṛtīyakalpa
eva śrutyabhipreto yuktaśca parigrāhya ityāha - tasmādityādyuttaraślokena |
35 |
durbuddhibhiḥ kāraṇakāryabhāvaṃ
saṃkalpitaṃ dūratare vyudasya |
tadeva tatsatyamanādimadhyaṃ
jagattadetatsthitamityavehi
]