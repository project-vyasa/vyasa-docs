`v 1 [
| navamo divasaḥ |
ṣaṭcatvāriṃśaḥ sargaḥ 46
śrīvasiṣṭha uvāca |
ramye dhaneṣu dārādau śokasyāvasaro `note[mūle harṣasyāvasaro hi kaḥ iti
pāṭhaḥ | ṭīkāyāṃ ca ubhayānvayītyasyānantaraṃ - dārādāvindrajāle
kṣaṇā duṣṭe sati harṣasyāvasaraḥ kaḥ tasminnaṣṭe vā kā
paridevanetyanvayaḥ iti pāṭho'dhikaḥ kvacit] hi kaḥ |
indrajālekṣaṇāddṛṣṭe naṣṭe kā paridevanā
]

`v 2 [
gandharvanagarasyārthe dūṣite bhūṣite tathā |
avidyāṃśe sutādau vā kaḥ kramaḥ sukhaduḥkhayoḥ
]

`v 3 [
ramye dhane'tha dārādau harṣasyāvasaro hi kaḥ |
vṛddhāyāṃ mṛgatṛṣṇāyāṃ kimānando jalārthinām
]

`v 4 [
dhanadārādau ca samṛddhe satīti śeṣaḥ | ānando jalakrīḍādisukhādhikyaṃ kim |
3 |
dhanadāreṣu vṛddheṣu duḥkhaṃ yuktaṃ na tuṣṭayaḥ |
vṛddhāyaṃ mohamāyāyāṃ kaḥ samāśvāsavāniha
]

`v 5 [
yaireva jāyate rāgo mūrkhasyādhikatāgataiḥ |
taireva bhogaiḥ prājñasya virāga upajāyate
]

`v 6 [
naṣṭe dhane'tha dārādau harṣasyāvasaro hi kaḥ |
pārāvalokinastvetairvirāgaṃ yānti sādhavaḥ
]

`v 7 [
ato rāghava tattvajño vyavahāreṣu saṃsṛteḥ |
naṣṭaṃ naṣṭamupekṣasva prāptaṃ prāptamupāhara
]

`v 8 [
anāgatānāṃ bhogānāmavāñchanamakṛtrimam |
āgatānāṃ ca saṃbhoga iti paṇḍitalakṣaṇam
]

`v 9 [
saṃsārasaṃbhrame hyasiṃśchannātmanyātatāyini |
tathā vihara saṃbuddho yathā nāyāsi mūḍhatām
]

`v 10 [
saṃsārāḍambarasyāsya prapañcarahite krame |
samyagjñā nānupaśyanti ye hatāste kubuddhayaḥ
]

`v 11 [
yayā kayācidyuktyaiva dṛśyādyasya gatā ratiḥ |
parimajjati tasyāsthā na kvacidvimalā matiḥ
]

`v 12 [
yasyāsadidamityāsthā nivṛttā sarvavastuṣu |
kroḍīkaroti sarvajñaṃ nāvidyā tamavāstavī
]

`v 13 [
ahaṃ jagaccaikamidaṃ sarvameveti yasya dhīḥ |
āsthānāsthe parityajya saṃsthitā sa na majjati
]

`v 14 [
śuddhaṃ sadasatormadhyaṃ padaṃ buddhyā'valambya ca |
sabāhyābhyantaraṃ dṛśyaṃ mā gṛhāṇa vimuñca mā
]

`v 15 [
atyantavirataḥ svasthaḥ sarvavāsavivarjitaḥ |
vyomavattiṣṭha nīrāgo rāma kāryaparo'pi san
]

`v 16 [
yasya necchā na vānicchā jñasya karmaṇi tiṣṭhataḥ |
na tasya lipyate prajñā padmapatramivāmbubhiḥ
]

`v 17 [
darśanasparśanādīni mā karotu karotu ca |
tavendriyamano gauṇaṃ tvamaniccho bhavātmavān
]

`v 18 [
mamedamityasadbhūtamindriyārthe bhavanmanaḥ |
mā nimajjatvamagnaḥ sanmā karotu karotu vā
]

`v 19 [
yadā te nendriyārthaśrīḥ svadate hṛdi rāghava |
tadā vijñātavijñānaḥ samuttīrṇabhavārṇavaḥ
]

`v 20 [
āsvāditendriyārthasya satanoratanorapi |
anicchato'pi saṃpannā muktirarthavaśāttava
]

`v 21 [
uccaiḥpadāya parayā prajñayā vāsanāgaṇāt |
puṣpādgandhamivodāraṃ ceto rāma pṛthakkuru
]

`v 22 [
saṃsārāmbunidhāvasminvāsanāmbupariplute |
ye prajñā nāvamārūḍhāste tīrṇā bruḍitāḥ pare
]

`v 23 [
kṣuradhārāpramitayā dhiyā paramadhīrayā |
pravicāryātmanastattvaṃ tataḥ svapadamāviśa
]

`v 24 [
yathā tattvavidaḥ prājñā jñānabṛṃhitacetasaḥ |
viharanti tathā rāma vihartavyaṃ na mūḍhavat
]

`v 25 [
jīvanmuktā mahātmāno nityatṛptā mahādhiyaḥ |
ācārairanugantavyā na bhogakṛpaṇāḥ śaṭhāḥ
]

`v 26 [
na tyajanti na vāñchanti vyavahāraṃ jagadgatam |
sarvamevānuvartante pārāvāravido janāḥ
]

`v 27 [
prabhāvasyābhimānasya guṇānāṃ yaśasaḥ śriyaḥ |
na kvacitkṛpaṇā loke mahāntastattvadarśinaḥ
]

`v 28 [
suśūnye'pi na khidyante devodyāne nasaṅginaḥ |
niyatiṃ ca na muñcanti mahānto bhāskarā iva
]

`v 29 [
vigatecchā yathāprāptavyavahārānuvartinaḥ |
vicaranti samunnaddhāḥ svasthā deharathe sthitāḥ
]

`v 30 [
tvamapi prāptavān rāma vivekamimamātatam |
prajñābalena cānena jñāne svastho'si sundara
]

`v 31 [
mayi tarhi te guṇāḥ santi na veti sadehakātaraṃ rāmamāśvāsayati - tvamapīti |
30 |
spaṣṭāṃ dṛṣṭimavaṣṭabhya nirmāno gatamatsaraḥ |
viharāsminbhuvaḥ pīṭhe parāṃ siddhimavāpsyasi
]

`v 32 [
svasthaḥ sarvehitatyāgī dūrālokanavāñchanaḥ |
parāṃ śītalatāmantarādāya viharānagha
]

`v 33 [
śrīvālmīkiruvāca |
itthaṃ girā vimalayā vimalāśayasya
rāmo muneḥ sapadi mṛṣṭa ivābabhāse |
jñānāmṛtena madhureṇa virājitāntaḥ
pūrṇaḥ śaśāṅka iva śītalatāṃ jagāma
]