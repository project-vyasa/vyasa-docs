`v 1 [
pañcapañcāśaḥ sargaḥ 55
śrīvasiṣṭha uvāca |
ityākarṇya tadā tatra rātrāvālapanaṃ dvayoḥ |
ahaṃ raghukulākāśaśaśāṅka raghunandana
]

`v 2 [
patitaḥ khātkadambāgre patrapuṣpaphalākule |
tūṣṇīṃ nirvṛṣṭamuktātmā śṛṅgāgra iva toyadaḥ
]

`v 3 [
apaśyaṃ tatra dāśūraṃ śūramindriyanigrahe |
pareṇa tapasā yuktaṃ tejaseva hutāśanam
]

`v 4 [
tejobhirdehaniṣkrāntaiḥ kāñcanīkṛtabhūtalam |
tāpayantaṃ pradeśaṃ taṃ bhuvanaṃ bhāskaro yathā
]

`v 5 [
māmathālokya saṃprāptaṃ dāśūro'rghasaparyayā |
vitīrṇaviṣṭaraṃ patrapūjayā paryapūjayat
]

`v 6 [
tataḥ pūrvakathāstena saha dāśūra bhāsvatā |
kṛtāstanayasaṃbodhāḥ saṃsārottaraṇakṣamāḥ
]

`v 7 [
pūrvakathāḥ prākprasutabrahmacarcāḥ | tanayaṃ samyagbodhayantīti
tanayasaṃbohāḥ | karmaṇyaṇ | gatikārakopapadānāṃ kṛdbhiḥ saha
samāsavacane kṛdgrahaṇe gatipūrvakasyāpi grahaṇātsopasargeṇa saha samāsaḥ |
6 |
dṛṣṭavāṃstamahaṃ vṛkṣaṃ korakottarakoṭaram |
dāśūrasyecchayā sarvairayatadbhirmṛgavrajaiḥ
]

`v 8 [
sevyamānaṃ vanamiva latāmaṇḍalamaṇḍitam |
smitena visphuṭamiva śvasanasphuritacchadam
]

`v 9 [
taṃ kadambaṃ vadhūśliṣṭavaraveṣeṇa varṇayati - smitenetyādinā | yataḥ
korakottarakoṭaraṃ śvasanasphuritapallavaṃ ca ata eva smitena sphuṭamiva sthitam |
8 |
latākoṭigatairbhrāntaiścāmarairindusundaraiḥ |
śubhrābhrakhaṇḍanikaraiḥ śarannabha ivāvṛtam
]

`v 10 [
prāleyakaṇapaddhatyā muktāvalyābhyalaṃkṛtam |
sarvāvayavamevācchapuṣpapūraiḥ prapūritam
]

`v 11 [
svareṇucandanālepaiḥ samālabdhamakhaṇḍitam |
svacchadābhogavipularaktāmbaraparicchadam
]

`v 12 [
vivāhāyeva veṣeṇa puṣpabhārātibhāriṇā |
latāṅganānuṣaktena nāgareṇa kṛtopamam
]

`v 13 [
munibaddhoṭajākāralatāmaṇḍapamaṇḍitam |
mañjarībhiḥ patākābhiryuktaṃ puramahotsave
]

`v 14 [
mṛgakaṇḍūyanadhvastapuṣpadhūlividhūsaram |
protsāritopāntavanaṃ vṛṣamallamivotthitam
]

`v 15 [
barhibhiḥ kusumodvāntaparāgaparipāṭalaiḥ |
nikṣepakṣiptasaṃdhyābhrabālavālamivācalaiḥ
]

`v 16 [
pravālāruṇahastena kusumasmitaśobhinā |
madhunā ghūrṇamānena prāntena pulakatviṣā
]

`v 17 [
nīrandhrapuṣpapūrṇena ghūrṇitena vanānilaiḥ |
nidrālukuḍmaladṛśā stabakastanadhāriṇā
]

`v 18 [
puṣpajālarajaḥpuñjakuṅkumāruṇavāsasā |
latāvitānanilayavātāyananiṣaṅgiṇā
]

`v 19 [
nīlapuṣpalatādolālīlālāsyavilāsinā |
āpādamastakaprāntaṃ sarvato nirmitālayam
]

`v 20 [
vṛndena vanadevīnāṃ kokilālāpaśālinā |
saṃdigdhamañjarījālamalinetreṇa bhāsinā
]

`v 21 [
avaśyāyopaśamitaratikhedairmadālasaiḥ |
puṣpadhūlisamālabdhairāśliṣṭairnibiḍaṃ mithaḥ
]

`v 22 [
puṣpāntarāntaḥpuragaiḥ kimapi praṇayocitam |
dhvanadbhirabhitaḥ svacchamattāliyugalairvṛtam
]

`v 23 [
kānanopāntanagarīguṃgumākarṇanecchayā |
kṣaṇamutkarṇamāśāntacāruvarvaṇaṭāṃkṛtaiḥ
]

`v 24 [
kṣaṇaṃ dalāgraviśrāntamugdhamugdhaśirastayā |
paśyadbhirindvaṃśukavajjālāmarṇavamekhalām
]

`v 25 [
vanasthalīnāṃ tanayairnayairmūrtimivāsthitaiḥ |
śubhaiḥ patrapuṭeṣvantarmṛgaiḥ sāratalāntaram
]

`v 26 [
nīḍaśvasatsuviśvastasuptamātrakapakṣiṇam |
pākacyutaphalopāntabhūtakañcukamaṇḍalī
]

`v 27 [
saṃdigdhamūkabhramaraṃ gucchaiḥ pūjākṣasūtrakaiḥ |
śyāmalīkṛtaparyantaṃ nīḍaiḥ pallavamaṇḍitaiḥ
]

`v 28 [
sugandhitāśeṣavanaṃ puṣpameghīkṛtāmbaram |
dhūlīkadambaśabalaphalaughavalitaṃ tale
]

`v 29 [
bahunātra kimuktena na kiṃcidapi vidyate |
patraṃ yatra tarau yatra noṣyate vā na yujyate
]

`v 30 [
patre patre mṛgāḥ suptā viśrāntāśca pade pade |
kacche kacche khagā līnāstasya bhūruhabhūpateḥ
]

`v 31 [
patre patre | adhogalitapatreṣu sarveṣvityarthaḥ | kaṃ avaśyāyajalaṃ chayati
chinattīti kacchaḥ patrādyadhodeśaḥ | cho chedane ityasmādāto'nupasarge kaḥ |
30 |
evaṃguṇaviśiṣṭaṃ taṃ samālokayato mama |
mahotsavena sadṛśī sā babhūva tamasvinī
]

`v 32 [
tataḥ kathābhī ramyābhiḥ sa tasya tanayo mayā |
vijñānālokaramyābhirnīto bodhaṃ paraṃ punaḥ
]

`v 33 [
āvayostatra citrābhiḥ kathābhiritaretaram |
śarvarī sā vyatīyāya muhūrta iva kāntayoḥ
]

`v 34 [
prātaḥ pratanutāṃ yāte puṣparddhighanajālake |
svargāṅganāṅgabhogābhe tārakānikare śanaiḥ
]

`v 35 [
ākadambanabhobhāgamupayātaṃ `note[mārgam iti pāṭhaḥ] sutānvitam |
ahaṃ visṛjya dāśuraṃ tato'maranadīṃ gataḥ
]

`v 36 [
tatrābhimatamāsādya sthānametya nabhastalam |
praviśya khaṃ munīnāṃ ca madhyaṃ svastha iva sthitaḥ
]

`v 37 [
dāśūrākhyāyikaiṣā te kathitā raghunandana |
jagataḥ pratibimbābhā satyākārāpyasanmayī
]

`v 38 [
dāśūrākhyāyikeveyamityetatkathitaṃ mayā |
tubhyaṃ rāghava bodhāya jagadrūpanirūpaṇe
]

`v 39 [
tasmādavāstavīṃ tyaktvā vāstavīmapi rañjanām |
dāśūrasiddhāntadṛśā sadodāro bhavātmavān
]

`v 40 [
tasmādvikalpaṃ malamātmanastvaṃ
nirdhūya paśyāmalamātmatattvam |
āsādayiṣyasyacirātpadaṃ ta-
dbhaviṣyasījyo bhuvaneṣu yena
]