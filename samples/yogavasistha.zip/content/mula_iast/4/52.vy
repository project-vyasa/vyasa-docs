`v 1 [
dvipañcāśaḥ sargaḥ 52
śrīvasiṣṭha uvāca |
kadācidatha mārgeṇa tena kailāsavāsinīm |
ahaṃ snātumadṛśyātmā vyomavīthīgato'gamam
]

`v 2 [
tena dāśūrakadambopalakṣitena mārgeṇa | kailāsavāsinīṃ mandākinīmiti śeṣaḥ |
1 |
nirgatya nabhasaḥ saptamunimaṇḍalakoṭarāt |
rātrau prāpto'smi sumate dāśūratarumunnatam `note[mūlataḥ iti pāṭhaḥ
tatra sārvavibhaktikastasiḥ]
]

`v 3 [
saptarṣimaṇḍalaṃ koṭaramivaikadeśo yasya tathāvidhānnabhaso dyulokākāśāt |
2 |
yāvacchṛṇomi viṭapakuharātkānane vacaḥ |
kuḍmalāmbhojalagnasya ṣaṭpadasyeva niḥsvanam
]

`v 4 [
śṛṇu putra mahābuddhe vastuto'sya samāmimām |
varṇayāmi mahāścaryāmekāmākhyāyikāṃ tava
]

`v 5 [
asti rājā mahāvīryo vikhyāto bhuvanatraye |
nāmnā khottha iti śrīmāñjagadākramaṇakṣamaḥ
]

`v 6 [
asyānuśāsanaṃ sarve bhuvaneṣvapi nāyakāḥ |
śirobhirdhārayantyuccaiścaḍāmaṇimivārthinaḥ
]

`v 7 [
yaḥ sāhasaikarasiko nānāścaryavihāravān |
kenacittriṣu lokeṣu na mahātmā vaśīkṛtaḥ
]

`v 8 [
yasyārambhasahasrāṇi sukhaduḥkhapradānyalam |
saṃkhyātuṃ kena śakyante kallolā jaladheriva
]

`v 9 [
yasya vīryaṃ suvīryasya na śastrairna ca pāvakaiḥ |
kenacidbhuvane krāntamākāśamiva muṣṭinā
]

`v 10 [
yadīyāṃ vitatārambhāṃ līlāṃ nirmāṇabhāsurām |
na manāganuvartante śakropendraharā api
]

`v 11 [
alpe'pi prayojane bahutarakalpanāsahasrasaṃkulatvādvitatārambhām |
svapnamanorathādinirmāṇairbhāsurām | anuvartante anukartuṃ śaknuvantīti yāvat |
10 |
trayastasya mahābāho dehā viharaṇakṣamāḥ |
jagadākramya tiṣṭhanti hyuttamādhamamadhyamāḥ
]

`v 12 [
vyomanyevātivitate jāto'sau triśarīrakaḥ |
tatraiva ca sthitiṃ yātaḥ śabdapātaśca pakṣivat
]

`v 13 [
tatraivāpāragagane nagaraṃ tena nirmitam |
caturdaśamahārathyaṃ vibhāgatrayabhūṣitam
]

`v 14 [
vanopavanamālāḍhyaṃ krīḍāśikharisundaram |
muktālatāvivalitavāpīsaptakabhūṣitam `note[vigalita iti pāṭhaḥ]
]

`v 15 [
śītaloṣṇātmakākṣīṇadīpadvayavirājitam |
ūrdhvādhogatirūpeṇa vaṇiṅmārgeṇa saṃkulam
]

`v 16 [
tasminnevātivipule pattane tena bhūbhṛtā |
saṃsāriṇo viracitā mugdhāpavarakā gaṇāḥ
]

`v 17 [
saṃsāriṇo jaṅgamāḥ | mugdhā viṣayavyāmūḍhā
apavarakavadātmākāśaparicchedakatvādapavarakā devamānuṣādidehagaṇāḥ | 16
|
ūrdhvaṃ kecidadhaḥ kecitkecinmadhye niyojitāḥ |
keciccireṇa naśyantaḥ kecicchīghravināśinaḥ
]

`v 18 [
asitacchādanacchannā navadvāravibhūṣitāḥ |
anāratavahadvātā bahuvātāyanānvitāḥ
]

`v 19 [
asitaiśchādanaiḥ keśatṛṇaiśchannāḥ | bahubhirvātāyanairūrdhvacchidraiḥ |
18 |
dīpapañcakasālokāstristhūṇāḥ śukladāravaḥ |
masṛṇālepamṛdavaḥ pratolībhujasaṃkulāḥ
]

`v 20 [
māyayā racitāstena rājñā teṣu mahātmanā |
rakṣitāro mahāyakṣā nityamālokabhīravaḥ
]

`v 21 [
teṣāṃ apavarakāṇāṃ abhimānena rakṣitāro yakṣāḥ kāryakaraṇaiḥ pūjyāḥ
svāmibhūtā ahaṃkārāḥ | ālokādātmavivekādbhīravaḥ | tatastatkṣayādityarthaḥ |
20 |
athāpavarakaugheṣu calatsu sa mahīpatiḥ |
karoti vividhāṃ krīḍāṃ nīḍeṣviva vihaṅgamaḥ
]

`v 22 [
triśarīraśateṣvantastairyakṣaiḥ saha putraka |
līlāvaśamuṣitvā tu punarnirgamya gacchati
]

`v 23 [
līlābhiravaśamasvādhīnaṃ yathā syāttathetyuṣitvā nirgamya cetyubhayānvayi | 22
|
tasyecchā jāyate vatsa kadāciccalacetasaḥ |
puraṃ bhaviṣyannirmāṇaṃ kiṃcidyāmīti niścalā
]

`v 24 [
bhūtāviṣṭa ivāvegāttata uthāya dhāvati |
puraṃ tadapyathāpnoti `note[tadāyamāpnoti iti pāṭhaḥ] gandharvairiva
nirmitam
]

`v 25 [
tasyecchā jāyate putra kadāciccalacetasaḥ |
vināśaṃ saṃprayāmīti tenāśu sa vinaśyati
]

`v 26 [
punarutpadyate tūrṇaṃ `note[purṇaṃ iti pāṭhaḥ]
svātmanormirivāmbhasaḥ |
vyavahāraṃ tanotyuccaiḥ punarārambhamantharam
]

`v 27 [
svayaiva vyavahṛtyātha kadācitparibhūyate |
kiṃkarosmyahamajñao'smi duḥkhito'smīti śocati
]

`v 28 [
mudametya kadācicca svayamāyāti dīnatām |
prāvṛḍvarṣakalollāsapūrādiva nadīrayaḥ
]

`v 29 [
jayati gacchati valgati jṛmbhate
sphurati bhāti na bhāti ca bhāsuraḥ |
suta mahāmahimā sa mahīpatiḥ
patirapāmiva vātarayākulaḥ
]