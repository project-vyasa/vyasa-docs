`v 1 [
saptaviṃśaḥ sargaḥ 27
śrīvaiṣṭha uvāca |
tasmiṃstadā vartamāne ghore samarasaṃbhrame |
devāsuraśarīreṣu garteṣvabhrodareṣviva
]

`v 2 [
vahatsvasṛkpravāheṣu gaṅgāpūreṣvivāmbarāt |
dāmni veṣṭitadevaughakṛtakṣveḍāghanārave
]

`v 3 [
vyāle nijakarākṛṣṭipiṣṭasarvasurālaye |
kaṭe kaṭhinasaṃrambhasaṅgarakṣapitāmare
]

`v 4 [
airāvate kṣīṇarave palāyanaparāyaṇe |
pravṛddhe dānavānīke madhyāhna iva bhāskare
]

`v 5 [
patitāṅgavyathārtāni prasnavadrudhirāṇi ca |
payāṃsīvāvasetūni devasainyāni dudruvuḥ
]

`v 6 [
dāmavyālakaṭāstāni ciramantarhitāni ca |
anujagmurlasannādamindhanānīva pāvakāḥ
]

`v 7 [
anviṣṭānapi yatnena nālabhantāsurāḥ surān |
ghanajālavanoḍḍīnānsiṃhā hariṇakāniva
]

`v 8 [
alabdheṣvamaraugheṣu dāmavyālakaṭāstadā |
jagmuḥ pātālakośasthaṃ prabhuṃ pramuditāśayāḥ
]

`v 9 [
atha devā viṣaṇṇāste ksaṇamāśvāsya vai yayuḥ |
jayopāyāya vijitā brahmāṇamamitaujasam
]

`v 10 [
teṣāmāvirabhūdbrahmā raktaraktānanaśriyām |
sāyaṃ raktīkṛtāmbūnāmabdhīnāmiva candramāḥ
]

`v 11 [
praṇamya te surāstasmā anarthaṃ śambarehitam |
samyakprakathayāmāsurdāmavyālakaṭakramam
]

`v 12 [
tadākarṇyākhilaṃ brahmā vicārya sa vicāravit |
uvācedaṃ surānīkamāśvāsanakaraṃ vacaḥ
]

`v 13 [
śrībrahmovāca |
śatavarṣasahasrānte śambareṇa hareḥ karāt |
martavyaṃ samareśasya tatkālaṃ saṃpratīkṣatām
]

`v 14 [
dāmavyālakaṭānetānadya tvamarasattamāḥ |
yodhayantaḥ palāyadhvaṃ māyāyuddhena dānavān
]

`v 15 [
yuddhābhyāsavaśādeṣāṃ mukurāṇāmivāśaye |
ahaṃkāracamatkāraḥ pratibimbamupaiṣyati
]

`v 16 [
gṛhītavāsanāstvete dāmavyālakaṭāḥ surāḥ |
sujeyā vo bhaviṣyanti lagnajālāḥ khagā iva
]

`v 17 [
adya tvavāsanā hyete sukhaduḥkhavivarjitāḥ |
dhairyeṇārīnvinighnanto devā durjayatāṃ gatāḥ
]

`v 18 [
vāsanātantubaddhā ye āśāpāśavaśīkṛtāḥ |
vaśyatāṃ yānti te loke rajjubaddhāḥ khagā iva
]

`v 19 [
ye bhinnavāsanā dhīrāḥ sarvatrāsaktabuddhayaḥ |
na hṛṣyanti na kupyanti durjayāste mahādhiyaḥ
]

`v 20 [
yasyāntarvāsanārajjvā granthibandhaḥ śarīriṇaḥ |
mahānapi bahujñao'pi sa bālenāpi jīyate
]

`v 21 [
ayaṃ so'haṃ mamedaṃ tadityākalpitakalpanaḥ |
āpadāṃ pātratāmeti payasāmiva sāgaraḥ
]

`v 22 [
iyanmātraparicchinno yenātmā bhavyabhāvitaḥ |
sa sarvajño'pi sarvatra parāṃ kṛpaṇatāṃ gataḥ
]

`v 23 [
anantasyāprameyasya yeneyattā prakalpitā |
ātmanastasya tenātmā svātmanaivāvaśīkṛtaḥ
]

`v 24 [
ātmano vyatiriktaṃ yatkiṃcidasti jagattraye |
yatropādeyabhāvena baddhā bhavatu vāsanā
]

`v 25 [
āsthāmātramanantānāṃ duḥkhānāmākaraṃ viduḥ |
anāsthāmātramabhitaḥ sukhānāmākaraṃ viduḥ
]

`v 26 [
dāmavyālakaṭā yāvadanāsthā bhavasaṃsthitau |
tāvanna nāma jeyāvo maśakānāmivānalāḥ
]

`v 27 [
antarvāsanayā janturdīnatāmanuyātayā |
jito bhavatyanyathā tu maśako'pyamarācalaḥ
]

`v 28 [
vidyate vāsanā yatra tatra sā yāti pīnatām |
guṇo guṇini hi dvitvaṃ sato dṛṣṭaṃ hi nāsataḥ
]

`v 29 [
ayaṃ so'haṃ mamedaṃ cetyevamantaḥ svāsanam |
yathā dāmādayaḥ śakra bhāvayanti tathā kuru
]

`v 30 [
yā yā janasya vipado bhāvābhāvadaśāśca yāḥ |
tṛṣṇākarañjavallyāstā mañjaryaḥ kaṭukomalāḥ
]

`v 31 [
vāsanātantubaddho yo loko viparivartate |
sā pravṛddhātiduḥkhāya sukhāyocchedamāgatā
]

`v 32 [
dhīro'pyatibahujño'pi kulajo'pi mahānapi |
tṛṣṇayā badhyate jantuḥ siṃhaḥ śṛṅkhalayā yathā
]

`v 33 [
dehapādapasaṃsthasya hṛdayālayagāminaḥ |
tṛṣṇā cittakhagasyeyaṃ vāgurā parikalpitā
]

`v 34 [
dīno vāsanayā lokaḥ kṛtāntenāpakṛṣyate |
rajjveva bālena khago vivaśo bhṛśamucchvasan
]

`v 35 [
alamāyudhabhāreṇa saṃgara bhramaṇena ca |
vāsanāyā viparyāsaṃ yuktyā yatnādripoḥ kuru
]

`v 36 [
antarā `note[antarakṣubhite iti pāṭhaṣṭīkākṛtsaṃmata iti bhāti]
kṣubhite dhairye riporamaranāyaka |
na śastrāṇi na cāstrāṇi na śāstrāṇi jayanti ca
]

`v 37 [
dāmavyālakaṭāstvete yuddhābhyāsavaśena ca |
ahaṃkāramayīṃ mattāste grahīṣyanti vāsanām
]

`v 38 [
yadā te'tyajñapuruṣāḥ śambareṇa vinirmitāḥ |
vāsanāmāśrayiṣyanti tadā yāsyanti jeyatām
]

`v 39 [
tattāvadyuktiyuddhena tānprabodhayatāmarāḥ |
yāvadabhyāsavaśato bhaviṣyanti savāsanāḥ
]

`v 40 [
tato vaśyā bhaviṣyanti bhavatāṃ baddhavāsanāḥ |
tṛṣṇā'protāśayā loke na ca kecana pelavāḥ
]

`v 41 [
samaviṣamamidaṃ jagatsamagraṃ
samupanataṃ sthiratāṃ svavāsanāntaḥ |
calacalalaharībharo yathābdhā-
vata iha saiva cikitsyatāṃ prayātā
]