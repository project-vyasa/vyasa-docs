`v 1 [
daśamaḥ sargaḥ 10
śrīvasiṣṭha uvāca |
atha varṣasahasreṇa divyena parameśvaraḥ |
bhṛguḥ paramasaṃbodhādvirarāma samādhitaḥ
]

`v 2 [
nāpaśyadagre tanayaṃ vinayāvanatānanam |
sāmantaṃ guṇasenāyāḥ puṇyaṃ mūrtamiva sthitam
]

`v 3 [
apaśyatkevalaṃ kāyakaṅkālaṃ purato mahat |
dehayuktamivābhāgyaṃ dāridryamiva mūrtimat
]

`v 4 [
tāpaśuṣkavapuḥ kṛttirandhrasphuritatittiriṃ |
saṃśuṣkāntrodaraguhāchāyāviśrāntadarduram
]

`v 5 [
netragartakasaṃsaktaprasūtanavakīṭakam |
parśukāpañjaraprotakośakārakṛmivrajam
]

`v 6 [
prāktanīmupabhogehāmiṣṭāniṣṭaphalapradām |
dhārādhautāntrayā tadvadbhṛśaṃ śuṣkāsthimālayā
]

`v 7 [
śiroghaṭena śubhreṇa masṛṇenenduvarcasā |
viḍambayacca karpūrāplutaliṅgaśiraḥśriyam
]

`v 8 [
ṛjvyā saṃśuṣkaśirayā svāsthimātrāvaśeṣayā |
grīvayātmānusṛtayā dīrghīkurvadivākṛtim
]

`v 9 [
mṛṇālikāpāṇḍurayā dhārāvabhṛtamāṃsayā |
nāsāgrāsthikayā vaktre kṛtasīmākṛtiṃ dadhat
]

`v 10 [
dīrghakandharayā nūnamunnatīkṛtavaktrayā |
prekṣamāṇamiva prāṇānutkrāntānambarodare
]

`v 11 [
jaṅghorujānudordaṇḍairdviguṇāṃ dīrghatāṃ gataiḥ |
pratiṣṭhānamivāśāntaṃ dīrghādhvaśramabhītitaḥ
]

`v 12 [
udareṇātiriktena carmaśeṣeṇa śoṣiṇā |
pradarśayadivājñasya hṛdayasyātiśūnyatām
]

`v 13 [
prekṣya tacchuṣkakaṅkālamālānaṃ duḥkhadantinaḥ |
pūrvāparaparāmarśamakurvanbhṛgurutthitaḥ
]

`v 14 [
ālokasamakāle hi pratibhānaṃ tato bhṛgoḥ |
ciramutkrāntajīvaḥ kiṃ matputro'yamiti kṣaṇāt
]

`v 15 [
ālokanamālokastatsamakālaṃ pratibhānaṃ vakṣyamāṇavitarkaḥ abhūditi śeṣaḥ |
14 |
acintayata evāsya bhaviṣyaṃ tanayaṃ tataḥ |
kālaṃ prati babhūvāśu kopaḥ paramadāruṇaḥ
]

`v 16 [
bhaviṣyamavaśyabhāvyarthamacintayataḥ tanayaṃ mṛtaṃ dṛṣṭveti śeṣaḥ | 15
|
akāla eva matputro nītaḥ kimiti kopitaḥ |
kālāya śāpamutsraṣṭuṃ bhagavānupacakrame
]

`v 17 [
athākalitarūpo'sau kālaḥ kavalitaprajaḥ |
ādhibhautikamāsthāya vapurmunimupāyayau
]

`v 18 [
khaḍgapāśadharaḥ śrīmānkuṇḍalī kavacānvitaḥ |
ṣaḍbhujaḥ ṣaṇmukho vahnyā vṛtaḥ kiṅkarasenayā
]

`v 19 [
yaccharīrasamutthena jvālājālena valgatā |
phullakiṃśukavṛkṣasya babhārādreḥ śriyaṃ nabhaḥ
]

`v 20 [
yatkarasthatriśūlāgraniḥsṛtairagnimaṇḍalaiḥ |
virejuruditairāśāḥ kānakairiva kuṇḍalaiḥ
]

`v 21 [
yatparaśvasanāpāstaśikharā medinībhṛtaḥ |
dolāmiva samārūḍhāśceluḥ petuśca ghūrṇitāḥ
]

`v 22 [
yatkhaḍgamaṇḍaloddyotaiḥ śyāmaṃ bimbaṃ vivasvataḥ |
kalpadagdhajagaddhūmaparyākulamivābabhau
]

`v 23 [
sa upetya mahābāho kupitaṃ taṃ mahāmunim |
kalpakṣubdhābdhigambhīraṃ sāntvapūrvamuvāca ha
]

`v 24 [
vijñātalokasthitayo mune dṛṣṭaparāvarāḥ |
hetunāpi na muhyanti kiṃ nu hetuṃ vinottamāḥ
]

`v 25 [
tvamanantatapā vipro vayaṃ niyatipālakāḥ |
tena saṃpūjyase pūjyaḥ sādho netarayecchayā
]

`v 26 [
mā tapaḥkṣapayā'buddhe kalpakālamahānalaiḥ |
yo na dagdho'smi me tasya kiṃ tvaṃ śāpena dhakṣyasi
]

`v 27 [
śāpadāne pratyuta tavaivāniṣṭaṃ syānna mametyāśayenāha - mā tapa iti |
abuddhe vyarthabuddhe iti kṣepacchalena jñānabādhitatvādavidyamānabuddhe iti
praśaṃsā | samānavākye yuṣmadasmadādeśā vaktavyāḥ iti
kātyāyanavacanavirodhādbhinnavākyasthapadātparasya me ityādeśaśchāndasaḥ |
26 |
saṃsārāvalayo grastā nigīrṇā rudrakoṭayaḥ |
bhuktāni viṣṇuvṛndāni kva na śaktā vayaṃ mune
]

`v 28 [
bhoktāro hi vayaṃ brahmanbhojanaṃ yuṣmadādayaḥ |
svayaṃ niyatireṣā hi nāvayoretadīhitam
]

`v 29 [
svayamūrdhvaṃ prayātyagniḥ svayaṃ yānti payāṃsyadhaḥ |
bhoktāraṃ bhojanaṃ yāti sṛṣṭiṃ cāpyantakaḥsvayam
]

`v 30 [
idamitthaṃ mune rūpaṃ mameha paramātmanaḥ |
svātmani svayamevātmā svata eva vijṛmbhate
]

`v 31 [
neha kartā na bhoktāsti dṛṣṭyā naṣṭakalaṅkayā |
bahavaśceha kartāro dṛṣṭyā'naṣṭakalaṅkayā
]

`v 32 [
kartṛtākartṛte brahmankevalaṃ parikalpite |
asamyagdarśanenaiva na samyagdarśanasya te
]

`v 33 [
puṣpāṇi tarukhaṇḍeṣu bhūtāni bhuvaneṣu ca |
svayamāyānti yāntīha kalpate hetunāmabhiḥ
]

`v 34 [
abbimbitasya candrasya calane kartrakartṛte `note[kartṛkartṛte iti
pāṭhaḥ] |
na satye nānṛte yadvattadvatkālasya sṛṣṭiṣu
]

`v 35 [
mano mithyābhramābhoge kartṛtākartṛtāmayīm |
karoti kalanāṃ rajjvāṃ bhrāntekṣaṇa ivāhitām
]

`v 36 [
tena māgā mune kopamāpadāmīdṛśaḥ kramaḥ |
yadyathā tattathaivāśu satyamālokayākulaḥ
]

`v 37 [
na vayaṃ pratibhārthehā nābhimānavaśīkṛtāḥ |
svato hi tāta vaśagāḥ kevalaṃ niyatau sthitāḥ
]

`v 38 [
prakṛtavyavahārehāniyatīriyatervaśāt |
prājñāḥ samabhivartante nābhimānamahātamaḥ
]

`v 39 [
kartavyameva niyataṃ kevalaṃ kāryakovidaiḥ |
suṣuptivṛttimāśritya kadācittvaṃ na nāśaya
]

`v 40 [
kva sā jñānamayī dṛṣṭiḥ kva mahattvaṃ kva dhīratā |
mārge sarvaprasiddhe'pi kimandha iva muhyasi
]

`v 41 [
svakarmaphalapākotthāmavicārya daśāṃ mune |
kiṃ murkha iva sarvaña mudhā māṃ śaptumicchasi
]

`v 42 [
dehināmiha sarveṣāṃ śarīraṃ dvividhaṃ mune |
kiṃ na jānāsi taṃ dehamekamanyanmanobhidham
]

`v 43 [
tatra deho jaḍo'tyarthamāvināśaparāyaṇaḥ |
manastucchaṃ ca niyataṃ kadarthīkriyate tava
]

`v 44 [
catureṇa yathā sādho rathaḥ sārathinohyate |
kurvatā kiṃcana snehāddeho'yaṃ manasā tathā
]

`v 45 [
asatsaṃkalpaḥ kriyate saccharīraṃ vināśyate |
kṣaṇena manasā paṅkapuruṣaḥ śiśunā yathā
]

`v 46 [
cittameveha puruṣastatkṛtaṃ kṛtamucyate |
tadvaddhaṃ kalanāhetoḥ kalanāstaṃ vimucyate
]

`v 47 [
ayaṃ deha ivātrasthamidamaṅgamidaṃ śiraḥ |
idaṃ sphāravikāraṃ tanmana evābhidhīyate
]

`v 48 [
mano hi jīvājjīvākhyaṃ niścayaikatayā nu dhīḥ |
ahaṅkāro'bhimantṛtvānnānātā svayameva hi
]

`v 49 [
ekameva mano yathā pūrvapūrvajīvājjivāntarākhyaṃ bhavati tathā jīvaṭopākhyāne
vakṣyate | manaḥsaṃkalpite'rthe niścayaikatayā mana eva tadanu dhīrbhavati |
abhimantrtvādahaṅkāra iti manaḥ svayameva nānātā nānātvaṃ bhavatītyarthaḥ |
48 |
dehavāsanayā cetastvanyāni svāni cecchayā |
pārthivāni śarīrāṇi hyasanti paripaśyati
]

`v 50 [
ālokayati cetsatyaṃ tadā satyamayīṃ manaḥ |
śarīrabhāvanāṃ tyaktvā parāmāyāti nirvṛtim
]

`v 51 [
tanmanastava putrasya samādhau tvayi saṃsthite |
svamanorathamārgeṇa dūrāddūrataraṃ gatam
]

`v 52 [
imamauśanasaṃ tyaktvā dehaṃ mandarakandare |
prayāto vaibudhaṃ sadma nīḍoḍḍīnaḥ khago yathā
]

`v 53 [
tatra mandaraguñjeṣu pārijātataleṣu ca |
nandanodyānakhaṇḍeṣu lokapālapureṣu ca
]

`v 54 [
mune caturyugānyaṣṭau viśvācīṃ devasundarīm |
asevata mahātejāḥ ṣaṭpadaḥ padminīmiva
]

`v 55 [
tīvrasaṃvegasaṃpannasvasaṃkalpopakalpite |
atha puṇyakṣaye jāte nīhāra iva śārvare `note[śāmbare iti pāṭhaḥ]
]

`v 56 [
svarga iva puṇyakṣayāttatpāto'pi manaḥkalpanayaivetyāśayenāha - tīvreti | 55
|
pramlānakusumottaṃsaḥ khinnāṅgāvayavollasaḥ |
sa papāta tayā sārdhaṃ kālapakvaṃ phalaṃ yathā
]

`v 57 [
vaibudhaṃ tatparityajya nabhasyeva śarīrakam |
bhūtākāśamathāsādya vasudhāyāṃ vyajāyata
]

`v 58 [
āsīdvipro daśārṇeṣu kosaleṣu mahīpatiḥ |
dhīvaro'tha mahāṭavyāṃ haṃsastripathagātaṭe
]

`v 59 [
sūryavaṃśe nṛpaḥ pauṇḍraḥ sauraśālveṣu deśikaḥ |
kalpaṃ vidyādharaḥ śrīmāndhīmānatha muneḥ sutaḥ
]

`v 60 [
pauṇḍraḥ puṇḍradeśādhipatiḥ | deśiko mantrasiddhaḥ anyeṣāmupadeṣṭā | ata
eva mantropāstiprabhāvātkalpaṃ vidyādharaḥ | atha anantaraṃ muneḥ suto jātaḥ |
59 |
madreṣvatha mahīpālastatastāpasabālakaḥ |
vāsudeva iti khyātaḥ samaṅgāyāstaṭe sthitaḥ
]

`v 61 [
anyāsvapi vicitrāsu vāsanāvaśataḥ svayam |
viṣamāsveva putraste cacārāntarayoniṣu
]

`v 62 [
abhūdvindhyanage bhūyaḥ kirātaḥ kaikaṭeṣu ca |
sauvīreṣvatha sāmantastrigarteṣu ca gardabhaḥ
]

`v 63 [
vaṃśagulmaḥ kirāteṣu hariṇaścīnajaṅgale |
sarīsṛpastālavṛkṣe tamāle vanakukkuṭaḥ
]

`v 64 [
ayaṃ sa putro bhavato bhūtvā mantravidāṃ varaḥ |
prajajāpa purā vidyāṃ vidyādharapurapradām
]

`v 65 [
tenāsāvabhavadbrahmanvyomni vidyādharo mahān |
hārakuṇḍalakeyūralīlānicayalālakaḥ
]

`v 66 [
nāyikānalinībhānuḥ puṣpacāpa ivāparaḥ |
vidyādharīṇāṃ dayito gandharvapurabhūṣaṇaḥ
]

`v 67 [
sa kalpāvadhimāsādya dvādaśādityadhāmani |
jagāma bhasmaśeṣatvaṃ śalabhaḥ pāvake yathā
]

`v 68 [
jagannirmāṇarahite sphāre nabhasi sā tataḥ |
vāsanā tasya babhrāma nirnīḍā vihagī yathā
]

`v 69 [
atha kālena saṃjāte vicitrārambhakāriṇi |
saṃsāraracanārambhe brāhme rātriviparyaye
]

`v 70 [
sā mune vāsanā tasya vātavyācalitā satī |
kṛte brāhmaṇatāmetya jāto'dya vasudhātale
]

`v 71 [
vāsudevābhidhāno'sau mune viprakumārakaḥ |
jāto matimatāṃ madhye samadhītākhilaśrutiḥ
]

`v 72 [
kalpaṃ vidyādharo bhūtvā nadyāstvatha mahāmune |
tapaścarati te putraḥ samaṅgāyāstaṭe sthitaḥ
]

`v 73 [
vividhaviṣayavāsanānuvṛttyā
khadirakarañjakarālakoṭarāsu |
jagati jaṭharayoniṣu prayāto
gahanatarāsu ca kānanasthalīṣu
]