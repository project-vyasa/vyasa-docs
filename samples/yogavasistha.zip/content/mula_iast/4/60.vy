`v 1 [
ṣaṣṭitamaḥ sargaḥ 60
śrīvasiṣṭha uvāca |
asminbhagavati brahmaṃścapalaṃ padamāśrite |
pitāmahe mahābāho kṛtasargavyavasthitau
]

`v 2 [
jagajjīrṇāraghaṭṭe'sminvahati svavyavasthayā |
vipretabhūtaghaṭayā rajjvā jīvitatṛṣṇayā
]

`v 3 [
brahmottheṣu ca bhūteṣu viśatsu bhavapañjaram |
āvarteṣvīśvaravyomabālamadhyavivartiṣu
]

`v 4 [
manaḥsvanyeṣu vātāntalolāhatakaṇeṣviva |
anārataṃ viniryānti viśantyanye tathābhitaḥ
]

`v 5 [
rāma brahmaṇi jīvaughāstaraṅgā iva vāridhau |
anādyantapadotpannāḥ kalanāpadamāgatāḥ
]

`v 6 [
bhūtākāśaṃ viśantyete dhūmaśrīriva cāmbudam |
ekatāṃ yānti jīvaughā brahmaṇyākāśamārutaiḥ
]

`v 7 [
dinaṃ tanmātravātena tatprāṇātmatayā yathā |
ākramyante pracaṇḍena daityaughenāmarā iva
]

`v 8 [
bhūtaprāṇānilaṃ tena gandhavāhena tena ca |
niviśanti śarīreṣu jīvā gacchanti vīryatām
]

`v 9 [
tato jagati jāyante bhavanti prāṇino'sphuṭāḥ |
anyā dhūmādimājātā rāma jīvaparamparā
]

`v 10 [
tanmātravati tāvadbhiraśūnye'mbarakoṭare |
udeti yāvadbhagavāninduruddāmamaṇḍalaḥ
]

`v 11 [
kṣīrāmbudhinidhau lolaiḥ pāṇḍuvadraśmibhirjagat |
tatasteṣvatiramyeṣu candraraśmiṣu saṃpatat
]

`v 12 [
karoti vihagī lolā vane preṣyāntareṣviva |
tebhyo'pi svarasenaiva yānti pīvaratāmapi
]

`v 13 [
phaleṣu teṣu badhnāti padamindukarātkṣatā |
jīvālī kṣīrapūrṇeṣu mātuḥ stanabhareṣviva
]

`v 14 [
evaṃ rasapūrṇeṣu prāguktā jīvālī indukarāt kṣatā vibhaktā satī teṣu phaleṣu
padaṃ sthitiṃ badhnāti | yathā śiśurmātuḥ stanabhareṣu padaṃ badhnāti tadvat |
13 |
tāḥ phalāvalayaḥ pakvā bhaviṣyanti marīcibhiḥ |
teṣveva vīryamāgatya tiṣṭhantyaprāptabodhitāḥ
]

`v 15 [
prasuptavāsanājālajīvatāgarbhapañjaram |
adhitiṣṭhati bījaśrīḥ suptapatrā yathā vaṭam
]

`v 16 [
yathā kāṣṭhe sthitaścāgniryathā mṛdi ghaṭā sthitāḥ |
anekakramayogena parāgatya maheśvarāt
]

`v 17 [
adṛṣṭānyaśarīraśrīḥ kramateyo na codati |
sa hi satye jātiḥ syādudāravyavahāravān
]

`v 18 [
tenaiva mokṣabhāgī cejjanmanā sa tu sāttvikaḥ |
athaitāṃ yonimāsādya kṛtyāṃ janmaparamparām
]

`v 19 [
rakṣārthaṃ prāptajanmā cettamorājasasāttvikaḥ |
pāścātyajanmanā puṃso rāma vakṣyāmi cādhunā
]

`v 20 [
prādhānyena yathā'yātaḥ saṃsāramiti sāttvikaḥ |
sa kadācinna kaścicca saṃbhavatyanaghākṛte
]

`v 21 [
saṃbhavantīha puruṣā rāma rājasasāttvikāḥ |
pravicārya samāyāta mantavyaṃ ceha taddhiyā
]

`v 22 [
prādhānyena samāyātā ye yadā paramātmanaḥ |
durlabhāḥ puruṣā rāma te mahāguṇaśālinaḥ
]

`v 23 [
ye cānye vividhā mūḍhā mūkāstāmasajātayaḥ |
teṣāṃ sthāvaratulyānāṃ kiṃca rāma vicāryate
]

`v 24 [
katipayā na gatā bhavabhāvanāṃ
narasurāḥ prakṛtakramajanmani |
ahamiva pravicāraṇayogyatā-
manugato nanu rājasasāttvikaḥ
]

`v 25 [
sthitasya te mahāpadāvicāryayaivamāyatā |
vicāraya tvamañjasā tadadya ceha na dvayam
]