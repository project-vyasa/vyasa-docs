`v 1 [
saptapañcāśaḥ sargaḥ 57
śrīrāma uvāca |
satyametattvayā brahmanyaduktaṃ sūktisundaram |
akartaiva hi kartātmā bhoktābhoktaiva bhūtakṛt
]

`v 2 [
sarveśvaraḥ sarvagaśca cinmātramamalaṃ padam |
sthānaṃ bhuvi vapurdevaḥ sarvabhūtāntarasthitaḥ
]

`v 3 [
hṛdayaṃgamatāṃ prāptamidānīṃ brahma me vibho |
tvaduktibhiryathāmbhodadhārābhirbhūbhṛdavyathaḥ
]

`v 4 [
audāsīnyādanicchatvānna bhuṅkte na karoti ca |
samagrālokakāritvādbhuṅkte devaḥ karoti ca
]

`v 5 [
kiṃtvayaṃ bhagavansphāraḥ saṃśayo me hṛdi sthitaḥ |
taṃ tvaṃ chindhi girā brahmandīdhityenduryathā tamaḥ
]

`v 6 [
idaṃ sattadidaṃ vā'sadayaṃ so'hamidaṃ natu |
ayameko dvitīyo'yamityādikalanāmayam
]

`v 7 [
ekasminvidyate'dhvānte nīhāra iva bhāskare |
idaṃ prathamamevācche kathamātmani saṃsthitam
]

`v 8 [
śrīvasiṣṭha uvāca |
siddhāntakāla evāsya saṃpraśnasyottaraṃ sthiram |
kathayiṣyāmi te rāma yena jñāsyasi tattvataḥ
]

`v 9 [
mokṣopāyasya siddhāntamasaṃprāpya na rāghava |
śrotuṃ praśnottarāṇyetānyalaṃ yogyo bhaviṣyasi
]

`v 10 [
kāntāgītagirāṃ rāma taruṇo bhājanaṃ yathā |
praśnānāmuttamoktīnāṃ puṇyakṛdbhājanaṃ tathā
]

`v 11 [
vṛthā bhavati bāleṣu yathā rāgamayī kathā |
nirarthakālpabodheṣu tathodārodayā kathā
]

`v 12 [
kasmiṃścideva samaye kiṃcitpuṃso virājate |
phalamābhāti vṛkṣasya śaradyeva na mādhave
]

`v 13 [
upadeśagiro vṛddhe rañjanā nirmale paṭe |
lagantyudāravijñānakathā cādhigatātmani
]

`v 14 [
praśnasyāsyottaraṃ pūrvaṃ leśataḥ kathitaṃ mayā |
na vistareṇa tenaitanna jñātaṃ bhavatā sphuṭam
]

`v 15 [
yadi tvamātmanātmānamadhigacchasi taṃ svayam |
etatpraśnottaraṃ sādhu jānāsyatra na saṃśayaḥ
]

`v 16 [
akhaṇḍārthabodhe jāte maduktiṃ vināpyasyottaraṃ svayameva jñāsyasītyāha ##-
mayā siddhāntakāle tu prāptabodhe tvayi sthite |
vaktavyo vistareṇaiva sādho praśnottarakramaḥ
]

`v 17 [
jānātyātmānamātmaiva kṛta ātmātmanaiva hi |
ātmaiva saṃprasannaḥ sannātmānaṃ pratipadyate
]

`v 18 [
tadetatkathitaṃ rāma kartrakartṛvicāraṇam |
ajñātatvāttu tāmetāmakṣīṇavāsano bhavet
]

`v 19 [
baddho hi vāsanābaddho mokṣaḥ syādvāsanākṣayaḥ |
vāsanāstvaṃ parityajya mokṣārthitvamapi tyaja
]

`v 20 [
tāmasīrvāsanāḥ pūrvaṃ tyaktvā viṣayavāsitāḥ |
maitryādibhāvanānāmnīṃ gṛhāṇāmalavāsanām
]

`v 21 [
tāmapyantaḥ parityajya tābhirvyavaharannapi |
antaḥśāntasamasteho bhava cinmātravāsanaḥ
]

`v 22 [
tāmapyatha parityajya manobuddhisamanvitām |
śeṣe sthirasamādhāno yena tyajasi tattyaja
]

`v 23 [
cinmayaḥ kalanākālaprakāśatimirādikam |
vāsanāṃ vāsitāraṃ ca prāṇaspandanapūrvakam
]

`v 24 [
samūlamapi saṃtyaktvā vyomasaumyapraśāntadhīḥ |
yastvaṃ bhavasi sadbuddhe sa bhavānastu satkṛtaḥ
]

`v 25 [
hṛdayātsaṃparityajya sarvameva mahāmatiḥ |
yastiṣṭhati gatavyagraḥ sa muktaḥ parameśvaraḥ
]

`v 26 [
samādhimatha karmāṇi mā karotu karotu vā |
hṛdayenāstasarvāstho mukta evottamāśayaḥ
]

`v 27 [
naiṣkarmyeṇa na tasyārtho na tasyārtho'sti karmabhiḥ |
na samādhānajāpyābhyāṃ yasya nirvāsanaṃ manaḥ
]

`v 28 [
vicāritamalaṃ śāstraṃ ciramudgrāhitaṃ mithaḥ |
saṃtyaktavāsanānmaunādṛte nāstyuttamaṃ padama
]

`v 29 [
dṛṣṭaṃ draṣṭavyamakhilaṃ bhrāntvā bhrāntvā diśo daśa |
janāḥ katipayā eva yathāvastvavalokinaḥ
]

`v 30 [
yadyadālokyate kiṃcitkaścidyattanna vidyate |
īpsitānīpsitādanyanna tatra yatate janaḥ
]

`v 31 [
ye kecana samārambhā ye janasya kriyākramāḥ |
te sarve dehamātrārthamātmārthaṃ natu kiṃcana
]

`v 32 [
pātāle brahmaloke ca svarge ca vasudhātale |
vyomni katipayā eva dṛśyante dṛṣṭadṛṣṭayaḥ
]

`v 33 [
idaṃ heyamupādeyamidamityasadutthitau |
niścayau galitau yasya jñasyāsāvatidurlabhaḥ
]

`v 34 [
karotu bhuvane rājyaṃ viśatvambhodamambu vā |
nātmalābhādṛte janturviśrāntimadhigacchati
]

`v 35 [
ye mahāmatayaḥ santaḥ śūrāścendriyaśatruṣu |
janmajvaravināśāya ta upāsyā mahādhiyaḥ
]

`v 36 [
sarvatra pañcabhūtāni ṣaṣṭhaṃ kiṃcinna vidyate |
pātāle bhūtale svarge ratimetu kva dhīradhīḥ
]

`v 37 [
yuktyā vai carato jñasya saṃsāro goṣpadākṛtiḥ |
dūrasaṃtyaktayuktestu mahāmattārṇavopamaḥ
]

`v 38 [
kadambagolakaistulyaṃ brahmāṇḍaṃ sphāracetasaḥ |
kiṃ prayacchati kiṃ bhuṅkte prāpte'sminsakalepi saḥ
]

`v 39 [
etadarthamabuddhīnāṃ yanmahāsamarakriyāḥ |
tanmanye rāma dhikkāryaṃ dvandvalaks'kṣayāvaham
]

`v 40 [
kalpamātreṇa kālena sumahāpelavodare |
tasminnapi hi yo nāśaḥ sarvādhiramahādhiyām
]

`v 41 [
ātmano jñasya sargāderyanmanāgapi nodgatam |
tasmiñjagattraye prāpte kiṃ cidātmā balī bhavet
]

`v 42 [
itaḥ śailaśatairvyāptā tatheto jalarāśibhiḥ |
kiyānasya bhuvo deho yenodāraṃ prapūrayet
]

`v 43 [
na tadasti jagatyasminsapātālasurālaye |
yannāmātmavato jñasya kiṃcitkāryataraṃ bhavet
]

`v 44 [
ekatāmanuyātasya vyomavadvitatasya ca |
svasthasyātmavato jñasya sthitasyātmanyacetasaḥ
]

`v 45 [
śarīrajālanīhāradhūsarā śūnyakoṭarā |
śāntasaṃsārasubhagā trilokīvipulātaṭī
]

`v 46 [
sphārabrahmāmalāmbhodhiphenāḥ sarve kulācalāḥ |
cidādityamahābhāsamṛgatṛṣṇājalaśriyaḥ
]

`v 47 [
ātmatattvamahāmbhodhivīcayaḥ sargarājayaḥ |
anuttamapadāmbhodavṛṣṭayaḥ śāstradṛṣṭayaḥ
]

`v 48 [
candrāgnitapanālokā ghaṭakāṣṭhādisannibhāḥ |
prakāśanīyāścidrūpatviṣo malakaṇāstathā
]

`v 49 [
viharanti svamātmānaḥ saṃsāravanacāriṇaḥ |
kāmabhogolapagrāsamṛgā narasurāsurāḥ
]

`v 50 [
asthikhaṇḍārgalāmūrdhapidhānāḥ snāyuśṛṅkhalāḥ |
jagaddehā jarajjīvaraktamāṃsasamudgakāḥ
]

`v 51 [
vanamālāmṛgā mugdhāḥ purasaṃcārasaṃsthitau `note[saṃcāpitāsthitau iti
pāṭhaḥ] |
bālabuddhivinodāya yojitāścarmaputrikāḥ
]

`v 52 [
naivaṃvidhodāramanā manāgapi mahāmatiḥ |
na jñaścalati bhogaughairmandavātairivācalaḥ
]

`v 53 [
tasminkila pade rāma jñastiṣṭhati mahottame |
yasmiṃścandrārkadeśo'pi na pātālamiva sthitaḥ
]

`v 54 [
yasyālokāllokapālāḥ samālokāḥ suvedinaḥ |
śarīraṃ pāntyayamiva paśyanmūḍhāḥ kṣapārṇave
]

`v 55 [
yasya tattvavida ālokāccitprakāśāllokapālā brahmādayaḥ samālokāḥ
sarvajagatsādhāraṇaprakāśāḥ santaścakṣurādidvārā bahirantarbuddhyā ca
suvedinaḥ samyagvyvahārocitabodhaśālinaḥ santaḥ kṣapārṇave ajñānasamudre
magnāḥ paśyanmūḍhā aśarīraṃ svātmānaṃ vivicya paśyanto'pi mūḍhāḥ
santaḥ ayamajñajana iva śarīrātmabhāvena śarīraṃ pānti rakṣanti |
dṛḍhābhyastabhogavāsanāsahakṛtādhikārikaprārabdhaprābalyādityarthaḥ | 54
|
na kecana jagadbhāvāstattvajñaṃ rañjayantyamī |
apyabhyāsagatāḥ sphārahṛdayaṃ khamivāmbudāḥ
]

`v 56 [
na kecana jagadbhāvāstattvajñaṃ rañjayantyamī |
markaṭā iva nṛtyanto gaurīlāsyārthinaṃ haram
]

`v 57 [
na kecana jagadbhāvāstattvajñaṃ rajayantyamī |
prāktanapratibimbaśrī ratnaṃ kumbhagataṃ yathā
]

`v 58 [
vajrārpitopamamasanmayamambubhaṅga-
tuṅgaṃ taraṅgakṛtabimbamivāvalokya |
lolāṃ tadīhitasukheṣu ratiṃ na yāti
tajjñaḥ kuśaivalalaveṣviva rājahaṃsaḥ
]