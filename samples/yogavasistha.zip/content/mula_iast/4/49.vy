`v 1 [
ekonapañcāśaḥ sargaḥ 49
śrīvasiṣṭha uvāca |
atha kānanamadhyasthaṃ cumbitāmbudamaṇḍalam |
madhyāhnakhinnasūryāśvasevitaskandhamaṇḍalam
]

`v 2 [
vitānamiva dikkukṣidīrghaṃ viṭapabāhubhiḥ |
ālokayantaṃ kakubho vikāsikusumekṣaṇaiḥ
]

`v 3 [
vātāvadhūlitānalpabhramadbhramarakuntalam |
pramārjayantamāśānāṃ mukhaṃ pallavapāṇibhiḥ
]

`v 4 [
kacchairuruguḍucchācchamañjarīpuñjakañjaraiḥ |
āsyairiva satāmbūlairhasantaṃ vanamālikāḥ
]

`v 5 [
latāvilasitollāsaiḥ puṣpakesaradhūlibhiḥ |
ābaddhamaṇḍalābhogaṃ pūrṇendumiva dīptibhiḥ
]

`v 6 [
saṃkaṭaṃ viṭapāvalyā kuñjakūjaccakorayā |
channayā siddhavīthyeva jagaduccatayā śritam
]

`v 7 [
skandhapīṭhopaviṣṭānāṃ lambamānaiḥ kalāpinām |
kalāpaiḥ śobhitaṃ vyoma sendracāpairivāmbudaiḥ
]

`v 8 [
magnonmagnaiḥ pratiskandhamāśritaiścamaraiḥ sitaiḥ |
pūrṇaṃ muhurdṛṣṭanaṣṭaiḥ saṃvatsaramivendubhiḥ
]

`v 9 [
kapiñjalakulālāpaiḥ kalakokilakūjitaiḥ |
jīvaṃjīvavirāvaiśca pragāyantamivocchritaiḥ
]

`v 10 [
kādambakakadambaiśca kulāyakṛtakelibhiḥ |
svargakoṭaraviśrāntaiḥ siddhairjagadivāvṛtam
]

`v 11 [
pravālacalahastābhiralinetrābhirāśritam |
apsarobhiriva svargaṃ mañjarībhiritastataḥ
]

`v 12 [
sendracāpavilāsena kumudotkarareṇunā |
mañjarīpiñjarāśyāmaṃ vidyutvantamivāmbudam
]

`v 13 [
sahasrabhujaśākhāḍhyaṃ pūritākāśakoṭaram |
viśvarūpamivonnṛttaṃ candrārkakṛtakuṇḍalam
]

`v 14 [
p. 523)
tale niṣaṇṇanāgendraṃ vyomni tārāgaṇākulam |
latāpuṣpamayaṃ madhye khamaṇḍalamivāparam
]

`v 15 [
pitāmahamivāśeṣaśailakānanaśālinam |
phalapallavapuṣpāṇāṃ kośamekamivāvanau
]

`v 16 [
pitāmahapakṣe svasṛṣṭairaśeṣaiḥ prāṇibhiḥ śailaiḥ kānanaiśca śālinaṃ
śobhamānam | kadambapakṣe aśeṣaiḥ śailasya kānanaiḥ śobhamānamityarthaḥ |
15 |
dadhānaṃ kalikājālaṃ sthagitaṃ puṣpadhūlibhiḥ |
kaccheṣvarkakaracchannatārājālamivāmbaram
]

`v 17 [
vilolavihagaiḥ skandhaiḥ kulāyakulasaṃkulaiḥ |
valitaṃ bhūtalaṃ loke pūrṇairjanapadairiva
]

`v 18 [
mañjarīsupatākāḍhyaṃ latāmaṇḍalamaṇḍitam |
puṣpamaṅkoladhavalaṃ puṣpaprakarapūritam
]

`v 19 [
kūjaccakorabhramaraśukakokilasārikam |
ghanastabakasaṃchannakuharogragavākṣakam
]

`v 20 [
saṃcaratpakṣibahulaṃ janamantharakoṭaram |
sarvāsāṃ vanadevīnāmantaḥpuramivottamam
]

`v 21 [
kūladbhṛṅgataraṅgaughaiḥ puṣpakesararājibhiḥ |
rājamānaṃ patantībhiḥ saridbhiriva parvatam
]

`v 22 [
bhramadbhiḥ puṣpapatraughairmandavātavilāsibhiḥ |
vardhamānairvṛtaskandhaṃ śubhrābhrairiva bhūdharam
]

`v 23 [
mātaṅgakaṭaghṛṣṭena jānustabdhena pīṭhinā |
ābhoginā baddhapadaṃ taruṇeva mahācalam
]

`v 24 [
vicitravarṇapakṣāṇāṃ skandhakoṭaraccariṇām |
vṛtaṃ khagānāṃ vṛndena bhūtānāmiva śārṅgiṇam
]

`v 25 [
stabakāṅgulijālena lolenābhinayakriyām |
diśantamiva vallīnāṃ pranṛttānāṃ vanānilaiḥ
]

`v 26 [
kaścideva nivāso me nārthināmiti tuṣṭitaḥ |
nṛtyantamiva bahnāḍhyalatāvalayavalganaiḥ
]

`v 27 [
latākāntaikakāntatvācchṛṅgārarasanirbharam |
kākalyeva pragāyantaṃ mattālinijaniḥsvanaiḥ
]

`v 28 [
ādaronmuktakusumaṃ siddhānāṃ vyomacāriṇām |
svāgatānīva kurvāṇaṃ kokilālikulāravaiḥ
]

`v 29 [
latāpuṣpaphalollāsaṃ prāntapañcamahīruhām |
vihasantamivācchābhiḥ puṣpakuḍmaladīptibhiḥ
]

`v 30 [
pārijātamivājetumūrdhvagaiḥ khagamaṇḍalaiḥ |
vyomāntarābhidhāvantamalamuddhatakandharam
]

`v 31 [
madhyabhāgasphurattuṅgaiḥ `note[sphuradbhṛṅgaiḥ iti pāṭhaḥ]
stabakairghanapaṅktibhiḥ |
sahasrākṣatvamatulairjetumindramivodyatam
]

`v 32 [
kvacitkusumagucchācchaphaṇāmaṇigaṇāvṛtam |
pātālādutthitaṃ śeṣamiva vyomadidṛkṣayā
]

`v 33 [
rajasoddhūlitākāraṃ dvitīyamiva śaṃkaram |
chāyayā phalaśālinyā samastajanaśaṃkaram
]

`v 34 [
bhagavāṃstu bhaktānāmeva śaṃkaraḥ ayaṃ tu samastajanaśaṃkara ityatiśayaḥ |
33 |
nibiḍadalanivāhabhinnakośaiḥ
kusumalatānavamaṇḍapairupetam |
puramiva gagane kadambavṛkṣaṃ
khagakulanāgarasaṃkulaṃ dadarśa
]