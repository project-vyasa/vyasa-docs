`v 1 [
navamaḥ sargaḥ 9
śrīvasiṣṭha uvāca |
iti cintayatastasya śukrasya pituragrataḥ |
jagāmātitarāṃ kālo bahusaṃvatsarātmakaḥ
]

`v 2 [
atha kālena mahatā pavanātapajarjaraḥ |
kāyastasya papātorvyāṃ chinnamūla iva drumaḥ
]

`v 3 [
manastu cañcalābhogaṃ tāsu tāsu daśāsu ca |
babhrāmātivicitrāsu vanarājiṣvivaiṇakaḥ
]

`v 4 [
bhrāntamudbhrāntamabhitaścakrārpitamivākulam |
manastasya viśaśrāma samaṅgāsaritastaṭe
]

`v 5 [
anantavṛttāntaghanāṃ pelavāṃ sudṛḍhāmapi |
tāṃ saṃsṛtidaśāṃ śukro videho'nubhavansthitaḥ
]

`v 6 [
mandarācalasānusthā sā tanustasya dhīmataḥ |
tāpaprasarasaṃśuṣkā carmaśeṣā babhūva ha
]

`v 7 [
śarīrarandhrapravahadvātasītkārarūpayā |
ceṣṭā duḥkhakṣayānandātkākalyeva pragāyati
]

`v 8 [
manovarākamavaṭe luṭhitaṃ bhavabhūmiṣu |
hasatīveti śubhrābhrasitayā dantamālayā
]

`v 9 [
darśayantī jagacchūnyaṃ vapurakṣṇorakṛtrimam |
mukhāraṇyajaratkūparūpayā gartaśobhayā
]

`v 10 [
tāpopataptā saṃsiktā varṣājalabhareṇa sā |
prāganusmaraṇollāsamiva vāṣpaṃ vimuñcati
]

`v 11 [
candrānilavilāsena lulitā vanabhūmiṣu |
dhārānikarapātena vinunnā jaladāgame
]

`v 12 [
prāvṛṇnirjhararūpeṇa plutā girinadītaṭe |
pāṃśunā pavanotthena duṣkṛteneva rūṣitā
]

`v 13 [
śuṣkakāṣṭhavadālolā vāteṣu kṛtakhākṛtiḥ |
tāramārutasītkāre vane tapa ivāsthitā
]

`v 14 [
vakrā śuṣkāntratantrī ca bhūtabhāṅkārakāriṇī |
araṇyalakṣmīrbālyeva śūnyā carmamayodarī
]

`v 15 [
rāgadveṣavihīnatvāttasya puṇyāśramasya tu |
mahātapastvācca bhṛgorna bhuktā mṛgapakṣibhiḥ
]

`v 16 [
yamaniyamakṛśīkṛtāṅgayaṣṭi-
ścarati tapaḥ sma bhṛgūdvahasya cetaḥ |
tanuratha pavanāpanītaraktā
ciramaluṭhanmahatīṣu sā śilāsu
]