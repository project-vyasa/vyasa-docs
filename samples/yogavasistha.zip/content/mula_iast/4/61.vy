`v 1 [
ekaṣaṣṭitamaḥ sargaḥ 61
śrīvasiṣṭha uvāca |
ye hi rājasasāttvikyā jātā bhuvi mahāguṇāḥ |
te nityameva muditāḥ prakāśāḥ sva ivendavaḥ
]

`v 2 [
na khedamabhigacchanti vyomabhāgo malaṃ yathā |
nāpadā mlānimāyānti niśi hemāmbujaṃ yathā
]

`v 3 [
nehante prakṛtādanyatte nānyatsthāvaro yathā |
ramante svasadācāraiḥ svārthebhyaḥ pādapā yathā
]

`v 4 [
nityamāpūryatāṃ yāti sudhāyāmindusundarī |
rāma rājasasattvasya mokṣamāyātyasau yathā
]

`v 5 [
āpadyapi na muñcanti śaśivacchītatāmiva |
prakṛtyaiva virājante maitryādiguṇakāntayā
]

`v 6 [
navastabakabhāvinyā latayeva vanadrumāḥ |
samāḥ samarasāḥ saumyāḥ satataṃ sādhusādhavaḥ
]

`v 7 [
abdhivaddhṛtamaryādā bhavanti bhavatā samāḥ |
atasteṣāṃ mahābāho padamāpadavāsanam
]

`v 8 [
satataṃ tattu gantavyaṃ gantavyaṃ nāpadarṇave |
tathā tatheha jagati vihartavyamakhedinā
]

`v 9 [
ātmodayāśca vardhante yathā'rājasasāttvikāḥ |
acintyagatyā sacchāstraṃ vicāryaṃ ca punaḥpunaḥ
]

`v 10 [
anityatā svamanasā vividhaivāśu bhāvataḥ |
ādāvante ca yāṃ nityaṃ kriyāṃ trailokyavartinīm
]

`v 11 [
padārthānāpadevāśu bhāvayennetaratsudhīḥ |
asamyagdarśanaṃ tyaktvā vyarthamajñānasaṃtatim
]

`v 12 [
smartavyaṃ samyagevedaṃ jñānamarthamanantakam |
ko'haṃ kathamidaṃ jātaṃ saṃsārāḍambaraṃ vibho
]

`v 13 [
pravicārya prayatnena prājñena saha sādhubhiḥ |
naca karmasu maṅktavyaṃ nānarthena sahāvaset
]

`v 14 [
draṣṭavyaḥ sarvavicchedaḥ saṃsārānugataḥ sadā |
sādhurevānugantavyo mayūreṇāmbudo yathā
]

`v 15 [
ahaṃkārasya dehasya saṃsārasyāplavasya ca |
svavicāramalaṃkṛtya satyamevāvalokayet
]

`v 16 [
śarīramasthiramapi saṃtyaktvā ghanaśobhanam |
vītamuktāvalītantuṃ cinmātramavalokayet
]

`v 17 [
tasminpade nityatate sarvage sarvabhāvite |
śive sarvamidaṃ protaṃ sūtre maṇigaṇā yathā
]

`v 18 [
yaiva cidbhuvanābhoge bhūṣaṇe vyomni bhāskare |
dharāvivarakośasthe saiva citkīṭakodare
]

`v 19 [
kumbhavyomnāṃ na bhedo'sti yatheha paramārthataḥ |
citau śarīrasaṃsthānāṃ na bhedo'sti tathānagha
]

`v 20 [
sarveṣāmeva bhūtānāṃ tiktakaṭvādimedinām `note[kaṭvādivedināṃ iti
pāṭhaḥ] |
ekatvādanubhūterhi kutaścinmātrabhinnatā
]

`v 21 [
ekasinneva satataṃ sthite sanmātravastuni |
jāto'yamayamunnaṣṭa iti teṣāṃ taveha dhīḥ
]

`v 22 [
naca tannāma vastvasti yadbhūtvā saṃpralīyate |
ābhāsamātramevedaṃ na sannāsacca rāghava
]

`v 23 [
udbhūtenāpraśāntena cetasā sapadi sthitam |
neha mohānta āmokṣānnedaṃ yattadavastu ca
]

`v 24 [
kiṃ kilāsati rāmeha mohajāle samujjhati |
yatkiṃcitsaṅgasaṅgatyā vimohe kāraṇaṃ hi tat
]