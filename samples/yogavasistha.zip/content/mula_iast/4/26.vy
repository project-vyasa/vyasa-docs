`v 1 [
ṣaḍviṃśaḥ sargaḥ 26
śrīvasiṣṭha uvāca |
iti nirṇīya daityendro dāmavyālakaṭānvitām |
senāṃ saṃpreṣayāmāsa bhūtalaṃ devanāśinīm
]

`v 2 [
daityāḥ sāgarakuñjebhyaḥ kandarebhyaśca sāyudhāḥ |
udagurbhīmanirhrādāḥ sapakṣagirilīlayā
]

`v 3 [
rodasīkoṭaraṃ hastaprahārahatabhāskaram |
dānavāḥ pūrayāmāsurdāmavyālakaṭaidhitāḥ
]

`v 4 [
athottasthurnikuñjebhyaḥ kandarebhyaḥ surācalāt |
pralayānta ivākṣubdhā bhīmāḥ svarvāsināṃ gaṇāḥ
]

`v 5 [
devāsurapatākinyostadyuddhamabhavattayoḥ |
akālolbaṇakalpāntabhīṣaṇaṃ bhuvanāntare
]

`v 6 [
petuḥ pralayaparyastacandrārkā iva dīptayaḥ |
śirāṃsi kuṇḍaloddyotatejaḥpītatamāṃsyatha
]

`v 7 [
jughūrṇurbhaṭanirmuktasiṃhanādavirāvitāḥ |
pralayānilasaṃpūraiḥ sphuṭahāsā ivādrayaḥ
]

`v 8 [
reṇuḥ śailaśilātulyahetighātāstabhittayaḥ |
kulācalataṭābhīruviśrāntaharimaṇḍalāḥ
]

`v 9 [
ceruḥ parasparāghātahatahetisamutthitāḥ |
lolānalakaṇāḥ kalpaviśīrṇā iva tārakāḥ
]

`v 10 [
vilesū raktamāṃsaughapūrṇaikārṇavatīragāḥ |
kalpatālavaduttālā vetālāstālatālitāḥ
]

`v 11 [
prasphuradrudhirāsāraśāntapāṃsupayodhare |
vyomni hetihatakṣuṇṇā maulikuṇḍalakoṭayaḥ
]

`v 12 [
babhūvurbhāskarākāraiḥ kalpabhūruhadhāribhiḥ |
prahāradalitādrīndrairdaityairnirvivarā diśaḥ
]

`v 13 [
jagmurjvaladasiprāntavātapātitabhittayaḥ |
kaṇaprakaratāṃ śailāḥ kalpāgnidalitā iva
]

`v 14 [
devāste ca samājagmuraśvamedhaidhitā iva |
asurānastravibhraṣṭāñjaladāniva vāyavaḥ
]

`v 15 [
jagṛhustānathākramya jaraṭhākhūnivautavaḥ |
te'pi tāñjagṛhurmattānṛkṣārūḍhāniva drumān
]

`v 16 [
dorvṛkṣavilasaddhetikusumāḥ śastrapallavāḥ |
rejuḥ surāsurāḥ phullā vanalolā iva drumāḥ
]

`v 17 [
anyonyaṃ pūrayāmāsuḥ śastrapūrairdiśo daśa |
vanāni kusumavrātaiḥ sumerāviva mārutaḥ
]

`v 18 [
ghoraṃ samabhavadyuddhaṃ devadānava senayoḥ |
rodorandhrodumbarāntarmahāmaśakasaṃghayoḥ
]

`v 19 [
athodapataduttālairlokapālebhamaṇḍalaiḥ |
kalpābhrasphūrjitākāro dāruṇaḥ samarāravaḥ
]

`v 20 [
piṇḍagraheṇa nabhasi bhūbhāgamiva kuṭṭimam |
muṣṭigrāhyo mahāmeghamantharodarapīvaraḥ
]

`v 21 [
rathasaṃpātasaṃpiṣṭaśastraśailaraṭannaṭaḥ |
truṭaddhṛdayaniḥsattvakarkaśākrandaghargharaḥ
]

`v 22 [
pralayapratyayollāsikalpāntārāvabṛṃhaṇaḥ |
dvādaśādityasaṃghaṭṭadravatkāñcanaparvataḥ
]

`v 23 [
pralayasya pratyayaiḥ kāraṇairagnivāyvādibhirullāsī yaḥ kalpasya brahmāhṇo'nte
prasiddha ārāvastasya bṛṃhaṇaḥ pratigarjanaprāyaḥ | dvādaśādityānāṃ
saṃghaṭṭanena melanena dravan yaḥ kāñcanaparvatastadīyaśabda ivetyarthaḥ | 22
|
brahmāṇḍakuṇḍasaṃghaṭṭātparāvṛttyā ca nirgataḥ |
mahāsrotaḥpayaḥpūraḥ sattvāhata ivākaraḥ
]

`v 24 [
cañcatsapakṣaśailendrapakṣapātacaladdhvaniḥ |
kaṭhināpūraṇoddhūtasphuṭacchailendrakandaraḥ
]

`v 25 [
mandaroddhūtadugdhābdhisaṃkṣobhasadṛśāṅgakaḥ |
ratiśruddhuṃghumāsphoṭaghaṭitadvīpajantubhūḥ
]

`v 26 [
senayoḥ kṣubdhayorāsīdyuddhamuddhatadānavam |
niṣpiṣṭanagaragrāmagirikānanamānavam
]

`v 27 [
mahāhetiśatacchinnadānavācalapūrṇadik |
anyonyāhatahetyādicūrṇapūrṇāmbarodaram
]

`v 28 [
bhuśuṇḍīmaṇḍalāsphoṭasphuṭanmeruśiraḥśatam |
śaramārutanirlūnadaityadevamukhāmbujam
]

`v 29 [
cakrāvartaśatabhrāntadevadaityajarattṛṇam |
senāprahārakallolavalanāvalitāmbaram
]

`v 30 [
hetyugravātaniṣpiṣṭapatadvaimānikavrajam |
astroditābdhivāryoghaplāvitavyomapattanam
]

`v 31 [
vahanmahāstrapātāsiśūlaśaktinadīśatam |
śailapakṣodbhaṭāsphoṭaluṭhadbrahmāṇḍamaṇḍapam
]

`v 32 [
daityapārṣṇiprahāraughapatallokeśapattanam |
nārīhalahalārāvaraṇatkaṅkaṇamandiram
]

`v 33 [
luṭhaddaityabalodbhūtamattāsraughajalānvitam `note[baloddhūta iti
pāṭhaḥ] |
raktadhautanaraughogramuktanādadravajjanam
]

`v 34 [
lokapānīkapāmbhojacchannācchannayamānvitam |
punaḥ surāsurairghātairdṛṣṭasainyakulākulam
]

`v 35 [
sapakṣaparvatākāradānavādrigamāgamaiḥ |
vahacchavaśavāśabdabhūribhāṅkārabhīṣaṇam
]

`v 36 [
āyudhāgravibhinnogradaityaparvatanirjharaiḥ |
raktairaruṇitāśeṣavasudhārṇavaparvatam
]

`v 37 [
utsannarāṣṭranagaravipinagrāmagahvaram |
dhṛtāsaṃkhyāsurebhāśvamanuṣyaśavaparvatam
]

`v 38 [
sutālottālanārācarājirocitavāraṇam |
muṣṭiprahārapiṣṭāṃsamattairāvaṇavāraṇam
]

`v 39 [
kalpābhrapaṭalāsāradhārādalitaparvatam |
mahāśaniviniṣpeṣapiṣṭoḍḍīnakulācalam
]

`v 40 [
kupitāgnijvalajjvālājālajvalitadānavam |
ekāñjalipuṭānītasamudrotsāditānalam
]

`v 41 [
caṇḍadaityātisaṃbhāraśilīkṛtamahājvalam |
vanavyūhendhanāgnyarcirdrāvitāmbuśiloccayam
]

`v 42 [
astranirmitadurvāratamaḥkalpāntarātrikam |
māyāsūryagaṇoddyotaiḥ pītātanutamaḥpaṭam
]

`v 43 [
māyāgnivarṣaniṣpītakalābhraghanavarṣaṇam |
sasītkārāgnivamanaśastrasaṃghaṭṭavarṣaṇam
]

`v 44 [
vajravarṣāstranirdhūtaśailavarṣāstrasaṃbhramam |
nidrābodhāstrayuddhāḍhyaṃ saṃgharṣāvagrahāśrayam
]

`v 45 [
vahatkrakacavṛkṣāstraṃ jalāgnyasmaraṇānvitam |
brahmāstrayuddhaviṣamaṃ tamastejostrasāritam
]

`v 46 [
astrodgīrṇāyudhānīkanīrandhrasakalāmbaram |
śilāvarṣāstradalitaṃ vahnivarṣāstrabhāsuram
]

`v 47 [
patākāspṛṣṭaśaśikaścakracītkāragarjitaiḥ |
muhūrtena rathairlaṅghitodayāstamayācalam
]

`v 48 [
vajraprahārāviratamriyamāṇamahāsuram |
śukrāmaramahāvidyājīvamānamahāsuram
]

`v 49 [
vidravaddevasaṃghātaṃ jayaproḍḍāmarāmaram |
śubhagrahamahāketumālikānāmitastataḥ
]

`v 50 [
utpātamaṅgalughānāṃ buddheruddharakandharam |
sādrikhorvīsamudradyujagadrudhiravāridhi
]

`v 51 [
phullaikakiṃśukavanaṃ kurvaddurvāravairataḥ |
parvatapratimāsaṃkhyaṃ śavapūrṇamahārṇavam
]

`v 52 [
jagadityanuvartate | kurvaditi pūrvottarārdhānvayi | ubhayatrāpi rudhireṇeti śeṣaḥ |
51 |
samagrataruśākhāgralambalolamahāśavam |
dīpyamānaiḥ svavātārtaiḥ pakṣapuṣpairlasatphalaiḥ
]

`v 53 [
tālottālaiḥ śaravrātavanairvyāptanabhasthalam |
parvatapratimāsaṃkhyakabandhaśatabāhubhiḥ
]

`v 54 [
nṛtyadbhiḥ pātitāmbhodavimānasuratārakam |
śaraśaktigadāprāsapaṭṭiśaprotaparvatam
]

`v 55 [
lokasaptakavibhraṣṭakuḍyakhaṇḍacitāmbaram |
anāratarasanmattakalpābhradṛḍhadundubhi
]

`v 56 [
evaṃ śabdaśatonnādapātālatalavāraṇam |
vināyakakarākṛṣṭadīrghadānavaparvatam
]

`v 57 [
ekadikkaraniṣpandasiddhasādhyamarudgaṇam |
palāyamānagandharvakinnarāmaracāraṇam
]

`v 58 [
vaburaśaninipātakhaṇḍitāṅgā
dalitaśilāśakalāḥ kakummukheṣu |
pralayasamayasūcakāḥ surāṇāṃ
suratarughargharaghasmarāḥ samīrāḥ
]