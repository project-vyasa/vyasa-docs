`v 1 [
saptacatvāriṃśaḥ sargaḥ 47
śrīrāma uvāca |
bhagavansarvadharmajña sarvavedāṅgapāraga `note[vedavedāṅgapāraga iti
pāṭhaḥ] |
āśvasta iva tiṣṭhāmi śuddhābhirbhavaduktibhiḥ
]

`v 2 [
udārāṇi viviktāni peśalānyuditāni ca |
śrotuṃ tṛptiṃ na gacchāmi vacāṃsi vadatastava
]

`v 3 [
jātyā rājasasāttvikyāḥ kathanāvasarāntare |
utpattirbhavatā proktā śāstraiḥ kamalajanmanaḥ
]

`v 4 [
śrīvasiṣṭha uvāca |
bahūni brahmalakṣāṇi śaṃkarendraśatāni ca |
nārāyaṇasahasrāṇi samatītāni rāghava
]

`v 5 [
anyeṣu ca vicitreṣu brahmāṇḍeṣu ca bhūriśaḥ |
nānācāravihārāṇi viharanti sahasraśaḥ
]

`v 6 [
tulyakālamananteṣu kālāntarabhaveṣu ca |
jagatsu prodbhaviṣyanti bahūnyanyāni bhūriśaḥ
]

`v 7 [
teṣāmabjodbhavādīnāṃ brahmāṇḍeṣu divaukasām |
utpattayo mahābāho vicitrābhyutthitā iva
]

`v 8 [
kacācitsṛṣṭayaḥ śārvyaḥ kadācitpadmajodbhavāḥ |
kadācidapi vaiṣṇavyaḥ kadācinmuninirmitāḥ
]

`v 9 [
kadācitpadmajo brahmā kadācitsalilodbhavaḥ |
aṇḍodbhavaḥ kadācittu kadācijjāyate'mbarāt
]

`v 10 [
kasmiṃścidaṇḍe tryakṣo'rkaḥ kasmiṃścidapi vāsavaḥ |
kasmiṃścitpuṇḍarīkākṣaḥ kasmiṃścittryakṣa eva hi
]

`v 11 [
kasyāṃcidbhūrabhūtsṛṣṭau nīrandhratarusaṃkaṭā |
kasyāṃcinnaranīrandhrā kasyāṃcidbhūdharāvṛtā
]

`v 12 [
bhūrabhūnmṛnmayī kācitkācidāsīddṛṣanmayī |
āsīddhemamayī kācitkācittāmramayī tathā
]

`v 13 [
ihaiva kāni citrāṇi jagantyanyānyathānyathā |
anyānyekaikalokāni nirmahāṃsyāpi kānicit
]

`v 14 [
anantāni jagantyasminbrahmatattvamahāmbare |
ambhodhivīcijalavannimajjantyudbhavanti ca
]

`v 15 [
yathā taraṅgā jaladhau mṛgatṛṣṇā marau yathā |
kusumāni yathā cūte tathā viśvaśriyaḥ pare
]

`v 16 [
bhānorgaṇayituṃ śakyā raśmiṣu trasareṇavaḥ |
ālolavapuṣo brahma tattvena jagatāṃ gaṇāḥ
]

`v 17 [
yathā maśakajālāni varṣādiṣvākulāni tu |
utpattyotpattya naśyanti tathemā lokasṛṣṭayaḥ
]

`v 18 [
naca vijñāyate kasmātkālātprabhṛti cāgatāḥ |
nityāgamāpāyaparā etāḥ sargaparamparāḥ
]

`v 19 [
anādimatyo'virataṃ prasphuranti taraṅgavat |
pūrvātpūrvaṃ kilābhūvaṃstataḥ pūrvataraṃ yathā
]

`v 20 [
bhūtvā bhūtvā pralīyante sasurāsuramānavāḥ |
sarittaraṅgabhaṅgyaiva samastā bhūtajātayaḥ
]

`v 21 [
yathedamaṇḍaṃ vairiñcaṃ tathā brahmāṇḍapaṅktayaḥ |
yāḥ sahasrāḥ parikṣīṇā nāḍikā vatsareṣviva
]

`v 22 [
anyāḥ saṃprati vidyante vartamānaśarīrakāḥ |
prānte brahmapurasyāsya vitate brahmaṇaḥ pade
]

`v 23 [
brahmaṇyanyā bhaviṣyanti brāhyo brahmapuraśriyaḥ |
punastāśca vinaṅkṣyanti bhūtvā bhūtvā yathā giraḥ
]

`v 24 [
brahmaṇyanyā bhaviṣyantyaḥ sthitāḥ sargaparamparāḥ |
ghaṭā iva mṛdo rāśāvaṅkure pallavā iva
]

`v 25 [
yāvadbrahma cidākāśe tathā tribhuvanaśriyaḥ |
sphārākāravikārāḍhyāḥ prekṣyamāṇā na kiṃcana
]

`v 26 [
unmajjantyo nimajjantyo na satyā nāpyasacchriyaḥ |
jaḍārambhā vitanvantyastā eva khalatā iva
]

`v 27 [
taraṅgasamadharmiṇyo dṛṣṭanaṣṭaśarīrakāḥ |
sarvāsāṃ sṛṣṭirāśīnāṃ citrākāraviceṣṭitāḥ
]

`v 28 [
citrākāravikārāśca citrarūpā hi sṛṣṭayaḥ |
vyatiriktā na sarveṣāṃ samastāḥ sṛṣṭidṛṣṭayaḥ
]

`v 29 [
tattvajñaviṣaye rāma salilādiva vṛṣṭayaḥ |
āyānti sṛṣṭayo devājjaladādiva vṛṣṭayaḥ
]

`v 30 [
vyatiriktā na sarveṣāṃ samastāḥ sṛṣṭidṛṣṭayaḥ |
vyatiriktā dravāmbhodhisvāṣṭhīlāḥ śālmaleriva
]

`v 31 [
iha sṛṣṭiṣu puṣṭāsu nikṛṣṭāsu ca rāghava |
paramānnabhaso jātāstanmātramalamālikā
]

`v 32 [
kadācitprathamaṃ vyoma patiṣṭhāmadhigacchati |
tataḥ prajāyate brahmā vyomajo'sau prajāpatiḥ
]

`v 33 [
kadācitpadmajo brahmeti yaduktaṃ tatra yathāyogaṃ
pañcīkaraṇottarabhāvisthūlavyomādīnāṃ prathamāvirbhāvakramo niyāmaka
ityāha - kadācidityādinā | pratiṣṭhāṃ sthūlībhāvena sthitim | evaṃ sarvatra |
32 |
kadācitprathamaṃ vāyuḥ pratiṣṭhāmadhigacchati |
tataḥ prajāyate brahmā vāyujo'sau prajāpatiḥ
]

`v 34 [
kadācitprathamaṃ tejaḥ pratiṣṭhāmadhigacchati |
tataḥ prajāyate kartā tejaso'sau prajāpatiḥ
]

`v 35 [
kadācitprathamaṃ vāri pratiṣṭhāmadhigacchati |
tataḥ prajāyate brahmā vārijo'sau prajāpatiḥ
]

`v 36 [
kadācitprathamaṃ pṛthvī sphāratāmadhigacchati |
tataḥ prajāyate brahmā pārthivo'sau prajāpatiḥ
]

`v 37 [
idaṃ catvāri saṃpīḍya pañcamaṃ vardhate yadā |
tadā tajjāta evaiṣa kurute jāgatīṃ kriyām
]

`v 38 [
kadācidapsu vāyau vā susphāre vāpi tejasi |
svayaṃ saṃpadyate'kasmātpumānprakṛtibhāvitaḥ
]

`v 39 [
tasyātha śabdo vadanātkadācijjāyate padāt |
kadācidaṃśātpṛṣṭhādvā kadācillocanātkarāt
]

`v 40 [
kadācitpuruṣasyāsya nābhau padmaṃ prajāyate |
tasminsaṃvardhate brahmā padmajo'sau prakīrtitaḥ
]

`v 41 [
māyeyaṃ svapnavadbhrāntirmithyāracitacakrikā |
manorājyamivālolasalilāvartasundarī
]

`v 42 [
satastata eva tasya kathaṃ janma ghaṭatāmiti paryanujuñjānaṃ rāmaṃ pratyāha ##-
kimivāsyāṃ vada jñaptau kathaṃ saṃbhavatīha te |
kvacidbālamanorājyamidaṃ paryanuyujyate
]

`v 43 [
kadācidambare śuddhe manastattvānurañjanāt |
sauvarṇaṃ brahmagarbhaṃ ca svayamaṇḍaṃ pravartate
]

`v 44 [
kadācideva `note[eṣa iti pāṭhaḥ] puruṣo vīryaṃ sṛjati vāriṇi |
tasmātprajāyate padmaṃ brahmāṇḍamathavā mahat
]

`v 45 [
tasmātprajāyate brahmā kadācidbhāskaro'pyasau |
kadācidvaruṇo brahmā kadācidvāyuraṇḍajaḥ
]

`v 46 [
evamantarvihīnāsu vicitrāsviha sṛṣṭiṣu |
vicitrotpattayo rāma brahmaṇo vividhā gatāḥ
]

`v 47 [
nidarśanārthaṃ sṛṣṭestu mayaikasya prajāpateḥ |
bhavate kathitotpattirna tatra niyamaḥ kvacit
]

`v 48 [
manovijṛmbhaṇamidaṃ saṃsāra iti saṃmatam |
saṃbodhanāya bhavataḥ sṛṣṭikrama udāhṛtaḥ
]

`v 49 [
sāttvikīprabhṛtayo yāśca jātayaścetthamāgatāḥ |
iti te kathanāyaiṣa sṛṣṭikrama udāhṛtaḥ
]

`v 50 [
punaḥ sṛṣṭiḥ punarnāśaḥ punarduḥkhaṃ punaḥ sukham |
punarajñaḥ punastajjño bandhamokṣadṛśaḥ punaḥ
]

`v 51 [
punaḥ sṛṣṭikarā'vītavītasnehadṛśaḥ punaḥ |
dīpā iva kṛtālokāḥ praśāmyantyudbhavanti ca
]

`v 52 [
dehotpattau vināśe ca dīpānāṃ brahmaṇāmapi |
kālenādhikatāṃ tyaktvā nāśe bhedo na kaścana
]

`v 53 [
punaḥ kṛtaṃ punastretā punaḥ sa dvāparaḥ kaliḥ |
punarāvartate sarvaṃ cakrāvartatayā jagat
]

`v 54 [
punarmanvantarārambhāḥ punaḥ kalpaparamparāḥ |
punaḥ punaḥ kāryadaśāḥ prātaḥ prātaraho yathā
]

`v 55 [
lokālokakalākālakalanākalitāntaram |
punaḥpunaridaṃ sarvaṃ na kiṃcana punaḥpunaḥ
]

`v 56 [
anāhate pratapte'yaḥpiṇḍe'nalakaṇā iva |
ime bhāvāḥ sthitā nityaṃ cidākāśe svabhāvataḥ
]

`v 57 [
kadācidanabhivyaktaṃ kadācidvyaktimāgatam |
idamasti pare tattve sarvaṃ vṛkṣa ivārtavam
]

`v 58 [
citspanda eva sarvātmā sarvadaivedṛśākṛtiḥ |
yadasmājjāyate sargo dvindutvamiva locanāt
]

`v 59 [
citaḥ sarvāḥ samāyānti saṃtatāḥ sṛṣṭidṛṣṭayaḥ |
tatsthā evāpyatatsthābhāścandrādiva marīcayaḥ
]

`v 60 [
na kadācana saṃsāraḥ kilāyaṃ rāma satsadā |
sarvaśaktāvasaṃsāraśaktitā vidyate yataḥ
]

`v 61 [
na caivedaṃ kadācittu sādho jagadanīdṛśam |
sarvaśaktau hi saṃsāraśaktitā vidyate yataḥ
]

`v 62 [
mahākalpāvadhiḥ kālena saṃsāritayeddhayā |
na bhaviṣyati saṃsāra idānīmiti yujyate
]

`v 63 [
jñadṛṣṭyā sarvamevedaṃ brahmaiveti mahāmate |
nāsti saṃsāra ityetadupapadyata eva ca
]

`v 64 [
ajñadṛṣṭyā tvavicchinnasaṃsāratvādanāratam |
nityā saṃsāramāyeyaṃ mithyāpīhopapadyate
]

`v 65 [
punaḥpunaśca bhāvitvānna kadācidanīdṛśam |
jagadityetadityuktaṃ na mṛṣā raghunandana
]

`v 66 [
anāratapatadrūpā diśo dṛṣṭā vinaśvarāḥ |
vināśīdaṃ jagatsarvamiti kiṃ nopapadyate
]

`v 67 [
sarvatroditacandrārkā diśo dṛṣṭāḥ sthirācalāḥ |
avināśi jagatsarvamityapyavitathopamam
]

`v 68 [
na tadasti na yattasminnekasminvitatātmani |
saṃkalpakalanājālamanākhye nopapadyate
]

`v 69 [
punaḥpunaridaṃ sarvaṃ punarmaraṇajanmanī |
punaḥ sukhaṃ punarduḥkhaṃ punaḥ karaṇakarmaṇī
]

`v 70 [
punarāśāḥ punarvyoma punarambhodhayo'drayaḥ |
abhyudeti punaḥ sṛṣṭiḥ khavadarkaprabhā yathā
]

`v 71 [
punardaityāḥ punardevāḥ punarlokāntarakramāḥ |
punaḥ svargāpavargehāḥ punarindraḥ punaḥ śaśī
]

`v 72 [
punarnārāyaṇo devaḥ punardanusutādayaḥ |
punarāśācalaccārucandrārkavaruṇānilāḥ `note[āśāścalat iti pāṭhaḥ]
]

`v 73 [
sumerukarṇikākāntā sahyakesaraśālinī |
pūrṇā sphītodarodeti rodasī nalinī punaḥ
]

`v 74 [
vyomakānanamākramya valgatyaṃśunakhotkaraiḥ |
tamaḥkarighaṭā bhettuṃ punarbhāskarakesarī
]

`v 75 [
punarinduścalatsvacchamañjarīsundaraiḥ karaiḥ |
karotyamṛtamāhlādi digvadhūmukhamaṇḍanam
]

`v 76 [
punaḥ svargataroḥ puṇyakṣayavātasamīritāḥ |
patantīha vinunnāṅgāḥ puṇyakṛtpuṣparāśayaḥ
]

`v 77 [
punaḥ kāryakriyāpakṣaiḥ saṃsārārambhanāmakam |
kiṃcitpaṭapaṭaṃ kṛtvā yāti kālakapiñjalaḥ
]

`v 78 [
punarindrādike yāte sajjamāsthāya kevalam |
āyātyaparadevendraṣaṭpadaḥ svargapaṅkajam
]

`v 79 [
punaḥ kālaṃ kṛtāpūtaṃ `note[kṛpāpūtaṃ iti kvacit] kaluṣīkurute
kaliḥ |
sacakriṇamivāmbhodhiṃ pravṛddho'vakarānilaḥ
]

`v 80 [
kṛtena yugena āpūtaṃ sarvataḥ pūtam | kaliradharmaḥ | sacakriṇaṃ
svāntaḥśayānaviṣṇusahitam | avakirati pāṃsūnityavakaro'nilaḥ pralayavāyuḥ | 79
|
punaḥ kālakulālena kṛtabhūtaśarāvakam |
cakramāvartyate vegādajasraṃ kalpanāmakam
]

`v 81 [
punarnīrasatāmeti jagadastaśubhasthiti |
abhyāsībhūtasaṃkalpaṃ saṃśuṣkamiva kānanam
]

`v 82 [
punararkagaṇeṣvagnidagdhānantakalevaram |
sarvabhūtāsthisaṃpūrṇaṃ jagadeti śmaśānatām
]

`v 83 [
punaḥ kulācalākārapuṣkarāvartavarṣaṇaiḥ |
nṛtyadbhavavṛhatphenāṃ yātyekārṇavatāṃ jagat
]

`v 84 [
punaḥ saṃśāntavāyvamburiktaṃ sakalavastubhiḥ |
tadapūrvamivākāśaṃ jagadāyāti śūnyatām
]

`v 85 [
punaḥ katipayā bhuktvā samāḥ samarasāśayaḥ |
jīvitaṃ jīrṇayā tanvā punaḥ svātmani līyate
]

`v 86 [
punaranyena kālena tathaiva jagatāṃ gaṇān |
manastanoti vai śūnye gandharvanagaraṃ yathā
]

`v 87 [
punaḥ sarmasamārambhaḥ pralaye sarvasaṃbhavaḥ |
sarvaṃ punaridaṃ rāma cakravatparivartate
]

`v 88 [
punaḥ pralaye sati sargasamārambhaḥ `note[sarvasamāraṃbhaḥ iti pāṭhaḥ] | 87
|
kimetasminmahāmāyāḍambare dīrghaśambare |
rāma satyamasatyaṃ vā nirṇeyaṃ yadihocyate
]

`v 89 [
dāśūrākhyāyikeveyaṃ rāma saṃsāracakrikā |
kalpanāracitākārā vastuśūnyā na vastutaḥ
]

`v 90 [
aviralamidamātataṃ vikalpai-
rasaduditairapi tairdvicandrakalpaiḥ |
viracitamasatānupannasatyaṃ
jagadiha tena vimūḍhatā kimutthā
]