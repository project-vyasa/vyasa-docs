`v 1 [
tripañcāśaḥ sargaḥ 53
śrīvasiṣṭha uvāca |
athāpṛcchatsutastatra jambūdvīpe mahāniśi |
kadambāgrāvacūḍasthaṃ pitaraṃ pāvanāśayam
]

`v 2 [
putra uvāca |
ko'sau khottha iti khyāto bhūpastātottamākṛtiḥ |
kathitaṃ ca kimetanme tvayeti brūhi tattvataḥ
]

`v 3 [
kva bhaviṣyati nirmāṇaṃ vartamāne kva gamyatā |
ubhayārthaviruddhatvānmanmohāya vacastava
]

`v 4 [
yathāśrutārthe tātparyaṃ nāsti kiṃtu anyatra tātparyamiti tvayā kuto jñātamiti cet
puraṃ bhaviṣyannirmāṇaṃ kiṃcidyāmīti niścalā ityādyuktau
bhaviṣyattvavartamānatvayoryaugapadyavirodhādyananvitārthakatva##-
dāśūra uvāca |
śṛṇu putra yathābhūtametatte kathayāmyaham |
yena saṃsāracakrasya tattvamasyāvabudhyase
]

`v 5 [
asadapyutthitārambhamavastumayamātatam |
saṃsārasaṃsthānamidamevamākathitaṃ mayā
]

`v 6 [
paramānnabhaso jātaḥ saṃkalpaḥ khottha ucyate |
jāyate svayamevāsau svayameva vilīyate
]

`v 7 [
tatsvarūpamidaṃ sarvaṃ jagadābhogi vidyate |
jāyate tatra jāte tu tasminnaṣṭe vinaśyati
]

`v 8 [
brahmaviṣṇvindrarudrādyāṃstasyaivāvayavānviduḥ |
viṭapāniva vṛkṣasya śṛṅgāṇīva mahībhṛtaḥ
]

`v 9 [
śūnye vyomani tenedaṃ nirmitaṃ trijagatpuram |
pratibhāsānusaṃdhānamātreṇaitya viriñcitām
]

`v 10 [
yatreme vitatālokā lokakośāścaturdaśa |
vanopavanamālāśca yatrodyānaparamparāḥ
]

`v 11 [
krīḍāśikhariṇo yatra sahyamandarameravaḥ |
śītoṣṇadīptī candrārkau dīpau yatrānalākṛtī
]

`v 12 [
sūryāṃśukacadālolataraṅgottuṅgamauktikāḥ |
vahanti sarito yatra sanmuktāvalayaścalāḥ
]

`v 13 [
ikṣukṣīrādisalilā maṇiratnavisāṅkurāḥ |
aurvānalāmbujā yatra vāpyaḥ sapta mahārṇavāḥ
]

`v 14 [
adha urvyāṃ tathordhve khe puṇyāpuṇyadhanaśriyaḥ |
narāmarakirāṭānāṃ yatrāntaḥ krayavikrayau
]

`v 15 [
ūrdhvādhogatirūpeṇa vaṇijmārgeṇa saṃkulamiti yaduktaṃ tasyārthamāha -
adha iti | puṇyānyapuṇyāni pāpāni ca dhanaśriyo yeṣāṃ teṣāṃ narāṇāṃ
karmopāsanādhikāriṇāmāryāṇāmamarāṇāṃ ca devān bhāvayatānena te deva
bhāvayantu vaḥ iti bhagavaduktanyāyena puṇyatatphalakrayavikrayau | kirāṭānāṃ
pratyantadeśavāsināṃ karmādhikārabahiṣkṛtānāṃ
pāpatatphalasthāvaratiryagādibhiḥ parasparopakārabāhulyātkrayavikrayau bodhyau |
14 |
tasminneva jagatyasminpure saṃkalpabhūbhṛtā |
krīḍārthamātmanaścitrā dehāpavarakāḥ kṛtāḥ
]

`v 16 [
kecidgīrvāṇanāmāna ūrdhva eva niyojitāḥ |
naranāgādayaḥ kecidadha eva niyojitāḥ
]

`v 17 [
vātayantrapravāheṇa calanto māṃsamṛnmayāḥ |
sitāsthidāravaścitrāstvaglepamasṛṇāmalāḥ
]

`v 18 [
keciccireṇa naśyanti kecicchīghravināśinaḥ |
kecitkeśolapollāsaracitācchādanaśriyaḥ
]

`v 19 [
karṇākṣināsāpramukhairdvārairnavabhiranvitāḥ |
anāratavahatprāṇapavanenoṣṇaśītalāḥ
]

`v 20 [
karṇanāsāsyatālvādivātāyanagaṇānvitāḥ |
bhujādyaṅgapratolīkāḥ pañcendriyakudīpakāḥ
]

`v 21 [
māyayā racitāsteṣu saṃkalpena mahāmate |
ahaṅkāramahāyakṣāḥ paramālokabhīravaḥ
]

`v 22 [
dehāpavarakeṣvantarmahāhaṅkārayakṣakaiḥ |
saha saṃkrīḍate'tyarthaṃ sa sadaivāsadutthitaiḥ
]

`v 23 [
yathā kusūle mārjāro bhastrāyāṃ bhujago yathā |
muktāphalaṃ yathā veṇāvahaṅkārastathā tanau
]

`v 24 [
kṣaṇamabhyudayaṃ yānti kṣaṇaṃ śāmyanti dīpavat |
dehageheṣu saṃkalpataraṅgāḥ sāgareṣviva
]

`v 25 [
bhaviṣyannavanirmāṇaṃ sa vyāpnoti tadā puram |
yadā saṃkalpitaṃ vastu kṣaṇādeva prapaśyati
]

`v 26 [
asaṃkalpanamātreṇa svenaivāśu vinaśyati |
śreyase paramāyasya nāśatvena tu saṃbhavaḥ
]

`v 27 [
svayaṃ saṃkalpanāmātraṃ jāyate bālayakṣavat |
anantāyātmaduḥkhāya nānandāya kadācana
]

`v 28 [
idaṃ sphāraṃ jagadduḥkhaṃ pratanotyātmasattayā |
asattayā nāśayati ghanamāndhyaṃ yathā tamaḥ
]

`v 29 [
svayaiva duḥkhadāyinyā ceṣṭayā pariroditi |
kāṣṭhāvaṣṭabdhavṛṣaṇaḥ kīlotpāṭī kapiryathā
]

`v 30 [
saṃkalpitānandalavastiṣṭhatyuddharakandharam |
akasmātpracyutamadhubindubhukkarabho yathā
]

`v 31 [
kṣaṇaṃ viratimāyāti ratimeti kṣaṇaṃ svayam |
kṣaṇaṃ vikāramāyāti saṃkalpenaiva bālavat
]

`v 32 [
enaṃ sakalabhāvebhyaḥ kṛtvā nirmūlamādarāt |
matirantaḥpadaṃ yāti yathā putra tathā kuru
]

`v 33 [
trayastasyā materdehā adhamottamamadhyamāḥ |
tamaḥsattvarajaḥsaṃjñāḥ kāraṇaṃ jagataḥ sthiteḥ
]

`v 34 [
tamorūpo hi saṃkalpo nityaṃ prākṛtaceṣṭayā |
parāṃ kṛpaṇatāmetya prayāti kṛmikīṭatām
]

`v 35 [
sattvarūpo hi saṃkalpo dharmajñānaparāyaṇaḥ |
adūrakevalībhāvaṃ svārājyamadhitiṣṭhati
]

`v 36 [
rajorūpo hi saṃkalpo lokasaṃvyavahāravān |
paritiṣṭhati saṃsāre putradārānurañjitaḥ
]

`v 37 [
trividhaṃ tu parityajya rūpametanmahāmate |
saṃkalpaḥ paramāyāti padamātmaparikṣaye
]

`v 38 [
sarvā dṛṣṭīḥ parityajya niyamya manasā manaḥ |
sabāhyābhyantarārthasya saṃkalpasya kṣayaṃ kuru
]

`v 39 [
yadi varṣasahasrāṇi tapaścarasi dāruṇam |
yadi vā vilayātmānaṃ śilāyāṃ cūrṇayasyalam
]

`v 40 [
nanu saṃkalpakṣayo duṣkaraḥ anya evopāyo mokṣārthamupadiśyatāṃ netyāha ##-
yadi vāgniṃ praviśasi vaḍavāgnimathāpi vā |
yadi vā patasi śvabhre khaḍgadhārājave tathā
]

`v 41 [
haro yadyupadeṣṭā te hariḥ kamalajo'pi vā |
atyantakaruṇākrānto lokanātho'thavā yatiḥ
]

`v 42 [
pātālasthasya bhūsthasya svargasthasyāpi tattava |
nānyaḥ kaścidupāyo'sti saṃkalpopaśamādṛte
]

`v 43 [
anābādhe'vikāre ca sukhe paramapāvane |
saṃkalpopaśame yatnaṃ pauruṣeṇa paraṃ kuru
]

`v 44 [
saṃkalpatantāvakhilā bhāvāḥ protāḥ kilānagha |
chinne tantau na jāne te kva yānti viśarāravaḥ
]

`v 45 [
asatsatsadasatsarvaṃ saṃkalpādeva nānyataḥ |
saṃkalpaṃ sadasaccaivamiha satyaṃ kimucyatām
]

`v 46 [
saṃkalpyate yathā yadyattattathā bhavati kṣaṇāt |
mā kiṃcidapi tattvajña saṃkalpaya kadācana
]

`v 47 [
niḥsaṃkalpo yathāprāptavyavahāraparo bhava |
cidacetyonmukhatvaṃ hi yāti saṃkalpasaṃkṣaye
]

`v 48 [
utthāya sattvarūpeṇa yonyā satyamayātmakam |
na tajjagadduḥkhamidaṃ vyarthaṃ sadṛśamātmanaḥ
]

`v 49 [
tena duḥkhāya mahate kiṃ mṛtena tavānagha |
yadaduḥkhāya tatprājñāḥ saṃśrayantīha netarat
]

`v 50 [
adhigataparamārthatāmupetya
prasabhamapāsya vikalpajālamuccaiḥ |
adhigamaya padaṃ tadadvitīyaṃ
vitatasukhāya suṣuptacittavṛttiḥ
]