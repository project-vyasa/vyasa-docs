`v 1 [
caturthaḥ sargaḥ 4
śrīvasiṣṭha uvāca |
indriyagrāmasaṃgrāmasetunā bhavasāgaraḥ |
tīryate netareṇeha kenacinnāma karmaṇā
]

`v 2 [
śāstrasatsaṃgamābhyāsātsaviveko jitendriyaḥ |
atyantābhāvametasya dṛśyasyāpyavagacchati
]

`v 3 [
etatte kathitaṃ sarvaṃ svarūpaṃ rūpiṇāṃ vara |
saṃsārasāgaraśreṇyo yathā yānti prayānti ca
]

`v 4 [
bahunātra kimuktena manaḥkarmadrumāṅkuraḥ |
tasmiṃśchinne jagacchākhī chinnaḥ karmatanurbhavet
]

`v 5 [
manaḥ sarvamidaṃ rāma tasminnantaścikitsite |
cikitsito vai sakalo jagajālāmayo bhavet
]

`v 6 [
tadetajjāyate loke manomananamākulam |
manaso vyatirekeṇa dehaḥ kva kila dṛśyate
]

`v 7 [
dṛśyātyantāsaṃbhavena ṛte nānyena hetunā |
manaḥpiśācaḥ praśamaṃ yāti kalpaśatairapi `note[kalpaśatairati iti
pāṭhaḥ]
]

`v 8 [
etacca saṃbhavatyeva manovyādhicikitsite |
dṛśyātyantāsaṃbhavātma paramauṣadhamuttamam
]

`v 9 [
mano mohamupādatte mriyate jāyate manaḥ |
tatsvacintāprasādena badhyate mucyate punaḥ
]

`v 10 [
sphuratīdaṃ jagatsarvaṃ citte mananamūrcchite |
śūnyamevāmbare sphāre gandharvāṇāṃ puraṃ yathā
]

`v 11 [
manasīdaṃ jagatkṛtsnaṃ sphāraṃ sphurati cāsti ca |
puṣpaguccha ivāmodastatsthaṃ tasmādivetarat
]

`v 12 [
yathā tilakaṇe tailaṃ guṇo guṇini vā yathā |
yathā dharmiṇi vā dharmastathedaṃ cittake jagat
]

`v 13 [
raśmijālaṃ yathā sūrye yathālokastu tejasi |
yathauṣṇyaṃ citrabhānau ca manasīdaṃ tathā jagat
]

`v 14 [
śaityaṃ yathaiva tuhine yathā nabhasi śūnyatā |
yathā cañcalatā vāyau manasīdaṃ tathā jagat
]

`v 15 [
mano jagajjagadakhilaṃ tathā manaḥ
parasparaṃ tvavirahite sadaiva hi |
tayordvayormanasi nirantaraṃ kṣite
kṣitaṃ jagannatu jagati kṣite manaḥ
]