`v 1 [
tṛtīyaḥ sargaḥ 3
śrīrāma uvāca |
mahākalpāntasargādau prathamo'sau prajāpatiḥ |
smṛtyātmā jāyate manye smṛtyātmaiva tato jagat
]

`v 2 [
śrīvasiṣṭha uvāca |
mahāpralayasargādāvevametadraghūdvaha |
smṛtyātmaiva bhavatyādau prathamo'sau prajāpatiḥ
]

`v 3 [
tatsaṃkalpātmakajagatsmṛtyātmaivamidaṃ tataḥ |
bhāti saṃkalpanagaraṃ sthitaṃ pūrvaṃ prajāpateḥ
]

`v 4 [
prajāpateḥ pūrvaṃ prāthamikaṃ saṃkalpanagaramevaitajjagaditi sthitamityarthaḥ | 3
|
smṛtirna saṃbhavatyeva sargādau paramātmanaḥ |
janmābhāvātkathaṃ kutra nabhasīva mahādrumaḥ
]

`v 5 [
śrīrāma uvāca |
na saṃbhavati kiṃ brahmansargādau prāktanī smṛtiḥ |
mahāpralayasaṃmohairnaśyati prāksmṛtiḥ katham
]

`v 6 [
śrīvasiṣṭha uvāca |
ye mahāpralaye prājñāḥ sarve brahmādayaḥ purā |
kila nirvāṇamāyātāste'vaśyaṃ brahmatāṃ gatāḥ
]

`v 7 [
prāktanaḥ kaḥ smṛteḥ kartā tasmātkathaya suvrata |
smṛtirnirmūlatāṃ yātā smarturmuktatayā yataḥ
]

`v 8 [
ataḥ smarturabhāvena smṛtirvodeti kiṃ katham |
avaśyaṃ hi mahākalpe sarve mokṣaikabhāginaḥ
]

`v 9 [
nānubhūte'nubhūte ca svataścidvyomni yā smṛtiḥ |
sā jagadbhūriti prauḍhā dṛśyā sāstyeva citprabhā
]

`v 10 [
bhāti saṃvitprabhaiveyamanādyantāvabhāsinī |
yattadetajjagaditi svayaṃbhūriti ca sthitam `note[sphuṭaṃ iti pāṭhaḥ]
]

`v 11 [
anādikālasaṃsiddhaṃ yadbhānaṃ brahmaṇo nijam |
sa ātivāhiko deho virājo jagadākṛtiḥ
]

`v 12 [
paramāṇāvidaṃ bhāti trijagatsavanābhrakham |
deśakālakriyādravyadinarātrikramānvitam
]

`v 13 [
paramāṇuḥ pravitatastasyāste tādṛgeva ca |
bhāti bhāsuratākāri tādṛggirikulaṃ punaḥ
]

`v 14 [
tatrāpi tādṛgākārameva pratyanusaṃtatam |
dṛśyamābhāti bhārūpametadaṅga na vāstavam
]

`v 15 [
ityastyanto na saddṛṣṭerasaddṛṣṭeśca vā kvacit |
asyāstvabhyuditaṃ buddhaṃ nābuddhaṃ prati vānagha
]

`v 16 [
buddhaṃ pratīdaṃ brahmaiva kevalaṃ śāntamavyayam |
abuddhaṃ prati buddhyaitadbhāsuraṃ bhuvanānvitam
]

`v 17 [
yathedaṃ bhāsuraṃ bhāti jagadaṇḍakajṛmbhitam |
yathā koṭisahasrāṇi bhāntyanyānyapyaṇāvaṇau
]

`v 18 [
yathā stambhe putrikāntastasyāḥ svāṅgeṣu putrikā |
tasyāśca putrikāstyaṅge tathā trailokyaputrikā
]

`v 19 [
nābhinnā nāpi saṃkhyeyā yathādrau paramāṇukāḥ |
tathā brahma bṛhanmerau trailokyaparamāṇavaḥ
]

`v 20 [
sūryādyaṃśuṣu saṃkhyātuṃ śakyante laghavo'ṇavaḥ |
utpadyante cidāditye trailokyaparamāṇavaḥ
]

`v 21 [
yathāṇavo vahantyarkadīptiṣvapsu rajaḥsu ca |
tathā vahanti cidvyomni trailokyaparamāṇavaḥ
]

`v 22 [
śūnyānubhavamātrātma bhūtākāśamidaṃ yathā |
sargānubhavamātrātma cidākāśamidaṃ tathā
]

`v 23 [
sargastu sargaśabdārthatayā buddho nayatyadhaḥ |
sa brahmaśabdārthatayā buddhaḥ śreyo bhavatyalam
]

`v 24 [
vijñānātmā śāsitā viśvabījaṃ
brahmaivālaṃ svaṃ cidākāśamātram |
yasmājjātaṃ yattadeveti vidyā-
dvedyaṃ svāntarbodhasaṃbodhamātram
]