`v 1 [
pañcāśaḥ sargaḥ 50
śrīvasiṣṭha uvāca |
tamathāsau tathā buddhiphalapallavaśālinam |
ānandamantharamanāḥ puṣparūpācalopamam
]

`v 2 [
kadambaṃ rodasīstambhamāruroha vanasthitam |
ekārṇavagataṃ śaurirvaṭavṛkṣamivonnatam
]

`v 3 [
tatrāsau vyomalagnāyāḥ śākhāyāḥ prāntapallave |
viveśa vigatāśaṅkamekāgraṃ tapa āsthitaḥ
]

`v 4 [
athopaviśya mṛduni navapallavaviṣṭare |
kṣaṇamālokitāstena diśaḥ kautukacañcalam
]

`v 5 [
saridekāvalīramyāḥ śailendrastanakuḍmalāḥ |
nirmalākāśakabarā lolanīlāmbudālakāḥ
]

`v 6 [
nīlapallavavasanāḥ puṣpapūrāvataṃsikāḥ |
gṛhītasāgarāpūrṇakalaśāḥ purubhūṣaṇāḥ
]

`v 7 [
dhṛtapraphullapadminyaḥ sugandhimukhamārutāḥ |
nīlaghuṃghumakākalyo nirjharārāvanūpurāḥ
]

`v 8 [
dyumūrdhāno mahīpādā vanālīromarājayaḥ |
jaṅgalorunitambinyaścandrārkakṛtakuṇḍalāḥ
]

`v 9 [
śālisaṃsārakedārāścandanasthālikānvitāḥ |
śikharorasijālagnahimaśubhrāmbudāṃśukāḥ
]

`v 10 [
mahārṇavapayaḥpūranavamaṇḍanadarpaṇāḥ |
ṛkṣaughagharmapulakā bhuvanāntaḥpurāntarāḥ
]

`v 11 [
ārtavastanadhāriṇyo lagnasūryāṃśukuṅkumāḥ |
vicitrakusumopetāścandrāṃśusitacandanāḥ
]

`v 12 [
gaganagatalatādalopaviṣṭaḥ
prasṛtavanāvanivārivāhaveṣāḥ |
tribhuvanavanitā dadarśa hṛṣṭaḥ
kusumanirantaramaṇḍitā daśāśāḥ
]