`v 1 [
śrīvasiṣṭha uvāca |
evaṃ sthite tu tajjñānāṃ yadetatkartṛtvaṃ dṛśyate sukhaduḥkhādiṣu
yogādiṣu vā tadasannatu mūrkhāṇām
]

`v 2 [
yataḥ kartṛtvaṃ nāma kimucyate | yo hyantasthāyā manovṛtterniścaya
upādeyatāpratyayo vāsanābhidhānastatkartṛtvaśabdenocyate
]

`v 3 [
ceṣṭāvaśāttādṛkphalabhoktṛtvaṃ vāsanānurūpaṃ spandate puruṣaḥ
spandānurūpaṃ phalamanubhavati | phalabhoktṛtvaṃ nāma kartṛtvāditi
siddhāntaḥ
]

`v 4 [
tathāca |
kurvato'kurvato vāpi svarge'pi narake'pi vā |
yādṛgvāsanametatsyānmanastadanubhūyate
]

`v 5 [
tasmādajñātatatvānāṃ puṃsāṃ kurvatāmakurvatāṃ ca kartṛtā natu
jñātatattvānāmavāsanatvāt
]

`v 6 [
jñātatattvo hi śithilībhūtavāsanaḥ kurvannapi phalaṃ nānusaṃdadhāti |
athaca spandanamātraṃ kevalaṃ karotyasaktabuddhiḥ saṃprāptamapi
phalamātmaivedaṃ sarvameva karmaphalamanubhavatyakurvannapi karoti
magnamanāḥ
]

`v 7 [
mano yatkaroti tatkṛtaṃ bhavati yanna karoti tanna kṛtaṃ bhavati ato mana
eva kartṛ na dehaḥ
]

`v 8 [
cittādevāyaṃ saṃsāra āgataścittamaya eva cittamātraṃ citta eva sthita iti
vijñātam | viṣayaśca sarvamupaśāntamabhūdvāsanaiveti jña evāstīti
]

`v 9 [
ātmavidāṃ hi tanmanaḥ paramupaśamamāgataṃ mṛgatṛṇājalamiva
varṣati jalade himakaṇa iva caṇḍātape vilīnaṃ turyadaśāmupāgataṃ sthitam |
9 |
teṣu jīveṣvātmavidāṃ tanmanaḥ varṣati jalade prāvṛṣi
mṛgatṛṣṇājalamivopaśamamāgataṃ sat caṇḍātape himakaṇa iva nilīnaṃ
turyadaśāmupāgataṃ sattadbhāvenaiva sthitamiti viśeṣa ityarthaḥ
]

`v 10 [
nānandaṃ na nirānandaṃ na calaṃ nācalaṃ sthiram |
na sannāsanna caiteṣāṃ madhyaṃ jñānimano viduḥ
]

`v 11 [
na vāsanāmaye spandarase gaja iva palvale majjati tajjño
mūrkhamanobhogabhūmimeva paśyati na sattattvaṃ
]

`v 12 [
tathācāyamatrāparo dṛṣṭāntaḥ | akurvannapi śvabhrapatanaṃ
śayyāsanagato'pi śvabhrapātavāsanāvāsite cetasi
śvabhrapatanaduḥkhamanubhavati | aparastu kurvannapi śvabhrapatanaṃ
paramamupaśamamupagatavati manasi śayyāsanasukhamanubhavati |
evamanayoḥ śayyāsanaśvabhrapātayorekaḥ śvabhrapatanasyākartāpi kartā
saṃpanno dvitīyaśca śvabhrapatanasya kartāpyakartā
saṃpannaścittavaśāttasmādyaccittaṃ tanmayo bhavati puruṣa iti siddhāntaḥ
]

`v 13 [
tena tatra karturakarturvā nityamasaṃsaktaṃ bhavatu ceto nahi
kiṃcidastyātmatattvavyatiriktaṃ yatra saṃsaktirbhāvyate | yatkiṃcididaṃ
jagadgataṃ tatsarvaṃ śuddhacittatvādābhāsamavehi
]

`v 14 [
evaṃ cāsya jñātajñeyasya puṃso nāmātmā sukhaduḥkhānāṃ na gamya iti
niścaye jāte nātmavyatiriktā ādhārādheyadṛṣṭayo vidyanta iti niścaye jāte
kartā bhoktā sarvapadārthavyatirikto vālāgrasahasrabhāgo'hamiti niścaye
jāte yatkiṃcididaṃ tatsarvamahameveti vā niścaye jāte
sarvasattvāvabhāsakaḥ sarvagastiṣṭhāmyevāhamiti niścaye jāte nāhaṃ
sukhaduḥkhānāṃ gamya iti vigatajvaratayā cittavṛttirlīlayaiva tiṣṭhate
vyavahāreṣu
]

`v 15 [
tajjñasya saṃkaṭe ca muditaiva kevalaṃ jyotsneva bhuvanabhāvamalaṃkaroti
yena cittādṛte tu jñaḥ kurvannapyakartā saṃpanno
manaso'lepakatvānnāsau pādapāṇyādivikṣepasya yatnakṛtasyāpi karmaṇaḥ
phalamanubhavati
]

`v 16 [
atastattvajñasya saṃkaṭeṣvapi na duḥkhabhoktṛtvaṃ pratyutānanda evetyāha ##-
evaṃ manaḥ sarvakarmaṇāṃ sarvehitānāṃ sarvabhāvānāṃ sarvalokānāṃ
sarvagatīnāṃ bījaṃ tasminparihṛte sarvakarmāṇi parihṛtāni bhavanti
sarvaduḥkhāni kṣīyante sarvakarmāṇi layamupayānti | mānasenāpi karmaṇā
yatkṛtenāpi jño nākramyate na vivaśīkriyate na
rañjanāmupaityavyatiriktāt
]

`v 17 [
yathā bālo manasā nagarasya nirmāṇaṃ nirmṛṣṭaṃ ca
kurvannagaranirmāṇaṃ manaḥkṛtamakṛtamiva līlayānubhavati
nopādeyatayāsukhaduḥkhamakṛtrimamiti paśyati nagaranirmathanaṃ ca
manaḥkṛtaṃ kṛtamiti paśyatīti duḥkhamapi līlayānubhavannapi na
duḥkhamiti paśyati | evamasau paramārthataḥ kurvannapi na lipyata eveti
]

`v 18 [
sarvabhāveṣu heyopādeyatābhyāṃ jagati kiṃ kāraṇaṃ duḥkhasya na
copādeye kiṃcidapi saṃbhavati yadavināśaṃ vyatiriktaṃ
cātmanastasmādayamātmā'kartā'bhoktā'tattvato yadetatkartṛtvaṃ ca
svadhyāropyate
]

`v 19 [
āvaśyakaṃ tatsamyagdarśanamohānna vastuta iti
yathābhūtavastuvicāraṇātkartṛtvabhoktṛtve na staḥ |
indriyendriyārthadveṣābhilāṣādikā dṛṣṭayastaddṛṣṭīnāṃ dṛśyante
nātaddṛṣṭīnām
]

`v 20 [
āvaśyakaṃ jīvatā anivāryam | nahi dehabhṛtā śakyaṃ tyaktuṃ
karmāṇyaśeṣataḥ iti nyāyādityarthaḥ | āvaśyakatvaṃ kutastatrāha - indriyeti
| indriyairindriyārtheṣu dveṣābhilāṣādikaistannimittaiḥ
puṇyapāpādṛṣṭaiścāyastā vivaśīkkṛtā buddhiryeṣāmajñānāṃ
`note[mūlasthasyaiva dṛṣṭipadasyāyaṃ paryāyārthaḥ] teṣāmevetyarthaḥ |
19 |
mokṣo'sti na saṃsāre svasaṃsaktamanasāmihāsaṃsaktamanasāṃ
tvetatsarvamevāsti
]

`v 21 [
yathāsthitaṃ jñasya kevalamātmatattvamevollasati taddvitvaikatvavādisiddhe
dvitvaikatve karoti sattvāsattve karoti śaktijālādabhinnāṃ sarvaśaktitāṃ ca
darśayati tasya
]

`v 22 [
na bandho'sti na mokṣo'sti nābandhosti na bandhanam |
aprabodhādidaṃ duḥkhaṃ prabodhātpravilīyate
]

`v 23 [
saṃkalpitā jagati mokṣamatirmudhaiva
saṃkalpitā jagati bandhamatirmudhaiva |
saṃtyajya sarvamanahaṃkṛtirātmaniṣṭho
dhīro dhiyā vyavaharanbhuvi rāma tiṣṭha
]