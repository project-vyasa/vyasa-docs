`v 1 [
dvitīyaḥ sargaḥ 2
śrīvasiṣṭha uvāca |
athaitadabhyupagame vacmi vedyavidāṃ vara |
samastakalanātīte mahācidvyomni nirmale
]

`v 2 [
jagadādyaṅkurastatra yadyasti tadasau tadā |
kairivodeti kathaya kāraṇaiḥ sahakāribhiḥ
]

`v 3 [
sahakārikāraṇānāmabhāve tvaṅkurodgatiḥ |
vandhyākanyeva dṛṣṭeha na kadācana kenacit
]

`v 4 [
sahakārikāraṇānāmabhāve yadyavoditam |
mūlakāraṇamevāṅga tatsvabhāvasthitiṃ gatam
]

`v 5 [
sargādau sargarūpeṇa brahmaivātmani tiṣṭhati |
yathāsthitamanākāraṃ kva janyajanakakramaḥ
]

`v 6 [
atha pṛthvyādayo'nye vā kecidatropakurvate |
sahakārikāraṇatvaṃ tatpūrvaṃ cātra dūṣaṇam
]

`v 7 [
nanu pralaye sarvajagatsattvasvikārānna sahakāridaurlabhyaṃ tadantargataiḥ
pṛthavyādibhiḥ parasparamupakartuṃ śakyatvādityāśaṅkya pariharati -
atheti | tatpūrvaṃ pṛthvyādyutpattipūrvakaṃ vācyam | nahi
svayamevānutpannamanyasyotpattau sahakāri bhavituṃ śaknoti | tathācotpattisiddhau
sahakāritvasiddhistatsiddhābutpattisiddhirityanyonyāśrayo'tra dūṣaṇamityarthaḥ | 6
|
tasmātpade jagacchāntamāste tatsahakāribhiḥ |
cittātprasaratītyuktirbālasya na vipaścitaḥ
]

`v 8 [
tasmādrāma jagannāsīnna cāsti na bhaviṣyati |
cetanākāśamevāśu kacatītthamivātmani
]

`v 9 [
atyantābhāva evāsya jagato vidyate yadā |
tadā brahmedamakhilamiti tadrāma nānyathā
]

`v 10 [
pūrvaṃ pradhvaṃsanānyonyābhāvairyadupaśāmyati |
na śāmyatyeva taccitte śāmyatyeva tu dṛśyate
]

`v 11 [
atyantābhāva evāsya bhāvairyadupaśāmyati |
na śāmyatyeva saccitte kva śāmyatyeva dṛśyatā
]

`v 12 [
atyantābhāva evāto jagaddṛśyasya sarvathā |
varjayitvetarā yuktirnāstyevānarthasaṃkṣaye
]

`v 13 [
ata eva samūlamanonāśāntaśrautabādhātiriktaḥ
sarvadṛśyānarthasaṃkṣayarūpe mokṣe upāyo nāstītyāha - atyanteti |
atyantābhāvo'dhiṣṭhānadarśanena bādha evātra yuktiḥ | imāṃ yuktiṃ varjayitvā |
12 |
cidākāśasya bodho'yaṃ jagadbhātīti yatsthitam |
ayaṃ so'hamidaṃ nāhaṃ loke citrakathā yathā
]

`v 14 [
idamadryādi pṛthvyādi tathedaṃ vatsarādi ca |
ayaṃ kalpaḥ kṣaṇaścāyamime maraṇajanmanī
]

`v 15 [
ayaṃ kalpāntasaṃrambho mahākalpānta eṣa saḥ |
ayaṃ sa sargaprārambho bhāvyabhāvakramastvasau
]

`v 16 [
lakṣmāṇīmāni kalpānāmimā brahmāṇḍakoṭayaḥ |
ete ceme parigatā ime bhūya upāgatāḥ
]

`v 17 [
imāni dhiṣṇyajālāni deśakālakalā imāḥ |
mahācitparamākāśamanāvṛtamanantakam
]

`v 18 [
yathāpūrvaṃ sthitaṃ śāntamityevaṃ kacati svayam |
paramāṇusahasrāṃśubhāsa etā mahāciteḥ
]

`v 19 [
ityevaṃ varṇitena citrakathānyāyena mahācitparamākāśameva svayaṃ svātmani
kacati sphurati nānyadityarthaḥ | tarhi kiṃ mahācitprakāśa etāvāneva netyāha ##-
prabhāḥ paricchinnāstathā manonirgatabrhmāṇḍakoṭiṣu paricchinnā
etāścidbhāsaḥ | yathā ca nabhovistṛtena sūryaprakāśena
paramāṇubhedabhramaṇādi dṛśyate tathā mahācitparamākāśe'pīti bhāvaḥ | 18
|
svayamantaścamatkāro yaḥ samudgīryate citā |
tatsargabhānaṃ bhātidamarūpaṃ natu bhittimat
]

`v 20 [
nodyanti naca naśyanti nāyānti naca yānti ca |
mahāśilāsu lekhānāṃ sanniveśā ivācalāḥ
]

`v 21 [
ime sargāḥ prasphuranti svātmanātmani nirmale |
nabhasīva nabhobhāgā nirākārā nirākṛtau
]

`v 22 [
dravatvānīva toyasya spandā iva sadāgatau |
āvartā iva cāmbhodherguṇino vā yathā guṇāḥ
]

`v 23 [
vijñānaghanamevaikamidamevamavasthitam |
sodayāstamayārambhamanantaṃ `note[manāraṃbhaṃ iti pāṭhaḥ]
śāntamātatam
]

`v 24 [
sahakāryādihetūnāmabhāve śūnyato jagat |
svayaṃbhūrjāyate ceti kilonmattakaphūtkṛtam
]

`v 25 [
praśāntasarvārthakalākalaṅko
nirastaniḥśeṣavikalpatalpaḥ |
cirāya vidrāvitadīrghanidro
bhavābhayo bhūṣitabhūḥ prabuddhaḥ
]