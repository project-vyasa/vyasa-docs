`v 1 [
ekapañcāśaḥ sargaḥ 51
śrīvasiṣṭha uvāca |
tataḥprabhṛti tatrāsau prasiddhastāpasāśrame |
kadambadāśūra iti śūrastapasi dāruṇe
]

`v 2 [
tasmṁllatādale sthitvā vilokya kakubhaḥ kṣaṇāt |
dṛḍhapadmāsanaṃ baddhvā digbhyaḥ pratyāhṛtātmanā
]

`v 3 [
ajñātaparamārthena kriyāmātre ca tiṣṭhatā |
phalakārpaṇyayuktena manasā so'karonmakham
]

`v 4 [
nabhogatalatāpatrasaṃsthitenāntarātmanā |
sarvāḥ svamanasā tena kṛtā yajñakriyāḥ kramāt
]

`v 5 [
tatrāsau daśa varṣāṇi manasaivāyajatsurān |
gavāśvanaramedhādyairyajñairvipuladakṣiṇaiḥ
]

`v 6 [
kālenāmalatāṃ yāte vitate tasya cetasi |
balādavatatārāntarjñānamātmaprasādajam
]

`v 7 [
tato viśīrṇāvaraṇo vigaladvāsanāmalaḥ |
sa dadarśikadā tasyāṃ latāyāmagrataḥ sthitām
]

`v 8 [
vanadevīṃ viśālākṣīmālokakusumāmbarām |
kāminīṃ kāntavadanāṃ madagūrṇitalocanām
]

`v 9 [
nīlotpalāmodavatīmatīva sumanoharām |
tāmuvācānavadyāṅgīṃ sa munirvinatānanām
]

`v 10 [
kokilākusumāpūranatāṃ vanalatāmiva |
kā tvamutpalapatrākṣi kāntivikṣobhitasmarā
]

`v 11 [
vayasyāmiva puṣpāḍhyāṃ latāṃ kimiva tiṣṭhasi |
ityukte mṛgaśāvākṣī gaurapīnapayodharā
]

`v 12 [
munimāha manohāri mugdhākṣaramidaṃ vacaḥ |
yāni yāni durāpāni vāñchitāni mahītale
]

`v 13 [
prāpyante tānti tānyāśu mahatāmeva yācñayā |
ahamasmiṁllatākīrṇe tvatkadambābhyalaṃkṛte
]

`v 14 [
latālīlālayā brahmanvipine vanadevatā |
yaścaitrasitapakṣasya trayodaśyāṃ smarotsave
]

`v 15 [
babhūva vanadevīnāṃ samājo nandane vane |
tatrāhamagamaṃ nātha trailokyalalanāsadaḥ
]

`v 16 [
tatra dṛṣṭā mayā sarvā vayasyā madanotsave |
aputrayā putrayutāstenāhaṃ duḥkhitā bhṛśam
]

`v 17 [
tvayi sarvārthasārthasya bṛhatkalpatarau sthite |
anātheva kathaṃ nātha kila śocāmyaputrikā
]

`v 18 [
dehi me bhagavanputra no deddehamihāgnaye |
prakaromyāhutiṃ putra duḥkhadāhopaśāntaye
]

`v 19 [
tāmityuktavatīṃ tanvīṃ vihasya munipuṅgavaḥ |
prāha hastagataṃ puṣpaṃ tasyai dattvā dayānvitaḥ
]

`v 20 [
gaccha tanvaṅgi māsena pūjārhamalilocanam |
prasoṣyase sutaṃ kāntaṃ prasūnamiva sallatā
]

`v 21 [
kiṃtvasau maraṇāveśayāyinyā nastvayā sutaḥ |
yācitaḥ kṛcchraṃ saṃprāpya jñātā tena bhaviṣyati
]

`v 22 [
ityuktvā sa munistanvīṃ prasannamukhamaṇḍalām |
paricaryāṃ karomīti prārthanotkāṃ vyasarjayat
]

`v 23 [
sā jagāmātmasadanaṃ so'tiṣṭhatsvātmanā saha |
avahatkramaśaḥ kāla ṛtusaṃvatsarāṅkitaḥ
]

`v 24 [
atha dīrgheṇa kālena saivotpalavilocanā |
dvādaśābdamupādāya sutaṃ munimupāyayau
]

`v 25 [
sā praṇamyopaviśyāgre munimindusamānanam |
uvāca kalayā vācā cūtadrumamivālinī
]

`v 26 [
ayaṃ sa bhagavanbhavyaḥ kumāraḥ putra āvayoḥ |
kṛto mayā samagrāṇāṃ kalānāṃ kila kovidaḥ
]

`v 27 [
prabho kevalametena jñānaṃ nādhigataṃ śubham |
yena saṃsāracakre'sminna punaḥ paripīḍyate
]

`v 28 [
jñānaṃ tvamevāsya vibho kṛpayopadiśādhunā |
ko hi nāma kule jātaṃ putraṃ maurkhyeṇa yojayet
]

`v 29 [
evaṃ vadantīṃ sa muniḥ sacchiṣyamabale sutam |
ihaiva sthāpayainaṃ tvamityuktvā tāṃ vyasarjayat
]

`v 30 [
tasyāṃ gatāyāṃ sa piturantevāsitayā tayā |
atiṣṭhatsaṃyato dhīmānarkasyevāruṇaḥ puraḥ
]

`v 31 [
kadarthaḥ prāpya vijñānaṃ tataścitrābhiruktibhiḥ |
cirakālamasau tatra muniḥ putramabodhayat
]

`v 32 [
kadarthaḥ śuśrūṣāvratacaryādikleśaiḥ kadarthitaḥ san vijñānaṃ
upāyabhūtaśāstrajanyaṃ parokṣajñānaṃ prāpya sthita iti śeṣaḥ |
tatastadanantaraṃ taṃ putraṃ cirakālaṃ abodhayat |
aparokṣībhāvāyopadideśetyarthaḥ | athavā pitā prāktapaḥkadarthitaḥ san
vijñānaṃ prāpya putro'pyevaṃ kadarthito mābhūditi svayamabodhayadityarthaḥ |
31 |
ākhyāyikākhyānaśatairdṛṣṭāntairdṛṣṭikalpitaiḥ |
tathetihāsavṛttāntairvedavedāntaniścayaiḥ
]

`v 33 [
anudvegitayā nityaṃ vistareṇa kathākramaiḥ |
anubhūtimupārūḍhai rūḍhimeti yathā mayi
]

`v 34 [
anubhavavaśato rasātiriktai-
ralamucitārthavacogaṇairmahātmā |
jalada iva śikhaṇḍinaṃ puraḥsthaṃ
tanayamabodhayadambare maharṣiḥ
]