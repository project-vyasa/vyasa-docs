`v 1 [
ekonaṣaṣṭitamaḥ sargaḥ 59
annapānāṅganāsaṅgādṛte nāstīha kiṃcana |
śubhamastviti saṃvādi mahānkimiva vāñchatu
]

`v 2 [
tiryañcaḥ paśavo mūḍhā ye na tuṣyantyasādhavaḥ |
bhogaiḥ kṛpaṇasarvasvairādimadhyāntapelavaiḥ
]

`v 3 [
viśvāsaṃ yānti ye loke tairalaṃ naragardabhaiḥ |
itaḥ keśā ito raktamitīyaṃ pramadātanuḥ
]

`v 4 [
etayā toṣamāyānti sārameyā na mānavāḥ |
mṛnmahīdārutaravo dehā māṃsamayā api
]

`v 5 [
adho bhūrambaraṃ pṛṣṭhe kimapūrvaṃ sukhāya tu |
mātrāsparśānusāriṇyo vivekapadabhaṅgurāḥ
]

`v 6 [
mohāyaivāparāmṛṣṭāḥ sakalā lokasaṃvidaḥ |
sarvasyā eva paryante sukhāśāyāśca saṃsthitam
]

`v 7 [
mālinyaṃ duḥkhamapyevaṃ jvālāyā iva kajjalam |
āgamāpāyino'nityā manaḥṣaṣṭhendriyakriyāḥ
]

`v 8 [
latā nāgendramṛditā dhārayanti na saṃpadaḥ |
putrikā raktamāṃsasya kānteyamiti sādaram
]

`v 9 [
svadehanāmnā'sthicaye `note[nāmnā sthitaye ityapi kvacitpaṭhyate tattu
saṅgativikalamiti pratīyate] śliṣyate mohakakramaḥ |
sarvaṃ satyamidaṃ rāma sthiramajñasya tuṣṭaye
]

`v 10 [
jñasyāsthairyamasatyaṃ ca jagadrāma na tuṣṭaye |
abhukte'pi viṣā yaiṣā viṣamūrcchāṃ prayacchati
]

`v 11 [
tāṃ parityajya bhogāsthāṃ svātmaikatvagatiṃ bhaja |
anātmamayabhāvena cittaṃ sthitimupāgatam |
yadā tadaitadājātaṃ jagajjālamasanmayam
]

`v 12 [
vāsanāvaśato brahmamanasā kalpitaṃ vapuḥ |
tejasā śritakuḍyena hemābhatvamivātmanaḥ
]

`v 13 [
śrīrāma uvāca |
vairiñcapadamāsādya mano brahmanmahāmate |
idaṃ jagatsughanatāṃ kathamānayati kramāt
]

`v 14 [
śrīvasiṣṭha uvāca |
garbhatalpātsamutthāya padmajaḥ prathamaḥ śiśuḥ |
brahmeti śabdamakarodbrahmā tena sa ucyate
]

`v 15 [
saṃkalpajālarūpasya manasā kalpitākṛteḥ |
akarottasya saṃkalpalakṣmīḥ padamathottare
]

`v 16 [
tataḥ saṃkalpayāmāsa pūrvaṃ tejo mahāprabham |
śaradante latācakracakrīkṛtadigantaram
]

`v 17 [
pakṣapratimanisyūtakarmaṇātiguṇākṣaram |
puñjapiñjaraparyantaṃ hemajñānanibhāmbaram
]

`v 18 [
jālahemalatājālajaṭālanijamandiram |
kacatprasaradudyānākārakuṇḍalamaṇḍitam
]

`v 19 [
taṃ śarīraṃ manastasmiṃstatastejasi bhāsvare |
ātmākārasamākāraṃ bhāsvaraṃ samakalpayat
]

`v 20 [
sa tatastejasastasmādabhyudeti divākaraḥ |
jālamaṇḍalamadhyastho jvalatkanakakuṇḍalaḥ
]

`v 21 [
jvalajjaṭābhāradharopāntavisphārapāvakaḥ |
jvālāviśālāvayavaḥ pūritākāśamaṇḍalaḥ
]

`v 22 [
atha brahmā mahābuddhiranyāstāstejasaḥ kalāḥ |
apālya yadasadbrahmā taraṅgāniva sāgaraḥ
]

`v 23 [
te'pi saṃkalpasaṃprāptasiddhayaḥ samaśaktayaḥ |
yathāsaṃkalpitaṃ vastu kṣaṇāddṛṣṭvāpuragrataḥ
]

`v 24 [
saṃkalpayanto yānyāṃste nānābhūtagaṇānbahūn |
bhūteṣvanyāṃstu teṣvanyāṃsteṣvanyānvividhānapi
]

`v 25 [
saṃsmṛtya vedāṃstadanu yajñakramaguṇānbahūn |
jagadgṛhādayaṃ brahmā maryādāṃ samakalpayat
]

`v 26 [
saṃkalpayanta āpurityatrāpyanuvartate | tato yajñāvikarmapravṛttiṃ darśayati ##-
brāhmaṃ rūpamupādāya manonāma mahadvapuḥ |
tanotītthamimāṃ dṛṣṭiṃ bhūtasaṃtatisaṃkulām
]

`v 27 [
samudrācalavṛkṣāḍhyāṃ kṛtalokottarakramām |
merubhūpīṭhadikkuñjajaṭālodaramaṇḍalām
]

`v 28 [
sukhaduḥkhajarājanmamaraṇasvādhbodhitām |
rāgadveṣamayodvignāṃ guṇatrayamayātmikām
]

`v 29 [
manohastairviriṃcotthairyadyathā kalpitaṃ purā |
tattathaivākhilaṃ draṣṭuṃ dṛśyate'dyāpi māyayā
]

`v 30 [
itthaṃ sarveṣu bhūteṣu keṣucittvathavā punaḥ |
saṃkalpayati saṃsāraṃ paraṃ paśyati citsthitam
]

`v 31 [
moha evaṃmayo mithyā jāgataḥ sthiratāṃ gataḥ |
saṃkalpanena manasā kalpito'cirataḥ svayam
]

`v 32 [
saṃkalpavaśataḥ sarvāḥ prasavanti jagatkriyāḥ |
saṃkalpavaśato devā niryānti niyatisthitāḥ
]

`v 33 [
kopitāyāḥ prajānātharjagatsṛṣṭeḥ kulodbhavaḥ |
brahmā saṃcintayatyeṣa padmāsanagataḥ prabhuḥ
]

`v 34 [
manaḥspandanamātreṇa citraṃ cittaṃ yadutthitam |
sṛṣṭirvā bhoginī sphārā vyavahāravikāriṇī
]

`v 35 [
rudropendramahendrādyā `note[mahendrāḍhyā iti pāṭhaḥ]
śailasāgarasaṃkulā |
pātālarododiksvargamārgasaṃkaṭakoṭarā
]

`v 36 [
saṃkalpajālamatyantaṃ mayedamabhitastatam |
adhunā virato'smyasmādvikalpollāsanakramāt
]

`v 37 [
iti niścitya virataḥ kalpanānarthasaṃkaṭāt |
anādimatparaṃ brahma smaratyātmānamātmanā
]

`v 38 [
tamāsādya tadābhāse pade galitamānase |
sukhaṃ tiṣṭhati śāntātmā talpe'dhaḥ śramavāniva
]

`v 39 [
nirmamo nirahaṃkāraḥ parāṃ śāntimupāgataḥ |
avikṣubdha ivāmbhodhirātmanātmani tiṣṭhati
]

`v 40 [
dhyānātkadācidbhagavānsvayaṃ viramati prabhuḥ |
bandhanātsalilasyandātsaumyatvādiva vāridhiḥ
]

`v 41 [
vicārayati saṃsāraṃ sukhaduḥkhasamanvitam |
āśāpāśaśatairbaddhaṃ rāgadveṣabhayāturam
]

`v 42 [
tataḥ sa karuṇākrāntamanā bhūtavibhūtaye |
karotīha mahārthāni śāstrāṇi vividhāni ca
]

`v 43 [
adhyātmajñānagarbhāṇi vedavedāṅgasaṃgraham |
purāṇādīni cānyāni muktaye sarvadehinām
]

`v 44 [
punasttpadamālambya paramāpadvinirgataḥ |
svasthastiṣṭhati śāntātmā nirmandara ivārṇavaḥ
]

`v 45 [
avalokya jagacceṣṭāṃ maryādāṃ viniyojya ca |
brahmā kamalapīṭhasthaḥ punaḥ svātmani tiṣṭhati
]

`v 46 [
kadācitkevalaṃ sarvasaṃkalpaparihīnayā |
yadṛcchayānugrahārthaṃ lokakramavadāsthitaḥ
]

`v 47 [
nārjavaṃ nāsya saṃtyāgo vapuṣo naca saṃgrahaḥ |
nānā na cetanaṃ neha na sthitirnāsthitiḥ sthitā
]

`v 48 [
sarvabhāvasamārambhaḥ samaḥ sarvāsu vṛttiṣu |
paripūrṇārṇavākāro muktaśeṣo'vatiṣṭhate
]

`v 49 [
kadācitkevalaṃ sarvasaṃkalpaparihīnayā |
yadṛcchayānugrahārthaṃ lokānāṃ pratibudhyate
]

`v 50 [
eṣā brāhmī sthitiḥ puṇyā yā mayoktā mahāmate |
yātāṃ vidhisurānīkau tāmetāṃ sātvikīmapi
]

`v 51 [
upasaṃharati - eṣeti | idānīṃ mānasaḥ prajāpatīnāṃ sargaste hi
saṃkalpasaṃprāptasiddhayaḥ svayaṃ prajñātajñānayogaiśvaryāḥ prathamo
vidhyanīkaḥ | maithunasarge'pi devagandharvayakṣādīnāṃ
sāttvikatvātsakṛdupadeśaprāptajñānaiśvaryaḥ surānīko madhyamaḥ |
manuṣyādistu rajastamograstaḥ prayatnasahasrasādhyajñānaiśvaryo
narānīko'dhama ityanīkatrayavibhāgaṃ manasi nidhāya teṣāṃ
svakāraṇāsāditacittaśuddhyanurūpajñānodayena brahmaprāptiṃ vibhajya
darśayati - yātāmityādinā | tāṃ varṇitaprakārāṃ etāṃ sāttvikīṃ
sattvotkarṣaprāpyāṃ brāhmīṃ sthitiṃ vidhisurānīkāvapi yātāṃ prāpnuyātām |
50 |
citsargoparamākāśe brahmaṇo yanmanaḥphalam |
udeti prathamaḥ saiva brahmatvaṃ samavāśnute
]

`v 52 [
sarge sthitiṃ gate tvanyā yodeti kalpanāparā |
sā vyomānilamāśritya praviśyauṣadhipallavān
]

`v 53 [
kācitsuratvamāyāti kācidāyāti yakṣatām |
udeti prathamaṃ saiṣā brahmatvaṃ samavāśnute
]

`v 54 [
yā yatsattvaṃ samanveti sā tadevāśu jāyate |
jātā saṃsargavaśatastasminneva ca janmani |
badhyate mucyate vāsau svayamanvārabhedataḥ
]

`v 55 [
itthaṃ gatāsthitiriyaṃ kila rāmabhadra
sṛṣṭiḥ sphuṭaprakaṭasaṃkaṭakarmalabdhā |
āvirbhavedvividhavegavihārabhāra-
saṃrambhagarbhavidhṛtā kalanāpade sā
]