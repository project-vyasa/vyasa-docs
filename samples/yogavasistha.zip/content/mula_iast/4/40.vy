`v 1 [
catvāriṃśaḥ sargaḥ 40
śrīrāma uvāca |
utpattiḥ kathameteṣāṃ jīvānāṃ brahmaṇaḥ padāt |
kiyatī kīdṛśī ceti vistareṇa vada prabho
]

`v 2 [
śrīvasiṣṭha uvāca |
utpadyante yathā citrā brahmaṇo bhūtajātayaḥ |
yathā nāśaṃ prayāntyetā yathā muktā bhavanti hi
]

`v 3 [
yathā ca parivardhante tiṣṭhantyantarhitā yathā |
saṃkṣepeṇa mahābāṇo śṛṇu vakṣyāmi te'nagha
]

`v 4 [
brāhmī cicchaktiramalā kalpayantī yadṛcchayā |
sarvaśaktiḥ svayaṃ cetyaṃ bhavatyākalanātmakam
]

`v 5 [
kalanāddhanatāmetya yatkiṃcidapi sā svayam |
saṃkalpayati paścāttattattāmeti manaḥpadam
]

`v 6 [
manaḥsaṃkalpamātreṇa gandharvapuravatkṣaṇāt |
tanotīdamasaddṛśyaṃ brāhmīṃ sthitimiva tyajat
]

`v 7 [
citsvarūpaṃ parikacacchūnyamevāvatiṣṭhate |
yattaddṛśyaṃ sthitaṃ tatsyāddṛśyamākāśameva tat
]

`v 8 [
kṛtvā padmajasaṃkalpaṃ rūpaṃ paśyati padmajam |
tato jagatkalpayati saprajāpatipūrvakam
]

`v 9 [
tasminnākāśe caturmukhādisthūladehasya bhuvanānāṃ ca kalpanāṃ darśayati ##-
caturdaśavidhānantabhūtajātasaghuṃghumā |
sṛṣṭirevamiyaṃ rāma cittanirmitimāgatā
]

`v 10 [
cittamātramayī śūnyā vyomamātraśarīrikā |
saṃkalpamātranagarī bhrāntimātrātmikā satī
]

`v 11 [
iha kāścinmahāmohā bhūtānāṃ jātayaḥ sthitāḥ |
kāścidabhyuditajñānāḥ kāścinmadhye skhalanti hi
]

`v 12 [
bhuvi saṃbadhyamānānāṃ yāntyenāmupadeśyatām |
sarvāsāṃ bhūtajātīnāṃ yā etā narajātayaḥ
]

`v 13 [
bahvādhayo duḥkhamayā mohadveṣabhayāturāḥ |
tāsāṃ samyakpravakṣyāmi tāvadrājasasāttvikīḥ
]

`v 14 [
yattadapyamṛtaṃ brahma sarvavyāpi nirāmayam |
cidābhāsamanantākhyamanādi vigatabhramam
]

`v 15 [
nispandavapuṣastasya spandaḥ sattaikadeśataḥ |
ghanatāmeti saumye'bdhau calatā calatāmiva
]

`v 16 [
śrīrāma uvāca |
anantasyātmatattvasya ekadeśaḥ ka ucyate |
kathaṃ vikāritā vā syātkathaṃ vā dvayavikramaḥ
]

`v 17 [
śrīvasiṣṭha uvāca |
tena jātaṃ tato jātamitīyaṃ racanā girām |
śāstrasaṃvyavahārārthaṃ na rāma paramārthataḥ
]

`v 18 [
vikāritāvayavitādiksattādeśatādayaḥ |
kramā na saṃbhavantīśe dṛśyamānodayā api
]

`v 19 [
taṃ vinā kalpanaivānyā nāsti nāpi bhaviṣyati |
kutastyau kramaśabdārthāvuktayo vyavahārajāḥ
]

`v 20 [
yā yeha kalanā yo'rtho yaḥ śabdo yo girāṃ gaṇaḥ |
tajjatvāttanmayatvācca tattatpadamiveṣyate
]

`v 21 [
tajjaḥ sa eva bhavati vahnervahnirivotthitaḥ |
janyo'yaṃ janakaścāyamityuktā bhedakalpanā
]

`v 22 [
ayamasmātsamutpanna itīyaṃ yā jagatsthitiḥ |
ādhikyaṃ tatkriyāśaktau janyaṃ janakameva vā
]

`v 23 [
idamanyadidaṃ cānyaditi śabdārthaviklavaḥ |
uktāveva na deve'sti pramitau bhinnatā yataḥ
]

`v 24 [
tajjayaiva manaḥśaktyā svataḥ saṃjñā pravartate |
dṛḍhabhāvanayā tasmādiṣṭo'rthaḥ pratipadyate
]

`v 25 [
agneḥ śikhāyā ekasyā dvitīyā janaketi yā |
uktivaicitryamevaitannoktyarthe'trāsti satyatā
]

`v 26 [
na janyajanakādyāstāḥ saṃbhavantyuktayaḥ pare |
ekameva hyanantatvātkiṃ kathaṃ janayiṣyati
]

`v 27 [
uktereva svabhāvo'yamukteruktiranantaram |
pratiyogivyavacchedasaṃkhyādyarthe na yujyate
]

`v 28 [
pratiyogī svāśrayatādātmyavirodhī | vyavacchedo bhedaḥ | saṃkhyādvitvādiḥ | 27
|
ūrmijālamivāmbhodhau pare yaḥ paridṛśyate |
śabdo'rthakalanākārastadbrahmaiva vidurbudhāḥ
]

`v 29 [
brahma cidbrahma ca mano brahma vijñānavastu ca |
brahmārtho brahma śabdaśca brahma cidbrahma dhātavaḥ
]

`v 30 [
brahma sarvamidaṃ viśvaṃ viśvātītaṃ ca tatpadam |
vastutastu jagannāsti sarvaṃ brahmaiva kevalam
]

`v 31 [
ayamanyo'yamanyo'yaṃ bhāga ityambarātmani |
mithyājñānavikalpoktirvāci satyārthatātra kā
]

`v 32 [
vahneḥ śikheva jāteyaṃ śikheti manaso'bhidhā |
cāpalotthavikalpaśrīrvastutaḥ syānna siddhyati
]

`v 33 [
asatyaiva vikalpoktiḥ satyabhāvo vikalpate |
tamopahatadṛṣṭitvāddvicandrajñānadoṣavat
]

`v 34 [
sarvasmātsarvagāttasmādanantādbrahmaṇaḥ padāt |
nānyatkiṃcitsaṃbhavati tadutthaṃ yattadeva tat
]

`v 35 [
brahmatattvaṃ vinā neha kiṃcidevopapadyate |
sarvaṃ ca khalvidaṃ brahmetyeṣaiva paramārthatā
]

`v 36 [
evaṃprāyaśca he prājña siddhāntaste bhaviṣyati |
tatraivodāhariṣyāpaḥ siddhāntārthoktipañjaram
]

`v 37 [
ihāvidyādikāḥ kecidvidyante netarakramāḥ |
jñāsyasyalamaśeṣārthāṃstattadajñānasaṃkṣaye
]

`v 38 [
avastusaṃkṣaye vastu yathāvastu prasīdati |
yathā ca dṛśyate dṛśyaṃ jagannaiśatamaḥkṣaye
]

`v 39 [
yadidamakhilamātataṃ kudṛṣṭyā
tadupaśame tava rāma nirmalābhe |
avitathapadanirmale bhaviṣya-
tyavitathameva na saṃśayo'tra kaścit
]