`v 1 [
ekonatriṃśaḥ sargaḥ 29
śrīvasiṣṭha uvāca |
evaṃprāyākulārambhairasurairasuhāribhiḥ |
sahasā hṛtasaṃrabdhairārabdhaḥ sumahān raṇaḥ
]

`v 2 [
māyayātha vivādena sandhinā vigraheṇa ca |
palāyanena dhairyeṇa cchannagopāyanena ca
]

`v 3 [
kārpaṇyenāstrayuddhena svāntardhānaiśca bhūriśaḥ |
dhṛtaḥ sa saṃgaro devaistriṃśadvarṣāṇi pañcakam
]

`v 4 [
varṣāṇi divasānmāsāndaśāṣṭau sapta pañca ca |
varṣāṇi peturvṛkṣāgnihetyekāśanibhūbhṛtām
]

`v 5 [
etāvatā tu kālena dṛḍhābhyāsādahaṃkṛteḥ |
dāmādayo'hamityāsthāṃ jagṛhurgrastacetasaḥ
]

`v 6 [
naikaṭyātiśayādyadvaddarpaṇaṃ bimbavadbhavet |
abhyāsātiśayāttadvatte sāhaṃkāratāṃ gatāḥ
]

`v 7 [
yadvaddūragataṃ vastu nādarśe pratibimbati |
padārthavāsanā tadvadanabhyāsānna jāyate
]

`v 8 [
yadā dāmādayo jātā ahaṃkārātmavāsanāḥ |
tadā me jīvitaṃ me'rtha iti dainyamupāgatāḥ
]

`v 9 [
bhavavāsanayā grastā mohavāsanayā tataḥ |
āśāpāśanibaddhāste tataḥ kṛpaṇatāṃ gatāḥ
]

`v 10 [
mugdheva hyanahaṃkarairmamatvamupakalpitam |
rajjvāṃ bhujaṅgatvamiva dāmavyālakaṭaistataḥ
]

`v 11 [
āpādamastako dehaḥ kathaṃ me bhavatu sthiraḥ |
mameti tṛṣṇākṛpaṇā dīnatāṃ te samāyayuḥ
]

`v 12 [
sthiro bhavatu me dehaḥ sukhāyāstu dhanaṃ mama |
iti baddhadhiyāṃ teṣāṃ dhairyamantarddhimāyayau
]

`v 13 [
savāsanatvādvapuṣāmalpasattvātsuradviṣām |
yā tu prahāraparatā mārjitevāśu sābhavat
]

`v 14 [
kathaṃ surā jagatyasminbhavāma iti cintayā |
vivaśā dīnatāṃ jagmuḥ padmā iva nirambhasaḥ
]

`v 15 [
teṣāṃ yoṣānnapānena svāhaṃkṛtimatāṃ ratiḥ |
babhūva bhāvabhāvasthā bhīṣaṇā bhavabhājinī
]

`v 16 [
atha tasminraṇe bhītyā sāpekṣatvamupāyayuḥ |
mattebhaganasaṃrabdhe vane hariṇakā iva
]

`v 17 [
mariṣyāmo mariṣyāma iti cintāhatāśayāḥ |
mandaṃ mandaṃ kila bhremuḥ kupitairāvaṇe raṇe
]

`v 18 [
śarīraikārthināṃ teṣāṃ bhītānāṃ maraṇādapi |
alpasattvatayā mūrdhni kṛtameva paraiḥ padam
]

`v 19 [
atha pramlānasattvāste hantumagragataṃ bhaṭam |
na śekurindhane kṣīṇe havirdagdhumivāgnayaḥ
]

`v 20 [
vibudhānāṃ praharatāṃ maśakatvamupāgatāḥ |
kṣatavikṣatasaṃghātāstasthuḥ sāmānyasadbhaṭāḥ
]

`v 21 [
bahunātra kimuktena maraṇādbhītacetasaḥ |
daityā deveṣu valgastu dudruvuḥ samarājirāt
]

`v 22 [
teṣu dravatsu bhīteṣu sarvato dānavādiṣu |
dāmavyālakaṭākhyeṣu vikhyāteṣu surālaye
]

`v 23 [
taddaityasainyaṃ nyapatadvidrutaṃ khāditastataḥ |
kalpāntapavanodbhūtaṃ `note[pavanoddhūtaṃ iti pāṭhaḥ]
tārājālamivābhitaḥ
]

`v 24 [
amarācalakuñjeṣu śikharāṇāṃ śikhāsu ca |
taṭeṣu vārirāśīnāṃ payodapaṭaleṣu ca
]

`v 25 [
sāgarāvartagarteṣu śvabhreṣūdyatsaritsu ca |
jaṅgaleṣu diganteṣu jvalatsu vipineṣu ca
]

`v 26 [
tadbāṇocchinnadeśeṣu grāmeṣu nagareṣu ca |
aṭavīṣūgrapakṣāsu marubhūmidavāgniṣu
]

`v 27 [
lokālokācalānteṣu parvateṣu hradeṣu ca |
āndhradraviḍakāśmīrapārasīkapureṣu ca
]

`v 28 [
nānāmbhodhitaraṅgāsu gaṅgājalaghaṭāsu ca |
dvipāntareṣu jāleṣu jambukhaṇḍalatāsu ca
]

`v 29 [
sarvataḥ parvatākārāḥ patitāste surārayaḥ |
visphoṭitāṅgacaraṇā vibhinnakarabāhavaḥ
]

`v 30 [
śākhālagnāntratantrīkā muktaraktabharacchaṭāḥ |
vyastaśekharamūrdhāno niṣkrāntāḥ kupitekṣaṇāḥ
]

`v 31 [
sāyudhā balamāyeṣucchinnakaṅkaṭahetayaḥ |
dūrāpātaviparyastapatannānāyudhāṃśukāḥ
]

`v 32 [
kaṇṭhalambiśirastrāṇacaṭatkārograbhītayaḥ |
śikhāśataśilāprotā dehabhāgavilambinaḥ
]

`v 33 [
śālmalyugradṛḍhāpātakaṭatkaṇṭakasaṃkaṭāḥ |
suśilāphalakāsphālaśatadhāśīrṇamastakāḥ
]

`v 34 [
sarva eva sakalāyudhaśastra-
pātamātrasamanantarameva |
dikṣu nāśamagamannasurendrāḥ
pāṃsavo'mbudanidhau payasīva
]