`v 1 [
aṣṭacatvāriṃśaḥ sargaḥ 48
śrīvasiṣṭha uvāca |
kriyāviśeṣabahulā bhogaiśvaryahatāśayāḥ |
nāpekṣante yadā satyaṃ na paśyanti śaṭhāstadā
]

`v 2 [
ye tu pāraṃ gatā buddherindriyairna vaśīkṛtāḥ |
ta enāṃ jāgatīṃ māyāṃ paśyanti karabilvavat
]

`v 3 [
tarhi ke paśyanti tānāha - ye tviti | māyāgrahaṇaṃ satyasyāpyupalakṣaṇam | 2
|
tucchāṃ tāṃ jāgatīṃ māyāṃ dṛṣṭvā jīvo vicāravān |
ahaṃkāramayīṃ māyāṃ tyajatyahiriva tvacam
]

`v 4 [
asaktatāṃ tato'bhyetya punā rāma na jāyate |
kṣetreṣvapi ciraṃ tiṣṭhanbījaṃ dagdhamivāgninā
]

`v 5 [
ādhivyādhiparītāya prātarvādya vināśine |
prayatante śarīrāya hitamajñāstu nātmane
]

`v 6 [
tvamapyajñavadajñasya śarīrasya samīhitam |
mā saṃpādaya duḥkhāya bhavātmaikaparāyaṇaḥ
]

`v 7 [
śrīrāma uvāca |
dāśūrākhyāyikeveyaṃ sukhasaṃsāracakrikā |
kalpanāracitākārā vastuśūnyeti kiṃ prabho
]

`v 8 [
śrīvasiṣṭha uvāca |
jaganmāyāsvarūpasya varṇanāvyapadeśataḥ |
dāśūrākhyāyikāṃ rāma varṇyamānāṃ mayā śṛṇu
]

`v 9 [
astyasminvasudhāpīṭhe vicitrakusumadrumaḥ |
māgadho nāma vikhyātaḥ śrīmāñjanapado mahān
]

`v 10 [
kadambavanavistāralīlāvalitajaṅgalaḥ |
vicitravihagavyūhasarvāścaryamanoharaḥ
]

`v 11 [
sasyasaṃkaṭasīmāntaḥ puropavanamaṇḍitaḥ |
kamalotpalakahlārapūrṇasarvasarittaṭaḥ
]

`v 12 [
udyānadolāvilasallalanāgeyaghuṃghumaḥ |
niśopabhuktakusumanīrandhraviśikhāvaniḥ
]

`v 13 [
tatraikasmingiritaṭe karṇikārasamākule |
kadalīkhaṇḍanīrandhranīpagulmavirājite
]

`v 14 [
puṣpaughasphūrjadanile kesarāruṇadhūlini |
kāraṇḍavakṛtārāve rasatsarasasārase
]

`v 15 [
tasminnagavare puṇye vicitravihagadrume |
kaścitparamadharmātmā munirāsīnmahātapāḥ
]

`v 16 [
dāśūranāmā mahatā tapoyogena saṃyutaḥ |
kadambapṛṣṭhavāstavyo vītarāgo mahāmatiḥ
]

`v 17 [
śrīrāma uvāca |
asau tapasvī bhagavanvipine kena hetunā |
kathaṃ cāpyavasatpṛṣṭhe kadambasya mahātaroḥ
]

`v 18 [
śrīvasiṣṭha uvāca |
śaralometi vikhyātaḥ pitā tasya babhūva ha |
rāmā'para iva brahmā tasminnevāvasadgirau
]

`v 19 [
tasyāsāvekaputro'bhūtkaco devaguroriva |
tena sārdhaṃ sa putreṇa nītavāñjīvitaṃ vane
]

`v 20 [
athāsau śaralomātra bhuktvā yugagaṇaṃ yayau |
tyaktadehaḥ surāgāraṃ muktanīḍaḥ khago yathā
]

`v 21 [
eka eva vane tasmindāśūraḥ praruroda ha |
daśāpanītapitṛkaḥ karuṇaṃ kuraro yathā
]

`v 22 [
mātāpitṛviyogena śokasaṃtāpitāśayaḥ |
mlānimabhyāyayau nūnaṃ hemanta iva paṅkajam
]

`v 23 [
bālo'sāvatidīnātmā vanadevatayā vane |
itthamāśvāsito rāma tadā'dṛśyaśarīrayā
]

`v 24 [
ṛṣiputra mahāprājña kimajña iva rodiṣi |
saṃsārasya na kasmāttvaṃ svarūpaṃ vetsi cañcalam
]

`v 25 [
sarvadaivedṛśī sādho saṃsāre saṃsṛtiścalā |
jāyate jīvyate paścādavaśyaṃ ca vinaśyati
]

`v 26 [
yadyatkiṃciddṛśyadṛśi brahmādikamidaṃ mune |
gantavyastena sarveṇa vināśo nātra saṃśayaḥ
]

`v 27 [
tadarthaṃ mā kṛthā vyarthaṃ viṣādaṃ maraṇe pituḥ |
avaśyabhāvyastamayo jātasyāharpateriva
]

`v 28 [
aśarīrāmiti śrutvā giramāraktalocanaḥ |
dhairyamāsādayāmāsa śikhaṇḍī stanitādiva
]

`v 29 [
utthāyāvaśyakaṃ kṛtvā pāścātyaṃ piturādarāt |
cakāra tapase buddhiṃ dṛḍhāmuttamasiddhaye
]

`v 30 [
brāhmeṇa karmaṇā tasya vipine caratastapaḥ |
anantasaṃkalpamayaṃ śrotriyatvaṃ babhūva ha
]

`v 31 [
ajñātajñeyabuddheastu śrotriyasya tayā tayā |
na viśaśrāma ceto'sya pavitre'pi dharātale
]

`v 32 [
kevalaṃ sarvamevedamapi śuddhaṃ dharātalam |
aśuddhamiva paśyansa na reme kvacideva hi
]

`v 33 [
atha saṃkalpayāmāsa svasaṃkalpanayaiva saḥ |
vṛkṣāgrameva saṃśuddhaṃ sthitistatrocitā mama
]

`v 34 [
tadidānīṃ tapastapsye tapasā yena śākhiṣu |
svagavatsthitimāpnomi śākhāsu ca daleṣu ca
]

`v 35 [
iti saṃcintya saṃjvālya hutāśamatibhāsvaram |
juhāva tasminprotkṛttya māṃsaṃ svaskandhabhittitaḥ
]

`v 36 [
atha gīrvāṇavṛndasya samagrā galabhittayaḥ |
manmukhatvena mā yāntu vipramāṃsena bhasmatām
]

`v 37 [
iti saṃcintya bhagavānsaptārcistasya devatā |
puro babhūva dīptāṃśurdīptāṃśurvākpateriva
]

`v 38 [
uvāca vacanaṃ dhīraṃ `note[dhīraṃ iti dvitīyaikavacanasthāne dhīra iti
saṃbuddhiṣṭīkākṛtorarīkaraṇātsusvārasyācca sa eva pāṭhaḥ
samīcīnaḥ] kumārābhimataṃ varam |
gṛhāṇa sthāpitaṃ sādho kośākāśānmaṇiṃ yathā
]

`v 39 [
ityuktavantamanalamarghapuṣpeṇa śobhinā |
saṃpūjya stutivādena prāha viprakumārakaḥ
]

`v 40 [
bhagavan bhūtapūrṇāyā bhuvaḥ pāvanamaṇḍalam |
nāpnomi tena vṛkṣāṇāmupari sthitirastu me
]

`v 41 [
ityukte muniputreṇa sarvadevamukhaṃ śikhī |
evamastu tavetyuktvā jagāmāntarddhimīśvaraḥ
]

`v 42 [
tasminnantarhite deve kṣaṇātsāndhya ivāmbuje |
pūrṇakāmaḥ kumāro'sau pūrṇenduriva cābabhau
]

`v 43 [
adhigatābhimatānanamaṇḍala-
dyutibhareṇa jahāsa sa tuṣṭimān |
śaśinamāptakalākulamambujaṃ
vikasitaṃ ca sitasmitaśobhinā
]