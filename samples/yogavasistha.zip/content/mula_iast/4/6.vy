`v 1 [
ṣaṣṭhaḥ sargaḥ 6
śrīvasiṣṭha uvāca |
atha tāṃ manasā dhyāyaṃstatraivāmīlitekṣaṇaḥ |
ārabdhavānmanorājyamidamekaḥ kilośanā
]

`v 2 [
eṣā hi lalanā vyomni sahasranayanālaye |
saṃprāpto'yamahaṃ svargamālolasurasundaram
]

`v 3 [
ime te mṛdumandārakusumottaṃsasundarāḥ |
dravatkanakaniṣyandavilāsivapuṣaḥ surāḥ
]

`v 4 [
imāstā locanollāsadṛṣṭanīlābjadṛṣṭayaḥ |
mugdhahāsavilāsinyaḥ kāntā hariṇadṛṣṭayaḥ
]

`v 5 [
ime te kausumoddyotā anyonyapratibimbitāḥ |
viśvarūpopamākārā maruto mattakāśinaḥ
]

`v 6 [
airāvaṇakaṭāmodaviraktamadhupaśrutāḥ |
imāstāḥ kākalīgītā gīrvāṇagaṇagītayaḥ
]

`v 7 [
iyaṃ sā kanakāmbhojacaladvairiñcasārasā |
mandākinītaṭodyānaviśrāntasuranāyakā
]

`v 8 [
ete te yamacandrendrasūryānalajalānilāḥ |
lokapālāstanudyotakīrṇadīptānalārciṣaḥ
]

`v 9 [
ayaṃ sa raṇavṛttāntahetikaṇḍūyitānanaḥ |
airāvaṇo raṇe dantaprotadaityendramaṇḍalaḥ
]

`v 10 [
ime te bhūtalasthānādvyomni tārakatāṃ gatāḥ |
vaimānikāścaraccārucāmīkaramayātapāḥ
]

`v 11 [
carantaḥ prasarantaścārucāmīkaramayā iva ātapā dehavimānādikāntayo yeṣām |
10 |
merūpalatalāsphālasīkarākīrṇadevatāḥ |
etāstāḥ kīrṇamandārā gaṅgāsalilavīcayaḥ
]

`v 12 [
etāḥ prasṛtamandāramañjarīpuñjapiñjarāḥ |
dolālolāpsaraḥśreṇyaḥ śakropavanavīthayaḥ
]

`v 13 [
ime te kundamandāramakarandasugandhayaḥ |
candrāṃśunikarākārāḥ pārijātasamīraṇāḥ
]

`v 14 [
puṣpakesaranīhārapaṭavāsaraṇotsukaiḥ |
latāṅganāgaṇairvyāptamidaṃ tannandanaṃ vanam
]

`v 15 [
kāntagītaravānandapranartitasurāṅganau |
imau tau vallakīsnigdhasvarau nāradatumburū
]

`v 16 [
ime te puṇyakartārau bhūribhūṣaṇabhūṣitāḥ |
vyomanyuḍḍīyamāneṣu vimāneṣu ca saṃsthitāḥ
]

`v 17 [
madamanmathamattāṅgya imāstāḥ surayoṣitaḥ |
deveśvaraṃ niṣevante vanaṃ vanalatā iva
]

`v 18 [
indrāśmajālakusumāścintāmaṇigulucchakāḥ |
kalpavṛkṣā ime pakvaphalastabakadanturāḥ
]

`v 19 [
iha tāvadimaṃ śakramahamāsanasaṃsthitam |
dvitīyamiva trailokyasraṣṭāramabhivādaye
]

`v 20 [
iti saṃcintya śukreṇa manasaiva śacīpatiḥ |
tenābhivāditastatra dvitīya iva khe bhṛguḥ
]

`v 21 [
atha sādaramutthāya śukraḥ śakreṇa pūjitaḥ |
gṛhītahasta ānīya samīpamupaveśitaḥ
]

`v 22 [
dhanyastvadāgame nātha svargo'yaṃ śukra śobhate |
uṣyatāṃ cirameveha śakra itthamuvāca tam
]

`v 23 [
atha tatropaviśyāsau bhārgavaḥ śobhitānanaḥ |
śriyaṃ jahāra śaśinaḥ sakalasyāmalasya ca
]

`v 24 [
sakalasuragaṇābhivandito'sau
bhṛgutanayaḥ śatamanyupārśvasaṃsthaḥ |
cirataramatulāmavāpa tuṣṭiṃ
narapatisattamalālanaṃ babhūva
]