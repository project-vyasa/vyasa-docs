`v 1 [
trayastriṃśaḥ sargaḥ 33
śrīvasiṣṭha uvāca |
sarvātiśayasāphalyātsarvaṃ sarvatra sarvadā |
saṃbhavatyeva tasmāttvaṃ śubhodyogaṃ na saṃtyaja
]

`v 2 [
mitrasvajanabandhūnāṃ nandinānandadāyinā |
sarasīśānamāsādya mṛtyurapyupanirjitaḥ
]

`v 3 [
sarvotkarṣeṇa saṃpannā devā api vimarditāḥ |
dānavairdānavārthāḍhyairgajaiḥ padmākarā iva
]

`v 4 [
maruttanṛpateryajñe saṃvartena maharṣiṇā |
brahmaṇevāparaḥ sargo bhāvitaḥ sasurāsuraḥ
]

`v 5 [
mahātiśayayuktena viśvāmitreṇa vipratā |
bhūyobhūyaḥ prayuktena duṣprāpā tapasārjitā
]

`v 6 [
piṣṭasekāmbu duṣprāpaṃ rasāyanavadaśnatā |
durbhagenedṛśenāptaḥ kṣīroda upamanyunā
]

`v 7 [
trailokyamallāṃstṛṇavadaśnanviṣṇvabjajādikān |
bhaktyātiśayadārḍhyena kālaḥ śvetena kālitaḥ
]

`v 8 [
praṇayena yamaṃ jitvā kṛtvā vacanasaṃgamam |
paralokādupānītaḥ sāvitryā satyavānpatiḥ
]

`v 9 [
na so'styatiśayo loke yasyāsti na phalaṃ sphuṭam |
bhavitavyaṃ vicāryāntaḥ sarvātiśayaśālinā
]

`v 10 [
ātmajñānamaśeṣāṇāṃ sukhaduḥkhadaśādṛśām |
mūlakāṣakaraṃ tasmādbhāvyaṃ tatrātiśāyinā
]

`v 11 [
nāśāyāpadgatārthinyā dṛṣṭyā dṛśyādidṛṣṭayaḥ |
duḥkhādṛte nirābādhaṃ sukhaṃ kiṃ cidavāpyate
]

`v 12 [
aśamaḥ paramaṃ brahma śamaśca paramaṃ padam |
yadyapyevaṃ tathāpyenaṃ prathamaṃ viddhi śaṃkaram
]

`v 13 [
abhimānaṃ parityajya śamamāśritya śāśvatam |
vicārya prajñayāryatvaṃ kuryātsajjanasevanam
]

`v 14 [
na tapāṃsi na tīrthāni na śāstrāṇi jayanti ca |
saṃsārasāgarottāre sajjanāsevanaṃ vinā
]

`v 15 [
lobhamoharuṣāṃ yasya tanutānudinaṃ bhavet |
yathāśāstraṃ viharati svasvakarmasu sajjanaḥ
]

`v 16 [
athātmaviduṣāṃ saṅgāttasya sādhoḥ pravartate |
atyantābhāva evāsya yathā dṛśyasya dṛśyate
]

`v 17 [
dṛśyātyantābhāvatastu paramevāvaśiṣyate |
anyābhāvavaśādāśu jīvastatraiva līyate
]

`v 18 [
nacotpannaṃ nacaivāsīddṛśyaṃ naca bhaviṣyati |
vartamāne'pi naivāsti paramevāstyavedhitam
]

`v 19 [
evaṃ yuktisahasreṇa darśitaṃ dṛśyate'pi ca |
sarvairevānubhūtaṃ ca darśayiṣyāmi cādhunā
]

`v 20 [
tathedamamalaṃ śāntaṃ trijagatsaṃvidambaram |
idaṃ tattvamatattvādi kuto'tra syātkathaṃ ca vā
]

`v 21 [
ciccamatkurute cāru cañcalā'cañcalātmani |
yattayaiva tadevedaṃ jagadityavabudhyate
]

`v 22 [
trailokyabhūyonubhavaścidādityāṃśumaṇḍalam |
ko vā svāṃśumatorbhedo nirvikalpaḥ sa kathyatām
]

`v 23 [
svābhāvato'syāściddṛṣṭerye `note[cidvṛtteriti pāṭhaścettarhi
vyākhyānukūlaḥ syāt] unmeṣanimeṣaṇe |
jagadrūpānubhūtestāvetāvastamayodayau
]

`v 24 [
ahamartho'parijñātaḥ paramārthāmbare malam |
parijñāto'hamarthastu paramātmāmbaraṃ bhavet
]

`v 25 [
ahaṃbhāvaḥ parijñāto nāhaṃbhāvo bhavatyalam |
ekatāmambunevāmbu yāti cinnabhasātmanā
]

`v 26 [
ahamādijagaddṛśyaṃ kila nāstyeva vastutaḥ |
avaśyameva tattasmācchiṣyate'haṃvicārataḥ
]

`v 27 [
bādhyate cāmaladhiyāmapiśāce piśācadhīḥ |
śiśūnāṃ tāvadādhvāntaḥkaraṇānāṃ vicāraṇā
]

`v 28 [
cijjyotsnā yāvadevāntarahaṃkāraghanāvṛtā |
vikāsayati no tāvatparamārthakumudvatīm
]

`v 29 [
pramārjite'hamityasminpade svārthe svayaṃ vinā |
narakasvargamokṣāditṛṣṇāyāḥ kalpanaiva kā
]

`v 30 [
hṛdi yāvadahaṃbhāvo vāridaḥ pravijṛmbhate |
tāvadvikāsamāyāti tṛṣṇākuṭajamañjarī
]

`v 31 [
ākramya cetanāṃ nityamahaṃkārāmbude sthite |
jāḍyameva sthitiṃ yāti na prakāśaḥ kadācana
]

`v 32 [
asannayamahaṃkāraḥ svayaṃ mithyā prakalpitaḥ |
duḥkhāyaiva na harṣāya bālasaṃbhramayakṣavat
]

`v 33 [
mudhaiva kalpito mohamahaṃbhāvaḥ prayacchati |
anantasaṃsārakaraṃ dāmādiṣviva durmatau
]

`v 34 [
ayaṃ so'hamiti sphārānmohādanyatarattamaḥ |
anarthabhūtaṃ saṃsāre na bhūtaṃ na bhaviṣyati
]

`v 35 [
yatkiṃcididamāyāti sukhaduḥkhamalaṃ bhave |
tadahaṃkāracakrasya pravikāro vijṛmbhate
]

`v 36 [
ahaṃkārāṅkuraḥ kṛṣṭo hṛdayenāvaropitaḥ |
sahasraśākhaṃ duśchedaṃ tasya saṃsṛtināśanam
]

`v 37 [
ahaṃbhāvo'ṅkuro janma vṛkṣāṇāmakṣayātmanām |
mamedamiti vistīrṇāsteṣāṃ śākhāḥ sahasraśaḥ
]

`v 38 [
karaṭāpātavisphoṭā bhāntyarthā vāsanādayaḥ |
vicāryacāruravavattaraṅgavarapaṅktivat
]

`v 39 [
ahaṃbhāvanayā bhāti tvamahaṃbhāvavarjitaḥ |
saṃsāracakravahanamātmanaḥ parirodhayā
]

`v 40 [
ahaṃbhāvatamo yāvajjanmāraṇye vijṛmbhate |
tāvadetā vivalganti cintāmattāḥ piśācikāḥ
]

`v 41 [
ahaṃkārapiśācena gṛhīto yo narādhamaḥ |
na śāstrāṇi na mantrāśca tasyābhāvasya siddhaye
]

`v 42 [
śrīrāma uvāca |
kenopāyena bhagavannahaṃkāro na vardhate |
taṃ tvaṃ kathaya me brahmansaṃsārabhayaśāntaye
]

`v 43 [
śrīvasiṣṭha uvāca |
cinmātradarpaṇākāre nirmale svātmani sthite |
iti bhāvānusaṃdhānādahaṃkāro na vardhate
]

`v 44 [
iti uktaprakārasya bhāvasya svātmasvabhāvasyānusaṃdhānāt sadā
smaraṇātsvātmani cinmātradarpaṇākāre nirmale sthite sati ahaṃkāro na vardhate |
43 |
mithyeyamindrajālaśrīḥ kiṃ me snehavirāgayoḥ |
ityantarānusaṃdhānādahaṃkāro na jāyate
]

`v 45 [
nāhamātmani no yasya dṛśyaśriya iti svayam |
śāntena vyavahāreṇa nāhaṃkāraḥ pravardhate
]

`v 46 [
ahaṃ hi jagadityantarheyādeyadṛśoḥ kṣaye |
samatāyāṃ prasannāyāṃ `note[prapannāyāṃ ktyubhayatra pāṭhaḥ
kvacit] nāhaṃbhāvaḥ pravardhate
]

`v 47 [
ahaṃ cijjagadityantarheyādeyadṛśoḥ kṣaye |
samatāyāṃ prasannāyāṃ `note[prapannāyāṃ ktyubhayatra pāṭhaḥ
kvacit] nāhaṃbhāvaḥ pravardhate
]

`v 48 [
śrīrāma uvāca |
kimākṛtirahaṃkāraḥ kathaṃ saṃtyajyate prabho |
saśarīro'śarīraśca tyakte tasmiṃśca kiṃ bhavet
]

`v 49 [
śrīvasiṣṭha uvāca |
trividho rāghavāstīha tvahaṃkāro jagattraye |
dvau śreṣṭhāvitarastyājyaḥ śṛṇu tvaṃ kathayāmi te
]

`v 50 [
ahaṃ sarvamidaṃ viśvaṃ paramātmāhamacyutaḥ |
nānyadastīti paramā vijñeyā sā hyahaṃkṛtiḥ
]

`v 51 [
mokṣāyaiṣā na bandhāya jīvanmuktasya vidyate |
sarvasmādvyatirikto'haṃ vālāgraśatakalpitaḥ
]

`v 52 [
iti yā saṃvideṣāsau dvitīyāhaṃkṛtiḥ śubhā |
mokṣāyaiṣā na bandhāya jīvanmuktasya vidyate
]

`v 53 [
ahaṃkārābhidhā yā sā kalpyate natu vāstavī |
pāṇipādādimātro'yamahamityeṣa niścayaḥ
]

`v 54 [
ahaṃkārastṛtīyo'sau laukikastuccha eva saḥ |
varjya eva durātmāsau śatrureva `note[kandaḥ saṃsārasaṃtateḥ iti
pāṭhaḥ] paraḥ smṛtaḥ
]

`v 55 [
anenābhihato janturna bhūyaḥ parirohati |
ripuṇānena balinā vividhādhipradāyinā
]

`v 56 [
kaṣṭīkṛtamatirlokaḥ saṃkaṭeṣveva majjati |
anayā durahaṃkṛtyā bhāvātsaṃsaktayā ciram
]

`v 57 [
śiṣṭāhaṃkāravāñjanturbhagavānyāti muktatām |
lokāhaṃkāravaddoṣavapurasminnirūpaṇaḥ
]

`v 58 [
na deho'smīti nirṇīya varjanaṃ mahatāṃ matam |
prathamaṃ dvāvahaṃkārāvaṅgīkṛtyāntyalaukikau
]

`v 59 [
prathamaṃ dvāvahaṃkārāvaṅgīkṛtyāntyalaukikau |
tṛtīyāhaṃkṛtistyājyā laukikī duḥkhadāyinī
]

`v 60 [
anayā durahaṃkṛtyā dāmavyālakaṭāḥ kila |
tāṃ daśāṃ samanuprāptā yā kathāsvapi khedadā
]

`v 61 [
śrīrāma uvāca |
tṛtīyāṃ laukikīmetāṃ tyaktvā cittādahaṃkṛtim |
kiṃbhāvaḥ puruṣo brahmanprāpnuyādātmano hitam
]

`v 62 [
śrīvasiṣṭha uvāca |
eṣā tāvatparityājyā tyaktvaitāṃ duḥkhadāyinīm |
yathā yathā pumāṃstiṣṭhetparameti tathā tathā
]

`v 63 [
ahaṃkāradṛśāvete pūrvokte bhāvayanyadi |
tiṣṭhedupaiti paramaṃ tatpadaṃ puruṣa'nagha
]

`v 64 [
atha te api saṃtyajya sarvāhaṃkṛtivarjitaḥ |
saṃtiṣṭheta tathātyuccaiḥ padamevādhirohati
]

`v 65 [
sarvadā sarvayatnena laukikī durahaṃkṛtiḥ |
paramānandabodhāya varjanīyā'nayā dhiyā
]

`v 66 [
śarīrāsthāmayāpuṇyadurahaṃkāravarjanam |
atyantaparamaṃ śreya etadeva paraṃ padam
]

`v 67 [
bhāvādahaṃkṛtiṃ tyaktvā sthūlāmetāṃ hi laukikīm |
tiṣṭhanvyavaharanvāpi na naraḥ prapatatyadhaḥ
]

`v 68 [
saṃśāntāhaṃkṛterjantorbhogā rogā mahāmate |
na svadante sutṛptasya yathā prativiṣā rasāḥ
]

`v 69 [
bhogeṣvasvadamāneṣu puṃsaḥ śreyaḥ puro gatam |
kṣīṇe'ndhakāre kiṃ nāma manaso'nyatpravartate
]

`v 70 [
pratibandhanirāsātpurogatamiva bhavatīti śeṣaḥ | manasaḥ andhakāre
andhakāravadagrahaṇānyathāgrahaṇanimitte'haṃkāre kṣīṇe satyanyatkiṃ
pratibandhakaṃ pravartate yena śreyaḥprāptivighātaḥ syāt | na kiṃcidityarthaḥ | 69
|
ahaṃkārānusaṃdhānavarjanādeva rāghava |
pauruṣeṇa prayatnācca tīryate bhavasāgaraḥ
]

`v 71 [
nāhaṃ na tena mama kiṃcidapīti matvā
sarvaṃ ca me sakalamapyahameva ceti |
labdhāspadaṃ manasi saṃvidamevamīḍyāṃ
nītvā sthitiṃ paramupaiti padaṃ mahātmā
]