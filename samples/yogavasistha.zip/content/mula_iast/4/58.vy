`v 1 [
aṣṭapañcāśaḥ sargaḥ 58
śrīvasiṣṭha uvāca |
atraiva vastunyuditā śṛṇu rāghava pūrvajāḥ |
kacena gāthā yā gītā bārhaspatyena pāvanāḥ
]

`v 2 [
kasmiṃścinmerugahane'tiṣṭhansuraguroḥ sutaḥ |
kadācidabhyāsavaśādviśrāntiṃ prāpa cātmani
]

`v 3 [
abhyāsavaśāt śrutāyā brahmavidyāyā mananamididhyāsanaparipākāditi yāvat |
2 |
samyagjñānāmṛtāpūrṇā matirnāramatāsya sā |
pañcabhūtamaye'mānye dṛśye'sminpelavātmani `note[dṛśyaḥ iti
pāṭhaḥ]
]

`v 4 [
sa tena nirviṇṇa iva sadātmatvādṛte padam |
apaśyansamuvācedameko gadgadayā girā
]

`v 5 [
kiṃ karomi kva gacchāmi kiṃ gṛhṇāmi tyajāmi kim |
ātmanā pūritaṃ viśvaṃ mahākalpāmbunā yathā
]

`v 6 [
duḥkhamātmā sukhaṃ caiva khamāśāsumahattayā |
sarvamātmamayaṃ jñātaṃ naṣṭakaṣṭo'hamātmanā
]

`v 7 [
sabāhyābhyantare dehe adhaścordhvaṃ ca dikṣu ca |
ita ātmā tataścātmā nāstyanātmamayaṃ kvacit
]

`v 8 [
sarvatraiva sthito hyātmā sarvamātmamayaṃ sthitam |
sarvamevedamātmaivamātmanyeva bhavāmyaham
]

`v 9 [
yannāma nāma tatkiṃcitsarvamevāhamāntaraḥ |
āpūritāpāranabhāḥ sarvatra sanmayaḥ sthitaḥ
]

`v 10 [
pūrṇastiṣṭhāmi modātmā sukhamekārṇavopamaḥ |
ityevaṃ bhāvayaṃstatra kanakācalakuñjake
]

`v 11 [
uccārayannoṅkāraṃ ca ghaṇṭāsvanamiva kramāt |
oṃkārasya kalāmātraṃ pāścātyaṃ vālakomalam |
nāntarastho na bāhyastho bhāvayanparame hṛdi
]

`v 12 [
vyapagatakalanākalaṅkaśuddho
hṛdayanirantaralīnavātavṛttiḥ |
gataghanaśaradāśayopamānaḥ
sthita iti rāma kacaḥ sa gāyamānaḥ
]