`v 1 [
dāśūropākhyānaṃ samāptam |
ṣaṭpañcāśaḥ sargaḥ 56
śrīvasiṣṭha uvāca |
nāstīdamiti nirṇīya sarvatastyaja rañjanām |
yannāsti tatprati kila kevāstheha vicāriṇām
]

`v 2 [
dṛśyamānamathedaṃ cedasti sattāmupāgatam |
tiṣṭha svātmani badhnāsi tvaṃ kimatra kilātmatām
]

`v 3 [
atha cedasti nāstīdamiti niścayavānasi |
tathāpi bhāvanāsaṅgaḥ kathaṃ yuktaścalācale
]

`v 4 [
nedamasti jagadrāma tava nāsti mahāmate |
kevalaṃ svacchamevetthamātataṃ mitamīdṛśam
]

`v 5 [
nedaṃ kartṛkṛtaṃ kiṃcinna vā kartṛkṛtakramam |
svayamābhāsate cedaṃ kartrakartṛpadaṃ gatam
]

`v 6 [
akartṛkaṃ jagajjālaṃ bhavatvatha sakartṛkam |
mā tvametena śabalaṃ bhāvayannāsva cetasi
]

`v 7 [
sarvendriyavihīnātmā karteva sa jaḍopamaḥ |
akartṛ ca tadā manye kākatālīyavajjagat
]

`v 8 [
kākatālīyayogena jātaṃ yatkiṃcideva tat |
tasminbhāvānusaṃdhānaṃ bālo badhnāti netaraḥ
]

`v 9 [
na kadācididaṃ śāntaṃ jagadrāma na ca kṣayi |
ajasraṃ dṛśyamānatvādbhāvitvācca punaḥ punaḥ
]

`v 10 [
na kadācididaṃ cāsti jagadrāma na ca kṣayi |
ajasraṃ kṣīyamāṇatvānāstitvāccānumānataḥ
]

`v 11 [
sarvendriyapadātīto yadā karteha vijvaraḥ |
kurvāṇaḥ sarvadā khedaṃ na kadācana gacchati
]

`v 12 [
teneyaṃ niyatiḥ prauḍhā bhāvābhāvadaśāmayī |
īdṛśyeva sthirā dīrghā mithyotthāpi ca dṛśyate
]

`v 13 [
aparyantasya kālasya kaścidaṃśaḥ śaracchatam |
tāvanmātramahāścaryaḥ kimarthaṃ so'nudhāvati
]

`v 14 [
śaracchataṃ mānuṣadehajīvanaparamāvadhiḥ kālaḥ | anādyanantayoḥ
pūrvottarakālayoḥ kadāpyasattvādatyantāsaṃbhāvitaṃ tāvatkālamātraṃ
mahadatidṛḍhaṃ manuṣyadehātmatālakṣaṇamāścaryaṃ yasya tathāvidhaḥ san
sa sarvendriyapadātīta ātmā kimarthamanudhāvati | sarvathedamanucitamityarthaḥ |
13 |
sthirāścejjagatāṃ bhāvāstattvādāsthā na śobhate |
kathamanyonyasaṃśleṣo jaḍacetanayoḥ kila
]

`v 15 [
asthirāścejjagadbhāvāstadapyāsthā na śobhate |
payaḥphenāsthirasyānte duḥkhameṣā dadāti te
]

`v 16 [
āsthābandho mahābāho jagadbhāvatvamātmanaḥ |
na sthirāsthirayoḥ phenaśailayoriva rājate
]

`v 17 [
sarvakartāpyakarteva karotyātmā na kiṃcana |
tiṣṭhatyevamudāsīna ālokaṃ prati dīpavat
]

`v 18 [
kurvanna kiṃcitkurute divākāryamivāṃśumān |
gacchanna gacchati svasthaḥ svāspadastho raviryathā
]

`v 19 [
yataḥ kutaścidevedaṃ saṃpannamiva lakṣyate |
aruṇātīravadvāripūrāvartavadātatam
]

`v 20 [
iti cedbhavatā rāma naipuṇyenāvadhāritam |
pramāṇapariśuddhena cetasā na vicāritam
]

`v 21 [
tathāpi bhāvanāṃ sādho padārthaṃ prati nārhasi |
alātacakre svapne ca bhrame vā keva bhāvanā
]

`v 22 [
akasmādāgato jantuḥ sauhārdasya na bhājanam |
bhramodbhūtaṃ jagajjālamāsthāyāstanna bhājanam
]

`v 23 [
auṣṇyendau śītale bhānau mṛgatṛṣṇājale tathā |
yathā na bhāvayasyāsthāmevaṃ bhāvaya mā sthitau
]

`v 24 [
saṃkalpapuruṣasvapnajanadvīndutvavibhramam |
yathā paśyasi paśya tvaṃ bhāvajātamidaṃ tathā
]

`v 25 [
antarāsthāṃ parityajya bhāvaśrībhāvanāmayīm |
yo'si so'si jagatyasmiṁllīlayā viharānagha
]

`v 26 [
akartṛtvapadaṃ pītvā pītvecchāmapi kurvataḥ |
sarvabhāvāntarasthasya sarvātītasya cātmanaḥ
]

`v 27 [
iyaṃ saṃnidhimātreṇa niyatiḥ parijṛmbhate |
dīpasaṃnidhimātreṇa niricchaiva prakāśate
]

`v 28 [
abhrasaṃnidhimātreṇa kuṭajāni yathā svayam |
ātmasaṃnidhimātreṇa trijaganti tathā svayam
]

`v 29 [
sarvecchārahite bhānau yathā vyomani tiṣṭhati |
jāyate vyavahāraśca sati deve tathā kriyā
]

`v 30 [
niricche saṃsthite ratne yathālokaḥ pravartate |
sattāmātreṇa deve tu tathaivāyaṃ jagadgaṇaḥ
]

`v 31 [
ataḥ svātmani kartṛtvamakartṛtvaṃ ca saṃsthitam |
niricchatvādakartāsau kartā saṃnidhimātrataḥ
]

`v 32 [
sarvendriyādyatītatvātkartā bhoktā na sanmayaḥ |
indriyāntargatatvāttu kartā bhoktā sa eva hi
]

`v 33 [
dve etāmani vidyete kartṛtākartṛtānagha |
yayaiva paśyasi śreyastāmāśritya sthiro bhava
]

`v 34 [
sarvastho'hamakarteti dṛḍhabhāvanayānayā |
pravāhapatitaṃ kāryaṃ kurvannapi na lipyate
]

`v 35 [
yāti nīrasatāṃ janturapravṛtteśca cetasaḥ |
yasyāhaṃ kiṃcideveha na karomīti niścayaḥ
]

`v 36 [
bhogaughakāmavāṃstatra kaḥ karotu jahātu vā |
tasmānnityamakartāhamiti bhāvanayeddhayā
]

`v 37 [
paramāmṛtanāmnī sā samataivāvaśiṣyate |
atha sarvaṃ karomīti mahākartṛtayā tayā
]

`v 38 [
yadīcchasi sthitiṃ rāma tattāmapyuttamāṃ viduḥ |
aho yanna karomīmaṃ samagraṃ jāgataṃ bhramam
]

`v 39 [
tattāṃ tādṛśīṃ sthitimapi | prathamakalpe rāgadveṣādyaprasaktiṃ darśayati ##-
rāgadveṣakramastatra kuto'nyasyātyasaṃbhavāt |
yadanyena śarīraṃ tu dagdhamanyena lālitam
]

`v 40 [
so'smadārambha evātaḥ kaḥ khedollāsayoḥ kramaḥ |
matsukhāsukhavistāre jagajjālakṣayodaye
]

`v 41 [
ahaṃ karteti matvāntaḥ kaḥ khedollāsayoḥ kramaḥ |
khedollāsavilāseṣu svātmakartṛtayaitayā
]

`v 42 [
svayameva layaṃ yāte samataivāvaśiṣyate |
samatā sarvabhūteṣu yāsau satyā parā sthitiḥ
]

`v 43 [
tasyāmavasthitaṃ cittaṃ na bhūyo janmabhāṅmanāk |
athavā sarvakartṛtvamakartṛtvaṃ ca rāghava
]

`v 44 [
sarvaṃ tyaktvā manaḥ pītvā yo'si sosi sthiro bhava |
ahaṃ so'hamayaṃ nāhaṃ karomīdamidaṃ tu na
]

`v 45 [
iti bhāvānusaṃdhānamayī dṛṣṭirna tuṣṭaye |
sā kālasūtrapadavī sā mahāvīcivāgurā
]

`v 46 [
sāsipatravanaśreṇī yā deho'hamiti sthitiḥ |
sā tyājyā sarvayatnena sarvanāśe'pyupasthite
]

`v 47 [
spraṣṭavyā sā na bhavyena saśvamāṃseva puṣkasī |
tayā sudūrojjhitayā dṛṣṭau paṭalalekhayā
]

`v 48 [
udeti paramā dṛṣṭirjyotsneva vigatāmbudā |
yayābhyuditayā rāma tīryate bhavasāgaraḥ
]

`v 49 [
kartā nāsmi na cāhamasmi sa iti jñātvaivamantaḥ sphuṭaṃ |
kartā cāsmi samagramasmi taditi jñātvāthavā niścayaṃ |
kopyevāsmi na kiṃcidevamiti vā nirṇīya sarvottame |
tiṣṭha tvaṃ svapade sthitāḥ padavido yatrottamāḥ sādhavaḥ
]