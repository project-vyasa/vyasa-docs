`v 1 [
catuḥpañcāśaḥ sargaḥ 54
putra uvāca |
kīdṛśastāta saṃkalpaḥ kathamutpadyate prabho |
kathaṃ ca vṛddhimāpnoti kathaṃ caiṣa vinaśyati
]

`v 2 [
dāśūra uvāca |
anantasyātmatattvasya sattāsāmānyarūpiṇaḥ |
citaścetyonmukhatvaṃ yattatsaṃkalpāṅkuraṃ viduḥ
]

`v 3 [
leśataḥ prāptasattākaḥ sa eva ghanatāṃ śanaiḥ |
yāti cittakhamāpūrya dṛḍhajāḍyāya meghavat
]

`v 4 [
bhāvayantī citiścetyaṃ vyatiriktamivātmanaḥ |
saṃkalpatāmupāyāti bījamaṅkuratāmiva
]

`v 5 [
saṃkalpena hi saṃkalpaḥ svayameva prajāyate |
vardhate svayamevāśu duḥkhāya na sukhāya tu
]

`v 6 [
saṃkalpamātraṃ hi jagajjalamātraṃ yathārṇavaḥ |
ṛte saṃkalpamanyā te nāsti saṃsāraduḥkhitā
]

`v 7 [
kākatālīyayogena saṃjāto'sti mudhaiva hi |
mṛgatṛṣṇādvicandratvamivāsatyaṃ ca vardhate
]

`v 8 [
nigīrṇamātuliṅgasya kanakapratyayo yathā |
svayamabhyetyasatyo'ntaḥ saṃkalpaste tathā hṛdi
]

`v 9 [
asatyameva jātastvamasatyamapi vartase |
asmiñjñāte ca vijñāne hyasatyaṃ saṃvilīyate
]

`v 10 [
asau so'hamime bhāvāḥ sukhaduḥkhamayā mama |
vyarthameveti nānāsthā yenāntaḥ paritapyase
]

`v 11 [
asannevāsya jāto'si kuto janmavilāsataḥ |
vyarthamevāvamūḍho'si saṃkalpavaśataḥ svataḥ
]

`v 12 [
mā saṃkalpaya saṃkalpaṃ bhāvaṃ bhāvaya mā sthitau |
etāvataiva bhāvena bhavyo bhavati bhūtaye
]

`v 13 [
tarhyasya bhramasya nivṛttau ka upāyastamāha - mā saṃkalpayeti |
pūrvānubhūtaṃ sukhaduḥkhādibhāvaṃ sāṃpratikasthitau mā bhāvaya mā smara |
smṛterhi pūrvabhāve tadupādānahānādyarthasaṃkalpodayaḥ syādeveti bhāvaḥ |
12 |
saṃkalpanāśayatnena na bhayānyanugacchati |
bhāvanābhāvamātreṇa saṃkalpaḥ kṣīyate svayam
]

`v 14 [
sumanaḥpallavāmarde kiṃcidvyatikaro bhavet |
susādhyo bhāvamātreṇa natu saṃkalpanāśane
]

`v 15 [
puṣpākrāntau karaspandayatnaḥ putropayujyate |
tadapyupakarotyasminna saṃkalpaparikṣaye
]

`v 16 [
saṃkalpo yena hantavyastena bhāvaviparyayāt |
apyardhena nimeṣeṇa līlayaiva nihanyate
]

`v 17 [
bhāvamātropasaṃpanne svātmani sthitimāgate |
sādhyate yadasādhyaṃ tatkasya syātkimivāṅga te
]

`v 18 [
saṃkalpenaiva saṃkalpaṃ manasā svamano mune |
chittvā svātmani tiṣṭha tvaṃ kimetāvati duṣkaram
]

`v 19 [
upaśānte hi saṃkalpe upaśāntamidaṃ bhavet |
saṃsāraduḥkhamakhilaṃ mūlādapi mahāmate
]

`v 20 [
saṃkalpo hi mano jīvaścittaṃ buddhiḥ savāsanā |
nāmnaivānyatvameteṣāṃ nārthenārthavidāṃ vara
]

`v 22 [
saṃkalpanādṛte neha kiṃcidevāsti kutracit |
tameva hṛdayācchindhi kimetatpariśocasi `note[kimanyat iti pāṭhaḥ] |
21 |
yathaivedaṃ nabhaḥ śūnyaṃ jagacchūnyaṃ tathaiva hi |
asanmayavikalpotthe ubhe ete tate yataḥ
]

`v 23 [
asiddhaṃ sarvamevaitadasiddhenaiva sādhitam |
saṃkalpena jagadyasmādbhāvanā kvāvatiṣṭhatām
]

`v 24 [
(satyāsthāyāmasatyāṃ `note[idamardhamadhikaṃ kvacit] tu
kiṃniṣṭhā vāsanā bhavet |)
bhāvanākṣayataḥ siddhistataḥ prāpyaṃ na śiṣyate |
tasmādasadidaṃ sarvaṃ vijñeyaṃ helayeddhayā
]

`v 25 [
tanubhāvanayā tena sukhaduḥkhairna lipyate |
avastviti ca nirṇīya snehāsthā na pravartate
]

`v 26 [
āsthākṣaye na jāyete harṣāmarṣau bhavābhavau |
tasmādasadidaṃ sarvaṃ sukhaduḥkhādivibhramaiḥ
]

`v 27 [
mano jīvaḥ sphuratyuccairmānasaṃ nagaraṃ jagat |
bhaviṣyadvartamānaṃ ca bhūtaṃ ca parivartayan
]

`v 28 [
vāsanāvalitaṃ loke sphuracchakti manaḥ sthitam |
karoti svāśayenemāṃ vyavasthāṃ malinaścalaḥ
]

`v 29 [
ātmanaḥ sadṛśīṃ līlāṃ jīvo hṛdvanamarkaṭaḥ |
dīrghamākāramādāya nimeṣādyāti hrasvatām
]

`v 30 [
grahītuṃ ca na śakyante saṃkalpajalavīcayaḥ |
manāgdṛṣṭā vivardhante hrasanti saparicchadāḥ
]

`v 31 [
tṛṇamātreṇa dīpyante saṃkalpā vahniśeṣavat |
jagatyaprakaṭākārāḥ pradīptāḥ kṣaṇabhaṅgurāḥ
]

`v 32 [
bhramadā jaḍasaṃsthānāḥ saṃkalpāstaḍidagnayaḥ |
yadevāsanmayaṃ putra tadevāśu cikitsitum
]

`v 33 [
śakyate nātra saṃdeho nāsatsadbhavati kvacit |
saṃsthito yadi saṃkalpo duścikitsyaḥ svato bhavet
]

`v 34 [
kiṃtvasadbhūta evaiṣa sucikitsyastadā bhavet |
akṛtrimaṃ cetsaṃsāramalamaṅgārakārṣṇyavat
]

`v 35 [
tadetatkṣālane sādho kaḥ pravarteta durmatiḥ |
kiṃtvetattaṇḍuleṣveva tuṣakañcukavatsthitam
]

`v 36 [
yatastataḥ prayatnena pauruṣeṇa vinaśyati |
akṛtrimamapi prāptaṃ bhṛśaṃ putra tathā punaḥ
]

`v 37 [
sukhocchedyatayā jñasya saṃsāramalamātatam |
taṇḍulasya yathā carma yathā tāmrasya kālimā
]

`v 38 [
naśyati kriyayā putra puruṣasya tathā malam |
naśyatyeva na saṃdehastasmādudyamavānbhava
]

`v 39 [
asatkalpairvikalpairyatsaṃsāro na jito mudhā |
stokenāśu layaṃ yāti kvāsadvastu ciraṃ sthitam
]

`v 40 [
asatyāmeti saṃsāraḥ svavyavasthāṃ vicārataḥ |
dīpālokādibāndhasya dvindutvaṃ svīkṣitādiva
]

`v 41 [
nāsau tava na cāsya tvaṃ bhrāntiṃ putra parityaja |
asatye satyavaddṛṣṭe bhāvanā mā sma hīdṛśaḥ
]

`v 42 [
mama guruvibhavojjvalā vilāsā
iti tava māstu vṛthaiva vibhramo'ntaḥ |
tvamapi ca vitatāśca te vilāsā
vilasati sarvamidaṃ tadātmatattvam
]