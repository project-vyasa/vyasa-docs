`v 1 [
dvicatvāriṃśaḥ sargaḥ 42
śrīvasiṣṭha uvāca |
kupitasyāsato'pyasya prekṣāmātravināśinaḥ |
avidyāvitatavyādherauṣadhaṃ śṛṇu rāghava
]

`v 2 [
yāṃ tāṃ kathayituṃ jātiṃ rāma rājasasāttvikīm |
manovīryavicārārthaṃ prastuto'smīha tāṃ śṛṇu
]

`v 3 [
yattadapyamṛtaṃ brahma sarvavyāpi nirāmayam |
cidābhāsamanantākhyamanādi vigatabhramam
]

`v 4 [
citspandavapuṣastasya `note[atra nispandavapuṣa iti pāṭho yuktaḥ syāt]
spandastasmāccideva hi |
pradeśāddhanatāmeti saumyo'bdhiścalanādiva
]

`v 5 [
antarabdherjalaṃ yadvatspandāspandavadīhate |
sarvaśaktistathaikatra gacchati spandaśaktitām
]

`v 6 [
ātmanyevātmanā vyomni yathā sarati mārutaḥ |
tathehātmātmaśaktyaiva svātmanyevaiti lolatām
]

`v 7 [
svaśikhāspandaśaktyaiva dīpaḥ saumyo yathonnatam |
eti tadvadasāvātmā tatsve vapuṣi valgati
]

`v 8 [
jalāntare'mbudhiryadvallasadvārīva cañcalaḥ |
sarvaśaktirvapuṣyeva tathā spandavilāsavān
]

`v 9 [
yathollasati bhāścakraiḥ kacankanakasāgaraḥ |
tathātmani parispandaiḥ sphuratyakṣaiścidarṇavaḥ
]

`v 10 [
lakṣyate mauktikaspando yathā vyomni dṛśo'dṛśi |
tathā bhāti lasadrūpā cicchaktiścinmahāmbare
]

`v 11 [
atīndriye aindriyakarūpasphuraṇe'pi tamāha - lakṣyata iti | adṛśi atīndriye | 10
|
kiṃcitkṣubhitarūpā sā cicchaktiścinmahārṇave |
tanmayī citsphuratyacchā tatraivormirivārṇave
]

`v 12 [
ātmano'vyatiriktaiva vyatirikteva tiṣṭhati |
ālokaśrīrivālokakoṭare yattatāṃ gatā
]

`v 13 [
kṣaṇaṃ sphurati sā devī sarvaśaktitayā tayā |
cetati svāṃ svayaṃ śaktiṃ kalendoḥ śītatāmiva
]

`v 14 [
uditaiṣā prakāśākhyā cicchaktiḥ paramātmanaḥ |
deśakālakriyāśaktirvayasyāḥ saṃprakarṣati
]

`v 15 [
svasvabhāvaṃ viditvaivamanādyantapade sthitā |
rūpaṃ parimitevāsau bhāvayatyavibhāvitā
]

`v 16 [
yadaivaṃbhāvitaṃ rūpaṃ tayā paramasattayā |
tadaivaināmanugatā nāmasaṃkhyādikā dṛśaḥ
]

`v 17 [
cidevaitadavastveva vyatiriktā tathātmanaḥ |
anantā tadgataivāśu laharīva mahārṇavāt
]

`v 18 [
yathā kaṭakakeyūrairbhedo hemno vilakṣaṇaḥ |
tathātmanaścito rūpaṃ bhāvayantyāḥ svamāṃśikam
]

`v 19 [
yathā dīpena dīpānāṃ jātānāmātmanāṃ tathā |
deśakālakalāmātrabhedaḥ svābhāvikaściteḥ
]

`v 20 [
deśakālaparispandaśaktisandīpitātha cit |
saṃkalpamanudhāvantī prayāti kalanāpadam
]

`v 21 [
vikalpakalitākāraṃ deśakālakriyāspadam |
cito rūpaṃ mahābāho kṣetrajña iti kathyate
]

`v 22 [
kṣetraṃ śarīramityāhustadasau vettyakhaṇḍitam |
sabāhyābhyantaraṃ tena kṣetrajña iti kathyate
]

`v 23 [
vāsanāṃ kalayanso'pi yātyahaṃkāratāṃ punaḥ |
ahaṃkāro'pi nirṇetā kalaṅkī buddhirucyate
]

`v 24 [
buddhiḥ saṃkalpakalitā prayāti manasaḥ padam |
mano ghanavikalpaṃ tu gacchatīndriyatāṃ śanaiḥ
]

`v 25 [
pāṇipādamayaṃ dehamindriyāṇi vidurbudhāḥ |
deho'sau jñāyate loke sūyate'pi ca jīvati
]

`v 26 [
evaṃ jīvo hi saṃkalpavāsanārajjuveṣṭitaḥ |
duḥkhajālaparītātmā kramādāyāti cittatām
]

`v 27 [
krameṇa pākavaśataḥ phalameti yathānyatām |
avasthayaiva nākṛtyā jīvo malavaśāttathā
]

`v 28 [
jīvo'haṃkāratāṃ prāptastvahaṃkāraśca buddhitām |
saṃkalpajālakalitāṃ manastāṃ buddhirāgatā
]

`v 29 [
mano hi saṃkalpamayaṃ saṃsthāgrahaṇatatparam |
pratiyogivyavacchinnaprāptisatyairapīhitaiḥ
]

`v 31 [
icchādyāḥ śaktayaśceto gāvo vṛṣamivonmadam |
tadāsaktau tānviṣayānpunaḥpunaḥ smaraccittabhāvāpannaṃ
rāgadveṣādidoṣairāskandyata ityāha - icchādyā iti | anudhāvantyanusaranti |
30 |
iti śaktimayaṃ ceto ghanāhaṃkāratāṃ gatam |
kośakārakrimiriva svecchayā yāti bandhanam
]

`v 32 [
iti uktakrameṇa rāgadveṣādiśaktipracuraṃ cetaḥ
śākhāprarohaśatakoṭibhirabhimānavṛddhyā ghanāhaṃkāratāṃ gataṃ sat | 31
|
svasaṃkalpānusaṃdhānātpāśairiva nayanvapuḥ |
kaṣṭamasminsvayaṃ bandhametyātmā paritapyate
]

`v 33 [
baddhamasmīti kalyadvidyātattvaṃ jahacchanaiḥ |
avidyāṃ janayatyantarjagajjaṅgalarākṣasīm
]

`v 34 [
svasaṃkalpitatanmātrajvālābhyantaravarti ca |
parāṃ vivaśatāmeti śṛṅkhalābaddhasiṃhavat
]

`v 35 [
vicitrakāryakartṛtvamāharadvāsanāvaśāt |
svecchāmātrānuracitā daśāścānupatattathā
]

`v 36 [
kvacinmanaḥ kvacidbuddhiḥ kvacijjñānaṃ kvacitkriyāḥ |
kvacidetadahaṃkāraḥ kvacitpuryaṣṭakaṃ smṛtam
]

`v 37 [
kvacitprakṛtirityuktaṃ kvacinmāyeti kalpitam |
kvacinmalamiti proktaṃ kvacitkarmeti saṃsthitam
]

`v 38 [
kvacidbandhamiti khyātaṃ kvaciccittamiti sphuṭam |
proktaṃ kvacidavidyeti kvacidiccheti saṃsthitam
]

`v 39 [
tadetadābaddhamiha cittaṃ rāghava duḥkhitam |
tṛṣṇāśokasamāviṣṭaṃ rāgāyatanamātatam
]

`v 40 [
jarāmaraṇamohāntarbhavabhāvanayāhatam |
īhitānīhitairgrastamavidyārāgarañjitam
]

`v 41 [
icchāsaṃkṣubhitākāraṃ karmavṛkṣavanāṅkuram |
suvismṛtotpattipadaṃ kalpitānarthakalpitam
]

`v 42 [
kośakāravadābaddhaṃ śokākārapadaṃ gatam |
tanmātravṛndāvayavamanantanarakātapam
]

`v 43 [
svadṛśyamapi śailendrasamabhārabhayāvaham |
jarāmaraṇaśākhāḍhyaṃ saṃsāraviṣadurdrumam
]

`v 44 [
imaṃ saṃsāramakhilamāśāpāśavidhāyakam |
dadhadantaḥ phalairhīnaṃ vaṭadhānā vaṭaṃ yathā
]

`v 45 [
cintānalaśikhādagdhaṃ kopājagaracarvitam |
kāmābdhikallolahataṃ vismṛtātmapitāmaham
]

`v 46 [
mṛgaṃ yūthādiva bhraṣṭaṃ śokopahatacetanam |
pataṅgakamiva jvālādagdhaṃ viṣayapāvake
]

`v 47 [
chinnamūlamivāmbhojaṃ paramāṃ mlānimāgatam |
chinnāṅgamātmanaḥ sthānādviśeṣāsaṅgaduḥsthitam
]

`v 48 [
viṣayādiṣu madhyasthaṃ citrarūpeṣu śatruṣu |
daśāsvetāsvanantāsu luṭhitaṃ saṃkaṭāsviti
]

`v 49 [
duḥkhe nipatitaṃ ghore vihaṅgaḥ sāgare yathā |
svabandhāsthaṃ jagajjāle śūnye gandharvapattane
]

`v 50 [
svasya bandhe bandhanahetau tatsādhanadehādau ca āsthā snehātiśayo yasya tat | 49
|
uhyamānamanāsthābdhau mano viṣayavidrutam |
uddharāmarasaṃkāśa mātaṅgamiva kardamāt
]

`v 51 [
balīvardavadāmagnaṃ mano madanapalvale |
ālūnaśīrṇāvayavaṃ balādrāma samuddhara
]

`v 52 [
śubhāśubhaprasaraparāhatākṛtau
jvalajjarāmaraṇaviṣādamūrcchite |
vyatheha yasya manasi bho na jāyate
narākṛtirjagati sa rāma rākṣasaḥ
]