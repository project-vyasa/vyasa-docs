`v 1 [
dvāviṃśaḥ sargaḥ 22
śrīvasiṣṭha uvāca |
jantoḥ kṛtavicārasya vigaladvṛtticetasaḥ |
mananaṃ tyajato jñātvā kiṃcitpariṇatātmanaḥ
]

`v 2 [
dṛśyaṃ saṃtyajato heyamupādeyamupeyuṣaḥ |
draṣṭāraṃ paśyato dṛśyamadraṣṭāramapaśyataḥ
]

`v 3 [
jāgartavye pare tattve jāgarūkasya jīvataḥ |
suptasya ghanasaṃmohamaye saṃsāravartmani
]

`v 4 [
paryantātyantavairāgyātsaraseṣvaraseṣvapi |
bhogeṣvābhogaramyeṣu viraktasya nirāśiṣaḥ
]

`v 5 [
vrajatyātmāmbhasaikatvaṃ jīrṇajāḍye nabhasyalam |
galatyapagatāsaṅge himāpūra ivātape
]

`v 6 [
taraṅgitāsu kallolajalalolāntarāsu ca |
śāmyantīṣvatha tṛṣṇāsu nadīṣviva ghanātyaye
]

`v 7 [
saṃsāravāsanājāle khagajāla ivākhunā |
troṭite hṛdayagranthau ślathe vairāgyaraṃhasā
]

`v 8 [
kātakaṃ phalamāsādya yathā vāri prasīdati |
tathā vijñānavaśataḥ svabhāvaḥ saṃprasīdati
]

`v 9 [
nīrogaṃ nirupāsaṅgaṃ nirdvandvaṃ nirupāśrayam |
viniryāti mano mohādvihagaḥ pañjarādiva
]

`v 10 [
śānte saṃdehadaurātmye gatakautukavibhramam |
paripūrṇāntaraṃ cetaḥ pūrṇenduriva rājate
]

`v 11 [
janitottamasaundaryā dūrādastamayonnatā |
samatodeti sarvatra śānte vāta ivārṇave
]

`v 12 [
andhakāramayī mūkā jāḍyajarjaritāntarā |
tanutvameti saṃsāravāsanevodaye kṣapā
]

`v 13 [
dṛṣṭacidbhāskarā prajñāpadminī puṇyapallavā |
vikasatyamaloddyotā prātardyuriva rūpiṇī
]

`v 14 [
prajñā hṛdayahāriṇyo bhuvanāhlādanakṣamāḥ |
sattvalabdhāḥ pravardhante sakalendorivāṃśavaḥ
]

`v 15 [
hṛdayahāriṇyo manoharāḥ sattvaguṇopacayāllabdhāḥ prajñāḥ pravardhante |
14 |
bahunātra kimuktena jñātajñeyo mahāmatiḥ |
nodeti naiva yātyastamabhūtākāśakośavat
]

`v 16 [
vicāraṇā parijñātasvabhāvasyoditātmanaḥ |
anukampā bhavantīha brahmaviṣṇvindraśaṃkarāḥ
]

`v 17 [
prakaṭākāramapyantarnirahaṃkāracetasam |
nāpnuvanti vikalpāstaṃ mṛgatṣṇāmivaiṇakāḥ
]

`v 18 [
taraṅgavadime lokāḥ prayāntyāyānti cetasaḥ |
kroḍīkurvanti cājñaṃ te na jñaṃ maraṇajanmanī
]

`v 19 [
āvirbhāvatirobhāvau saṃsāro netarakramaḥ |
iti tābhyāṃ samāloko ramate sa nibadhyate
]

`v 20 [
na jāyate na mriyate kumbhe kumbhanabho yathā |
bhūṣite dūṣite vāpi dehe tadvadihātmavān
]

`v 21 [
viveka udite śīte mithyā bhramamarūditā |
kṣīyate vāsanā sāgre mṛgatṛṣṇā marāviva
]

`v 22 [
ko'haṃ kathamidaṃ ceti yāvanna pravicāritam |
saṃsārāḍambaraṃ tāvadandhakāropamaṃ sthitam
]

`v 23 [
mithayābhramabharodbhūtaṃ śarīraṃ padamāpadām |
ātmabhāvanayā nedaṃ yaḥ paśyati sa paśyati
]

`v 24 [
kīdṛśasthityā tarhi niḥsaṃsārāndhakāraṃ pūrṇātmānaṃ paśyati tāmāha ##-
deśakālavaśotthāni na mameti gatabhramam |
śarīre sukhaduḥkhāni yaḥ paśyati sa paśyati
]

`v 25 [
apāraparyantanabho dikkālādikriyānvitam |
ahameveti sarvatra yaḥ paśyati sa paśyati
]

`v 26 [
bālāgralakṣabhāgāttu koṭiśaḥ parikalpitāt |
ahaṃ sūkṣma iti vyāpī yaḥ paśyati sa paśyati
]

`v 27 [
ātmānamitaraccaiva dṛṣṭyā nityāvibhinnayā |
sarvaṃ cijjyotireveti yaḥ paśyati sa paśyati
]

`v 28 [
sarvaśaktiranantātmā sarvabhāvāntarasthitaḥ |
advitīyaścidityantaryaḥ paśyati sa paśyati
]

`v 29 [
ādhivyādhibhayodvigno jarāmaraṇajanmavān |
deho'hamiti yaḥ prājño na paśyati sa paśyati
]

`v 30 [
tiryagūrdhvamadhastācca vyāpako mahimā mama |
dvitīyo na mamāstīti yaḥ paśyati sa paśyati
]

`v 31 [
mayi sarvamidaṃ protaṃ sūtre maṇigaṇā iva |
cittaṃ tu nāhameveti yaḥ paśyati sa paśyati
]

`v 32 [
cideva tantustena prote sarvamahameveti vā cittamantaḥkaraṇaṃ tu nāhameveti vā |
31 |
nāhaṃ na cānyadastīti brahmaivāsti nirāmayam |
itthaṃ sadasatormadhye yaḥ paśyati sa paśyati
]

`v 33 [
yannāma kiṃcittrailokyaṃ sa evāvayavo mama |
taraṅgo'bdhāvivetyantaryaḥ paśyati sa paśyati
]

`v 34 [
śocyā pālyā mayaiveyaṃ svaseyaṃ me kanīyasī |
trilokī pelavetyuccairyaḥ paśyati sa paśyati
]

`v 35 [
ātmatāparate tvattāmatte yasya mahātmanaḥ |
bhavāduparate nūnaṃ sa paśyati sulocanaḥ
]

`v 36 [
cetyānupātarahitaṃ cidbhairavamayaṃ vapuḥ |
āpūritajagajjālaṃ yaḥ paśyati sa paśyati
]

`v 37 [
sukhaṃ duḥkhaṃ bhavo bhāvo vivekakalanāśca yāḥ |
ahameveti vā nūnaṃ paśyannapi na hīyate
]

`v 38 [
bhavaḥ adhikāridehastatra bhāvo gurudaivataśāstrādiśraddhā tatra
nityānityādivivekastena kalanāḥ
śravaṇādikrameṇātmaparicayatāratamyabhedāśca sarve ahameveti yaḥ paśyati |
37 |
svātmasattāparāpūrṇe jagatyaṃśena vartinā |
kiṃ me heyaṃ kimādeyamiti paśyansudṛṅgaraḥ
]

`v 39 [
ātmasattayaiva parayā niratiśayānandaghanayā āpūrṇe brahmādistambaparyante
ānandalavārpaṇena tarpite jagati aṃśenaikadeśena vartinā
aihikapāralaukikabhogyavastunā me kiṃ duḥkhamasti yaddheyaṃ
kiṃvānyatsukhamasti yadupādeyamiti paśyansudṛk abhrāntadṛṣṭirityarthaḥ |
38 |
apratarkyamanābhāsaṃ sanmātramidamityalam |
heyopādeyakalanā yasya kṣīṇā sa vai pumān
]

`v 40 [
ya ākāśavadekātmā sarvabhāvagato'pi san |
na bhāvarañjanāmeti sa mahātmā maheśvaraḥ
]

`v 41 [
tamaḥprakāśakalanāmuktaḥ kālātmatāṃ gataḥ |
yaḥ saumyaḥ susamaḥ svasthastaṃ naumi padamāgatam
]

`v 42 [
yasyodayastamayasaṃkalanākalāsu
citrāsu cāruvibhavāsu jagadgatāsu |
vṛttiḥ sadaiva sakalaikamateranantā
tasmai namaḥ paramabodhavate śivāya
]