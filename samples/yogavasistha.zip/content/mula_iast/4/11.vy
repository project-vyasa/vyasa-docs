`v 1 [
ekādaśaḥ sargaḥ 11
kāla uvāca |
adyoddāmataraṅgaughabhāṅkāraraṇitānile |
tīra eva taraṅgiṇyāstapastapati te sutaḥ
]

`v 2 [
jaṭāvānakṣavalayī jitasarvendriyabhramaḥ |
tatra varṣaśatānyaṣṭau saṃsthitastapasi sthire
]

`v 3 [
yadīcchasi mune draṣṭuṃ taṃ svapnābhaṃ manobhramam |
tatsamunmīlya vijñānanetramāśu vilokaya
]

`v 4 [
śrīvasiṣṭha uvāca |
ityukte jagadīśena kālena samadṛṣṭinā |
muniḥ saṃcintayāmāsa jñānākṣṇā tanayehitam
]

`v 5 [
dadarśa ca muhūrtena pratibhānavaśādasau |
putrodantamaśeṣeṇa buddhidarpaṇabimbitam
]

`v 6 [
punarmandarasānusthāṃ svasthāṃ kālāgrasaṃsthitām |
samaṅgāyāstaṭādetya viveśa svatanuṃ bhṛguḥ
]

`v 7 [
vismayasmerayā dṛṣṭyā kālamālokya kāntayā |
vītarāgamuvācedaṃ vītarāgo munirvacaḥ
]

`v 8 [
bhagavanbhūtabhavyeśa bālā vayamanujjvalāḥ |
tvādṛśāmeva dhīrdeva trikālāmaladarśinī
]

`v 9 [
nānākāravikārāḍhyā satyevāsatyarūpiṇī |
vibhramaṃ janayatyeṣā dhīrasyāpi jagatsthitiḥ
]

`v 10 [
tvameva deva jānāsi tvadabhyantaravarti yat |
rūpamasyā manovṛtterindrajālavidhāyakam
]

`v 11 [
matputrasyāsya bhagavanmṛtyuḥ kila na vidyate |
tenemaṃ mṛtamālokya jātaḥ saṃbhramavānaham
]

`v 12 [
akṣīṇājīvitaṃ putraṃ kālo me nītavāniti |
niyatervaśato deva tucchāpīcchā mamoditā
]

`v 13 [
nanu vijñātasaṃsāragatayo vayamāpadām |
saṃpadāṃ caiva gacchāmo harṣāmarṣavaśaṃ vibho
]

`v 14 [
ayuktakāriṇi krodhaḥ prasādo yuktakāri.i |
kartavya iti rūḍheyaṃ saṃsāre bhagavan sthitiḥ
]

`v 15 [
idaṃ kāryamidaṃ neti yāvatkāryaṃ jagadbhramaḥ |
tasyaitatsaṃparityāgo heya eva jagadguro
]

`v 16 [
kevalaṃ tāvakīṃ cintāmanālokya yadā vayam |
bhagavanbhavate kruddhā yātāḥ smastena bādhyatām
]

`v 17 [
tvayedānīmahaṃ deva smāritastanayehitam |
samaṅgāyāstaṭe tena dṛṣṭo'yaṃ tanayo mayā
]

`v 18 [
mano jagati bhūtānāṃ dve śarīre'tra sarvagam |
mana eva śarīraṃ hi yenedaṃ bhāvyate jagat
]

`v 19 [
kāla uvāca |
samyaguktaṃ tvayā brahman śarīraṃ mana eva ca |
karoti dehaṃ saṃkalpātkumbhakāro ghaṭaṃ yathā
]

`v 20 [
karotyakṛtamākāraṃ kṛtaṃ nāśayati kṣaṇāt |
saṃkalpena manomohādbālo vetālakaṃ yathā
]

`v 21 [
tathā ca saṃbhramasvapnamithyājñānādibhāsurāḥ |
gandharvanagarākārā dṛṣṭā manasi śaktayaḥ
]

`v 22 [
sthūladṛṣṭidaśāṃ tvetāmavalambya mahāmune |
puṃso manaḥ śarīraṃ ca kāyau dvāviti kathyate
]

`v 23 [
mano manananirmāṇamātrametajjagattrayam |
na sannāsadiva sphāramuditaṃ netaranmune
]

`v 24 [
cittadehāṅgalatayā bhedavāsanayeddhayā |
dvicandratvamivājñānānnānāteyaṃ samutthitā
]

`v 25 [
bhedavāsanayā paśyatpadārthanicayaṃ manaḥ |
bhinnaṃ paśyati sarvatra ghaṭāvaṭapaṭādikam
]

`v 26 [
kṛśo'tiduḥkhī mūḍho'hametāścānyāśca bhāvanāḥ |
bhāvayatsvavikalpotthāṃ yāti saṃsāritāṃ manaḥ
]

`v 27 [
mananaṃ kṛtrimaṃ rūpaṃ mamaitanna yato'smyaham |
iti tattyāgataḥ śāntaṃ ceto brahma sanātanam
]

`v 28 [
saṃsaraṇakramamupapādya tannivṛttyupāyamāha - mananamiti |
kṛtrimamananarūpatyāge akṛtrimasvarūpāvasthiterarthaprāptatvāditi bhāvaḥ |
27 |
yathā pravitatāmbhodhau drutāṃ naikataraṅgiṇi |
śāmyatspandatayānekakallolāvaliśālini
]

`v 29 [
vāryātmani same svacche śuddhe svāduni śītale |
avināśini vistīrṇe mahāmahimani sphuṭe
]

`v 30 [
hrasvastaraṅgaḥ svaṃ rūpaṃ bhāvayansvasvabhāvataḥ |
hrasvo'smīti vikalpena karoti svena bhāvanām
]

`v 31 [
dīrghastaraṅgaḥ svaṃ rūpaṃ bhāvayansvasvabhāvataḥ |
dīrgho'smīti vikalpena karoti svena bhāvanām
]

`v 32 [
hrasvaścaiva paribhraṣṭarūpo'smīti talātalam |
bhāvayanbhūtalaṃ yāti tādṛgbhāvanayā svayā
]

`v 33 [
utpannaśca palādūrdhvamutthito'smīti bhāvitaḥ |
saraśmiratnajālastu śobhate dīptayā śriyā
]

`v 34 [
tuṣārakarabimbasthaḥ śītalo'smīti bimbati |
sataṭācaladāvāgnipratibimbo jvaladvapuḥ
]

`v 35 [
bibheti vata dagdho'smītyāttamaunaśca kampate |
pratibimbitavelādritaṭapakṣavanadrumaḥ
]

`v 36 [
mahadārambhasaṃrambhasaṃyukto'smīti rājate |
viśallolānilātyantadhvastalolaśarīrakaḥ
]

`v 37 [
khaṇḍaśaḥ pariyāto'smītyāttakranda ivāravī |
na cormayaste jaladhervyatiriktāḥ payodharāt
]

`v 38 [
āttakranda ārabdharodana iva āravī dhvanimān | dṛṣṭānte āropamuktvā
apavādaṃ darśayati - na cetyādinā | payobharādvārisamūharūpājjaladheḥ |
37 |
nacaikaṃ rūpameteṣāṃ kiṃcitsannāpyasanmayam |
nacaite hrasvadairghyādyā guṇāsteṣu na teṣu te
]

`v 39 [
normayaḥ saṃsthitā hyabdhau na tattatra na saṃsthitāḥ |
kevalaṃ svasvabhāvasthasaṃkalpavikalīkṛtāḥ
]

`v 40 [
naṣṭānaṣṭāḥ punarjātā jātājātāḥ punaḥ punaḥ |
parasparaparāmarśānnānyatāmupayāntyalam
]

`v 41 [
ekarūpāmbusāmānyamayā eva nirāmayāḥ |
tathaivāsminpravitate site śuddhe nirāmaye
]

`v 42 [
brahmamātraikavapuṣi brahmaṇi sphārarūpiṇi |
sarvaśaktāvanādyante pṛthagvadapṛthakkṛtāḥ
]

`v 43 [
saṃsthitāḥ śaktayaścitrā vicitrācāracañcalāḥ |
nānāśaktirhi nānātvameti sve vapuṣi sthitim
]

`v 44 [
bṛṃhitaṃ brahmaṇi brahma payasīvormimaṇḍalam |
strīpumānvyaṅgarūpeṇa brahmaiva parivartate
]

`v 45 [
kalpanānyā jagannāmnī nāsīdasti bhaviṣyati |
brahmaṇo jagato bhedo manāgapi na vidyate
]

`v 46 [
saṃpūrṇaṃ khalvidaṃ brahma jagadbrahmaiva kevalam |
iti bhāvaya yatena hyanyatsarvaṃ parityaja
]

`v 47 [
nānārūpiṇyekarūpā vairūpyaśatakāriṇī |
niyatirniyatākārā padārthamadhitiṣṭhati
]

`v 48 [
jaḍājaḍamupādatte cittamāyāti cinmaye |
vāsanārūpiṇī śaktiḥ svasvarūpā sthitātmanaḥ
]

`v 49 [
brahmaivānagha tenedaṃ sphārākāraṃ vijṛmbhate |
nānārūpaiḥ pratispandaiḥ paripūrṇa ivārṇavaḥ
]

`v 50 [
nānātāṃ svayamādatte nānākāravihārataḥ |
ātmaivātmanyātmanaiva samudrāmbha ivāmbhasi
]

`v 51 [
vyatiriktā na payaso vicitrā vīcayo yathā |
vyatiriktā na viśveśātsamagrāḥ kalpanāstathā
]

`v 52 [
śākhāpuṣpalatāpatraphalakorakayuktayaḥ |
yathaikasmiṃstathā bīje sarvadā sarvaśaktitā
]

`v 53 [
vicitravarṇatā yadvaddṛśyate kaṭhinātape |
vicitraśaktitā tadvaddeveśe sadasanmayī
]

`v 54 [
vicitrarūpodetīyamavicitrātsthitiḥ śivāt |
ekavarṇātpayovāhācchakracāpalatā yathā
]

`v 55 [
ajaḍājjaḍatodeti jāḍyabhāvanahetukā |
ūrṇanābhādyathā tanturyathā puṃsaḥ suṣuptatā
]

`v 56 [
acitaścetasaḥ śaktiṃ svabandhāyecchayā śivaḥ |
tanoti tāntavaṃ kośaṃ kośakārakṛmiryathā
]

`v 57 [
svecchayātmātmano brahmanbhāvayitvaiṣa vismṛtim |
karoti kaṭhinaṃ bandhaṃ kośakārakṛmiryathā
]

`v 58 [
svecchayātmātmano brahmanbhāvayitvā svakaṃ vapuḥ |
saṃsārānmokṣamāpnoti svālānādiva vāraṇaḥ
]

`v 59 [
yathaiva bhāvayatyātmā satataṃ bhavati svayam |
tathaivāpūryate śaktyā śīghrameva mahānapi
]

`v 60 [
bhāvitā śaktirātmānamātmatāṃ nayati kṣaṇāt |
anantamakhilaṃ prāvṛḍmihikā mahatī yathā
]

`v 61 [
yā śaktiruditā śīghraṃ yāti tanmayatāmajaḥ |
ya evartuḥ sthitiṃ yātastanmayo bhavati drumaḥ
]

`v 62 [
na mokṣo mokṣa īśasya na bandho bandha ātmanaḥ |
bandhamokṣadṛśau loke na jāne protthite kutaḥ
]

`v 63 [
nāsti bandho na mokṣo'sti tanmayastviva lakṣyate |
grastaṃ nityamanityena māyāmayamaho jagat
]

`v 64 [
yadaiva cittaṃ kalitaṃ kilānenākalātmanā |
kośakāravadātmāyamanenāvalitastadā
]

`v 65 [
anyonyarūpāstvatyantaṃ vikalpitaśarīrakāḥ |
manaḥśaktaya etasmādimā niryānti koṭayaḥ
]

`v 66 [
tajjāstatsthāḥ pṛthagrūpāḥ samudrādiva vīcayaḥ |
tajjāstatsthāḥ pṛthaksthāśca candrādiva marīcayaḥ
]

`v 67 [
asminspandamaye sphāre paramātmamahāmbudhau |
cijjale vitatābhoge cinmātrarasamālini
]

`v 68 [
mukhyāmukhyabandhopādhikajīvākhyasaṃvidbhedāneva
nāmarūpakriyādivaicitryairvistareṇa darśayitumupakramate - asminnityādinā |
67 |
kāścitsthirā brahmaviṣṇū kāścidrudratvamāgatāḥ |
kāścitpuruṣatāṃ prāptāḥ kāściddevatvamāgatāḥ
]

`v 69 [
(laharyaḥ `note[koṣṭhakavinyastāḥ ślokāḥ prakṣiptā iti bhāti]
prasphurantyetāḥ svabhāvodbhāvitātmakāḥ |
kāścidyamamahendrārkavahnivaiśravaṇādikāḥ |
ghnanti kurvanti tiṣṭhanti laharyaścapalaiṣaṇāḥ |
kāścitkiṃnaragandharvavidyādharasurādikāḥ |
utpatanti patantyugrā laharyaḥ parivalgitāḥ |
kāścitkiṃcitsthirākārā yathā kamalajādikāḥ |
kāścidutpannavidhvastā yathā suranarādikāḥ |)
kṛmikīṭapataṅgāhigomaśājagarādikāḥ |
kāścittasminmahāmbhodhau sphurantyetembubinduvat
]

`v 70 [
maśā maśakāḥ | mahāmbhodhau yādorūpeṇeti śeṣaḥ | dṛṣṭāntaśeṣo vā | 69
|
kāściccalā naramṛgagṛdhrajambulakādikāḥ |
sphuranti girikuñjeṣu velāvanataṭeṣviva
]

`v 71 [
sudīrghajīvitāḥ kāścitkāścidatyalpajīvitāḥ |
atucchakalanāḥ kāścitkāścittucchaśarīrakāḥ
]

`v 72 [
saṃsārasvapnasaṃrambhe kāścitsthairyeṇa bhāvitāḥ |
suvikalpahatāḥ kāścicchaṅkante susthiraṃ jagat
]

`v 73 [
alpālpabhāvanāḥ kāściddainyadoṣavaśīkṛtāḥ |
kṛśo'tiduḥkhī mūḍho'hamitiduḥkhairvaśīkṛtāḥ
]

`v 74 [
kāścitsthāvaratāṃ yātāḥ kāściddevatvamāgatāḥ |
kāścitpuruṣatāṃ prāptāḥ kāścidarṇavatāṃ gatāḥ
]

`v 75 [
kāścitsthitā jagati kalpaśatānyanalpāḥ
kāścidvrajanti paramaṃ padaminduśuddhaḥ |
brahmārṇavātsamuditā laharīvilolā-
ścitsaṃvido hi mananāparanāmavatyaḥ
]