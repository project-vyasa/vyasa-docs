`v 1 [
aṣṭāviṃśaḥ sargaḥ 28
śrīvasiṣṭha uvāca |
ityuktvā bhagavāndevāṃstatraivāntardhimāyayau |
velāvanitaṭe śabdaṃ kṛtvevāmbutaraṅgakaḥ
]

`v 2 [
surāstvākarṇya tadvākyaṃ jagmuḥ svābhimatāṃ diśam |
kamalāmodamādāya vanamālāmivānilāḥ
]

`v 3 [
dināni katicitsveṣu kānteṣu sthirakāntiṣu |
dvirephā iva padmeṣu mandireṣu viśaśramuḥ
]

`v 4 [
kaṃcitkālaṃ samāsādya svātmodayakaraṃ śubham |
cakrurdundubhinirghoṣaṃ pralayābhraravopamam
]

`v 5 [
atha daityairmamāvyomni taiḥ pātālatale sthitaiḥ |
kālakṣepakaraṃ ghoraṃ punaryuddhamavartata
]

`v 6 [
vavurasiśaraśaktimudgaraughā
musalagadāparaśūgracakraśaṅkhāḥ |
aśanigiriśilāhutāśavṛkṣā
ahigaruḍādimukhāni cāyudhāni
]

`v 7 [
māyākṛtāyudhamahāmbughanapravāhā
kṣiprāvahā pratidiśaṃ kila nirjagāma |
pāṣāṇaparvatamahīruhalakṣavṛkṣa-
kṣubdhāmbupūraghanaghoṣavatī nadī drāk
]

`v 8 [
madhyapravāhavahadulmukaśūlaśaila-
prāsāsikuntaśaratomaramudgaraughā |
gaṅgopamāmbuvalitāmaramandireṇa
sarvāsu dikṣvaśanivarṣanikarṣaṇena
]

`v 9 [
pṛthvyādidāruṇaśarīramapi prahāra-
dānagrahā gahanarāśiśarīrakeva |
māyopaśāmyati surāsurasiddhasannā
māyākṛtiḥ punarudeti nacaiva saiva
]

`v 10 [
śailopamāyudhavighaṭṭitabhūdharāṇi
raktāmbupūraparipūrṇamahārṇavāni |
devāsurendraśavaśailavirūḍhakunta-
tālīvanāni kakubhāṃ vadanāni cācan
]

`v 11 [
udgīrṇakuntaśaraśaktigadāsicakra-
helānigīrṇasuradānavamuktaśailā |
kāṣollasatkrakacadantanakhāgramālā
jīvānvitā hyapatadāyasasiṃhasṛṣṭiḥ
]

`v 12 [
ujjvālalocanaviṣajvalanātapaugha-
digdāhadarśitayugāntadineśasenā |
uḍḍīyamānaparidīrghamahāmahīdhna-
magnābdhivadviṣadharāvalirullalāsa
]

`v 13 [
unnādavajramakarotkarakarkaśāntaḥ-
kṣubdhābdhivīcivalayairvalitācalendraiḥ |
āsījjagatsakalameva susaṃkaṭāṅga-
māvṛttibhirvividhahetinadīpravāhaiḥ
]

`v 14 [
śailāstraśastragaruḍācalacālitocca-
nāgaṃ mahāsuragaṇāṅgaṇamantarikṣam |
āsītkṣaṇaṃ jaladhibhiḥ kṣaṇamagnipūraiḥ
pūrṇaṃ kṣaṇaṃ dinakaraiḥ kṣaṇamandhakāraiḥ
]

`v 15 [
garuḍaguḍaguḍākulāntarikṣa-
pravisṛtahetihutāśaparvataughaiḥ |
jagadabhavadasahyakalpakāle
jvalitasurālayabhūtalāntarālam
]

`v 16 [
udapatannasurā vasudhātalā-
dgaganamadritaṭādiva pakṣiṇaḥ |
atibalādapatanvibudhā bhuvi
pralayacālitaśailaśilā iva
]

`v 17 [
śarīrarūḍhonnatahetivṛkṣa-
vanāvalīlagnamahāgnidāhāḥ |
surāsurāḥ prāpurathāmbarāntaḥ
kalpānilāndolitaśailaśobhām
]

`v 18 [
surāsurādrīndraśarīramuktai
raktapravāhairabhito bhramadbhiḥ |
vabhāra pūrṇaṃ parito'mbaro'dreḥ
saṃdhyākaraughakṣatamaṅga gaṅgām
]

`v 19 [
girivarṣaṇamambuvarṣaṇaṃ
vividhogrāyudhavarṣaṇaṃ tathā |
viṣamāśanivarṣaṇaṃ ca te
samamanyonyamathāgnivarṣaṇam
]

`v 20 [
anayannayamārgakovidā
dalitāśeṣagirīndrabhittayaḥ |
sasṛjuśca samaṃ samantataḥ
karikumbheṣviva puṇyavarṣaṇam
]

`v 21 [
devāsurāḥ samarasaṃbhramamākulāste
anyonyamaṅgadalanākulahetihastāḥ |
nāgendraḍimbhapṛtanāpṛthupīṭhapeṣaiḥ
kīrṇaśriyo nabhasi babhramurakṣipantaḥ
]

`v 22 [
chinnaiḥ śiraḥkarabhujorubharairbhramadbhi-
rākāśakāṣṭhaśalabhairaśivaistadānīm |
āsījjagajjaṭharamabhrabharairivograi-
rābhāskarasthagitadiktaṭaśailajālam
]

`v 23 [
raṭadbhaṭāsphoṭakaṭisphuṭadbhiḥ
samīritairhetikalāsitaughaiḥ |
parasparāghātahataiḥ patadbhi-
rjagāma śīrṇā dalaśo dharitrī
]

`v 24 [
anyonyamāyudhaśilācalavṛkṣavarṣai-
rmerupramāṇakaṭhināṅganigharṣaṇaiśca |
āsīdraṇaṃ caṭacaṭāsphuṭadantarikṣaṃ
kalpakṣayāntamiva bhīmabharogranādaiḥ
]

`v 25 [
mattānilakṣubdhajalānalārka-
daladvayaṃ dīrghasurāsuraugham |
brahmāṇḍamākhaṇḍitakuḍyakoṇa-
makālakalpāntakarālamāsīt
]

`v 26 [
bhrāntairbhṛśaṃ bharitadiktaṭamadrikūṭai-
rātmapramāṇaghanahetihatai raṇadbhiḥ |
kūjadbhirārtibhirivograguhoccavātaiḥ
krandadbhirāpatitasiṃharavairadabhraiḥ
]

`v 27 [
māyānadījaladhiyodhaganāgnidāhai-
rvṛkṣaiḥ surāsuraśavairacalaiḥ śiloccaiḥ |
bhrāntaiḥ śarāśiśitaśaktigadāstraśastrai-
rvātāvakīrṇavanaparṇavadantarantaḥ
]

`v 28 [
adrīndrapakṣaparimāṇagamākṣamokta-
durvārahastivaladāruṇadehakairdrāk |
āsītpatadbhaṭaśarīragirīndravāta-
vibhraṣṭadevapurapūrṇajalārṇavaugham
]

`v 29 [
ghanaghuṃghumapūritāntarikṣā
kṣatajakṣālitabhūdharā dharā ca |
rudhirahadavṛttivartinī vā
bhuvanābhogaguhā tadākulābhūt
]

`v 30 [
anantadṛkprasṛtavikārakāriṇī
kṣayodayonmukhasukhaduḥkhaśaṃsinī |
raṇakriyāsurasuraghaṭṭasaṃkaṭā
tadābhavatkhalu sadṛśīha saṃsṛteḥ
]