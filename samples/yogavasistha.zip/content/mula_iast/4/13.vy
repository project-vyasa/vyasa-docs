`v 1 [
trayodaśaḥ sargaḥ 13
kāla uvāca |
etāsāṃ bhūtajātīnāmūrmīṇāmiva sāgarāt |
vividhānāṃ vicitrāṇāṃ latānāmiva mādhave
]

`v 2 [
bhavyā jitamanomohā dṛṣṭalokaparāvarāḥ |
jīvanmuktā bhramantīha yakṣagandharvakiṃnarāḥ
]

`v 3 [
anye tu kāṣṭhakuḍyābhā mūḍhāḥ sthāvarajaṃgamāḥ |
apare kṣīṇamohāste kiṃ teṣāṃ pravicāryate
]

`v 4 [
loke prabudhyamānānāṃ bhūtānāmātmasiddhaye |
viharantīha śāstrāṇi kalpitānyuditātmabhiḥ
]

`v 5 [
saṃprabuddhāśayā ye tu duṣkṛtānāṃ parikṣaye |
teṣāṃ śāstravicāreṣu nirmalā dhīḥ pravartate
]

`v 6 [
vilīyate manomohaḥ sacchāstrapravicāraṇāt |
nabhoviharaṇādbhānoḥ śārvaraṃ timiraṃ yathā
]

`v 7 [
akṣīyamāṇaṃ hi mano mohāyaiva na siddhaye |
nīhāra iva saṃcādya vetāla iva valgati
]

`v 8 [
sarveṣāmeva dehānāṃ sukhaduḥkārthabhājanam |
śarīraṃ mana eveha natu māṃsamayaṃ mune
]

`v 9 [
yo'yaṃ māṃsāsthisaṃghāto dṛśyate pāñcabhautikaḥ |
manovikalpanaṃ viddhi na dehaḥ paramārthataḥ
]

`v 10 [
manaḥśarīreṇa tava putro'yaṃ kṛtavānmune |
tadeva prāptavānāśu vayaṃ nātrāparādhinaḥ
]

`v 11 [
svayā vāsanayā loko yadyatkarma karoti yaḥ |
sa tathaiva tadāpnoti netarasyeha kartṛtā
]

`v 12 [
svānusaṃhitamantaryanmanovāsanayā svayā |
ko nāma bhuvaneśo'sti tatkartuṃ yasya śaktatā
]

`v 13 [
ye sargā narakābhogā yā janmamaraṇaiṣaṇāḥ |
svamanomananenedaṃ sa niṣpando'pi duḥkhadaḥ
]

`v 14 [
bahunātra kimuktena śabdasaṃgrahakāriṇā |
uttiṣṭha bhagavanyāmo yatra te tanayaḥ sthitaḥ
]

`v 15 [
sarvaṃ cittaśarīreṇa bhuktvā śukraḥ kṣaṇādiva |
tathenduraśmisaṃghaṭṭātsamaṅgātāpasaḥ sthitaḥ
]

`v 16 [
sarvaṃ svargabhogaṃ cittakalpitaśarīreṇa bhuktvā atha ākāśādikrameṇa
bhūmāvavatīrṇa induraśmisaṃparkādoṣadhīḥ praviśyānnādibhāvakrameṇa
janmaparamparāṃ prāpya saṃprati samaṅgāyāṃ tāpaso bhūtvā sthita ityarthaḥ |
15 |
tatprāṇapavanaścittānmukta indvaṃśuvatphalam |
avaśyāyatayā bhūtvā vīryaṃ tenāntarāsthitaḥ
]

`v 17 [
ityuktvā bhagavānkālo hasanniva jagadgatim |
hastāddhastena jagrāha bhṛgumindumivāṃśumān
]

`v 18 [
aho nu citrā niyatervyavastheti vadañchanaiḥ |
bhagavānbhṛguruttasthāvudayādreryathā raviḥ
]

`v 19 [
tejonidhī ha samamaṅga smutthitau tau
bhātastadāmbaratale sāmālajāle |
tulyodayāviva nabhasyamale vihartu-
mabhyutthitau sajaladau sakalendusūryau
]

`v 20 [
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā krtanamaskaraṇā jagāma
śyāmākṣaye ravikaraiśca sahājagāma
]