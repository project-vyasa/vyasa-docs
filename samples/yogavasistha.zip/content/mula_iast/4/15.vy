`v 1 [
pañcadaśaḥ sargaḥ 15
śrīvasiṣṭha uvāca |
vicārayantastattvajñā iti te jāgatīrgatīḥ |
samaṅgāyāstaṭāttasmātpraceluścañcalāsavaḥ
]

`v 2 [
kramādākāśamākramya nirgatyāmbudakoṭaraiḥ |
saṃprāpuḥ siddhamārgeṇa kṣaṇānmandarakandaram
]

`v 3 [
adhityakāyāṃ tasyādrerārdraparṇāvaguṇṭhitām |
dadarśa bhārgavaḥ śuṣkāṃ pūrvajanmodbhavāṃ tanum
]

`v 4 [
uvācedaṃ ca he tāta tanvī tanuriyaṃ hi sā |
yā tvayā sukhasaṃbhogaiḥ purā samabhilālitā
]

`v 5 [
iyaṃ sā mattanuryasyāḥ karpūrāgurucandanaiḥ |
aṅgamaṅgīkṛtasnehā dhātrī ciramalepayat
]

`v 6 [
iyaṃ sā mattanuryasyā mandārakusumotkaraiḥ |
racitā śītalā śayyā merūpavanabhūmiṣu
]

`v 7 [
iyaṃ sā mattanurmattadevastrīgaṇalālitā |
sarīsṛpamukhakṣuṇṇā paśya śete dharātale
]

`v 8 [
candanodyānakhaṇḍeṣu mama tanvā yayānayā |
ciraṃ vilasitaṃ seyaṃ śuṣkakaṅkālatāṃ gatā
]

`v 9 [
surāṅganāṅgasaṃsargāduttūṅgānaṅgabhaṅgayā |
cetovṛttyā rahitayā tanvādya mama śuṣyate
]

`v 10 [
teṣu teṣu vilāseṣu tāsu tāsu daśāsu ca |
tathā tadbhāvanābandhaḥ kathaṃ svastho'si dehaka
]

`v 11 [
hā tano śavanāmāsi tāpasaṃśoṣamāgatā |
kaṅkālatāṃ prayātāsi māṃ bhīṣayasi durbhage
]

`v 12 [
dehenāhaṃvilāseṣu `note[alamiti pāṭhaḥ] yenaiva mudito'bhavam |
kaṅkālatāmupagatāttasmādeva bibhemyaham
]

`v 13 [
tārājālasamākāro yatra hāro'bhavatpurā |
mamorasi nilīyante tatra paśya pipīlikāḥ
]

`v 14 [
dravatkāñcanakāntena lobhaṃ nītā varāṅganā |
yena madvapuṣā tena paśya kaṅkālatohyate
]

`v 15 [
paśya me vitatāsyena tāpasaṃśuṣkakṛttinā |
matkaṅkālakuvaktreṇa vitrāsyante vane mṛgāḥ
]

`v 16 [
paśyāmi saṃśuṣkatayā śavodaradarī mama |
prakāśārkāṃśujālena vivekeneva śobhate
]

`v 17 [
mattanuḥ pariśuṣkeyaṃ sthitottānācalopale |
vairāgyaṃ nayatīvātmatucchatvenāntaraṃ satām
]

`v 18 [
śabdarūparasasparśagandhalobhādvimuktayā |
nirvikalpasamādhyeva tadetacchuṣyate girau
]

`v 19 [
muktācittapiśācena nūnaṃ sukhamivāsthitā |
tanurdaivatabhaṅgebhyo na bibheti manāgapi
]

`v 20 [
saṃśānte cittavetāle yāmānandakalāṃ tanuḥ |
yāti tāmapi rājyena jāgatena na gacchati
]

`v 21 [
paśya viśrāntasaṃdehaṃ vigatāśeṣakautukam |
nirastakalanājālaṃ sukhaṃ śete kathaṃ vane
]

`v 22 [
cittamarkaṭasaṃrambhasaṃkṣubdhaḥ kāyapādapaḥ |
tathā vegena calati yathā'mūlānnikṛntati
]

`v 23 [
cittānarthavimukto'drau gajābhraharivigraham |
nādya paśyati me dehaḥ parānanda iva sthitaḥ | 23 |
adrau asminmandare me dehaścittalakṣaṇenānarthena vimuktaḥ sannadya
gajānāmabhrairmeghairharibhiḥ siṃhaiśca vigrahaṃ vairaṃ
yuyutsāpratigarjanābhigamanādilakṣaṇaṃ na paśyati |
prākkautukadarśanaparānande sthita iva yathā prāgbahiḥ kautukadarśanena nandati
tathādya netyarthaḥ | athavā adrau sphaṭikaśilāsu pratibimbitaṃ jagābhraharīṇāṃ
vigrahaṃ yuddhaṃ mūrtiṃ vādya na paśyatītyarthaḥ | nāṭyaṃ paśyati iti pāṭhe tu
yathā parānande paramātmani sthito jīvanmuktaḥ prathamaṃ gajamiva sthūlaṃ
abhramiva sūkṣmaṃ harimiva kāraṇaṃ ca vigrahāḥ śarīrāṇi
yasmiṃstathāvidhamātmanaṭasya nāṭyaṃ paśyati tathā mama deho'pi
cittānarthavimuktatvādeva pṛthak sthitena madātmanā asmiñjadrau kvacidravāḥ
kvacidabhrāṇi kvaciddharayaḥ siṃhamarkaṭādaya iti nānāvigrahamātmanaṭasya
nāṭyaṃ paśyatītyarthaḥ
]

`v 24 [
sarvāśājvarasaṃmohamihikāśaradāgamam |
acittatvaṃ vinā nānyacchreyaḥ paśyāmi jantuṣu
]

`v 25 [
ta eva sukhasaṃbhogasīmāntaṃ samupāgatāḥ |
mahādhiyā śāntadhiyo ye yātā vimanaskatām
]

`v 26 [
sarvaduḥkhadaśāmuktāṃ saṃsthitāṃ vigatajvarām |
diṣṭyā paśyāmyamananāṃ vane tanumimāmaham
]

`v 27 [
śrīrāma uvāca |
bhagavansarvadharmajña bhārgaveṇa tadā kila |
subahūnyupabhuktāni śarīrāṇi punaḥpunaḥ
]

`v 28 [
bhṛguṇotpādite kāye tattasmiṃstasya kiṃ punaḥ |
mahānatiśayo jātaḥ paridevanameva vā
]

`v 29 [
śrīvasiṣṭha uvāca |
śukrasya kalanā rāma yāsau jīvadaśāṃ gatā |
karmātmikā samutpannā bhṛgorbhārgavarūpiṇī
]

`v 30 [
sā hīdaṃprathamatvena samupetya parātpadāt |
bhūtākāśapadaṃ prāpya vātavyāvalitā satī
]

`v 31 [
prāṇāpānapravāheṇa praviśya hṛdayaṃ bhṛgoḥ |
krameṇa vīryatāmetya saṃpannauśanasī tanuḥ
]

`v 32 [
vihitabrāhmasaṃskārā tatra sā pituragragā |
kālena mahatā prāptā śuṣkakaṅkālarūpatām
]

`v 33 [
idaṃprathamamāyātā yadāsau brahmaṇastanuḥ |
atastāṃ prati śukreṇa tadā tatparidevitam
]

`v 34 [
vītarāgo'pyaniccho'pi samaṅgāviprarūpavān |
sa śuśoca tanuṃ śukraḥ svabhāvo hyeṣa dehajaḥ
]

`v 35 [
jñasyājñasya ca dehasya yāvaddehamayaṃ kramaḥ |
lokavadvyavahāro'yaṃ saktyāsaktyāthavā sadā
]

`v 36 [
yāvaddehaṃ yāvajjīvanaṃ sadā sarvakāle kramo maryādāniyamaḥ na
kadācidvyabhicaratītyarthaḥ | jñasya saktyā ajñasya tvasaktyeti viśeṣa ityarthaḥ |
35 |
ye parijñātagatayo ye cājñāḥ paśudharmiṇaḥ |
lokasaṃvyavahāreṣu te sthitā lokajālavat
]

`v 37 [
vyavahāre yathaivājñastathaivākhilapaṇḍitaḥ |
vāsanāmātrabhedo'tra kāraṇaṃ bandhamokṣadam
]

`v 38 [
yāvaccharīraṃ tāvaddhi duḥkhe duḥkhaṃ sukhe sukham |
asaṃsaktadhiyo dhīrā darśayantyaprabuddhavat
]

`v 39 [
sukheṣu sukhitā nityaṃ duḥkhitā duḥkhavṛttiṣu |
mahātmāno hi dṛśyante dṛśya evāprabuddhavat
]

`v 40 [
sūryasya pratibimbāni kṣubhyanti na punaḥ sthiram |
calācalatayā tajjño lokavṛttiṣu tiṣṭhati
]

`v 41 [
avasthita iva svasthaḥ pratibimbeṣu bhāskaraḥ |
saṃtyaktalokakarmāpi buddha evāprabuddhadhīḥ
]

`v 42 [
muktabuddhīndriyo mukto baddhakarmendriyo'pi hi |
baddhabuddhindriyo baddho muktakarmendriyo'pi hi
]

`v 43 [
sukhaduḥkhadṛśo loke bandhamokṣadṛśastathā |
heturbuddhindriyāṇyeva tejāṃsīva prakāśane
]

`v 44 [
bahirlokocitācārastvantarācāravarjitaḥ |
samo hyatīva tiṣṭha tvaṃ saṃśāntasakalaiṣaṇaḥ
]

`v 45 [
sarvaiṣaṇāvimuktena svātmanātmani tiṣṭhatā |
kuru karmāṇi kāryāṇi nūnaṃ dehasya saṃsthitiḥ
]

`v 46 [
ādhivyādhimahāvartagartasaṃsāravartmani |
mamatogrāndhakūpe'sminmā patātāpadāyini
]

`v 47 [
na tvaṃ bhāveṣu no bhāvāstvayi tāmarasekṣaṇa |
śuddhabuddhasvabhāvastvamātmāntaḥ susthiro bhava
]

`v 48 [
tvaṃ brahma hyamalaṃ śuddhaṃ tvaṃ sarvātmā ca sarvakṛt |
sarvaṃ śāntamajaṃ viśvaṃ bhāvayanvai sukhī bhava
]

`v 49 [
vyapagatamamatāmahāndhakāraḥ
padamamalaṃ vigataiṣaṇaṃ sametya |
prabhavasi yadi cetaso mahātmaṃ-
stadatidhiye mahate sate namaste
]