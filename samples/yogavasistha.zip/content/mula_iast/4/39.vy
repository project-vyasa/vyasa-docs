`v 1 [
ekonacatvāriṃśaḥ sargaḥ 39
śrīrāma uvāca |
bhagavannevaṃ sthite pare brahmaṇyeva vidyamāne kuta
evābhitticitrarūpāyāḥ sṛṣṭeragama iti kathaya mahātman
]

`v 2 [
śrīvasiṣṭha uvāca
rājaputra brahmatattvamevedamāvartate yasmātsarvaśakti tattasmātsarvāḥ
śaktayo brahmaṇi dṛśyante
]

`v 3 [
sattvamasattvaṃ dvitvamekatvamanekatvamādyatvamantatvamiti
]

`v 4 [
tacca nānyat | yathā jalarāśerjalāśaya ullāsapraphullāsena nānākāratāṃ
`note[nānākāratāditi pāṭhaḥ] darśayanprakaṭatāṃ gacchati
]

`v 5 [
tathā ciddhanaścittaṃ cittvācca sarvāḥ śaktīḥ
karmamayīrvāsanāmayīrmanomayīścinoti darśayati bibharti janayati
kṣipayati ceti
]

`v 6 [
sarveṣāmeva jīvānāṃ sarvāsāmabhito dṛśām |
samagrāṇāṃ padārthānāmutpattirbrahmaṇo'niśam
]

`v 7 [
lokātparādupāyānti tasmiṃścittvādviśantyalam |
tanmayā eva satataṃ taraṅgā iva sāgare
]

`v 8 [
śrīrāma uvāca |
bhagavaṃstavātigahaneyaṃ vacanavyaktirna khalvadya
vākyārthamavagacchāmi
]

`v 9 [
evaṃ śaktivādena samādhīyamāno'pi rāmo vahnau śaityaśaktimiva jale
dahanaśaktimiva viruddhāṃ citi jāḍyaśaktiṃ adṛśye dṛśyatāśaktiṃ nitye
anityatāśaktiṃ ca brahmaṇyasaṃbhāvayan śaṅkate - bhagavannityādinā |
vacanavyaktirvākyārthāvagatiḥ | atigahanā duḥsaṃpādā virodhasattvādityarthaḥ |
8 |
kva kilātītamanaḥṣaṣṭhendriyavṛtti brahmatattvaṃ kva bhaṅgureyaṃ tajjā
padārthaśrīriti vacanaracanā | yadi cāyamārambho brahmaṇa
āpatitastadanena tatsadṛśenaiva bhavitavyam
]

`v 10 [
yo yasmājjāyate sa tatsadṛśa eva bhavati
]

`v 11 [
yathā dīpāddīpaḥ puruṣātpuruṣaḥ sasyātsasyam
]

`v 12 [
yato nirvikārādyadāgataṃ nirvikāreṇaivānena bhavitavyam
]

`v 13 [
athaitadvyatiriktaṃ cidātmanastanniṣkalaṅkasya parameśvarasya yeyaṃ
kalaṅkāpattirityākarṇya bhagavān brahmarṣiruvāca `note[etadagre
śrīvasiṣṭha uvāceti kvacit paṭhyate]
]

`v 14 [
brahmaivedaṃ sthitaṃ nāma malamastīha nānagha |
taraṅgaughagaṇairambhaḥ sindhau sphurati no rajaḥ
]

`v 15 [
dvitīyā kalpanaiveha na raghūdvaha vidyate |
brahmamātrādṛte vahvāvauṣṇyamātrādṛte yathā
]

`v 16 [
śrīrāma uvāca |
nirduḥkhaṃ brahma nirdvandvaṃ tajjaṃ duḥkhamayaṃ jagat |
aspaṣṭārthamidaṃ brahmanna vedmi vacanaṃ tava
]

`v 17 [
śrīvālmīkiruvāca |
ityukte tatra rāmeṇa cintayāmāsa cetasā |
vasiṣṭho muniśārdūlo rāghavasyopadeśane
]

`v 18 [
paraṃ vikāsamāyātā nāsya tāvadiyaṃ matiḥ |
kiṃcinnirmalatāṃ prāptā prohyate ceha vastuni
]

`v 19 [
yo vyutpannamanāstasya jñātajñeyasya dhīmataḥ |
mokṣopāyagirāṃ pāraṃ prayātasya vivekataḥ
]

`v 20 [
na kaścitkasyaciddoṣo nāsti vidyātmani hyalam |
yāvannoktaṃ na viśrāntiṃ tāvadetyeṣa rāghavaḥ
]

`v 21 [
ardhavyutpannabuddhestu naitadvyaktaṃ hi śobhate |
dṛśyānayā bhogadṛśā bhāvayanneṣa naśyati
]

`v 22 [
parāṃ dṛṣṭiṃ prayātasya bhogecchā nābhijāyate |
sarvaṃ brahmeti siddhāntaḥ kāle nāmāsya yujyate
]

`v 23 [
ādau śamadamaprāyairguṇaiḥ śiṣyaṃ viśodhayet |
paścātsarvamidaṃ brahma śuddhastvamiti bodhayet
]

`v 24 [
ajñasyārdhaprabuddhasya sarvaṃ brahmeti yo vadet |
mahānarakajāleṣu sa tena viniyojitaḥ
]

`v 25 [
prabuddhabuddheḥ prakṣīṇabhogecchasya nirāśiṣaḥ |
nāstyavidyāmalamiti yuktaṃ vaktuṃ mahātmanaḥ
]

`v 26 [
aparīkṣya ca yaḥ śiṣyaṃ praśāstyativimūḍhadhīḥ |
sa eva narakaṃ yāti yāvadābhūtasaṃplavam
]

`v 27 [
iti saṃcintya bhagavānajñānatimirāpahaḥ |
tamuvāca muniśreṣṭho vasiṣṭho bhūmibhāskaraḥ
]

`v 28 [
śrīvasiṣṭha uvāca |
kalaṅkakalanā brahmaṇyasti nāstīti vānagha |
siddhāntakāle vaktavyaṃ svayaṃ jñāsyasi rāghava
]

`v 29 [
brahma sarvaśakti sarvavyāpi sarvagataṃ sarvohameveti
]

`v 30 [
yathendrajālinaḥ paśyasi citrā māyayā kriyā janayantaḥ sadasattāṃ
nayantyasacca sattāṃ nayanti tathaivātmā amāyāmayo'pi māyāmaya iva
parama aindrajāliko ghaṭaṃ paṭaṃ karoti paṭaṃ ca ghaṭaṃ karoti upale
latāṃ janayati merau kanakataṭe nandanavanamiva latāyāmupalamutpādayati
kalpapādapeṣu ratnastabakamiva vyomni kānanamadhyāropayati
]

`v 31 [
gandharva udyānamiva tasmin jagati bhaviṣyati gagane kalpanayā nagaratāṃ
janayati naṣṭacchāyāñjanamiva vyoma dharātalaṃ nayatīti
]

`v 32 [
gandharvanagararājagṛhe vipulāṅganājanamiva bhūtale vyoma niveśayati |
32 |
tarhi kiṃ gaganasyādho niveśāya bhūtalamanyato nayati netyāha -
gandharvanagareti
]

`v 33 [
raktakuṭṭimeṣvākāśapratibimbamiva kiṃcidasti jagati bhaviṣyati vā babhūva
]

`v 34 [
yadīśvaro vyaktarūpo vicitratāmupetya nidarśayati
]

`v 35 [
sarvameva sarvathā sarvatra yathā saṃbhavatyekameveha vastu vidyata iti
tasmāddharṣāmarṣavismayānāṃ kva vā'vasaro rāma
]

`v 36 [
samatayaiva satataṃ dhṛtimatā sthātavyam
]

`v 37 [
vismayasmayasaṃmohaharṣāmarṣavikāritām |
samatāvalitastajjño na kadācana gacchati
]

`v 38 [
aparyavasāne deśakālavati citrā hi jagati yuktayo dṛśyante
]

`v 39 [
etāśca yuktīrnāmāsāvātmā yatnena racanāṃ karoti na cotpannāṃ
tiraskāroti sāgara iva vīcīḥ
]

`v 40 [
kiṃ tarhi kṣīra iva ghṛtaṃ ghaṭa iva mṛdi paṭa iva tantuṣu vaṭa iva
dhānāyātmanyeva sthitāḥ śaktayaḥ prakaṭatāmāgatā
vyavahriyante'viracitameva taraṅgavat
]

`v 41 [
nātra kaścitkartā na bhoktā na vināśameti
]

`v 42 [
kevalamātmatattve sākṣiṇi nirāmaye samatayātmani nityamasaṃkṣubdhe
tiṣṭhati satyevaṃ saṃpadyate
]

`v 43 [
sati dīpa ivālokaḥ satyarka iva vāsaraḥ |
sati puṣpa ivāmodaḥ svataḥ saṃpadyate jagat
]

`v 44 [
ābhāsamātramevedaṃ paridṛśyata eva ca |
spandaḥ samīraṇasyeva na sannāsadavasthitam
]

`v 45 [
nirdoṣavadeva jāgatīnāṃ dṛṣṭīnāṃ paramārthato bhagavānsthito
vinaṣṭānāṃ punaḥ kartā kṛtānāṃ vā nāśayitā sa kevalaṃ
kadācitprakaṭāḥ kadācidalpaprakaṭāḥ kadācidaprakaṭāstārakā iva
kusumarāśayaḥ
]

`v 46 [
naśyatīha hi tadvastu nātmabhūtaṃ yadātmanaḥ |
kathaṃ naśyati tadvastu svātmabhūtaṃ yadātmanaḥ
]

`v 47 [
jāyate naiva tadvastu nātmabhūtaṃ yadātmanaḥ |
jāyate caiva tadvastu svātmabhūtaṃ yadātmanaḥ
]

`v 48 [
kathaṃ tajjāyate tasmātsvātmabhūtaṃ yadātmanaḥ
]

`v 49 [
tasmātsamyagjñānavaśādbrahmaṇaḥ sarvapadārthānāmāgamaḥ
]

`v 50 [
avatīrṇānāṃ ca teṣāmavataraṇasamakālamevāvidyodeti tattvajñānaṃ
dṛḍhatāmeti tadanu śatasahasraskandho
vicitraśubhāśubhaphalabharaphalito bhūriśākhaḥ sphāratāmeti
saṃsāradrumaḥ
]

`v 51 [
āśāmañjaritākṛtiṃ viphalitaṃ duḥkhādibhirdāruṇairbhogaiḥ pallavitaṃ
jarākusumitaṃ tṛṣṇālatābhāsuram |
saṃsārābhidhavṛkṣamātmanigaḍaṃ chittvā vivekāsinā muktastvaṃ
vihareha vāraṇapatiḥ stambhādivonmocitaḥ
]