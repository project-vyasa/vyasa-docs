`v 1 [
saptamaḥ sargaḥ 7
iti śukraḥ puraṃ prāpya vaibudhaṃ svena tejasā |
visasmāra nijaṃ bhāvaṃ prāktanaṃ vyasanaṃ vinā
]

`v 2 [
muhūrtamiva viśramya tasya pārśve śacīpateḥ |
svargaṃ vihartumuttasthau svargābhiparimoditaḥ
]

`v 3 [
svaḥśriyaṃ sa samālokya lolalocanavāñchitām |
straiṇaṃ draṣṭuṃ jagāmāsau nalinīmiva sārasaḥ
]

`v 4 [
tatra tāṃ mṛgaśāvākṣīṃ kāntāmadhyagatāmasau |
dadarśa vipināntasthāṃ bhṛguścūtalatāmiva
]

`v 5 [
sāpi taṃ bhārgavaṃ rāma dṛṣṭvā paravaśābhavat |
tāmālokya lasallolavilāsavalitākṛtim
]

`v 6 [
āsīdvilīyamānāṅgo jyotsnāmindumaṇiryathā |
vilīyamānasarvāṅgastāmavaikṣata kāminīm
]

`v 7 [
candrakānta iva jyotsnāṃ śītalāṃ khe vilāsinīm |
tenāvalokitā sāpi tatparāyaṇatāṃ gatā
]

`v 8 [
niśānte cakravākena kānteva parikūjitā |
rasādvikasitā nūnamanyonyamanuraktayoḥ
]

`v 9 [
prātararkanalinyoryā śobhā saiva tayorabhūt |
saṃkalpitārthadāyitvāddeśasyābhūcca tena sā
]

`v 10 [
sarvāṅgaṃ vivaśīkṛtya kāmāyaiva samarpitā |
petuḥ smaraśarāstasyā mṛduṣvaṅgeṣu bhūriśaḥ
]

`v 11 [
palāśeṣviva padminyā dhārā iva payomucaḥ |
sā babhūva smaroddhūtā lolālivalayākulā
]

`v 12 [
mandavātābhinunnāyā mañjaryāḥ sahadharmiṇī |
nīlanīrajanetrāntāṃ haṃsasārasagāminīm
]

`v 13 [
madanaḥ kṣobhayāmāsa gajaḥ kamalinīmiva |
atha tāṃ tādṛśīṃ dṛṣṭvā śukraḥ saṃkalpitārthabhāk
]

`v 14 [
tamaḥ saṃkalpayāmāsa saṃhāra iva bhūtabhuk |
triviṣṭapasya deśo'sau babhūva timirākulaḥ
]

`v 15 [
bhūlokasyāndhatamasā lokālokataṭo yathā |
lajjāndhakāratīkṣṇāṃśau tasmiṃstimiramaṇḍale
]

`v 16 [
pratiṣṭhāmāgate tasya mithunasyeva maṇḍale |
teṣu sarveṣu bhūteṣu gateṣvabhimatāṃ diśam
]

`v 17 [
tasmātpradeśādbhūloke dinānte vihageṣviva |
sā dīrghacañcalāpāṅgī pravṛddhamadanavyathā
]

`v 18 [
ājagāma bhṛgoḥ putraṃ mayūrī vāridaṃ yathā |
dhavalāgāramadhyasthe paryaṅke parikalpite
]

`v 19 [
viveśa bhārgavastatra kṣīroda iva mādhavaḥ |
sā karāvavalambyāsya viveśāvanatānanā
]

`v 20 [
rarāja ca surebhasya hṛdi lagneva padminī |
uvāca cedaṃ madhuraṃ rasasnehāktayā girā
]

`v 21 [
vaco madhuramānandavilāsavalitākṣaram |
paśyāmalenduvadanamaṇḍalīkṛtakārmukaḥ
]

`v 22 [
abalāmanubadhnāti māmeṣa kila nāṅgakaḥ |
pāhi māmabalāṃ nātha dīnāṃ tvaccharaṇāmiha
]

`v 23 [
kṛpaṇāśvāsanaṃ sādho viddhi saccaritavratam |
snehadṛṣṭimajānadbhirmūḍhaireva mahāmate
]

`v 24 [
praṇayā avagaṇyante na rasajñaiḥ kadācana |
aśaṅkitopasaṃpannaḥ praṇayo'nyonyaraktayoḥ
]

`v 25 [
adhaḥkaroti niṣyandaṃ candramāhlādanaṃ priya |
na tathā sukhayatyeṣā cetastribhuvaneśitā
]

`v 26 [
yathā parasparānandaḥ snehaḥ prathamaraktayoḥ |
tvatpādasparśaneneyaṃ samāśvastāsmi mānada
]

`v 27 [
candrapādaparāmṛṣṭā yathā niśi kumudvatī |
saṃsparśāmṛtapānena tava jīvāmi sundara
]

`v 28 [
candrāṃśurasapānena cakorī capalā yathā |
māmimāṃ caraṇālīnāṃ bhramarīṃ karapallavaiḥ
]

`v 29 [
āliṅgyāmṛtasaṃpūrṇe svapadmahṛdaye kuru |
ityuktvā puṣpamṛdvaṅgī sā tasya patitorasi |
vyāghūrṇitālinayanā sutaroriva mañjarī
]

`v 30 [
tau dampatī tatra vilāsakāntī
viveśatustāsu vanasthalīṣu |
kiñjalkagaurānilaghūrṇitāsu
raktau dvirephāviva padminīṣu
]