`v 1 [
viṃśaḥ sargaḥ 20
śrīvasiṣṭha uvāca |
etatte kathitaṃ sarvaṃ manorūpanirūpaṇam |
mayā rāghava nānyena kenacinnāma hetunā
]

`v 2 [
dṛḍhaniścayavacceto yadbhāvayati bhūriśaḥ |
tattāṃ yātyanalāśleṣādayaḥpiṇḍo'gnitāmiva
]

`v 3 [
bhāvābhāvagrahotsargadṛśaścetanakalpitāḥ |
nāsatyā nāpi satyāstā manaścāpalakāritāḥ
]

`v 4 [
mano mohe tu kartṛ syātkāraṇaṃ ca jagatsthiteḥ |
viśvarūpatayaivedaṃ tanoti malinaṃ manaḥ
]

`v 5 [
mano hi puruṣo nāma taṃ niyojya śubhe pathi |
tajjayaikāntasādhyā hi sarvā jagati bhūtayaḥ
]

`v 6 [
puruṣaśceccharīraṃ syātkathaṃ śukro mahāmatiḥ |
agamadvividhākāraṃ janmāntaraśatabhramam `note[janāntara iti
pāṭhaḥ]
]

`v 7 [
ataścittaṃ hi puruṣaḥ śarīraṃ cetyameva hi |
yanmayaṃ ca bhavatyetattadavāpnotyasaṃśayam
]

`v 8 [
yadatucchamanāyāsamanupādhi gatabhramam |
yatnāttadanusaṃdhānaṃ kuru tattāmavāpsyasi
]

`v 9 [
abhipatati manaḥsthitaṃ śarīraṃ
natu vapurācaritaṃ manaḥ prayāti |
abhipatatu tavātra tena satyaṃ
subhaga manaḥ prajahātvasatyamanyat
]