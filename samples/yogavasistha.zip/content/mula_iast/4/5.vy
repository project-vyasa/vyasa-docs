`v 1 [
pañcamaḥ sargaḥ 5
śrīrāma uvāca |
bhagavansarvadharmajña pūrvāparavidāṃ vara |
ayaṃ manasi saṃsāraḥ sphāraḥ kathamiva sthitaḥ
]

`v 2 [
yathāyaṃ manasi sphāraḥ saṃsāraḥ sphurati sphuran |
dṛṣṭāntadṛṣṭyā sphuṭayā tathā kathaya me'nagha
]

`v 3 [
śrīvasiṣṭha uvāca |
yathaindavānāṃ viprāṇāṃ jagantyavapuṣāmapi |
sthitāni jātadārḍhyāni manasīdaṃ tathā sthitam
]

`v 4 [
lavalaṇasya yathā rājñaścendrajālākulākṛteḥ |
caṇḍālatvamanuprāptaṃ tathedaṃ manasi sthitam
]

`v 5 [
bhārgavasya ciraṃ kālaṃ svargabhogabubhukṣayā |
yathā bhogādhināthatvaṃ saṃsāritvaṃ babhūva ca
]

`v 6 [
bhogeśvaratvaṃ ca yathā `note[tathā iti pāṭhaḥ] tathedaṃ manasi sthitam |
śrīrāma uvāca |
bhagavanbhṛguputrasya svargabhogabubhukṣayā
]

`v 7 [
kathaṃ bhogādhināthatvaṃ saṃsāritvaṃ babhūva ca |
śrīvasiṣṭha uvāca |
śṛṇu rāma purā vṛttaṃ saṃvādaṃ bhṛgukālayoḥ
]

`v 8 [
sānau mandaraśailasya tamālaviṭapākule |
purā mandaraśailasya sānau kusumasaṃkule
]

`v 9 [
atapyata tapo ghoraṃ kasmiṃścidbhagavānbhṛguḥ |
tamupāste sma tejasvī bālaḥ putro mahāmatiḥ
]

`v 10 [
śukraḥ sakalacandrābhaḥ `note[tathā iti pāṭhaḥ] prakāśa iva bhāsuraḥ
|
bhṛgurvanavare tasminsamādhāveva saṃsthitaḥ
]

`v 11 [
sakalaḥ pūrṇaḥ | bhāskara iti pāṭhe prakāśata iti prakāśaḥ sphuran bhāskara iva |
10 |
sarvakālaṃ samutkīrṇo vanopalatalādiva |
śukraḥ kusumaśayyāsu kaladhautājireṣu ca
]

`v 12 [
mandaroddāmadolāsu bālo ramaṇalīlayā |
vidyāvidyādṛśormadhye śukraḥ prāptamahāpadaḥ
]

`v 13 [
triśaṅkuriva rodontaravartata tadākulaḥ |
nirvikalpasamādhisthe sa kadācitpitaryatha
]

`v 14 [
avyagro'bhavadekānte jitāririva bhūmipaḥ |
dadarśāpsarasaṃ tatra gacchantīṃ nabhasaḥ pathā
]

`v 15 [
kṣīrodamadhyalulitāṃ lakṣmīmiva janārdanaḥ |
mandāramālāvalitāṃ mandānilacalālakām
]

`v 16 [
hārajhāṅkārigamanāṃ sugandhitanabhonilām |
lāvaṇyapādapalatāṃ madaghūrṇitalocanām
]

`v 17 [
amṛtīkṛtataddeśāṃ dehendūdayadīptibhiḥ |
kāntāmālokya tasyābhūdullasattaralaṃ manaḥ
]

`v 18 [
dṛṣṭanirmalapūrṇenduvapurambunidheriva |
sāpyālokya śukramukhaṃ tathā paravaśā hyabhūt
]

`v 19 [
manasijeṣu parāhatamāśayaṃ
sa paribodhya manastadanūśanā |
vigalitetaravṛttitayātmanā
sa ca vadhūmaya eva babhūva ha
]