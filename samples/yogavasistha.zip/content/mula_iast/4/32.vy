`v 1 [
dvātriṃśaḥ sargaḥ 32
śrīrāma uvāca |
satāmapyasatāmeva bālayakṣapiśācavat |
dāmavyālakaṭādīnāṃ duḥkhasyāntaḥ kathaṃ bhavet
]

`v 2 [
śrīvasiṣṭha uvāca |
dāmavyālakuṭumbaistaistadaiva yamakiṅkaraiḥ |
prārthitena yamenoktamidaṃ śṛṇu raghūdvaha
]

`v 3 [
yadā viyogameṣyanti śroṣyanti ca nijāṃ kathām |
dāmādayastadā muktā bhaviṣyantītyasaṃśayam
]

`v 4 [
śrīrāma uvāca |
svavṛttāntamimaṃ kutra kadā kathayate katham |
śroṣyanti bhagavaṃste vā varṇayedaṃ yathākramam
]

`v 5 [
śrīvasiṣṭha uvāca |
kāśmīreṣu mahāpadmasarasītīrapalvale |
bhūyobhūyo'nubhūyaiva matsyayoniparamparām
]

`v 6 [
ālolitāśayā lolāḥ kālena layamāgatāḥ |
tatraiva padmasarasi te bhaviṣyanti sārasāḥ
]

`v 7 [
tatra khlāramālāsu sarojapaṭalīṣu ca |
śaivālavaravalliṣu taraṅgavalanāsu ca
]

`v 8 [
calatkusumadolāsu nīlotpalalatāsu ca |
sīkaraughābhralekhāsu śītalāvartavartiṣu
]

`v 9 [
sārasāḥ sarasaṃbhogānbhuktvā bhuvanabhūṣaṇāḥ |
vihṛtya suciraṃ kālamalamāgataśuddhayaḥ
]

`v 10 [
te viyuktā bhaviṣyanti muktaye labdhabuddhayaḥ |
rajaḥsattvatamāṃsīva bhedaṃ prāpya yadṛcchayā
]

`v 11 [
kāśmīramaṇḍalasyāntarnagaraṃ nagaśobhitam |
nāmnādhiṣṭhānamityeva śrīmattasya bhaviṣyati
]

`v 12 [
pradyumnaśikharaṃ nāma tasya madhye bhaviṣyati |
śṛṅgaṃ laghu sarojasya kośacakramivodare
]

`v 13 [
tasya mūrdhni girergehaṃ kaścidrājā bhaviṣyati |
abhraṃkaṣamahāśālaṃ śṛṅge `note[śālaśṛṅge iti ṭikānuguṇaḥ
pāṭhaḥ] śṛṅgamivāparam
]

`v 14 [
gṛhasyeśānakoṇe'sti śirobhittivraṇodare |
tasyāniśamaviśrāntavātādhūtatṛṇāntike
]

`v 15 [
ālaye dānavo vyālaḥ kalaviṅko bhaviṣyati |
prathamālpaśrutaśāstra ivārtharahitāravaḥ
]

`v 16 [
tasminneva tadā kāle tatra rājā bhaviṣyati |
śrīyaśaskaradevākhyaḥ śakraḥ svarga ivāparaḥ
]

`v 17 [
dānavo dāmanāmātra maśakastasya sadmani |
bhaviṣyati bṛhatstambhapṛṣṭhacchidre mṛdudhvaniḥ
]

`v 18 [
adhiṣṭhānābhidhe tasminnevāntarnagare tadā |
ratnāvalīvihārākhyo vihāro'pi bhaviṣyati
]

`v 19 [
tasmiṃstadbhūmipāmātyo narasiṃha iti śrutaḥ |
karāmalakavaddṛṣṭabandhamokṣo nivatstyati
]

`v 20 [
bhaviṣyati gṛhe tasya krīḍanaḥ krakaraḥ khagaḥ |
kaṭo māyāsuro nāma kṛtarājatapañjaraḥ
]

`v 21 [
sa nṛsiṃho nṛpāmātyaślokairviracitāmimām |
dāmavyālakaṭādīnāṃ kathayiṣyati satkathām
]

`v 22 [
sakaṭaḥ krakaraḥ śrutvā tatkathāsaṃsmṛtātmabhūḥ |
śāntamitthaṃ mahāśāntaṃ paraṃ nirvāṇameṣyati
]

`v 23 [
pradyimnaśikharaprāntavāstavyaḥ kalaviṅkakaḥ |
tatratyaiśca kathāṃ śrutvā paraṃ nirvāṇameṣyati
]

`v 24 [
rājamandiradārvantarvraṇavāstavyatāṃ gataḥ |
maśako'pi prasaṅgena śrutvā śāntimupaiṣyati
]

`v 25 [
pradyumnaśṛṅgāccaṭako maśako rājamandirāt |
vihārātkrakaraśceti mokṣameṣyanti rāghava
]

`v 26 [
eṣa te kathitaḥ sarvo dāmavyālakathākramaḥ |
māyaivameva saṃsāraśūnyaivātyantabhāsurā
]

`v 27 [
bhramayatyaparijñānānmṛgatṛṣṇāmbudhīriva |
mahato'pi padādevaṃ nānājñānavaśādadhaḥ
]

`v 28 [
patanti mohitā mūḍhā dāmavyālakaṭā iva |
kva bhrūkṣepaviniṣpiṣṭamerumandarasadmatā
]

`v 29 [
kva rājagṛhadārvantarvraṇe maśakarūpatā |
kva capeṭabhujāmātrapātitārkendubimbatā
]

`v 30 [
kva pradyumnagirau gehe bhittivraṇavihaṅgatā |
kva puṣpalīlayā lolakaratolitamerutā
]

`v 31 [
kva vā śṛṅge nṛsiṃhasya gṛhe krakarapotatā |
cidākāśo'hamityeva rajasā rañjitaprabhaḥ
]

`v 32 [
svarūpamatyajanneva virūpamapi budhyate |
svayaiva vāsanābhrāntyā satyayevāpyasatyayā
]

`v 33 [
mṛgatṛṣṇāmbubuddhyeva yāti janturivāntaram |
taranti te bhavāmbhodhiṃ svapravāhadhiyaiva ye
]

`v 34 [
śāstreṇāsāditaṃ dṛśyamiti nirvāṇasaṃsthitāḥ |
nānāduḥkhavikārāṇi śuṣkatarkamatāni ye
]

`v 35 [
yānti śvabhraṃ `note[svabhraṃ ityapi pāṭhaḥ] jalānīva svalābhaṃ
nāśayanti te |
svānubhūtiprasiddhena mārgeṇāgamagāminā
]

`v 36 [
na vināśo bhavatyaṅga gacchatāṃ paramāṃ gatim |
idaṃ me syādidaṃ me syāditibuddhermahāmate `note[buddherityatra
vṛddhairiti kvacitpaṭhyate]
]

`v 37 [
svena daurbhāgyadainyena na bhasmāpyupatiṣṭhate |
vetti nityamudārātmā trailokyamapi yastṛṇam
]

`v 38 [
taṃ tyajantyāpadaḥ sarvāḥ sarpā iva jarattvacam |
parisphurati yasyāntarnityaṃ sattvacamatkṛtiḥ
]

`v 39 [
brāhmamaṇḍamivākhaṇḍaṃ lokeśāḥ pālayanti tam |
apyāpadi durantāyāṃ naiva gantavyamakrame
]

`v 40 [
rāhurapyakrameṇaivaṃ pabannapyamṛtaṃ mṛtaḥ |
sacchāstrasādhusaṃparkamarkamugraprakāśadam
]

`v 41 [
ye śrayante na te yānti mohāndhyasya punarvaśam |
avaśyā vaśyatāṃ yānti yānti sarvāpadaḥ kṣayam
]

`v 42 [
akṣayaṃ bhavati śreyaḥ kṛtaṃ yena guṇairyaśaḥ |
yeṣāṃ guṇeṣvasaṃtoṣo rāgo yeṣāṃ śrutaṃ prati
]

`v 43 [
satyavyasanino ye ca te narāḥ paśavo'pare |
yaśaścandrikayā yeṣāṃ bhāsitaṃ jantuhṛtsaraḥ
]

`v 44 [
teṣāṃ kṣīrasamudrāṇāṃ nūnaṃ mūrtau sthito hariḥ |
bhuktaṃ bhoktavyamakhilaṃ dṛṣṭā draṣṭavyadṛṣṭayaḥ
]

`v 45 [
kimanyadbhavabhaṅgāya bhūyo bhogeṣu lubdhatā |
yathākramaṃ yathāśāstraṃ yathācāraṃ yathāsthiti
]

`v 46 [
sthīyatāṃ mucyatāmantarbhogajālamavāstavam |
saṃstavaḥ kriyatāṃ kīrtyā guṇairgaganagāmibhiḥ
]

`v 47 [
trāyete mṛtyuto hyete na kadācana bhogakāḥ |
gāyanti siddhasundaryo yeṣāmindusitaṃ yaśaḥ
]

`v 48 [
gītibhirgaganābhogaiste jīvanti mṛtāḥ pare |
paramaṃ pauruṣaṃ yatnamāsthāyādāya sūdyamam
]

`v 49 [
yathāśāstramanudvegamācaranko na siddhibhāk |
yathāśāstraṃ viharatā tvarā kāryā na siddhiṣu
]

`v 50 [
cirakālaparipakvā siddhiḥ puṣṭaphalā bhavet |
vītaśokabhayāyāsamagarvamapayantraṇam
]

`v 51 [
vyavahāro yathāśāstraṃ kriyatāṃ mā vinaśyatām |
jīvo jīrṇāndhakūpeṣu bhaveṣvantamivāgataḥ
]

`v 52 [
bhavatāṃ bhūrisaṅgānāmadhunendriyadāmataḥ |
itaḥprabhṛti mā bhūyo gamyatāmadhamādadhaḥ
]

`v 53 [
idaṃ vicāryatāṃ śāstramastramāpannivāraṇam |
raṇe śitaśaraśreṇiśatanirlūnavāraṇe
]

`v 54 [
jīvamudrā ca kiṃ paṅke bhogagandho nirasyatām |
kimarthamātrayā kāryamāryāḥ śāstramavekṣyatām
]

`v 55 [
idaṃ bimbamidaṃ bimbamiti satyaṃ vicāryatām |
dhiyā parapreraṇayā yātamāpaśavo yathā
]

`v 56 [
daurbhāgyadāyinī dīnā śubhahīnā vicāraṇā |
ghanadīrghamahānidrā tyajyatāṃ saṃprabudhyatām
]

`v 57 [
suptaṃ māsthīyatāṃ vṛddhakacchapeneva palvale |
utthānamaṅgīkriyatāṃ jarāmaraṇaśāntaye
]

`v 58 [
anarthāyārthasaṃpattirbhogaugho bhavarogadaḥ |
āpadaḥ saṃpadaḥ sarvāḥ sarvatrānādaro jayaḥ
]

`v 59 [
lokatantrānusāreṇa vicārādvyavahāriṇām |
śāstrācārānusāreṇa karmaṇā satphalāya ca
]

`v 60 [
lokatantraṃ janavṛttaṃ tadanusāreṇa tadavirodhinā | śāstrācārau anusarati
tathāvidhena karmaṇā tatphalāya cotthānamaṅgīkriyatāmiti vyavahitānuṣaṅgaḥ |
59 |
ācāracārucaritasya viviktavṛtteḥ
saṃsārasaukhyaphaladuḥkhadaśāstragṛdhnoḥ `note[daśāsvagṛdhroḥ iti
pāṭhaṣṭīkānuguṇaḥ susamīcīnaśceti pratīyate anyathā
mūle'narthāpātaṣṭīkānanuguṇatvaṃ cāpateta] |
āyuryaśāṃsi ca guṇāśca sahaiva lakṣmyā
phullanti mādhavalatā iva satphalāya
]