`v 1 [
catuścatvāriṃśaḥ sargaḥ 44
śrīrāma uvāca |
krameṇānena yenāptā jīvena sthitirātmanaḥ |
sa kathaṃ bhagavandehaṃ samādhatte'sthipañjaram
]

`v 2 [
śrīvasiṣṭha uvāca |
pūrvameva mayā proktaṃ rāma kiṃ nāvabudhyase |
pūrvāparavicārārhā śemuṣī kva gatā tava
]

`v 3 [
yadidaṃ hi śarīrādi jagatsthāvarajaṅgamam |
ābhāsamātramevaitadasatsvapnamivotthitam
]

`v 4 [
dīrghasvapno hyayaṃ rāma mithyaivānagha dṛśyate |
dvicandravibhramākāraṃ bhramāntarbhrāntaśailavat
]

`v 5 [
praśāntājñānanidrastu nūnaṃ galitabhāvanaḥ |
prabuddhacetāḥ saṃsārasvapnaṃ paśyanna paśyati
]

`v 6 [
svabhāvakalpito rāma jīvānāṃ sarvadaiva hi |
āmokṣapadasaṃpāpti saṃsāro'styātmano'ntare
]

`v 7 [
jīvasya taralaḥ kāya āvartaḥ payaso yathā |
yathā bīje'ṅkuraḥ sphāraḥ pallavaḥ svāṅkure yathā
]

`v 8 [
pallave ca yathā puṣpaṃ puṣpakośe phalaṃ yathā |
yataḥ sa kalpanārūpo deho'sti manaso'ntare
]

`v 9 [
bahūrūpatayā rāma yato'styekatamaḥ sphuṭaḥ |
sa eva pratibhāso'sya manasaḥ kila jāyate
]

`v 10 [
sa evāśu bhavatyetanmṛtpiṇḍo ghaṭakopamaḥ |
ādisarge purā kāyaḥ pratibhāso'sya cottamaḥ
]

`v 11 [
yasmādeṣa vibhurbrahmā padmakośagṛhasthitaḥ |
tatsaṃkalpakrameṇaiva tataḥ sthitimupāgatā
]

`v 12 [
ityaṃ sṛṣṭiraparyantā māyeva ghanamāyayā |
śrīrāma uvāca |
jīvo manaḥpadaṃ prāpya vairiñcaṃ padamāgataḥ
]

`v 13 [
yathā brahmaṃstathā sarvaṃ vistareṇa vadāśu me |
śrīvasiṣṭha uvāca |
brahme śṛṇu mahābāho śarīragrahaṇe kramam
]

`v 14 [
nidarśanena tenaiva jāgatīṃ jñāsyasi sthitim |
dikkālādyanavacchinnamātmatattvaṃ svaśaktitaḥ
]

`v 15 [
līlayaiva yadādatte dikkālakalitaṃ vapuḥ |
tadaiva jīvaparyāyaṃ vāsanāveśatatparam
]

`v 16 [
manaḥ saṃpadyate lolaṃ kalanākalanonmukham |
malayantī manaḥśaktirādau bhāvayati kṣaṇāt
]

`v 17 [
ākāśabhāvanāmacchāṃ śabdabījarasonmukhīm |
tatastāṃ ghanatāṃ yātaṃ ghanaspandakramānmanaḥ
]

`v 18 [
bhāvayatyanilaspandaṃ sparśabījarasonmukham |
tābhyāmākāśavātābhyāmadṛṣṭābhyāṃ manodṛśā
]

`v 19 [
śabdasparśasvarūpābhyāṃ saṃghātājjanyate'nalaḥ |
manastadghantāṃ prāpya tato bhāvayati kṣaṇāt
]

`v 20 [
prākāśyamamalālokamālokastena vardhate |
manastāvadguṇagataṃ rasatanmātravedanam
]

`v 21 [
kṣaṇārdhena tvapāṃ śaityaṃ jalasaṃvittato bhavet |
tatastādṛgguṇagataṃ mano bhāvayati kṣaṇāt
]

`v 22 [
svarūpaṃ gandhavatsthūlaṃ yenodeṣyati medinī |
athetthaṃbhūtatanmātraveṣṭitaṃ tanutāṃ jahat
]

`v 23 [
udeṣyatīti pūrvabhūtajanmakālamapekṣya bhaviṣyattvavivakṣaṇālḷṭ |
bhūtatanmātraveṣṭitamidaṃ pañcakaṃ militaṃ sattanutāṃ saukṣmyaṃ jahattyajat |
22 |
vapurvahnikaṇākāraṃ sphuritaṃ vyomni paśyati |
ahaṃkārakalāyuktaṃ buddhibījasamanvitam
]

`v 24 [
tatpuryaṣṭakamityuktaṃ bhūtahṛtpadmaṣaṭpadam |
tasmiṃstu tīvrasaṃvegādbhāvayadbhāsvaraṃ vapuḥ
]

`v 25 [
sthūlatāmeti pākena mano bilvaphalaṃ yathā |
mūṣāsthadrutahemābhaṃ sphuritaṃ vimalāmbare
]

`v 26 [
sanniveśamupādatte tattejaḥ svasvabhāvataḥ |
tasminsvasanniveśe ca tejaḥpuñjamaye punaḥ `note[mana ityapi pāṭhaḥ] |
26 |
tatra manaso viśeṣakalpanābhiniveśaśākhopaśākhāpracaya ityāha -
tasminnityādinā
]

`v 27 [
bhajate bhāvanāṃ sphārāṃ niścitāmātatāmbarām |
ūrdhvaṃ śiraḥpīṭhamayīmadhaḥpādamayīṃ tathā
]

`v 28 [
pārśvayorhastasaṃsthānāṃ madhye codaradharmiṇīm |
prakaṭāvayavo bālo jvālāmālāmalākṛtiḥ
]

`v 29 [
manorathavaśopāttavapustiṣṭhatyasāvatha |
evaṃ svavāsanāveśātkalitāṅgo manomuniḥ
]

`v 30 [
nayatyupacayaṃ dehaṃ svasvabhāvamṛturyathā |
kālena sphuṭatāmeti bhavatyamalavigrahaḥ
]

`v 31 [
buddhisattvabalotsāhavijñānaiśvaryasaṃsthitaḥ |
sa eva bhagavānbrahmā sarvalokapitāmahaḥ
]

`v 32 [
jñānamapratimaṃ yasya vairāgyaṃ ca jagatpateḥ | aiśvaryaṃ caiva dharmaśca
sahasiddhaṃ catuṣṭayam | iti smṛtiprasiddhaviśeṣaṇasiddhiṃ tasya darśayati ##-
dravatkanakasaṃkāśaḥ paramākāśasaṃbhavaḥ |
yathāsau paramākāśe tiṣṭhatyapararūpavān
]

`v 33 [
janayatyātmano mohamātmasthaṃ cittalīlayā |
kadācitkevalaṃ vyoma paramaṃ pāravarjitam
]

`v 34 [
anādimadhyaparyantaṃ kadācidamalaṃ payaḥ |
kadācitkalpakālāgnijvālābhāsvaramaṇḍakam
]

`v 35 [
dainaṃdinapralayakāle tu amalaṃ paya eva kalpayati | kadācitkalpānte dāhakāle | 34
|
kadācitkānanaṃ kārṣṇyaṃ kālaṃ kamalakuḍmalam |
anyānyanyānyanekāni pratijanmāvadhiḥ prabhuḥ
]

`v 36 [
kalpayanpālayatyeṣa nānārūpāṇi helayā |
tatredaṃprathamatvena yadaiṣa brahmaṇaḥ padāt
]

`v 37 [
avatīrṇastadā'jñānāttathaiva sukhamasmṛtam |
garbhanidrāvyapagame vapuḥ paśyati bhāsvaram
]

`v 38 [
prāṇāpānapravāhāḍhyaṃ dravyairiva vinirmitam |
romakoṭibhirākīrṇaṃ dvātriṃśaddaśanānvitam
]

`v 39 [
tristhūṇaṃ pañcadaivatyamadhaścaraṇalāñchitam |
pañcabhāgaṃ navadvāraṃ tvaglepamasṛṇāṅgakam
]

`v 40 [
yuktamaṅgulirviśatyā nakhaviṃśatilāñchitam |
dvibāhuṃ dvistanaṃ dvyakṣaṃ bahvakṣibhujameva ca
]

`v 41 [
nīḍaṃ cittavihaṅgasya nīḍaṃ manmathabhoginaḥ |
tṛṣṇāpiśācyā nilayaṃ jīvakesarikandaram
]

`v 42 [
abhimānagajālānaṃ mānasāmbhojaśobhitam |
athālocya vapurbrahmā kāntamātmīyamuttamam
]

`v 43 [
cintayāmāsa bhagavāṃstrikālāmaladarśanaḥ |
asminnākāśakuhare tate madhupalāñchite
]

`v 44 [
adṛṣṭapāraparyante prathamaṃ kimabhūditi |
iti cintitavānbrahmā sadyo jāto'malātmadṛk
]

`v 45 [
apaśyatsargavṛndāni samatītānyanekaśaḥ |
atha sasmāra sakalānsarvāndharmagaṇānkramāt
]

`v 46 [
vasantaḥ kusumānīva vedānādāya saṃstutān |
līlayā kalpayāmāsa citrasaṃkalpajāḥ prajāḥ
]

`v 47 [
nānācārasamācāraṃ gandharvanagare yathā |
tāsāṃ svargāpavargārthaṃ dharmakāmārthasiddhaye
]

`v 48 [
anantāni vicitrāṇi śāstrāṇi samakalpayat |
dṛṣṭirevamiyaṃ rāma sarge'sminsthitimāgatā |
viriñcirūpānmanasaḥ puṣpalakṣmīrmadhoriva
]

`v 49 [
vividhaviracanaiḥ kriyāvilāsaiḥ
kamalajarūpadhareṇa cetasaiva |
raghusuta parikalpanena nītā
sthitimatulāṃ jagatīha sargalakṣmīḥ
]