`v 1 [
caturdaśaḥ sargaḥ 14
śrīvasiṣṭha uvāca |
śāstrāvabodhāmalayā dhiyā paramapūtayā |
kartavyaḥ kāraṇajñena vicāro'niśamātmanaḥ
]

`v 2 [
vicārāttīkṣṇatāmetya dhīḥ paśyati paraṃ padam |
dīrghasaṃsārarogasya vicāro hi mahauṣadham
]

`v 3 [
āpadvanamanantehāparipallavitākṛti |
vicārakrakacacchinnaṃ naiva bhūyaḥ prarohati
]

`v 4 [
mohena bandhunāśeṣu saṃkaṭeṣu śameṣu `note[bhrameṣu ca iti pāṭhaḥ]
ca |
sarvaṃ vyāptaṃ mahāprājña vicāro hi satāṃ gatiḥ
]

`v 5 [
p. 107)
na vicāraṃ vinā kaścidupāyo'sti vipaścitām |
vicārādaśubhaṃ tyaktvā śubhamāyāti dhīḥ satām
]

`v 6 [
balaṃ buddhiśca tejaśca pratipattiḥ kriyāphalam |
phalantyetāni sarvāṇi vicāreṇaiva dhīmatām
]

`v 7 [
yuktāyuktamahādīpamabhivāñchitasādhakam |
sphāraṃ vicāramāśritya saṃsārajaladhiṃ taret
]

`v 8 [
ālūnahṛdayāmbhojānmahāmohamataṅgajān |
vidārayati śuddhātmā vicāro nāma kesarī
]

`v 9 [
mūḍhāḥ kālavaśeneha yadgatāḥ paramaṃ padam |
tadvicārapradīpasya vijṛmbhitamanuttamam
]

`v 10 [
rājyāni saṃpadaḥ sphārā bhogo mokṣaśca śāśvataḥ |
vicārakalpavṛkṣasya phalānyetāni rāghava
]

`v 11 [
yā vivekavikāsinyo matayo mahatāmiha |
na tā vipadi majjanti tumbakānīva vāriṇi
]

`v 12 [
vicārodayakāriṇyā dhiyā vyavaharanti ye |
phalānāmatyudārāṇāṃ bhājanaṃ hi bhavanti te
]

`v 13 [
vicāravatī dhīrvivekodayakāriṇī tayā ye vyavaharanti | udārāṇāṃ śreṣṭhānām |
12 |
mūrkhahṛtkānanasthānāmāśāprathamarodhinām |
avicārakarañjānāṃ mañjaryo duḥkharītayaḥ
]

`v 14 [
kajjalakṣodamalinā madirāmadadharmiṇī |
avicāramayī nidrā yātu te rāghava kṣayam
]

`v 15 [
mahāpadatidīrgheṣu sadvicāraparo naraḥ |
na nimajjati moheṣu tejorāśistamaḥ sviva
]

`v 16 [
mānase sarasi svacche vicārakamalotkaraḥ |
nūnaṃ vikasito yasya himavāniva bhāti saḥ
]

`v 17 [
vicāravikalā yasya matirmāndyamupeyuṣaḥ |
tasyodetyaśaniścandrānmudhā yakṣaḥ śiśoriva
]

`v 18 [
duḥkhakhaṇḍakamasthūlaṃ vipannavalatāmadhuḥ |
rāma dūre parityājyo nirviveko narādhamaḥ
]

`v 19 [
ye kecana durārambhā durācārā durādhayaḥ |
avicāreṇa te bhānti vetālāstamasā yathā
]

`v 20 [
avicāriṇamekāntavanadrumasadharmakam |
akṣamaṃ sādhukāryeṣu dūre kuru raghūdvaha
]

`v 21 [
viviktaṃ hi mano jantorāśāvaivaśyavarjitam |
parāṃ nirvṛtimabhyeti pūrṇacandra ivātmani
]

`v 22 [
vivekitoditā dehe sarvaṃ śītalayatyalam |
alaṃkaroti cātyantaṃ jyotsneva bhuvanaṃ yathā
]

`v 23 [
paramārthapatākāyā dhiyo dhavalacāmaram |
vicāro rājate janto rajanyāmiva candramāḥ
]

`v 24 [
vicāracāravo jīvā bhāsayanto diśo daśa |
bhānti bhāskaravannūnaṃ bhūyo bhavabhayāpahāḥ
]

`v 25 [
p. 108)
bālasya svamanomohakalpitaḥ prāṇahārakaḥ |
rātrau nabhasi vetālo vicāreṇa vilīyate
]

`v 26 [
sarva eva jagadbhāvā avicāreṇa cāravaḥ |
avidyamānasadbhāvā vicāraviśarāravaḥ
]

`v 27 [
puṃso nijamanomohakalpito'nalpaduḥkhadaḥ |
saṃsāraciravetālo vicāreṇa vilīyate
]

`v 28 [
samaṃ sukhaṃ nirābādhamanantamanapāśrayam |
viddhīmaṃ kevalībhāvaṃ vicāroccataroḥ `note[vicāro'sya taroḥ iti
pāṭhaḥ] phalam
]

`v 29 [
acalasthititodārā prakaṭābhogatejasā |
tena niṣkāmatodeti śītatevendunoditā
]

`v 30 [
svavicāramahauṣadhyā sādhuścittaniṣaṇṇayā |
tayottamatvapradayā nābhivāñchati nojjhati
]

`v 31 [
tatpadālambanaṃ cetaḥ sphāramābhāsamāgatam |
nāstameti na codeti khamivātitatāntaram `note[gatāntaram iti pāṭhaḥ] | 31
|
nanu cittaṃ yadi vicārajanyajñānena naśyettarhi jīvanāsaṃbhavaḥ yadi na
naśyettarhi punarvikṣepāñjanayedeveti kathaṃ kṛtakṛtyatetyāśaṅkyāha ##-
tadvadābhāsatāṃ gataṃ cittamapi
khamākāśamivātitatamativistīrṇabrahmabhāvaṃ prāptamāntaraṃ
vikṣepabījavāsanājālaṃ yasya | nāstaṃ vināśameti yena jīvanaṃ na syāt nāpi
rāgadveṣādivṛttibhirudeti yena vikṣepaḥ syādityarthaḥ | yadvā cetaḥ ābhāsaṃ
bharjitabījamiva nodeti yena vikṣepaḥ syāt | anādivāsanayā sphāratāṃ gataṃ
dṛḍhaṃ viṣaya saṃskāravaśānna vināśameti
]

`v 32 [
na dadāti na cādatte na connamati śāmyati |
kevalaṃ sākṣivatpaśyañjagadābhogi tiṣṭhati
]

`v 33 [
tatkutaḥ | yato jagadviṣayānayaṃ kevalaṃ sākṣivadaudāsīnyena paśyaṃsteṣu
rāgitayā mano na dadāti satyatayā puruṣārthabuddhyā ca nādatte nopabhuṅkte | 32
|
na ca śāmyati nāpyantarnāpi bāhye'vatiṣṭhati |
na ca naiṣkarmyamādatte na ca karmaṇi majjati
]

`v 34 [
upekṣate gataṃ vastu saṃprāptamanuvartate |
na kṣubdho na ca vā'kṣubdho bhāti pūrṇa ivārṇavaḥ
]

`v 35 [
evaṃ pūrṇena manasā mahātmāno mahāśayāḥ |
jīvanmuktā jagatyasminviharantīha yoginaḥ
]

`v 36 [
uṣitvā suciraṃ kālaṃ dhīrāste yāvadīpsitam |
te tamante parityajya yānti kevalatāṃ tatām
]

`v 37 [
ko'haṃ kasya ca saṃsāra ityāpadyapi dhīmatā |
cintanīyaṃ prayatnena sapratīkāramātmanā
]

`v 38 [
kāryasaṃkaṭasaṃdehaṃ rājā jānāti rāghava |
niṣphalaṃ saphalaṃ vāpi vicāreṇaiva nānyathā
]

`v 39 [
vedavedāntasiddhāntasthitayaḥ sthitikāraṇam |
nirṇīyante vicāreṇa dīpena ca bhuvo niśi
]

`v 40 [
anaṣṭamandhakareṣu bahutejaḥ `note[tejassu jihmitaṃ iti ṭīkākārasammataḥ
pāṭhaḥ] svajihmitam |
paśyatyapi vyavahitaṃ vicāraścārulocanam
]

`v 41 [
vivekāndho hi jātyandhaḥ śocyaḥ sarvasya durmatiḥ |
divyacakṣurvivekātmā jayatyakhilavastuṣu
]

`v 42 [
p. 109)
paramātmamayī mānyā mahānandaikasādhinī |
kṣaṇamekaṃ parityājyā na vicāracamatkṛtiḥ
]

`v 43 [
vicāracārupuruṣo mahatāmapi rocate |
paripakvacamatkāraṃ sahakāraphalaṃ yathā
]

`v 44 [
vicārakāntamatayo nānekeṣu punaḥ punaḥ |
luṭhanti duḥkhaśvabhreṣu jñātādhvagatayo narāḥ
]

`v 45 [
naca rauti tathā rogī nānarthaśatajarjaraḥ |
avicāravinaṣṭātmā yathā'jñaḥ pariroditi
]

`v 46 [
varaṃ kardamamekatvaṃ malakīṭakatā varam |
varamandhaguhāhitvaṃ na narasyāvicāritā
]

`v 47 [
sarvānarthanijāvāsaṃ sarvasādhutiraskṛtam |
sarvadausthityasīmāntamavicāraṃ `note[1] parityajet
]

`v 48 [
nityaṃ vicārayuktena bhavitavyaṃ mahātmanā |
tathāndhakūpe patatāṃ vicāro hyavalambanam
]

`v 49 [
svayamevātmanātmānamavaṣṭabhya vicārataḥ |
saṃsāramohajaladhestārayetsvamanomṛgam
]

`v 50 [
ko'haṃ kathamayaṃ doṣaḥ saṃsārākhya upāgataḥ |
nyāyeneti parāmarśo vicāra iti kathyate
]

`v 51 [
andhāndhamohasughanaṃ ciraṃ duḥkhāya kevalam |
kṛtaṃ śilāyā hṛdayaṃ durmateścāvicāriṇaḥ
]

`v 52 [
bhāvābhāvagrahotsargadṛśāmiha hi rāghava |
na vicārādṛte tattvaṃ jñāyate sādhu kiṃcana
]

`v 53 [
vicārājjñāyate tattvaṃ tattvādviśrāntirātmani |
ato manasi śāntatvaṃ sarvaduḥkhaparikṣayaḥ
]

`v 54 [
saphalatāṃ phalate bhuvi karmaṇāṃ
prakaṭatāṃ kila gacchati uttamām |
sphuṭavicāradṛśaiva vicāritā
śamavate bhavate ca virocatām
]