`v 1 [
prathamo divasaḥ |
ṣaṣṭhaḥ sargaḥ 6
śrīvasiṣṭha uvāca |
tasmātprākpauruṣāddaivaṃ nānyattatprojjhasya dūrataḥ |
sādhusaṃgamasacchāstrairjīvamuttārayedbalāt
]

`v 2 [
yathā yathā prayatnaḥ syādbhavedāśu phalaṃ tathā |
iti pauruṣamevāsti daivamastu tadeva ca
]

`v 3 [
duḥkhādyathā duḥkhāke hā kaṣṭamiti kathyate |
hākaṣṭaśabdaparyāyastathā hā daivamityapi
]

`v 4 [
prāksvakarmetarākāraṃ `note[prāksakarma] daivaṃ nāma na vidyate |
bālaḥ prabalapuṃseva tajjetumiha śakyate
]

`v 5 [
hyastano duṣṭa ācāra ācāreṇādya cāruṇā |
yathāśu śubhatāmeti prāktanaṃ karma tattathā
]

`v 6 [
tajjayāya yatante ye na lobhalavalampaṭāḥ |
te dīnāḥ prākṛtā mūḍhāḥ sthitā daivaparāyaṇāḥ
]

`v 7 [
pauruṣeṇa kṛtaṃ karma daivādyadabhinaśyati `note[dyadapi] |
tatra nāśayiturjñeyaṃ pauruṣaṃ balavattaram
]

`v 8 [
yadekavṛntaphalayorathaikaṃ śūnyakoṭaram |
tatra prayatnaḥ sphuritastathā tadrasasaṃvidaḥ
]

`v 9 [
nanvastu puruṣatantreṣvevam apuruṣatantreṣu tu daivameva śaraṇaṃ syāttatrāha ##-
śeṣaḥ | tadrasaṃ saṃvettyupabhuṅkte `note[sevantyupa] yaḥ puruṣaḥ
kīṭādirvā tasya prāktana aihiko vā prayatna eva tadrasavi-ghātāya sphuritaḥ | 8
|
yatprayānti jagadbhāvāḥ saṃsiddhā api saṃkṣayam |
kṣayakārakayatnasya hyatra jñeyaṃ mahadbalam
]

`v 10 [
dvau huḍāviva yudhyete puruṣārthau parasparam |
ya eva balavāṃstatra sa eva jayati kṣaṇāt
]

`v 11 [
bhikṣuko maṅgalebhena nṛpo yatkriyate balāt |
tadamātyebhapaurāṇāṃ prayatnasya balaṃ mahat
]

`v 12 [
pauruṣeṇānnamākramya yathā dantena cūrṇyate |
anyaḥ pauruṣamāśritya tathā śūreṇa cūrṇyate
]

`v 13 [
annabhūtā hi mahatāṃ laghavo yatnaśālinām |
yatheṣṭaṃ viniyojyante tena karmasu loṣṭavat
]

`v 14 [
śaktasya pauruṣaṃ dṛśyamadṛśyaṃ vāpi yadbhavet |
taddaivamityaśaktena buddhamātmanyabuddhinā
]

`v 15 [
bhūtānāṃ balavadbhūtaṃ yanna daivamiti sthitam |
tatteṣāmapyadhiṣṭhātṛ satāmetatsphuṭaṃ mithaḥ
]

`v 16 [
śāstrāmātyebhapaurāṇāmavikalpā svabhāvadhīḥ |
yā sā bhikṣukārājyasya kartṛ dhartṛ prajāsthiteḥ
]

`v 17 [
bhikṣuko maṅgalebhena nṛpo yatkriyate kvacit |
prāktanaṃ pauruṣaṃ tatra balavadvāpi kāraṇam
]

`v 18 [
aihikaḥ prāktanaṃ hanti prāktano'dyatanaṃ balāt |
sarvadā puruṣaspandastatrānudvegavāñjayī
]

`v 19 [
dvayoradyatanasyvia pratyakṣādbalitā bhavet |
daivaṃ jetuṃ `note[jetumataḥ] yato yatnairbālo yūneva śakyate
]

`v 20 [
meghena nīyate yadvadvatsaropārjitā kṛṣiḥ |
meghasya puruṣārtho'sau jayatyadhikayatnavān
]

`v 21 [
krameṇopārjite'pyarthe naṣṭe kāryā na kheditā |
na balaṃ yatra me śaktaṃ tatra kā paridevanā
]

`v 22 [
yanna śaknomi tasyārthe yadi duḥkhaṃ karomyaham |
tadamāritamṛtyorme yuktaṃ pratyaharodanam
]

`v 23 [
deśakālakriyādravyavaśato visphurantyamī |
sarva eva jagadbhāvā jayatyadhikayatnavān
]

`v 24 [
tasmātpauruṣamāśritya sacchāstraiḥ satsamāgamaiḥ |
prajñāmamalatāṃ nītvā saṃsārajaladhiṃ taret
]

`v 25 [
prāktanaścaihikaścemau puruṣārthau phaladdrumau |
saṃjātau puruṣāraṇye jayatyabhyadhikastayoḥ
]

`v 26 [
karma yaḥ prāktanaṃ tucchaṃ na nihanti śubhehitaiḥ |
ajño janturanīśo'sāvātmanaḥ sukhaduḥkhayoḥ
]

`v 27 [
īśvaraprerito gacchetsvargaṃ narakameva vā |
sa sadaiva parādhīnaḥ paśureva na saṃśayaḥ
]

`v 28 [
yastūdāracamatkāraḥ sadācāravihāravān |
sa niryāti jaganmohānmṛgendraḥ pañjarādiva
]

`v 29 [
svapakṣe tu nāyaṃ doṣa ityāha - yastviti | prayatnakauśalamatra camatkāraḥ |
28 |
kaścinmāṃ prerayatyevamityanarthakukalpane |
yaḥ `note[sthito dṛṣṭaṃ] sthito'dṛṣṭamutsṛjya tyājyo'sau
dūrato'dhamaḥ
]

`v 30 [
vyavahārasahasrāṇi yānupāyānti yānti ca |
yathāśāstraṃ vihartavyaṃ teṣu tyaktvā sukhāsukhe
]

`v 31 [
yathāśāstramanucchinnāṃ maryādāṃ svāmanujjhataḥ |
upatiṣṭhanti sarvāṇi ratnānyambunidhāviva
]

`v 32 [
svārthaprāpakakāryaikaprayatnaparatā budhaiḥ |
proktā pauruṣaśabdena sā siddhyai śāstrayantritā
]

`v 33 [
kriyayā spandadharmiṇyā svārthasādhakatā svayam |
sādhusaṃgamasacchāstratīkṣṇayonniyate dhiyā
]

`v 34 [
anantaṃ samatānandaṃ paramārthaṃ vidurbudhāḥ |
sa yebhyaḥ prāpyate nityaṃ te sevyāḥ śāstrasādhavaḥ
]

`v 35 [
devalokādihāgatya lokadvayahitaṃ bhavet |
prāktanaṃ pauruṣaṃ tadvai daivaśabdena kathyate
]

`v 36 [
tadyuktametadetasminnāsti nāpavadāmahe |
mūḍhaiḥ prakalpitaṃ daivaṃ manyante ye kṣayaṃ gatāḥ
]

`v 37 [
nityaṃ svapuruṣādeva lokadvayahitaṃ bhavet |
hyastanī duṣkriyābhyeti śobhāṃ satkriyayā yathā
]

`v 38 [
adyaivaṃ prāktanī tasmādyatnādyaḥ kāryavānbhavet |
karāmalakavaddṛṣṭaṃ pauruṣādeva tatphalam |
mūḍhaḥ pratyakṣamutsṛjya daivamohe nimajjati
]

`v 39 [
evaṃ adya `note[kvacit adya iti na labhyate] adyatanyā prāktanī śobhāmabhyetīti
pūrveṇānvayaḥ | nanvastu prāktanajayaḥ puruṣārthasiddhistu kutastatrāha -
tasmāditi | yaḥ kāryavānbhavettasya tatphalaṃ karāmalakaddṛṣṭamityanvayaḥ |
38 |
sakalakāraṇakāryavivarjitaṃ
nijavikalpabalādupakalpitam |
tadanapekṣya hi daivamasanmayaṃ
śraya śubhāśaya pauruṣamātmanaḥ
]

`v 40 [
śāstraiḥ sadācaravijṛmbhitadeśadharmairya-
tkalpitaṃ phalamatīva ciraprarūḍham |
tasminhṛdi sphurati copanameti citta-
maṅgāvalī tadanu pauruṣametadāhuḥ
]

`v 41 [
buddhvaiva pauruṣaphalaṃ puruṣatvameta-
dātmaprayatnaparataiva sadaiva kāryā |
neyā tataḥ saphalatāṃ paramāmathāsau
sacchāstrasādhujanapaṇḍitasevanena
]

`v 42 [
daivapauruṣavicāracārubhi-
ścedamācaritamātmapauruṣam |
nityamea jayatīti bhāvitaiḥ
kārya āryajanasevayodyamaḥ
]

`v 43 [
janmaprabandhamayamāmayameṣa jīvo
buddhvaihikaṃ sahajapauruṣameva siddhyai |
śāntiṃ nayatvavitathena varauṣadhena
mṛṣṭena tuṣṭaparapaṇḍitasevanena
]