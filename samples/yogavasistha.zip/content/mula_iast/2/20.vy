`v 1 [
viṃśaḥ sargaḥ 20
śrīvasiṣṭha uvāca |
āryasaṃgamayuktyādau prajñāṃ vṛddhiṃ nayedbalāt |
tato mahāpuruṣatāṃ mahāpuruṣalakṣaṇaiḥ
]

`v 2 [
yo yo yena guṇeneha puruṣaḥ pravirājate |
śiṣyate taṃ tamevāśu tasmādbuddhiṃ vivardhayet
]

`v 3 [
mahāpuruṣatā hyeṣā śamādiguṇaśālinī |
samyagjñānaṃ vinā rāma siddhimeti na kāṃcana
]

`v 4 [
p. 123)
jñānācchamādayo yānti vṛddhiṃ satpuruṣakramāḥ |
ślāghanīyāḥ phalenāntarvṛṣṭeriva navāṅkurāḥ
]

`v 5 [
śamādibhyo guṇebhyaśca vardhate jñānamuttamam |
annātmakebhyo yajñebhyaḥ śālivṛṣṭirivottamā
]

`v 6 [
guṇāḥ śamādayo jñānācchamādibhyastathā jñatā |
parasparaṃ vivardhante te abjasarasī iva
]

`v 7 [
jñānaṃ satpuruṣācārājjñānātsatpuruṣakramaḥ |
parasparaṃ gatau vṛddhiṃ jñānasatpuruṣakramau
]

`v 8 [
śamaprajñādinipuṇapuruṣāthakrameṇa ca |
abhyasetpuruṣo dhīmāñjñānasatpuruṣakramau
]

`v 9 [
na yāvatsamamabhyastau jñānasatpuruṣakramau |
eko'pi naitayostāta puruṣasyeha sidhyati
]

`v 10 [
yathā kalamarakṣiṇyā gītyā vitatatālayā |
khagotsādena sahitaṃ gītānandaḥ prasādhyate
]

`v 11 [
jñānasatpuruṣehābhyāmakartrā kartṛrūpiṇā |
tathā puṃsā niricchena samamāsādyate padam
]

`v 12 [
sadācārakramaḥ prokto mayaivaṃ raghunandana |
tathopadiśyate samyagevaṃ jñānakramo'dhunā
]

`v 13 [
idaṃ yaśasyamāyuṣyaṃ puruṣārthaphalapradam |
tajjñādāptācca sacchāstraṃ śrotavyaṃ kila dhīmatā
]

`v 14 [
śrutvā tvaṃ buddhinairmalyādbalādyāsyasi tatpadam |
yathā katakasaṃśleṣātprasādaṃ kaluṣaṃ payaḥ
]

`v 15 [
viditavedyamidaṃ hi mano mune-
rvivaśameva hi yāti paraṃ padam |
yadavabuddhamakhaṇḍitamuttamaṃ
tadavabodhavaśānna jahāti hi
]