`v 1 [
saptamaḥ sargaḥ 7
śrīvasiṣṭha uvāca |
prāpya vyādhivinirmuktaṃ dehamalpādhivedanam |
tathātmani samādadhyādyathā bhūyo na jāyate
]

`v 2 [
daivaṃ puruṣakāreṇa yo nivartitumicchati |
iha vāmutra jagati sa saṃpūrṇābhivāñchitaḥ
]

`v 3 [
ye samudyogamutsṛjya sthitā daivaparāyaṇāḥ |
te dharmarthaṃ kāmaṃ ca nāśayantyātmavidviṣaḥ
]

`v 4 [
saṃvitspando manaḥspanda aindriyaspanda eva ca |
etāni puruṣārthasya rūpāṇyebhyaḥ phalodayaḥ
]

`v 5 [
p. 88)
yathā saṃvedanaṃ cetastathā `note[caitattathā iti pāṭhaḥ]
tatspandamṛcchati |
tathaiva kāyaścalati tathaiva phalabhoktṛtā
]

`v 6 [
uktamartha vivṛṇoti - yatheti | yathā saṃvedanaṃ sākṣiṇi yādṛśī
viṣayasphūrtiḥ pūrva bhavati tato manastādṛśaṃ spandamṛcchati gacchati |
tathaiva karmendriyaspandena kāyaścalati | kriyānusāriṇī ca phalasiddhirityarthaḥ | 5
|
ābālametatsaṃsiddhaṃ yatra yatra yathā yathā |
daivaṃ tu na kvaciddṛṣṭamato jagati pauruṣam
]

`v 7 [
puruṣārthena devānāṃ gurureva bṛhaspatiḥ |
śukro daityendragurutāṃ puruṣārthena cāsthitaḥ
]

`v 8 [
dainyadāridryaduḥkhārtā api sādho narottamāḥ |
pauruṣeṇaiva yatnena yātā devendratulyatām
]

`v 9 [
mahānto vibhavāsvādairnānāścaryasamāśrayāḥ |
pauruṣeṇaiva doṣeṇa narakātithitāṃ gatāḥ
]

`v 10 [
bhāvābhāvasahasreṣu daśāsu vividhāsu ca |
svapauruṣavaśādeva nivṛttā bhūtajātayaḥ
]

`v 11 [
śāstrato gurutaścaiva svataśceti trisiddhayaḥ |
sarvatra puruṣārthasya na daivasya kadācana
]

`v 12 [
aśubheṣu samāviṣṭaṃ śubheṣvevāvatārayet |
prayatnāccittamityeṣa sarvaśāstrārthasaṃgrahaḥ
]

`v 13 [
yacchreyo yadatucchaṃ ca yadapāyavivarjitam |
tattadācara yatnena putreti guravaḥ sthitāḥ
]

`v 14 [
yathā yathā prayatno me phalamāśu tathā tathā |
ityahaṃ pauruṣādeva phalabhāṅ natu daivataḥ
]

`v 15 [
pauruṣāddṛśyate siddhiḥ pauruṣāddhīmatāṃ kramaḥ |
daivamāśvāsanāmātraṃ `note[duḥkhapelava iti pāṭhaḥ] duḥkhe
pelavabuddhiṣu
]

`v 16 [
pratyakṣapramukhairnityaṃ pramāṇaiḥ pauruṣakramaḥ |
phalito dṛśyate loke deśānataragamādikaḥ
]

`v 17 [
bhoktā tṛpyati nābhoktā gantā gacchati nāgatiḥ |
vaktā vakti na cāvaktā pauruṣaṃ saphalaṃ nṛṇām
]

`v 18 [
pauruṣeṇa durantebhyaḥ saṃkaṭebhyaḥ subuddhayaḥ |
samuttarantyayatnena na tu moghatayānayā
]

`v 19 [
yo yo yathā prayatate sa sa tattatphalaikabhāk |
na tu tūṣṇīṃ sthiteneha kenacitprāpyate phalam
]

`v 20 [
śubhena puruṣārthena śubhamāsādyate phalam |
aśubhenāśubhaṃ rāma yathecchasi tathā kuru
]

`v 21 [
puruṣārthātphalaprāptirdeśakālavaśādiha |
prāptā cireṇa śīghraṃ vā yāsau daivamiti smṛtā
]

`v 22 [
na daivaṃ dṛśyate dṛṣṭyā na ca lokāntare sthitam |
uktaṃ daivābhidhānena svarloke karmaṇaḥ phalam
]

`v 23 [
puruṣo jāyate loke vardhate jīryate punaḥ |
na tatra dṛśyate daivaṃ jarāyauvanabālyavat
]

`v 24 [
arthaprāpakakāryaikaprayatnaparatā budhaiḥ |
proktā pauruṣaśabdena sarvamāsādyate'nayā
]

`v 25 [
deśāddeśāntaraprāptirhastasya dravyadhāraṇam |
vyāpāraśca tathāṅgānāṃ pauruṣeṇa na daivataḥ
]

`v 26 [
p. 89)
anarthaprāptikāryaikaprayatnaparatā tu yā |
proktā pronmattaceṣṭeti na kiṃcitprāpyate'nayā
]

`v 27 [
kriyayā spandadharmiṇyā svārthasādhakatā svayam |
sādhusaṃgamasacchāstratīkṣṇayonnīyate dhiyā
]

`v 28 [
anantasamatānandaṃ paramārthaṃ svakaṃ viduḥ |
sa yebhyaḥ prāpyate yatnātsevyāste śāstrasādhavaḥ
]

`v 29 [
sacchāstrādiguṇo matyā sacchāstrādiguṇānmatiḥ |
vivardhete mitho'bhyāsātsarobjāviva kālataḥ
]

`v 30 [
yadvivakṣayoktamapi punaruktaṃ tadāha - sacchāstreti |
ādipadātsādhusaṃgamaparigrahaḥ | tatra sādhusaṃgamābhyāsasya
guṇastatsamaśīlatāprāptiḥ | śāstrābhyāsasya guṇaḥ śāstratātrparyajñānam |
matistattvabodhaḥ | yathā yathāyaṃ guruśuśrūṣāśāstrābhyāsaparo bhavati tathā
tathāsya bodho vivardhate | yathā yathā ca bodhābhivṛddhistathā tathā
guruśāstraviśvāsavṛddhistadguṇavṛddhyā
sukhādivṛddhyottarottarabhūmikāmārohati | kālataścirakālato varṣākālataśca |
29 |
ābālyādalamabhyastaiḥ śāstrasatsaṃgamādibhiḥ |
guṇaiḥ puruṣayatena svārthaḥ saṃpadyate hitaḥ
]

`v 31 [
pauruṣeṇa jitā daityāḥ sthāpitā bhuvanakriyāḥ |
racitāni jagantīha viṣṇunā na ca daivataḥ
]

`v 32 [
jagati puruṣakārakāraṇe'smin
kuru raghunātha ciraṃ tathā prayatnam |
vrajasi tarusarīsṛpābhidhānāṃ
subhaga yathā na daśāmaśaṅka eva
]