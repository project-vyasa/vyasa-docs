`v 1 [
aṣṭamaḥ sargaḥ 8
śrīvasiṣṭha uvāca |
nākṛtirna ca karmāṇi na spando na parākramaḥ |
tanmithyājñānavadrūḍhaṃ daivaṃ nāma kimucyate
]

`v 2 [
svakarmaphalasaṃprāptāvidamitthamitīti yāḥ |
girastā daivanāmnaitāḥ rpasiddhiṃ samupāgatāḥ
]

`v 3 [
tatraiva mūḍhamatibhirdaivamastīti niścayaḥ |
ātto duravabodhena rajjvāmiva bhujaṃgamaḥ
]

`v 4 [
hyastanī duṣkriyābhyeti śobhāṃ satkriyayā yathā |
adyaivaṃ prāktanī tasmādyatnātsatkāryavānbhavet
]

`v 5 [
mūḍhānumānasaṃsiddhaṃ daivaṃ yasyāsti durmateḥ |
daivāddāho'sti naiveti gantavyaṃ tena pāvake
]

`v 6 [
upajīvyapramāṇavirodhaṃ vivakṣuḥ prathamaṃ pratyakṣasvakriyāvirodhamāha ##-
p. 90)
daivameveha cetkartṛ puṃsaḥ kimiva ceṣṭayā |
snānadānāsanoccārāndaivameva kariṣyati
]

`v 7 [
kiṃvā śāstropadeśena mūko'yaṃ puruṣaḥ kila |
saṃcāryate tu daivena kiṃ kasyehopadiśyate
]

`v 8 [
na ca nispandatā loke dṛṣṭeha śavatāṃ vinā |
spandācca phalasaṃprāptistasmāddaivaṃ nirarthakam
]

`v 9 [
na cāmūrtena daivena mūrtasya sahakartṛtā |
puṃsaḥ saṃdṛśyate kācittasmāddaivaṃ nirarthakam
]

`v 10 [
mitho'ṅgāni samāsādya dvayorekaikakartṛtā |
hastādīnāṃ hatatve ha na daivena kvacitkṛtam
]

`v 11 [
manobuddhivadapyetaddaivaṃ nehānubhūyate |
āgopālaṃ kṛtaprajñaistena daivamasatsadā
]

`v 12 [
pṛthakcedbuddhiranyo'rthaḥ saiva cetkānyatā tayoḥ |
kalpanāyāṃ pramāṇaṃ cetpauruṣaṃ kiṃ na kalpyate
]

`v 13 [
kiṃca daivasiddhau kartrādikārakabuddhireva mānaṃ tatpṛthagbhūtabuddhirvā |
dvitīye kriyāyāmanupayukto'nya eva daivmiti nirarthako'rthaḥ kalpitaḥ syāt | ādye
prasiddhakartrādireva daivaśabdenoktaḥ syādityāha - pṛthagiti | nanu
samānapāṇḍityādiphalamīhamānānāmadhīyānānāṃ kecideva tatphalena yujyante
na sarve tatrāvaśyaṃ vaiṣamye nimittaṃ kalpyam kāryavaiṣamyaliṅgasya
kalpanāpramāṇatvāditicettatrāha - kalpanāyāmiti | tatrāpi
dṛṣṭasajātīyapauruṣameva prāktanaṃ kalpyate nāprasiddhaṃ daivamityarthaḥ | 12
|
nāmūrtestena saṅgo'sti nabhaseva vapuṣmataḥ |
mūrtaṃ ca dṛśyate lagnaṃ tasmāddaivaṃ na vidyate
]

`v 14 [
viniyotkratha bhūtānāmastyanyaccejjagattraye |
śerate bhūtavṛndāni daivaṃ sarvaṃ kariṣyati
]

`v 15 [
daivena tvabhiyukto'haṃ tatkaromīdṛśaṃ sthitam |
samāśvāsanavāgeṣā na daivaṃ paramārthataḥ
]

`v 16 [
mūḍhaiḥ prakalpitaṃ daivaṃ tatparāste kṣayaṃ gatāḥ |
prājñāstu pauruṣārthena padamuttamatāṃ gatāḥ
]

`v 17 [
ye śūrā ye ca vikrāntā ye prājñā ye ca paṇḍitāḥ |
taistaiḥ kimiva loke'sminvada daivaṃ pratīkṣyate
]

`v 18 [
kālavidbhirvinirṇītā yasyāticirajīvitā |
sa cejjīvati saṃchinnaśirāstaddaivamuttamam
]

`v 19 [
kālavidbhirvinirṇītaṃ pāṇḍityaṃ yasya rāghava |
anadhyāpita evāsau tajjñaśceddaivamuttamam
]

`v 20 [
viśvāmitreṇa muninā daivamutsṛjya dūrataḥ |
pauruṣeṇaiva saṃprāptaṃ brāhmaṇyaṃ rāma nānyathā
]

`v 21 [
asmābhiraparai rāama puruṣairmunitāṃ gataiḥ |
pauruṣeṇaiva saṃprāptā ciraṃ gaganagāmitā
]

`v 22 [
utsādya devasaṃghātaṃ cakrustribhuvanodare |
pauruṣeṇaiva yatnena sāmrājyaṃ dānaveśvarāḥ
]

`v 23 [
ālūnaśīrṇamābhogi jagadājahnurojasā |
pauruṣeṇaiva yatnena dānavebhyaḥ sureśvarāḥ
]

`v 24 [
rāma pauruṣayuktyā ca salilaṃ dhāryate'nayā |
ciraṃ karaṇḍake cāru na daiva tatra kāraṇaṃ
]

`v 25 [
bharaṇādānasaṃrambhavibhramaśramabhūmiṣu |
śaktatā dṛśyate rāma na daivasyauṣadheriva
]

`v 26 [
p. 91)
sakalakāraṇakāryavivarjitaṃ
nijavikalpavaśādupakalpitam |
tvamanapekṣya hi daivamasanmayaṃ
śraya śubhāśaya pauruṣamuttamam
]