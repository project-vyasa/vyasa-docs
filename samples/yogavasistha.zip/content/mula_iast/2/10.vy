`v 1 [
daśamaḥ sargaḥ 10
śrīvasiṣṭha uvāca
yathāsthitaṃ brahmatattvaṃ sattāniyatirucyate |
sā vineturvinetṛtvaṃ sā vineyavineyatā
]

`v 2 [
ataḥ paruṣamāśritya śreyase nityabāndhavam |
ekāgraṃ kuru taccittaṃ śṛṇu coktamidaṃ mama
]

`v 3 [
avāntaranipātīni svārūḍhāni manoratham |
pauruṣeṇendriyāṇyāśu saṃyamya samatāṃ naya
]

`v 4 [
ihāmutra ca siddhyarthaṃ puruṣārthaphalapradām |
mokṣopāyamayīṃ vakṣye saṃhitāṃ sāranirmitām
]

`v 5 [
apunargrahaṇāyāntastyaktvā saṃsāravāsanām |
saṃpūrṇau śamasaṃtoṣāvādāyodārayā dhiyā
]

`v 6 [
sapūrvāparavākyārthavicāraviṣayāhṛtam |
manaḥ samarasaṃ kṛtvā sānusaṃdhānamātmani
]

`v 7 [
karmakāṇḍaśrutayaḥ pūrvavākyāni | upāsanāparaśrutaya uttaravākyāni |
arthavicāro jñānasādhakatvam | pūrvāparavākyārthavicārasahitaṃ ca
tadviṣayairahataṃ ceti vigrahaḥ | ātmani sānusaṃdhānaṃ samarasaṃ
guruśāstropadiṣṭaprakārasya svānubhavasya caikarasyāpādanasahitamiti yāvat | 6
|
sukhaduḥkhakṣayakaraṃ mahānandaikakāraṇam |
mokṣopāyamimaṃ rāma vakṣyamāṇaṃ mayā śṛṇu
]

`v 8 [
imāṃ mokṣakathāṃ śrutvā saha sarvairvivekibhiḥ |
paraṃ yāsyasi nirduḥkhaṃ nāśo yatra na vidyate
]

`v 9 [
idamuktaṃ purākalpe brahmaṇā parameṣṭhinā |
sarvaduḥkhakṣayakaraṃ paramāśvāsanaṃ dhiyaḥ
]

`v 10 [
śrīrāma uvāca |
kenoktaṃ kāraṇenedaṃ brahmanpūrvaṃ svayaṃbhuvā |
kathaṃ ca bhavatā prāptametatkathaya me prabho
]

`v 11 [
śrīvasiṣṭha uvāca |
astyanantavilāsātmā sarvagaḥ sarvasaṃśrayaḥ |
cidākāśo'vināśātmā pradīpaḥ sarvajantuṣu
]

`v 12 [
spandāspandasamākārātttato viṣṇurajāyata |
syandamānarasāpūrāttaraṅgaḥ sāgarādiva
]

`v 13 [
p. 95)
sumerukarṇikāttasya digdalāddhṛdayāmbujāt |
tārakākesaravataḥ parameṣṭhī vyajāyata
]

`v 14 [
vedavedārthaviddevamunimaṇḍalamaṇḍitaḥ |
so'sṛjatsakalaṃ sarvaṃ vikalpaughaṃ yathā manaḥ
]

`v 15 [
jambūdvipasya koṇe'sminvarṣe bhāratanāmani |
sasarja janasargaughaṃ hyādhivyādhipariplutam
]

`v 16 [
bhāvābhāvaviṣaṇṇāṅgamutpātadhvaṃsatatparam |
sarge'sminbhūtajātīnāṃ `note[sarvabhūtānāṃ iti pāṭhaḥ]
nānāvyasanasaṃkulam
]

`v 17 [
janasyaitasya duḥkhaṃ taddṛṣṭvā sakalalokakṛt |
jagāma karuṇāmīśaḥ putraduḥkhātpitā yathā
]

`v 18 [
ka eteṣāṃ hatāśānāṃ duḥkhasyānto hatāyuṣām |
syāditi kṣaṇamekāgraṃ cintayāmāsa bhūtaye
]

`v 19 [
iti saṃcintya bhagavānsasarja svayamīśvaraḥ |
tapo dharmaṃ ca dānaṃ ca satyaṃ tīrthānic caiva hi
]

`v 20 [
etatsṛṭvā punardevaścintayāmāsa bhūtakṛt |
puṃsāṃ nānena sarvasya duḥkhasyānta iti svayam
]

`v 21 [
nirvāṇaṃ nāma paramaṃ sukhaṃ yena punarjanaḥ |
na jāyate na mriyate tajjñānādeva labhyate
]

`v 22 [
saṃsārottaraṇe jantorupāyo jñānameva hi |
tapo dānaṃ tathā tīrthamanupāyāḥ prakīrtitāḥ
]

`v 23 [
tattāvadduḥkhamokṣārthe janasyāsya hatātmanaḥ `note[mahātmanaḥ iti
pāṭhaḥ] |
pratyagraṃ taraṇopāyamāśu prakaṭayāmyaham
]

`v 24 [
iti saṃcintya bhagavānbrahmā kamalasaṃsthitaḥ |
manasā parisaṃkalpya māmutpāditavānimam
]

`v 25 [
kuto'pyutpanna evāśu tato'haṃ samupasthitaḥ |
pitustasya punaḥ śīghramūrmirūrmerivānagha `note[mūrtirūrmeḥ iti
pāṭhaḥ]
]

`v 26 [
kamaṇḍaludharo nāthaḥ sakamaṇḍalunā mayā |
sākṣamālaḥ sākṣamālaṃ sa praṇmyābhivāditaḥ
]

`v 27 [
ehi putreti māmuktvā sa svābjasyottare dale |
śuklābhra iva śītāṃśuṃ yojayāmāsa pāṇinā
]

`v 28 [
mṛgakṛttiparīdhāno mṛgakṛttinijāmbaram |
māmuvāca pitā brahmā suhaṃsaḥ sārasaṃ yathā
]

`v 29 [
muhūrtamātraṃ te putra ceto vānaracañcalam |
ajñānamabhyāviśatu śaśaḥ śaśadharaṃ yathā
]

`v 30 [
iti tenāśu śaptaḥ sanvicārasamanantaram |
ahaṃ vismṛtavānsarvaṃ svarūpamamalaṃ kila
]

`v 31 [
athāhaṃ dīnatāṃ yātaḥ sthito'saṃbuddhayā dhiyā |
duḥkhaśokābhisaṃtapto jāto jana ivādhanaḥ
]

`v 32 [
kaṣṭaṃ saṃsāranāmāyaṃ doṣaḥ kathamihāgataḥ |
iti cintitavānantastūṣṇīmeva vyavasthitaḥ
]

`v 33 [
athābhyadhātsa māṃ tātaḥ putra kiṃ duḥkhavānasi |
duḥkhopaghātaṃ māṃ pṛccha sukhī nityaṃ bhaviṣyasi
]

`v 34 [
tataḥ pṛṣṭaḥ sa bhagavānmayā sakalalokakṛt |
hemapadmadalasthena saṃsāravyādhibheṣajam
]

`v 35 [
kathaṃ nātha mahāduḥkhamayaḥ saṃsāra āgataḥ |
kathaṃ ca kṣīyate jantoriti pṛṣṭena tena me
]

`v 36 [
tajjñānaṃ subahu proktaṃ yajjñātvā pāvanaṃ param |
ahaṃ piturabhiprāyaḥ kilādhika iva sthitaḥ
]

`v 37 [
tato viditavedyaṃ māṃ nijāṃ prakṛtimāsthitam |
sa uvāca jagatkartā vaktā sakalakāraṇaṃ
]

`v 38 [
śāpenājñapadaṃ nītvā pṛcchakastvaṃ mayā kṛtaḥ |
putrāsya jñānasārasya samastajanasiddhaye
]

`v 39 [
p. 96)
idānīṃ śāntaśāpastvaṃ paraṃ bodhamupāgataḥ |
saṃsthito'hamivaikātmā'kanakaṃ kanakādivat
]

`v 40 [
gacchedānīṃ mahīpṛṣṭhe jambūdvipāntarasthitam |
sādho bharatavarṣaṃ tvaṃ lokānugrahahetunā
]

`v 41 [
tatra kriyākāṇḍaparāstvayā putra mahādhiyā |
upadeśyāḥ kriyākāṇḍakrameṇa kramaśālinā
]

`v 42 [
tatreti | na buddhibhedaṃ janayedajñānāṃ karmasaṅginām iti nyāyāditi bhāvaḥ |
41 |
viraktacittāśca tathā mahāprājñā vicāriṇaḥ |
upadeśyāstvayā sādho jñānenānandadāyinā
]

`v 43 [
iti tena niyukto'haṃ pitrā kamalayoninā |
iha rāghava tiṣṭhāmi yāvadbhūtaparamparā
]

`v 44 [
kartavyamasti na mameha hi kiṃcideva
sthātavyamityatimanā bhuvi saṃsthito'smi |
saṃśāntayā satatasuptadhiyeha vṛttyā
kāryaṃ karomi na ca kiṃcidahaṃ karomi
]