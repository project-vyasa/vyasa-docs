`v 1 [
caturthaḥ sargaḥ 4
śrīvasiṣṭha uvāca |
saumyāmbutve taraṅgatve salilasyāmbutā yathā |
samaivābdhau tathāḍehasadehamunimuktatā
]

`v 2 [
muktānubhavato muktyoraviśeṣo'tra kīrtyate |
mūladārḍhyāya śāstrīyaṃ pauruṣaṃ ca praśasyate |
ātmano nityamuktasvabhāvasyājñānāvaraṇameva bandhaḥ | jñānena tannāśa
eva muktiḥ | naṣṭe tvajñāne parijñātaścitravyāghra iva dṛśyamāno'pi
vyavahāraḥ kautukāyaiva nānarthāyeti na jīvanmuktavidehamuktayorviśeṣa iti
pūrvaśaṅkāṃ samādhāya prastutamātmatattvaṃ vistareṇopadeṣṭukāmaḥ
prathamaṃ mūladārḍhyāya puruṣaprayatnaṃ samarthayati - saumyetyādinā | he
saumya priyadarśana ambutve niścalāmbutve | samaiva na viṣamā | tathaiva adeha##-
sadehā vāstvadehā vā muktatā viṣaye na ca |
anāsvāditabhogasya kuto bhojyānubhūtayaḥ
]

`v 3 [
viṣaye na ca viṣayādhīnā tu na | yadi muktiḥ svargādiriva viṣayādhīnā syāttarhi
tathaiva viṣayavaiṣamyādviṣamāsyāditi bhāvaḥ | nanu tathāpi
bhoktṛtvābhoktṛ-tvakṛto viśeṣo'styeva bhogārthatvāddehasthitestatrāha
- anāsvāditeti | bhogeṣu satyabuddhyā bhoktṛtvābhimānena | bhogāsvādane
hi bhogakṛto viśeṣaḥ syānna tvasaṅgodāsīnātmaikatvadarśinaḥ sa iti bhāvaḥ |
2 |
jīvanmuktaṃ muniśreṣṭhaṃ kevalaṃ hi padārthavat |
paśyāmaḥ purato nāsya punarvighno'ntarāśayam
]

`v 4 [
sadehādehamuktānāṃ bhedaḥ ko bodharūpiṇām |
yadevāmbutaraṅgatve saumyatve'pi tadeva tat
]

`v 5 [
na manāgapi bhedo'sti sadehādehamuktayoḥ |
saspando'pyathavā'spando vāyureva yathānilaḥ
]

`v 6 [
sadehā vā videhā vā muktatā na pramāspadam |
asmākamapi tasyāsti svaikatāstyavibhāginī
]

`v 7 [
tasmātprakṛtamevedaṃ śṛṇu śravaṇabhūṣaṇam |
mayopadiśyamānaṃ tvaṃ jñānamajñāndhyanāśanam
]

`v 8 [
sarvameveha hi sadā saṃsāre raghunandana |
samyakprayuktātsarveṇa pauruṣātsamavāpyate
]

`v 9 [
iha hīndorivodeti śītalāhlādanaṃ hṛdi |
parispandaphalaprāptau pauruṣādeva nānyataḥ
]

`v 10 [
pauruṣaṃ spandaphalavaddṛṣṭaṃ pratyakṣato nayat |
kalpitaṃ mohitairmandairdaivaṃ kiṃcinna vidyate
]

`v 11 [
sādhūpadiṣṭamārgeṇa yanmanoṅgaviceṣṭitam |
tatpauruṣaṃ `note[tatsāphalyam] tatsaphalamanyadunmattaceṣṭitam
]

`v 12 [
yo yamarthaṃ prārthayate tadarthaṃ cehate kramāt |
avaśyaṃ sa tamāpnoti na cedardhānnivartate
]

`v 13 [
pauruṣeṇa prayatnena trailokyaiśvaryasundarām |
kaścitprāṇiviśeṣo hi `note[vṛṣatāṃ, vṛṣā=indraḥ] śakratāṃ
samupāgataḥ
]

`v 14 [
tameva niyamaṃ bahuśaḥ saṃvādena draḍhayati - pauruṣeṇetyādicaturbhiḥ |
13 |
pauruṣeṇaiva yatnena sahasāmbhoruhāspadam |
kaścideva cidullāso brahmatāmadhitiṣṭhati
]

`v 15 [
sāreṇa puruṣārthena svenaiva garuḍadhvajaḥ |
kaścideva pumāneva puruṣottamatāṃ gataḥ
]

`v 16 [
pauruṣeṇaiva yatnena lalanāvalitākṛtiḥ `note[valitākṛtim] |
śarīrī kaścideveha gataścandrārdhacūḍatām
]

`v 17 [
prāktanaṃ caihikaṃ ceti dvividhaṃ viddhi pauruṣam |
prāktano'dyatanenāśu puruṣārthena jīyate
]

`v 18 [
yatnavadbhirdṛḍhābhyāsaiḥ `note[prajotsāha] prajñotsāhasamanvitaiḥ
|
meravo'pi nigīryante kaiva prākpauruṣe kathā
]

`v 19 [
śāstraniyantritapauruṣaparamā puruṣasya puruṣatā yā syāt |
abhimataphalabharasiddhyai bhavati hi saivānyathā tvanarthāya
]

`v 20 [
kasyāṃcitsvayamātmaduḥsthitivaśātpuṃso daśāyāṃ
śanairaṅgulyagranipīḍitaikaculukādāvāpabindurbahuḥ |
kasyāṃcijjalarāśiparvatapuradvīpāntarālīkṛtā
bhartavyocitasaṃvibhāgakaraṇe pṛthvī na pṛthvī bhavet
]