`v 1 [
dvitīyaḥ sargaḥ 2
viśvāmitra uvāca |
tasya vyāsatanūjasya malamātropamārjanam |
yathopayuktaṃ te rāma tāvadevopayujyate
]

`v 2 [
jñeyametena vijñātamaśeṣeṇa munīśvarāḥ |
svadante'smai na yadbhogā rogā iva sumedhase
]

`v 3 [
jñātajñeyasya manaso nūnametaddhi lakṣaṇam |
na svadante samagrāṇi bhogavṛndāni yatpunaḥ
]

`v 4 [
bhogabhāvanayā yāti bandho dārḍhyamavastujaḥ |
tayopaśāntayā yāti bandho jagati tānavam
]

`v 5 [
vāsanātānavaṃ rāma mokṣa ityucyate budhaiḥ |
padārthavāsanādārḍhyaṃ bandha ityabhidhīyate
]

`v 6 [
svātmatattvābhigamanaṃ bhavati prāyaśo nṛṇām |
mune viṣayavairasyaṃ kadarthādupajāyate
]

`v 7 [
samyakpaśyati yastajjño jñātajñeyaḥ sa paṇḍitaḥ |
na svadante balādeva tasmai bhogā mahātmane
]

`v 8 [
yaśaḥprabhṛtinā yasmai hetunaiva vinā punaḥ |
bhuvi bhogā na rocante sa jīvanmukta ucyate
]

`v 9 [
jñeyaṃ yāvanna vijñātaṃ tāvattāvanna jāyate |
viṣayeṣvaratirjantormarubhūmau latā yathā
]

`v 10 [
ataeva hi vijñātajñeyaṃ `note[vijñātaṃ jñeyaṃ] viddhi raghūdvaham |
`note[yenedaṃ] yadenaṃ rañjayantyetā na ramyā bhogabhūmayaḥ
]

`v 11 [
rāmo yadantarjānāti tadvastvityeva sanmukhāt |
ākarṇya cittaviśrāntimāpnotyeva munīśvarāḥ
]

`v 12 [
yadi rāmastattvajñastarhi kimarthamupadeśārthaṃ vakṣyamāṇā
vasiṣṭhaprārthanā tatrāha - rāma iti | sato vasiṣṭhasya mukāt | āpnotyeva
anyo'pyadhikārīti śeṣaḥ | tathā ca sarvopakārāyopadeśaprārthanetyarthaḥ | athavā
rāmo yadantastattvaṃ jānāti tadrāma eva viśvāsadārḍhyābhāvāda##-
kevalaṃ kevalībhāvaviśrāntiṃ samapekṣate |
rāmabuddhiḥ śarallakṣmīḥ khalu viśramaṇaṃ yathā
]

`v 13 [
atrāsya cittaviśrāntyai rāghavasya mahātmanaḥ |
yuktiṃ kathayatu śrīmānvasiṣṭho bhagavānayam
]

`v 14 [
raghūṇāmeṣa sarveṣāṃ prabhuḥ kulaguruḥ sadā |
sarvajñaḥ sarvasākṣī ca trikālāmaladarśanaḥ
]

`v 15 [
vasiṣṭha bhagavanpūrvaṃ kaccitsmarasi yatsvayam |
āvayorvairaśāntyarthaṃ śreyase ca mahādhiyām
]

`v 16 [
niṣadhādrermunīnāṃ ca sānau saralasaṃkule |
upadiṣṭaṃ bhagavatā jñānaṃ padmabhuvā bahu
]

`v 17 [
yena yuktimatā brahmanjñāneneyaṃ hi vāsanā |
sāṃsārī nūnamāyāti śamaṃ śyāmeva bhāsvatā
]

`v 18 [
tadeva yuktimajjñeyaṃ rāmāyāntenivāsine |
brahmannupadiśāśu tvaṃ yena viśrāntimeṣyati
]

`v 19 [
kadarthanā ca naivaiṣā rāmo hi gatakalpaṣaḥ |
nirmale mukure vakramayatnenaiva bimbati
]

`v 20 [
tajjñānaṃ sa ca śāstrārthastvadvaidagdhyamaninditam |
sacchiṣyāya viraktāya `note[yatkiṃcidupadiśyate] sādho yadupadiśyate |
20 |
neyaṃ kadarthanā pratyutābhijñatādayādisārthakyāpādanādabhyudaya evetyāha
- taditi | vidagdhaḥ paṇḍitastadbhāvo vaidagdhyam | aninditaṃ praśastam |
pātreṣvapratipattau vaiyarthyānninditameva syāditi bhāvaḥ
]

`v 21 [
aśiṣyāyāviraktāya yatkiṃcidupadiśyate |
tatprayātyapavitratvaṃ gokṣīraṃ śvadṛtāviva
]

`v 22 [
vītarāgabhayakrodhā nirmānā galitainasaḥ |
vadanti tvādṛśā yatra tatra viśrāmyatīha dhīḥ
]

`v 23 [
ityukte gādhiputreṇa vyāsanāradapūrvakāḥ |
munayaste tamevārthaṃ sādhusādhvityapūjayan
]

`v 24 [
athovāca mahātejā rājñaḥ pārśve vyavasthitaḥ |
brahmeva brahmaṇaḥ putro vasiṣṭho bhagavānmuniḥ
]

`v 25 [
śrīvasiṣṭha uvāca |
mune yadādiśasi me tadavighnaṃ karomyaham |
kaḥ samarthaḥ samartho'pi satāṃ laṅghayituṃ vacaḥ
]

`v 26 [
ahaṃ hi rājaputrāṇāṃ rāmādīnāṃ manastamaḥ |
jñānenāpanayāmyāśu dīpeneva niśātamaḥ
]

`v 27 [
smarāmyakhaṇḍitaṃ sarvaṃ saṃsārabhramaśāntaye |
niṣadhādrau purā proktaṃ yajjñānaṃ padmajanmanā
]

`v 28 [
vālmīkiruvāca |
iti nigaditavānasau mahātmā parikarabandhagṛhītavaktṛtejāḥ |
akathayadidamajñatopaśāntyai paramapadaikavibodhanaṃ vasiṣṭhaḥ
]