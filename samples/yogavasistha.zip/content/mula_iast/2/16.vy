`v 1 [
p. 111)
ṣoḍaśaḥ sargaḥ 16
viśeṣaṇa mahābuddhe saṃsārottaraṇe nṛṇām |
sarvatropakarotīha sādhuḥ sādhusamāgamaḥ
]

`v 2 [
sādhusaṅgatarorjātaṃ vivekakusumaṃ sitam |
rakṣanti ye mahātmāno bhājanaṃ te phalaśriyaḥ
]

`v 3 [
śūnyamākīrṇatāmeti mṛtirapyutsavāyate |
āpatsaṃpadivābhāti vidvajjanasamāgame
]

`v 4 [
himamāpatsarojinyā mohanīhāramārutaḥ |
jayatyeko jagatyasminsādhuḥ sādhusamāgamaḥ
]

`v 5 [
paraṃ vivardhanaṃ buddherajñānataruśātanam
`note[ajñānajvaranāśanam iti pāṭhaḥ] |
samutsāraṇamādhīnāṃ viddhi sādhusamāgamam
]

`v 6 [
vivekaḥ paramo dīpo jāyate sādhusaṃgamāt |
manohārojjvalo nūnamāsekādiva gucchakaḥ
]

`v 7 [
nirapāyāṃ nirābādhāṃ nirvṛtiṃ nityapīvarīm |
anuttamāṃ prayacchanti sādhusaṅgavibhūtayaḥ
]

`v 8 [
api kaṣṭatarāṃ prāptairdaśāṃ vivaśatāṃ gataiḥ |
manāgapi na saṃtyājyā mānavaiḥ sādhusaṃgatiḥ
]

`v 9 [
sādhusaṃgatayo loke sanmārgasya ca dīpikāḥ |
hārdāndhakārahāriṇyo bhāso jñānavivasvataḥ
]

`v 10 [
yaḥ snātaḥ śītasitayā sādhusaṃgatigaṅgayā |
kiṃ tasya dānaiḥ kiṃ tīrthaiḥ kiṃ tapibhiḥ kimadhvaraiḥ
]

`v 11 [
nīrāgāśchinnasaṃdehā galitagranthayo'nagha |
sādhavo yadi vidyante kiṃ tapastīrthasaṃgrahaiḥ
]

`v 12 [
viśrāntamanaso dhanyāḥ prayatnena pareṇa hi |
daridreṇeva maṇayaḥ prekṣaṇīyā hi sādhavaḥ
]

`v 13 [
satsamāgamasaundaryaśālinī dhīmatāṃ matiḥ |
kamalevāpsarovṛnde sarvadaiva virājate
]

`v 14 [
tenāmalavicārasya padasyāgrāvacūlitā |
prathitā yena dhanyena na tyaktā sādhusaṃgatiḥ
]

`v 15 [
vicchinnagranthayastajjñāḥ sādhavaḥ sarvasaṃmatāḥ |
sarvopāyena saṃsevyāste hypāyā bhavāmbudhau
]

`v 16 [
ta ete narakāgnīnāṃ saṃśuṣkendhanatāṃ gatāḥ |
yairdṛṣṭā helayā santo narakānalavāridāḥ
]

`v 17 [
dāridryaṃ maraṇaṃ duḥkhamityādiviṣayo bhramaḥ |
saṃpraśāmyatyaśeṣeṇa sādhusaṃgamabheṣajaiḥ
]

`v 18 [
saṃtoṣaḥ sādhusaṅgaśca vicāro'tha śamastathā |
eta eva bhavāmbhodhāvupāyāstaraṇe nṛṇām
]

`v 19 [
saṃtoṣaḥ paramo lābhaḥ satsaṅgaḥ paramā gatiḥ |
vicāraḥ paramaṃ jñānaṃ śamo hi paramaṃ sukham
]

`v 20 [
catvāra ete vimalā upāyā bhavabhedane |
yairabhyastāsta uttīrṇā mohavāribhavārṇavāt
]

`v 24 [
ekasminneva vai teṣāmabhyaste vimalodaye |
sarvābhyāsāsāmarthye
folio 112 - 113 is unclear
p. 114)
dadhātyevaṃ jagacchabdarūpārthamasadātmakam |
taraṅgotpalamālābhaṃ dṛṣṭanṛtyamivotthitam
]

`v 25 [
cakracītkārapūrṇasya jalarāśimivodyatam |
śīrṇapatraṃ bhraṣṭanaṣṭaṃ grīṣme vanamivārasam
]

`v 26 [
maraṇavyagracittābhaṃ śilāgṛhaguhāspadam |
andhakāraguhaikaikanṛttamunmattaceṣṭitam
]

`v 27 [
praśāntājñānanīhāraṃ vijñānaśaradambaram |
samutkīrṇamiva stambhe citaṃ `note[cittabhittāviva iti pāṭhaḥ]
bhittāvivoditam
]

`v 28 [
paṅkādivābhiracitaṃ sacetanamacetanam |
tataḥ sthitiprakaraṇaṃ caturthaṃ parikalpitam
]

`v 29 [
trīṇi granthasahasrāṇi vyākhyānākhyāyikāmayam |
itthaṃ jagadahaṃbhāvarūpasthitimupāgatam
]

`v 30 [
draṣṭṭadṛśyakramaṃ prauḍhamityatra parikīrtitam |
daśadiṅmaṇḍalābhogabhāsuro'yaṃ jagadbhramaḥ
]

`v 31 [
itthamabhyāgato vṛddhimiti tatrocyate ciram |
upaśāntiprakaraṇaṃ tataḥ pañcasahasrakam
]

`v 32 [
pañcamaṃ pāvanaṃ proktaṃ yuktisaṃtatisundaram `note[munisaṃtati iti
pāṭhaḥ] |
idaṃ jagadahaṃ tvaṃ ca sa iti bhrāntirutthitā
]

`v 33 [
itthaṃ saṃśāmyatītyasminkathyate ślokasaṃgrahaiḥ |
upaśāntiprakaraṇe śrute śāmyati saṃsṛtiḥ
]

`v 34 [
prabhraṣṭacitraseneva kiṃcillabhyopalambhanā |
śatāṃśaśiṣṭā bhavati saṃśāntabhrāntarūpiṇī `note[bhrāntirūpiṇī iti
pāṭhaḥ]
]

`v 35 [
anyasaṃkalpacittasthā nagaraśrīrivāsatī |
alabhyavastupārśvasthasvapnayuddhacirāravā
]

`v 36 [
śāntasaṃkalpamattābhrabhīṣaṇāśaniśabdavat |
vismṛtasvapnasaṃkalpanirmāṇanagaropamā
]

`v 37 [
bhaviṣyannagarodyānaprasūvandhyāmalāṅgikā
`note[nagarodyānasotsavaśyāmalātmikāḥ iti pāṭhaḥ] |
tasyā `note[naśyajjihvocyamāna iti pāṭhaḥ]
jihvocyamānograkathārthānubhavopamā
]

`v 38 [
anullikhitacitrasya citravyāpteva bhittibhūḥ |
parivismaryamāṇārthakalpanānagarīnibhā
]

`v 39 [
sarvartumadanutpannavanaspandāsphuṭākṛtiḥ |
bhāvipuṣpavanākāravasantarasarañjanā
]

`v 40 [
antarlīnataraṅgaughasaumyavārisaritsamā |
nirvāṇākhyaṃ prakaraṇaṃ tataḥ ṣaṣṭhamudāhṛtam
]

`v 41 [
śiṣṭo granthaḥ parīmāṇaṃ tasya jñānamahārthadaḥ |
buddhe tasminbhavecchreyo nirvāṇaṃ śāntakalpanam
]

`v 42 [
p. 115)
acetyacitprakāśātmā vijñānātmā nirāmayaḥ |
paramākāśakośācchaḥ śāntasarvabhavabhramaḥ
]

`v 43 [
nirvāpitajagadyātraḥ kṛtakartavyasusthitaḥ |
samastajanatārambhavajrastambho nabhonibhaḥ
]

`v 44 [
vinigīrṇayathāsaṃkhyajagajjālātitṛptimān |
ākāśībhūtaniḥśeṣarūpālokamanaskṛtiḥ
]

`v 45 [
kāryakāraṇakartṛtvaheyādeyadṛśojjhitaḥ |
sadeha ivanirdehaḥ sasaṃsāro'pyasaṃsṛtiḥ
]

`v 46 [
cinmayo ghanapāṣāṇajaṭharāpīvaropamaḥ |
cidādityastaṁllokānandhakāroparopamam
]

`v 47 [
paraprakāśarūpo'pi paramāndhyamivāgataḥ |
ruddhasaṃsṛtidurlīlaḥ prakṣīṇāśāviṣūcikaḥ
]

`v 48 [
naṣṭāhaṃkāravetālo dehavānakalevaraḥ |
kasmiṃścidromakoṭyagre tasyeyamavatiṣṭhate |
jagallakṣmīrmahāmeroḥ puṣpe kvacidivālinī
]

`v 49 [
paramāṇau paramāṇau cidākāśaḥ svakoṭare |
jagallakṣmīsahasrāṇi dhatte kṛtvātha paśyati
]

`v 50 [
vitatatā hṛdayasya mahāmate-
rhariharāñjajalakṣaśatairapi |
tulanameti na muktimato yataḥ
pravitatāsti niruttamavastunaḥ
]