`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīvasiṣṭha uvāca |
asyāṃ vā cittamātrāyāṃ prabodhaḥ saṃpravartate |
bījādiva sato vyuptādavaśyaṃbhāvi satphalam
]

`v 2 [
api pauruṣamādeyaṃ śāstraṃ cedyuktibodhakam |
anyattvārṣamapi tyājyaṃ bhāvyaṃ nyāyyaikasevinā
]

`v 49 [
nanu satīṣvanekaśākhābhedabhinnāsu śrutiṣu tā vihāya
puruṣabuddhiviracitamidamevopādeyatayā kimarthamucyate tatrāha - apīti |
yuktibhirbodhakaṃ tattvanirṇāyakam | ṛṣirvedastatra bhavamārṣam |
nyāyādanapetaṃ nyāyyaṃ tadeva mukhyamityanusaratā bhāvyam puruṣeṇetyarthaḥ
| yadyapi śrutayo'bhyarhitāstathāpi gūḍhābhisaṃdhitvātsahasā nānubhavāyālamiti
na sādhāraṇādhikāribhirupādeyāḥ | tatsārābhijñānubhavamūlakayuktighaṭitaṃ
tvidaṃ śāstraṃ sphuṭābhisandhitvā
folio 116 - 117 in unclear
p. 118)
yathedaṃ śrūyate cāstraṃ tāmāpātanikāṃ śṛṇu |
vicāryate yathārtho'yaṃ yathā ca paribhāṣayā
]

`v 50 [
yenehānanubhūte'rthe dṛṣṭenārthena bodhanam |
bodhopakāraphaladaṃ taṃ dṛṣṭāntaṃ vidurbudhāḥ
]

`v 51 [
dṛṣṭāntena vinā rāma nāpūrvārtho'vabudhyate |
yathā dīpaṃ vinā rātrau bhāṇḍopaskaraṇaṃ gṛhe
]

`v 52 [
yairyaiḥ kākutstha dṛṣṭāntaistvaṃ mayehāvabodhyase |
sarve sakāraṇāste hi prāpyantu sadakāraṇam
]

`v 53 [
upamānopameyānāṃ kāryakāraṇatoditā |
varjayitvā paraṃ brahma sarveṣāmeva vidyate
]

`v 54 [
brahmopadeśe dṛṣṭānto yastaveha hi kathyate |
ekadeśasadharmatvaṃ tatrāntaḥ parigṛhyate
]

`v 55 [
yo yo nāmeha dṛṣṭānto brahmatattvāvabodhane |
dīyate sa sa boddhavyaḥ svapnajāto `note[svapnadṛṣṭajagataḥ]
jagadgataḥ
]

`v 56 [
evaṃ sati nirākāre brahmaṇyākāravānkatham |
dṛṣṭānta iti nodyanti mūrkhavaikalpikoktayaḥ
]

`v 57 [
anyāsiddhaviruddhādidṛgdṛṣṭāntapradūṣaṇaiḥ |
svapnopamatvājjagataḥ samudeti na kiṃcana
]

`v 58 [
etena dṛṣṭāntopanyāsasyānumānonnayanena bodhakatve
dṛṣṭāntahetuvyāptyāderanṛtatve vyāpyatvāsiddhiḥ svarūpāsiddhirityādayaḥ
prāpañcikairhetubhiḥ satyatvādisādhane viruddhatvādayaśca
hetvābhāsatāprayojakadoṣāḥ syuriti tārkikapratyavasthānasyāpyavasaro nirasta
ityāha - anyeti | anyeṣāmasiddhaviruddhādidoṣadṛśāṃ tārkikāṇāṃ
dṛṣṭāntapradūṣaṇairdūṣyasya hetvāderjagataḥ svapnopamatvādvastuni na
kiṃciddūṣaṇaṃ samudetītyarthaḥ | sādhyasiddhiparyantaṃ
bodhyabodhakavyavahārastu vyāvahārikasatyatāmātreṇāpyupapanna iti bhāvaḥ |
57 |
avastu pūrvāparayorvartamāne vicāritam |
yathā jāgrattathā svapnaḥ siddhamābālamāgatam
]

`v 59 [
svapnasaṃkalpanādhyānavaraśāpauṣadhādibhiḥ |
yathārthā iha dṛṣṭāntāstadrūpatvājjagatsthiteḥ
]

`v 60 [
mokṣopāyakṛtā granthakāreṇānye'pi ye kṛtāḥ |
granthāsteṣviyamevaikā vyavasthā bodhyabodhane
]

`v 61 [
svapnābhatvaṃ ca jagataḥ śrute śāstre'vabodhyate |
śīghraṃ na pāryate vaktuṃ vākkila kramavartinī
]

`v 62 [
p. 119)
svapnasaṃkalpanādhyānanagarādyupamaṃ jagat |
yatasta eva dṛṣṭāntāstasmātsantīha netare
]

`v 63 [
akāraṇe kāraṇatā yadbodhāyopamīyate |
na tatra sarvasādharmyaṃ saṃbhavatyupamāśramaiḥ
]

`v 64 [
upameyasyopamānādekāṃśena sadharmatā |
aṅgīkāryāvabodhāya dhīmatā nirvivādinā
]

`v 65 [
arthāvalokane dīpādābhāmātrādṛte kila |
na sthānatailavartyādi kiṃcidavyupayujyate
]

`v 66 [
ekadeśasamarthatvādupameyāvabodhanam |
upamānaṃ karotyaṅga dīpa'rthaprabhayā yathā
]

`v 67 [
dṛṣṭāntasyāṃśamātreṇa bodhyabodhodaye sati |
upādeyatayā grāhyo mahāvākyārthaniścayaḥ
]

`v 68 [
na kutārkikatāmetya nāśanīyā prabuddhatā |
anubhūtyapalāpāntairapavitrairvikalpitaiḥ
]

`v 69 [
vicāraṇādanubhavakārivairiṇo'pi
vāṅmayaṃ tvanugatamasmadādiṣu |
striyoktamapyapaparamārthavaidikaṃ
vaco vacaḥpralapanameva nāgamaḥ
]

`v 70 [
asmākamasti matiraṅga tayeti sarva-
śāstraikavākyakaraṇaṃ phalitaṃ yato yaḥ |
prātītikārthamapaśāstranijāṅgapuṣṭā-
tsaṃvedanāditaradasti tataḥ pramāṇam
]