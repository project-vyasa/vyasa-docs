`v 1 [
tṛtīyaḥ sargaḥ 3
śrīvasiṣṭha uvāca |
pūrvamuktaṃ bhagavatā yajjñānaṃ padmajanmanā |
sargādau lokaśāntyarthaṃ tadidaṃ kathayāmyaham
]

`v 2 [
śrīrāma uvāca |
kathayiṣyasi vistīrṇāṃ bhagavanmokṣasaṃhitām |
imaṃ tāvatkṣaṇaṃ jātaṃ saṃśayaṃ me nivāraya
]

`v 3 [
pitā śukasya sarvajño gururvyāso mahāmatiḥ |
videhamukto na kathaṃ kathaṃ muktaḥ suto'sya saḥ
]

`v 4 [
`note[tameva] darśayati - piteti | nanvaghaṭito'yaṃ saṃśayaḥ | na |
ātyantikaduḥkho##-
-##muktireva jñānaphalaṃ taccetsarvajñasyāpi vyāsasya na saṃpannaṃ
jñāsyā-nityaphalatvaṃ prāptam | kiṃca yadi jñānenājñānaṃ
niḥśeṣamucchinna tarhi bhṛgvādivajjīvanāsaṃbhavaḥ upādānanāśe
kāryāvasthānāyogāt ajīvane ca
brahmavidyāpravartakābhāvātsaṃpradāyocchedaḥ | atha nocchinnaṃ tarhyanir##-
`note[phalatyavidheyatvāditi] phalati tasya kālatraye'pyakhaṇḍātmanāva##-
śrīvasiṣṭha uvāca |
paramārkaprakāśāntastrijagatrasareṇavaḥ |
utpatyotpatya līnā ye na saṃkhyāmupayānti te
]

`v 5 [
vartamānāśca yāḥ santi trailokyagaṇakoṭayaḥ |
śakyante tāśca saṃkhyātuṃ naiva kāścana kenacit
]

`v 6 [
bhaviṣyanti parāmbodhau jagatsargataraṅgakāḥ |
tāṃśca vai parisaṃkhyātuṃ sā kathaiva na vidyate
]

`v 7 [
śrīrāma uvāca |
yā bhūtā yā bhaviṣyantyo jagatsargaparamparāḥ |
tāsāṃ vicāraṇā yuktā vartamānāstu kā iva
]

`v 8 [
śrīvasiṣṭha uvāca |
tiryakpuruṣadevāderyo nāma sa vinaśyati |
yasminneva pradeśe'sau tadaivedaṃ prapaśyati
]

`v 9 [
ātivāhikanāmnāntaḥ svahṛdyeva jagatrayam |
vyomni cittaśarīreṇa vyomātmānubhavatyajaḥ
]

`v 10 [
evaṃ mṛtā mriyante ca mariṣyanti ca koṭayaḥ |
bhūtānāṃ yāṃ jagantyāśāmuditāni pṛthakpṛthak
]

`v 11 [
saṃkalpanirmāṇamiva manorājyavilāsavat |
indrajālāmāla iva kathārthapratibhāsavat
]

`v 12 [
durvātabhūkampa iva trastabālapīśācavat |
muktālīvāmale vyomni nauṣpandataruyānavat
]

`v 13 [
svapnasaṃvittipuravatsmṛtijātakhapuṣpavat |
jagatsaṃsaraṇaṃ svāntarmṛto'nubhavati svayam
]

`v 14 [
tatrātipariṇāmena tadeva ghanatāṃ gatam |
ihaloko'yamityeva jīvākāśe vijṛmbhate
]

`v 15 [
punastatraiva janmehāmaraṇādyanubhūtimān |
paraṃ lokaṃ kalpayati mṛtastatra tathā punaḥ
]

`v 16 [
tadantaranye puruṣāsteṣāmantastathetare `note[tathā pare] |
saṃsāra iti bhāntīme kadalīdalapīṭhavat
]

`v 17 [
vāsanāyā antaḥ antare anye puruṣā dehāḥ | puruṣā iti paśvādīnāmapyupa##-
na pṛthvyādimahābhūtagaṇā na ca jagatkramāḥ |
mṛtānāṃ santi tatrāpi tathāpyeṣāṃ jagadbhramāḥ
]

`v 18 [
avidyaiva hyananteyaṃ nānāprasaraśālinī |
jaḍānāṃ saridādīrghā taratsargataraṅgiṇī
]

`v 19 [
paramārthāmbudhau sphāre rāma sargataraṅgakāḥ |
bhūyobhūyo'nuvartante ta evānye ca bhūriśaḥ
]

`v 20 [
sarvataḥ sadṛśāḥ kecitkulakramamanoguṇaiḥ |
kecidardhena sadṛśāḥ keciccātivilakṣaṇāḥ
]

`v 21 [
imaṃ vyāsamuniṃ tatra dvātriṃśaṃ saṃsmarāmyaham |
yathāsaṃbhavavijñānadṛśā saṃdṛśyamānayā
]

`v 22 [
dvādaśālpadhiyastatra kulākārehitaiḥ samāḥ |
daśa sarve samākārāḥ śiṣṭāḥ kulavilakṣaṇāḥ
]

`v 23 [
teṣvapyavāntaraviśeṣamāha - dvādaśeti | alpadhiyo brahmavidbrahmavidvaro
brahmavidvarīyān brahmavidvariṣṭha iti prasiddheṣu caturthasthānāviśrānteralpa##-
adyāpyanye bhaviṣyanti vyāsavālmīkayastathā |
bhṛgviṅgaraḥpulastyāśca tathaivāpyanyathaiva ca
]

`v 24 [
narāḥ surarṣidevānāṃ gaṇāḥ saṃbhūya bhūriśaḥ |
utpadyante vilīyante kadācicca pṛthakpṛthak
]

`v 25 [
brāhmī dvāsaptatistretā āsīdasti bhaviṣyati |
sa evānyaśca lokāśca tvaṃ cāhaṃ ceti vedmyaham
]

`v 26 [
brāhmī brāhmakalpāvayavabhūtā tretā sāṃpratamasti pratikalpaṃ cāsīd##-
25 |
krameṇāsya muneritthaṃ vyāsasyādbhutakarmaṇaḥ |
saṃlakṣyate'vatāro'yaṃ daśamo dīrghadarśinaḥ
]

`v 27 [
abhūma vyāsavālmīkiyuktā vayamanekaśaḥ |
abhūma vayameveme bahuśaśca pṛthakpṛthak
]

`v 28 [
abhūma vayameveme sadṛśā itare vidaḥ |
abhūma vayameveme nānākārāḥ samāśayāḥ
]

`v 29 [
bhāvyamadyāpyaneneha nanu svārāṣṭakaṃ punaḥ |
bhūyo'pi bhārataṃ nāma setihāsaṃ kariṣyati
]

`v 30 [
kṛtvā vedavibhāgaṃ ca nītvānena kulaprathām |
brahmatvaṃ ca tathā kṛtvā bhāvyaṃ vaidehamokṣaṇam
]

`v 31 [
vītaśokabhayaḥ śāntanirvāṇo gatakalpanaḥ |
jīvanmukto jitamanā vyāso'yamiti varṇitaḥ
]

`v 32 [
vittabandhuvayaḥkarmavidyāvijñānaceṣṭitaiḥ |
samāni santi bhūtāni kadācinnatu tāni tu
]

`v 33 [
`note[kvaciditi pūrvottarānvayi] dvacitsargaśataistāni bhavanti na bhavanti
vā |
kadācidapi māyeyamitthamantavivarjitā
]

`v 34 [
yacchatīyaṃ viparyāsam bhūribhūtaparamparā |
bījarāśirivājasraṃ pūryamāṇaḥ punaḥpunaḥ
]

`v 35 [
tenaiva saṃniveśena tathānyena punaḥpunaḥ |
sargākārāḥ pravartante taraṅgāḥ kālavāridheḥ
]

`v 36 [
saṃniveśo'vayavasaṃsthānaviśeṣaḥ kramo vā
]