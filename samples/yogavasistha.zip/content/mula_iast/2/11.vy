`v 1 [
ekādaśaḥ sargaḥ 11
śrīvasiṣṭha uvāca |
etatte kathitaṃ sarvaṃ jñānāvataraṇaṃ bhuvi |
mayā svamīhitaṃ caiva kamalodbhavaceṣṭitam
]

`v 2 [
tadidaṃ paramaṃ jñānaṃ śrotumadya `note[śrotu mama iti pāṭhaḥ]
tavānagha |
bhṛśamutkaṇṭhitaṃ ceto mahataḥ sukṛtodayāt
]

`v 3 [
śrīrāma uvāca |
kathaṃ brahmanbhavato loke jñānāvatāraṇe |
sargādanantaraṃ buddhiḥ pravṛttā parameṣṭhinaḥ
]

`v 4 [
śrīvasiṣṭha uvāca |
parame brahmaṇi brahmā svabhāvavaśataḥ svayam |
jātaḥ spandamayo nityamūrmirambunidhāviva
]

`v 5 [
dṛṣṭvaivamāturaṃ sargaṃ sargasya sakalāṃ gatim |
bhūtabhavyabhaviṣyasthāṃ dadarśa parameśvaraḥ
]

`v 6 [
sakriyākramakālasya kṛtādeḥ kṣaya āgate |
mohamālocya lokānāṃ kāruṇyamagamatprabhuḥ
]

`v 7 [
tato māmīśvaraḥ sṛṣṭvā jñānenāyojya casakṛt |
visasarja mahīpīṭhaṃ lokasyājñānaśāntaye
]

`v 8 [
yathāhaṃ prahitastena tathānye ca maharṣayaḥ |
sanatkumārapramukhā nāradādyāśca bhūriśaḥ
]

`v 9 [
kriyākrameṇa puṇyena tathā jñānakrameṇa ca |
manomohāmayonnaddhamuddhartuṃ lokamīritāḥ
]

`v 10 [
maharṣibhistatastaistaiḥ kṣīṇe kṛtayuge purā |
kramātkriyākrame śuddhe pṛthivyāṃ tanutāṃ gate
]

`v 11 [
kriyākramavidhānārthaṃ maryādāniyamāya ca |
pṛthagdeśavibhāgena bhūpālāḥ parikalpitāḥ
]

`v 12 [
p. 97)
bahūni smṛtiśāstrāṇi yajñaśāstrāṇi cāvanau |
dharmakāmārthasiddhyarthaṃ kalpitānyucitānyatha
]

`v 13 [
kālacakre vahatyasmiṃstato vigalite krame |
pratyahaṃ bhojanapare jane śālyarjanonmukhe
]

`v 14 [
bhojanagrahaṇaṃ bhogamātrasyopalakṣaṇaṃ śāligrahaṇaṃ ca viṣayamātrasya | 13
|
dvandvāni saṃpravṛttāni viṣayārthaṃ mahībhujām |
daṇḍyatāṃ saṃprayātāni bhūtāni bhuvi bhūriśaḥ
]

`v 15 [
tato yuddhaṃ vinā bhūpā mahīṃ pālayituṃ kṣamāḥ |
na samarthāstadā yātāḥ prajābhiḥ saha dainyatām
]

`v 16 [
teṣāṃ dainyāpanodārthaṃ samyagdṛṣṭikramāya ca |
tato'smadādibhiḥ proktā mahatyo jñānadṛṣṭayaḥ
]

`v 17 [
adhyātmavidyā teneyaṃ pūrvaṃ rājasu varṇitā |
tadanu prasṛtā loke rājavidyetyudāhṛtā
]

`v 18 [
rājavidyā rājaguhyamadhyātmajñānamuttamam |
jñātvā rāghava rājānaḥ parāṃ nirduḥkhatāṃ gatāḥ
]

`v 19 [
atha rājasvatīteṣu bahuṣvamalakīrtiṣu |
asmāddaśarathādrāma jāto'dya tvamihāvanau
]

`v 20 [
tava cātiprasanne'smiñjātaṃ manasi pāvanam |
nirnimittamidaṃ cāru vairāgyamarimardana
]

`v 21 [
sarvasyaiva hi sarvasya sādhorapi vivekinaḥ |
nimittapūrvaṃ vairāgyaṃ jāyate rāma rājasam
]

`v 22 [
idaṃ tvapūrvamutpannaṃ camatkārakaraṃ satām |
tavānimittaṃ vairāgyaṃ sāttvikaṃ svavivekajam
]

`v 23 [
bībhatsaṃ viṣayaṃ dṛṣṭvā ko nāma na virajyate |
satāmuttamavairāgyaṃ vivekādeva jāyate
]

`v 24 [
te mahānto mahāprājñā nimittena vinaiva hi |
vairāgyaṃ jāyate yeṣāṃ teṣāṃ hyamalamānasam
]

`v 25 [
svavivekacamatkāraparāmarśaviraktayā |
rājate hi dhiyā janturyuveva varamālayā
]

`v 26 [
parāmṛśya vivekena saṃsāraracanābhimām |
vairāgyaṃ ye'dhigacchanti ta eva puruṣottamāḥ
]

`v 27 [
svavivekavaśādeva vicāryedaṃ punaḥ punaḥ |
indrajālaṃ parityājyaṃ sabāhyābhyantaraṃ balāt
]

`v 28 [
śmaśānamāpadaṃ dainyaṃ dṛṣṭvā ko na virajyate |
tadvairāgyaṃ paraṃ śreyaḥ svato yadabhijāyate
]

`v 29 [
akṛtrimavirāgatvaṃ mahattvamalamāgataḥ |
yogyo'si jñānasārasya bījasyeva mṛdusthalam
]

`v 30 [
alamatyantamāgataḥ prāptavān | jñānānāṃ vidyānāṃ sāra ātmavidyā tasya | 29
|
prasādātparameśasya nāthasya paramātmanaḥ |
tvādṛśasya śubhā buddhirvivekamanudhāvati
]

`v 31 [
kriyākrameṇa mahatā tapasā niyamena ca |
dānena tīrthayātrābhiścirakālaṃ vivekataḥ
]

`v 32 [
duṣkṛte kṣayamāpanne paramārthavicāraṇe |
kākatālīyayogena buddhirjantoḥ pravartate
]

`v 33 [
p. 98)
kriayāparāstāvadalaṃ cakrāvartibhirāvṛtāḥ |
bhramantīha janā yāvanna paśyanti paraṃ padam
]

`v 34 [
yathābhūtamidaṃ dṛṣṭvā saṃsāraṃ tanmayīṃ dhiyam |
parityajya paraṃ yānti nirālānā gajā iva
]

`v 35 [
yathābhūtaṃ yathāsthitaṃ paramārthabhūtamityarthaḥ | idaṃ nityāparokṣaṃ
brahmatattvaṃ paraṃ ca tadeva | yadvā | idaṃ dṛśyajātaṃ yathābhūtaṃ
paramārthataḥ asadasāraṃ duḥkhabhūtaṃ vivekabuddhyā dṛṣṭvetyarthaḥ | paraṃ
brahma yānti jñānena prāpnuvanti | ālānaṃ bandhanastambhastasmānnirgatāḥ | 34
|
viṣameyamananteha rāma saṃsārasaṃsṛtiḥ |
dehayukto mahājanturvinā jñānaṃ na paśyati
]

`v 36 [
jñānayuktiplavenaiva saṃsārābdhiṃ sudustaram |
mahādhiyaḥ samuttīrṇā nimeṣeṇa radhūdvaha
]

`v 37 [
tāmimāṃ jñānayuktiṃ tvaṃ saṃsārāmbhodhitāriṇīm |
śṛṇuṣvāvahito buddhyā nityāvahitayā tayā
]

`v 38 [
yasmādanantasaṃrambhā jāgatyo duḥkhabhītayaḥ |
cirāyāntardahantyetā vinā yuktimaninditām
]

`v 39 [
śītavātātapādīni dvandvaduḥkhāni rāghava |
jñānaśaktiṃ vinā kena sahyatāṃ yānti sādhuṣu
]

`v 40 [
āpatanti pratipadaṃ yathākālaṃ dahanti ca |
duḥkhcintā naraṃ mūḍhaṃ tṛṇamagniśikhā iva
]

`v 41 [
prājñaṃ vijñātavijñeyaṃ samyagadarśanamādhayaḥ |
na dahanti vanaṃ varṣāsiktamagniśikhā iva
]

`v 42 [
vijñātāni vijñeyāni vicārya jñātuṃ yogyānyadhyātmaśāstrāṇi yena ata eva
samyagadarśanaṃ brahma tattvasākṣātkāro yasya tam | ādhayo mānasavyathāḥ |
41 |
ādhivyādhiparāvarte saṃsāramarumārute |
kṣubhite'pi na tattvajño bhajyate kalpavṛkṣavat
]

`v 43 [
tattvaṃ jñātumato yatnāddhīmāneva hi dhīmatā |
prāmāṇikaḥ prabuddhātmā praṣṭavyaḥ praṇayānvitam
]

`v 44 [
prāmāṇikasya pṛṣṭasya vakturuttamacetasaḥ |
yatena vacanaṃ grāhyamaṃśukeneva kuṅkumam
]

`v 45 [
atattvajñamanādeyavacanaṃ vāgvidāṃ vara |
yaḥ pṛcchati naraṃ tasmānnāsti mūḍhataro'paraḥ
]

`v 46 [
prāmāṇikasya tajjñasya vaktuḥ pṛṣṭasya yatnataḥ |
nānutiṣṭhati yo vākyaṃ nānyastasmānnarādhamaḥ
]

`v 47 [
ajñatātajjñate pūrvaṃ vakturnirṇīya kāryataḥ |
yaḥ karoti naraḥ praśnaṃ pracchakaḥ sa mahāmatiḥ
]

`v 48 [
anirṇīya pravaktāraṃ bālaḥ praśnaṃ karoti yaḥ |
adhamaḥ pracchakaḥ sa syānna mahārthasya bhājanam
]

`v 49 [
pūrvāparasamādhānakṣamabuddhāvanindite |
pṛṣṭaṃ prājñena vaktavyaṃ nādhame paśudharmiṇi
]

`v 50 [
prāmāṇikārthayogyatvaṃ pracchakasyāvicārya ca |
yo vakti tamiha prājñāḥ prāhurmūḍhataraṃ naram
]

`v 51 [
tvamatīva guṇaślāghī pracchako raghunandana |
ahaṃ ca vaktuṃ jānāmi samo yogo'yamāvayoḥ
]

`v 52 [
yadahaṃ vacmi tadyatnāttvayā śabdārthakovida |
etadvastviti nirṇīya hṛdi kāryamakhaṇḍitam
]

`v 53 [
mahānasi virakto'si tattvajño'si janasthitau |
tvayi coktaṃ lagatyantaḥ kuṅkumāmbu yathāṃśuke
]

`v 54 [
uktāvadhānaparamā paramārthavivecinī |
viśatyarthaṃ tava prajñā jalamadhyamivārkabhāḥ
]

`v 55 [
medhāpratibhāśālinītvaṃ viśeṣaṇadvayena labhyate | arkabhāḥ sūryaprabhā | 54
|
yadyadvacmi tadādeyaṃ hṛdi kāryaṃ prayatnataḥ |
nocetpraṣṭavya evāhaṃ na tvayeha nirarthakam
]

`v 56 [
ādaradṛḍhīkaraṇāyāha - yadyaditi | prayatnataścirābhyāsādiprayatnena | 55
|
mano hi capalaṃ rāma saṃsāravanamarkaṭam |
saṃśodhya hṛdi yatnena śrotavyā paramārthagīḥ
]

`v 57 [
p. 99)
avivekinamajñānamasajjanaratiṃ janam |
ciraṃ dūratare kṛtvā pūjanīyā hi sādhavaḥ
]

`v 58 [
nityaṃ sajjanasaṃparkādviveka upajāyate |
vivekapādapasyaiva bhogamokṣau phale smṛtau
]

`v 59 [
mokṣadvāre dvārapālāścatvāraḥ parikīrtitāḥ |
śamo vicāraḥ saṃtoṣaścaturthaḥ sādhusaṃgamaḥ
]

`v 60 [
ete sevyāḥ prayatnena catvārau dvau trayo'thavā |
dvāramuddhāṭayantyete mokṣarājagṛhe tathā
]

`v 61 [
ekaṃ vā sarvayatnena prāṇāṃstyaktvā samāśrayet |
ekasminvaśage yānti catvāro'pi vaśaṃ yataḥ
]

`v 62 [
saviveko hi śāstrasya jñānasya tapamaḥ śruteḥ |
bhājanaṃ bhūṣaṇākāro bhāskarastejasāmiva
]

`v 63 [
ghanatāmupayātaṃ hi prajñāmāndyamacetasām |
yāti sthāvaratāmambu jāḍyātpāṣāṇatāmiva
]

`v 64 [
tvaṃ tu rāghava saujanyaguṇaśāstrārthadṛṣṭibhiḥ |
vikāsitāntaḥkaraṇaḥ sthitaḥ padma ivodaye
]

`v 65 [
imāṃ jñānagiraṃ śrotumavaboddhuṃ ca sanmate |
arhasyuddhatakarṇastvaṃ janturvīṇāsvanaṃ yathā
]

`v 66 [
vairāgyābhyāsayogena samasaujanyasaṃpadām `note[śamasaujanya] |
arjanāṃ kurutāṃ rāma yatra nāśo na vidyate
]

`v 67 [
śāstrasajjanasaṃsargapūrvakaiḥ satapodamaiḥ |
ādau saṃsāramuktyarthaṃ prajñāmevābhivardhayet
]

`v 68 [
etadevāsya maurkhyasya paramaṃ viddhi nāśanam |
yadidaṃ prekṣyate śāstraṃ kiṃcitsaṃskṛtayā dhiyā
]

`v 69 [
saṃsāraviṣavṛkṣo'yamekamāspadamāpadām |
ajñaṃ saṃmohayennityaṃ maurkhyaṃ yatnena nāśayet
]

`v 70 [
āspadaṃ pratiṣṭhā | yataḥ saṃmohayettasmāditi śeṣaḥ | maurkhyamajñānam | 69
|
durāśāsarpagatyena maurkhyeṇa hṛdi valgatā |
cetaḥ saṃkocamāyāti carmāgnāviva yojitam
]

`v 71 [
prājñe yathārthabhūteyaṃ vastudṛṣṭiḥ prasīdati |
dṛgivendau nirambhode sakalāmalamaṇḍale
]

`v 72 [
pūrvāparavicārārthacārucāturyaśālinī |
savikālsā matiryasya sa pumāniha kathyate
]

`v 73 [
vikasitena sitena tamomucā
varavicāraṇaśītalarociṣā |
guṇavatā hṛdayena virājase
tvamamalena nabhaḥ śaśinā yathā
]