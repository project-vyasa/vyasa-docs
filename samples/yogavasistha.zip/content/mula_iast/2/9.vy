`v 1 [
navamaḥ sargaḥ 9
śrīrāma uvāca |
bhagavansarvadharmajña pratiṣṭhāmalamāgatam |
yalloke tadvada brahmandaivaṃ nāma kimucyate
]

`v 2 [
śrīvasiṣṭha uvāca |
pauruṣaṃ sarvakāryāṇāṃ kartṛ rāghava netarat |
phalabhoktṛ ca sarvatra na daivaṃ tatra kāraṇam
]

`v 3 [
daivaṃ na kiṃcitkurute na bhuṅkte na ca vidyate |
na dṛśyate nādriyate kevalaṃ kalpanedṛśī
]

`v 4 [
siddhasya pauruṣeṇeha phalasya phalaśālinā |
śubhāśubhārthasaṃpattirdaivaśabdena kathyate
]

`v 5 [
pauruṣopanatā nityamiṣṭāniṣṭasya vastunaḥ |
prāptiriṣṭāpyaniṣṭā vā daivaśabdena kathyate
]

`v 6 [
bhāvī `note[bhāvī pauruṣajaḥ] tvavaśyamevārthaḥ
puruṣārthaikasādhanaḥ |
yaḥ so'smiṁllokasaṃghāte daivaśabdena kathyate
]

`v 7 [
nanu rāghava lokasya kasyacitkiṃcideva hi |
daivamākāśarūpaṃ hi karoti na karoti ca
]

`v 8 [
puruṣārthasya siddhasya śubhāśubhaphalodaye |
idamitthaṃ sthitamiti yoktistaddaivamucyate
]

`v 9 [
itthaṃ mamābhavadbuddhiritthaṃ me niścayo hyabhūt |
iti karmaphalaprāptau yoktistaddaivamucyate
]

`v 10 [
iṣṭāniṣṭaphalaprāptāvidamityasya vācakam |
āśvāsanāmātravaco daivamityeva kathyate
]

`v 11 [
śrīrāma uvāca |
bhagavansarvadharmajña yatprākkarmopasaṃcitam |
taddaivaṃ `note[tadetaddaivamityuktaṃ iti pāṭhaḥ]
daivamityuktamapamṛṣṭaṃ kathaṃ tvayā
]

`v 12 [
kalpadvayābhedoktyā'śayamapratipadyamānaḥ prathamakalpenopakramya
dvitīyakalpenopasaṃhāre virodhaṃ manyamānaḥ svābhisaṃdhiṃ prakāśayan
śrīrāma uvāca - bhagavanniti | yatprāktanaṃ karma tadeva punaḥpunardaivamiti
yadyuktaṃ tarhi tadvidyata eva na vidyate iti tvayā kathamapamṛṣṭamapalapitam |
apalāpavacanasya ko'bhiprāya ityarthaḥ | 11 |
śrīvasiṣṭha uvāca |
sādhu rāghava jānāsi śṛṇu vakṣyāmi te'khilam |
daivaṃ nāstīti te yena sthirā buddhirbhaviṣyati
]

`v 13 [
p. 92)
yā manovāsanā pūrvaṃ babhūva kila bhūriśaḥ |
saiveyaṃ karmabhāvena nṛṇāṃ pariṇatiṃ gatā
]

`v 14 [
janturyadvāsano rāma tatkartā `note[tatkarmā iti pāṭhaḥ] bhavati kṣaṇāt
|
anyakarmānyabhāvaścetyetannaivopapadyate
]

`v 15 [
grāmago grāmamāpnoti pattanārthī ca pattanam |
yo yo yadvāsanastatra sa sa prayatate sadā
]

`v 16 [
yadeva tīvrasaṃvegāddṛḍhaṃ karma kṛtaṃ purā |
tadeva daivaśabdena paryāyeṇeha kathyate
]

`v 17 [
evaṃ karmasthakarmāṇi karmaprauḍhā svavāsanā |
vāsanā manaso nānyā mano hi puruṣaḥ smṛtaḥ
]

`v 18 [
yaddaivaṃ tāni karmāṇi karma sādho mano hi tat |
mano hi puruṣastasmāddaivaṃ nāstīti niścayaḥ
]

`v 19 [
eṣa eva manojanturyadyatprayatate hitam |
kṛtaṃ tattadavāpnoti svata eva hi daivataḥ
]

`v 20 [
manaścittaṃ vāsanā ca karma daivaṃ ca niścayaḥ |
rāma durniścayasyaitāḥ saṃjñāḥ sadbhirudāhṛtāh
]

`v 21 [
evaṃnāmā hi puruṣo dṛḍhabhāvanayā yathā |
nityaṃ prayatate rāma phalamāpnotyalaṃ tathā
]

`v 22 [
evaṃ puruṣakāreṇa sarvameva raghūdvaha |
prāpyate netareṇeha `note[nacireṇeha iti pāṭhaḥ] tasmātsa śubhado'stu te
]

`v 23 [
śrīrāma uvāca |
prāktanaṃ vāsanājālaṃ niyojayati māṃ yathā |
mune tathaiva tiṣṭhāmi kṛpaṇaḥ kiṃ karomyaham
]

`v 24 [
śrīvasiṣṭha uvāca |
ata eva hi rāma tvaṃ śreyaḥ prāpnoṣi śāśvatam |
svaprayatnopanītena pauruṣeṇaiva nānyathā
]

`v 25 [
dvividho vāsanāvyūhaḥ śubhaścaivāśubhaśca te |
prāktano vidyate rāma dvayorekataro'tha vā
]

`v 26 [
vāsanaughena śuddhena tatra cedadya nīyase |
tatkrameṇa śubhenaiva padaṃ prāpsyasi śāśvatam
]

`v 27 [
atha cedaśubho bhāvastvāṃ yojayati saṃkaṭe |
prāktanastadasau yatnājjetavyo bhavatā balāt
]

`v 28 [
prājñaścetanamātrastvaṃ na dehastvaṃ jaḍātmakaḥ |
anyena cetasā `note[cetyase tattvaṃ iti pāṭhaḥ] tatte cetyatvaṃ kveva
vidyate
]

`v 29 [
p. 93)
anyastvāṃ cetayati cettaṃ cetayati ko'paraḥ |
ka imaṃ cetayettasmādanavasthā na vāstavī
]

`v 30 [
citaścidantaravedyatve tadapyanyavedyamityanavasthāpi syādityāha - anya iti |
imaṃ taccetayitāraṃ kaścetayet | tasyāpyanyaścedanavasthā syāt sā ca na vāstavī
vastusiddhikarīti tava sadvāsanodbodhayatne svātantryamavyāhṛtamiti bhāvaḥ | 29
|
śubhāśubhābhyāṃ mārgābhyāṃ vahantī vāsanāsarit |
pauruṣeṇa prayatnena yojanīyā śubhe pathi
]

`v 31 [
aśubheṣu samāviṣṭaṃ śubheṣvevāvatāraya |
svaṃ manaḥ puruṣārthena balena balināṃ vara
]

`v 32 [
aśubhāccālitaṃ yāti śubhaṃ tasmādapītarat |
jantościttaṃ tu śiśuvattasmāttaccālayedbalāt
]

`v 33 [
cittanadī hi dvedhā pravahati puṇyāya ca pāpāya ca tatraikasrotonirodhe aparatra
dviguṇaṃ vahatīti yogaśāstroktimanusṛtyāha - aśubhāditi | cālitaṃ
nivāritam | tasmācchubhādapi cālitamitaradaśubham | cālayedaśubhāditi śeṣaḥ |
32 |
samatā sāṃtvanenāśu na drāgiti śanaiḥ śanaiḥ |
pauruṣeṇaiva yatnena pālayeccittabālakam
]

`v 34 [
vāsanaughastvayā pūrvamabhyāsena ghanīkṛtaḥ |
śubho vāpyaśubho vāpi śubhamadya ghanīkuru
]

`v 35 [
prāgabhyāsavaśādyātā yadā te vāsanodayam |
tadābhyāsasya sāphalyaṃ viddhi tvamarimardana
]

`v 36 [
idānīmapi te yāti ghanatāṃ vāsanānagha |
abhyāsavaśatastasmācchubhābhyāsamupāhara
]

`v 37 [
pūrve ceddhanatāṃ yātā nābhyāsāttava vāsanā |
varghiṣyate tu nedānīmapi tāta sukhī bhava
]

`v 38 [
saṃdigdhāyāmapi bhṛśaṃ śubhāmeva samāhara |
asyāṃ tu vāsanāvṛddhau śubhāddoṣo na kaścana
]

`v 39 [
yadyadabhyasyate loke tanmayenaiva bhūyate |
ityākumāraṃ prājñeṣu dṛṣṭaṃ saṃdehavarjitam
]

`v 40 [
vastutastu na saṃdehasaṃbhāvanā |
anyatrāpyabhyāsasyābhyasyamānadārḍhyahetutvakḷpterityāha - yadyaditi |
39 |
śubhavāsanayā yuktastadatra bhava bhūtaye |
paraṃ pauruṣamāśritya vijityendriyapañcakam
]

`v 41 [
avyutpannamanā yāvadbhavānajñātatatpadaḥ |
guruśāstrapramāṇaistu nirṇītaṃ tāvadācara
]

`v 42 [
tataḥ pakvakaṣāyeṇa nūnaṃ vijñātavastunā |
śubhopyasau tvayā tyājyo vāsanaugho nirādhinā
]

`v 43 [
yadatisubhagamāryasevitaṃ ta-
cchubhamanusṛtya manojñabhāvabuddhyā |
adhigamaya padaṃ sadā viśokaṃ
tadanu tadapyavamucya sādhu tiṣṭha
]