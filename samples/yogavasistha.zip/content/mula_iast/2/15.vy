`v 1 [
pañcadaśaḥ sargaḥ 15
śrīvasiṣṭha uvāca |
saṃtoṣo hi paraṃ śreyaḥ saṃtoṣaḥ sukhamucyate |
saṃtuṣṭaḥ paramabhyeti viśrāmamarisūdana
]

`v 2 [
p. 110)
saṃtoṣaiśvaryasukhināṃ ciraviśrāntacetasām |
sāmrājyamapi śāntānāṃ jarattṛṇalavāyate
]

`v 3 [
saṃtoṣaśālinī buddhī rāma saṃsāravṛttiṣu |
viṣamāsvapyanudvignā na kadācana hīyate
]

`v 4 [
saṃtoṣāmṛtapānena ye śāntāstṛptimāgatāḥ |
bhogaśrīratulā teṣāmeṣā prativiṣāyate
]

`v 5 [
na tathā sukhayantyetāḥ pīyūṣarasavīcayaḥ |
yathātimadhurāsvādaḥ saṃtoṣo doṣanāśanaḥ
]

`v 6 [
aprāptavāñchāmutsṛjya saṃprāpte samatāṃ gataḥ |
adṛṣṭakhedākhedo yaḥ sa saṃtuṣṭa ihocyate
]

`v 7 [
ātmanātmani saṃtoṣaṃ yāvadyāti na mānasam |
udbhavantyāpadastāvallatā iva manobilāt
]

`v 8 [
saṃtoṣaśītalaṃ cetaḥ śuddhavijñānadṛṣṭibhiḥ |
bhṛśaṃ vikāsamāyāti sūryāṃśubhirivāmbujam
]

`v 9 [
āśāvaivaśyavivaśe citte saṃtoṣavarjite |
mlāne vaktramivādarśe na jñānaṃ pratibimbati
]

`v 10 [
ajñānaghanayāminyā saṃkocaṃ na narāmbujam |
yātyasāvudito yasya nityaṃ saṃtoṣabhāskaraḥ
]

`v 11 [
yasya narāmbujasya vikāsāyāsau prāguktaḥ saṃtoṣabhāskara
uditastannarāmbujamajñānalakṣaṇayā gāḍhāndhakārarātryā saṃkocaṃ na yāti |
10 |
akiṃcano'pyasau jantuḥ sāmrājyasukhamaśnute |
ādhivyādhivinirmuktaṃ saṃtuṣṭaṃ yasya mānasam
]

`v 12 [
nābhivāñchatyasaṃprāptaṃ bhuṅkte yathākramam |
yaḥ susaumyasamācāraḥ saṃtuṣṭa iti kathyate
]

`v 13 [
saṃtuṣṭiparatṛptasya mahataḥ pūrṇacetasaḥ |
kṣīrābdheriva śuddhasya mukhe lakṣmīrvirājate
]

`v 14 [
pūrṇatāmalamāśritya svātmanyevātmanā svayam |
pauruṣeṇa prayatnena tṛṣṇāṃ sarvatra varjayet
]

`v 15 [
saṃtoṣāmṛtapūrṇasya śāntaśītalayā dhiyā |
svayaṃ sthairyaṃ mano yāti śītāṃśoriva śāśvatam
]

`v 16 [
saṃtoṣapuṣṭamanasaṃ bhṛtyā iva maharddhayaḥ |
rājānamupatiṣṭhanti kiṃkaratvamupāgatāḥ
]

`v 17 [
ātmanaivātmani svasthe saṃtuṣṭe puruṣe sthite |
praśāmyantyādhayaḥ sarve prāvṛṣīvāśu pāṃśavaḥ
]

`v 18 [
nityaṃ śītalayā rāma kalaṅkaparibhinnayā |
puruṣaḥ śuddhayā vṛttyā bhāti pūrṇatayenduvat
]

`v 19 [
samatāsundaraṃ vaktraṃ puruṣasyāvalokayan |
toṣameti yathā loko na tathā dhanasaṃcayaiḥ
]

`v 20 [
samatayā matayā guṇaśālināṃ
puruṣarāḍiha yaḥ samalaṃkṛtaḥ |
tamamalaṃ praṇamanti nabhaścarā
api mahāmunayo raghunandana
]