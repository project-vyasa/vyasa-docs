`v 28 [
folio 120 - 121 is unclear
p. 122)
rūpālokamanaskārapadārthavyākulaṃ jagat |
vidyate vedanasyāntarvātāntaḥ spandanaṃ yathā
]

`v 29 [
nanu manaścalane nirviṣayavedanasya hetutvāyogātsaviṣaya tadvācyam | tatra
manaścalanādapi pūrvasiddho viṣayo vācyaḥ | tathā viṣayāṇāṃ manomayatvasya
prāguktatvādviṣayasiddheḥ prāṅmanaḥsiddhirvācyetyanyonyāśraya
ityāśaṅkya sarvasaṃskārarūpeṇa māyāśabalacidantaradhiṣṭhānasattayā
sadevāvirbhavatītyāha - rūpeti | bahirindriyairviṣayagraho rūpāloko manasā
viṣayānusaṃdhānaṃ manaskārastadubhayaviṣayāḥ padārthāśca tairvyākulam |
28 |
sarvātmavedanaṃ śuddhaṃ yathodeti tadātmakam |
bhāti prasṛtadikkālabāhyāntārūpadehakam
]

`v 30 [
dṛṣṭvaiva dṛśyatābhāsaṃ svarūpaṃ dhārayansthitaḥ |
svaṃ yathā yatra yadrūpaṃ pratibhāti tathaiva tat
]

`v 31 [
sa sarvātmā yathā yatra samullāsamupāgataḥ |
tiṣṭhatyāśu tathā tatra tadrūpa iva rājate
]

`v 32 [
sarvātmakatayā draṣṭurdṛśyatvamiva yujyate |
dṛśyatvaṃdraṣṭṭasadbhāve dṛśyatāpi na vāstavī
]

`v 33 [
akāraṇakaevāto brahma siddhamidaṃ sthitam |
pratyakṣameva nirmātṛ tasyāṃśāstvanumādayaḥ
]

`v 34 [
svayatnamātre yadupāsako ya-
staddaivaśabdārthamapāsya dūre |
śūreṇa sādho padamuttamaṃ tat
svapauruṣeṇaiva hi labhyate'ntaḥ
]

`v 35 [
vicārayācāryaparamparāṇāṃ
matena satyena `note[sattvena iti mūlavyākhyayoḥ kvācitkaḥ pāṭhaḥ]
sitena tāvat |
yāvadviśuddhaṃ svayameva buddhyā
hyanantarūpaṃ paramabhyupaiṣi
]