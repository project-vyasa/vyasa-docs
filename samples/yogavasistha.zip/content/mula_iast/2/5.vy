`v 1 [
pañcamaḥ sargaḥ 5
śrīvasiṣṭha uvāca |
pravṛttireva prathamaṃ yathāśāstravihāriṇām |
prabheva varṇabhedānāṃ sādhanī sarvakarmaṇām
]

`v 2 [
manasā vāñchyate yacca yathāśāstraṃ na karmaṇā |
sādhyate mattalīlāsau mohanī nārthasādhanī
]

`v 3 [
nanu tṛptyādivaddṛṣṭaphalatvādvidyāyāḥ kastatsādhane
śāstrīyaniyamasyopa-yogastatrāha - manaseti | asau mattalīlā
unmattaceṣṭaiva | sādhyate teneti śeṣaḥ | ataeva na puruṣārthasādhanī pratyuta
mohanī | dṛṣtaphalatve'pyaśāstrīyopāya##-
yathā saṃyatate `note[saṃyatyate] yena tathā tenānubhūyate |
svakarmaiveti cāste'nyā vyatiriktā na daivadṛk
]

`v 4 [
ucchāstraṃ śāstritaṃ ceti dvividhaṃ pauruṣaṃ smṛtam |
tatricchāstramanarthāya paramārthāya śāstritam
]

`v 5 [
dvau huḍāviva yudhyete puruṣārthau samāsamau |
prāktanaścaihikaścaiva śāmyatyatrālpavīryavān
]

`v 6 [
ataḥ puruṣayatnena yatitavyaṃ yathā tathā |
puṃsā tantreṇa sadyogādyenāśvadyatano jayet
]

`v 7 [
dvau huḍāviva yudhyete puruṣārthau samāsamau |
ātmīyaścānyadīyaśca jayatyatibalastayoḥ
]

`v 8 [
anarthaḥ prāpyate yatra śāstritādapi pauruṣāt |
anarthakartṛ balavattatra jñeyaṃ svapuruṣam
]

`v 9 [
paraṃ paruṣamāśritya dantairdantānvicūrṇayan |
śubhenā'śubhamudyuktaṃ prāktanaṃ pauruṣaṃ jayet
]

`v 10 [
prāktanaḥ puruṣārtho'sau māṃ niyojayatīti dhīḥ |
balādadpadīkāryā pratyakṣādadhikā na sā
]

`v 11 [
tāvattāvatprayatnena yatitavyaṃ supauruṣam |
prāktanaṃ pauruṣaṃ yāvadaśubhaṃ śāmyati svayam
]

`v 12 [
doṣaḥ śāmyatyasaṃdehaṃ prāktano'dyatanairguṇaiḥ |
dṛṣṭānto'tra hyastanasya doṣasyādya guṇaiḥ kṣayaḥ
]

`v 13 [
asaddaivamadhaḥkṛtvā nityamudriktayā dhiyā |
saṃsārottaraṇaṃ bhūtyai yatetā''dhātumātmani
]

`v 14 [
na gantavyamanudyogaiḥ sāmyaṃ puruṣagardabhaiḥ |
udyogastu yathāśāstraṃ lokadvitayasiddhaye
]

`v 15 [
saṃsārakuharādasmānnirgantavyaṃ svayaṃ balāt |
pauruṣaṃ yatnamāśritya hariṇevāripañjarāt
]

`v 16 [
pratyahaṃ pratyavekṣeta dehaṃ na"varamātmanaḥ |
saṃtyajetpaśubhistulyaṃ śrayetsatpuruṣocitam
]

`v 17 [
kiṃcitkāntānnapānādikalilaṃ komalam gṛhe |
vraṇe kīṭa ivāsvādya vayaḥ kāryaṃ na bhasmasāt
]

`v 18 [
śubhena pauruṣeṇāśu śubhamāsādyate phalam |
aśubhenāśubhaṃ nityaṃ daivaṃ nāma na kiṃcana
]

`v 19 [
pratyakṣamānamutsṛjya yo'numānamupaityasau |
svabhujābhyāmimau sarpāviti prekṣya palāyate
]

`v 20 [
daivaṃ saṃprerayati māmiti dagdhadhiyāṃ mukham |
adṛṣṭaśreṣṭhadṛṣṭīnāṃ dṛṣṭvā lakṣmīrnivartate
]

`v 21 [
tasmātpuruṣayatnena vivekaṃ pūrvamāśrayet |
ātmajñānamahārthāni śāstrāṇi pravicārayet
]

`v 22 [
citte cintayatāmarthaṃ yathāśāstraṃ nijehitaiḥ |
asaṃsādhayatāmeva mūḍhānā. mdhigdurīpsitam
]

`v 23 [
pauruṣaṃ ca navānantaṃ na yatnamabhivācchyate |
na yatnenāpi mahatā prāpyate ratnamaśmataḥ `note[tailamaśmanaḥ] | 23
|
nanviyantaṃ kālaṃ pauruṣaṃ kāryamityavadhyavagamena tasyānantyātpari##-
tatpauruṣama-nantamanavadhikaṃ na | sākṣātkārodayasyaivāvadhitvāt | yatnaṃ
pariśrama-mabhilakṣya ca na vāñchyate nāpekṣyate | pratyakṣāvagamaṃ
dharmyaṃ susukhaṃ kartumavyayam iti bhagavadvacanāditi bhāvaḥ | nanvidaṃ
pūrṇāhutyā sarvānkāmānavāpnoti itivatprarocanāmātraṃ śramādhikye satyevaṃ
phalādhikyaniyamādityāśaṅkyānvayavyabhicāramāha - neti | ratnatattva##-
`note[vyatireke'bhicāro] vyabhicāro'pi bodhyaḥ
]

`v 24 [
yathā ghaṭaḥ parimito yathā parimitaḥ paṭaḥ |
niyataḥ parimāṇasthaḥ puruṣārthastathaiva ca
]

`v 25 [
sa ca sacchāstrasatsaṅgasadācārairnijaṃ phalam |
dadātīti svabhāvo'yamanyathā nārthasiddhaye
]

`v 26 [
svarūpaṃ pauruṣasyaitadevaṃ vyavaharannaraḥ |
yāti niṣphalayatnatvaṃ na kadācana kaścana
]

`v 27 [
dainyadāridryaduḥkhārtā apyanye puruṣottamāḥ |
pauruṣeṇaiva yatnena yātā devendratulyatām
]

`v 28 [
ābālyādalamabhyastaiḥ śāstrasatsaṅgamādibhiḥ |
guṇaiḥ puruṣayatnena svārthaḥ saṃprāpyate yataḥ
]

`v 29 [
iti pratyakṣato dṛṣṭamanubhūtaṃ śrutaṃ kṛtam |
`note[daivotthamiti] daivāttamiti manyante ye hatāste kubuddhayaḥ
]

`v 30 [
ālasyaṃ yadi na bhavejjagatyanarthaḥ
ko na syādbahudhanako bahuśruto vā |
ālasyādiyamavaniḥ sasāgarāntā
saṃpūrṇā narapaśubhiśca nirdhanaiśca
]

`v 31 [
bālye gate'viratakalpitakelilole
dordaṇḍamaṇḍitavayaḥ `note[maṇḍanavayaḥ] prabhṛti prayatnāt |
satsaṅgamaiḥ padapadārthaviśuddhabuddhiḥ
kuryānnaraḥ `note[suguṇa] svaguṇadoṣavicāraṇāni
]

`v 32 [
yatyapyatyantabālyaprabhṛti kartuṃ na śakyate tarhi yauvanamārabhya vā
yatitavyamityāha - bālya iti | naraḥ avirataiścapalairbālaiḥ kalpitābhiḥ
krīḍābhirlole bālye gate sati dordaṇḍābhyāṃ duruśuśrūṣādisamarthā##-
padapadārthaviśuddhabuddhiḥ padatadarthatatparīkṣākuśalaḥ
`note[tattvaparīkṣā] | vyutpannaḥ sannityarthaḥ |
gurusatīrthyābhijñatamādisatsaṃgamaiḥ | svasya ātmano guṇānāṃ
śāntyādīnāṃ doṣāṇāṃ rāgādīnāṃ cārthānarthaparya##-
vālmīkiruvāca |
ityuktavatyatha munau divaso jagāma
sāyaṃtanāya vidhaye'stamino jagāma |
snātuṃ sabhā kṛtanamaskaraṇā jagāma
śyāmākṣaye ravikareṇa `note[ravikaraiśca] sahājagāma
]