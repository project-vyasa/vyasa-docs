`v 1 [
dvādaśaḥ sargaḥ 12
śrīvasiṣṭha uvāca |
paripūrṇamanā mānyaḥ praṣṭuṃ jānāsi rāghava |
vetsi coktaṃ ca tenāhaṃ pravṛtto vaktumādarāt
]

`v 2 [
p. 100)
rajastamobhyāṃ rahitāṃ śuddhasattvānupātinīm |
matimātmani saṃsthāpya jñānaṃ śrotuṃ sthiro bhava
]

`v 3 [
vidyate tvayi sarvaiva pracchakasya guṇāvalī |
vakturguṇāścaiva `note[guṇāvalī ca mayi iti mudritapustake pāṭhaḥ] mayi
ratnaśrīrjaladhau yathā
]

`v 4 [
āptavānasi vairāgyaṃ vivekāsaṅgajaṃ suta |
candrakānta ivārdratvaṃ lagnacandrakarotkaraḥ
]

`v 5 [
ciramāśaiśavādeva tavābhyāso'sti sadguṇaiḥ |
śuddhaiḥ śuddhasya dīrghaiśca padmasyevātisaṃtataiḥ
]

`v 6 [
ataḥ śṛṇu kathāṃ vakṣye tvamevāsyā hi bhājanam |
na hi candraṃ vinā śuddhā savikāsā kumudvatī
]

`v 7 [
ye kecana samārambhā yāśca kāścana dṛṣṭayaḥ |
te ca tāśca pade dṛṣṭe niḥśeṣaṃ yānti vai śamam
]

`v 8 [
yadi vijñānaviśrāntirna bhavedbhavyacetasaḥ |
tadasyāṃ saṃsṛtau sādhuścintāmauḍhyaṃ saheta kaḥ
]

`v 9 [
paraṃ prāpya vilīyante sarvā mananavṛttayaḥ |
kalpāntārkagaṇāsaṅgātkulaśailaśilā iva
]

`v 10 [
duḥsahā rāma saṃsāraviṣāveśaviṣūcikā |
yogagāruḍamantreṇa pāvanena praśāmyati
]

`v 11 [
sa ca yogaḥ sajjanena saha śāstravicāraṇāt |
paramārthajñānamantro nūnaṃ labhyata eva ca
]

`v 12 [
avaśyamiha hi vicāre kṛte sakaladuḥkhaparikṣayo bhavatīti mantavyaṃ nāto
vicāradṛṣṭayo'vahelayā draṣṭavyāḥ
]

`v 13 [
vicāravatā `note[vicāravaśataḥ iti pāṭhaḥ] puruṣeṇa
sakalamidamādhipañjaraṃ `note[māyipañjaraṃ iti pāṭhaḥ] sarpeṇa
tvacamiva paripakvāṃ saṃtyajya vigatajvareṇa śītalāntaḥkaraṇena
vinodādindrajālamiva jagadakhilamālokyate samyagdarśanavatā
asamyagadarśanavato hi paraṃ duḥkhamidam
]

`v 14 [
viṣamo hyatitarāṃ saṃsārarāgo `note[saṃsāroraga iti pāṭhaḥ] bhogīva
daśati asiriva cchinatti kunta iva vedhayati rajjurivāveṣṭayati pāvaka ieva
dahati rātririvāndhayati aśaṅkitaparipatitapuruṣānpāṣāṇa iva vivaśīkaroti
harati prajñāṃ nāśayati sthitiṃ pātayati mohāndhakūpe tṛṣṇā
jarjarīkaroti na tadasti kiṃcidduḥkhaṃ saṃsārī yanna prāpnoti
]

`v 15 [
p. 101)
duranteyaṃ kila viṣayaviṣūcikā yadi na cikitsyate tannitarāṃ
narakanagaranikaraphalānubandhinī tattatkaroti
]

`v 16 [
yatra śilāśitāsiśātaḥ pāta upalatāḍanamagnidāho
himāvaseko'ṅgāvakartanaṃ candanacarcātaruvanāni
ghuṇavṛttāntaḥpariveṣo'ṅgaparimārjanamanavaratānalavicalitasamaranār
ācanipāto nidāghavinodanaṃ dhārāgṛhasīkaravarṣaṇaṃ śiraśchedaḥ
sukhanidrāmūkīkaraṇamānanamudrābāndhuryaṃ mahānupacayaḥ
]

`v 17 [
tadevaṃvidhakaṣṭaceṣṭāsahasradāruṇe saṃsāracalayantre'smin rāghava
nāvahelanā kartavyā avaśyamevaṃ vicāraṇīyamevaṃ cāvaboddhavyaṃ yathā
kila śāstravicārācchreyo bhavatīti
]

`v 18 [
anyacca raghukulendo yadi caite mahāmunayo maharṣayaśca viprāśca
rājānaśca jñānakavacenāvaguṇṭhitaśarīrāste kathamaduḥkhakṣamā api
duḥkhakarīṃ tāṃ tāṃ vṛttipūrvikāṃ saṃsārakadarthanāmanubhavantaḥ
satatameva muditamanasastiṣṭhanti
]

`v 19 [
iha hi |
vikautukā vigatavikalpaviplavā
yathā sthitā hariharapadmajādayaḥ |
narottamāḥ samadhigatātmadīpakā-
stathā sthitā jagati viśuddhabuddhayaḥ
]

`v 20 [
parikṣīṇe mohe vigalati `note[vigalitaghane iti pāṭhaḥ] ghane jñānajalade
parijñāte tattve samadhigata ātmanyatitate |
vicāryāryaiḥ sārdhaṃ calitavapuṣo vai sadṛśato
dhiyā dṛṣṭe tattve ramaṇamaṭanaṃ jāgatamidam
]

`v 21 [
p. 102)
anyacca rāghava |
prasanne cittattve hṛdi śamabhave valgati pare
śamābhogībhūtāsvakhilakalanādṛṣṭiṣu puraḥ |
samaṃ yāti svāntaḥkaraṇaghaṭanāsvāditarasaṃ
dhiyā dṛṣṭe tattve ramaṇamaṭanaṃ jāgatamidam
]

`v 22 [
anyacca |
rathaḥ sthāṇurdehasturagaracanā cendriyagatiḥ
parispando vāto vahanakalitānandaviṣayaḥ |
paro'ṇurvā dehī jagati viharāmītyanaghayā
dhiyā dṛṣṭe tattve ramaṇamaṭanaṃ jāgatamidam
]