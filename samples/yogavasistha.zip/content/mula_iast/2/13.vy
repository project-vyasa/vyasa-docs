`v 1 [
trayodaśaḥ sargaḥ 13 |
śrīvasiṣṭha uvāca |
etāṃ dṛṣṭimavaṣṭabhya dṛṣṭātmānaḥ subuddhayaḥ |
vicarantīha saṃsāre mahānto'bhyuditā iva
]

`v 2 [
na śocanti na vāñchanti na yācante śubhāśubham |
sarvameva ca kurvanti na kurvantīha kiṃcana
]

`v 3 [
svacchamevāvatiṣṭhante svacchaṃ kurvanti yānti hi |
heyopādeyatāpakṣarahitāḥ svātmani sthitāḥ
]

`v 4 [
āyānti ca na cāyānti prayānti ca na yānti ca |
kurvantyapi na kurvanti na vadanti vadanti ca
]

`v 5 [
ye kecana samārambhā yāśca kāścana dṛṣṭayaḥ |
heyopādeyatastāstāḥ kṣīyante'dhigate pade
]

`v 6 [
parityaktasamastehaṃ manomadhuravṛttimat |
sarvataḥ sukhamabhyeti candrabimba iva sthitam
]

`v 7 [
api nirmananārambhamavyastākhilakautukam |
ātmanyeva na mātyantarindāviva rasāyanam
]

`v 8 [
na karotīndrajālāni nānudhāvati vāsanām |
bālacāpalamutsṛjya pūrvameva virājate
]

`v 9 [
evaṃvidhā hi vṛttaya ātmatattvāvalokanāllabhyante nānyathā
]

`v 10 [
tasmādvicāreṇātmaivānveṣṭavya upāsanīyo jñātavyo yāvajjīvaṃ puruṣeṇa
netaraditi
]

`v 11 [
svānubhūteśca śāstrasya guroścaivaikavākyatā |
yasyābhyāsena tenātmā santatenāvalokyate
]

`v 12 [
ekavākyatā ekārthaniṣṭhatā niścayaḥ yasyādhikāriṇaḥ śravaṇāderabhyāsena |
11 |
avahelitaśāstrārthairavajñātamahājanaiḥ |
kaṣṭāmapyāpadaṃ prāpto na mūḍhaiḥ samatāmiyāt
]

`v 13 [
p. 103)
na vyādhirna viṣaṃ nāpattathā nādhiśca bhūtale |
khedāya svaśarīrasthaṃ maurkhyamekaṃ yathā nṛṇām
]

`v 14 [
kiṃcitsaṃskṛtabuddhīnāṃ śrutaṃ śāstramidaṃ yathā |
maurkhyāpahaṃ tathā śāstramanyadasti na kiṃcana
]

`v 15 [
idaṃ śrāvyaṃ sukhakaraṃ yathā dṛṣṭāntasundaram |
aviruddhamaśeṣeṇa śāstraṃ vākyārthabandhunā
]

`v 16 [
āpado yā duruttārā yāśca tucchāḥ kuyonayaḥ |
tāstā maurkhyātprasūyante khadirādiva kaṇṭakāḥ
]

`v 17 [
varaṃ śarāvahastasya cāṇḍālāgāravīthiṣu |
bhikṣārthamaṭanaṃ rāma na maurkhyahatajīvitam
]

`v 18 [
varaṃ ghorāndhakūpeṣu koṭareṣveva bhūruhām |
andhakīṭatvamekānte na maurkhyamatiduḥkhadam
]

`v 19 [
imamālokamāsādya mokṣopāyamayaṃ janaḥ |
andhatāmeti na punaḥ kaścinmohatamasyapi
]

`v 20 [
tāvannayati saṃkocaṃ tṛṣṇā vai mānavāmbujam |
yāvadvivekasūryasya noditā vimalā prabhā
]

`v 21 [
saṃsāraduḥkhamokṣārthaṃ `note[mokṣorthamīdṛśaiḥ iti pāṭhaḥ]
mādṛśaiḥ saha bandhubhiḥ |
svarūpamātmano jñātvā guruśāstrapramāṇataḥ
]

`v 22 [
jīvanmuktāścarantīha yathā hariharādayaḥ |
yathā brahmarṣayaścānye tathā vihara rāghava
]

`v 23 [
anantānīha duḥkhāni sukhaṃ tṛṇalavopamam |
nātaḥ sukheṣu badhnīyāddṛṣṭiṃ duḥkhānubandhiṣu
]

`v 24 [
yadanantamanāyāsaṃ tatpadaṃ sārasiddhaye |
sādhanīyaṃ prayatnena puruṣeṇa vijānatā
]

`v 25 [
ta eva puruṣārthasya bhājanaṃ puruṣottamāḥ |
anuttamapadālambi mano yeṣāṃ gatajvaram
]

`v 26 [
saṃbhogāśanamātreṇa rājyādiṣu sukheṣu ye |
saṃtuṣṭā duṣṭamanaso viddhi tānandhadardurān
]

`v 27 [
ye śaṭheṣu duranteṣu duṣkṛtārambhaśāliṣu |
dvipatsu mitrarūpeṣu bhaktā vai bhogabhogiṣu
]

`v 28 [
te yānti durgamādurgaṃ duḥkhāduḥkhaṃ bhayādbhayam |
narakānnarakaṃ mūḍhā mohamantharabuddhayaḥ
]

`v 29 [
parasparavināśokteḥ śreyaḥstho na kadācana |
sukhaduḥkhadaśe rāma taḍitprasarabhaṅgure `note[taḍitprāsarabhaṅgure
iti pāṭhaḥ]
]

`v 30 [
ye viraktā mahātmānaḥ suviviktā bhavādṛśāḥ |
puruṣānviddhi tānvandyānbhogamokṣaikabhājanān
]

`v 31 [
vivekaṃ paramāśritya vairāgyābhyāsayogataḥ |
saṃsārasaritaṃ ghorābhimāmāpadamuttaret
]

`v 32 [
na svaptavyaṃ ca saṃsāramāyāsviha vijānata |
viṣamūrcchanasaṃmohadāyinīṣu vivekinā
]

`v 33 [
saṃsārabhimamāsādya yastiṣṭhatyavahelayā |
jvalitasya gṛhasyoccaiḥ śete tārṇasya saṃstare
]

`v 34 [
yatprāpya na nivartante yadāsādya na śocati |
tatpadaṃ śemuṣīlabhyamastyevātra na saṃśayaḥ
]

`v 35 [
nāsti cettadvicāreṇa doṣaḥ ko bhavatāṃ bhavet |
asti cettatsamuttīrṇā bhaviṣyatha bhavārṇavāt
]

`v 36 [
p. 104)
pravṛttiḥ puruṣasyeha mokṣopāyavicāraṇe |
yadā bhavatyāśu tadā mokṣabhāgī sa ucyate
]

`v 37 [
anapāyi nirāśaṅkaṃ svāsthyaṃ vigatavibhramam |
na vinā kevalībhāvādvidyate bhuvanatraye
]

`v 38 [
tatprāptāvuttamaprāptau na kleśa upajāyate |
na dhanānyupakurvanti na mitrāṇi na bāndhavāḥ
]

`v 39 [
na hastapādacalanaṃ na deśāntarasaṃgamaḥ |
na kāyakleśavaidhuryaṃ na tīrthāyatanāśrayāḥ
]

`v 40 [
puruṣārthaikasādhyena vāsanaikārthakarmaṇā |
kevalaṃ tanmanomātrajayenāsādyate padam
]

`v 41 [
vivekamātrasādhyaṃ tadvicāraikāntaniścayam |
tyajatā duḥkhajālāni nareṇaitadavāpyate
]

`v 42 [
sukhasevyāsanasthena tadvicārayatā svayam |
na śocyate padaṃ prāpya na sa bhūyo hi jāyate
]

`v 43 [
tatsamastasukhāsārasīmāntaṃ sādhavo viduḥ |
tadanuttamaniṣpandaṃ paramāhū rasāyanam
]

`v 44 [
kṣayitvātsarvabhāvānāṃ svargamānuṣyayordvayoḥ |
sukhaṃ nāstyeva salilaṃ mṛtatṛṣṇāsvivaitayoḥ
]

`v 45 [
ato manojayaścintyaḥ śamasaṃtoṣasādhanaḥ |
anantasamasaṃyogastasmādānanda āpyate
]

`v 46 [
tiṣṭhatā gacchatā caiva patatā bhramatā tathā |
rakṣasā dānavenāpi devena puruṣeṇa vā
]

`v 47 [
śārīrapariśramo manuṣyādhikāraniyamaśca nāstītyāha - tiṣṭhatetyādinā |
46 |
manaḥ praśamanodbhūtaṃ tatprāpyaṃ paramaṃ sukham |
vikāsiśamapuṣpasya vivekoccataroḥ phalam
]

`v 48 [
vyavahārapareṇāpi kāryavṛndamavindatā |
bhānunevāmbarasthena nojjhyate na ca vāñchayate
]

`v 49 [
nanu tatprāptamapi punarvyavahāraprasaktāvapaiṣyatītyāśaṅkyāha -
vyavahāreti | nojjhyate notsṛjyate pūrṇatvenāheyatvādata eva na vāñchayate | 48
|
manaḥpraśāntamatyacchaṃ viśrāntaṃ vigatabhramam |
anīhaṃ vigatābhīṣṭaṃ nābhivāñchati nojjhati
]

`v 50 [
mokṣadvāre dvārapālānimāñchṛṇu yathākramam |
yeṣāmekatamāsaktyā mokṣadvāraṃ praviśyate
]

`v 51 [
sukhadoṣadaśādīrghā saṃsāramarumaṇḍalī |
jantoḥ śītalatāmeti śīraraśmeḥ samaprabhā
]

`v 52 [
śamenāsādyate śreyaḥ śamo hi paramaṃ padam |
śamaḥ śivaḥ śamaḥ śāntiḥ śamo bhrāntinivāraṇam
]

`v 53 [
puṃsaḥ praśamatṛptasya śītalācchatarātmanaḥ |
śamabhūṣitacittasya śatrurapyeti mitratām
]

`v 54 [
p. 105)
śamacandramasā yeṣāmāśayaḥ samalaṃkṛtaṃ |
kṣīrodānāmivodeti teṣāṃ paramaśuddhatā
]

`v 55 [
hṛtkuśeśayakośeṣu yeṣāṃ śamakuśeśayam |
satāṃ vikasitaṃ te hi dvihṛtpadmāḥ samā hareḥ
]

`v 56 [
śamaśrīḥ śobhate yeṣāṃ mukhendāvakalaṅkite |
te kulīnendavo vandyāḥ saundaryavijitendriyāḥ
]

`v 57 [
trailokyodaravartinyo nānandāya tathā śriyaḥ |
sāmrājyasaṃpatpratimā yathā `note[yathāśrama iti pāṭhaḥ]
śamavibhūtayaḥ
]

`v 58 [
yāni duḥkhāni yā tṛṣṇā duḥsahā ye durādhayaḥ |
tatsarvaṃ śāntacetaḥsu tamo'rkeṣviva naśyati
]

`v 59 [
mano hi sarvabhūtānāṃ prasādamadhigacchati `note[manugacchati iti
pāṭhaḥ] |
na tathendoryathā śānte jane janitakautukam
]

`v 60 [
śamaśālini sauhārdavati sarveṣu jantuṣu |
sujane paramaṃ tattvaṃ svayameva prasīdati
]

`v 61 [
mātarīva paraṃ yānti viṣamāṇi mṛdūni ca |
viśvāsamiha bhūtāni sarvāṇi śamaśālini
]

`v 62 [
na rasāyanapānena na lakṣmyāliṅganena ca |
tathā sukhamavāpnoti śamenāntaryathā manaḥ
]

`v 63 [
sarvādhivyādhicalitaṃ `note[vyādhivalitaṃ] krāntaṃ tṛṣṇāvaratrayā |
manaḥ śamāmṛtāsekaiḥ samāśvāsaya rāghava
]

`v 64 [
yatkaroṣi yadaśnāsi śamaśītalayā dhiyā |
tatrātisvadate svādu `note[sādhu iti pāṭhaḥ] netarattāta mānase
]

`v 65 [
śamāmṛtarasācchannaṃ mano yāmeti nirvṛtim |
chinnānyapi tayāṅgāni manye rohanti rāghava
]

`v 66 [
na piśācā na rakṣāṃsi na daityā na ca śatravaḥ |
na ca vyāghrabhujaṅgā vā dviṣanti śamaśālinam
]

`v 67 [
susaṃnaddhasamastāṅgaṃ praśamāmṛtavarmaṇā |
vedhayanti na duḥkhāni śarā vajraśilāmiva
]

`v 68 [
na tathā śobhate rājā apyantaḥpurasaṃsthitaḥ |
samayā svacchayā buddhyā yathopaśamaśīlayā
]

`v 69 [
prāṇātpriyataraṃ dṛṣṭvā tuṣṭimeti na vai janaḥ |
yāmāyāti janaḥ śāntimavalokya śamāśayam
]

`v 70 [
samayā śamaśālinyā vṛttyā yaḥ sādhu vartate |
abhinanditayā loke jīvatīha sa netaraḥ
]

`v 71 [
anuddhatamanāḥ śāntaḥ sādhuḥ karma karoti yat |
tatsarvamabhinandanti tasyemā bhūtajātayaḥ
]

`v 72 [
śrutvā spṛṣṭvā ca dṛṣṭvā ca bhuktvā ghrātvā `note[snātvā iti
pāṭhaḥ] śubhāśubham |
na hṛṣyati glāyati yaḥ sa śānta iti kathyate
]

`v 73 [
yaḥ samaḥ sarvabhūteṣu bhāvi kāṅkṣati nojjhati |
jitvendriyāṇi yatnena sa śānta iti kathyate
]

`v 74 [
spṛṣṭvā'vadātayā buddhyā yathaivāntastathā bahiḥ |
dṛśyante yatra kāryāṇi sa śānta iti kathyate
]

`v 75 [
tuṣārakarabimbābhaṃ mano yasya nirākulam |
maraṇotsavayuddheṣu sa śānta iti kathyate
]

`v 76 [
sthito'pi na sthita iva na hṛṣyati na kupyati |
yaḥ suṣuptasamaḥ svasthaḥ sa śānta iti kathyate
]

`v 77 [
amṛtasyandasubhagā yasya sarvajanaṃ prati |
dṛṣṭiḥ prasarati prītā sa śānta iti kathyate
]

`v 78 [
p. 106)
yo'ntaḥ śītalatāṃ yāto yo bhāveṣu na majjati |
vyavahārī na saṃmūḍhaḥ sa śānta iti kathyate
]

`v 79 [
apyāpatsu durantāsu kalpānteṣu mahatsvapi |
tucche'haṃ na mano yasya sa śānta iti kathyate
]

`v 80 [
ākāśasadṛśī yasya puṃsaḥ saṃvyavahāriṇaḥ |
kalaṅkameti na matiḥ sa śānta iti kathyate
]

`v 81 [
tapasviṣu bahujñeṣu yājakeṣu nṛpeṣu ca |
balavatsu guṇāḍhyeṣu śamavāneva rājate
]

`v 82 [
śamasaṃsaktamanasāṃ mahatāṃ guṇaśālinām |
udeti nirvṛtiścittājjyotsneva sitarociṣaḥ
]

`v 83 [
sīmānto `note[sīmantaḥ iti pāṭhaḥ] guṇapūgānāṃ
pauruṣaikāntabhūṣaṇam |
saṃkaṭeṣu bhayasthāne śamaḥ śrīmānvirājate
]

`v 84 [
śamamamṛtamahāryamāryaguptaṃ
paramavalambya paraṃ padaṃ prayātāḥ |
raghutanaya yathā mahānubhāvāḥ
kramamanupālaya siddhaye tameva
]