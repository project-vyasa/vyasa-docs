`v 1 [
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
Vasudeva ḻaxmana ṣharma Pansikar
1918
mumukṣuvyavahāraprakaraṇaṃ dvitīyam |
prathamaḥ sargaḥ 1
vālmīkiruvāca |
iti nādena mahatā vacasyukte sabhāgataiḥ |
rāmamagragataṃ prītyā viśvāmitro'bhyabhāṣata
]

`v 2 [
na rāghava tavāstyanyajjñeyaṃ jñānavatāṃ vara |
svayaiva sūkṣmayā buddhyā sarvaṃ vijñātavānasi
]

`v 3 [
jñeyamajñātatvādavaśyajñātavyam | sarvaṃ heyopādeyarahasyam | tathāca
sārāsāravivecanaparayā buddhyā paramārthasārabhūtamakhaṇḍādvayacin##-
kevalaṃ mārjanāmātraṃ manāgevopayujyate |
svabhāvavimale nityaṃ svabuddhimukure tava
]

`v 4 [
bhagavadvyāsapūtrasya śukasyeva matistava |
viśrāntimātramevāntarjñātajñeyāpyapekṣate
]

`v 5 [
śrīrāma uvāca |
bhagavadyāsaputrasya śukasya bhagavankatham |
jñeye'pyādau na viśrāntaṃ viśrāntaṃ ca dhiyā punaḥ
]

`v 6 [
jñeye svenaiva vicāreṇa jñātuṃ śakye'pi tattve | dhiyā gurūpadeśasaṃvā##-
viśvāmitra uvāca |
ātmodantasamaṃ rāma kathyamānamidaṃ mayā |
śṛṇu vyāsātmajodantaṃ janmanāmantakāraṇam
]

`v 7 [
yo'yamañjanaśailābho niviṣṭo hemaviṣṭare |
pārśve tava piturvyāso bhagavānbhāskaradyutiḥ
]

`v 8 [
asyābhūdinduvadanastanayo nayakovidaḥ |
śuko nāma mahāprājño yajño mūrtyeva susthitaḥ
]

`v 9 [
pravicārayato lokayātrāmalamimāṃ hṛdi |
taveva kila tasyāpi viveka udabhūdayam
]

`v 10 [
tenāsau svavivekena svayameva mahāmanāḥ |
pravicārya ciraṃ cāru yatsatyaṃ tadavāptavān
]

`v 11 [
svayaṃ prāpte pare vastunyaviśrāntamanāḥ sthitaḥ |
idaṃ vastviti viśvāsaṃ nāsāvātmanyupāyayau
]

`v 12 [
kevalaṃ virarāmāsya ceto vigatacāpalam |
bhogebhyo bhūribhaṅgebhyo dhārābhya iva cātakaḥ
]

`v 13 [
virarāma uparatam | viraktamiti yāvat | bhūribhaṅgebhyo bahutaravināśaduḥkha##-
ekadā so'malaprajño merāvekāntasusthitam |
papraccha pitaraṃ bhaktyā kṛṣṇadvaipāyanaṃ munim
]

`v 14 [
saṃsārāḍambaramidaṃ kathamabhyutthitaṃ mune |
kathaṃ ca praśamaṃ yāti kiyatkasya kadeti vā
]

`v 15 [
iti pṛṣṭena muninā vyāsenākhilamātmaje |
yathāvadamalaṃ proktaṃ vaktavyaṃ viditātmanā
]

`v 16 [
ā'jñāsiṣaṃ pūrvametadahamityatha tatpituḥ |
sa śukaḥ śubhayā buddhyā na vākyaṃ bahvamanyata
]

`v 17 [
vyāso'pi bhagavānbuddhā putrābhiprāyamīdṛśam |
pratyuvāca punaḥ putraṃ nāhaṃ jānāmi tattvataḥ
]

`v 18 [
janako nāma bhūpālo vidyate vasudhātale |
yathāvadvettyasau vedyaṃ tasmātsarvamavāpsyasi
]

`v 19 [
pitretyukte śukaḥ prāyātsumerorvasudhātale |
videhanagarīṃ prāpa janakenābhipālitām
]

`v 20 [
āvedito'sau yāṣṭīkairjanakāya mahātmane |
dvāri vyāsasuto rājañśuko'tra sthitavāniti
]

`v 21 [
jijñāsārthaṃ (śukasyājñāyāstāṃ)
śukasyāsāvāstāmevetyavajñayā |
uktvā babhūva janakastūṣṇīṃ sapta dinānyatha
]

`v 22 [
tataḥ praveśayāmāsa janakaḥ śukamaṅgaṇam |
tatrāhāni sa saptaiva tathaivāvasadunmanāḥ
]

`v 23 [
atha praveśayāmāsa janako'ntaḥpuraṃ śukam |
rājā na dṛśyate tāvaditi sapta dināni ca
]

`v 24 [
tatronmadābhiḥ kāntābhirbhojanairbhogasaṃcayaiḥ |
janako lālayāmāsa śukaṃ śaśisamānanam
]

`v 25 [
24 ||
te bhogāstāni duḥkhāni vāsaputrasya tanmanaḥ |
nājahrurmandapavanā baddhapīṭhamivācalam
]

`v 26 [
kevalaṃ susamaḥ svastho maunī muditamānasaḥ |
atiṣṭhatsa śukastatra saṃpūrṇa iva candramāḥ
]

`v 27 [
kevalamityavadhāraṇe | bhogānādarayoḥ susamo'taeva svasthaḥ | tatra hetuḥ##-
parijñātasvabhāvaṃ taṃ śukaṃ sa janako nṛpaḥ |
ānītaṃ muditātmānamavalokya nanāma ha
]

`v 28 [
itthaṃ parīkṣaṇena parijñātastattvadarśanaparyantapratiṣṭhito vicāravairādyādi##-
niḥśeṣitajagatkārya prāptākhilamanoratha |
kimīpsitaṃ tavetyāśu kṛtasvāgatamāha tam
]

`v 29 [
niḥśeṣitāni niravaśeṣaṃ kṛtāni jagati prasiddhāni kāryāṇyavaśyakartavyāni
paramapuruṣārthasādhanāni yena tathāvidha | he kṛtakṛtyetyarthaḥ |
sarvasukhala-vānāmātmasukhe'ntarbhāvāttatprāptyaiva prāptākhilamanoratha ||
28 ||
śrīśuka uvāca |
saṃsārāḍambaramidaṃ kathamabhyutthitaṃ guro |
kathaṃ praśamamāyāti yathāvatkathayāśu me
]

`v 30 [
viśvāmitra uvāca |
janakeneti pṛṣṭena śukasya kathitaṃ tadā |
tadeva yatpurā proktaṃ tasya pitrā mahātmanā
]

`v 31 [
śrīśuka uvāca |
svayameva mayā pūrvametajjñātaṃ vivekataḥ |
etadeva ca pṛṣṭena pitrā me samudāhṛtam
]

`v 32 [
bhavatāpyeṣa evārthaḥ kathito vāgvidāṃ vara |
eṣa eva ca vākyārthaḥ śāstreṣu paridṛśyate
]

`v 33 [
vyakyārthaḥ sarvopaniṣadgatamahāvākyānāmarthaḥ | tattātparyanirṇāyaka##-
yathāyaṃ svavikalpotthaḥ svavikalpaparikṣayāt |
kṣīyate dagdhasaṃsāro niḥsāra iti niścayaḥ
]

`v 34 [
tatkimetanmahābāho satyaṃ brūhi mamācalam |
tvatto viśrāntimāpnomi cetasā bhramatā jagat
]

`v 35 [
janaka uvāca |
nātaḥ parataraḥ kaścinniścayo'styaparo mune |
svayameva tvayā jñātaṃ gurutaśca punaḥ śrutam
]

`v 36 [
avicchinnacidātmaikaḥ pumānastīha netarat |
svasaṃkalpavaśādbaddho niḥsaṃkalpaśca mucyate
]

`v 37 [
tena tvayā sphuṭaṃ jñātaṃ jñeyaṃ yasya mahātmanaḥ |
bhogebhyo viratirjātā (dṛśyādvā) rḍśyātprāksakalādiha
]

`v 38 [
tava bāla mahāvīra matirviratimāgatā |
bhogebhyo dīrgharogebhyaḥ kimanyacchrotumicchasi
]

`v 39 [
na tathā pūrṇatā jātā sarvajñānamahānidheḥ |
tiṣṭhatastapasi sphāre pitustava yathā tava
]

`v 40 [
vyāsādadhika evāhaṃ vyāsaśiṣyo'si tatsutaḥ |
bhogecchātānaveneha matto'pyatyadhiko bhavān
]

`v 41 [
prāptaṃ prāptavyamakhilaṃ bhavatā pūrṇacetasā |
na dṛśye patasi brahmanmuktastvaṃ bhrāntimutsṛja
]

`v 42 [
anuśiṣṭaḥ sa ityevaṃ janakena mahātmanā |
atiṣṭhatsa śukastūṣṇīṃ svacche paramavastuni
]

`v 43 [
vītaśokabhayāyāso nirīhaścchinnasaṃśayaḥ |
jagāma śikharaṃ meroḥ samādhyarthamaninditam
]

`v 44 [
tatra varṣasahasrāṇi nirvikalpasamādhinā |
daśa sthitvā śaśāmāsāvātmanyasnehadīpavat
]

`v 45 [
vyapagatakalanākalaṅkaśuddhaḥ svayamamalātmani pāvane pade'sau |
salilakaṇa evāmbudhau mahātmā vigalitavāsanamekatāṃ jagāma
]