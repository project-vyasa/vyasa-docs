`v 1 [
śrīḥ | yataḥ sarvāṇi bhūtāni pratibhānti sthitāni ca |
yatraivopaśamaṃ yānti tasmai satyātmane namaḥ
]

`v 2 [
jñātā jñānaṃ tathā jñeyaṃ draṣṭā darśanadṛśyabhūḥ |
kartā hetuḥ kriyā yasmāttasmai jñaptyātmane namaḥ
]

`v 3 [
sphuranti sīkarā yasmādānandasyāmbare'vanau |
sarveṣāṃ jīvanaṃ tasmai brahmānandātmane namaḥ
]

`v 4 [
sūtīkṣṇo brāhmaṇaḥ kaścitsaṃśayākṛṣṭamānasaḥ |
agasterāśramaṃ gatvā muniṃ papraccha sādaram
]

`v 5 [
atrārṣadaivasaṃvādaḥ saṃpradāyaviśuddhaye |
rāmājñānanimittaṃ cāpyupoddhātāya varṇyate |
itthaṃ maṅgalaviṣayādipradarśanamukhena śāstrārthaṃ suprabodhāya
saṃkṣepataḥ pradarśya sahasādhanopapattyādibhirvistareṇa tamevārthaṃ
vyutpādayituṃ śāstramārabhamāṇastasmin śrotṝṇāṃ viśvāsadārḍhyāya
bahutarabrahmavinmūrdhanyamaharṣijuṣṭabrahmādisaṃpradāyaprāpta##-
ityādinā | sutīkṣṇaḥ tapaḥkarmopāsanāśodhitatvācchobhanā durūhārtha##-
brāhmaṇagrahaṇaṃ brāhmaṇānāmeva brahmavidyāyāṃ mukhādhikāra iti
dyotanārtham | saṃśayena jijñāsāyai ākṛṣṭaṃ mānasaṃ yasyeti
jijñāsurityarthaḥ | sādaraṃ vidhyuktasamitpāṇitvapraṇipātaprapattyādyā##-
sutīkṣṇa uvāca |
bhagavandharmatattvajña sarvaśāstraviniścita |
saṃśayo'sti mahānekastvametaṃ kṛpayā vada
]

`v 6 [
dharma tattvaṃ ca jānāsīti dharmatattvajña | sarveṣu śāstreṣu viśiṣṭaṃ niścitaṃ
niścayo yasya sa tathā | parasparaviruddhārthānekaśrutismṛtivādi##-
mokṣasya kāraṇaṃ karma jñānaṃ vā mokṣasādhanam |
ubhayaṃ vā viniścitya ekaṃ kathaya kāraṇam
]

`v 7 [
agastiruvāca |
ubhābhyāmeva pakṣābhyāṃ yathā khe pakṣiṇāṃ gatiḥ |
tathaiva jñānakarmabhyāṃ jāyate paramaṃ padam
]

`v 8 [
kevalātkarmaṇo jñānānnahi mokṣo'bhijāyate |
kiṃtubhābhyāṃ bhavenmokṣaḥ sādhanaṃ tūbhayaṃ viduḥ
]

`v 9 [
asminnarthe purāvṛttamitihāsaṃ vadāmi te |
kāruṇyākhyaḥ purā kaścidbrāhmaṇo'dhītavedakaḥ
]

`v 10 [
agniveśyasya putro'bhūdvedavedāṅgapāragaḥ |
guroradhītavidyaḥ sannājagāma gṛhaṃ prati
]

`v 11 [
tasthāvakarmakṛttūṣṇīṃ saṃśayāno gṛhe tadā |
agniveśyo vilokyātha putraṃ karmavivarjitam
]

`v 12 [
agniveśya uvāca |
kimetatputra kuruṣe pālanaṃ na svakarmaṇaḥ
]

`v 13 [
akarmanirataḥ siddhiṃ kathaṃ prāpsyasi tadvada |
karmaṇo'smānnivṛtteḥ kiṃ kāraṇaṃ tannivedyatām
]

`v 14 [
kāruṇya uvāca |
yāvajjivamagnihotraṃ nityaṃ saṃdhyāmupāsayet |
pravṛttirūpo dharmo'yaṃ śrutyā smṛtyā ca coditaḥ
]

`v 15 [
na dhanena bhavenmokṣaḥ karmaṇā prajayā na vā |
tyāgamātreṇa kiṃtveke yatayo'śnanti cāmṛtam
]

`v 16 [
iti śrutyordvayormadhye kiṃ kartavyaṃ mayā guro |
iti saṃdigdhatāṃ gatvā tūṣṇīṃbhūto'smi karmaṇi
]

`v 17 [
agastiruvāca |
ityuktvā tāta vipro'sau kāruṇyo maunamāgataḥ |
tathāvidhaṃ sutaṃ dṛṣṭvā punaḥ prāha guruḥ sutam
]

`v 18 [
agniveśya uvāca |
śṛṇu putra kathāmekāṃ tadarthaṃ hṛdaye'khilam |
matto'vadhārya putra tvaṃ yathecchasi tathā kuru
]

`v 19 [
surucirnāma kācitstrī apsarogaṇauttamā |
upaviṣṭā himavataḥ śikhare śikhisaṃvṛte
]

`v 20 [
ramante kāmasaṃtaptāḥ kinnaryo yatra kinnaraiḥ |
svardhunyodhena saṃsṛṣṭe mahāghaughavināśinā
]

`v 21 [
dūtamindrasya gacchantamantarikṣe dadarśa sā |
tamuvāca mahābhāgā suruciścāpsarovarā
]

`v 22 [
jñānopadeśaphalabhāginītvānmahābhāgā | cakāro na kevalaṃ nāmnaiva kiṃtu
śobhanāyāṃ brahmavidyāyāṃ ruciḥ saṃjātā asyā ityarthago'pi suruciriti
samuccayārthaḥ | divyadṛśā dūtabrahmavittvaparijñānasamartha##-
suruciruvāca |
devadūta mahābhāga kuta āgamyate tvayā |
adhunā kutra gantāsi tatsarvaṃ kṛpayā vada
]

`v 23 [
devadūta uvāca |
sādhu pṛṣṭaṃ tvayā subhru yathāvatkathayāmi te |
ariṣṭanemī rājarṣirdattvā rājyaṃ sutāya vai
]

`v 24 [
vītarāgah sa dharmātmā niryayau tapase vanam |
tapaścaratyasau rājā parvate gandhamādane
]

`v 25 [
kāryaṃ kṛtvā mayā tatra tata āgamyate'dhunā |
gantāsmi pārśve śakrasya taṃ vṛttāntaṃ niveditum
]

`v 26 [
apsarā uvāca |
vṛttāntaḥ ko'bhavattatra kathayasva mama prabho |
praṣṭukāmā vinītāsmi nodvegaṃ kartumarhasi
]

`v 27 [
śṛṇu bhadre yathāvṛttaṃ vistareṇa vadāmi te |
tasminrājñi vane tatra tapaścarati dustaram
]

`v 28 [
ityahaṃ devarājena subhrūrājñāpitastadā |
dūtaṃ tvaṃ tatra gacchāśu gṛhītvedaṃ vimānakam
]

`v 29 [
apsarogaṇasaṃyuktaṃ nānāvāditraśobhitam |
gandharvasiddhayakṣaiśca kinnarādyaiśca śobhitam
]

`v 30 [
tālaveṇumṛdaṅgādi parvate gandhamādane |
nānāvṛkṣasamākīrṇe gatvā tasmingirau śubhe
]

`v 31 [
ariṣṭanemi rājānaṃ dūtāropya vimānake |
ānaya svargabhogāya nagarīmamarāvatīm
]

`v 32 [
dūta uvāca |
ityājñāṃ prāpya śakrasya gṛhītvā tadvimānakam |
sarvopaskarasaṃyuktaṃ tasminnadrāvahaṃ yayau
]

`v 33 [
āgatya parvate tasminrājño gatvāśhramaṃ mayā |
niveditā mahendrasya sarvājñā'riṣṭanemaye
]

`v 34 [
iti madvacana. m śrutvā saṃśayāno'vadacchubhe |
rājovāca |
praṣṭumicchāmi dūta tvāṃ tanme tvaṃ vaktumarhasi
]

`v 35 [
guṇā doṣāśca ke tatra svarge vada mamāgrataḥ |
jñātvā sthitiṃ tu tatratyāṃ kariṣye'haṃ yathāruci
]

`v 36 [
dūta uvāca |
svarge puṇyasya sāmagryā bhujyate paramaṃ sukham |
uttamena tu puṇyena prāpnoti svargamuttamam
]

`v 37 [
madhyamena tathā madhyaḥ svargo bhavati nānyathā |
kaniṣṭhena tu puṇyena svargo bhavati tādṛśaḥ
]

`v 38 [
parotkarṣāsahiṣṇutvaṃ spardhā caiva samaiśca taiḥ |
kaniṣṭheṣu ca saṃtoṣo yāvatpuṇyakṣayo bhavet
]

`v 39 [
kṣīṇe puṇye viśantyetaṃ martyalokaṃ ca mānavāḥ |
ityādiguṇadoṣāśca svarge rājannavasthitāḥ
]

`v 40 [
iti śrutvā vaco bhadre sa rājā pratyabhāṣata |
rājovāca |
necchāmi devadutāhaṃ svargamīdṛgvidhaṃ phalam
]

`v 41 [
tatḥ paraṃ `note[mahograṃ tu] mahograṃ ca tapaḥ kṛtvā kalevaram |
tyakṣyāmyahamaśuddhaṃ hi jīrṇāṃ tvacamivoragaḥ
]

`v 42 [
pāpānāṃ tapasā niḥśeṣaṃ kṣapaṇāt sukṛtānāmasati rāge janmā##-
devadūtaṃ vimānedaṃ gṛhītvā tvaṃ yathāgataḥ |
tathā gaccha mahendrasya saṃnidhau tvaṃ namo'stu te
]

`v 43 [
devadūta uvāca |
ityukto gato bhadre śakrasyāgre niveditum |
yathāvṛttaṃ nivedyātha mahadāścaryatāṃ gataḥ
]

`v 44 [
punaḥ prāha mahendro māṃ ślakṣṇaṃ madhurayā girā |
indra uvāca |
dūta gaccha punastatra taṃ rājānaṃ nayāśramam
]

`v 45 [
vālmīkerjñātatattvasya svabodhārthaṃ virāgiṇam |
saṃdeśaṃ mama vālmīkermaharṣestvaṃ nivedaya
]

`v 46 [
aharṣe tvaṃ vinītāya rājñe'smai vītarāgiṇe |
nasvargamiccyate tattvaṃ prabodhaya mahāmune
]

`v 47 [
tena saṃsāraduḥkhārto mokṣameṣyati ca kramāt |
ityuktvā devarājena preṣito'haṃ tadantike
]

`v 48 [
mayāgatya punastatra rājā valmīkajanmane |
nivedito mahendrasya rājñā mokṣasya sādhanam
]

`v 49 [
tato valmīkajanmāsau rājānaṃ samapṛcchata |
anāmayamatiprītyā kuśalapraśnavārtayā
]

`v 50 [
rājovāca |
bhagavandharmatattvajña jñātajñeya vidāṃvara |
kṛtārtho'haṃ bhavaddṛṣṭyā tadeva kuśalaṃ mama
]

`v 51 [
bhagavanpraṣṭumicchāmi tadavighnena me vada |
saṃsārabandhaduḥkhārteḥ kathaṃ muñcāmi tadvada
]

`v 52 [
vālmīkiruvāca |
śṛṇu rājanpravakṣyāmi rāmāyaṇamakhaṇḍitam |
śrutvāvadhārya yatnena jīvanmukto bhaviṣyasi
]

`v 53 [
vasiṣṭharāmasaṃvādaṃ mokṣopāyakathāṃ śubhām |
jñātasvabhāvo rājendra vadāmi śrūyatāṃ budha
]

`v 54 [
rājovāca |
ko rāmaḥ kīdṛśaḥ kasya baddho vā mukta eva vā |
etanme niścitaṃ brūhi jñānaṃ tattvavidāṃ vara
]

`v 55 [
vālmīkiruvāca |
śāpavyājavaśādeva rājaveṣadharo hariḥ |
āhṛtājñānasaṃpannaḥ kiṃcijjño'sau bhavatprabhuḥ
]

`v 57 [
rājovāca |
cidānandasvarūpe hi rāme caitanyavigrahe |
śāpasya kāraṇaṃ brūhi kaḥ `note[kaḥ śaśāpeti] śaptā ceti me vada |
56 |
maharṣibhiraparādhino hi śapyante aparādho hyapūrṇakāmasyājñasya syāt
nacānāvṛtacidānanda svarūpatvādathābhūtasya rāmasya tatsaṃbhavaḥ
śāpādeva taduktau tvanonyāśraya ityabhipretyāha - cidānandeti |
paramārtha-taścidabhinnānandasvarūpe `note[ścidānandasvarūpe] |
vyavahāre'pi caitanyameva bhaktānukampayā vigrahātmanā pariṇataṃ yasa tasmin |
56 |
vālmīkiruvāca |
sanatkumāro niṣkāma avasadbrahmasadmani |
vaikuṇṭhādāgato viṣṇustrailokyādhipatiḥ prabhuḥ
]

`v 58 [
brahmaṇā pūjitastatra satyalokanivāsibhiḥ |
vinā kumāraṃ taṃ dṛṣṭvā hyuvāca prabhurīśvaraḥ
]

`v 59 [
sanatkumāra stabdho'si niṣkāmo garvaceṣṭayā |
atastvaṃ bhava kāmārtaḥ śarajanmeti nāmataḥ
]

`v 60 [
tenāpi śāpito viṣṇuḥ sarvajñatvaṃ tavāsti yat |
kiṃcitkālaṃ hi tyaktvā tvamajñānī bhaviṣyasi
]

`v 61 [
bhṛgurbhāryāṃ hatāṃ dṛṣṭvā hyuvāca krodhamūrcchitaḥ |
viṣṇo tavāpi bhāryāyā viyogo hi bhaviṣyati
]

`v 62 [
vṛndayā śāpito viṣṇuśchalanaṃ yattvayā kṛtam |
atastvaṃ strīviyogaṃ ti vacanānmama yāsyasy
]

`v 63 [
vṛndayā jalandhara bhāryayā | chalanaṃ pativeṣeṇa mohayitvā
pātivṛtyabhaṅga-rūpaṃ vañcanam | śāpitaḥ śaptaḥ | adhyāropita##-
bhāryā hi devadattasya payoṣṇītīrasaṃsthitā |
nṛsiṃhaveṣadhṛgviṣṇuṃ dṛṣṭvā pañcatvamāgatā
]

`v 64 [
tena śapto hi hṛharirduḥkhārtaḥ strīviyogataḥ |
tavāpi bhāryayā sārdhaṃ viyogo hi bhaviṣyati
]

`v 65 [
duḥkhairduḥkhasādhyaiḥ sukṛtaiḥ ṛtaḥ sākṣātkṛto'pi nṛharistena śaptaḥ |
64 |
bhṛguṇaivaṃ kumāreṇa śāpito devaśarmaṇā |
vṛndayā śāpito viṣṇustena mānuṣyatāṃ gataḥ
]

`v 66 [
etatte kathitaṃ sarvaṃ śāpavyājasya kāraṇam |
idānīṃ vacmi tatsarvaṃ sāvadhānamatiḥ śṛṇu
]