`v 1 [
pañcamaḥ sargaḥ 5
vālmīkiruvāca |
athonaṣoḍaśe varṣe vartamāne raghūdvahe |
rāmānuyāyini tathā śatrughne lakṣmaṇe'pi ca
]

`v 2 [
bharate saṃsthite nityaṃ mātāmahagṛhe sukham |
pālayatyavaniṃ rājñi yathāvadakhilāmimām
]

`v 3 [
janyatrārthaṃ ca putrāṇāṃ pratyahaṃ saha mantribhiḥ |
kṛtamantre mahāprājñe tajjñe daśarathe nṛpe
]

`v 4 [
kṛtāyāṃ tīrthayātrāyāṃ rāmo nijagṛhe sthitaḥ |
jagāmānudinaṃ kārśyaṃ śaradīvāmalaṃ saraḥ
]

`v 5 [
kumārasya viśālākṣaṃ pāṇḍutāṃ mukhamādade |
pāpaphūlladalaṃ śuklaṃ sālimālamivāmbujam
]

`v 6 [
kapolatalasaṃlīnapāṇiḥ padmāsanasthitaḥ |
cintāparavaśastūṣṇīmavyāpāro babhūva ha
]

`v 7 [
kṛśāṅgaścintayā yuktaḥ khedī paramadurmanāḥ |
novāca kasyacitkiṃcillipikarmārpitopamaḥ
]

`v 8 [
khedātparijanenāsau prārthyamānaḥ punaḥ punaḥ |
cakārāhnikamācāraṃ parimlānamukhāmbujaḥ
]

`v 9 [
evaṃguṇaviśiṣṭaṃ taṃ rāmaṃ guṇagaṇākaram |
ālokya bhrātarāvasya tāmevāyayaturdaśām `note[tāmevāvāpatuḥ]
]

`v 10 [
guṇagaṇākaraṃ taṃ rāmadevaṃ pūrvoktacintādibhirguṇairviśeṣanairviśiṣṭa##-
tathā teṣu tanūjeṣu khedavatsu kṛśeṣu ca |
sapatnīko mahīpālaścintāvivaśatāṃ yayau
]

`v 11 [
kā te putra ghanā cintetyevaṃ rāmaṃ punaḥ punaḥ |
apṛcchatsnigdhayā vācā naivākathayadasya saḥ
]

`v 12 [
na kiṃcittāta me duḥkhamityuktvā pituraṅkagaḥ |
rāmo rājīvapatrākṣastūṣṇīmeva sma tiṣṭhati
]

`v 13 [
tato daśaratho rājā rāmaḥ kiṃ khedavāniti |
apṛcchatsarvakāryajñaṃ vasiṣṭhaṃ vadatāṃ varam
]

`v 14 [
ityuktaścintayitvā sa vasiṣṭhamuninā nṛpaḥ |
astyatra kāraṇaṃ śrīmanmā rājanduḥkhamastu te
]

`v 15 [
iti pṛṣṭena vasiṣṭhamuninā sa nṛpa iti evaṃ prakāreṇa uktaḥ | tadevāha -
astyatretyādinārdhenottaraślokasahitena | rāmacintāyāḥ śubhodarkatva##-
kopaṃ viṣādakalanāṃ vitataṃ ca harṣaṃ
nālpena kāraṇavaśena vahanti santaḥ |
sargeṇa saṃhṛtijavena vinā jagatyāṃ
bhūtāni bhūpa na mahānti vikāravanti
]