`v 1 [
tṛtīya sargaḥ 3
bharadvāja uvāca |
jīvanmuktasthitiṃ brahmankṛtvā rāghavamāditaḥ |
kramātkathaya me nityaṃ bhaviṣyāmi sukhī yathā
]

`v 2 [
śrīvālmīkiruvāca |
bhramasya jāgatasyāsya jātasyākāśavarṇavat |
apunaḥsmaraṇaṃ manye sādho vismaranaṃ varam
]

`v 3 [
dṛśyātyantābhāvabodhaṃ vinā tannānubhūyate |
kadācitkenacinnāma svabodho'nviṣyatāmataḥ
]

`v 4 [
manye ityanena tayoḥ svānubhavasiddhatvaṃ darśitam | tarhyasmābhistatkuto
nānubhūyate tatrāha - dṛśyeti | dṛśyasyātyantābhāvabodho bādhastvaṃ
vinā | tat uktaṃ lakṣaṇaṃ svarūpaṃ ca | ananubhavasya kālato deśataśca
vyāpakatva-pradarśanāya kadācitkenaciditi | dṛśyabādhastarhi kena hetunā
tamāha - svabodha iti |
sarvajagadadhiṣṭānapratyagabhinnātmatattvasākṣātkārādeva sa ityatastatsā##-
sa ceha saṃbhavatyeva tadartha midamātatam |
śāstramākarṇayasi cettattvamāpsyasi nānyathā
]

`v 5 [
jagadbhramo'yaṃ dṛśyo'pi nāstyevetyanubhūyate |
varṇo vyomna ivākhedādvicāreṇāmunā'nagha
]

`v 6 [
dṛśyaṃ nāstīti bodhena manaso dṛśyamārjanam |
saṃpannaṃ cettadutpannā parā nirvāṇanirvṛtiḥ
]

`v 7 [
anyathā śāstragarteṣu luṭhatāṃ bhavatāmiha |
bhavatyakṛtrimājñānāṃ kalpairapi na nirvṛtiḥ
]

`v 8 [
aśeṣeṇa parityāgo vāsanānāṃ ya uttamaḥ |
mokṣa ityucyate brahmansa eva vimalakramaḥ
]

`v 9 [
kṣīṇāyāṃ vāsanāyāṃ tu ceto galati satvaram |
kṣīṇāyāṃ śītasaṃtatyāṃ brahmanhimakaṇo yathā
]

`v 10 [
ayaṃ vāsanayā deho dhriyate bhūtapañjaraḥ |
tanunāntarniviṣṭena muktaughastantunā yathā
]

`v 11 [
vāsanā dvividhā proktā śuddhā ca malinā tathā |
malinā janmano hetuḥ śuddhā janmavināśinī
]

`v 12 [
ajñānasughanākārā ghanāhaṃkāraśālinī |
punarjanmakarī proktā malinā vāsanā budhaiḥ
]

`v 13 [
punarjanmāṅkuraṃ tyaktvāsthitā saṃbhṛsṭabījavat |
dehārthaṃ dhriyate `note[mriyate] jñātajñeyā śuddheti cocyate
]

`v 14 [
apunarjanmakaraṇī jīvanmukteṣu dehiṣu |
vāsanā vidyate śuddhā dehe cakra iva bhramaḥ
]

`v 15 [
ye śuddhavāsanā bhūyo na janmānarthabhājanam |
jñātajñeyāsta ucyante jīvanmuktā mahādhiyaḥ
]

`v 16 [
jīvanmuktipadaṃ `note[muktipada] prāpto yathā rāmo mahāmatiḥ |
tatte'haṃ śṛṇu vakṣyāmi jarāmaraṇaśāntaye
]

`v 17 [
tatsādhananirūpaṇaṃ pratijānīte - jīvanmuktīti | tathāvidhaṃ jīvanmuktipadaṃ
rāmo yathā yena sādhanakrameṇa prāptastadvakṣyāmi | jarāmaraṇopalakṣita##-
bharadvāja mahābuddhe rāmakramamimaṃ śubham |
śṛṇu vakṣyāmi tenaiva sarvaṃ jñāsyasi sarvadā
]

`v 18 [
vidyāgṛhādviniṣkramya rāmo rājīvalocanaḥ |
divasānanayadgehe līlābhirakutobhayaḥ
]

`v 19 [
vidyāgṛhādbrahmacaryāśramocitagurukulavāsādviniṣkramyetyarthātsarva##-
|
atha gacchati kāle tu pālayatyavaniṃ nṛpe |
prajāsu vītaśokāsu sthitāsu vigatajvaram
]

`v 20 [
tīrthapuṇyāśramaśreṇīrdraṣṭumutkaṇṭhitaṃ manaḥ |
rāmasyābhūdbhṛśaṃ tatra kadācidguṇaśālinaḥ
]

`v 21 [
rāghavaścintayitvaivamupetya caraṇau pituḥ |
haṃsaḥ padmāniva navau jagrāha nakhakesarau
]

`v 22 [
śrīrama uvāca |
tīrthāni devasadmāni vanānyāyatanāni ca |
draṣṭumutkaṇṭhitaṃ tāta mamedaṃ nātha mānasam
]

`v 23 [
tadetāmarthitāṃ pūrvāṃ saphalāṃ kartumarhasi |
na so'sti bhuvane nātha tvayā yo'rthī na mānitaḥ
]

`v 24 [
iti saṃprārthito rājā vasiṣṭhena samaṃ tadā |
vicāryāmuñcadevainaṃ rāmaṃ prathamamarthinam
]

`v 25 [
śubhe nakṣatradivase bhrātṛbhyāṃ saha rāghavaḥ |
maṅgalālaṃkṛtavapuḥ kṛtasvastyayano dvijaiḥ
]

`v 26 [
vasiṣṭhaprahitairvipraiḥ śāstrajñaiśca samanvitaḥ |
snigdhaiḥ katiayaireva rājaputravaraiḥ saha
]

`v 27 [
ambābhirvihitāśīrbhirāliṅgyāliṅgya bhūṣitaḥ |
niragātsvagṛhāttasmāttīrthayātrārthamudyataḥ
]

`v 28 [
nirgataḥ svapurātpauraistūryaghoṣeṇa vāditaḥ |
pīyamānaḥ purastrīṇāṃ netrairbhṛṅgaughabhaṅguraiḥ
]

`v 29 [
grāmīṇalalanālolahastapadmāpanoditaiḥ |
jālavarṣairvikīrṇātmā himairiva himācalaḥ
]

`v 30 [
āvarjayanvipragaṇānpariśṛṇvanprajāśiṣaḥ |
ālokayandigatāṃśa paricakrāma jāṅgalān
]

`v 31 [
āvarjayandānamānādinā vaśīkurvan | jāṅgalānyeva jāṅgalān jīrṇāraṇyāni |
30 |
athārabhya svakāttasmātkrāmātkośamaṇḍalāt |
snānadānatapodhyānapūrvakaṃ sa dadarśa ha
]

`v 32 [
nadītīrāṇi puṇyāni vanānyāyatanāni ca |
jaṅgalāni janānteṣu taṭānyabdhimahībhṛtām
]

`v 33 [
mandākinīmindunibhāṃ kālindīṃ cotpalāmalām |
sarasvatīṃ śatadrūṃ ca candrabhāgāmirvāvatīm
]

`v 34 [
veṇīṃ ca kṛṣṇaveṇīṃ ca nirvindhyāṃ sarayūṃ tathā |
carmaṇvatīṃ vitastāṃ ca vipāśāṃ bāhudāmapi
]

`v 35 [
prayāgaṃ naimiṣaṃ caiva dharmāraṇyaṃ gayāṃ tathā |
vārāṇasīṃ śrīgiriṃ ca kedāraṃ puṣkaraṃ tathā
]

`v 36 [
mānasaṃ ca kramasarastathaivottaramānasam |
vaḍavāvadanaṃ caiva tīrthavṛndaṃ sa sādaram
]

`v 37 [
agnitīrthaṃ mahātīrthamindradyumnasarastathā |
sarāṃsi saritaścaiva tathā nadahradāvalīm
]

`v 38 [
svāminaṃ kārtikeyaṃ ca śālagrāmaṃ hariṃ tatha |
sthānāni ca catuḥṣaṣṭiṃ hareratha harasya ca
]

`v 39 [
nānāścaryavicitrāṇi caturabdhitaṭāni ca |
vindhyamandarakuñcāṃśca kulaśailasthalāni ca
]

`v 40 [
rājarṣiṇāṃ ca mahatāṃ brahmarṣiṇāṃ tathaiva ca |
devānāṃ brāhmaṇānāṃ ca pāvanānāśramāñchubhān
]

`v 41 [
bhūyobhūyaḥ sa babhrāma bhrātṛbhyāṃ saha mānadaḥ |
caturṣvapi diganteṣu sarvāneva mahītaṭān
]

`v 42 [
amarakinnaramānavamānitaḥ samavalokya mahīmakhilāmimām |
upayayau svagṛhaṃ raghunandano vihṛtadik śivalokamiveśvaraḥ
]