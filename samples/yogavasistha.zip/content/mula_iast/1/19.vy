`v 1 [
ekonaviṃśaḥ sargaḥ 19
śrīrama uvāca |
labdhvāpi taralākāre kāryabhārataraṅgiṇi |
saṃsārasāgare janma bālyaṃ duḥkhāya kevalam
]

`v 2 [
aśaktirāpadastṛṣṇā mūkatā mūḍhabuddhitā |
gṛdhnutā lolatā dainyaṃ sarvaṃ bālye pravartate
]

`v 3 [
roṣarodanaraudrāsu dainyajarjaritāsu ca |
daśāsu bandhanaṃ bālyamālānaṃ kariṇāmiva
]

`v 4 [
na mṛtau na jarāroge na cāpadi na yauvane |
tāścintāḥ `note[vinikṛntati] parikṛntanti hṛdayaṃ śaiśaveṣu yāḥ
]

`v 5 [
tiryagjātisamārambhaḥ sarvairevāvadhīritaḥ |
lolo bālasamācāro maraṇādapi duḥkhadaḥ
]

`v 6 [
pratibimbaghanājñānaṃ nānāsaṃkalpapelavam |
bālyamālūnasaṃśīrṇamanaḥ `note[saṃśīrṇaṃ mana] kasya
sukhāvaham
]

`v 7 [
jalavahnyanilājasrajātabhītyā pade pade |
yadbhayaṃ śaiśave'buddhyā kasyāpadi hi tadbhavet
]

`v 8 [
līlāsu durvilāseṣu durīhāsu durāśaye |
paramaṃ mohamādhatte bālo balavadāpatan
]

`v 9 [
vikalpakalpitārambhaṃ durvilāsaṃ durāspadam |
śaiśavaṃ śāsanāyaiva puruṣasya na śāntaye
]

`v 10 [
niṣphale'pi karmaṇi bālapramattādivacanādapi kautuhalena kalpitamahārambham |
durāspadaṃ duṣpratiṣṭham | śāsanāya gurvādikṛtakaśātāḍanādiduḥkhā##-
ye doṣā ye durācārā duṣkramā ye durādhayaḥ |
te sarve saṃsthitā bālye `note[durgate iva] durgarta iva kauśikāḥ
]

`v 11 [
bālyaṃ ramyamiti vyarthabuddhayaḥ kalpayanti ye |
tānmūrkhapuruṣānbrahmandhigastu hatacetasaḥ
]

`v 12 [
yacchaṅkitaṃ bālyaṃ ramyataramiti tatrāha - bālyamiti | śrutistu rāgādi##-
yatra dolākṛti manaḥ parisphurati vṛttiṣu |
trailokyā'bhavyamappi tatkathaṃ bhavati tuṣṭaye
]

`v 13 [
sarveṣāmeva sattvānāṃ sarvāvasthābhya eva hi |
manaścañcalatāmeti bālye daśaguṇaṃ mune
]

`v 14 [
manaḥ prakṛtyaiva calaṃ bālyaṃ ca calatāṃ varam |
tayoḥ saṃśliṣṭyatostrātā ka ivāntaḥ kucāpale
]

`v 15 [
strīlocanaistaḍitpuñjairjvālājālaistaraṅgakaiḥ |
cāpalaṃ śikṣitaṃ brahmañchaiśavākrāntacetasaḥ
]

`v 16 [
śaiśavenākrāntāccetasaścittātsakāśāt śikṣitamabhyastaṃ nūnamityutprekṣā |
15 |
śaiśavaṃ ca manaścaiva sarvāsveva hi vṛttiṣu |
bhrātarāviva lakṣyete satataṃ bhaṅgurāsthitī
]

`v 17 [
sarvāṇi duḥkhabhūtāni sarve doṣā durādhayaḥ |
`note[bālyameva] bālamevopajīvanti śrimantamiva mānavāḥ
]

`v 18 [
navaṃ navaṃ prītikaraṃ na śiśuḥ pratyahaṃ yadi |
prāpnoti tadasau yāti viṣayaiṣamyamūrchanām
]

`v 19 [
stokena vaśamāyāti stokenaiti vikāritām |
amedhya eva ramate bālaḥ kauleyako yathā
]

`v 20 [
ajasrabāṣpavadanaḥ kardamākto jaḍāśayaḥ |
varṣokṣitasya taptasya sthalasya sadṛśaḥ śiśuḥ
]

`v 21 [
bhayāhāraparaṃ dīnaṃ dṛṣṭādṛṣṭābhilāṣi ca |
lolabuddhi vapurdhatte bālyaṃ duḥkhāya kevalam
]

`v 22 [
svasaṃkalpābhilaṣitānbhāvānaprāpya taptadhīḥ |
duḥkhametyabalo bālo `note[viniṣkṛta] viniṣkṛtta ivāśaye
]

`v 23 [
durīhālabdhalakṣāṇi `note[lakṣyāṇi] bahuvakrolbaṇāni ca |
`note[bālyasya] bālasya yāni duḥkhāni mune tāni na kasyacit
]

`v 24 [
bālo balavatā svena manorathavilāsinā |
manasā tapyate nityaṃ grīṣmeṇeva vanasthalī
]

`v 25 [
vidyāgṛhagato bālo parāmeti kadarthanām |
ālāna iva nāgendro viṣavaiṣamyabhīṣaṇām
]

`v 26 [
aparāṃ prāguktādanyāmapi kadarthanāṃ pāravaśyakaśāghādyaniṣṭa##-
nānāmanorathamayī mithyākalpitakalpanā |
duḥkhāyātyantadīrghāya bālatā pelavāśayā
]

`v 27 [
saṃhṛṣṭo bhuvanaṃ bhoktumindumādātumambarāt |
vāñchate yena maurkhyeṇa tatsukhāya kathaṃ bhavet
]

`v 28 [
antaścitteraśaktasya śītātapanivāraṇe |
ko viśeṣo `note[mahābāho] mahābuddhe bālasyorvīruhastathā
]

`v 29 [
uḍḍītumabhivāñchanti pakṣābhyāṃ kṣutparāyaṇāḥ |
bhayāhāraparā nityaṃ bālā vihagadharmiṇaḥ
]

`v 30 [
śaiśave guruto bhītirmātṛtaḥ pitṛtastathā |
janato jyeṣṭhabālācca śaiśavaṃ bhayamandiram
]

`v 31 [
sakaladoṣadaśāvihatāśayaṃ śaraṇamapyavivekavilāsinaḥ |
iha na kasyacideva mahāmune bhavati bālyamalaṃ parituṣṭaye
]