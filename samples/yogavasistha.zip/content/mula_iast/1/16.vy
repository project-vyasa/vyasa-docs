`v 1 [
ṣoḍaśaḥ sargaḥ 16
śrīrāma uvāca |
doṣairjarjaratāṃ yāti satkāryādāryasevanāt |
vātāntaḥpicchalavavaccetaścalati cañcalam
]

`v 2 [
itaścetaśca suvyagraṃ vyarthamevābhidhāvati |
dūrāddūrataraṃ dīnaṃ grāme kauleyako yathā
]

`v 3 [
na prāpnoti kvacitkiṃcitprāptairapi mahādhanaiḥ |
nāntaḥ saṃpūrṇatāmeti karaṇḍaka ivāmbubhiḥ
]

`v 4 [
nityameva mune śūnyaṃ kadāśāvāgurāvṛtam |
na mano nirvṛtiṃ yāti mṛgo yūthādiva cyutaḥ
]

`v 5 [
taraṅgataralāṃ vṛttiṃ dadhadālūnaśīrṇatām `note[dīrghatā] |
parityajya kṣaṇamapi hṛdaye yāti na sthitim
]

`v 6 [
mano mananavikṣubdhaṃ diśo daśa vidhāvati |
mandarāhananoddhūtaṃ kṣīrārṇavapayo yathā
]

`v 7 [
kallolakalitāvartaṃ māyāmakaramālitam |
na niroddhuṃ samartho'smi manomayamahārṇavam
]

`v 8 [
kallolasadṛśairbhogalābhotsāhaiḥ kalitāvartaṃ saṃpāditamajjanānukūla##-
bhogadūrvāṅkurākāṅkṣī śvabhrapātamacintayan |
manohariṇako brahmandūraṃ viparidhāvati
]

`v 9 [
na kadācana me cetaḥ svāmālūnaviśīrṇatām |
tyajatyākulayā vṛttyā cañcalatvamivārṇavaḥ
]

`v 10 [
cetaścañcalayā vṛttyā cintānicayacañcuram |
dhṛtiṃ badhnāti naikatra pañjare kesarī yathā
]

`v 11 [
mano moharathārūḍhaṃ śarīrātsamatāsukham |
haratyapahatodvegaṃ haṃsaḥ kṣīramivāmbhasaḥ
]

`v 12 [
analpakalpanātalpe vilīnāścittavṛttayaḥ |
munīndra na prabudhyante tena tapye'hamākulaḥ
]

`v 13 [
kroḍīkṛtadṛḍhagranthitṛṣṇāsūtre sthitātmanā |
vihago jālakeneva brahmanbaddho'smi cetasā
]

`v 14 [
saṃtatāmarṣadhūmena cintājvālākulena ca |
vahnineva tṛṇaṃ śuṣkaṃ mune dagdho'smi cetasā
]

`v 15 [
krūreṇa jaḍatāṃ yātastṛṣṇābhāryānugāminā |
śavaṃ kauleyakeneva brahmanbhukto'smi cetasā
]

`v 16 [
taraṅgataralāsphālavṛttinā jaḍarūpiṇā |
taṭavṛkṣa ivaughena brahmannīto'smi cetasā
]

`v 17 [
taraṅgavattaralā āsphālāḥ alabhyaviṣaye pratihanyamānā vṛttayo yasyeti
cetaḥpakṣe | anyatra taraṅgāstaralā āsphālavṛttayo yasmiṃstena ḍalayora##-
avāntaranipātāya śūnye vā bhramaṇāya ca |
tṛṇaṃ caṇḍānileneva `note[dūraṃ nīto'smi] dūre nīto'smi cetasā
]

`v 18 [
saṃsārajaladherasmānnityamuttaraṇonmukhaḥ |
setuneva payaḥpūro rodhito'smi kucetasā
]

`v 19 [
pātālādgacchatā pṛthvīṃ pṛthvyāḥ pātālagāminā |
kūpakāṣṭhaṃ kudāmneva veṣṭito'smi kucetasā
]

`v 20 [
pṛthvīpātālaśabdābhyāṃ tatsadṛśāvūrdhvādhodeśau lakṣyete | rajjvā
jalādibhārākarṣaṇāyaikato baddhabhāraṃ triyakkāṣṭhaprotavalayākāra##-
mithyaiva sphārarūpeṇa vicārādviśarāruṇā |
bālo vetālakeneva gṛhīto'smi kucetasā
]

`v 21 [
vahneruṣṇataraḥ śailādapi kaṣṭatarakramaḥ |
vajrādapi dṛḍho brahmandurnigrahamanograhaḥ
]

`v 22 [
cetaḥ patati kāryeṣu vihagaḥ sāmiṣeṣviva |
kṣaṇena viratiṃ yāti bālaḥ krīḍanakādiva
]

`v 23 [
kāryeṣu viṣayeṣu patati jhaṭityevāsajjate | viratiṃ nivṛttim | cirābhyastebhyo'pi
sadvyāpārebhya iti śeṣaḥ | yathā bālaḥ kadācidapi prāptākrīḍanakānnimittā##-
jaḍaprakṛtirālolo vitatāvartavṛttimān |
mano'bdhirahitavyālo dūraṃ nayati tāt mām
]

`v 24 [
apyabdhipānānmahataḥ sumerūnmūlanādapi |
api vahnyaśanātsādho viṣamaścittanigrahaḥ
]

`v 25 [
cittaṃ kāraṇamarthānāṃ tasminsati jagatrayam |
tasminkṣīṇe jagatkṣīṇaṃ taccikitsyaṃ prayatnataḥ
]

`v 26 [
cittādimāni sukhaduḥkhaśatāni nūna-
mabhyāgatānyagavarādiva kānanāni |
tasminvivekavaśatastanutāṃ prayāte
manye mune nipuṇameva galanti tāni
]

`v 27 [
sakalaguṇajayāśā yatra baddhā mahadbhi-
stamarimiha vijetuṃ cittamabhyutthito'ham |
vigataratitayāntarnābhinandāmi lakṣmīṃ
jaḍamalinavilāsāṃ meghalekhāmivenduḥ
]