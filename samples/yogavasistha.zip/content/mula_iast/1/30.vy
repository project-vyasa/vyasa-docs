`v 1 [
triṃśaḥ sargaḥ 30
śrīrāma uvāca |
evamabhyutthitānarthaśatasaṃkaṭakoṭare |
jagadālokya nirmagnaṃ mano mananakargame
]

`v 2 [
mano me bhramatīvedaṃ saṃbhramaścopajāyate |
gātrāṇi parikampante patrāṇīva jarattaroḥ
]

`v 3 [
anāptottamasaṃdoṣadhairyotsaṅgākulā matiḥ |
śūnyāspadā bibhetīha bālevālpabaleśvarā
]

`v 4 [
vikalpebhyo luṭhantyetāścāntaḥkaraṇavṛttayaḥ |
śvabhrebhya iva sāraṅgāstucchālambaviḍambitāḥ
]

`v 5 [
avivekāspadā bhraṣṭāḥ kaṣṭe rūḍhā na satpade |
andhakūpamivāpannā `note[avakārā] varākāścakṣurādayaḥ
]

`v 6 [
nāvasthitimupāyāti na ca yāti yathepsitam |
cintā jīveśvarāyattā `note[śvarāyātā] kānteva priyasadmani
]

`v 7 [
jarjarīkṛtya vastūni tyajantī bibhratī tathā |
mārgaśīrṣāntavallīva dhṛtirvidhuratām gatā
]

`v 8 [
vastūni viṣayān parṇādīṃśca vivekahimopaghātāttyajantī rasāvaśeṣātkāni##-
apahastitasarvārthamanavasthitirāsthitā |
gṛhītvotsṛjya cātmānaṃ bhavasthitiravasthitā
]

`v 9 [
tāmantarālāvasthāmeva kleśāvahāṃ svasya prapañcayati - apahastiteti | uktā
cittasyānavasthitirasthiratā | hastādapagamitāḥ sarve sāṃsārikāḥ pāramārthi##-
svavivekamātreṇārdhaprabodhādardhamutsṛjyārdhaṃ ca gṛhītvā'va##-
calitācalitenāntaravaṣṭambhena me matiḥ |
daridrā chinnavṛkṣasya mūleneva viḍambyate
]

`v 10 [
cetaścañcalamābhogi bhuvanāntarvihāri ca |
na saṃbhramaṃ jahātīdaṃ svavimānamivāmarāḥ
]

`v 11 [
svata eva cañcalamābhogi nānābhogavāsanāvistīrṇaṃ bhuvanāntarviharaṇena ca
dṛḍhābhyastacāpalamato balānnigṛhyamāṇamapi tattvajñānāvaṣṭambhā##-
ato'tucchamanāyāsamanupādhi gatabhramam |
kiṃ tatsthitipadaṃ sādho yatra śoko na vidyate
]

`v 12 [
sarvārambhasamāruḍhāḥ sujanā janakādayaḥ |
vyavahāraparā eva kathamuttamatāṃ gatāḥ
]

`v 13 [
lagnenāpi kilāṅgeṣu bahudhā bahumānada |
kathaṃ saṃsārapaṅkena pumāniha na lipyate
]

`v 14 [
kāṃ dṛṣṭiṃ samupāśritya bhavanto vītakalmaṣāḥ |
mahānto vicarantīha jīvanmuktā mahāśayāḥ
]

`v 15 [
lobhayanto bhayāyaiva viṣayābhogabhotinaḥ |
bhaṅgurākāravibhavāḥ kathamāyānti bhavyatām
]

`v 16 [
mohamātaṅgamṛditā kalaṅkakalitāntarā |
paraṃ prasādamāyāti śemuṣīsarasī katham
]

`v 17 [
saṃsāra eva nivahe jano vyavaharannapi |
na bandhaṃ kathamāpnoti padmapatre payo yathā
]

`v 18 [
ātmavattṛṇavaccedaṃ sakalaṃ kalayañjanaḥ |
kathamuttamatāmeti manomanmathamaspṛśan
]

`v 19 [
paraduḥkhādāvātmavatsvaduḥkhādau tṛṇavat | antardṛṣṭyā ātmavat
bahirdṛṣṭyā tṛṇavat | kalayanpaśyan | manaso manmathaṃ kāmādivṛttim |
18 |
kaṃ mahāpuruṣaṃ `note[upayātaṃ] pāramupāyātaṃ mahodadheḥ |
ācāreṇānusaṃsmṛtya jano yāti na duḥkhitām
]

`v 20 [
kiṃ tasyāducitaṃ śreyaḥ kiṃ tatsyāducitaṃ phalam |
vartitavyaṃ ca saṃsāre kathaṃ nāmāsamañjase
]

`v 21 [
ucitamanaśvaratvātprāptuṃ yogyam | śreyo mokṣaḥ | phalaṃ karmopāsanādeḥ |
20 |
tattvaṃ kathaya me kiṃcidyenāsya jagataḥ prabho |
vedmi pūrvāparaṃ dhātuśceṣṭitasyānavasthiteḥ
]

`v 22 [
hṛdayākāśaśaśinaścetaso malamārjanam |
yathā me jāyate brahmaṃstathā nirvighnamācara
]

`v 23 [
kimiha syādupādeyaṃ kiṃvā heyamathetarat |
kathaṃ viśrāntimāyātu cetaścapalamadrivat
]

`v 24 [
kena pāvanamantreṇa duḥsaṃsṛtiviṣūcikā |
śāmyatīyamanāyāsamāyāsaśatakāriṇī
]

`v 25 [
rogāṇāṃ pāpamūlatvāttannirāsadvārā pāvanena pavanadoṣopaśamana##-
kathaṃ śītalatāmantarānandatarumañjarīm |
pūrṇacandra ivākṣīṇāṃ `note[bhṛśaṃ sākṣāddayā]
bhṛśamāsādayāmyaham
]

`v 26 [
ānandatarormañjarīmiva sthitāṃ śītalatām | bhṛśaṃ daiśikapariccheda##-
prāpyāntaḥ pūrṇatāṃ pūrṇo na śocāmi yathā punaḥ |
santo bhavantastattvajñāstathehopadiśantu mām
]

`v 27 [
anuttamānandapadapradhānaviśrāntiriktaṃ satataṃ mahātman |
kadarthayantīha bhṛśaṃ vikalpāḥ śvāno vane dehamivālpajīvam
`note[ātmajīvaṃ]
]