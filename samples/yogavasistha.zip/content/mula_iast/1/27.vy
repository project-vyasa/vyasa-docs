`v 1 [
saptaviṃśaḥ sargaḥ 27
śrīrama uvāca |
anyacca tātāṭitarāmaramye manorame ceha jagatsvarūpe |
na kiṃcidāyāti tadarthajātaṃ yenātiviśrāntimupaiti cetaḥ
]

`v 2 [
bālye gate kalpitakelilole manomṛge dādarīṣu jīrṇe |
śarīrake jarjaratāṃ prayāte vidūyate kevalameva lokaḥ
]

`v 3 [
dārā eva daryo giriguhāḥ | viśeṣeṇa dūyate upatapyate | kevalaṃ puruṣārtha##-
jarātuṣārābhihatāṃ śarīrasarojinīṃ dūratare vimucya |
kṣaṇādgate jīvitacañcarīke janasya saṃsārasaro'vaśuṣkam
]

`v 4 [
jīvitaṃ jīvanaṃ sa eva cañcarīko bhramaraḥ | saṃsāro'traihikasamārambhasta##-
yadā yadā pākamupaiti nūnaṃ tadā tadeyaṃ ratimātanoti |
jarābharā'nalpanavaprasūnā vijarjarā kālayatā narāṇām
]

`v 5 [
tṛṣṇānadī sāratarapravāhagrastākhilānantapadārthajātā |
taṭasthasaṃdoṣasuvṛkṣamūlanikāṣadakṣā vahatīha loke
]

`v 6 [
śārīranauścarmanibandhabaddhā bhavāmbudhāvālulitā bhramantī |
praloḍyate pañcabhirindriyākhyairadhobhavantī makarairadhīrā
]

`v 7 [
tṛṣṇālatākānanacāriṇo'mī śākhāśataṃ kāmamahīruheṣu |
paribhramantaḥ kṣapayanti kālaṃ manomṛgā no phalamāpnuvanti
]

`v 8 [
kṛcchreṣu dūrāstaviṣādamohāḥ svāsthyeṣu notsiktamanobhirāmāḥ |
sudurlabhāḥ saṃprati sundarībhiranāhatāntaḥkaraṇā mahāntaḥ
]

`v 9 [
taranti māgaṅgaghaṭātaraṅgaṃ raṇāmbudhiṃ ye mayi te na śūrāḥ |
śūrāsta eveha manastaraṅgaṃ dehendriyāmbodhimimaṃ taranti
]

`v 10 [
akliṣṭaparyantaphalābhirāmā na dṛśyate kasyacideva kācit |
kriyādurāśāhatacittavṛttiryāmetya viśrāntimupaiti lokaḥ
]

`v 11 [
kīrtyā jagaddikkuharaṃ pratāpaiḥ śriyā gṛhaṃ sattvabalena lakṣmīm |
ye pūrayantyakṣatadhairyabandhā na te jagatyāṃ sulabhā mahāntaḥ
]

`v 12 [
apyantarasthaṃ giriśailabhittervajrālayābhyantarasaṃsthitaṃ vā |
sarvaṃ samāyānti sasiddhivegāḥ sarvāḥ śriyaḥ santatamāpadaśca
]

`v 13 [
putrāśca dārāśca dhanaṃ ca buddhyā prakalpyate tāta rasāyanābham |
sarvaṃ tu tannopakarotyathānte yatrātiramyā viṣamūrchanaiva
]

`v 14 [
viṣādayukto viṣamāmavasthā mupāgataḥ kāyavayovasāne |
bhāvānsmaransvāniha dharmariktān janturjarāvāniha dahyate'ntaḥ
]

`v 15 [
kāmārthadharmāptikṛtāntarābhiḥ kriyābhirādau divasāni nītvā |
cetaścaladbarhiṇapicchalolaṃ viśrāntimāgacchatu kena puṃsaḥ
]

`v 16 [
purogatairapyanavāptarūpaistaraṅgiṇītuṅgataraṅgakalpaiḥ |
kriyāphalairdaivavaśādupetairviḍambyate bhinnarucirhi lokaḥ
]

`v 17 [
imānyamūnīti vibhāvitāni kāryāṇyaparyantamanoramāṇi |
janasya jāyājanarañjanena javājjarāntaṃ jarayanti cetaḥ
]

`v 18 [
parṇāni jīrṇāni yathā tarūṇāṃ sametya janmāśu layaṃ prayānti |
tathaiva lokāḥ svavivekahīnāḥ sametya gacchanti kuto'pyahobhiḥ
]

`v 19 [
itastato dūrataraṃ vihṛtya praviśya gehaṃ divasāvasāne |
vivekilokāśrayasādhukarma rikte'hni rātrau ka upaiti nidrām
]

`v 20 [
vidrāvite śatrujane samaste samāgatāyāmabhitaśca lakṣmyām |
sevyanta etāni sukhāni yāvattāvatsamāyāti kuto'pi mṛtyuḥ
]

`v 21 [
kuto'pi saṃvardhitatuccharūpairbhāvairamībhiḥ kṣaṇanaṣṭadṛṣṭaiḥ |
viloḍyamānā janatā jagatyāṃ navetyupāyātamaho na pātam
]

`v 22 [
priyāsubhiḥ kālamukhaṃ kriyante janaiḍakāste hatakarmabaddhāḥ |
yaiḥ pīnatāmeva balādupetya śarīrabādhena na te bhavanti
]

`v 23 [
ajastramāgacchati satvaraivamanārataṃ gacchati satvaraiva |
kuto'pi lolā janatā jagatyāṃ taraṅgamālā kṣaṇabhaṅgureva
]

`v 24 [
prāṇāpahāraikaparā narāṇāṃ mano manohāritayā haranti |
raktacchadāścañcalaṣaṭpadākṣyo viṣadrumālolalatāḥ striyaśca
]

`v 25 [
ito'nyataścopagatā mudhaiva samānasaṃketanibaddhabhāvā |
yātrāsamāsaṃgasamā narāṇāṃ kalatramitravyavahāramāyā
]

`v 26 [
pradīpaśāntiṣviva bhuktabhūridaśāsvatisnehanibandhanīṣu |
saṃsāramālāsu calācalāsu na jñāyate tattvamatāttvikīṣu
]

`v 27 [
saṃsārasaṃrambhakucakrikeyaṃ prāvṛṭpayobudbudabhaṅgurāpi |
asāvadhānasya janasya buddhau cirasthirapratyayamātanoti
]

`v 28 [
śobhojjvalā daivavaśādvinaṣṭā guṇāḥ sthitāḥ saṃprati jarjaratve |
āśvāsanādūrataraṃ prayātā janasya hemanta ivāmbujasya
]

`v 29 [
punaḥpunardaivavaśādupetya svadehabhāreṇa kṛtopakāraḥ |
vilūyate yatra taruḥ kuṭhārairāśvāsane tatra hi kaḥ prasaṅgaḥ
]

`v 30 [
manoramasyāpyatidoṣavṛtterantarvighātāya samutthitasya |
viṣadrumasyeva janasya saṅgādāsādyate saṃprati mūrchanaiva
]

`v 31 [
kāstā dṛśo yāsu na santi doṣāḥ
kāstā diśo yāsu na duḥkhadāhaḥ |
kāstāḥ prajā yāsu na bhaṅguratvaṃ
kāstāḥ kriyā yāsu na nāma māyā
]

`v 32 [
saṃsāradṛṣṭiṣu kāstā dṛśo dṛṣṭayaḥ | kriyā laukikyaḥ | māyā chalam |
31 |
kalpābhidhānakṣaṇajīvino hi kalpaughasaṃkhyākalane `note[viriñcyā]
viriñcyāḥ |
ataḥ kalāśālini kālajāle laghutvadīrghatvadhiyo'pyasatyāḥ
]

`v 33 [
sarvatra pāṣāṇamayā mahīdhrā mṛdā mahī dārubhireva vṛkṣāḥ |
māṃsairjanāḥ pauruṣabaddhabhāvā nāpūrvamastīha vikārahīnam
]

`v 34 [
ālokyate cetanayā'nuviddhā payonubaddho'stanayo nabhaḥ sthāḥ |
pṛthagvibhāgena padārthalakṣmyā etajjagannetaradasti kiṃcit
]

`v 35 [
camatkṛtiśceha manasvilokacetaścamatkārakarī narāṇām |
svapne'pi sādho viṣayaṃ kadācitkeṣāṃcidabhyeti na citrarūpā
]

`v 36 [
adyāpi yāti'pi ca kalpanāyā ākāśavallīphalavanmahattve |
udeti no lobhalavāhatānāmudāravṛttāntamayī kathaiva
]

`v 37 [
ādātumicchanpadamuttamānāṃ svacetasaivāpahato'dya lokaḥ |
patatyaśaṅkaṃ paśuradrikūṭādānīlavallīphalavāñchayaiva
]

`v 38 [
avāntaranyastanirarthakāṃśacchāyālatāpatraphalaprasūnāḥ |
śarīra eva kṣatasaṃpadaśca śvabhradrumā adyatanā narāśca
]

`v 39 [
avāntare durgame gartodara eva nyastānyataeva nirarthakāṃśāni aṃśato'pi
prāṇibhiranupabhogyatvādvyarthānīti yāvat | chāyādīni yeṣāṃ tathāvidhāḥ
śvabhradrumāḥ śarīre svaśarīrapoṣaṇāyaivopayogātkṣatā vyarthaṃ nāśitā
vidyāvinayadhanādisaṃpado yaistathāvidhā narāśca tulyā eva | vyarthajanma##-
kvacijjanā mārdavasundareṣu dvacitkaṭhoreṣu ca saṃcaranti |
deśāntarāleṣu nirantareṣu vanāntakhaṇḍeṣviva kṛṣṇasārāḥ
]

`v 40 [
dhāturnavāni divasaṃ prati bhīṣaṇāni
ramyāṇi vā vilulitāntatamākulāni |
kāryāṇi kaṣṭaphalapākahatodayāni
vismāpayanti na śavasya manāṃsi keṣām
]

`v 41 [
janaḥ kāmāsakto vividhakukalāceṣṭanaparaḥ
sa tu svapne'pyasmiñjagati sulabho nādya sujanaḥ |
kriyā duḥkhāsaṅgā'vidhuravidhurā nūnamakhilā
na jāne netavyā kathamiva daśā jīvitamayī
]