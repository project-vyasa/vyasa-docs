`v 1 [
yogavāsiṣṭha
of
vālmīki
śrīvāsiṣṭhamahārāmāyaṇatātparyaprakāśākhyavyākhyāsahitaḥ
With the commentary
vāsiṣṭhamahārāmāyaṇatātparyaprakāśa
paṇaśīkaropahvalakṣmaṇaśarmatanujanuṣā vāsudevaśarmaṇā
sampāditaḥ
Edited by
Vasudeva ḻaxmana ṣharma Pansika
vairāgyaprakaraṇaṃ prathamam |
prathamaḥ sargaḥ 1
śrīmahāgaṇapaticaraṇāravindābhyāṃ namaḥ |
oṃ namo brahmaṇe brahmavidbhyo brahmavidyāsaṃpradāyakartṛbhyo
vasiṣṭhaviśvāmitravyāsavālmīkiśukādibhyaḥ śrīrāmabhadrāya ca |
ajamajaramanādyanantamantarnijasukhabodhasadadvitīyapūrṇam |
śivamakhilahṛdi sphuratsvamāyāvikasitaviśvavilāsamānatāḥ smaḥ
]

`v 2 [
smṛtiphalitasamastābhīṣṭamudyaddineśa##-
kamapi śivabhavānyoraṅkasaubhāgyamantaḥ
suramaṇimavalambe cāru lambodarākhyam
]

`v 3 [
mugdhasmitāñcitamanojñamukhendubimbaṃ
snigdhāmṛtapratimacārukṛpākaṭākṣam |
agresarairanusṛtaṃ munibhirmunīnāṃ
nyagrodhamūlavasatiṃ gurumāśrayāmaḥ
]

`v 4 [
tribhuvanāvanakṛtyakṛtodayaḥ sadabhayāmalabodhasukhādvayaḥ
(sukhodayaḥ) |
sujanahṛdgirigahvarakesarī śaraṇamastu sadā narakesarī
]

`v 5 [
dakṣe varākṣavalayāvabhayaṃ ca vāme
yā pustakaṃ ca dadhatī vidhinetrapeyā |
sā śāradābjanayanā śaradinduśobhā
bhāsā svayā haratu me hṛdayāndhakāram
]

`v 6 [
ye netrāṇi harasya yairjagadidaṃ pradyotitaṃ ceṣṭate
yatraivāyatate (vāpatate) śrutismṛtinuto dharmaḥ saśarmodayaḥ |
yekālaṃ kalayanti ye ca paramasvajyotirātmopamā-
stesūryendvanalā bhavantu hṛdi me bodhābjinībhānavaḥ
]

`v 7 [
vakrendubhirdikṣu tamo haradbhirvedārthasārāmṛtamudgirantam |
vāṇībhujāśiṣṭamabhīṣṭasiddhyai taṃ brahmavidyādiguruṃ prapadye
]

`v 8 [
yadvākyāmṛtapāyināṃ pratipadaṃ satyaṃ sudhā nīrasā
yadvākyārthavicāraṇādabhimataḥ svargo'pi kārāgṛham |
yadvāṇīviśadātmapūrṇamanasāṃ tucchaṃ jagattūlava-
ttasmai śrīgurave vasiṣṭhamunaye nityaṃ namaskūrmahe
]

`v 9 [
(yasyārṣaprathitā; yaśārdhaprathitā) yasyārṣaṃ prathitā jagattrayahitā
sā vedamātā parā
yaścakre tapasā vaśe suragaṇānanya (nanyānsisṛkṣuḥ) tsisṛkṣurjagat
|
taṃ bodhāmbunidhiṃ tapasvimukuṭālaṃkāracintāmaṇiṃ
viśvāmitramuniṃ śaraṇyamanaghaṃ bhūyo (namasyāmahe)
namasyāmyaham
]

`v 10 [
śrutyā brahmaiva rāmaḥ prakaṭitamahimā yena tasmai vasiṣṭho
yaḥ sītāṃ brahmavidhāmiva sadasi punaḥ satyaśuddhāṃ kilādāt |
yadvāṇī mohamūlaṃ śamayati jagadānandasaṃdohadogdhrī
tasmai vālmīkaye śrīgurutamagurave bhūribhāvairnatāḥ smaḥ
]

`v 11 [
pūrṇānandasvabhāvaḥ svajanahitakṛte māyayopāttakāyaḥ
kāruṇyāduddidhīrṣurjanamanavarataṃ mohapaṅke nimagnam |
āviśyāntarvasiṣṭhaṃ bahirapi kalayañśiṣyabhāvaṃ vitene
yaḥ saṃvādena śāstrāmṛtajaladhimanuṃ rāmacandraṃ prapadye
]

`v 12 [
vidyābhiḥ saha viśrutā śritavatī yeṣāṃ mukhaṃ bhāratī
sattvotkarṣasamādhibhiḥ sthiramaho tadbrahma yeṣāṃ hṛdi |
pādāmbhoruhamāśritāśca satataṃ tīrthaiḥ samaṃ saṃpadaḥ
śrīsarvajñasarasvatīti viditāñśrīmadgurūṃstānbhaje
]

`v 13 [
śrīḥ saṃśritaiva caraṇau hṛdayaṃ ca rāma-
ścandro mukhaṃ guṇabhareṇa sarasvatī ca |
yeṣāmatastadabhidhāṅkitanāmadheyān
śrīmadgurūngurutarānpraṇato'smi nityam
]

`v 14 [
tāpadhvastivyāpṛtakāruṇyakaṭākṣān
vyākhyāvāṇīnirvṛtasarvāṅghriśaraṇyān |
śrīmadrāmānanadamunīnadbhutacaryā-
nāryānnityaṃ deśikavaryānpraṇato'smi
]

`v 15 [
viśveśo'pi hariḥ śaraṇyacaraṇo yānmānayansauhṛdā-
cchāntānnityamanuvrajāmi rajasā pūyeya cetyabravīt |
yatpūjāṃ vidadhe śrutirmatimatāṃ sarveṣṭasiddhyai sadā
jīvanmuktasukhātmapūrṇamanasastānbrahmaniṣṭhānbhaje
]

`v 16 [
kṛtibhirasukarāḥ kva nu prabandhāḥ kva ca bata bāliśabuddhireṣa jantuḥ |
tadapi viracane'tra sadguruṇāṃ sadayanīkṣaṇameva me'valambaḥ
]

`v 17 [
aśeṣavidyāmbudhipāragāṇāmapāstarāgādimanomalānām |
kṛpānidhīnāṃ kṛtināṃ mamāsminsatāṃ padābjasmaraṇaṃ sahāyaḥ
]

`v 18 [
yatkṛpāleśamātreṇa tīrṇo'smi bhavasāgaram |
śrīmadgaṅgādharendrākhyānśrīgurūṃstānsadā bhaje
]

`v 19 [
ānandabodyayatinā śrīmadguruvacomṛtaiḥ |
vāsiṣṭhārthaprakāśo'yaṃ yathāmati vitanyate
]

`v 20 [
praśaṃsantu svairaṃ matibhiratha nindantu sudhiyaḥ
pravṛttirme yasmānna bhavati janārādhanakṛte |
anena vyājenāmṛtarasavasiṣṭhoktibharite
vihartuṃ vāñchāmi pratidivasamānanandajaladhau
]

`v 21 [
yathāmati bubhutsubhyaḥ sāhāyyaṃ saṃkaṭeṣviva |
durūhaślokabhāveṣu darśayiṣye pariśramam
]

`v 22 [
sthitamekarase yuktyā nānārasavijṛmbhaṇam |
vāsiṣṭhaṃ rocayatvetatsubhojyaṃ lavaṇaṃ yathā
]

`v 23 [
apyalpamatidurbodhaṃ sphuṭaṃ vyākhyāsyate padam |
dvistrirvyākhyātapūrvaṃ tu durūhamapi mokṣyate
]

`v 24 [
ananyapūrvavyākhyātaṃ granthaṃ me vyācikīrṣataḥ |
santaḥ śramajñāḥ kṛpayā kṣamadhvaṃ skhalitaṃ kvacit
]