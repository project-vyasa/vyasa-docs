`v 1 [
saptamaḥ sargaḥ 7
śrīvālmīkiruvāca |
tacchrutvā rājasiṃhasya vākyamadbhutavistaram |
hṛṣṭaromā mahātejā viśvāmitro'bhyabhāṣata
]

`v 2 [
sadṛśaṃ rājaśārdūla tavaivaitanmahītale |
mahāvaṃśaprasūtasya vasiṣṭhavaśavartinaḥ
]

`v 3 [
sadṛśaṃ yuktam | tatra hetugarbhe viśeṣaṇe | vaṃśaprabhāvādguruprabhāvā##-
yattu me hṛdgataṃ vākyaṃ tasya kāryavinirṇayam |
kuru tvaṃ rājaśārdūla dharmaṃ samanupālaya
]

`v 4 [
ahaṃ dharmaṃ samātiṣṭhe siddhyarthaṃ puruṣarṣabha |
tasya vighnakarā ghorā rākṣasā mama saṃstithāḥ
]

`v 5 [
yadā yadā tu yajñena yaje'haṃ vibudhavrajān |
tadā tadā tu me yajñaṃ vinighnanti niśācarāḥ
]

`v 6 [
bahuśo vihite tasminmayā rākṣasanāyakāḥ |
akiraṃste mahīṃ yāge māṃsena rudhireṇa ca
]

`v 7 [
avadhūte tathābhūte tasminyāgakadambake |
kṛtaśramo nirutsāhastasmāddeśādupāgataḥ
]

`v 8 [
na ca me krodhamutsraṣṭuṃ buddhirbhavati pārthiva |
tathābhūtaṃ hi tatkarma na śāpastasya vidyate
]

`v 9 [
īdṛśī yajñadīkṣā sā mama tasminmahākratau |
tvatprasādādavighnena prāpayeyaṃ mahāphalam
]

`v 10 [
trāturmahasi māmārtaṃ śaraṇārthinamāgatam |
arthināṃ yannirāśatvaṃ sattame'bhibhavo hi saḥ
]

`v 11 [
tavāsti tanayaḥ śrīmāndṛptaśārdūlavikramaḥ |
mahendrasadṛśo vīrye rāmo rakṣovidāraṇaḥ
]

`v 12 [
uttaratra tamiti darśanādatra ya ityadhyāhāryam | viśeṣaṇāni vivakṣitārthopa##-
taṃ putraṃ rājaśārdūla rāmaṃ satyaparākramam |
kākapakṣadharaṃ śūraṃ jyeṣṭhaṃ me dāturmahasi
]

`v 13 [
śakto hyeṣa mayā gupto divyena dvena tejasā |
rākṣasā ye'pakartārasteṣāṃ mūrdhavinigrahe
]

`v 14 [
śreyaścāsya kariṣyāmi bahurūpamanantakam |
trayāṇāmapi lokānāṃ yena pūjyo bhaviṣyati
]

`v 15 [
śreyo'stravidyāpradānarūpam | astrabhedādbahurūpaṃ prabhāvastvanantakama##-
na ca te rāmamāsādya sthātuṃ śaktā niśācarāḥ |
kruddhaṃ kesariṇam dṛṣṭvā `note[vaneriṇe vanodbhūte īriṇākhye]
vaneraṇa ivaiṇakāḥ
]

`v 16 [
teṣāṃ na cānyaḥ kākutsthādyoddhumutsahate pumān |
ṛte kesariṇaḥ kruddhānmattānāṃ kariṇāmiva
]

`v 17 [
vīryotsiktā hi te pāpāḥ kālakūṭopamā raṇe |
karadūṣaṇayorbhṛtyāḥ kṛtāntāḥ kupitā iva
]

`v 18 [
rāmasya rājaśārdūla sahiṣyante na sāyakān |
amāratagatā dhārā jaladasyeva pāṃsavaḥ
]

`v 19 [
na ca putrakṛt'm snehaṃ kartumarhasi pārthiva |
na tadasti jagatyasminyanna deyaṃ mahātmanām
]

`v 20 [
hanta nūnaṃ vijānāmi hatāṃstānviddhi rākṣasān |
nahyasmadādayah prājñāḥ saṃdigdhe saṃpravṛttayaḥ
]

`v 21 [
ahaṃ vedmi mahātmānaṃ rāmaṃ rājīvalocanam |
vasiṣṭhaśca mahātejā ye cānye dīrghadarśinaḥ
]

`v 22 [
yadi dharmo mahattvaṃ ca yaśaste manasi sthitam |
tanmahyaṃ samabhipretamātmajaṃ dātumarhasi
]

`v 23 [
daśarātraśca me yajño asminrāmeṇa rākṣasāḥ |
hantavyā vighnakartāro mama yajñasya vairiṇaḥ
]

`v 24 [
atrāpyanujñāṃ kākutstha dadatāṃ tava mantriṇaḥ |
vasiṣṭhapramukhāh sarve tena rāmaṃ visarjaya
]

`v 25 [
nātyeti kālaḥ kālajña yathāyaṃ mama rāghava |
tathā kuruṣva bhadraṃ te mā ca śoke manaḥ kṛthāḥ
]

`v 26 [
kāryamaṇvapi kāle tu kṛtametyupakāratām |
mahadapyupakāro'pi riktatāmetyakālataḥ
]

`v 27 [
ityevamuktvā dharmātmā dharmārthasahitaṃ vacaḥ |
virarāma mahātejā viśvāmitro munīśvaraḥ
]

`v 28 [
śrutvāvaco munivarasya mahānubhāva-
stūṣṇīmatiṣṭhadupapannapadaṃ sa vaktum |
no yuktiyuktakathanena vinaiti toṣaṃ
dhīmānapūritamano'bhimataśca lokaḥ
]