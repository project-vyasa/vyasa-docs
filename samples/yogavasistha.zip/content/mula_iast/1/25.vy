`v 1 [
pañcaviṃśaḥ sargaḥ 25
śrīrama uvāca |
atraiva durvilāsānāṃ cūḍāmaṇirihāparaḥ |
karotyattīti loke'smindaivaṃ kālaśca kathyate
]

`v 2 [
kriyāmātrādṛte yasya svaparispandarūpiṇaḥ |
nānyadālakṣyate rūpaṃ na karma na samīhitam
]

`v 3 [
teneyamakhilā bhūtasaṃtatiḥ paripelavā |
tāpena himamāleva nītā vidhuratāṃ bhṛśam
]

`v 4 [
yadidaṃ dṛśyate kiṃcijjagadābhogi maṇḍalaṃ |
tattasya nartanāgāramihāsāvatinṛtyati
]

`v 5 [
tṛtīyaṃ ca kṛtānteti nāma bibhratsudāruṇam |
kāpālikavapurmattaṃ `note[vapurbhūtaṃ] daivaṃ jagati nṛtyati
]

`v 6 [
nṛtyato hi kṛtāntasya nitāntamiva rāgiṇaḥ |
nityaṃ niyatikāntāyāṃ mune paramakāmitā
]

`v 7 [
śeṣaḥ śaśikalāśubhro gaṅgāvāhaśca tau tridhā |
upavīte avīte ca ubhau saṃsāravakṣasi
]

`v 8 [
candrārkamaṇḍale hemakaṭakau karamūlayoḥ |
līlāsarasijaṃ haste brahmanbramāṇḍakarṇikā
]

`v 9 [
tārābinducitaṃ lolapuṣkarāvartapallavam |
ekārṇavapayodhau tamekamambaramambaram
]

`v 10 [
evaṃrūpasya tasyāgre niyatirnityakāminī |
anastamitasaṃrambhamārambhaiḥ parinṛtyati
]

`v 11 [
anastamitasaṃrambhamavirataprayatnam | prāṇisabhyabhogānukūlakāryā##-
tasyā nartanalolayā jaganmaṇḍapakoṭare `note[nmaṇḍalakoṭare] |
aruddhaspandarūpāyā āgamāpāyacañcure
]

`v 12 [
cārubhūṣaṇamaṅgeṣu devalokāntarāvalī |
āpātālaṃ nabholambaṃ kabarīmaṇḍalaṃ bṛhat
]

`v 13 [
narakālī ca mañjīrāmālā kalakalojjvalā |
protā duṣkṛtasūtreṇa pātālacaraṇe sthitā
]

`v 14 [
kastūrikātilakakaṃ kriyāsaṃkhyopakalpitam |
citritaṃ citraguptena yame vadanapaṭṭake
]

`v 15 [
kālāsyaṃ samupādāya kalpānteṣu kilākulā |
nṛtyatyeṣā punardevī sphuṭacchailaghanāravam
]

`v 16 [
paścātprālambavibhrāntakaumārabhṛtabarhibhiḥ |
netratrayabṛhadrandhrabhūribhāṅkārabhīṣaṇaiḥ
]

`v 17 [
lambalolajaṭācandravikīrṇaharamūrdhabhiḥ |
uccaraccārumandāragaurīkabaracāmaraiḥ
]

`v 18 [
candrāntabahurvīhighaṭitaḥ karmadhārayaḥ | kabarāḥ keśāstadrūpaiścā##-
uttāṇḍavācalākārabhairavodaratumbakaiḥ |
raṇatsaśatarandhrendradehabhikṣākapālakaiḥ
]

`v 19 [
śuṣkaśārīrakhaṭvāṅgabharairāpūritāmbaram |
bhīṣayatyātmanātmānaṃ sarvasaṃhārakāriṇī
]

`v 20 [
viśvarūpaśiraścakracārupuṣkaramālayā |
tāṇḍaveṣu vivalgantyā mahākalpeṣu rājate
]

`v 21 [
pramattapuṣkarāvartaḍamaroḍḍāmarāravaiḥ |
tasyāḥ kila palāyante kalpānte `note[tumbarādayaḥ] tumburādayaḥ
]

`v 22 [
puṣkarāvartākhyāḥ saṃvartameghā eva ḍamaro ḍamarukaṃ tasyoḍḍāmarāra##-
nṛtyato'ntaḥ kṛtāntasya candramaṇḍalabhāsinaḥ |
tārakācandrikācāruvyomapicchāvacūlinaḥ
]

`v 23 [
ekasmiñchravaṇe dīptā himavānasthimudrikā |
apare ca mahāmeruḥ kāntā kāñcanakarṇikā
]

`v 24 [
atraiva kuṇḍale lole candrārkau gaṇḍamaṇḍale |
lokālokācalaśreṇī sarvataḥ kaṭimekhalā
]

`v 25 [
atra anayoreva karṇayoḥ | śreṇīti śṛṅgabāhu.yāt kalpabrahmāṇḍabhedādvā |
24 |
itaścetaśca gacchantī vidyudvalayakarṇikā |
anilāndolitā bhāti nīradāṃśukapaṭṭikā
]

`v 26 [
musalaiḥ paṭṭiśaiḥ prāsaiḥ śūlaistomaramudgaraiḥ |
tīkṣṇaiḥ `note[jagadvātakṛtānta] kṣīṇajagadvāntakṛtāntairiva
saṃbhṛtaiḥ
]

`v 27 [
kṣīṇebhyo jagadbhyaḥ pūrvasargebhyo vāntairnigataiḥ kṛtāntarimṛtyubhiḥ
saṃbhṛtairmilitairiva sthitairmusalādibhirvaricitā asya mālā śobhate ityutta##-
saṃsārabandhānādīrghe pāśe kālakaracyute |
śeṣabhogamahāsūtraprote mālāsya śobhate
]

`v 28 [
jīvollasanmakarikāratnatejobhirujjvalā |
saptābdhikaṅkaṇaśreṇī bhujayorasya bhūṣaṇam
]

`v 29 [
vyavahāramahāvartā sukhaduḥkhaparamparā |
rajaḥpūrṇatamaḥśyāmā romālī tasya rājate
]

`v 30 [
evaṃprāyaḥ sa kalpānte kṛtāntastāṇḍavodbhavām |
upasaṃhrtya nṛtyehāṃ sṛṣṭvā saha `note[maheśvaraiḥ]
maheśvaram
]

`v 31 [
punarlāsyamayīṃ nṛtyalīlāṃ sargasvarūpiṇīm |
tanotīmāṃ jarāśokaduḥkhābhibhavabhūṣitām
]

`v 32 [
bhūyaḥ karoti bhuvanāni vanāntarāṇi
lokāntarāṇi janajālakakalpanāṃ ca |
ācāracārukalanāmacalāṃ calāṃ ca
paṅkādyathārbhakajano racanāmakhinnaḥ
]