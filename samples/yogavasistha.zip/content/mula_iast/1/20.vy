`v 1 [
viṃśaḥ sargaḥ 20
śrīrāma uvāca |
bālyānarthamatha tyaktvā pumānabhihatāśayaḥ |
ārohati nipātāya yauvanaṃ saṃbhrameṇa tu
]

`v 2 [
tatrānantavilāsasya lolasya svasya cetasaḥ |
vṛttiranubhavanyāti duḥkhādduḥkhāntaraṃ jaḍaḥ
]

`v 3 [
svacittabilasaṃsthena nānāsaṃbhramakāriṇā |
balātkāmapiśācena vivaśaḥ paribhūyate
]

`v 4 [
cintānāṃ lolavṛttīnāṃ lalanānāmivā'vṛtīḥ |
arpayatyavaśaṃ ceto bālānāmañjanaṃ yathā
]

`v 5 [
te te doṣā durārambhāstatra taṃ tādṛśāśayam |
tadrūpaṃ pratilumpanti duṣtāstenaiva ye mune
]

`v 6 [
mahānarakabījena saṃtatabhramadāyinā |
yauvanena na ye naṣṭā naṣṭā nānyena te janāḥ
]

`v 7 [
nānārasamayī citravṛttāntanicayombhitā |
bhīmā yauvanabhūryena tīrṇā dhīraḥ sa ucyate
]

`v 8 [
rasāḥ śṛṅgārādayaḥ kaṭvādayo viṣayābhilāṣā dustarajalāni ca | prācurye
mayaṭ | rāgalobhādīnāṃ coravyāghrasarpādīnāṃ ca caitrairāścaryahetu##-
`note[bhāsvarākāra] nimeṣabhāsurākāramālolaghanagarjitam |
vidyutprakāśamivaṃ yauvanaṃ me na rocate
]

`v 9 [
madhuraṃ svādu tiktaṃ ca dūṣaṇaṃ doṣabhūṣaṇam |
surākallolasadṛśaṃ yauvanaṃ me na rocate
]

`v 10 [
asatyaṃ satyasaṃkāśamacirādvipralambhadam |
svapnāṅganāsaṅgasamaṃ yauvanaṃ me na rocate
]

`v 11 [
sarvasyāgre sarvapuṃsaḥ kṣaṇamātramanoharam |
gandharvanagaraprakhyaṃ yauvanaṃ me na rocate
]

`v 12 [
iṣuprapātamātraṃ hi sukhadaṃ duḥkhabhāsuram |
dāhapoṣapradaṃ nityaṃ yauvanaṃ me na rocate
]

`v 13 [
āpātamātraramaṇaṃ sadbhāvarahitāntaram |
veśyāstrīsaṃgamaprakhyaṃ yauvanaṃ me na rocate
]

`v 14 [
ye kecana samārambhāste sarve sarvaduḥkhadāḥ |
tāruṇye saṃnidhiṃ yānti mahotpātā iva kṣaye
]

`v 15 [
sarveṣāṃ duḥkhadā ye kecana samārambhāste sarve ityanvayaḥ | kṣaye pralaye | 14
|
hārdāndhakārakāriṇyā bhairavākāravānapi |
yauvanājñānayāminyā bibheti bhagavānapi `note[jñānavānapi]
]

`v 16 [
suvismṛtaśubhācāraṃ buddhivaidhuryadāyinam |
dadātyatitarāmeṣa bhramaṃ yauvanasaṃbhramaḥ
]

`v 17 [
kāntāviyogajātena hṛdi duḥsparśavahninā |
yauvane dahyate jantustarurdāvāgninā yathā
]

`v 18 [
sunirmalāpi vistīrṇā pāvanyapi hi yauvane |
matiḥ kaluṣatāmeti prāvṛṣīva taraṅgiṇī
]

`v 19 [
śakyate ghanakallolā bhīmā laṅghayituṃ nadī |
na tu tāruṇyataralā tṛṣṇātaralitāntarā
]

`v 20 [
sā kāntā tau stanau pīnau te vilāsāstadānanam |
tāruṇya iti cintābhiryāti jarjaratāṃ janaḥ
]

`v 21 [
naraṃ taralarṣṇārti yuvānamiha sādhavaḥ |
pūjayanti na tu cchinnaṃ jarattṛṇalavaṃ yathā
]

`v 22 [
nāśāyaiva madārtasya doṣamauktikadhāriṇaḥ |
abhimānamahebhasya nityālānaṃ hi yauvanam
]

`v 23 [
manovipulamūlānāṃ doṣāśīviṣadhāriṇām |
śoṣarodanavṛkṣāṇāṃ yauvanaṃ bata kānanam
]

`v 24 [
rasakesarasaṃbādhaṃ kuvikalpadalākulam |
duścintācañcarīkāṇāṃ puṣkaraṃ viddhi yauvanam
]

`v 25 [
kṛtākṛtakupakṣāṇāṃ hṛtsarastīracāriṇām |
ādhivyādhivihaṃgānāmālayo navayauvanam
]

`v 26 [
jaḍānāṃ gatasaṃkhyānāṃ kallolānāṃ vilāsinām |
amapekṣitamaryādo vāridhirnavayauvanam
]

`v 27 [
sarveṣāṃ guṇasargāṇāṃ parirūḍharajastamāḥ |
apanetuṃ sthitiṃ dakṣo viṣamo yauvanānilaḥ
]

`v 28 [
nayanti pāṇḍutāṃ vakramākulāvakarotkaṭāḥ |
ārohanti parāṃ koṭiṃ rūkṣā yauvanapāṃsavaḥ
]

`v 29 [
udbodhayati doṣāliṃ `note[vikṛnnati] nikṛntati guṇāvalim |
narāṇāṃ yauvanollāso vilāso duṛkṛtaśriyām
]

`v 30 [
śarīrapaṅkajarajaścañcalāṃ matiṣaṭpadīm |
nibandhanmohayatyeṣa navayauvanacandramāḥ
]

`v 31 [
śarīrakhaṇḍakodbhūtā ramyā yauvanavallarī |
lagnameva manobhṛṅgaṃ madayatyunnatiṃ gatā
]

`v 32 [
śarīramarutāpotthāṃ yuvatāmṛgatṛṣṇikām |
manomṛgāḥ pradhāvantaḥ patanti viṣayāvaṭe
]

`v 33 [
śarīraśarvarījyotsnā cittakesariṇaḥ saṭā |
laharī jīvitāmbhodheryuvatā me na tuṣṭaye
]

`v 34 [
dināni katicidyeyaṃ phalitā dehajaṅgale |
yuvatā śaradasyāṃ hi na samāśvāsamarhatha
]

`v 35 [
jhaṭityeva prayātyeva śarīrādyuvatākhagaḥ |
kṣaṇenaivālpabhāgyasya hastāccintāmaṇiryathā
]

`v 36 [
yadā yadā parāṃ koṭimadhyārohati yauvanam |
valganti sajvarāḥ kāmāstadā nāśāya kevalam
]

`v 37 [
tāvadeva vivalganti rāgadveṣapiśācakāḥ |
nāstameti samastaiṣā yāvadyuvanayāminī
]

`v 38 [
nānāvikārabahule varāke kṣaṇanāśini |
kāruṇyaṃ kuru tāruṇye mriyamāṇe sute yathā
]

`v 39 [
harṣamāyāti yo mohātpuruṣaḥ kṣaṇabhaṅginā |
yauvanena mahāmugdhaḥ sa vai naramṛgaḥ smṛtaḥ
]

`v 40 [
mānamohānmadonmattaṃ yauvanaṃ yo'bhilaṣyati |
acireṇa sa durbuddhiḥ paścāttāpena yujyate
]

`v 41 [
te pūjyāste mahātmānasta eva puruṣā bhuvi |
ye sukhena samuttirṇāḥ sādho yauvanasaṃkaṭāt
]

`v 42 [
sukhena tīryate'mbhodhirutkṛṣṭamakarākaraḥ |
na kallolabalollāsi sadoṣaṃ hatayauvanam
]

`v 43 [
vinayabhūṣitamāryajanāspadaṃ karuṇayojjvalamāvalitaṃ guṇaiḥ |
iha hi durlabhamaṅga suyauvanaṃ jagati kānanamambaragaṃ yathā
]