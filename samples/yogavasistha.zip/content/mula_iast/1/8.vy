`v 1 [
aṣṭamaḥ sargaḥ 8
vālmīkiruvāca |
tacchrutvā rājaśārdūlo viśvāmitrasya bhāṣitam |
muhūrtamāsīnniśceṣṭaḥ sadainyaṃ cedamabravīt
]

`v 2 [
ūnaṣoḍaśavarṣo'yaṃ rāmo rājīvalocanaḥ |
na yuddhayogyatāmasya paśyāmi saha rākṣasaiḥ
]

`v 3 [
iyamakṣauhiṇī pūrṇā yasyāḥ patirahaṃ prabho |
tayā parivṛto yuddhaṃ dāsyāmi piśitāśinām
]

`v 4 [
ime hi śūrā vikrāntā bhṛtyā mantraviśāradāḥ |
`note[atra] ahaṃ caiṣāṃ dhanuspāṇirgoptā samaramūrdhani
]

`v 5 [
ebhiḥ sahaiva vīrāṇāṃ mahendramahatāmapi |
dadāmi yuddhaṃ mattānāṃ kariṇāmiva kesarī
]

`v 6 [
bālo rāmastvanīkeṣu na jānāti balābalam |
antaḥpurādṛte dṛṣṭā nānenānyā raṇāvaniḥ
]

`v 7 [
nanvanena raṇāvanirna dṛṣṭetyeva vaktavye anyeti viśeṣaṇavaiyarthyam | evaṃ
tarhi purasyāntarantaḥpuramityavyayībhāvaḥ | puramadhye khuralīkrīḍārtha##-
na śastraiḥ paramairyukto na ca yuddhaviśāradaḥ |
navāstraiḥ śūrakoṭīnāṃ tajjñaḥ samarabhūmiṣu
]

`v 8 [
kevalaṃ puṣpakhaṇḍeṣu nagaropavaneṣu ca |
udyānavanakuñjeṣu sadaiva pariśīlanam
]

`v 9 [
vihartumeṣa jānāti saha rājakumārakaiḥ |
kīrṇapuṣpopahārāsu svakāsvajirabhūmiṣu
]

`v 10 [
adya tvatitarāṃ brahmanmama bhāgyaviparyayāt |
himeneva hi padmābhaḥ saṃpanno hariṇaḥ kṛśaḥ
]

`v 11 [
nāttumannāni śaknoti na vihartuṃ gṛhāvanim |
antaḥkhedaparītātmā tūṣṇīṃ tiṣṭhati kevalam
]

`v 12 [
sadāraḥ sahabhṛtyo'haṃ tatkṛte munināyaka |
śaradīva payovāho nūnaṃ niḥsāratāṃ gataḥ
]

`v 13 [
īdṛśo'sau suto bāla ādhinā'tha vaśīkṛtaḥ |
kathaṃ dadāmi taṃ tubhyaṃ yoddhuṃ saha niśācaraiḥ
]

`v 14 [
api bālāṅganāsaṅgādapi sādho sudhārasāt |
rājyādapi sukhāyaiva putrasneho mahāmate
]

`v 15 [
ye durantā mahārambhāstriṣu lokeṣu khedadāḥ |
putrasnehena santo'pi kurvate tānasaṃśayam
]

`v 16 [
asavo'tha dhanaṃ dārāstyajyante mānavaiḥ sukham |
na putro muniśārdūla svabhāvo hyeṣa jantuṣu
]

`v 17 [
rākṣasāḥ krūrakarmāṇaḥ kūṭayuddhaviśāradāḥ |
rāmastānyodhayatvitthaṃ yuktirevātiduḥsahā
]

`v 18 [
voprayukto hi rāmeṇa muhūrtamapi notsahe |
jīvituṃ jīvitākāṅkṣī na rāmaṃ netumarhasi
]

`v 19 [
navavarṣahasrāṇi mama jātasya kauśika |
duḥkhenotpāditāstvete catvāraḥ putrakā mayā
]

`v 20 [
pradhānabhūtasteṣveva rāmaḥ kamalalocanaḥ |
taṃ vineha trayo'pyanye dhārayanti na jīvitam
]

`v 21 [
sa eva rāmo bhavatā nīyate rākṣasānprati |
yadi tatputrahīnaṃ tvaṃ mṛtamevāśu viddhi mām
]

`v 22 [
caturṇāmātmajānāṃ hi prītiratraiva me parā |
jyeṣṭhaṃ dharmamayaṃ tasmānna rāmaṃ netumarhasi
]

`v 23 [
niśācarabalaṃ hantuṃ mune yadi tavepsitam |
caturaṅgasamāyuktaṃ mayā saha balaṃ naya
]

`v 24 [
kiṃvīryā rākṣasāste tu kasya putrāḥ kathaṃ ca te |
kiyatpramāṇāḥ ke caiva iti varṇaya me sphuṭam
]

`v 25 [
kathaṃ tena prakartavyaṃ teṣāṃ rāmeṇa rakṣasām |
māmakairbālakairbrahmanmayā vā kūṭayodhinām
]

`v 26 [
sarvaṃ me śaṃsa bhagavanyathā teṣāṃ mahāraṇe |
sthātavyaṃ duṣṭabhāgyānāṃ vīryotsiktā hi rākṣasāḥ
]

`v 27 [
śrūyate hi mahāvīryo rāvaṇo nāma rākṣasaḥ |
sākṣādvaiśravaṇabhrātā putro viśravaso muneḥ
]

`v 28 [
sa cettava makhe vighnaṃ karoti kila durmatiḥ |
tatsaṃgrāme na śaktāḥ smo vayaṃ tasya durātmanaḥ
]

`v 29 [
kāle kāle pṛthagbrahmanbhūrivīryavibhūtayaḥ |
bhūteṣvabhyudayaṃ yānti pralīyante ca kālataḥ
]

`v 30 [
adyāsmiṃstu vayaṃ kāle rāvaṇādiṣu śatruṣu |
na samarthāḥ puraḥ sthātuṃ niyatereṣa niścayaḥ
]

`v 31 [
tasmātprasādaṃ dharmajña kuru tvaṃ mama putrake |
mama caivālpabhāgyasya bhavānhi paradaivatam
]

`v 32 [
anukampyaḥ putraḥ putrakastasmin | arthimanorathasamarthanāsamarthatvādalpa##-
devadānavagandharvā yakṣāḥ patagapannagāḥ |
na śaktā rāvaṇaṃ yoddhuṃ kiṃ punaḥ puruṣā yudhi
]

`v 33 [
mahāvīryavatāṃ vīryamādatte yudhi rākṣasaḥ |
tena sārdhaṃ na śaktāḥ sma saṃyuge tasya bālakaiḥ
]

`v 34 [
ayamanyatamaḥ kālaḥ pelavīkṛtasajjanaḥ |
rāghavo'pi gato dainyaṃ yato vārdhakajarjaraḥ
]

`v 35 [
athavā lavaṇaṃ brahmanyajñaghnaṃ taṃ madhoḥ sutam |
kathayatvasuraprakhyaṃ naiva mokṣyāmi putrakam
]

`v 36 [
sundopasundayoścaiva putrau vaivasvatopamau |
yajñavighnakarau brūhi na te dāsyāmi putrakam
]

`v 37 [
atha neṣyasi cedbrahmaṃstaddhato'smyahameva te |
anyathā tu na paśyāmi śāśvataṃ jayamātmanaḥ
]

`v 38 [
ityuktvā mṛdu vacanaṃ raghūdvaho'sau
kallole munimatasaṃśaye nimagnaḥ |
nājñāsītkṣaṇamapi niścayaṃ mahātmā
prodvīcāviva jaladhau sa muhyamānaḥ
]