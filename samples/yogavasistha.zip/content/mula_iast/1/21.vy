`v 1 [
ekaviṃśaḥ sargaḥ 21
śrīrāma uvāca |
māṃsapāñcalikāyāstu yantralole'ṅgapañjare |
snāyvasthigranthiśālinyāḥ striyāḥ kimiva śobhanaṃ
]

`v 2 [
tvaḍvāṃsaraktabāṣpāmbu pṛthakkṛtvā vilocanam |
samālokaya ramyaṃ cetkiṃ mudhā parimuhyasi
]

`v 3 [
itaḥ keśā ito raktamitīyaṃ pramadātanuḥ |
kimetayā ninditayā karoti vipulāśayaḥ
]

`v 4 [
vāsovilepanairyāni lālitāni punaḥ punaḥ |
tānyaṅgānyaṅga luṇṭhanti kravyādāḥ sarvadehinām
]

`v 5 [
meruśṛṅgataṭollāsigaṅgājalarayopamā |
dṛṣṭā yasminstane muktāhārasyollāsaśālitā
]

`v 6 [
śmaśāneṣu diganteṣu sa eva lalanāstanaḥ |
śvabhirāsvādyate kāle laghupiṇḍa ivāndhasaḥ
]

`v 7 [
raktamāṃsāsthidigdhāni karabhasya yathā vane |
tathaivāṅgāni kāminyāstāṃ pratyapi hi ko grahaḥ
]

`v 8 [
āpātaramaṇīyatvaṃ `note[kalpyate kevalaṃ striyaḥ] kalpate kevalaṃ
striyāḥ |
manye tadapi nāstyatra mune mohaikakāraṇam
]

`v 9 [
vipulollāsadāyinyā madamanmathapūrvakam |
ko viśeṣo vikāriṇyā madirāyāḥ `note[striyastathā] striyāstathā
]

`v 10 [
lalanālānasaṃlīnā mune mānavadantinaḥ |
prabodhaṃ nādhigacchanti dṛdhairapi śamāṅkuśaiḥ
]

`v 11 [
keśakajjaladhāriṇyo duḥsparśā locanapriyāḥ |
duṣkṛtāgniśikhā nārtho dahanti tṛṇavannaram
]

`v 12 [
jvalatāmatidūre'pi sarasā api nīrasāḥ |
striyo hi narakāgnīnāmindhanaṃ cāru dāruṇam
]

`v 13 [
vikīrṇākārakabarī tarattārakalocanā |
purṇendubimbavadanā kusumotkarahāsinī
]

`v 14 [
līlāvilolapuruṣā kāryasaṃhārakāriṇī |
paraṃ vimohanaṃ buddheḥ kāminī dīrghayāminī
]

`v 15 [
puṣpābhirāmamadhurā karapallavaśālinī |
bhramarākṣivilāsāḍhyā stanastabakadhāriṇī
]

`v 16 [
puṣpakeṣaragaurāṅgī naramāraṇatatparā |
dadātyunmattavaivaśaṃ kāntā viṣalatā yathā
]

`v 17 [
satkāryocchvāsamātreṇa bhujaṅgadalanotkayā |
kāntayoddhriyate jantuḥ karabhyevorago bilāt
]

`v 18 [
kāmanāmnā kirātena vikīrṇā mugdhacetasām |
nāryo naravihaṃgānāmaṅgabandhanavāgurāḥ
]

`v 19 [
lalanāvipulālāne manomattamataṃgajaḥ |
ratiśṛṅkhalayā brahmanbaddhastiṣṭhati mūkavat
]

`v 20 [
janmapalvalamatsyānāṃ `note[vittakardama] cittakardamacāriṇām |
puṃsāṃ durvāsanārajjurnārī baḍiśapiṇḍikā
]

`v 21 [
kanduraṃ ca turaṅgāṇāmālānamiva dantinām |
puṃsāṃ mantra ivāhīnāṃ bandhanaṃ vāmalocanā
]

`v 22 [
nānārasavatī citrā bhogabhūmiriyaṃ mune |
striyamāśritya saṃyātā parāmiha hi saṃsthitim
]

`v 23 [
sarveṣāṃ doṣaratnānāṃ susamudgikayā'nayā |
duḥkhaśṛṅkhalayā nityamalamastu mama striyā
]

`v 24 [
susamudgikayā dṛḍhasaṃpuṭikayā | alaṃ paryāptam | prayojanaṃ nāstītyarthaḥ |
23 |
kiṃ stanena kimakṣṇā vā kiṃ nitambena kiṃ bhuvā |
māṃsamātraikasāreṇa karomyahamavastunā
]

`v 25 [
iti māṃsamito raktamito'sthīnīti vāsaraiḥ |
brahmankatipayaireva yāti strī viśarārutām
]

`v 26 [
yāstāt puruṣaiḥ sthūlairlalitā manujaiḥ priyāḥ |
tā mune pravibhaktāṅgyaḥ svapanti pitṛbhūiṣu
]

`v 27 [
yasminghanatarasnehaṃ mukhe patrāṅkurāḥ striyaḥ |
kāntena racitā brahmanpīyate tena jaṅgale
]

`v 28 [
keśāḥ śmaśānavṛkṣeṣu yānti cāmaralekhikām |
asthīnyuḍuvadābhānti dinairavanimaṇḍale
]

`v 29 [
striyaḥ keśāḥ lekha ullekha utprekṣā saiva lekhikā tām | bhasmadhūsaratvā##-
pibanti pāṃsavo raktaṃ kravyādāścāpyanekaśaḥ |
carmāṇi ca śivā bhuṅkte khaṃ yānti prāṇavāyavaḥ
]

`v 30 [
ityeṣā lalanāṅgānāmacireṇaiva bhāvinī |
sthirmayā vaḥ kathitā kiṃ bhrāntimanudhāvatha
]

`v 31 [
bhūtapañcakasaṃghaṭṭasaṃsthānaṃ lalanābhidham |
rasādabhipatatvetakathaṃ nāma dhiyānvitaḥ
]

`v 32 [
śākhyāpratānagahanā kaṭvamlaphalamālinī |
sutālottālatāmeti cintā kāntānusāriṇī
]

`v 33 [
kāndigbhūtatayā ceto ghanagardhāndhamākulam |
paraṃ mohamupādatte yūthabhraṣṭamṛgo yathā
]

`v 34 [
śocyatāṃ paramāṃ yāti taruṇastaruṇīparaḥ |
nibaddhaḥ kariṇīlolo vindhyakhāte yathā gajaḥ
]

`v 35 [
yasya strī tasya bhogecchā niḥstrīkasya kva bhogabhūḥ |
striyaṃ tyaktvā jatattyaktaṃ jatattyakatvā sukhī bhavet
]

`v 36 [
āpātamātraramaṇeṣu sudustareṣu
bhogeṣu nāhamalipakṣaticañcaleṣu |
brahmanname maraṇarogajarādibhītyā
śāmyāmyahaṃ paramupaimi padaṃ prayatnāt
]