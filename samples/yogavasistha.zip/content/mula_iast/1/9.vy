`v 1 [
navamaḥ sargaḥ 9
vālmīkiruvāca |
tacchrutvā vacanaṃ tasya snehaparyākulekṣaṇam |
samanyuḥ kauśiko vākyaṃ pratyuvāca mahīpatim
]

`v 2 [
kariṣyāmīti saṃśrutya pratijñāṃ hātumarhasi |
sa bhavānkesarī bhūtvā mṛgatāmiva vāñchasi
]

`v 3 [
rāghavāṇāmayukto'yaṃ kulasyāsya viparyayaḥ |
na kadācana jāyante śītāṃśoruṣṇaraśmayaḥ
]

`v 4 [
yadi tvaṃ na kṣamo rājangamiṣyāmi yathāgatam |
hīnapratijña kākutstha sukhī bhava sabāndhavaḥ
]

`v 5 [
vālmīkiruvāca |
tasminkopaparīte'tha viśvāmitre mahātmani |
cacāla vasudha kṛtsnā surāṃśca bhayamāviśat
]

`v 6 [
krodhābhibhūtaṃ vijñāya jaganmitraṃ mahāmunim |
dhṛtimānsuvrato dhīmānvasiṣṭho vākyamabravīt
]

`v 7 [
vasiṣṭha uvāca |
ikṣvākūṇāṃ kule jātaḥ sākṣāddharma ivāparaḥ |
bhavāndaśarathaḥ śrīmāṃstrailokyaguṇabhūṣitaḥ
]

`v 8 [
dhṛtimānsuvrato bhūtvā na dharmaṃ hāturmarhasi |
triṣu lokeṣu vikhyāto dharmeṇa yaśasā yutaḥ
]

`v 9 [
svadharmaṃ pratipadyasva na dharmaṃ hātumarhasi |
munestribhuvaneśasya vacanaṃ kartumarhasi
]

`v 10 [
svasya svānāṃ ca dharma pratijñāpālana. pratipadyasva | triṣvapi bhuvaneṣvabhi##-
kariṣyāmīti saṃśrutya tatte rājannakurvataḥ |
iṣṭāpūrtaṃ harerddharmaṃ tasmādrāmaṃ visarjaya
]

`v 11 [
ikṣvākuvaṃśajāto'pi svayaṃ daśaratho'pi san |
na pālayasi cedvākyaṃ ko'paraḥ pālayiṣyati
]

`v 12 [
yuṣmadādipraṇītena vyavahāreṇa jantavaḥ |
maryādāṃ na vimuñcanti tāṃ na hātuṃ tvamarhasi
]

`v 13 [
guptaṃ puruṣasiṃhena jvalanenāmṛtaṃ yathā |
kṛtāstramakṛtāstraṃ vā nainaṃ śakṣyanti rākṣasāḥ
]

`v 14 [
eṣa vigrahavāndharma eṣa vīryavatāṃ varaḥ |
eṣa buddhyā'dhiko loke tapasāṃ ca parāyaṇam
]

`v 15 [
eṣo'straṃ vividhaṃ vetti trailokye scarācare |
naitadanyaḥ pumānvetti na ca vetsyati kaścana
]

`v 16 [
na devā narṣayaḥ kecinnāsurā na ca rākṣasāḥ |
na nāgā yakṣagandharvāḥ sametāḥ sadṛśā muneḥ
]

`v 17 [
astramasmai kṛśāśvena paraiḥ paramadurjayam |
kauśikāya purā dattaṃ yadā rājyaṃ samanvagāt
]

`v 18 [
te hi putrāḥ kṛśāśvasya prajāpatisutopamāḥ |
enamanvacaranvīrā dīptimanto mahaujasaḥ
]

`v 19 [
jayā ca suprabhā caiva dākṣāyaṇyau sumadhyame |
tayostu yānyapatyāni śataṃ paramadurjayam
]

`v 20 [
pañcāśataṃ sutāñjajñe jayā labdhavarā purā |
vadhārthaṃ surasainyānāṃ te kṣamāḥ kāmacāriṇaḥ
]

`v 21 [
suprabhā janayāmāsa putrānpañcāśataṃ parān |
saṃghaṣānnāma durdharṣāndurākārānbalīyasaḥ
]

`v 22 [
evaṃvīryo mahātejā viśvāmitro jaganmuniḥ |
na rāmagamane buddhiṃ viklvāṃ kartumarhasi
]

`v 23 [
asminmahāsattvatame munīndre sthite samīpe puruṣasya sādho |
prāpte'pi mṛtyāvamaratvameti mā dīnatāṃ gaccha yathā vimūḍhaḥ
]