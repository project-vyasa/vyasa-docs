`v 1 [
saptadaśaḥ sargaḥ 17
śrīrāma uvāca |
hārdāndhakāraśarvayā tṛṣṇayeha durantayā |
sphuranti cetanākāśe `note[doṣāḥ kauśika] doṣakauśikapaṅktayaḥ | 1
|
sarvapāpaughajananī dainyakārpaṇyamṛtyudā |
bhramayantī jagatkṛtsnaṃ tṛṣṇaikātra vinindyate |
hārdasya paramapremāspadasya ātmatattvasya hṛdayodbhavasya vivekādeśca
tirodhāne andhakāraśarvayā tamisrayā | durantayā durucchedayā | iha cetanākāśe
jīve | rāgādidoṣalakṣaṇāḥ kauśikapaṅktaya ulukaśreṇayaḥ
]

`v 2 [
antardāhapradāyinyā samūḍharasamārdavaḥ |
paṅka ādityadīptyeva śoṣaṃ nīto'smi cintayā
]

`v 3 [
mama cittamahāraṇye vyāmohatimirākule |
śūnye tāṇḍavinī jātā bhṛśamāśāpiśācikā
]

`v 4 [
vacoracitanīhārā kāñcanopavanojjvalā |
nūnaṃ vikāsamāyāti cintācaṇakamañjarī
]

`v 5 [
alamantarbhramāyaiva tṛṣṇātaralitāśayā |
āyātā viṣamollāsamūrmirambunidhāviva
]

`v 6 [
uddāmakallolaravā dehādrau vahatīha me |
taraṅgataralākārā tarattṛṣṇātaraṅgiṇī
]

`v 7 [
vegaṃ saṃroddhumudito vātyayeva jarattṛṇam |
nītaḥ kaluṣayā kvāpi tṛṣṇayā cittacātakaḥ
]

`v 8 [
yāṃ yāmahamatīvāsthāṃ saṃśrayāmi guṇaśriyām |
tāṃ tāṃ kṛntati me tṛṣṇā tantrīmiva kumūṣikā
]

`v 9 [
guṇaśriyāṃ vivekavairāgyādiguṇasaṃpadāṃ viṣaye yāṃ yāmāsthāmut##-
payasīva jaratparṇaṃ vāyāviva jarattṛṇam |
nabhasīva śaranmeghaścintācakre bhramāmyaham
]

`v 10 [
gantumāspadamātmīyamasamarthadhiyo vayam |
cintājāle vimuhyāmo jāle śakunayo yathā
]

`v 11 [
tṛṣṇābhidhānayā tāta dagdho'smi jvālayā tathā |
yathā dāhopaśamanamāśaṅke nāmṛtairapi
]

`v 12 [
dūraṃ dūramito gatvā sametya ca punaḥ punaḥ |
bhramatyāśu diganteṣu tṛṣṇonmattā turaṅgamī
]

`v 13 [
jaḍasaṃsargiṇī tṛṣṇā kṛtordhvādhogamāgamā |
kṣubdhā granthimatī nityamāraghaṭṭāgrarajjuvat
]

`v 14 [
antargrathitayā dehe sarvaduśchedayā'nayā |
rajjvevāśu balīvardastṛṣṇayā vāhyate janaḥ
]

`v 15 [
dehe antarmanasi `note[granthitayeti kvacit] grathitayā protayā balīvardarajjupakṣe
nāsādipradeśe protayā | vāhyate aihikāmuṣmikasādhanasahasrabhāramityarthaḥ |
14 |
putramitrakalatraditṛṣṇayā nityakṛṣṭayā |
khageṣviva kirātyedaṃ jālaṃ lokeṣu racyate
]

`v 16 [
nityaṃ kṛṣṭamākarṣaṇaṃ yasyāh svabhāvastathābhūtayā tṛṣṇayā kirātyā
khageṣu jālamiva idaṃ prasiddhaṃ putramitrakalatrādijālaṃ lokeṣu janeṣu racyate |
15 |
bhīṣayatyapi dhīraṃ māmandhayatyapi sekṣaṇam |
khedayatyapi sānandaṃ tṛṣṇā kṛṣneva śarvarī
]

`v 17 [
kuṭilā komalasparśā viṣavaiṣamyaśaṃsinī |
daśatyapi manākṣpṛṣṭā tṛṣnā kṛṣṇeva bhoginī
]

`v 18 [
bhindatī hṛdayaṃ puṃsāṃ māyāmayavidhāyinī |
daurbhāgyadāyinī dīnā tṛṣṇā kṛṣṇeva rākṣasī
]

`v 19 [
tandrītantrīgaṇaiḥ kośaṃ dadhānā pariveṣṭitam |
nānande rājate brahmaṃstṛṣṇā jarjaravallakī
]

`v 20 [
nityamevātimalinā kaṭukonmādadāyinī |
dīrghatantrī ghanasnehā tṛṣṇā gahvaravallarī
]

`v 21 [
anānandakarī śūnyā niṣphalā vyarthamunnatā |
amaṅgalakarī krūrā tṛṣṇā kṣīṇeva mañjarī
]

`v 22 [
anāvarjitacittāpi sarvamevānudhāvati |
na cāpnoti phalaṃ kiṃcittṛṣṇā jīrṇeva kāminī
]

`v 23 [
saṃsāravṛnde mahati nānārasasamākule |
bhuvanābhogaraṅgeṣu tṛṣṇā jaraṭhanartakī
]

`v 24 [
jarākusumitārūḍhā pātotpātaphalāvaliḥ |
saṃsarajaṃgale dīrghe tṛṣṇā viṣalatā tatā
]

`v 25 [
yanna śaknoti tatrāpi dhatte tāṇḍavitāṃ gatim |
nṭyatyānandarahitaṃ tṛṣṇā jīrṇeva nartakī
]

`v 26 [
bhṛśaṃ sphurati nīhāre śāmyatyāloka āgate |
durlaṅghyeṣu padaṃ dhatte cintā capalabarhiṇī
]

`v 27 [
jaḍakallolabahulā ciraṃ śūnyāntarāntarā |
kṣaṇamullāsamāyāti tṛṣṇā prāvṛṭtaraṅgiṇī
]

`v 28 [
naṣṭamutsṛjya tiṣṭhantaṃ tṛṣṇā vṛkṣamivāparam |
puruṣātpuruṣaṃ yāti tṛṣṇā loleva pakṣiṇī
]

`v 29 [
padaṃ karotyalaṅghye'pi tṛptāpi phalamīhate |
ciraṃ tiṣṭhati naikatra tṛṣṇā capalamarkaṭī
]

`v 30 [
idaṃ kṛtvedamāyāti sarvamevāsamañcasam |
anārataṃ ca yatate tṛṣṇā ceṣṭeva daivikī
]

`v 31 [
kṣaṇamāyāti pātālaṃ kṣaṇaṃ yāti nabhasthalam |
kṣaṇaṃ bhramati dikkuñje tṛṣṇā hṛpadmaṣaṭpadī
]

`v 32 [
sarvasaṃsāradoṣāṇāṃ tṛṣṇaikā dīrghaduḥkhadā |
antaḥpurasthamapi yā yojayatyatisaṃkaṭe
]

`v 33 [
payacchati paraṃ jāḍyaṃ paramālokarodhinī |
mohanīhāragahanā tṛṣṇā jaladamālikā
]

`v 34 [
sarveṣāṃ jantujātānāṃ saṃsāravyavahāriṇām |
pariprotamanomālā tṛṣṇā bandhanarajjuvat
]

`v 35 [
yathā bahunāṃ paśūnāṃ kaṇṭhadāmabhiḥ protā mālopamānā tiryagdīrgha##-
vicitravarṇā viguṇā dīrghā malinasaṃsthitiḥ |
śūnyā śūnyapadā tṛṣṇā śakrakārmukadhariṇī
]

`v 36 [
aśanirgunasasyānāṃ phalitā śaradāpadām |
himaṃ saṃvitsarojānāṃ tamasāṃ dīrghayāminī
]

`v 37 [
saṃsāranāṭakanaṭī kāryālayavihaṃgamī |
mānasāraṇyahariṇī smarasaṃgītavallakī
]

`v 38 [
vyavahārābdhilaharī mohamātaṅgaśṛṅkhalā |
sarganyagrodhasulatā duḥkhakairavacandrikā
]

`v 39 [
nyagrohatīti nyagrodho vaṭastasya sulatā prarohavallī | kairavāṇāṃ kumudānām |
38 |
jarāmaraṇaduḥkhānāmekā ratnasamudrikā |
ādhivyādhivilāsānāṃ nityaṃ mattā vilāsinī
]

`v 40 [
kṣaṇamālokavimalā `note[ālokaviṣayā] sāndhakāralavā kṣaṇam |
vyomavīthyupamā tṛṣṇā nīhāragahanā kṣaṇam
]

`v 41 [
āloka īṣadvivekaprakāśaḥ | vyomaiva vīthī tadupamā | nīhārasadṛśairvyā##-
gacchatyupaśamaṃ tṛṣṇā kāyavyāyāmaśāntaye |
tamī ghanatamaḥkṛṣṇā yathā rakṣonivṛttaye
]

`v 42 [
tāvanmuhyatyayaṃ mūko loko vilulitāśayaḥ |
yāvadevānusaṃdhatte tṛṣṇā viṣaviṣūcikā
]

`v 43 [
loko'yamakhilaṃ duḥkhaṃ cintayojjhitayojjhati |
tṛṣṇāviṣūcikāmantraścintātyāgo hi kathyate
]

`v 44 [
tṛṇapāṣāṇakāṣṭhādisarvamāmiṣaśaṅkayā |
ādadānā sphuratyante tṛṣṇā matsyī hrade yathā
]

`v 45 [
āmiṣaśaṅkayā bhakṣyamiti saṃbhāvanayā | sā yathā ante baḍiśamapyādā##-
rogārtiraṅganātṛṣṇā gambhīramapi mānavam |
uttānatāṃ nayantyāśu sūryāṃśava ivāmbujam
]

`v 46 [
antaḥśūnyā granthimatyo dīrghasvāṅkurakaṇṭakāḥ |
muktāmaṇipriyā nityaṃ tṛṣṇā veṇulatā iva
]

`v 47 [
granthayo dṛḍhābhiniveśāḥ parvāṇi ca | tṛṣṇāyā aṅkurā"cintāḥ | kaṇṭakā
duḥkhāni | muktāmaṇayaśca priyā yāsām | veṇulatāpakṣe tāsāṃ muktākara##-
aho bata mahaccitraṃ tṛṣṇāmapi mahādhiyaḥ |
duśchedāmapi kṛntanti vivekenāmalāsinā
]

`v 48 [
nāsidhārā na vajrārcirna taptāyaḥkaṇārciṣaḥ |
tathā tīkṣṇā yathā bhramaṃstṛṣṇeyaṃ hṛdi saṃsthitā
]

`v 49 [
ujjvalā'sitatīkṣṇāgrā snehadīrghadaśā parā |
prakāśā dāhaduḥsparśā tṛṣṇā dīpaśikhā iva
]

`v 50 [
api merusamaṃ prājñamapi śūramapi sthiram |
tṛṇīkaroti tṛṣṇaikā nimeṣeṇa narottamam
]

`v 51 [
saṃstīrṇagahanā bhīmā ghanajālarajomayī |
sāndhakārogranīhārā tṛṣṇā vindhyamahātaṭī
]

`v 52 [
ekaiva sarvabhuvanāntaralabdhalakṣyā
durlakṣyatāmupagataiva vapuḥsthitaiva |
tṛṣṇā sthitā jagati cañcalavīcimāle
kṣīrodakāmbutarale madhureva śaktiḥ
]