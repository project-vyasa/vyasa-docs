`v 1 [
trayodaśaḥ sargaḥ 13
śrīrāma uvāca |
iyamasminsthitodārā saṃsāre parikalpitā |
śrīrmune parimohāya sāpi nūnaṃ kadarthadā
]

`v 2 [
ullāsabahulānantakallolānalamākulān |
jaḍānpravahati sphārānprāvṛṣīva taraṅgiṇī
]

`v 3 [
ullāsairutsāhairbahulā anantāḥ kallolā manorathaparamparā yeṣāṃ tān
sphārānbahūn jaḍānmūrkhān pravahati pāravaśyamāpādyākarṣati |
taraṅgiṇīpakṣe ūrdhvaṃ lāso nāṭyaṃ tena bahulānupacitānanantān##-
cintāduhitaro bahvyo bhūridurlalitaidhitāḥ |
cañcalāḥ prabhavantyasyāstaraṅgāḥ sarito yathā
]

`v 4 [
eṣā hi padamekatra na nibadhnāti durbhagā |
dagdhevāniyatācāramitaścetaśca dhāvati
]

`v 5 [
yathā kāciddurbhagā mohādvahniṃ padā āskandya dagdhā satī ekatra padaṃ na
nibadhnāti pādaṃ na sthāpayati kiṃtvaniyataceṣṭaṃ yathā syāttathā itaścetaśca
dhāvati tathā śrīrapi padaṃ sthānaṃ aniyatācāraṃ śāstra##-
janayantī paraṃ dāhaṃ `note[parikṣīṇāṅgakā satī]
parāmṛṣṭāṅgikā satī |
vināśameva dhatte'ntardīpalekheva kajjalam
]

`v 6 [
guṇāguṇavicāreṇa vinaiva kila pārśvagam |
rājaprakṛtivanmūḍhā durārūḍhā'valambate
]

`v 7 [
karmaṇā `note[tenaiva] tenatenaiṣā vistāramanugacchati |
doṣāśīviṣavegasya yatkṣīraṃ vistarāyate
]

`v 9 [
tāvacchītamṛdusparśāḥ pare sve ca jane `note[janaḥ] janāḥ |
vātyayeva himaṃ yāvacchriyā na paruṣīkṛtāḥ `note[paruṣīkṛtaḥ] | 8
|
śītamṛdusparśapadena dayādākṣiṇyasnehādyupalakṣyate | vātasamūho vātyā |
paruṣīkṛtā `note[kṛtaḥ ityubhayatraikavacanaṃ kvacit] duḥsahīkṛtāḥ | 8
|
prājñāḥ śūrāḥ kṛtajñāśca peśalā mṛdavaśca ye |
pāṃsumuṣṭyeva maṇayaḥ śriyā te malinīkṛtāḥ
]

`v 10 [
na śrīḥ sukhāya bhagavanduḥkhāyaiva hi vardhate |
guptā vināśanaṃ dhatte mṛtiṃ viṣalatā yathā
]

`v 11 [
śrīmānajananindyaśca śūraścāpyavikatthanaḥ |
samadṛṣṭiḥ prabhuścaiva durlabhāḥ puruṣāstrayaḥ
]

`v 12 [
eṣā hi viṣamā duḥkhabhogināṃ gahanā guhā |
ghanamohagajendrāṇāṃ vindhyaśailamahātaṭī
]

`v 13 [
satkāryapadmarajanī duḥkhakairavacandrikā `note[kairavaṃ
śubhrakamalam] |
sudṛṣṭidīpikāvātyā kallolaughataraṅgiṇī
]

`v 14 [
satkāryāṇi puṇyakarmāṇi tallakṣaṇapadmānāṃ rajanī rātriḥ |
saṃkocaheturityarthaḥ | evaṃ duḥkhakairavāṇāṃ candrikā vikāsahetuḥ |
sudṛṣṭirdayādṛṣṭiḥ paramārthadṛṣṭirvā tadrūpadīpikāyā vātyā
vātasamūhaḥ | kallolaughayuktā taraṅgiṇīva | asyā api dīpapraśamana##-
saṃbhramābhrādipadavī viṣādaviṣavardhinī |
kedārikā vikalpānāṃ khedāyabhayabhoginī
]

`v 15 [
himaṃ vairāgyavallināṃ vikārolūkayāminī |
rāhudaṃṣṭrā vivekendoḥ saujanyāmbhojacandrikā
]

`v 16 [
indrāyudhavadālolanānārāgamanoharā |
lolā taḍidivotpannadhvaṃsinī ca jaḍāśrayā
]

`v 17 [
cāpalāvajitāraṇyanakulī nakulīnajā |
vipralambhanatātparyajitogramṛgatṛṣṇikā
]

`v 18 [
laharīvaikarūpeṇa padaṃ kṣaṇamakūrvatī |
calā dīpaśikhevātidurjñeyagatigocarā
]

`v 19 [
siṃhīva vigrahavyagrakarīndrakulapothinī `note[pātinī] |
khaḍgadhāreva śiśirā tīkṣṇatīkṣṇāśayāśrayā
]

`v 20 [
nānayāpahṛtārthinyā durādhiparilīnayā |
paśyāmyabhavyayā lakṣmyā kiṃcidduḥkhādṛte `note[dṛte yathā]
sukham
]

`v 21 [
apahṛtaiḥ parasvairarthavatyā apahṛtānvā mṛtyunā arthayate vāñchati
tacchīlayā | durādhayaḥ parilīnāḥ pracchannāścoravadyasyām | āhitā##-
dūreṇotsāritā'lakṣmyā punareva tamādarāt |
aho batāśliṣyatīva nirlajjā durjanā sadā
]

`v 22 [
tamiti parāmarśādyasyeti labhyate | tathāca yasya puruṣasya alakṣmyā sapatnyeva
svayaṃ dūreṇotsāritā tameva ciraṃ sapatnyopabhuktaṃ punarādarādāśliṣya##-
manoramā karṣati cittavṛttiṃ kadarthasādhyā kṣaṇabhaṅgurā ca |
vyālāvalīgātravivṛttadehā śvabhrotthitā puṣpalateva lakṣmīḥ
]