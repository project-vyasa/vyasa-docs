`v 1 [
ekatriṃśaḥ sargaḥ 31
śrīrāma uvāca |
proccavṛkṣacalatpatralambāmbulavabhaṅgure |
āyuṣīśānaśītāṃśukalāmṛduni dehake
]

`v 2 [
kedāraviraṭadbhekakaṇṭhatvakkoṇabhaṅgure |
vāgurāvalaye jantoḥ suhṛtsujanasaṃgame
]

`v 3 [
kedāreṣu śālikṣetreṣu | koṇo'tra madhyabhāgaḥ sa iva bhaṅgure asthire dehake iti
pūrveṇa saṃbandhaḥ | suhṛdāṃ mitrāṇāṃ sujanānāṃ āptabandhu##-
vāsanāvātavalite kadāśātaḍiti sphuṭe |
mohogramihikāmeghe ghanaṃ sphūrjati garjati
]

`v 4 [
nṛtyatyuttāṇḍavaṃ caṇḍe lole lobhakalāpini |
suvikāsini sāsphoṭe hyanarthakuṭajadrume
]

`v 5 [
krūre kṛtāntamārjāre sarvabhūtākhuhāriṇi |
aśrāntasyandasaṃcāre `note[spanda] kuto'pyuparipātini
]

`v 6 [
ka upāyo gatiḥ kā vā kā cintā kaḥ samāśrayaḥ |
keneyamaśubhodarkā na bhavejjīvitāṭavī
]

`v 7 [
na tadasti pṛthivyāṃ vā divi deveṣu vā kvacit |
sudhiyastucchamapyetadyannayanti na ramyatām
]

`v 8 [
ayaṃ hi dagdhasaṃsāro nīrandhrakalanākulaḥ |
kathaṃ susvādutāmeti nīraso mūḍhatāṃ vinā
]

`v 9 [
āśāprativipākena kṣīrasnānena ramyatām |
upaiti puṣpaśubhreṇa madhuneva vasuṃdharā
]

`v 10 [
apamṛṣṭamalodeti kṣālanenāmṛtadyutiḥ |
manaścandramasaḥ kena tena kāmakalaṅkitāt
]

`v 11 [
kāmena kalaṅkitānmanaścandramasaḥ | tena vidvadanabhavaprasiddhena kena
kṣālanenāpakṛṣṭakāmādimalā amṛtadyutirāhlādacandrikā udetītyanvayaḥ |
10 |
dṛṣṭasaṃsāragatinā dṛṣṭādṛṣṭavināśinā |
keneva vyavahartavyaṃ saṃsāravanavīthiṣu
]

`v 12 [
rāgadveṣamahārogā bhogapūgā vibhūtayaḥ |
kathaṃ jantuṃ na bādhante saṃsārāṇavacāriṇam
]

`v 13 [
kathaṃ ca dhīravaryāgnau patatāpi na dahyate |
pāvake pāradeneva rasena rasaśālinā
]

`v 14 [
yasmātkila jagatyasminvyavahārakriyā `note[kriyāṃ vinā] vinā |
na sthitiḥ saṃbhavatyabdhau patitasyājalā yathā
]

`v 15 [
rāgadveṣavinirmuktā sukhaduḥkhavivarjitā |
kṛśānordāhahīneva śikhā nāstīha satkriyā
]

`v 16 [
nanvastu durvyavahāre duḥkhaṃ satkriyāyāṃ tu na tatsaṃbhāvanetyā##-
manomananaśālinyāḥ sattāyā bhuvanatraye |
kṣayo yuktiṃ vinā nāsti brūta tāmalamuttamām
]

`v 17 [
vyavahāravato yuktyā duḥkhaṃ nāyāti me yayā |
athavā vyavahārasya brūta tāṃ yuktimuttamām
]

`v 18 [
tatkathaṃ kena vā kiṃ vā kṛtamuttamacetasā |
pūrvaṃ yenaiti viśrāmaṃ paramaṃ pāvanaṃ manaḥ
]

`v 19 [
yathā jānāsi bhagavaṃstathā mohanivṛttaye |
brūhi me sādhavo yena nūnaṃ nirduḥkhatāṃ gatāḥ
]

`v 20 [
athavā tādṛśī yuktiryadi brahmanna vidyate |
na vakti mama vā kaścidvidyamānāmapi sphuṭam
]

`v 21 [
svayaṃ caiva na cāpnomi tāṃ viśrāntimanuttamām |
tadahaṃ tyaktasarveho nirahaṃkāratāṃ gataḥ
]

`v 22 [
na bhokṣye na pibāmyambu nāhaṃ paridadhe'mbaram |
karomi nāhaṃ vyāpāraṃ snānadānāśanādikam
]

`v 23 [
na ca tiṣṭhāmi kāryeṣu saṃpatsvāpaddaśāsu `note[saṃpatsvāpatsu caiva
hi]   ca |
na kiṃcidapi vāñchāmi dehatyāgādṛte mune
]

`v 24 [
kevalaṃ vigatāśaṅko nirmamo gatamatsaraḥ |
mauna eveha tiṣṭhāmi lipikarmasvivārpitaḥ
]

`v 25 [
maune vāgādisarvavyavahārābhāve | lipikarmasu citrakriyāsu | arpito           likhitaḥ |
24 |
atha krameṇa saṃtyajya praśvāsocchvāsasaṃvidaḥ |
saṃniveśaṃ tyajāmīmamanarthaṃ dehanāmakam
]

`v 26 [
nāhamasya na me nānyaḥ śāmyāmyasnehadīpavat |
sarvameva parityajya tyajāmīdaṃ kalevaram
]

`v 27 [
vālmīkiruvāca |
ityuktavānamalaśītakarābhirāmo
rāmo mahattaravicāravikāsicetāḥ |
rūṣṇīṃ babhūva purato mahatāṃ ghanānāṃ
kekāravaṃ śramavaśādiva nīlakaṇṭhaḥ
]