`v 1 [
iti vāsiṣṭhamāhārāmāyaṇatātparyaprakāśe vairāgyaprakareṇe prathamaḥ
sagaraḥ
]

`v 2 [
vālmīkiruvāca |
ahaṃ baddho vimuktaḥ syāmiti yasyāsti niścayaḥ |
nātyantamajño `note[no tajjñaḥ] nota jñaḥ so'smiñchāstre'dhikāravān
]

`v 3 [
kathopāyānvicāryādau mokṣopāyānimānatha |
yo vicārayati prājño na sa bhūyo'bhijāyate
]

`v 4 [
asminrāmāyaṇe rāmakadhopāyānmahābalān |
etāṃstu prathamaṃ kṛtvā purāhamarimardana
]

`v 5 [
asminsāṃpratike ṣaṭpañcāśatsahasrasaṃmite rāmāyaṇe anādikālābhyasta##-
śiṣyāyāsmi `note[śiṣyāyāsmai] vinītāya bharadvājāya dhīmate |
ekāgro dattavāṃstasmai maṇimabdhirivārthine
]

`v 6 [
śiṣyaviśeṣaṇānyadhikārasaṃpattidyotakāni | eka evāgro `note[evāgraṃ]
grahaṇadhāraṇapracārapaṭuḥ pradhānaśiṣyo yasya sa tathā | anugrahaprema##-
tata ete kathopāyā bharadvājena dhīmatā |
kasmiṃścinmerugahane brahmaṇo'gra udāhṛtāḥ
]

`v 7 [
athāsya tuṣṭo bhagavānbrahmā lokapitāmahaḥ |
varaṃ putra gṛhāṇeti tamuvāca mahāśayaḥ
]

`v 8 [
bharadvāja uvāca |
bhagavanbhūtabhavyeśa varo'yaṃ me'dya rocate |
yeneyaṃ janatā duḥkhānmucyate tadudāhara
]

`v 9 [
bhūtaṃ pūrvamutpannama | bhavamutpatsyamānam | adya pūrvarāmāṇārthānu##-
śrībrahmovāca |
guruṃ vālmīkimatrāśu prārthayasva prayatnataḥ |
tenedaṃ yatsamārabdhaṃ rāmāyaṇamaninditam
]

`v 10 [
tasmiñchrute naro mohātsamagrātsaṃtariṣyati |
setunevāmbudheḥ pāramapāraguṇaśālinā
]

`v 11 [
śrīvālmīkiruvāca |
ityuktvā sa bharadvājaṃ parameṣṭhī madāśramam |
abhyāgacchatsamaṃ tena bharadvājena bhūtakṛt
]

`v 12 [
tūrṇaṃ saṃpūjito devaḥ so'rghyapādyādinā mayā |
avocanmāṃ mahāsattvaḥ sarvabhūtahite rataḥ
]

`v 13 [
yadyapi sṛṣṭau rajaḥ pradhānastathāpi jagaduddhārodbhūtakaruṇatvānmahā##-
rāmasvabhāvakathanādasmādvaramune tvayā |
nodvegātsa parityājya āsamāpteraninditāt
]

`v 14 [
granthenānena loko'yamasmātsaṃsārasaṃkaṭāt |
samuttariṣyati kṣipraṃ potenevāśu sāgarāt
]

`v 15 [
vaktuṃ tadevamevārthamahamāgatavānayam |
kuru lokahitārthaṃ tvaṃ śāstramityuktavānajaḥ
]

`v 16 [
mama puṇyāśramāttasmātkṣaṇādantarddhimāgatḥ |
muhūrtabhyutthitaḥ proccaistaraṅga iva vāriṇaḥ
]

`v 17 [
tasminprayāte bhagavatyahaṃ vismayamāgataḥ |
punastatra bharadvājamapṛcchaṃ svasthayā dhiyā
]

`v 18 [
svasthayā dhiyetyukteḥ purvaṃ prabmāgamanaharṣaviṣmayavyatracittatvādbra##-
kimetadbrahmaṇā proktaṃ bharadvāja vadāśu me |
ityuktena punaḥ proktaṃ bharadvājena tena me
]

`v 19 [
bharadvāja uvāca |
etaduktaṃ bhagavatā yathā rāmāyaṇaṃ kuru |
sarvalokahitārthāya saṃsārṇavatārakam
]

`v 20 [
mahyaṃ ca bhagavanbrūhi kathaṃ saṃsārasaṃkaṭe |
rāmo vyavahṛto hyasminbharataśca mahāmanāḥ
]

`v 21 [
śatrughno lakṣamaṇaścāpi sītā cāpi yaśasvinī |
rāmānuyāyinaste vā mantriputrā mahādhiyaḥ
]

`v 22 [
cakārāddaśarathaparigrahaḥ | cakāro'piśabdadvayaṃ ca tatparivārasamucca##-
`note[nirduḥkhatāṃ yathaite tu] nirduḥkhitāṃ yathaite nu
prāptāstadbrūhi me sphuṭam |
tathaivāhaṃ bhaviṣyāmi tato janatayā saha
]

`v 23 [
sphuṭaṃ madbodhaparyavasitam | janatayā tvadupadeśaśravaṇakṛtārthajana##-
bharadvājena rājendra vadetyukto'smi sādaram |
tadā kartuṃ vibhorājñāmahaṃ vaktuṃ pravṛttavān
]

`v 24 [
śṛṇu vatsa bharadvāja yathāpṛṣṭaṃ vadāmi te |
śrutena yena saṃmohamalaṃ dūre kariṣyasi
]

`v 25 [
saṃmoha ātmatattvāparijñānaṃ tadrūpaṃ malaṃ paṅkam | alamiti vā chedaḥ |
24 |
tathā vyavahara prājña yathā vyavahṛtaḥ sukhī |
sarvāsaṃsaktayā buddhyā rāmo rājīvalocanaḥ
]

`v 26 [
lakṣmaṇo bharataścaiva śatrughnaśca mahāmanāḥ |
kausalyā ca sumitrā ca sītā daśarathastathā
]

`v 27 [
kṛtāstraścā'virodhaśca bodhapāramupāgatāḥ |
vasiṣṭho vāmadevaśca mantriṇo'ṣṭau tathetare
]

`v 28 [
dhṛṣṭirjayanto bhāsaśca satyo vijaya eva ca |
vibhīṣaṇaḥ suṣeṇaśca hanumānindrajittathā
]

`v 29 [
ete'ṣṭau mantriṇaḥ proktāḥ samanīrāgacetasaḥ |
jīvanmuktā mahātmāno yathāprāptānuvartinaḥ
]

`v 30 [
etairyathā hutaṃ dattaṃ hṛhītamuṣitaṃ smṛtam |
tathā cedvartase putra mukta evāsi saṃkaṭāt
]

`v 31 [
hutaṃ dattamiti śrautasmārtakarmopalakṣaṇam | smṛtamityubhayagocarapūrvā##-
apārasaṃsārasamudrapātī `note[samudramadhye] labdhvā parāṃ
yuktimudārasattvaḥ |
na śokamāyāti na dainyameti gatajvarastiṣṭhati nityatṛptaḥ
]