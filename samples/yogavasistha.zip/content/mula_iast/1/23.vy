`v 1 [
trayoviṃśaḥ sargaḥ 23
śrīrāma uvāca |
vikalpakalpanānalpajalpitairalpabuddhibhiḥ |
bhedairuddhuratāṃ nītaḥ saṃsārakuhare bhramaḥ
]

`v 2 [
ramayansvavilāsaughaiḥ sarvaprāṇikriyāpriyām `note[kriyāparām] |
guṇadoṣabalotkarṣaiḥ kāla eko'tra varṇyate |
itthaṃ bhogyāyāḥ śriyo bhogatṛṣṇāyā bhogāvasarabhūtabālyādyava##-
svasyehāmutrārthaphalabhogavirāgo darśitaḥ | saṃprati kāmādisvabhāva##-
vikalpeti | mamedaṃ bhogyam ahamasya bhoktā imāni ca tatsādhanāni
anenedamitthaṃ saṃpādya ciraṃ bhokṣyāmi idamadya mayā labdhamimaṃ prāpsye
manoratham ityādyanantamanovikalpakalpanairanalpāni jalpitāni vyavahāravacanāni
yeṣāṃ taiḥ | slpe dehe ātmabuddhiralpeṣu sukhalaveṣu paramapuruṣārthabuddhiśca
yeṣāṃ tairmūḍhajanaiḥ | śatrumitrodāsīnādi##-
saṃsaratyasminniti saṃsāro brahmāṇḍaṃ tasya kuhare chidre bhramo'nyathā##-
satāṃ kathamivāstheha jāyate jālapañjare |
bālā evāttumicchanti phalaṃ mukurabimbitam
]

`v 3 [
ihāpi vidyate yeṣāṃ pelavā sukhabhāvanā |
ākhustantumivāśeṣaṃ kālastāmapi kṛntati
]

`v 4 [
iha īdṛśe'pi saṃsāre yeṣāṃ pelavā kṣudrā sukhabhāvanā sukhāśā
tāmākhurbilatṛṇāgrātkūpe lambamānaṃ tanmātrāvalambajijīviṣukīṭā##-
na tadastīha yadayaṃ kālaḥ sakalaghasmaraḥ |
grasate tajjagajjātaṃ protthābdhimiva vāḍavaḥ
]

`v 5 [
samastasāmānyatayā bhīmaḥ kālo maheśvaraḥ |
dṛśyasattāmimāṃ sarvāṃ kavalīkartumudyataḥ
]

`v 6 [
mahatāmapi no devaḥ pratipālayati kṣaṇam |
kālaḥ kavalitānantaviśvo viśvātmatāṃ gataḥ
]

`v 7 [
yugavatsarakalpākhyaiḥ kiṃcitprakaṭatāṃ gataḥ |
rūpairalakṣyarūpātmā sarvamākramya tiṣṭhati
]

`v 8 [
ye ramyā ye śubhārambhāḥ sumeruguravo'pi ye |
kālena vinigīrṇāste garuḍeneva pannagāḥ
]

`v 9 [
nirdayaḥ kaṭhinaḥ krūraḥ karkaśaḥ kṛpaṇo'dhamaḥ |
na tadasti yadadyāpi na kālo nigiratyayam
]

`v 10 [
kālaḥ kavalanaikāntamatiratti girannapi |
anantairapi lokoghairnāyaṃ tṛpto mahāśanaḥ
]

`v 11 [
haratyayaṃ nāśayati karotyatti nihanti ca |
kālaḥ saṃsāranṛttaṃ hi nānārūpaṃ yathā naṭaḥ
]

`v 12 [
bhinatti pravibhāgastha bhūtabījānyanāratam |
jagatyasattayā bandhāddāḍimāni yathā śukaḥ
]

`v 13 [
śubhāśubhaviṣāṇāgravilūnajanapallavaḥ |
sphūrjati sphītajanatājīvarājīvanīgajaḥ
]

`v 14 [
viriñcimūlabrahmāṇḍabṛhaddevaphaladrumam |
brahmakānanamābhogi paramāvṛtya tiṣṭhati
]

`v 15 [
yāminī bhramarāpūrṇā racayandinamañjarīḥ |
varṣakalpakalāvallīrna kadācana khidyate
]

`v 16 [
bhidyate `note[na ca bhagno'pi] nāvabhagno'pi dagdho'pi hi na dahyate |
dṛśyate nāpi dṛśyo'pi dhurtacūḍāmaṇirmune
]

`v 17 [
ekenaiva nimeṣeṇa kiṃcidutthāpayatyalam |
kiṃcidvināśayatyuccairmanorājyavadātataḥ
]

`v 18 [
durvilāsavilāsinyā ceṣṭayā kaṣṭapuṣṭayā |
draviaykarūpakṛdrūpaṃ janamāvartayansthitaḥ
]

`v 19 [
tṛṇaṃ pāṃsuṃ mahendraṃ ca sumeruṃ parṇamarṇavam |
ātmaṃbharitayā sarvamātmasātkartumudyataḥ
]

`v 20 [
krauryamatriva paryāptaṃ lubdhatātraiva saṃsthitā |
sarvadaurbhāgyamatraiva cāpalaṃ `note[cāpi] vāpi duḥsaham
]

`v 21 [
prerayaṁllīlayārkendū krīḍatīva nabhastale |
nikṣiptalīlāyugalo nije bāla ivāṅgaṇe
]

`v 22 [
sarvabhūtāsthimālābhirāpādavalitākṛtiḥ |
vilasatyeva kalpānte kālaḥ kalitakalpanaḥ
]

`v 23 [
asyoḍḍāmaravṛttasya kalpānte'ṅgavinirgataiḥ |
prasphuratyambare merurbhūrjatvagiva vāyubhiḥ
]

`v 24 [
rudro bhūtvā bhavatyeṣa mahendro'tha pitāmahaḥ |
śakro vaiśravaṇaścāpi punareva na kiṃcana
]

`v 25 [
dhatte'jasrotthitoddhvastānsargānamitabhāsvarān |
anyāndadhaddivānaktaṃ vīcīrabdhirivātmani
]

`v 26 [
mahākalpābhidhānebhyo vṛkṣebhyaḥ pariśātayan |
devāsuragaṇānpakvānphalabhārāniva sthitaḥ
]

`v 27 [
kālo'yaṃ bhūtamaśakaghuṃghumānāṃ prapātinām |
brahmāṇḍodumbaraughānāṃ vṛhatpādapatāṃ gataḥ
]

`v 28 [
sattāmātrakumudvatyā cijjyotsnāpariphullayā |
vapurvinodayatyekaṃ kriyāpriyatamānvitaḥ
]

`v 29 [
anantāpāraparyantabaddhapīṭha nijaṃ vapuḥ |
mahāśailavaduttuṅgamavalambya vyavasthitaḥ
]

`v 30 [
kvacicchyāmatamaḥśyāmaṃ kvacitkāntiyutaṃ tatam |
dvayenāpi kvacidriktaṃ svabhāvaṃ bhāvayan sthitaḥ
]

`v 31 [
saṃlīnāsaṃkhyasaṃsārasārayā svātmasattayā |
urvyeva bhāraghanayā nibaddhapadatāṃ gataḥ
]

`v 32 [
na khidyate nādriyate nāyāti na ca gacchati |
nāstameti na codeti mahākalpaśatairapi
]

`v 33 [
kevalaṃ jagadārambhalīlayā ghanahelayā |
pālayatyātmanātmānamanahaṃkāramātatam
]

`v 34 [
yāminīpaṅkakalitāṃ dinakokanadāvalīm |
`note[bhramarikāṃ svātma]
meghabhramarikāmātmasarasyāropayansthitaḥ
]

`v 35 [
gṛhītvā kṛpaṇaḥ kṛṣṇāṃ rajanīṃ jīrṇamārjanīm |
ālokakanakakṣodānāharatyabhito girim
]

`v 36 [
saṃārayankriyāṅgulyā koṇakeṣvarkadīpikām |
jagatsadmani kārpaṇyātkva kimastīti vīkṣate
]

`v 37 [
prakārāntareṇa tasya kārpaṇyamāha - saṃcārayanniti | koṇakeṣu dikkoṇeṣu |
36 |
prekṣyāharvinimeṣeṇa sūryākṣṇā pākavantyalam |
lokapālaphalānyatti jagajjīrṇavanādayam
]

`v 38 [
jagajjīrṇakuṭīkīrṇānarpayatyugrakoṭare |
krameṇa guṇavallokamaṇīnmṛtyusamudgake
]

`v 39 [
guṇairāpūryate yaiva lokaratnāvalī bhṛśam |
bhūṣārthamiva tāmaṅge kṛtvā bhūyo nikṛntanti
]

`v 40 [
dinahaṃsānusṛtayā niśendīvaramālayā |
tārakesarayājasraṃ capalo valayatyalam
]

`v 41 [
śailārṇadyudharāśṛṅgajagadūrṇāyusaunikaḥ |
pratyahaṃ pibate prekṣya tārāraktakaṇānapi
]

`v 42 [
tāruṇyanalinīsoma āyurmātaṅgakesarī |
na tadasti na yasyāyaṃ tucchātucchasya taskaraḥ
]

`v 43 [
kalpakelivilāsena piṣṭapātitajantunā |
abhāvo bhāvabhāsena ramate svātmanātmani
]

`v 44 [
kartā bhoktātha saṃhartā smartā sarvapadaṃ gataḥ
]

`v 45 [
sakalamapyakalākalitāntaraṃ subhagadurbhagarūpadharaṃ vapuḥ |
prakaṭayansahasaiva ca gopayan vilasatīha hi kālabalaṃ nṛṣu
]