`v 1 [
aṣṭāviṃśaḥ sargaḥ 28
śrīrāma uvāca |
yaccedaṃ dṛśyate kiṃcijjagatsthāvarajaṃgamam |
tatsarvamasthiraṃ brahmansvapnasaṃgamasaṃnibham
]

`v 2 [
śuṣkasāgarasaṃkāśo nikhāto yo'dya dṛśyate |
sa prātarabhrasaṃvīto nagaḥ saṃpadyate mune
]

`v 3 [
yo vanavyūhavistīrṇo vilīḍhagagano mahān `note[gagano'calaḥ] |
dinaireva sa yātyurvīsamatāṃ kūpatāṃ ca vā
]

`v 4 [
yadaṅgamadya saṃvītaṃ kauśeyasragvilepanaiḥ |
digambaraṃ tadeva śvo dūre viśaritā'vaṭe
]

`v 5 [
yatrādya nagaraṃ dṛṣṭaṃ vicitrācāracaṅcalam |
tatraivodeti divasaiḥ saṃśūnyāraṇyadharmatā
]

`v 6 [
yaḥ pumānadya tejasvī maṇḍalānyadhitiṣṭhati |
sa bhasmakūṭatāṃ rājandivasairadhigacchati
]

`v 7 [
araṇyāni mahābhīmā yā nabhomaṇḍalopamā |
patākācchāditākāśā saiva saṃpadyate purī
]

`v 8 [
yā latāvalitā bhīmā bhātyadya vipināvalī |
divasaireva sā yāti punarmarumahīpadam
]

`v 9 [
salilaṃ sthalatāṃ yāti sthalībhavati vāribhūḥ |
viparyasyati sarvaṃ hi sakāṣṭhāmbutṛṇaṃ jagat
]

`v 10 [
anityaṃ yauvanaṃ bālyaṃ śarīraṃ dravyasaṃcayāḥ |
bhāvādbhāvāntaraṃ yānti taraṅgavadanāratam
]

`v 11 [
vātāntardīpakaśikhālolaṃ jagati jīvitam |
taḍitsphuraṇasaṃkāśā padārthaśrīrjagatraye
]

`v 12 [
viparyāsamiyaṃ yāti bhūribhūtaparamparā |
bījarāśirivājastraṃ pūryamāṇaḥ punaḥpunaḥ
]

`v 13 [
manaḥpavanaparyastabhūribhūtarajaḥpaṭā |
pātotpātaparāvartaparābhinayabhūṣitā
]

`v 14 [
ālakṣyate sthitiriyaṃ jāgatī janitabhramā |
nṛttāveśavivṛtteva saṃsārārabhaṭīnaṭī
]

`v 15 [
gandharvanagarākāraviparyāsavidhāyinī |
apāṅgabhaṅgurodāravyavahāramanoramā
]

`v 16 [
tāmeva varṇayati dvābhyām - gandharveti | viparyāso bhrāntiḥ
vaṃśanaṭīnāṃ netrapidhānagāruḍavidyā prasiddhā | apāṅgāviva
bhaṅguraiścapalairapāṅga-pātaiśca bhaṅgurairvyavahārairmanoramā | 15
|
taḍittaralamāmolamātanvānā punaḥpunaḥ |
saṃsāraracanā rājannṛttasakteva rājate
]

`v 17 [
divāsāste mahāntaste saṃpadastāḥ kriyāśca tāḥ |
sarvaṃ smṛtipathaṃ yātaṃ yāmo vayamapi kṣaṇāt
]

`v 18 [
pratyahaṃ kṣayamāyāti pratyahaṃ jāyate punaḥ |
adyāpi hatarūpāyā nānto'syā dagdhasaṃsṛteḥ
]

`v 19 [
triyaktvaṃ puruṣā yānti tiryañco naratāmapi |
devāścādevatāṃ yānti kimiveha vibho sthiram
]

`v 20 [
racayanraśmijālena rātryahāni punaḥpunaḥ |
atibāhya raviḥ kālo vināśavadhimīkṣate
]

`v 21 [
brahmāviṣṇuśca rudraśca sarvā vā bhūtajātayaḥ |
nāśamevānudhāvanti salilānīva vāḍavam
]

`v 22 [
dyauḥ kṣamā vāyurākāśaṃ parvatāḥ sarito diśaḥ |
vināśavāḍavasyaitatsarvaṃ saṃśuṣkamindhanam
]

`v 23 [
dhanāni bāndhavā bhṛtyā mitrāṇi vibhavāśca ye |
vināśabhayabhītasya sarvaṃ nīrasatāṃ gatam
]

`v 24 [
svadante tāvadevaite bhāvā jagati dhīmate |
yāvatsmṛtipathaṃ yāti na vināśakurākṣasaḥ
]

`v 25 [
kṣaṇamaiśvaryamāyāti kṣaṇameti daridratām |
kṣaṇaṃ vigatarogatvaṃ kṣaṇamāgatarogatām
]

`v 26 [
pratikṣaṇaviparyāsadāyinā nihatātmanā |
jagadbhrameṇa ke nāma dhīmanto hi na mohitāḥ
]

`v 27 [
tamaḥpaṅkasamālabdhaṃ kṣaṇamākāśamaṇḍalam |
kṣaṇaṃ kanakaniṣyandakomalālokasundaram
]

`v 28 [
kṣaṇaṃ jaladanīlābjamālāvalitakoṭaram |
kṣaṇamuḍḍāmararavaṃ kṣaṇaṃ mūkamiva `note[mūkamavasthitam]
sthitam
]

`v 29 [
kṣaṇaṃ tārāviracitaṃ kṣaṇamarkeṇa bhūṣitam |
kṣaṇamindukṛtāhlādaṃ kṣaṇaṃ sarvabahiṣkṛtam
]

`v 30 [
āgamāpāyaparayā kṣaṇasaṃsthitināśayā |
na bibheti hi saṃsāre dhīro'pi `note['dhika iva] ka ivānayā
]

`v 31 [
āpadaḥ kṣaṇamāyānti kṣaṇamāyānti saṃpadaḥ |
kṣaṇaṃ janma kṣaṇaṃ mṛtyurmune kimiva na kṣaṇam
]

`v 32 [
prāgāsīdanya eveha jātastvanyo naro dinaiḥ |
sadaikarūpaṃ bhagavankiṃcidasti na susthiram
]

`v 33 [
ghaṭasya paṭatā dṛṣṭā paṭasyāpi ghaṭasthitiḥ |
na tadasti na yaddṛṣṭaṃ viparyasyati saṃsṛtau
]

`v 34 [
tanotyutpādayatyatti nihatyāsṛjati kramāt |
satataṃ rātryahānīva nivartate naraṃ prati
]

`v 35 [
aśūreṇa hataḥ śūra ekenāpi hataṃ śatam |
prākṛtāḥ prabhutāṃ yātāḥ sarvamāvartyate jagat
]

`v 36 [
janateyaṃ viparyāsamajasramanugacchati |
jaḍaspandaparāmarśāttaraṅgāṇāmivāvalī
]

`v 37 [
janatā cetanasamūhaḥ jaḍasyācetanasya prāṇakaraṇādeḥ | ḍalayorabhedā##-
bālyamalpadinaireva yauvanaśrīstato jarā |
dehe'pi naikarūpatvaṃ kāsthā bāhyeṣu vastuṣu
]

`v 38 [
kṣaṇamānanditāmeti kṣaṇameti viṣāditām |
kṣaṇaṃ saumyatvamāyāti sarvasminnaṭavanmanaḥ
]

`v 39 [
itaścānyaditaścānyaditaścānyadayaṃ vidhiḥ |
racayanvastunāyāti khedaṃ līlāsvivārbhakaḥ
]

`v 40 [
cinotyutpādayatyatti nihatyāsṛjati kramāt |
satataṃ rātryahānīva nivartante naraṃ prati
]

`v 41 [
āvirbhāvatirobhāvabhāgino bhavabhātinaḥ |
janasya sthiratāṃ yānti nāpado na ca saṃpadaḥ
]

`v 42 [
kālaḥ krīḍatyayaṃ prāyaḥ sarvamāpadi pātayan |
helāvicalitāśeṣacaturācāracañcuraḥ
]

`v 43 [
samaviṣamavipākato vibhinnāstribhuvanabhūtaparamparāphalaughāḥ |
samayapavanapātitāḥ patanti pratidinamātatasaṃsṛtidrumebhyaḥ
]