`v 1 [
dvātriṃśaḥ sargaḥ 32
śrīvālmīiruvāca |
vadatyevaṃ manomohavinivṛttikaraṃ vacaḥ |
rāme rājīvapatrākṣe tasminrājakumārake
]

`v 2 [
sarve babhūvustatrasthā vismayotphullalocanāḥ |
bhinnāmbarā deharuhairgiraḥ śrotumivoddhuraiḥ
]

`v 3 [
virāgavāsanāpāstasamastabhavavāsanāḥ |
muhūrtamamṛtāmbhodhivīcīvilulitā iva
]

`v 4 [
tā giro rāmabhadrasya tasya citrārpitairiva |
saṃśrutā śṛṇukairantarānandapadapīvaraiḥ
]

`v 5 [
śṛṇukaiḥ śravaṇasamartaiḥ | ānandasya padena lakṣmaṇā pīvaraiḥ puṣṭaiḥ | 4
|
vasiṣṭhaviśvāmitrādyairmunibhiḥ saṃsadi sthitaiḥ |
jayantadhṛṣṭipramukhairmantribhirmantrakovidaiḥ
]

`v 6 [
nṛpairdaśarathaprakhyaiḥ pauraiḥ pāraśavādibhiḥ |
sāmantai rājaputraiśca brāhmaṇairbrahmavādibhiḥ
]

`v 7 [
tathā bhṛtyairamātyaiśca pañcarasthaiśca pakṣibhiḥ |
krīḍāmṛgairgataspandaisturaṅgaistyaktacarvaṇaiḥ
]

`v 8 [
kausalyāpramukhaiścaiva nijavātāyanasthitaiḥ |
saṃśāntabhūṣaṇārāvairaspandairvanitāgaṇaiḥ
]

`v 9 [
udyānavallinilayairviṭaṅkanilayairapi |
akṣubdhapakṣatatibhirvihaṅgairviratāravaiḥ
]

`v 10 [
siddhairnabhaścaraiścaiva tathā gandharvakinnaraiḥ |
nāradavyāsapulahapramukhairmunipuṅgavaiḥ
]

`v 11 [
anyaiśca devadeveśavidyādharamahoragaiḥ |
rāmasya tā vicitrārthā mahodārā giraḥ śrutāḥ
]

`v 12 [
atha tūṣṇīṃ sthitavati rāme rājīvalocane |
tasminraghukulākāśaśaśāṅke śaśisundare
]

`v 13 [
sādhuvādagirā sārdhaṃ siddhasārthasamīritā |
vitānakasamā vyomnaḥ pauṣpī vṛsṭiḥ papāta ha
]

`v 14 [
mandārakośaviśrāntabhramadvandvanādinī |
madhurāmodasaundaryamuditonmadamānavā
]

`v 15 [
vyomavātavinunneva tārakāṇāṃ paramparā |
patitameva dharāpīṭhe svargastrīhasitacchaṭā
]

`v 16 [
`note[vṛṣṭamūka] vṛṣyamūkakacanmeghalavāvaliriva cyutā |
haiyaṃgavīnapiṇḍānāmīriteva paramparā
]

`v 17 [
himavṛṣṭirivodārā muktāhāracayopamā |
aindavī raśmimāleva kṣīrormīṇāmivātatiḥ
]

`v 18 [
kiñjalkāmbhojavalitā bhramadbhṛṅgakadambakā |
sītkāragāyadāmodimadhurānilalolitā
]

`v 19 [
prabhramatketakīvyūhā prasphūratkairavotkarā |
prapatatkundavalayā calatkuvalayālayā
]

`v 20 [
āpūritāṅgaṇarasā gṛhācchādanacatvarā |
ugdrīvapuravāstavyanaranārīvilokitā
]

`v 21 [
nirabhrotpalasaṃkāśavyomavṛṣṭiranākulā |
adṛṣṭapūrvā sarvasya janasya janitasmayā
]

`v 22 [
nirabhramata evotpalasaṃkāśaṃ yadvyoma tataḥ patitā vṛṣṭirvarṇi (rṣi##?
adṛśyāmbarasiddhaughakarotkarasamīritā |
sā muhūrtacaturbhāgaṃ puṣpavṛṣṭiḥ papāta ha
]

`v 23 [
āpūritasabhāloke śānte kusumavarṣaṇe |
imaṃ siddhagaṇālāpaṃ śuśruvuste sabhāgatāḥ
]

`v 24 [
ākalpaṃ siddhasenāsu bhramadbhirabhitodivam |
apūrvamidamasmābhiḥ śrutaṃ śrutirasāyanam
]

`v 25 [
yadanena kilodāramuktaṃ raghukulendunā |
vītarāgatayā taddhi vākpaterapyagocaram
]

`v 26 [
aho bata mahatpuṇyamadyāsmābhiridaṃ śrutam |
vaco rāmamukhodbhūtaṃ mahāhlādakaraṃ dhiyaḥ
]

`v 27 [
upaśamāmṛtasundaramādarādadhigatottamatāpadameṣa yat |
kathitavānucitaṃ raghunandanaḥ sapadi tena vyayaṃ pratibodhitāḥ
]