`v 1 [
dvādaśaḥ sargaḥ 12
vālmīkiruvāca |
iti pṛṣṭo munīndreṇa samāśvasya ca rāghavaḥ |
uvāca vacanaṃ cāru paripūrṇārthamantharam
]

`v 2 [
śrīrāma uvāca |
bhagavanbhavatā pṛṣṭo yathāvadadhunā'khilam |
kathayāmyahamajño'pi ko laṅghayati sadvacaḥ
]

`v 3 [
ahaṃ tāvadayaṃ jāto nije'sminpitṛsadmani |
kremaṇa vṛddhiṃ saṃprāptaḥ prāptavidyaśca saṃsthitaḥ
]

`v 4 [
tataḥ sadācāraparo bhūtvāhaṃ munināyaka |
vihṛtastīrthayātrārthamurvīmambudhimekhalām
]

`v 5 [
etāvatātha kālena saṃsārāsthāmimāṃ haran |
samudbhūto manasi me vicāraḥ so'yamīdṛśaḥ
]

`v 6 [
vivekena parītātmā tenāhaṃ tadanu svayam |
bhoganīrasayā buddhyā pravicāritavānidam
]

`v 7 [
kiṃnāmedaṃ bata sukhaṃ yeyaṃ saṃsārasaṃtatiḥ |
jāyate mṛtaye loko mriyate jananāya ca
]

`v 8 [
asthirāḥ sarva eveme sacarācaraceṣṭitāḥ |
āpadāṃ patayaḥ pāpā bhāvā vibhavabhūmayaḥ
]

`v 9 [
ayaḥśalākāsadṛśāḥ parasparamasaṅginaḥ |
śliṣyante kevalaṃ bhāvā manaḥkalpanayā svayā
]

`v 10 [
yadi na te sukhadāstarhi kathaṃ sukhakārakatvena parasparaṃ saṃbadhyante tatrāha
- aya iti | sarve'pi bhāvāḥ svato lohaśalākāḥ sūcyādaya iva
parasparamasaṅginaḥ saṃbandhaśunyā eva paraṃtu anayā mamedaṃ
bhogasādhanamanenetthamidaṃ kariṣyāmītyādimanaḥkalpanayā kevalaṃ
kriyākārakādibhāvena śliṣyante saṃbandhyante | tathaivānvayavyatireka##-
manaḥ samāyattamidaṃ jagadābhogi dṛśyate |
manaścāsadivābhāti kena `note[kena smaḥ] sma parimohitāḥ
]

`v 11 [
asataiva vayaṃ kaṣṭaṃ vikṛṣṭā mūḍhabuddhayaḥ |
mṛgatṛṣṇāmbhasā dūre vane mugdhamṛgā iva
]

`v 12 [
na kenacicca vikrītā vikrītā iva saṃsthitāḥ |
bata mūḍhā vayaṃ sarve jānānāṃ api śāmbaram
]

`v 13 [
kimeteṣu prapañceṣu bhogā nāma sudurbhagāḥ |
mudhaiva hi vayaṃ mohātsaṃsthitā baddhabhāvanāḥ
]

`v 14 [
ā jñātaṃ bahukālena vyarthameva vayaṃ vane |
mohe nipatitā mugdhāḥ śvabhre mugdhā mṛgā iva
]

`v 15 [
kiṃ me rājyena kiṃ bhigaiḥ ko'haṃ kimidamāgatam |
yanmithyaivāstu tanmithyā kasya nāma kimāgatam
]

`v 16 [
evaṃ vimṛśato brahmansarveṣveva tato mama |
bhāveṣvaratirāyātā pathikasya maruṣviva
]

`v 17 [
tadetadbhagavanbrūhi kimidaṃ pariṇaśyati |
kimidaṃ jāyate bhūyaḥ kimidaṃ parivardhate
]

`v 18 [
jarāmaraṇamāpacca jananaṃ saṃpadastathā |
āvirbhāvatirobhāvairvivardhante `note[vivardhanti] punaḥ punaḥ
]

`v 19 [
bhogaistaireva taireva tucchairvayamamī kila |
paśya jarjaratāṃ nītā vātairiva giridrumāḥ
]

`v 20 [
acetanā iva janāḥ pavanaiḥ prāṇanāmabhiḥ |
dhvanantaḥ saṃsthitā vyarthaṃ yathā kīcakaveṇavaḥ
]

`v 21 [
śāmyatīdaṃ kathaṃ duḥkhamiti tapto'smi cintayā |
jaraddruma ivogreṇa koṭarasthena vahninā
]

`v 22 [
saṃsāraduḥkhapāṣāṇanīrandhrahṛdayo'pyaham |
nijalokabhayādeva galadbāṣpaṃ na rodimi
]

`v 23 [
śūnyā manmukhavṛttīstāḥ śuṣkarodananīrasāḥ |
viveka eva hṛtsaṃstho mamaikānteṣu paśyati
]

`v 24 [
bhṛśaṃ muhyāmi saṃsmṛtya bhāvābhāvamayīṃ sthitim |
dāridryeṇeva subhago dūre saṃsāraceṣṭayā
]

`v 25 [
mohayanti manovṛttiṃ khaṇḍayanti guṇāvalim |
duḥkhajālaṃ prayacchanti vipralambhaparāḥ śriyaḥ
]

`v 26 [
cintānicayacakrāṇi nānandāya dhanāni me |
saṃprasūtakalatrāṇi gṛhāṇyugrāpadāmiva
]

`v 27 [
tadeva prapañcayati - cinteti | dhaninaścintādhārābhistilaśaḥ khaṇḍanena
nicayāya rāśīkaraṇāya pravṛttāni cakrāṇi | ugrāpadāṃ dāridryaśatru##-
vividhadoṣadaśāparicintanairvitatabhaṅgurakāraṇakalpitaiḥ |
mama na nirvṛtimeti mano mune nigaḍitasya yathā vanadantinaḥ
]

`v 28 [
khalāḥ kālekāle niśi niśitamohaikamihikā-
gatāloke loke viṣayaśatacaurāḥ sucaturāḥ |
pravṛtāḥ prodyuktā diśidiśi vivekaikaharaṇe
raṇe śaktāsteṣāṃ ka iva viduṣaḥ projjhya subhaṭāḥ
]