`v 1 [
dvāviṃśaḥ sargaḥ 22
śrīrāma uvāca |
aparyāptaṃ hi bālatvaṃ balātpibati yauvanam |
yauvanaṃ ca jarā paścātpaśya karkaśatāṃ mithaḥ
]

`v 2 [
śokamohaviyogārtiviṣādagadasaṃkulam |
cintāparibhavasthānaṃ vṛddhatvamiha nindyate |
nanu kāmādidoṣaprābalyānmāstu yauvane sukham vṛddhāvasthāyāṃ tu
tadupaśāntau vinītaiḥ putrapautrādibhirgṛhe sevyamānasya bahutaraṃ sukhaṃ
bhaviṣyatītyāśaṅkya tatra duḥkhasthānāmānantyaṃ vistareṇa vivakṣuḥ
prathamaṃ svakulagrāsisarpāṇāṃ dayā parakule kutaḥ iti nyāyena karka##-
1 |
himāśanirivāmbhojaṃ vātyeva śaradambukam `note[dambujaṃ] |
dehaṃ jarā nāśayati nadī tīrataruṃ yathā
]

`v 3 [
pāmarāṇāṃ paramapremāspadasukhāyatanasya dehasyaiva śithilīkaraṇe kva tatra
sukhapratyāśetyāha - himāśanirivetyādinā | himamaśanirvajramiveti
himāśaniḥ | `note[dambujaṃ] ambukamambukaṇaṃ tṛṇāgrasthamiti yāvat |
2 |
jarjarīkṛtasarvāṅgī jarā jaraṭharūpiṇī |
virūpatāṃ nayatyāśu dehaṃ viṣalavo yathā
]

`v 4 [
`note[dīrghasarvāṅgaṃ] śidhilādīrṇasarvāṅgaṃ jarājīrṇakalevaram |
samaṃ paśyanti kāminyaḥ puruṣaṃ karabhaṃ yathā
]

`v 5 [
anāyāsakadarthinyā gṛhīte jarasā jane |
palāyya gacchati prajñā sapatnyevāhatāṅganā
]

`v 6 [
dāsāḥ putrāḥ striyaścaiva bāndhavāḥ suhṛdastathā |
hasantyunmattakamiva naraṃ vārdhakakampitam
]

`v 7 [
duṣprekṣyaṃ jaraṭhaṃ dīnaṃ hīnaṃ guṇaparākramaiḥ |
gṛdho vṛkṣamivādīrghaṃ gardho hyabhyeti vṛddhakam
]

`v 8 [
ādīrghamatidīrgham | gardho'bhilāṣātiśayaḥ | vṛkṣapakṣe saphalaśākhā##-
dainyadoṣamayī dīrghā hṛdi dāhapradāyinī |
sarvāpadāmekasakhī vārdhake vardhate spṛhā
]

`v 9 [
kartavyaṃ kiṃ mayā kaṣṭaṃ paratretyatidāruṇam |
apratīkārayogyaṃ hi vardhate vārdhake bhayam
]

`v 10 [
ko'haṃ varākaḥ kimiva karomi kathameva ca |
tiṣṭhāmi kaunameveti dīnatodeti vārdhake
]

`v 11 [
ko'hamityādirdīnatāyā evollekhaḥ | kiṃkathaṃśabdau sādhyasādhanacintā##-
kathaṃ kadā me kimiva svādu syādbhojanaṃ `note[janāditi] janāt |
ityajasraṃ jarā caiṣā ceto dahati vārdhake
]

`v 12 [
gardho'bhyudeti sollāsamupabhoktuṃ na śakyate |
hṛdayaṃ dahyate nūnaṃ śaktidausthyena vārdhake
]

`v 13 [
bhoktuṃ śaktau jaraṇāśaktistacchaktau bhoktumaśaktirityādiśaktidausthyam | 12
|
jarājīrṇabakī yāvatkāyakleśāpakāriṇī |
rauti rogoragākīrṇā kāyadrumaśiraḥsthitā
]

`v 14 [
tāvadāgata evāśu kuto'pi paridṛśyate |
ghanāndhyatimirākāṅkṣī mune maraṇakauśikaḥ
]

`v 15 [
sāyaṃsaṃdhyāṃ prajātāṃ vai tamaḥ samanudhāvati |
jarāṃ vapuṣi dṛṣṭvaiva mṛtiḥ samanudhāvati
]

`v 16 [
jarākusumitaṃ dehadrumaṃ dṛṣṭvaiva dūrataḥ |
adhyāpatati vegena mune maraṇamarkaṭaḥ
]

`v 17 [
śūnyaṃ nagaramābhāti bhāti cchinnalato drumaḥ |
bhātyanāvṛṣṭimāndeśo na jarājarjaraṃ vapuḥ
]

`v 18 [
kṣaṇānnigaraṇāyaiva kāsakvaṇitakāriṇī |
gṛdhrīvāmiṣamādatte tarasaiva naraṃ jarā
]

`v 19 [
dṛṣṭvaiva sotsukevāśu pragṛhya śirasi kṣaṇam |
pralunāti jarā dehaṃ kumārī kairavaṃ yathā
]

`v 20 [
sītkārakāriṇī pāṃsuparuṣā parijarjaram |
śarīraṃ śātayatyeṣā vātyeva tarupallavam
]

`v 21 [
jarasopahato deho dhatte jarjaratāṃ gataḥ |
tuṣāranikarākīrṇaparimlānāmbujaśriyam
]

`v 22 [
jarā jyotsnoditaiveyaṃ śiraḥśikharipṛṣṭhataḥ |
vikāsayati saṃrabdhaṃ vātakāsakumudvatī
]

`v 23 [
paripakvaṃ samālokya jarākṣāravidhūsaram |
`note[kūśmāṇḍetyubhayatra] śiraḥkūṣmāṇḍakaṃ bhuṅkte puṃsāṃ
kālaḥ kileśvaraḥ
]

`v 24 [
jarājahnusutodyuktā mūlānyasya nikṛntati |
śarīratīravṛkṣasya calatyāyuṣi satvaram
]

`v 25 [
jahnusuta gaṅgā | avirāmādudyukteva | āyuṣi āyuḥpravāhe satvaraṃ calati sati | 24
|
jarāmārjārikā bhuṅkte yauvanākhuṃ tathoddhatā |
paramullāsamāyāti śarīrāmiṣagardhinī
]

`v 26 [
kācidasti jagatyasminnāma"galakarī tathā |
yathā jarākrośakarī dehajaṅgalajambukī
]

`v 27 [
kāsaśvāsasasītkārā duḥkhadhūmatamomayī |
jarājvālā jvalatyeṣā yasyāsau dagdha eva hi
]

`v 28 [
jarasā vakratāmeti śuklāvayavapallavā |
tāta tanvī tanurnṝṇāṃ latā puṣpānatā yathā
]

`v 29 [
jarākarpūradhavalaṃ dehakarpūrapādapam |
mune maraṇamātaṅgo nūnamuddharati kṣaṇāt
]

`v 30 [
maraṇasya mune rājño jarādhavalacāmarā |
āgacchato'gre niryāti svādhivyādhipatākinī
]

`v 31 [
na jitāḥ śatrubhiḥ saṃkhye praviṣṭā ye'drikoṭare |
te jarājīrṇarākṣasyā paśyāśu vijitā mune
]

`v 32 [
jarātuṣāravalite śarīrasadanāntare |
śaknuvantyakṣaśiśavaḥ spandituṃ na manāgapi
]

`v 33 [
daṇḍatṛtīyapādena praskhalantī muhurmuhuḥ |
kāsādhovāyumurajā jarā yoṣitpranrtyati
]

`v 34 [
saṃsārasaṃsṛterasyā gandhakuṭyāṃ śirogatā |
dehayaṣṭyāṃ jarānāmnī cāmaraśrīrvirājate
]

`v 35 [
jarācandrodayasite śarīranagare sthite |
kṣaṇādvikāsamāyāti mune maraṇakairavam
]

`v 36 [
jarāsudhālepasite śarīrāntaḥpurāntare |
aśaktirārtirāpacca tiṣṭhanti sukhamaṅganāḥ
]

`v 37 [
abhāvo'gresarī yatra jarā jayati jantuṣu |
kastatreha samāśvāso mama mandamatermune
]

`v 38 [
yatra yeṣu jantuṣu caturvidhaśarīreṣu prathamaṃ jarā jayatyabhibhavati | agre ca
abhāvo mṛtyuḥ saraṇaṃ saraḥ saro'syāstīti sarī | avaśyamāgantetyarthaḥ |
abhāvāgresarīti pāṭhaścetspaṣṭaḥ | tatra teṣu śarīreṣu madhye ihāsmin śarīre
mama kaḥ samāśvāso visrambhaḥ | nanu vasiṣṭhādīnāmapi tulyametadityā##-
kiṃ tena durjīvitadurgraheṇa jarāgatenāpi hi jīvyate yat |
jarājagatyāmajitā janānāṃ sarvaiṣaṇāstāt tiraskaroti
]