`v 1 [
daśamaḥ sargaḥ 10
vālmīkiruvāca |
tathā vasiṣṭhe bruvati rājā daśarathaḥ sutam |
saṃprahṛṣṭamanā rāmamājuhāva salakṣmaṇam
]

`v 2 [
daśaratha uvāca |
pratihāraṃ mahābāhuṃ rāmaṃ satyaparākramam |
salakṣmaṇamavighnena puṇyārthaṃ śīghramānaya
]

`v 3 [
iti rājñā visṛṣṭo'sau gatvāntaḥpuramandiram |
muhūrtamātreṇāgatya samuvāca mahīpatim
]

`v 4 [
deva dordalitāśeṣaripo rāmaḥ svamandire |
vimanāḥ saṃsthito rātrau ṣaṭpadaḥ kamale yathā
]

`v 5 [
āgacchāmi kṣaṇeneti vakti dhyāyati caikataḥ |
na kasyacicca nikaṭe sthātumicchati khinnadhīḥ
]

`v 6 [
ityuktastena bhūpālastaṃ rāmānucaraṃ janam |
sarvamāśvāsayāmāsa papraccha ca yathākramam
]

`v 7 [
kathaṃ kīdṛgvidho rāma iti pṛṣṭo mahībhṛtā |
rāmabhṛtyajanaḥ khinno vākyamāha mahīpatim
]

`v 8 [
deyahaṣṭimimāṃ deva dhārayanta ime vayam |
khinnāḥ khede parimlānatanau rāme sute tava
]

`v 9 [
rāmo rājīvapatrākṣo yataḥprabhṛti cāgataḥ |
saviprastīrthayātrāyāstataḥprabhṛti durmanāḥ
]

`v 10 [
rājīvaṃ kamalam | yato yasmāddinātprabhṛtyāgatastiṣṭhatīti padamadhyā##-
āgatastataḥ-prabhṛtītyetāvataiva siddheḥ | sthitestu
prātyahikatvāddaurmanasyavadastyevādhi##-
yatnaprārthanayāsmākaṃ nijavyāpāramāhnikam |
so'yamāmlānavadanaḥ `note[sāyamamlān] karoti na karoti vā
]

`v 11 [
snānadevārcanādānabhojanādiṣu durmanāḥ |
prārthito'pi he nātṛpteraśnātyaśanamīśvaraḥ
]

`v 12 [
lolāntaḥpuranārībhiḥ kṛtadolābhiraṅgaṇe |
naca krīḍati līlābhirdhārābhiriva cātakaḥ
]

`v 13 [
māṇikyamukulaprotā keyūrakaṭakāvaliḥ |
nānandayati taṃ rājandyauḥ pātaviṣayaṃ yathā
]

`v 14 [
mukulākārairmāṇikyaiḥ protā khacitā | dyauḥ svargaḥ | pātaviṣayamāsanna##-
krīḍadvadhūvilokeṣu vahatkusumavāyuṣu |
latāvalayageheṣu bhavatyativiṣādavān
]

`v 15 [
yaddravyamucitaṃ svādu peśalaṃ cittahāri ca |
bāṣpapūrṇekṣaṇa iva tenaiva parikhidyate
]

`v 16 [
ucitamupabhoge lokaśāstrāviruddham | peśalaṃ caturam | cittahāri manoharam | 15
|
kimimā duḥkhadāyinyaḥ prasphūrantīḥ purāṅganāḥ |
iti `note[nṛtyavilāseṣu] nṛttavilāseṣu kāminīḥ parinindati
]

`v 17 [
bhojanaṃ śayanaṃ yānaṃ vilāsaṃ snānamāsanam |
unmattaceṣṭita iva nābhinandatyaninditam
]

`v 18 [
kiṃ saṃpadā kiṃ vipadā kiṃ gehena kimiṅgitaiḥ |
sarvamevāsadityuktvā `note[tyuktyā] tūṣṇīmeko'vatiṣṭhate
]

`v 19 [
nodeti parihāseṣu na bhogeṣu nimajjati |
na ca tiṣṭhati kāryeṣu maunamevāvalambate
]

`v 20 [
udeti hṛṣyati | nimajjati sajjate | kāryeṣvārambheṣu na tiṣṭhatyāsthāṃ na karoti |
19 |
vilolālakavallaryo helāvalitalocanāḥ |
nānandayanti taṃ nāryo mṛgyo vanataruṃ yathā
]

`v 21 [
ekānteṣu diganteṣu tīreṣu vipineṣu ca |
ratimāyātyaraṇyeṣu vikrīta iva jantuṣu
]

`v 22 [
vastrapānāśanādānaparāṅmukhatayā tayā |
parivrāḍdharmiṇaṃ bhūpaṃ so'nuyāti tapasvinam
]

`v 23 [
eka eva vasandeśe janaśūnye janeśvara |
na hasatyekayā buddhyā na gāyati na roditi
]

`v 24 [
baddhapadmāsanaḥ śūnyamanā vāmakarasthale |
kapolatalamādhāya kevalaṃ paritiṣṭhati
]

`v 25 [
nābhimānamupādatte naca vāñchati rājatām |
nodeti nāstamāyāti sukhaduḥkhānuvṛttiṣu
]

`v 26 [
udayāstamayāvatra prasādaviṣādau | sukhaduḥkhānuvṛttiṣviṣṭāniṣṭa##-
na vidmaḥ kimasau yāti kiṃ karoti kimīhate |
kiṃ dhyāyati kimāyāti kathaṃ kimanudhāvati
]

`v 27 [
pratyaha. kṛśatāmeti pratyahaṃ yāti pāṇḍutām |
virāgaṃ pratyahaṃ yāti śaradanta iva drumaḥ
]

`v 28 [
anuyātau tathaivaitau rājañchatrughnalakṣmaṇau |
tādṛśāveva tasyaiva pratibimbāviva sthitau
]

`v 29 [
bhṛtyai rājabhirambābhiḥ saṃpṛṣṭo'pi punaḥ punaḥ |
uktvā na kiṃcideveti tūṣṇīmāste nirīhitaḥ
]

`v 30 [
āpātamātrahṛdyeṣu mā bhogeṣu manaḥ kṛthāḥ |
iti pārśvagataṃ bhavyamanu"āsti suhṛjjanam
]

`v 31 [
nānāvibhavaramyāsu strīṣu goṣṭhīgatāsu ca |
purasthitamivāsneho nāśamevānupaśyati
]

`v 32 [
nītamāyuranāyāsapadaprāptivivarjitaiḥ |
ceṣṭitairiti kākalyā bhūyobhūyaḥ pragāyati
]

`v 33 [
samrāḍbhaveti pārśvasthaṃ vadantamanujīvinam |
pralapantamivonmattaṃ hasatyanyamanā muniḥ
]

`v 34 [
yeneṣṭaṃ rājasūyena maṇḍalasyeśvaraśca yaḥ | śāsti yaścājñayā rājñaḥ sa
samrāṭ | anyamanā iti | samyaksvaprakāśatayā rājata iti samrāṭ
paramātmetyarthāntare mano yasyetyarthaḥ | tasya cāparijñānmunistatparyālo##-
na proktamākarṇayati īkṣate na purogatam |
karotyavajñāṃ sarvatra susametyāpi vastuni
]

`v 35 [
apyākāśasarojinyā apyākāśamahāvane |
itthametanmana iti vismayo'sya na jāyate
]

`v 36 [
kāntāmadhyagatasyāpi mano'sya madaneṣavaḥ |
na bhedayanti durbhedyaṃ dhārā iva mahopalam
]

`v 37 [
āpadāmekamāvāsamabhivāñchasi kiṃ dhanam |
anuśiṣyeti sarvasvamarthine saṃprayacchati
]

`v 38 [
iyamāpadiyaṃ saṃpadityevaṃ kalpanāmayaḥ |
manaso'bhyudito moha iti ślokānpragāyati
]

`v 39 [
hā hato'hamanātho'hamityākrandaparo'pi san |
na jano yāti vairāgyaṃ citramityeva vaktyasau
]

`v 40 [
raghukānanaśālena rāmeṇa ripughātinā |
bhṛśamitthaṃ sthitenaiva vayaṃ khedamupāgatāḥ
]

`v 41 [
na vidmaḥ kiṃ mahābāho tasya tādṛśacetasaḥ |
kurmaḥ kamalapatrākṣa gatiratra hi no bhavān
]

`v 42 [
rājānamathavā vipramupadeṣṭāramagrataḥ |
hasatyajñamivāvyagraḥ so'vadhīrayati prabho
]

`v 43 [
nanu nītijñaiḥ saṃvyavahāropadeśenāsya moho'panīyatāṃ tatrāha -
rājānamiti | upadeṣṭāraṃ rājanītivyavahārāniti śeṣaḥ | avadhīrayatya##-
yadevedamidaṃ sphāraṃ jagannāma yadutthitam |
naitadvastu nacaivāhamiti nirṇīya saṃsthitaḥ
]

`v 44 [
nārau nātmani no mitre na rājye na ca mātari |
na saṃpadā na vipadā taśāsthā na vibho bahiḥ
]

`v 45 [
nirastāstho nirāśo'sau nirīho'sau nirāspadaḥ |
na mūḍho na ca mukto'sau tena tapyāmahe bhṛśam
]

`v 46 [
kiṃ dhanena kimambābhiḥ kiṃ rājyena kimīhayā |
iti niścayavānantaḥ prāṇatyāgaparaḥ sthitaḥ
]

`v 47 [
bhoge'pyāyuṣi rājyeṣu mitre pitari mātari |
paramudvegamāyātaścātako'vagrahe yathā
]

`v 48 [
iti toke samāyātāṃ śākhāprasaraśālinīm |
āpattāmalamuddhartuṃ samudetu dayāparaḥ
]

`v 49 [
tasya tādṛksvabhāvasya samagravibhavānvitam |
saṃsārajālamābhogi prabho prativiṣāyate
]

`v 50 [
īdṛśaḥ syānmahāsattvaḥ ka ivāsminmahītale |
prakṛte vyavahāre taṃ yo niveśayituṃ kṣamaḥ
]

`v 51 [
manasi mohamapāsya mahāmanāḥ sakalamārtitamaḥ kila sādhutām |
saphalatāṃ nayatīha tamo haran dinakaro bhuvi bhāskaratāmiva
]