`v 1 [
caturdaśaḥ sargaḥ 14
śrīrāma uvāca |
āyuḥ pallavakoṇāgralambāmbukaṇabhaṅguram |
unmattamiva saṃtyajya yātyakāṇḍe śarīrakam
]

`v 2 [
viṣayāśīviṣāsaṅgaparijarjaracetasām |
aprauḍhātmavivekānāmāyurāyāsakāraṇam
]

`v 3 [
ye tu vijñātavijñeyā viśrāntā vitate pade |
bhāvābhāvasamāśvāsamāyusteṣāṃ sukhāyate
]

`v 4 [
vayaṃ parimitākārapariniṣṭhitaniścayāḥ |
saṃsārābhrataḍitpuñje mune nāyuṣi nirvṛtāḥ
]

`v 5 [
yujyate veṣṭanaṃ vāyorākāśasya ca khaṇḍanam |
grathanaṃ ca garaṅgāṇāmāsthā `note[māsthāyuṣi na yujyate] nāyuṣi
yujyate
]

`v 6 [
pelavaṃ śaradīvābhramasneha iva dīpakaḥ |
taraṅgaka ivālolaṃ gatamevopalakṣyate
]

`v 7 [
taraṅgaṃ pratibimbenduṃ taḍitpuñjaṃ nabhombujam |
grahītumāsthāṃ badhnāmi na tvāyuṣi hatasthitau
]

`v 8 [
aviśrāntamanāḥ śūnyamāyurātatamīhate |
duḥkhāyaiva vimūḍho'ntargarbhamaśvatarī yathā
]

`v 9 [
saṃsārasaṃsṛtāvasyāṃ pheno'sminsargasāgare |
kāyavallyāmbhaso brahmañjīvitaṃ me na rocate
]

`v 10 [
prāpyaṃ saṃprāpyate yena bhūyo yena na śocyate |
parāyā nirvṛteḥ sthānaṃ yattajjīvitamucyate
]

`v 11 [
taravo'pi hi jīvanti jīvanti mṛgapakṣiṇaḥ |
sa jīvati mano yasya mananena na jīvati
]

`v 12 [
mananena mananaphalena tattvabodhena vāsanākṣayeṇa vā na jīvati tucchībhavati |
11 |
jātāsta eva jagati jantavaḥ sādhujīvitāḥ |
ye punarneha jāyante śeṣā jaraṭhagardabhāḥ
]

`v 13 [
bhāro'vivekinaḥ śāstraṃ bhāro jñānaṃ ca rāgiṇaḥ |
aśāntasya mano bhāro bhāro'nātmavido vapuḥ
]

`v 14 [
bhāro bhāra iva vyarthaśramahetuḥ | jñānaṃ ca jñānamapi yatsarvaśrama##-
rūpamāyurmano buddhirahaṃkārastathehitam |
bhāro bhāradharasyeva sarvaṃ duḥkhāya durdhiyaḥ
]

`v 15 [
īhitaṃ ceṣṭitam | bhāraśabdārthaṃ svayamevāha - bhāradharasyevetyādinā |
14 |
aviśrāntamanāpūrṇamāpadāṃ paramāspadam |
nīḍaṃ rogavihaṅgānāmāyurāyāsanaṃ dṛḍham
]

`v 16 [
pratyahaṃ khedamutsṛjya śanairalamanāratam |
ākhuneva jaracchvabhraṃ kālena vinihanyate
]

`v 17 [
śarīrabilaviśrāntairviṣadāhapradāyibhiḥ |
rogairāpīyate raudrairvyālairiva vanānilaḥ
]

`v 18 [
prasnuvānairavicchedaṃ tucchairantaravāsibhiḥ |
duḥkhairāvṛścyate `note[rādhṛṣyate] krūrairghuṇairiva
jaraddrumaḥ
]

`v 19 [
nūnaṃ nigaraṇāyāśu ghanagardhamanāratam |
ākhurmārjārakeṇeva maraṇenāvalokyate
]

`v 20 [
gandhādiguṇagarbhiṇyā śūnyayā'śaktiveśyayā |
annaṃ mahāśaneneva `note[jarasā] jarayā parijīryate
]

`v 21 [
dinaiḥ katipayaireva parijñāya gatādaram |
durjanaḥ sujaneneva yauvanenāvamucyate
]

`v 22 [
vināśasuhṛdā nityaṃ jarāmaraṇabandhunā |
rūpaṃ khiṅgavareṇeva kṛtāntenābhilaṣyate
]

`v 23 [
kiṅgavaro viṭaśreṣṭhaḥ | rūpaṃ saundaryamiva | abhilaṣyate āyuḥ puruṣo vā | 22
|
sthiratayā sukhabhāsitayā tayā satatamujjhitamuttamaphalgu ca |
jagati nāsti tathā guṇavarjitaṃ maraṇabhājanamāyuridaṃ yathā
]