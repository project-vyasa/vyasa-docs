`v 1 [
pañcadaśaḥ sargaḥ 15
śrīrāma uvāca |
mudhaivābhyutthito mohānmudhaiva parivardhate |
mithyāmayena bhīto'smi durahaṃkāraśatruṇā
]

`v 2 [
ahaṃkāravaśādeva doṣakośakadarthatām |
dadāti dīnadīnānāṃ saṃsāro vividhākṛtiḥ
]

`v 3 [
vividhāḥ sādhyasādhanaphalavṛttilakṣaṇā ākārā yasya sa tathāvidhaḥ
saṃsāraḥ `note[kālamārabhya] anādikālādārabhya
janmamaraṇanarakādyanantaduḥkhaparamparāmanubhūyāpi
punaḥpunastaddhetūnsukhalavānāyāsasahasrairapi lipsamānatvāddīnebhyo'pi
dīnānāṃ viṣayalaṃpaṭānāṃ `note[durvāsanādi]
rāgadveṣadurvyasanādidoṣalakṣaṇeṣu kośagṛheṣu sadvyavahārānupa##-
ahaṃkāravaśādāpadahaṃkārāddurādhayaḥ |
ahaṃkāravaśādīhā `note[nāhaṃkārātparo ripuḥ] tvahaṃkāro
mamāmayaḥ
]

`v 4 [
tamahaṃkāramāśritya paramaṃ ciravairiṇam |
na bhuje na pibāmyambhaḥ kimu bhogānbhuje mune
]

`v 5 [
saṃsārarajanī dīrghā māyā manasi mohinī |
tato'haṃkāradoṣeṇa kirāteneva vāgurā
]

`v 6 [
yāni duḥkhāni dīrghāṇi viṣamāṇi mahānti ca |
ahaṃkārātprasūtāni tānyagātkhadirā iva
]

`v 7 [
śamendusaiṃhikeyāsyaṃ `note[siṃhikeyāsyamiti; sihikeyo=rāhuḥ;
vṛddhyabhāvaśchāndasaḥ] guṇapadmahimāśanim |
sāmyameghaśaratkālamahaṃkāraṃ tyajāmyaham
]

`v 8 [
nāhaṃ rāmo na me vāñchā bhāveṣu na ca me manaḥ |
śānta āsitumicchāmi svātmanīva jino yathā
]

`v 9 [
ahaṃkāravaśādyadyanmayā bhuktaṃ hutaṃ kṛtam |
sarvaṃ tattadavastveva vastvahaṃkārariktatā
]

`v 10 [
ahamityasti cedbrahmannahamāpadi duḥkhitaḥ |
nāsti cetsukhitastasmādanahaṃkāritā `note[varā] varam
]

`v 11 [
ahaṃkāraṃ parityajya mune śāntamanastayā |
avatiṣṭhe gatodvego bhogaugho bhaṅgurāspadaḥ
]

`v 12 [
brahmanyāvadahaṃkāravāridaḥ parijṛmbhate |
tāvadvikāsamāyāti tṛṣṇākuṭajamañjarī
]

`v 13 [
ahaṃkāra eva `note[eveti kvacinnopalabhyate]
vivekajyotirgaṇatirodhāyakatvādvāridaḥ | parito jṛmbhate gātrāṇi vistārayati | 12
|
ahaṃkāraghane śānte tṛṣṇā navataḍillatā |
śāntadīpaśikhāvṛttyā kvāpi yātyatisatvaram
]

`v 14 [
ahaṃkāramahāvindhye manomattamahāgajaḥ |
visphūrjati ghanāsphoṭaiḥ stanitairiva vāridaḥ
]

`v 15 [
stabdhatvadurvināmatvābhyāṃ vindhyasāmyam | visphūrjati garjati |
ghanairāsphotairyuddhotsāhaiḥ ghanānāṃ nibiḍaśilādīnāmāsphoṭana##-
iha dehamahāraṇye ghanāhaṃkārakesarī |
yo'yamullasati sphārastenedaṃ jagadātatam
]

`v 16 [
tṛṣṇātantulavaprotā bahujanmaparamparā |
ahaṃkārograkhiṅgena kaṇṭhe muktāvalī kṛtā
]

`v 17 [
putramitrakalatrāditantramantravivarjitam |
prasāritamaneneha mune'haṃkāravairiṇā
]

`v 18 [
pramārjite'hamityasminpade svayamapi drutam |
pramārjitā bhavantyete sarva eva durādhayaḥ
]

`v 19 [
ahamityambude śānte śanaiśca śamaśātinī |
manogaganasaṃmohamihikā kvāpi gacchati
]

`v 20 [
ahaṃkārocchedasya mandādhikāriṇāṃ cirasādhanābhyāsuprabodhasādhya##-
śamaśātanī śāntinikṛntanī | manogaganasthā mohamihikā mahābhrāntinīhā##-
nirahaṃkāravṛtterme maurkhyācchokena sīdataḥ |
yatkiṃciducitaṃ brahmaṃstadākhyātumihārhasi
]

`v 21 [
sarvāpadāṃ nilayamadhruvamantarastha-
munmuktamuttamaguṇena na saṃśrayāmi |
yatnādahaṃkṛtipadaṃ parito'tiduḥkhaṃ
śeṣeṇa māṃ samanuśādhi mahānubhāva
]