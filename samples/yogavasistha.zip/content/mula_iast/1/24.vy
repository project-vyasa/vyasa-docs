`v 1 [
caturviṃśaḥ sargaḥ 24
śrīrāma uvāca |
asyoḍḍāmaralīlasya dūrāstasakalāpadaḥ |
saṃsāre rājaputrasya kālasyākalitaujasaḥ
]

`v 2 [
asyaivācarato dīnairmugdhairbhūtamṛgavrajaiḥ |
ākheṭakaṃ jarjarite jagajjaṅgalajālake
]

`v 3 [
asyaiva kalpakālamahārṇavaḥ krīḍāpuṣkariṇīkṛta ityuttaratra saṃbandhaḥ |
mugdhairajñaiḥ | bhūtānyeva mṛgavrajāstaiḥ | vadhyānāmapi vadhakavinoda##-
ekadeśollasaccāruvaḍavānalapaṅkajā |
krīḍāpuṣkaraṇī ramyā kalpakālamahārṇavaḥ
]

`v 4 [
kaṭutiktāmlabhūtādyaiḥ sadadhikṣīrasāgaraiḥ |
taireva taiḥ paryuṣitairjagadbhiḥ kalyavartanam
]

`v 5 [
caṇḍī caturasaṃcārā sarvamātṛgaṇānvitā |
saṃsāravanavinyastā vyāghrī bhūtaughaghātinī
]

`v 6 [
pṛthvī karatale pṛthvī pānapātrī rasānvitā |
kamalotpalakalhāralolajālakamālitā
]

`v 7 [
tasy pānapātrīmāha - pṛthvīti | pṛthvī bhūreva tasya karatale pṛthvī mahatī
pānapātrī | āsavasaugandhyaśobhādyarthaṃ pānapātryā api kamalotpalādi##-
virāvī vikaṭāsphoṭo nṛsiṃho bhujapañjare |
saṭāvikaṭapīnāṃsaḥ kṛtaḥ krīḍāśakuntakaḥ
]

`v 8 [
alābuvīṇāmadhuraḥ śaradvyomalasacchaviḥ |
devaḥ kila mahākālo līlākokilabālakaḥ
]

`v 9 [
ajasra sphūrjitākāro vāntaduḥkhaśarāvaliḥ |
abhāvanāmakodaṇḍaḥ parisphurati sarvataḥ
]

`v 10 [
anuttamastvadhikavilāsapaṇḍito bhramaccalanparivilasanvidārayan |
jarajjagajjanitavilolamarkaṭaḥ parisphūradvapuriha kāla īhate
]