`v 1 [
aṣṭādaśaḥ sargaḥ 18
śrīrāma uvāca |
ārdrāntratantrīgahano vikārī paripātavān |
dehaḥ sphurati saṃsāre so'pi duḥkhāya kevalam
]

`v 2 [
ajño'pi tajjñasadṛśo valitātmacamatkṛtiḥ |
yuktyā bhavyo'pyabhavyo'pi na jaḍo nāpi cetanaḥ
]

`v 3 [
jaḍājaḍadṛśormadhye dolāyitadurāśayaḥ |
avivekī vimūḍhātmā mohameva prayacchati
]

`v 4 [
stokenānandamāyāti stokenāyāti kheditām |
nāsti dehasamaḥ śocyo nīco guṇabahiṣkṛtaḥ
]

`v 5 [
āgamāpāyinā nityaṃ dantakesaraśālinā |
vikāsasmitapuṣpeṇa pratikṣaṇamalaṃkṛtaḥ
]

`v 6 [
bhujaśākho ghanaskandho dvijastambhaśubhasthitiḥ |
locanālibilākrāntaḥ śiraḥ pīṭhabṛhatphalaḥ
]

`v 7 [
ghana unnataḥ skandhoṃ'saḥ śākhā mūlaṃ ca | dvijā dantāsta eva śleṣātpa##-
śravadantarasagrasto hastapādasupallavaḥ |
gulmavānkāryasaṃghāto vihaṅgamakṛtāspadaḥ `note[tatāspada]
]

`v 8 [
sacchāyo dehavṛkṣo'yaṃ jīvapānthagaṇāspadaḥ |
kasyātmīyaḥ kasya para āsthānāsthe `note[āsthānāsthā] kilātra ke
]

`v 9 [
tāta saṃtaraṇārthena gṛhītāyāṃ punaḥ punaḥ |
nāvi dehalatāyāṃ ca kasya syādātmabhāvanā
]

`v 10 [
nanvātmatvena sarvajanaprasiddho'yaṃ kathamupekṣyastatrāha - tāteti |
saṃtaraṇamāyurnadyāḥ saṃsārāmbudhervā paratīragamanam | nāvi naukāyām | 9
|
dehanāmni vane śūnye bahugartasamākule |
tanuruhāsaṃkhyatarau viśvāsaṃ ko'dhigacchati
]

`v 11 [
māṃsasnāyvasthivalite śarīrapaṭahe'dṛḍhe |
mārjāravadahaṃ tāta tiṣṭhāmyatra gatadhvanau
]

`v 12 [
saṃsārāraṇyasaṃrūḍho vilasaccittamarkaṭaḥ |
cintāmañjaritākāro dīrghaduḥkhaghuṇakṣataḥ
]

`v 13 [
tṛṣṇābhujaṅgamīgeha. kopakākakṛtālayaḥ |
smitapuṇyodgamaḥ śrīmāñchubhāśubhamahāphalaḥ
]

`v 14 [
suraskandhaughalatājālo hastastabakasundaraḥ |
pavanaspantitāśeṣasvāṅgāvayavapallavaḥ
]

`v 15 [
sarvendriyakhagādhāraḥ sujānustambha unnataḥ |
sarasacchāyayā yuktaḥ kāmapānthaniṣevitaḥ
]

`v 16 [
mūrdhasaṃjanitā''dīrghaśiroruhatṛṇāvaliḥ |
ahaṃkāragṛdhrakṛtakulāyaḥ suṣirodaraḥ
]

`v 17 [
vicchinnavāsanājālamūlatvāddurlavākṛtiḥ |
vyāyāmavirasaḥ kāyaplakṣo'yaṃ na sukhāya me
]

`v 18 [
kalevaramahaṃkāragṛhasthasya mahāgṛham |
luṭhatvabhyetu vā sthairyaṃ kimanena mune mama
]

`v 19 [
paṅktibaddhendriyapaśuṃ balattṛṣṇāgṛhāṅganam |
rāgarañjitasarvāṅgaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 20 [
pṛṣṭhāsthikāṣṭhasaṃghaṭṭaparisaṃkaṭakoṭaram |
āntrarajjubhirābaddhaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 21 [
prasṛtasnāyutantrīkaṃ raktāmbukṛtakardamam |
jarāmaṅkoladhavalaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 22 [
snāyavaḥ śirāstā eva tantryo vīṇādisūtrāṇi bandhanarajjavo vā yasmin |
asvāṅgatvāt nāḍītantryoḥ svāṅge iti na kanniṣeḍhaḥ | maṅkolaṃ cūrṇam | 21
|
cittabhṛtyakṛtānantaceṣṭāvaṣṭabdhasaṃsthiti |
mithyāmohamahāsthūṇaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 23 [
duḥkhārbhakakṛtākrandaṃ sukhaśayyāmanoramam |
durīhādagdhadāsīkaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 24 [
malāḍhyaviṣayavyūhabhāṇḍopaskarasaṃkaṭam |
ajñānakṣāravalitaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 25 [
ataeva malāḍhyairdoṣabahulairanirṇiktaiśca viṣayavyūhalakṣaṇairbhāṇḍairūpa##-
gulphagugguluviśrāntajānūrdhvastambhamastakam |
dīrghadordārusudṛḍhaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 26 [
jaṅghāstambhasya gulpho gugguluḥ ādhārakāṣṭhasthānīyastatra viśrāntasya
pratiṣṭhitasyārthāt jaṅghāstambhasya jānu mastakaṃ tadapi svādhārādhāre
paramparyā pratiṣṭhitameva | mūlaśaithilye sarvaśaithilyāpatteḥ | doṣau bāhū | 25
|
prakaṭākṣagavākṣāntaḥ krīḍatprajñāgṛhāṅganam |
cintāduhitṛkaṃ brahmanneṣṭaṃ dehagṛhaṃ mama
]

`v 27 [
mūrdhajācchādanachannakarṇaśrīcandraśālikam |
ādīrghāṅgulinirvyūhaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 28 [
mūrdhajāḥ keśāsta eva cchādanaṃ chadiḥ | karṇāveva kuṇḍalamuktādi##-
sarvāṅgakuḍyasaṃghātaghanaromayavāṅkuram |
saṃśūnyapeṭavivaraṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 29 [
nakhorṇanābhinilayaṃ saramāranitāntaram |
bhāṅkārakāripavanaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 30 [
praveśanirgamavyagravātavegamanāratam |
vitatākṣagavākṣaṃ tanneṣṭaṃ dehagṛhaṃ mama
]

`v 31 [
jihvāmarkaṭikākrāntavadanadvārabhīṣaṇam |
dṛṣṭadantāsthiśakalaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 32 [
tvaksudhālepamasṛṇaṃ yantrasaṃcāracañcalam |
manaḥ sadākhunotkhātaṃ neṣṭaṃ dehagṛhaṃ mama
]

`v 33 [
sudhā cūrṇam | tvageva sudhālepastena masṛṇaṃ snigdham | yantrāṇi
gharaṭṭaśakaṭādīni teṣāmiva sandhīnāṃ saṃcāro bhramaṇādisteṣāmeva
saṃcāro vā | mana eva sadātana ākhurmūṣakastenotkhātamiva śaithilya##-
smitadīpaprabhodbhāsi kṣaṇamānandasundaram |
kṣaṇaṃ vyāptaṃ tamaḥpūrairneṣṭaṃ dehagṛhaṃ mama
]

`v 34 [
samastarogāyatanaṃ valīpalitapattanam |
`note[sarvātisāra] sarvādhisāragahanaṃ neṣṭaṃ dehagṛhaṃ mama | 34
|
valī tvakśaithilyam | pattanaṃ nagaraṃ nivāsasthānamiti yāvat | ādhayo
mānasaduḥkhāni tānyeva sāraḥ prādhānyena bhogyatvāttairgahanaṃ
durgamamaraṇyāyamānaṃ vā
]

`v 35 [
akṣarkṣakṣobhaviṣamā śūnyā niḥsārakoṭarā |
tamogahanadikkuñjā neṣṭā dehāṭavī mama
]

`v 36 [
dehālayaṃ dhārayituṃ na śaknomi munīśvara |
paṅkamagnaṃ samuddhartuṃ gajamalpabalo yathā
]

`v 37 [
kiṃ śriyā kiṃ ca rājyena kiṃ kāyena kimīhitaiḥ |
dinaiḥ katipayaireva kālaḥ sarvaṃ nikṛntati
]

`v 38 [
raktamāṃsamayasyāsya sabāhyābhyantaraṃ mune |
nāśaikadharmiṇo brūhi kaiva kāyasya ramyatā
]

`v 39 [
maraṇāvasare kāyā jīvaṃ nānusaranti ye |
teṣu tāta kṛtaghneṣu kaivāsthā vada dhīmatām
]

`v 40 [
nānusaranti nānugacchanti | kṛtaṃ pālanapoṣaṇādyupakāraṃ ghnanti pratyupa##-
mattebhakarṇāgracalaḥ kāyo lambāmbubhaṅguraḥ |
na saṃtyajati māṃ yāvattāvadenaṃ tyajāmyaham
]

`v 41 [
calaścapalaḥ | lambaṃ lambamānaṃ yadambu jalakaṇaḥ | saṃnidhānānmattebha##-
pavanaspandataralaḥ pelavaḥ kāyapallavaḥ |
jarjarastanuvṛttaśca neṣṭo me kaṭunīrasaḥ
]

`v 42 [
bhuktvā pītvā ciraṃ kālaṃ bālapallavapelavām |
tanutāmetya yatnena vināśamanudhāvati
]

`v 43 [
tānyeva sukhaduḥkhāni bhāvābhāvamayānyasau |
bhūyo'pyanubhavankāyaḥ prākṛto hi na lajjate
]

`v 44 [
suciraṃ prabhutāṃ kṛtvā saṃsevya vibhavaśriyam |
nocchrāyameti na sthairyaṃ kāyaḥ kimiti pālyate
]

`v 45 [
saṃsevya saṃprāpya | ucchrāyamupacayamutkarṣaṃ vā | sthairyamavināśitām | 44
|
jarākāle jarāmeti mṛtyukāle tathā mṛtim |
sama evāviśeṣajñaḥ kāyo bhogidaridrayoḥ
]

`v 46 [
saṃsārāmbhodhijaṭhare tṛṣṇākuharakāntare |
suptasthiṣṭhati mukteho mūko'yaṃ kāyakacchapaḥ
]

`v 47 [
tṛṣṇaiva kuharakamalpacchidram | suptaḥ supta iva mūḍhaḥ | ataeva mukteha
ātmoddhārānukūlecchāceṣṭāvidhuro'taeva mūko gurūpasarpaṇena
tatpraśnādivāgvikalaśca | kacchopalakṣitadurindriyairdurviṣayakardamarasā##-
dahanaikārthayogyāni kāyakāṣṭhāni bhūriśaḥ |
saṃsārābdhāvihohyante kaṃcitteṣu naraṃ viduḥ
]

`v 48 [
dīrghadaurātmyavalayā nipātaphalapātayā |
na dehalatayā kāryaṃ kiṃcidasti vivekinaḥ
]

`v 49 [
majjankardamakośeṣu jhaṭityeva jarāṃ gataḥ |
na jñāyate yātyacirātkaḥ kathaṃ dehadarduraḥ
]

`v 50 [
niḥsārasakalārambhāḥ kāyāścapalavāyavaḥ |
rajomārgeṇa gacchanto dṛśyante neha kenacit
]

`v 51 [
niḥsārā nīrasāḥ | kāyā eva capalā vāyavo jhaṃjhāpavanāḥ | rajomārgeṇa
rājasapravṛttyā dhūlimātrapariśeṣeṇa vā dhūlisahitenākāśamārgeṇānyatra |
50 |
vāyordīpasya manaso gacchato jñāyate gatiḥ |
āgacchataśca bhagavañcharīrasya kadācana
]

`v 52 [
baddhāsthā ye śarīreṣu baddhāsthā ye jagatsthitau |
tānmohamadironmattandhigdhigastu punaḥ punaḥ
]

`v 53 [
nāhaṃ dehasya no deho mama nāyamahaṃ tathā |
iti viśrāntacittā ye te mune puruṣottamāḥ
]

`v 54 [
ayamidaṃtvena ghaṭādivajjaḍo deho'haṃ neti vicārya viśrāntacittaḥ |
paramātmanīti śeṣaḥ | puruṣottamāḥ puruṣaśreṣṭhāḥ viṣṇusvarūpā eveti vā |
53 |
mānāvamānabahulā bahulābhamanoramāḥ |
śarīramātrabaddhāsthaṃ ghnanti doṣadṛśo naram
]

`v 55 [
śarīraśvabhraśāyinyā piśācyā peśalāṅgayā |
ahaṃkāracamatkṛtyā chalena chalitā vayam
]

`v 56 [
prajñā varākī sarvaiva kāyabaddhāsthayānayā |
mithyājñānakurākṣasyā chalitā kaṣṭamekikā
]

`v 57 [
na kiṃcidapi dṛśye'sminsatyaṃ tena hatātmanā |
citraṃ dagdhaśarīreṇa janatā vipralabhyate
]

`v 58 [
dinaiḥ katipayaireva nirjharāmbukaṇo yathā |
patatyayamayatnena jaraṭhaḥ kāyapallavaḥ
]

`v 59 [
kāyo'yamacirāpāyo budbudo'mbunidhāviva |
vyarthaṃ kāryaparāvarte parisphūrati niṣphalaḥ
]

`v 60 [
midhyājñānavikāre'sminsvapnasaṃbhramapattane |
kāye sphuṭatarāpāye kṣaṇamāsthā na me dvija
]

`v 61 [
kutaḥ kāyādidṛśyavargasyāsatyatvaṃ tatrāha - mithyeti | yato
mithyābhūtasyājñānasya vikāra ityarthaḥ | svapnasaṃbhramanagaratulye | athavā
svāpnabhrāntīnāmādhāre | śarīre eva svapnadarśanāt | sve śarīre yathākāmaṃ
parivartata iti śruteḥ | nagarasya nāgarikavyāpāratulyasattāka-tvādityarthaḥ |
60 |
taḍitsu śaradabhreṣu gandharvanagareṣu ca |
sthairyaṃ yena vinirṇītaṃ sa viśvasitu vigrahe
]

`v 62 [
satatbhaṅgurakāryaparamparā vijayijātajayaṃ haṭhavṛttiṣu |
prabaladoṣamidaṃ tu kalevaraṃ tṛṇamivāhamapohya sukhaṃ sthitaḥ
]