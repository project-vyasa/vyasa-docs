`v 1 [
ekādaśaḥ sargaḥ 11
viśvāmitra uvāca |
evaṃ cettanmahāprājñā bhavanto raghunandanam |
ihānayantu tvaritā hariṇaṃ hariṇā iva
]

`v 2 [
eṣa moho raghupaternāpadbhyo na ca rāgataḥ |
vivekavairāgyavato bodha eva mahodayaḥ
]

`v 3 [
ihāyātu kṣaṇādrāma iha caiva vayaṃ kṣaṇāt |
mohaṃ tasyāpaneṣyāmo māruto'drerghanaṃ yathā
]

`v 4 [
etasminmārjite yuktyā mohe sa raghunandanaḥ |
viśrāntimeṣyati pade tasminvayamivottame
]

`v 5 [
satyatāṃ muditāṃ prajñāṃ viśrāntimapatāpatām |
pīnatāṃ varavarṇatvaṃ pītāmṛta ivaiṣyati
]

`v 6 [
nijāṃ ca prakṛtāmeva vyavahāraparamparām |
paripūrṇamanā mānya ācariṣyatyakhaṇḍitam
]

`v 7 [
bhaviṣyati mahāsattvo jñātalokaparāvaraḥ |
sukhaduḥkhaśāhīnaḥ samaloṣṭāśmakāñcanaḥ
]

`v 8 [
ityukte munināthena rājā saṃpūrṇamānasaḥ |
prāhiṇodrāmamānetuṃ bhūyo dūtaparamparām
]

`v 9 [
bhūya ityukte vasiṣṭhavacanātprāk pratīhārādanye'pi dūtāḥ preṣitā eveti gamyate |
8 |
etāvatātha kālena rāmo nijagṛhāsanāt |
pituḥ sakāśamāgantumutthito'rka ivācalāt
]

`v 10 [
vṛtaḥ katipayairbhṛtyairbhrātṛbhyāṃ ca jagāma ha |
tatpuṇyaṃ svapituḥ sthānaṃ svargaṃ surapateriva
]

`v 11 [
dūrādeva dadarśāsau rāmo daśarathaṃ tadā |
vṛtaṃ rājasamūhena devaugheneva vāsavam
]

`v 12 [
vasiṣṭhaviśvāmitrābhyāṃ sevitaṃ pārśvayordvayoḥ |
sarvaśāstrārthatajjñena mantrivṛndena mālitam
]

`v 13 [
cārucāmarahastābhiḥ kāntābhiḥ samupāsitam |
kakubbhiriva mūrtābhiḥ saṃsthitābhiryathocitam
]

`v 14 [
vasiṣṭhaviśvāmitrādyāstathā daśarathādayaḥ |
dadṛśu rāghavaṃ dūrādupāyāntaṃ guhopamam
]

`v 15 [
sattvāvaṣṭabdhagarbheṇa śaityeneva himācalam |
śritaṃ sakalasevyena gambhīreṇa sphuṭena ca
]

`v 16 [
saumyaṃ samaṃ śubhākāraṃ vinayodāramānasam |
kāntopaśāntavapuṣaṃ parasyārthasya bhājanam
]

`v 17 [
samudyadyauvanārambhaṃ vṛddhopaśamaśobhanam |
anudvignamanānandaṃ pūrṇaprāyamanoratham
]

`v 18 [
vicāritajagadyātraṃ pavitraguṇagocaram |
mahāsattvaikalobhena guṇairiva samāśritam
]

`v 19 [
udāramāryamāpūrṇamantaḥkaraṇakoṭaram |
avikṣubhitayā vṛttyā darśayantamanuttamam
]

`v 20 [
evaṅguṇagaṇākīrṇo dūrādeva raghūdvahaḥ |
parimeyasmitāñchācchasvahārāmbarapallavaḥ
]

`v 21 [
praṇanāma calaccārucūḍāmaṇimarīcinā |
śirasā vasudhākampaloladevācalaśriyā
]

`v 22 [
evaṃ munīndre bruvati pituḥ pādābhivandanam |
kartumabhyājagāmātha rāmaḥ kamalalocanah
]

`v 23 [
prathamaṃ pitaraṃ paścānmunī mānyaikamānitau |
tato viprāṃstato bandhūṃstato gurugaṇānsuhṛt
]

`v 24 [
jagrāha ca tato dṛṣṭyā manāṅmūrdhnā tathā girā |
rājalokena vihitāṃ tāṃ praṇāmaparamparām
]

`v 25 [
vihitāśīrmunibhyāṃ tu rāmaḥ susamamānasaḥ |
āsasāda pituḥ puṇyaṃ samīpaṃ surasundaraḥ
]

`v 26 [
pādābhivandanaparaṃ tamathāsau mahīpatiḥ |
śirasyabhyāliliṅgāśu cucumba ca punaḥpunaḥ
]

`v 27 [
śatrughnaṃ lakṣmaṇaṃ caiva tathaiva paravīrahā |
āliliṅga ghanasneho rājahaṃso'mbuje yathā
]

`v 28 [
utsaṅge putra tiṣṭheti vadatyatha mahīpatau |
bhūmau parijanāstīrṇe soṃ'śuke'tha nyavikṣata
]

`v 29 [
rājovāca |
putra prāptavivekastvaṃ kalyāṇānāṃ ca bhājanam |
jaḍavajjīrṇayā buddhyā khedāyātmā na dīyatām
]

`v 30 [
vṛddhavipraguruproktaṃ tvādṛśenānutiṣṭhatā |
padamāsādyate puṇyaṃ na mohamanudhāvatā
]

`v 31 [
vṛddhaiḥ pitrādibhiḥ | gurubhirācāryaiḥ | prajāpālanadharmasādhanatvāt##-
tāvadevā''pado dūre tiṣṭhanti paripelavāḥ |
yāvadeva na mohasya prasaraḥ putra dīyate
]

`v 32 [
śrīvasiṣṭha uvāca |
rājaputra mahābāho śūrastvaṃ vijitāstvayā |
durucchedā durārambhā apyamī viṣayārayaḥ
]

`v 33 [
tvameva śūro yatastvayā viṣayārayo vijitāḥ | prasiddhā arayo durucchedā eva na te
svena duḥkhenārabhyante | viṣayārayastu svenaiva saṃpāditā suḥkhāntarapara##-
kimatajjña ivājñānāṃ yogye vyāmohasāgare |
vinimajjasi kallolabahule jāḍyaśālini
]

`v 34 [
evaṃbhūto'pi tvamajñānāṃ yogye vyāmohasāgare atajjña ivānātmajña iva kiṃ
nimajjasi | kallolā bṛhattaraṅgā vikṣepakāḥ | jāḍyaṃ mauḍhyamāvaraṇam | 33
|
viśvāmitra uvāca |
calannilotpalavyūhasamalocanalolatām |
brūhi cetaḥkṛtāṃ tyaktvā hetunā kena muhyasi
]

`v 35 [
calatā nīlotpalasamūhena samāṃ locanayorlolatāṃ cañcalatām | ceto vyagracittaṃ
tena kṛtām | kena hetunā vimuhyasi bhrāmyasi | tava bhrāntihetuḥ ka ityarthaḥ | 34
|
kiṃniṣṭhāḥ ke ca te kena kiyantaḥ kāraṇena te |
ādhayaḥ pravilumpanti mano gehamivākhavaḥ
]

`v 36 [
manye nānucitānāṃ tvamādhīnāṃ padamuttamam |
āpatsu cā'prayojyaṃ te nihīnā api cādhayaḥ
]

`v 37 [
yathābhimatamāśu tvaṃ brūhi prāpsyasi cānagha |
sarvameva punaryena bhetsyante tvāṃ tu nādhayaḥ
]

`v 38 [
ityuktamasya sumate raghuvaṃśaketu-
rākarṇya vākyamucitārthavilāsagarbham |
tatyāja khedamabhigarjati vārivāhe
barhī yathā tvanumitābhimatārthasiddhiḥ
]