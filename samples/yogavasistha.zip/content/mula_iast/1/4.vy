`v 1 [
caturthaḥ sargaḥ 4
śrīvālmīkiruvāca |
rāmaḥ puṣpāñjalivrātairvikīrṇaḥ puravāsibhiḥ |
praviveśa gṛhaṃ śrīmāñjayanto viṣṭapaṃ yathā
]

`v 2 [
praṇanāmātha pitaraṃ vasiṣṭhaṃ bhrātṛbāndhavān |
brāhmaṇānkulavṛddhāṃśca rāghavaḥ prathamāgataḥ
]

`v 3 [
suhṛdbhirbhrātṛbhiścaiva `note[rmātṛbhiścaiva] pitrā dvijagaṇena
ca |
muhurāliṅgitācāro rāghavo na mamau mudā
]

`v 4 [
tasmingṛhe dāśaratheḥ priyaprakathanairmithaḥ |
jughūrṇurmadhurairāśā mṛduvaṃśasvanairiva
]

`v 5 [
prathāmagataḥ prathamapravāsadāgataḥ
]

`v 6 [
uvāsa sa sukhaṃ gehe tataḥ prabhṛti rāghavaḥ |
varṇayanvividhākārāndeśācārānitastataḥ
]

`v 7 [
prātarutthāya rāmo'sau kṛtvā saṃdhyāṃ yathāvidhi |
sabhāsaṃsthaṃ dadarśendrasamaṃ svapitaraṃ tathā
]

`v 8 [
kathābhiḥ suvicitrābhiḥ sa vasiṣṭhādibhiḥ saha |
sthitvā dinacaturbhāgaṃ jñānagarbhābhirādṛtaḥ
]

`v 9 [
jagāma pitrānujñāto mahatyā senayā vṛttaḥ |
varājamahiṣākīrṇaṃ vanamākhetakecchayā
]

`v 10 [
tata āgatua sadane kṛtvā snānādikaṃ kramam |
samitrabāndhavo bhuktvā nināya sasuhṛnniśām
]

`v 11 [
evaṃprāyadinācāro bhrātṛbhyāṃ saha rāghavaḥ |
āgatya tīrthayātrāyāḥ samuvāsa piturgṛhe
]

`v 12 [
nṛpatisaṃvyavahāramanojñayā sujanacetasi candrikayānayā |
parinināya dināni sa ceṣṭayā stutasudhārasapeśalayā'nagha
]