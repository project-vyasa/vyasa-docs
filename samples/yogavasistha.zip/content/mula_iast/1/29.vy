`v 1 [
ekonatriṃśaḥ sargaḥ 29
śrīrāma uvāca |
iti me doṣadāvāgnidagdhe mahati cetasi |
prasphuranti na bhogāśā mṛgatṛṣṇāḥ saraḥsviva
]

`v 2 [
pratyahaṃ yāti kaṭutāmeṣā saṃsārasaṃsthitiḥ |
kālapākavaśāllolā rasā nimbalatā yathā
]

`v 3 [
vṛddhimāyāti daurjanyaṃ saujanyaṃ yāti tānavam |
karañjakarkaśe rājanpratyahaṃ janacetasi
]

`v 4 [
bhajyate bhuvi maryādā jhaṭityeva dinaṃ prati |
śuṣkeva māṣaśimbīkā ṭaṅkārakaravaṃ vinā
]

`v 5 [
rājyebhyo bhogapūgebhyaścintāvadbhyo munīśvara |
nirastacintākalitā varamekāntaśīlatā
]

`v 6 [
nānandāya mamodyānaṃ na sukhāya mama striyaḥ |
na harṣāya mamārthāśā śāmyāmi manasā saha
]

`v 7 [
anityaścāsukho lokastṛṣṇā tāta durudvahā |
cāpalopahagaṃ cetaḥ kathaṃ yāsyāmi nirvṛtim
]

`v 8 [
nābhinandāmi maraṇaṃ nābhinandāmi jīvitam |
yathā tiṣṭhāmi tiṣṭhāmi tathaiva vigatajvaram
]

`v 9 [
kiṃ me rājyena kiṃ bhogaiḥ kimarthena kimīhitaiḥ |
ahaṃkāravaśādetatsa eva galito mama
]

`v 10 [
janmāvalivaratrāyāmindriyagranthayo dṛḍhāḥ |
ye baddhāstadvimokṣārthaṃ yatante ye ta uttamāḥ
]

`v 11 [
mathitaṃ māninīlokairmano makaraketunā |
komalaṃ kuraniṣpeṣaiḥ kamalaṃ kariṇā yathā
]

`v 12 [
adya cetsvacchayā buddhyā munīndra na cikitsyate |
bhūyaścittacikitsāyāstatkilāvasaraḥ kutaḥ
]

`v 13 [
viṣaṃ viṣayavaiṣamyaṃ na viṣaṃ viṣamucyate |
janmāntaraghnā viṣayā ekadehaharaṃ viṣam
]

`v 14 [
na sukhāni na duḥkhāni na mitrāṇi na bāndhavāḥ |
na jīvitaṃ na maraṇaṃ bandhāya jñasya cetasaḥ
]

`v 15 [
tadbhavāmi yathā brahmanpūrvāparavidāṃ vara |
vītaśokābhayāyāso jñastathopadiśāśu me
]

`v 16 [
vāsanājālavalitā duḥkhakaṇṭakasaṃkulā `note[saṃkaṭasaṃkulā] |
nipātotpātabahulā bhīmarūpā'jñatāṭavī
]

`v 17 [
krakacāgraviniṣpeṣaṃ soḍhuṃ śaknomyahaṃ mune |
saṃsāravyavahārotthaṃ nāśāviṣayavaiśasam
]

`v 18 [
idaṃ nāstīdamastīti vyavahārāñjanabhramaḥ |
dhunotīdaṃ calaṃ ceto rajorāśimivānilaḥ
]

`v 19 [
tṛṣṇātantulavaprotaṃ jīvasaṃcayamauktikam |
cidacchāṅgatayā nityaṃ vikasaccittanāyakam
]

`v 20 [
saṃsārahāramaratiḥ kālavyālavibhūṣaṇam |
troṭayāmyahamakrūraṃ vāgurāmiva kesarī
]

`v 21 [
kālo mṛtyuḥ sa eva vyālaḥ ṣiṅgastasya vibhūṣaṇamalaṃkārabhūtaṃ
saṃsāralakṣaṇaṃ hāraṃ `note[muktāsaraṃ] muktāhāramaratirvairāgyādi##-
syāttathā vāgurāṃ kesarīva troṭayāmi | bhavadupadeśajanyajñāneneti bhāvaḥ |
20 |
nīhāraṃ hṛdayāṭavyāṃ manastimiramāśu me |
kena vijñānadīpena bhindhi tattvavidāṃvara
]

`v 22 [
vidyanta eveha na te mahātman durādhayo na kṣayamāpnuvanti |
ye saṅgamenottamamānasānāṃ niśātamāṃsīva niśākareṇa
]

`v 23 [
ye uttamamānasānāṃ saṅgena tatphalenopadeśena kṣayaṃ nāpnuvanti te tathā##-
āyurvāyuvighaṭṭitābhrapaṭalīlambāmbuvadbhaṅguraṃ
bhogā meghavitānamadhyavilasatsaudāminīcañcalāḥ |
lolāyauvanalālanājalarayaścetyākalayya drutaṃ
mudraivādya dṛḍhārpitā nanu mayā citte ciraṃ śāntaye
]