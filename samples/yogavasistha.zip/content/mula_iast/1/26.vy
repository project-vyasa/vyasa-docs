`v 1 [
ṣaḍviṃśaḥ sargaḥ 26
śrīrāma uvāca |
vṛtte'sminnevameteṣāṃ kālādīnāṃ mahāmune |
saṃsāranāmni kaivāsthā mādṛśānāṃ `note[bhavatviha] vadatviha
]

`v 2 [
vikrītā iva tiṣṭhāma itairdaivādibhirvayam |
mune prapañcarajanairmugdhā vanamṛgā iva
]

`v 3 [
eṣo'nāryasamāmnāyaḥ kālaḥ kavalanonmukhaḥ |
jagatyavirataṃ lokaṃ pātayatyāpadarṇave
]

`v 4 [
dahatyantardurāśābhirdevo dāruṇaceṣṭayā |
lokamuṣṇaprakāśābhirjvālābhirdahano yathā
]

`v 5 [
dhṛtiṃ vidhurayatyeṣā maryādārūpavallabhā |
strītvātsvabhāvacapalā niyatirniyatonmukhī
]

`v 6 [
grasate'virataṃ bhūtajālaṃ sarpa ivānilam |
kṛtāntaḥ karkaśācāro jarāṃ nītvā'jaraṃ vapuḥ
]

`v 7 [
yamo nirghṛṇarājendro nārtaṃ nāmānukampate |
sarvabhūtadayodāro jano durlabhatāṃ gataḥ
]

`v 8 [
sarvā eva mune phalguvibhavā bhūtajātayaḥ |
duḥkhāiava durantāya dāruṇā bhogabhūmayaḥ
]

`v 9 [
sarvā brahmāntā api bhūtajātayaḥ prāṇijātayo viraktadaśā phalguvibhavāstu##-
āyuratyantacapalaṃ mṛtyurekāntaniṣṭhuraḥ |
tāruṇyaṃ cātitaralaṃ bālyaṃ jaḍatayā hṛtam
]

`v 10 [
kalākalaṅkito loko bandhavo bhavabandhanam |
bhogā bhavamahārogāstṛṣṇāśca mṛgatṛṣṇikāḥ
]

`v 11 [
śatravaścendriyāṇyeva satyaṃ yātamasatyatām |
praharatyātmanaivātmā manasaiva mano ripuḥ
]

`v 12 [
ahaṃkāraḥ kalaṅkāya buddhayaḥ paripelavāḥ |
kriyā duṣphaladāyinyo līlāḥ strīniṣṭhatāṃ gatāḥ
]

`v 13 [
vāñchāviṣayaśālinyaḥ saccamatkṛtayaḥ kṣatāḥ |
nāryo doṣapatākinyo rasā nīrasatāṃ gatāḥ
]

`v 14 [
vastvavastutayā jñātaṃ dattaṃ cittamahaṃkṛtau |
abhāvavedhitā bhāvā bhāvānto nādhigamyate
]

`v 15 [
vastu alaukikaṃ kāryakāraṇasaṃghātātmanā jñātam | cittaṃ dattam |
abhiniveśitamiti yāvat | abhāvavedhitā nāśagrastāḥ | bhāvānāmanitya##-
tapyate kevalaṃ sādho matirākulitāntarā |
rāgarogo vilasati virāgo nopagacchati
]

`v 16 [
rajoguṇahatā dṛṣṭistamaḥ saṃparivardhate |
na cādhigamyate sattvaṃ tattvamatyantadūrataḥ
]

`v 17 [
sthitirasthiratāṃ yātā mṛtirāgamanonmukhī |
dhṛtirvaidhuryamāyātā ratirnityamavastuni
]

`v 18 [
matirmāndyena malinā pātaikaparamaṃ vapuḥ |
jvalatīva jarā dehe pratisphurati duṣkṛtam
]

`v 19 [
yatnena yāti yuvatā dūre sajjanasaṃgatiḥ |
gatirna vidyate kācitkvacinnodeti satyatā
]

`v 20 [
mano vimuhyatīvāntarmuditā dūratāṃ gatā |
nojjvalā karuṇodeti dūrādāyāti nīcatā
]

`v 21 [
muditā parasukhadarśanasaṃtoṣaḥ | nīcatāśabdena taddheturasūyādirgṛhyate |
20 |
dhīratā'dhīratāmeti pātotpātaparo janaḥ |
sulabho durjanāśleṣo durlabhaḥ satsamāgamaḥ
]

`v 22 [
āgamāpāyino bhāvā bhāvanā bhavabandhanī |
nīyate kevalaṃ kvāpi nityaṃ bhūtaparamparā
]

`v 23 [
diśo'pi hi na dṛśyante deśo'pyanyāpadeśabhāk |
śailā api viśīryante kaivāsthā mādṛśe jane
]

`v 24 [
adyate sattayāpi dyaurbhuvanaṃ cāpi bhujyate |
dharāpi yāti vaidhuryaṃ kaivāsthā mādṛśe jane
]

`v 25 [
śuṣyantyapi samudrāśca śrīyante tārakā api |
siddhā api vinaśyanti kaivāsthā mādṛśe jane
]

`v 26 [
dānavā api dīryante dhruvo'pyadhruvajīvitaḥ |
amarā api māryante kaivāsthā mādṛśe jane
]

`v 27 [
śakro'pyākramyate vaktrairyamo'pi hi niyamyate |
vāyurapyetyavāyutvaṃ kaivāsthā mādṛśe jane
]

`v 28 [
somo'pi vyomatāṃ yāti mārtaṇḍo'pyeti khaṇḍatām |
magnatāmagnirapyeti kaivāsthā mādṛśe jane
]

`v 29 [
parameṣṭhyapi niṣṭhāvānhriyate harirapyajaḥ |
bhavo'pyabhāvamāyāti kaivāsthā mādṛśe jane
]

`v 30 [
kālaḥ saṃkālyate yena niyatiścāpi nīyate |
khamapyālīyate'nantaṃ kaivāsthā mādṛśe jane
]

`v 31 [
aśrāvyāvācyadurdarśatattvenājñātamūrtinā |
bhuvanāni viḍambyante kenacidbhramadāyinā
]

`v 32 [
ahaṃkārakalāmetya sarvatrāntaravāsinā |
na so'sti triṣu lokeṣu yasteneha na bādhyate
]

`v 33 [
śilāśailakavapreṣu sāśvabhūto divākaraḥ |
vanapāṣāṇavannityamavaśaḥ paricodyate
]

`v 34 [
sarvabādhakatvopapādanāya tasya niraṅkuśaṃ svātantryamāha -
śiletyāditribhiḥ | sāśvo'śvasahito rathastadbhāvaṃ prāptaḥ | ya āditye tiṣṭhan
ityādiśruteḥ | svādhirūḍheneśvareṇa preryamāṇaḥ śilāśailavaprādidurgama##-
vanaṃ jalaṃ yogyatayā parvataśikharādvegena pravahattena yathā vartulāḥ
sphatikādipāṣāṇā adhodhaḥ preryante tadvadavaśo'svatantraḥ | sūryādī##-
dharāgolakamantasthasurāsuragaṇāspadam |
veṣṭyate dhiṣṇyacakreṇa pakvākṣoṭamiva tvacā
]

`v 35 [
divi devā bhuvi narāḥ pātāleṣu ca bhoginaḥ |
kalpitāḥ kalpamātreṇa nīyante jarjarāṃ daśām
]

`v 36 [
kāmaśca jagadīśānaraṇalabdhaparākramaḥ |
akrameṇaiva vikrānto lokamākramya valgati
]

`v 37 [
vasanto mattamāgaṅgo madaiḥ kusumavarṣaṇaiḥ |
āmoditakakupcakraśceto nayati cāpalam
]

`v 38 [
anuraktāṅganālolalocanālokitākṛti |
svasthīkartuṃ manaḥ śakto na viveko mahānapi
]

`v 39 [
paropakārakāriṇyā parārtiparitaptayā |
buddha eva sukhī manye svātmaśītalayā dhiyā
]

`v 40 [
utpannadhvaṃsinaḥ kālavaḍavānalapātinaḥ |
saṃkyātuṃ kena śakyante kallolā jīvitāmbudhau
]

`v 41 [
sarva eva narā mohāddurāśāpāśapāśinaḥ |
doṣagulmakasāraṅgā viśīrṇā janmajaṅgale
]

`v 42 [
pūrvoktadoṣalakṣaṇeṣu gulmakeṣu sthitāḥ sāraṅgāḥ mṛgāḥ pakṣiṇo vā
durāśāpāśena pāśino badhāḥ santo janmajaṅgale viśīrṇā iti saṃbandhaḥ | 41
|
saṃkṣīyate jagati janmaparamparāsu
lokasya tairiha kukarmabhirāyuretat |
ākāśapādapalatākṛtapāśakalpaṃ
yeṣāṃ phalaṃ nahi vicāravido'pi vidmaḥ
]

`v 43 [
adyotsavo'yamṛtureṣa tatheha yatrā
te bandhavaḥ sukhamidaṃ saviśeṣabhogam |
itthaṃ mudhaiva kalayansuvikalpajāla-
mālolapelavamatirgalatīha lokaḥ
]