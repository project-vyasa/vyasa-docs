`v 1 [
ṣaṣṭhaḥ sargaḥ 6
vālmīkiruvāca |
ityukte munināthena saṃdehavati pārthive |
khedavatyāsthite maunaṃ kiṃcitkālapratīkṣaṇe
]

`v 2 [
parikhinnāsu sarvāsu rājñīṣu nṛpasadmasu |
sthitāsu sāvadhānāsu rāmaceṣṭāsu sarvataḥ
]

`v 3 [
etasminneva kāle tu viśvāmitra iti śrutaḥ |
maharṣirabhyagāddraṣṭuṃ tamayodhyānarādhipam
]

`v 4 [
tasya yajño'tha rakṣobhistathā vilulupe kila |
māyārvīryabalonmattairdharmakāryasya dhīmataḥ
]

`v 5 [
rakṣārthaṃ tasya yajñasya draṣṭumaicchatsa pārthivam |
nahi śaknotyavighnena samāptuṃ sa muniḥ kratum
]

`v 6 [
tatastes.āṃ vināśārthamudyatastapasāṃ nidhiḥ |
viśvāmitro mahātejā ayodhyāmabhyagātpurīm
]

`v 7 [
sa rājño darśanākāṅkṣī dvārādhyakṣānuvāca ha |
śīghramākhyāta māṃ prāptaṃ kauśikaṃ gādhinaḥ sutam
]

`v 8 [
tasya tadvacanaṃ śrutvā dvāsthā rājagṛhaṃ yayuḥ |
saṃbhrāntamanasaḥ sarve tena vākyena coditāḥ
]

`v 9 [
te gatvā rājasadanaṃ viśvāmitramṛṣiṃ tataḥ |
prāptamāvedayāmāsuḥ pratīhārāḥ patestadā
]

`v 10 [
sīdati niṣīdatyasminniti sadanaṃ sabhāsthānam | pratīhārā dvārapālāḥ |
paterbahirdvāsthasya svasvāminaḥ sabhādvāsthasya vā yāṣṭīkasya | gatibudhdi ##-
athāsthānagataṃ bhūpaṃ rājamaṇḍalamālinam |
samupetya tvarāyukto yāṣṭīko'sau vyajijñapat
]

`v 11 [
deva dvāri mahātejā bālabhāskarabhāsuraḥ |
jvālāruṇajaṭājuṭaḥ pumāñchrīmānavasthitaḥ
]

`v 12 [
samhāsurapatākāntaṃ sāśvebhapuruṣāyudham |
kṛtavāṃstaṃ pradeśaṃ yastejobhiḥ kīrṇakāñcanam
]

`v 13 [
vīkṣyamāṇe tu yāṣṭīke nivedayati rājani |
viśvāmitro muniḥ prāpta ityanuddhatayā girā
]

`v 14 [
iti yāṣṭīkavacanamākarṇya nṛpasattamaḥ |
sa samantrī sasāmantaḥ prottasthau hemaviṣṭarāt
]

`v 15 [
padātireva sahasā rājñāṃ vṛndena mālitaḥ |
vasiṣṭhavāmadevābhyāṃ saha sāmantasaṃstutaḥ
]

`v 16 [
jagāma `note[yatra tatrāsau] tatra yatrāsau viśvāmitro mahāmuniḥ |
dadarśa muniśārdūlaṃ dvārabhūmāvavasthitam
]

`v 17 [
kenāpi kāraṇenorvītalamarkamupāgatam |
brāhmeṇa tejasākrāntaṃ kṣātreṇa ca mahaujasā
]

`v 18 [
jarājaraṭhayā nityaṃ tapaḥprasararūkṣayā |
jaṭāvalyā vṛtaskandhaṃ sasaṃdhyābhramivācalam
]

`v 19 [
upaśāntaṃ ca kāntaṃ ca dīptamapratighāti ca |
nibhṛtaṃ corjitākāraṃ dadhānaṃ bhāsvaraṃ vapuḥ
]

`v 20 [
peśalenātibhīmena prasannenākulena ca |
gambhīreṇātipūrṇena tejasā rañjitaprabham
]

`v 21 [
anantajīvitadaśāsakhīmekāmaninditām |
dhārayantaṃ kare ślakṣaṇāṃ kuṇḍīmamlānamānasam
]

`v 22 [
karuṇākrāntacetastvātprasannairmadhurākṣaraiḥ |
vīkṣaṇairamṛteneva saṃsiñcantamimāḥ rajāḥ
]

`v 23 [
yuktayajñopavītāṅgaṃ dhavalapronnatabhruvam |
anantaṃ viṣmayaṃ cāntaḥ prayacchantamivekṣituḥ
]

`v 24 [
munimālokya bhūpālo dūrādevānatākṛtiḥ |
praṇanāma galanmaulimaṇimānitabhūtalam
]

`v 25 [
munirapyavanīnāthaṃ bhāsvāniva śatakratum |
tatrābhivādayāṃcakre madhurodārayā girā
]

`v 26 [
tato vasiṣṭhapramukhāḥ sarva eva dvijātayaḥ |
svāgatādikrameṇainaṃ pūjayāmāsurādṛtāḥ
]

`v 27 [
daśaratha uvāca |
aśaṅkitopanītena bhāsvatā darśanena te |
sādho svanugṛhītāḥ smo raviṇevāmbujākarāḥ
]

`v 28 [
uadanādi adakṣuṇṇaṃ yadapāyavivarjitam |
tadānandasukhaṃ prāptaṃ mayā tvaddarśanānmune
]

`v 29 [
adya vartāmahe nūnaṃ dhanyānāṃ dhuri dharmataḥ |
bhavadāgamanasyeme yadvayaṃ lakṣyamāgatāḥ
]

`v 30 [
evaṃ prakathayanto'tra rājāno'tha maharṣayaḥ |
āsaneṣu sabhāsthānamāsādya samupāviśan
]

`v 31 [
sa dṛṣṭvā mālitaṃ lakṣmyā bhītastamṛṣisattamam |
prahṛṣṭavadano rājā svayamarghyaṃ nyavedayat
]

`v 32 [
sa rājñaḥ pratigṛhyārghyaṃ śāstradṛṣṭena karmaṇā |
pradakṣiṇaṃ prakurvantaṃ rājānaṃ paryapūjayat
]

`v 33 [
sa rājñā pūjitastena prahṛṣṭavadanastadā |
kuśalaṃ cāvyayaṃ caiva paryapṛcchannarādhipam
]

`v 34 [
vasiṣṭhena samāgamya prahasya munipuṃgavaḥ |
yathārhaṃ cārcayitvainaṃ prapacchānāmayaṃ tataḥ
]

`v 35 [
kṣaṇaṃ yathārhamanyonyaṃ pūjayitvā sametya ca |
te sarve hṛṣṭamanaso mahārājaniveśane
]

`v 36 [
yathocitāsanagatā mithaḥ saṃvṛddhatejasaḥ |
paraspareṇa papracchuḥ sarve'nāmayamādarāt
]

`v 37 [
upaviṣṭāya tasmai sa viśvāmitrāya dhīmate |
pādyamarghyaṃ ca gāṃ caiva bhūyobhūyo nyavedayat
]

`v 38 [
arcayitvā tu vidhivadviśvāmitramabhāṣata |
prāñjaliḥ prayato vākyamidaṃ prītamanā nṛpaḥ
]

`v 39 [
yathā'mṛtasya saṃprāptiryathā varṣamavarṣake |
yathāndhasyekṣaṇaprāptirbhavadāgamanaṃ tathā
]

`v 40 [
yatheṣṭadārasaṃparkātputrajanmā'prajāvataḥ |
svapnadṛṣṭārthalābhaśca bhavadāgamanaṃ tathā
]

`v 41 [
yathepsitena saṃyoga iṣṭasyāgamanaṃ yathā |
praṇaṣṭasya yathā lābho bhavadāgamanaṃ tathā
]

`v 42 [
yathā harṣo nabhogatyā mṛtasya punarāgamāt |
tathā tvadāgamādbrahmansvāgataṃ te mahāmune
]

`v 43 [
brahmalokanivāso hi kasya na prītimāvahet |
mune tavāgamastadvatsatyameva bravīmi te
]

`v 44 [
kaśca te paramaḥ kāmaḥ kiṃ ca te karavāṇyaham |
pātrabhūto'si me vipra prāptaḥ paramadhārmikaḥ
]

`v 45 [
pūrvaṃ rājarṣiśabdena tapasā dyotitaprabhaḥ |
brahmarṣitvamanuprāptaḥ pūjyo'si bhagavanmayā
]

`v 46 [
gaṅgājalābhiṣekeṇa yathā prītirbhavenmama |
tathā tvaddarśanātprītirantaḥ śītayatīva mām
]

`v 47 [
vigatecchābhayakrodho vītarāgo nirāmayaḥ |
idamatyadbhutaṃ brahmanyadbhavānmāmupāgataḥ
]

`v 48 [
śubhakṣetragataṃ cāhamātmānamapakalmasam |
candrabimba ivonmagnaṃ vedavedya vidāṃvara
]

`v 49 [
devarṣijuṣṭasthānānāmeva kṣetratvāttvatsaṃnidhānādgṛhamapi tatheti bhāvaḥ |
atevāpakalmaṣamapagatapāpaṃ ataeva
dharmotkarṣādamṛtamayacandramaṇḍala-prāptyā tatronmagnamityutprekṣā |
48 |
sākṣādiva brahmaṇo me tavābhyāgamanaṃ matam |
pūto'smyanugṛhītaśca tavābhyāgamanānmune
]

`v 50 [
tvadāgamanapuṇyena sādho yadanurañjitam |
adya me saphalaṃ janma jīvitaṃ tatsujīvitam
]

`v 51 [
tvāmihābhyāgataṃ dṛṣṭvā pratipūjya praṇamya ca |
ātmanyeva namāmyantardṛṣṭvenduṃ jaladhiryathā
]

`v 52 [
yatkāryaṃ yena vārthena prāpto'si munipuṅgava |
kṛtamityeva tadviddhi mānyo'sīti sadā mama
]

`v 53 [
svakārye na vimarśaṃ tvaṃ kartumarhasi kauśika |
bhagavannāstyadeyaṃ me tvayi yatpratipadyate
]

`v 54 [
kāryasya na vicāraṃ tvaṃ kartumarhasi dharmataḥ |
kartā cāhamaśeṣaṃ te daivataṃ paramaṃ bhavān
]

`v 55 [
idamatimadhuraṃ niśamya vākyaṃ śrusukhamātmavidā vinītamuktam |
prathitagunayaśā guṇairviśiṣṭaṃ munivṛṣabhaḥ paramaṃ jagāma
harṣam
]