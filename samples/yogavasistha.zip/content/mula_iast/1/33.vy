`v 1 [
trayastriṃśaḥ sargaḥ 33
siddhā ūcuḥ |
pāvanasyāsya vacasaḥ proktasya raghuketunā |
nirṇayaṃ śrotumucitaṃ vakṣyamāṇaṃ maharṣibhiḥ
]

`v 2 [
nāradavyāsapulahapramukhā munipuṅgavāḥ |
āgacchatāśvavighnena sarva eva maharṣayaḥ
]

`v 3 [
`note[yatāmaḥ] patāmaḥ paritaḥ puṇyāmetāṃ dāśarathīṃ sabhām |
nīrandhrāṃ kanakoddyotāṃ padminīmiva ṣaṭpadāḥ
]

`v 4 [
śrīvālmīkiruvāca |
`note[ityuktā siddhairiti śeṣaḥ] ityuktā sā samastaiva vyomavāsanivāsinī |
tāṃ papāta sabhāṃ tatra divyā muniparamparā
]

`v 5 [
agrasthitamanutsṛṣṭaraṇadvīṇaṃ munīśvaram |
payaḥpīnaghanaśyāmaṃ vyāsameva kilāntarā
]

`v 6 [
bhṛgviṅgaraḥ pulastyādimunināyakamaṇḍitā |
cyavanoddālakośīraśaralomādimālitā
]

`v 7 [
parasparaparāmarśaduḥsaṃsthānamṛgājinā |
lolākṣamālāvalayā sukamaṇḍaludhāriṇī
]

`v 8 [
tārāvaliriva vyomni tejaḥ prasarapāṭalā |
sūryāvalirivānyonyaṃ bhāsitānanamaṇḍanā
]

`v 9 [
ratnāvalirivānyonyaṃ nānāvarṇakṛtāṅgikā |
muktāvalirivānyonyaṃ kṛtaśobhātiśāyinī
]

`v 10 [
kaumutīvṛṣṭiranyeva dvitīyevārkamaṇḍalī |
saṃbhṛtevātikālena pūrṇacandraparamparā
]

`v 11 [
tārājāla ivāmbhodo `note[ambhodhau] vyāso yatra virājate |
tāraugha iva śītāṃśurnārado'tra virājate
]

`v 12 [
deveṣviva surādhīśaḥ pulastyo'tra virājate |
āditya iva devānāmaṅgirāstu virājate
]

`v 13 [
asthāsyāṃ siddhasenāyāṃ patantyāṃ nabhaso rasām |
uttasthau munisaṃpūrṇā tadā dāśarathī sabhā
]

`v 14 [
miśrībhūtā virejuste nabhaścaramahīcarāḥ |
parasparavṛtāṅgābhā bhāsayanto diśo daśa
]

`v 15 [
veṇudaṇḍāvṛtakarā līlākamaladhāriṇaḥ |
durvāṅkurākrāntaśikhāḥ sacūḍāmaṇimūrdhajāḥ
]

`v 16 [
jaṭājūṭaiśca kapilā maulimālitamastakāḥ |
prakoṣṭhagākṣavalayā mallikāvalayānvitāḥ
]

`v 17 [
cīravalkalasaṃvītāḥ srakkauśaiyāvaguṇṭhitāḥ |
vilolamekhalāpāśāścalanmuktākalāpinaḥ
]

`v 18 [
cīravalkalayoravāntarajātyā bhedaḥ | kalāpino bhūṣitāḥ | karmadhārayāda##-
vasiṣṭhaviśvāmitrau tānpūjayāmāsatuḥ kramāt |
arghyaiḥ pādyairvacobhiśca sarvāneva nabhaścarān
]

`v 19 [
vasiṣṭhaviśvāmitrau te pūjayāmāsurādarāt |
arthyaiḥ pādyairvacobhiśca nabhaścaramahāgaṇāḥ
]

`v 20 [
sarvādareṇa siddhaughaṃ pūjayāmāsa bhūpatiḥ |
siddhaugho bhūpatiṃ caiva kuśalapraśnavārtayā
]

`v 21 [
taistaiḥ praṇayasaṃrambhairanyonyaṃ prāptasatkriyāḥ |
upāviśanviṣṭareṣu nabhaścaramahīcarāḥ
]

`v 22 [
vacobhiḥ puṣpavarṣeṇa sādhuvādena cābhitaḥ |
rāmaṃ te pūjayāmāsuḥ puraḥ praṇatamāsthitam
]

`v 23 [
āsāṃcakre ca tatrāsau rājyalakṣmīvirājitaḥ |
viśvāmitro vasiṣṭhaśca vāmadevo'tha mantriṇaḥ
]

`v 24 [
nārado devaputraśca vyāsaśca munipuṅgavaḥ |
marīciratha durvāsā munirāṅgirasastathā
]

`v 25 [
kratuḥ pulastyaḥ pulahaḥ śaralomā munīśvaraḥ |
vātsyāyano bharadvājo vālmīkirmunipuṅgavaḥ
]

`v 26 [
uddālaka ṛcīkaśca śaryātiścyavanastathā
]

`v 27 [
ete cānye ca bahavo vedavedāṅgapāragāḥ |
jñātajñeyā mahātmāna āsthitāstatra nāyakāḥ
]

`v 28 [
vasiṣṭhaviśvāmitrābhyāṃ saha te nāradādayaḥ |
idamūcuranūcānā rāmamānamitānanam
]

`v 29 [
aho bata kumāreṇa kalyāṇaguṇaśālinī |
vāguktā paramodārā vairāgyarasagarbhiṇī
]

`v 30 [
taduktīreva prapañcayati aho ityādibhiraṣṭādaśabhiḥ | kalyāṇairvakṣyamāṇa##-
pariniṣṭhitavaktavyaṃ sabodhamucitaṃ sphuṭam |
udāraṃ priyamāryārhamavihvalamapi sphuṭam
]

`v 31 [
vicāryetthameveti vyavasthāpitāḥ pariniṣṭhitā vaktavyārthā yasmin | sabodhaṃ
padārthatattvabodhasahitaṃ na kalpanāmātravyavasthāpitārthamiti yāvat | ataeva
vidvatsabhocitam | sphūṭaṃ vyaktavarṇam | udāramutkṛṣṭabahvāśayagarbham |
priyaṃ hṛdayānandanam | āryāṇāṃ pūjyānāmarhamucitam | avihvalaṃ citta##-
abhivyaktapadaṃ spaṣṭamiṣṭaṃ spaṣṭaṃ ca tuṣṭimat |
karoti rāghavaproktaṃ vacaḥ kasya na vismayam
]

`v 32 [
śatādekatamasyaiva sarvodāracamatkṛtiḥ |
īpsitārthārpaṇaikāntadakṣā bhavati bhāratī
]

`v 33 [
kumara tvāṃ vinā kasya vivekaphalaśālinī |
paraṃ vikāsamāyāti prajñāśaralatātatā
]

`v 34 [
prajñādīpaśikhā yasya rāmasyeva hṛdi sthitā |
prajvalatyasamālokakāriṇī sa pumānsmṛtaḥ
]

`v 35 [
raktamāṃsāsthiyantrāṇi bahūnyatitarāṇi ca |
padārthānabhikarṣanti nāsti teṣu sacetanaḥ
]

`v 36 [
janmamṛtyujarāduḥkhamanuyānti punaḥpunaḥ |
vimṛśanti na saṃsāraṃ paśavaḥ parimohitāḥ
]

`v 37 [
kathaṃcitkvacidevaiko dṛśyate vimalāśayaḥ |
pūrvāparavicārārho yathāyamarimardanaḥ
]

`v 38 [
anuttamacamatkāraphalāḥ subhagamūrtayaḥ |
bhavyā hi viralā loke sahakāradrumā iva
]

`v 39 [
samyagdṛṣṭajagadyātrā svavivekacamatkṛtiḥ |
asminmānyamatāvantariyamadyaiva dṛśyate
]

`v 40 [
subhagāḥ sulabhārohāḥ phalapallavaśālinaḥ |
jāyante taravo deśe na tu candanapādapāḥ
]

`v 41 [
vṛkṣāḥ prativanaṃ santi nityaṃ saphalapallavāḥ |
natvapūrvacamatkāro lavaṅgaḥ sulabhaḥ sadā
]

`v 42 [
jyotsneva śītā śaśinaḥ sutaroriva mañjarī |
puṣpādāmodalekheva dṛṣṭā rāmāccamatkṛtiḥ
]

`v 43 [
asminnuddāmadaurātmyadaivanirmāṇanirmite |
dvijendrā dagdhasaṃsāre sāro hyatyantadurlabhaḥ
]

`v 44 [
yatante sārasaṃprāptau ye yaśonidhayo dhiyaḥ |
dhanyā dhuri satāṃ gaṇyāsta eva puruṣottamāḥ
]

`v 45 [
na rāmeṇa samo'stīha dṛṣṭo lokeṣu kaścana |
vivekavānudārātmā na bhāvī ceti no matiḥ
]

`v 46 [
sakalalokacamatkṛtikāriṇo'pyabhimataṃ yadi rāghavacetasaḥ |
phalati no tadime vayameva hi sphuṭataraṃ munayo hatabuddhayaḥ
]